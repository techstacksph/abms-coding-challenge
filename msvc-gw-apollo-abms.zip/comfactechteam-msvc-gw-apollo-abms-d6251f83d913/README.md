# msvc-gw-apollo

This project contains the source code for an Apollo federated GraphQL gateway server. Its purpose is to support CTO's ecosystem of microservices.

Version: 1.0.0.0

## Installation

Node.js v18.17.1 is required to run this project.

**Node** : v18.17.1

 **NPM** : 9.6.7

 **Yarn** : 1.22.19

* Yarn will be used for executing command in package.json such as `yarn test`, `yarn dev`, `yarn build`, it will also be used or the installation of packages `yarn install`.

 **TypeScript** : 5.2.2

 **Jest** : 29.6.4

 **eslint** : 8.48.0

 **Apollo Server** : 4.9.3

 **Apollo Gateway** : 2.5.4

Pulsar Client: 1.9.0

### .env Config

Create a .env file to the root folder with the following variables and sample.

```bash
PORT=8080
NODE_ENV=test/local/staging/production
HOST_NAME=gateway-apollo/localhost
LOG_LEVEL=info
LOG_LABEL=apigateway
MICROSERVICE_URL=http://localhost:8081
APOLLO_SERVICE_LIST=[{ "name": "svc", "url": "http://localhost:8081" }]
SERVER_RETRIES_MAX=9
AUTH_API_URL=http://localhost:8082/v1   #base url for the authorization service
DISABLE_AUTH=false # Default value is false if not specified, disabling authentication will only run in test or local environment.
```

## Usage

To run the gateway locally with nodemon, such as in development:

```bash
yarn dev
```

To build the service, and start the service in production mode:

```bash
yarn build
yarn start
```

### Required environment variables

| Variable name           | Description                                                                                                                                                                                                                                                                                                                                                                             | Example                                                                                                       |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `APOLLO_SERVICE_LIST` | In order for the Gateway to run successfully, the `APOLLO_SERVICE_LIST` <br />environment var should be defined with a valid service list in JSON format.<br />Each entry must have a `name`, as well as a `url` pointing to a <br />microservice GraphQL endpoint that is available to the Gateway.<br />The JSON for this variable will be generated in CI/CD from a ConfigMap. | [  { "name": "person", "url": "http://localhost:8081" }, { "name": "iam", "url": "http://localhost:8082" } ] |

Locally, at least until we develop with the containerized stack, it would make sense to maintain a .env file with values that are appropriate for the microservices you want your local Gateway server to use.

Please ensure that you have linted and run all tests against your code prior to submitting a merge request.

* `yarn lint`
* `yarn test`

### Docker build

The Dockerfile also requires Nexus credentials. To build the image locally, please ensure that you export environment variables with your Nexus credentials, and then pass them to the build command via a build arg, like so:

#### For all platform

* `docker build -t msvc-gw-apollo:latest . --progress=plain`

#### For amd64 platform

* `docker build -t msvc-gw-bo:latest . --progress=plain --platform linux/amd64`

## Docker Development Environment

### Quick Start

For a complete development environment with hot reload functionality:

```bash
yarn docker:dev:full
```

This single command will:
- Create the necessary Docker network
- Start the Apollo Gateway microservice with hot reload enabled
- Connect to existing infrastructure services (Pulsar, etc.)

### Available Docker Commands

| Command | Description |
|---------|-------------|
| `yarn docker:dev:full` | Start Apollo Gateway development environment |
| `yarn docker:dev` | Start microservice only (same as dev:full) |
| `yarn docker:infrastructure` | Start Pulsar messaging service (if not already running) |
| `yarn docker:dev:down` | Stop development microservice |
| `yarn docker:infrastructure:down` | Stop all infrastructure services |

### Development Environment Features

**🔥 Hot Reload**: Code changes in the `src/` folder automatically restart the server
**🚀 One-Command Setup**: Full environment starts with single command
**📱 Web UI**: Access to Pulsar Express (http://localhost:3000) for message monitoring
**🔧 Consistent Environment**: All developers use identical setup
**⚡ Lightweight**: Uses existing infrastructure services from other microservices

### Environment Configuration

The development environment uses these key settings:

```env
NODE_ENV=local
PORT=3001
TENANT_PREFIX=abms
SYSTEM_ID=abmsgwapollo
MFE_ROOT_URL=http://localhost:3005
AUTH_API_URL=http://msvc-authorization:8082
APOLLO_SERVICE_LIST=[{"name":"msvc-abms","url":"http://msvc-cto-bo:8083"},{"name":"msvc-authorization","url":"http://msvc-authorization:8082"}]
PULSAR_SERVICE_URL=pulsar://pulsar-service:6650
```

### Service Discovery

When running with Docker, the gateway automatically connects to other microservices:
- **msvc-cto-bo**: `http://msvc-cto-bo:8083` (ABMS Core Service)
- **msvc-authorization**: `http://msvc-authorization:8082` (Authorization Service)

### Troubleshooting

**Container won't start**:
- Ensure Docker Desktop is running
- Check if ports 3001, 6650, 8080, 8081, 3000 are available
- Try `docker system prune` if disk space is full

**Hot reload not working**:
- Verify the `src/` folder is mounted correctly
- Check container logs with `docker logs msvc-gw-apollo-abms`

**Service discovery issues**:
- Ensure all dependent microservices (msvc-authorization, msvc-abms) are running and on the `local_bridge` network
- Verify service names in APOLLO_SERVICE_LIST match container names
- For standalone testing, temporarily modify APOLLO_SERVICE_LIST to point to running services or remove unavailable ones

**Pulsar connection failed**:
- Wait for Pulsar to fully start (may take 60-90 seconds)
- Check Pulsar logs with `docker logs broker`
- Verify Pulsar Express UI is accessible at http://localhost:3000

### Traditional Development vs Docker

**Docker Development (Recommended)**:
- Consistent environment across team
- Automatic service discovery
- Integrated Pulsar messaging
- Hot reload with volume mounts

**Traditional Development**:
- Direct `yarn dev` execution
- Manual service coordination
- Requires local Pulsar setup
- Environment variables from `.env` file

### Testing Hot Reload

To test that hot reload is working:

1. Start the development environment:
   ```bash
   yarn docker:dev:full
   ```

2. You should see: `[nodemon] starting ts-node ./src/server.ts`

3. Make a change to any file in the `src/` folder

4. You should see: `[nodemon] restarting due to changes...`

**Note**: The Apollo Gateway requires dependent microservices to be running. If you see connection errors to `msvc-authorization` or `msvc-abms`, start those services first or temporarily modify the `APOLLO_SERVICE_LIST` in `docker-compose.dev.yml`.

## Infrastructure Services

The Apollo Gateway requires the following infrastructure:

### Apache Pulsar (Message Broker)
- **Broker Port**: 6650
- **Admin Port**: 8080
- **Web UI**: http://localhost:3000 (Pulsar Express)
- **Purpose**: Handles messaging between microservices

## Docker compose files included in the code base

The Docker network `local_bridge` is automatically created when running the dev scripts.

* **PULSAR**: To run execute `docker compose -f docker-compose-pulsar.yml up -d`, to stop `docker compose -f docker-compose-pulsar.yml down`
* **DEVELOPMENT**: To run execute `docker compose -f docker-compose.dev.yml up --build`, to stop `docker compose -f docker-compose.dev.yml down`
