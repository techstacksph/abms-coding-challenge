#!/bin/sh
yarn start
