#!/bin/sh

echo "Starting Apollo Gateway in development mode..."
echo "Waiting for services to be available..."

# Simple service availability check
sleep 5

echo "Starting development server with hot reload..."
yarn dev