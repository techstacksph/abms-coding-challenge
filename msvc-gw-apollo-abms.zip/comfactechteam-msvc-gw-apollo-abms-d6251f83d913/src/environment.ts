import dotenv from 'dotenv';
import { toNumber } from 'lodash';
import os from 'os';
import process from 'process';

dotenv.config();

const {
  AUTH_API_URL,
  APOLLO_SERVICE_LIST,
  GRAPHQL_PATH,
  LOG_LABEL,
  LOG_LEVEL,
  NODE_ENV,
  PORT,
  SERVER_RETRIES_MAX,
  HOST_NAME,
  DISABLE_AUTH,
} = process.env;

export default {
  APOLLO_SERVICE_LIST: APOLLO_SERVICE_LIST,
  AUTH_API_URL: AUTH_API_URL ?? '',
  DISABLE_AUTH: (DISABLE_AUTH ?? ('' as string)).toLowerCase().includes('true')
    ? true
    : false,
  GRAPHQL_PATH: GRAPHQL_PATH ?? '/',
  HOST_NAME: HOST_NAME ?? os.hostname(),
  LOG_LABEL: LOG_LABEL ?? 'api-gateway-apollo',
  LOG_LEVEL: LOG_LEVEL ?? 'info',
  NODE_ENV: NODE_ENV ?? 'info',
  PORT: toNumber(PORT) ?? 8080,
  PULSAR_SERVICE_URL:
    process.env.PULSAR_SERVICE_URL || 'pulsar://localhost:6650',
  SERVER_RETRIES_MAX: SERVER_RETRIES_MAX ?? '9',
};
