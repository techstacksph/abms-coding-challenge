import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express from 'express';
import http from 'http';

import {
  ApolloGateway,
  GatewayConfig,
  IntrospectAndCompose,
} from '@apollo/gateway';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer';
import { createId as cuid } from '@paralleldrive/cuid2';

import environment from './environment';
import { buildService } from './utils/apollo-graphql-utils';
import {
  AuthorizationError,
  IAuthorizedUser,
  authorize,
  extractOperationName,
} from './utils/auth-utils';
import { logger } from './utils/logger-utils';

const SERVER_LIST = environment.APOLLO_SERVICE_LIST
  ? JSON.parse(environment.APOLLO_SERVICE_LIST)
  : '';

interface MyContext {
  access_token: string;
  authorizedUser: IAuthorizedUser;
  headers: {
    'correlation-id': string;
  };
}

async function startApolloServer() {
  const PORT = environment.PORT;
  const app = express();
  const httpServer = http.createServer(app);

  const gatewayConfig: GatewayConfig = {
    buildService,
    supergraphSdl: new IntrospectAndCompose({
      pollIntervalInMs: 1000 * 60 * 3,
      subgraphs: SERVER_LIST,
    }),
  };

  const gateway = new ApolloGateway(gatewayConfig);

  const server = new ApolloServer<MyContext>({
    formatError: (err) => {
      if (err instanceof AuthorizationError) {
        return {
          ...err,
          code: err.extensions.code,
          extensions: {},
        };
      } else {
        return {
          code: err.extensions?.code,
          extensions: { field: err.extensions?.field },
          message: err.message,
        };
      }
    },
    gateway,
    plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
  });

  await server.start();
  const corsOptions: {
    credentials: boolean;
    origin?: string;
    allowedHeaders?: string;
  } = {
    credentials: true,
  };

  corsOptions.allowedHeaders = '*';

  app.use(cors(corsOptions));
  app.use(cookieParser());
  app.use(bodyParser.json({ limit: '100mb' }));
  app.use(
    bodyParser.urlencoded({
      extended: true,
      limit: '100mb',
    })
  );

  app.use(
    expressMiddleware(server, {
      context: async ({ req }) => {
        logger.debug('type_of_request', { type: typeof req });

        const correlationId = cuid();
        const headers = {
          'correlation-id': correlationId,
        };

        // eslint-disable-next-line no-useless-catch
        try {
          // Extract operation name from the request
          const operationName = extractOperationName(req);

          logger.debug('graphql_request', {
            method: req.method,
            operationName,
            url: req.url,
          });

          // Pass operation name to authorize function for public operation detection
          const authorizedUser = await authorize(req, operationName);
          logger.debug('express_context_auth', { authorizedUser });
          return {
            access_token: 'string',
            authorizedUser: authorizedUser,
            headers,
          };

          //return authorizedUser;
        } catch (error) {
          logger.error('auth_request', { error });
          throw error;
        }
      },
    })
  );

  await new Promise<void>((resolve) =>
    httpServer.listen({ port: PORT }, resolve)
  );
  logger.info(`🚀 server_started`, { url: `http://localhost:${PORT}/` });
}

startApolloServer();
