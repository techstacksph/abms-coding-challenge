import { Request } from 'express';
import { GraphQLError } from 'graphql';
import { isBoolean } from 'lodash';
import fetch from 'node-fetch';
import { v4 as uuid } from 'uuid';

import environment from '../environment';
import { logger } from './logger-utils';

export interface IAuthorizedUser {
  email: string;
  external_id: string; // EXTERNAL USER ID, SHOULD BE CHANGED TO external_userid
  external_orgid: string;
  permission: {
    systemId: string;
    access: string[];
    departments: string[];
    functions: string[];
    locations: string[];
  };
  user_name: string;
  firstName: string;
  lastName: string;
}

interface IAccessToken {
  email: string;
  external_id: string; // EXTERNAL USER ID, SHOULD BE CHANGED TO external_userid
  external_orgid: string;
  permission: {
    access: string[];
    departments: string[];
    functions: string[];
    locations: string[];
    systemId: string;
  };
  user_name: string;
  firstName: string;
  lastName: string;
}

export class AuthorizationError extends GraphQLError {
  constructor(message: string, code = 'AUTHORIZATION_ERROR') {
    super(message, { extensions: { code } });
  }

  public name = 'AuthorizationError';
}

export class InsufficientPermissionsError extends GraphQLError {
  constructor(message: string) {
    super(message, { extensions: { code: 'INSUFFICIENT_PERMISSIONS_ERROR' } });
  }

  public name = 'InsufficientPermissionsError';
}

export class RefreshAccessTokenError extends AuthorizationError {
  constructor(message: string) {
    super(message, 'REFRESH_ACCESS_TOKEN_ERROR');
  }

  public name = 'RefreshAccessTokenError';
}

// Pattern for public operations that don't require authentication
// Matches operations with "public" in the name (e.g., abmspublicCountries, AbmspublicFindQuoteById)
// This allows any tenant prefix to work without hardcoding operation names
const PUBLIC_OPERATION_PATTERN = /public/i;

// Legacy hardcoded public operations for backward compatibility
// These will be removed once all services use the "public" naming convention
const LEGACY_PUBLIC_OPERATIONS = [
  'abmsapproveQuote',
  'abmsrejectQuote',
  'abmspostComment',
  'AbmsapproveQuote',
  'AbmsrejectQuote',
  'AbmspostComment',
  'abmstestQuote',
  'AbmstestQuote',
  'abmsallComments',
  'AbmsallComments',
];

/**
 * Check if an operation should be public (no authentication required)
 * Uses pattern matching to detect "public" in operation name,
 * plus legacy hardcoded list for backward compatibility
 */
export const isPublicOperation = (operationName: string): boolean => {
  // Check if operation name contains "public" (case-insensitive)
  if (PUBLIC_OPERATION_PATTERN.test(operationName)) {
    return true;
  }

  // Fallback to legacy hardcoded list
  return LEGACY_PUBLIC_OPERATIONS.includes(operationName);
};

/**
 * Extract operation name from GraphQL request
 */
export const extractOperationName = (req: Request): string | undefined => {
  try {
    if (req.body?.query) {
      // Simple regex to extract operation name from GraphQL query
      const operationMatch = req.body.query.match(/(?:query|mutation)\s+(\w+)/);
      return operationMatch ? operationMatch[1] : undefined;
    }
    return undefined;
  } catch (error) {
    logger.debug('error_extracting_operation_name', { error });
    return undefined;
  }
};

const AuthServiceTokenPermission = async (
  access_token: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> => {
  const params = {
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'GET',
  };

  const auth_url = `${environment.AUTH_API_URL}/v1/authenticate/token/permission/${access_token}`;
  logger.debug('auth_service_url', { auth_url });
  const resp = await fetch(auth_url, params);
  if (resp.status === 200) {
    const validate_resp = await resp.json();

    if (!validate_resp.valid) {
      logger.error(
        `Unable to Authorize - authorization service status ${
          resp.status
        } Error. ${validate_resp.valid ? 'Valid' : 'Invalid'} token`
      );
      throw new AuthorizationError(
        'Unable to Authenticate, invalid token - Internal Server Error'
      );
    }

    return validate_resp;
  }

  logger.error(
    `Unable to Authorize - authorization service status ${resp.status} Error`
  );
  throw new AuthorizationError('Unable to Auth - Internal Server Error');
};

export const authorize = async (
  req: Request,
  operationName?: string
): Promise<IAuthorizedUser> => {
  logger.debug('auth_config', {
    auth_config: environment.DISABLE_AUTH,
    disable_auth: environment.DISABLE_AUTH == true,
    isBool: isBoolean(environment.DISABLE_AUTH),
    operationName,
  });

  // Check if this is a public operation (works in production)
  if (operationName && isPublicOperation(operationName)) {
    logger.debug('public_operation_detected', { operationName });
    return Promise.resolve(testUserPermission());
  }

  if (
    environment.DISABLE_AUTH &&
    ['local', 'test'].includes(environment.NODE_ENV)
  ) {
    logger.debug('authentication_disabled', { auth: testUserPermission() });
    return Promise.resolve(testUserPermission());
  }

  let { access_token, refresh_token } = req.cookies;

  if (!access_token) {
    access_token = req.headers.authorization;
  }

  if (!refresh_token) {
    refresh_token = req.headers['refresh_token'];
  }

  if (!access_token && operationName && !isPublicOperation(operationName)) {
    throw new InsufficientPermissionsError(
      'Unable to Auth - Access Token not found'
    );
  }

  if (!refresh_token && !req.headers.authorization) {
    throw new InsufficientPermissionsError(
      'Unable to Auth - Refresh Token not found'
    );
  }

  // GET PERMISSION BY TOKEN FROM AUTH SERVICE

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const tokenPermission = await AuthServiceTokenPermission(access_token);

  const {
    email,
    external_id,
    external_orgid,
    firstName,
    lastName,
    permission,
    user_name,
  } = tokenPermission.userPermission as IAccessToken;

  const result: IAuthorizedUser = {
    email,
    external_id,
    external_orgid,
    firstName,
    lastName,
    permission,
    user_name,
  };

  logger.debug('user_permission', { result, tokenPermission });

  return Promise.resolve(result);
};

export const testUserPermission = (): IAccessToken => {
  return {
    email: 'test@extendSchemaImpl.com',
    external_id: uuid(),
    external_orgid: uuid(),
    firstName: 'John',
    lastName: 'Doe',
    permission: {
      access: [
        'organization.read.*',
        'organization.create.*',
        'organization.update.*',
        'organization.delete.*',
        'organization.*.*',
      ],
      departments: [],
      functions: [],
      locations: [],
      systemId: 'msvc-cto-bo',
    },

    user_name: 'test@user',
  };
};
