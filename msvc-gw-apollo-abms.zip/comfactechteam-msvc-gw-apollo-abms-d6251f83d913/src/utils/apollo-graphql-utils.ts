import {
  RemoteGraphQLDataSource,
  ServiceEndpointDefinition,
} from '@apollo/gateway';
import { createId as cuid } from '@paralleldrive/cuid2';

import { logger } from './logger-utils';

export function buildService({
  url,
}: ServiceEndpointDefinition): AuthorizedDataSource {
  return new AuthorizedDataSource({ url });
}

export class AuthorizedDataSource extends RemoteGraphQLDataSource {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  willSendRequest({ request, context }): void {
    let correlationId: string;

    if (context.headers && context.headers['correlation-id']) {
      correlationId = context.headers['correlation-id'];
    } else {
      correlationId = cuid();

      if (context.headers) {
        context.headers['correlation-id'] = correlationId;
      } else {
        context.headers = { 'correlation-id': correlationId };
      }
    }

    logger.debug(`Sending GraphQL request`, {
      correlationId,
      destination: request.http?.url,
      query: request.query,
      variables: request.variables,
    });
    logger.debug(`Sending GraphQL Context`, {
      context,
      correlationId,
    });

    request.extensions = {
      ...context,
    };
    request.http?.headers.set('correlation-id', correlationId);
  }
}
