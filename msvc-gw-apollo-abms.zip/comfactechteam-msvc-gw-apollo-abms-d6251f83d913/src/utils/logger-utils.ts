import morgan from 'morgan';
import morganJson from 'morgan-json';
import { config, createLogger, format, transports } from 'winston';

import env from '../environment';
import environment from '../environment';

const { combine, label, timestamp, json, prettyPrint } = format;

const ignoreHealthChecks = format((info) => {
  if (info.url === '/.well-known/apollo/server-health') {
    return false;
  }

  return info;
});

const loggingFormat = combine(
  ignoreHealthChecks(),
  label({ label: env.LOG_LABEL }),
  timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  json()
);

const loggingOptions = {
  console: {
    handleExceptions: true,
    handleRejections: true,
    level: env.LOG_LEVEL,
  },
};

const jsonWithTimestamp = {
  exitOnError: false,
  format: ['local', 'test'].includes(environment.NODE_ENV)
    ? combine(loggingFormat, prettyPrint())
    : loggingFormat,
  levels: config.npm.levels,
  transports: [new transports.Console(loggingOptions.console)],
};

export const httpLogger = morgan(
  morganJson({
    contentLength: ':res[content-length]',
    correlationId: ':req[correlation-id]',
    method: ':method',
    responseTime: ':response-time',
    status: ':status',
    url: ':url',
  }),
  {
    stream: {
      write: (message: string) => {
        const {
          method,
          url,
          status,
          contentLength,
          correlationId,
          responseTime,
        } = JSON.parse(message);

        logger.info('HTTP Access Log', {
          contentLength: Number(contentLength),
          correlationId,
          method,
          responseTime: Number(responseTime),
          status: Number(status),
          url,
        });
      },
    },
  }
);

export const logger = createLogger(jsonWithTimestamp);
