import 'reflect-metadata';

import { logger } from './src/utils/LoggerUtils';

export default async () => {
  //Jest global async setup here if any
  logger.debug('global_setup_init');
};
