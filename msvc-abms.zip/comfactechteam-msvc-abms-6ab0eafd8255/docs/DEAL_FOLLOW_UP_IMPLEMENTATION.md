# Deal Follow-Up Email Implementation

This document describes the implementation of the deal follow-up email functionality for the ABMS system.

**Implementation Date**: June 2025

## Overview

The deal follow-up email system automatically sends email notifications to deal record owners in two scenarios:

1. **Auto Follow-Up Emails**: Sent when a deal has been in "Pending" status for a specified number of days without any status changes
2. **Target Close Date Emails**: Sent when a deal's target close date has passed by a specified number of days and the deal is not in "Closed Won" or "Closed Lost" status

## Configuration

The system uses company settings to configure the follow-up behavior:

- **Auto Follow-Up Days**: Number of days a deal must be in Pending status before sending a follow-up email
- **Target Close Days**: Number of days to wait after the target close date before sending a notification email

These settings are configured in:
- Settings > System Preference Settings > Sales Preferences > Auto follow-up on deals

## Implementation Components

### 1. DealFollowUpService (`src/services/DealFollowUpService.ts`)

The main service that handles the deal follow-up email processing:

- `processDealFollowUpEmails()`: Main method called by the scheduled job
- `processAutoFollowUpEmails()`: Processes auto follow-up emails for deals in Pending status
- `processTargetCloseDateEmails()`: Processes target close date emails for deals whose target close date has passed by the specified number of days
- `sendAutoFollowUpEmail()`: Sends auto follow-up email for a specific deal
- `sendTargetCloseDateEmail()`: Sends target close date email for a specific deal
- `sendDealEmail()`: Generic method to send emails and create communication logs

### 2. DealFollowUpResolver (`src/resolver/DealFollowUpResolver.ts`)

GraphQL resolver that exposes the deal follow-up functionality:

- `processDealFollowUpEmails()`: Mutation that can be called to manually trigger the process

### 3. Scheduled Job

A scheduled job runs daily at 8:00 AM to process deal follow-up emails:

- **Job Name**: `DEAL_FOLLOW_UP_EMAILS`
- **Schedule**: `0 8 * * *` (Daily at 8:00 AM)
- **Function**: `processDealFollowUpEmails`

### 4. Pulsar Integration

The system integrates with Pulsar for message processing:

- Messages are sent to the `COMMUNICATION_MEDIA` topic for email delivery
- Communication logs are created for each email sent
- The system handles both successful and failed email attempts

### 5. DealConsumerService (Deprecated)

**Note**: The existing `DealConsumerService.sendDealEmail()` method has been deprecated in favor of the new `DealFollowUpService`. The old implementation:
- Only creates communication logs without sending actual emails
- Has no duplicate prevention
- Provides basic functionality compared to the new service

**Migration**: Use `DealFollowUpService` for all new deal email functionality.

## Email Templates

### Auto Follow-Up Email

**Subject**: AYR Deal Notification

**Content**:
```
Hi [Deal's record owner],

This is a reminder to follow up on the Deal [Deal number].
Click here to view this Deal: [Deal link]
```

### Target Close Date Email

**Subject**: AYR Deal Notification

**Content**:
```
Hi [Deal's record owner],

This is a reminder that [Deal number] target close date has been reached.
Target close date: [Target close date]
Click here to view this Deal: [Deal link]
```

**Note**: This email is sent only after the target close date has passed by the number of days specified in the "Target close date (days)" setting.

## Email Configuration

Emails are sent using the mail server settings configured in:
- Settings > Email Settings

The system uses:
- **Sender**: Mail account from Email server settings
- **Recipient**: Deal's record owner email
- **Reply-To**: Mail account from Email server settings

## Communication Logs

For each email sent, a communication log is created with:
- **Activity Type**: Email
- **Sender**: Mail account from Email server settings
- **Recipient**: Deal's record owner
- **Subject**: AYR Deal Notification
- **Message**: The email content
- **Related Deal**: Links to the specific deal

## Duplicate Prevention

The system prevents duplicate emails by:
- Checking for any previous communication logs with the same subject and content pattern
- Only sending one email per deal per type (auto follow-up or target close date) - once sent, it will never be sent again
- This ensures that follow-up emails are not sent repeatedly for the same deal

## Error Handling

The system includes comprehensive error handling:
- Logs all operations and errors
- Continues processing other deals if one fails
- Creates communication logs even if email delivery fails
- Graceful handling of missing configuration or data

## Testing

A test file is included at `src/test/services/DealFollowUpService.test.ts` that verifies:
- Service instantiation
- Basic functionality without errors
- Proper handling of edge cases

## Usage

### Automatic Processing

The system automatically processes deal follow-up emails daily at 8:00 AM. No manual intervention is required.

### Example Scenarios

**Auto Follow-Up**:
- Deal status: "Pending" since June 1, 2025
- Auto follow-up setting: 21 days
- Email sent: June 22, 2025 (21 days after status became Pending)

**Target Close Date**:
- Deal target close date: June 1, 2025
- Target close days setting: 7 days
- Email sent: June 8, 2025 (7 days after target close date passed)
- Condition: Only if status is not "Closed Won" or "Closed Lost"

### Manual Processing

To manually trigger the process, you can call the GraphQL mutation:

```graphql
mutation {
  processDealFollowUpEmails
}
```

### Configuration

To configure the system:

1. Go to Settings > System Preference Settings > Sales Preferences
2. Set "Auto follow-up on deals" to the desired number of days
3. Set "Target close date (days)" to the desired number of days
4. Configure email server settings in Settings > Email Settings

## Monitoring

The system logs all activities:
- Start and completion of processing
- Number of deals found for each type
- Email sending status
- Communication log creation
- Any errors encountered

Check the application logs to monitor the system's operation.

## Migration from DealConsumerService

### Deprecation Notice

The existing `DealConsumerService.sendDealEmail()` method has been deprecated and will show deprecation warnings when used. The old implementation has several limitations:

- **No Actual Email Sending**: Only creates communication logs without sending emails
- **No Duplicate Prevention**: Can send multiple emails for the same deal
- **Basic Error Handling**: Limited error handling and logging
- **Manual Triggering**: Requires manual or event-based triggering

### Migration Benefits

The new `DealFollowUpService` provides significant improvements:

- **✅ Actual Email Delivery**: Sends emails via Pulsar to the communication media service
- **✅ Permanent Duplicate Prevention**: Once sent, emails are never sent again for the same deal
- **✅ Automated Scheduling**: Runs daily at 8:00 AM automatically
- **✅ Comprehensive Logging**: Detailed logs for monitoring and debugging
- **✅ Robust Error Handling**: Graceful handling of failures and edge cases
- **✅ Better Email Content**: Improved formatting and link display

### Migration Steps

1. **Immediate**: Existing code continues to work with deprecation warnings
2. **Short-term**: Update any new integrations to use `DealFollowUpService`
3. **Long-term**: Gradually migrate existing integrations to the new service

### Code Comparison

**Old (Deprecated)**:
```typescript
// Only creates communication logs, no actual email sending
await dealConsumerService.sendDealEmail(dealId, emailType, dataOptions);
```

**New (Recommended)**:
```typescript
// Sends actual emails and creates communication logs
await dealFollowUpService.processDealFollowUpEmails(dataOptions);
``` 