# DataLoader Implementation Guide

## Table of Contents
1. [What is DataLoader?](#what-is-dataloader)
2. [Why Use DataLoader?](#why-use-dataloader)
3. [Architecture Overview](#architecture-overview)
4. [Implementation Steps](#implementation-steps)
5. [Code Examples](#code-examples)
6. [Best Practices](#best-practices)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

---

## What is DataLoader?

DataLoader is a generic utility library created by Facebook that provides:
- **Batching**: Combines multiple individual data requests into a single batch request
- **Caching**: Provides a memoization cache per-request to avoid duplicate loads
- **Simplified API**: Easy-to-use interface for loading data asynchronously

In GraphQL, DataLoader solves the **N+1 query problem** where nested field resolvers trigger multiple duplicate database queries.

### The N+1 Problem Example

Without DataLoader:
```graphql
query {
  jobs(limit: 100) {
    id
    account {      # 100 separate queries!
      name
    }
    site {         # 100 separate queries!
      name
    }
  }
}
```
**Result**: 1 query for jobs + 100 queries for accounts + 100 queries for sites = **201 total queries**

With DataLoader:
```graphql
# Same query as above
```
**Result**: 1 query for jobs + 1 batched query for accounts + 1 batched query for sites = **3 total queries**

---

## Why Use DataLoader?

### Benefits

1. **Performance**
   - Reduces database queries from O(n) to O(1) per relationship type
   - Example: 100 jobs with 10 relationships = 1,001 queries → 11 queries

2. **Automatic Batching**
   - Collects all loads within a single tick of the event loop
   - Executes one database query with `IN` clause

3. **Request-level Caching**
   - Prevents duplicate queries within the same GraphQL request
   - Automatically cleared between requests

4. **Type Safety**
   - Full TypeScript support with generic types
   - Compile-time checks for data integrity

5. **Simplified Code**
   - Cleaner resolver code without manual batching logic
   - Centralized data loading patterns

### When to Use DataLoader

✅ **Use DataLoader for:**
- Many-to-one relationships (e.g., job → account)
- One-to-many relationships (e.g., job → jobDetails)
- Frequently accessed relationships
- Resolvers that load data by ID or foreign key

❌ **Don't use DataLoader for:**
- Single queries (no batching benefit)
- Search/filter operations (use direct queries)
- Aggregations (use database queries)

---

## Architecture Overview

### File Structure

```
src/
├── utils/
│   ├── DataLoaderUtils.ts       # DataLoader factory functions
│   └── GraphqlUtils.ts          # Context interface with DataLoaders
│
├── resolver/
│   ├── JobResolver.ts           # Uses job DataLoaders
│   └── QualityAuditResolver.ts  # Uses qualityAudit DataLoaders
│
└── datasource/
    └── models/
        ├── JobModel.ts          # Entity models
        └── AccountModel.ts
```

### Components

1. **DataLoaderUtils.ts** - Central utility file
   - Generic factory functions (`createEntityLoader`, `createOneToManyLoader`)
   - Domain-specific interfaces (`JobDataLoaders`, `QualityAuditDataLoaders`)
   - Factory functions for creating all loaders (`createJobDataLoaders`)

2. **GraphqlUtils.ts** - Context definition
   - `IGraphQLContext` interface with `dataLoaders` property
   - TypeScript types for compile-time safety

3. **Resolvers** - GraphQL resolvers
   - FieldResolvers using `@FieldResolver()` decorator
   - Lazy DataLoader initialization with `getDataLoaders()` helper
   - Batched data loading in field resolvers

---

## Implementation Steps

### Step 1: Install DataLoader

```bash
yarn add dataloader
yarn add -D @types/dataloader
```

### Step 2: Add DataLoader Interface to DataLoaderUtils.ts

Define the interface for your domain entity's loaders:

```typescript
// src/utils/DataLoaderUtils.ts

import DataLoader from 'dataloader';
import { FindManyOptions, In } from 'typeorm';
import { JobModel } from '../datasource/models/JobModel';
import { AccountModel } from '../datasource/models/AccountModel';
// ... other imports

/**
 * Job specific DataLoaders
 */
export interface JobDataLoaders {
  // Many-to-one relationships (single entity)
  accountLoader: DataLoader<string, AccountModel | null>;
  siteLoader: DataLoader<string, SiteModel | null>;

  // One-to-many relationships (array of entities)
  jobDetailsLoader: DataLoader<string, JobDetailsModel[]>;
  jobBillingsLoader: DataLoader<string, JobBillingModel[]>;
}
```

### Step 3: Create Factory Function

Implement the factory function to create all loaders:

```typescript
// src/utils/DataLoaderUtils.ts

/**
 * Creates all DataLoaders for Job resolver
 * @param dataOptions Data options for org isolation
 * @returns Object containing all DataLoaders
 */
export function createJobDataLoaders(
  dataOptions?: DataOptionsDto
): JobDataLoaders {
  // Optional: Configure loaders with nested relations
  const accountDataOptions: DataOptionsDto = {
    ...(dataOptions || {}),
    findManyOptions: {
      ...(dataOptions?.findManyOptions || {}),
      relations: ['status', 'primaryContact'], // Eager load nested data
    },
  };

  return {
    // Many-to-one loaders
    accountLoader: createEntityLoader(AccountModel, accountDataOptions),
    siteLoader: createEntityLoader(SiteModel, dataOptions),

    // One-to-many loaders
    jobDetailsLoader: createOneToManyLoader(
      JobDetailsModel,
      'jobId', // Foreign key field name
      dataOptions
    ),
    jobBillingsLoader: createOneToManyLoader(
      JobBillingModel,
      'jobId',
      dataOptions
    ),
  };
}
```

### Step 4: Update GraphQL Context

Add your DataLoaders to the context interface:

```typescript
// src/utils/GraphqlUtils.ts

import { JobDataLoaders, QualityAuditDataLoaders } from './DataLoaderUtils';

export interface IGraphQLContext {
  authorizedUser: IAuthorizedUser;
  correlationId: string | string[];
  logger: Logger;
  dataLoaders?: {
    qualityAudit?: QualityAuditDataLoaders;
    job?: JobDataLoaders;  // Add this line
    // Add more DataLoaders for other resolvers as needed
  };
}
```

### Step 5: Implement FieldResolvers

Add FieldResolvers to your GraphQL resolver:

```typescript
// src/resolver/JobResolver.ts

import {
  Arg,
  Ctx,
  FieldResolver,  // Add this
  Mutation,
  Query,
  Resolver,
  Root,  // Add this
} from 'type-graphql';
import { createJobDataLoaders } from '../utils/DataLoaderUtils';
import { JobModel } from '../datasource/models/JobModel';
import { JobSchema } from '../schema/JobSchema';

@Service()
@Resolver(() => JobSchema)
export default class JobResolver extends BaseResolver {
  // ... constructor and other code

  /**
   * Lazy initialization of DataLoaders
   * Creates DataLoaders on first use, reuses for subsequent calls
   */
  private getDataLoaders(ctx: IGraphQLContext) {
    if (!ctx.dataLoaders) {
      ctx.dataLoaders = {};
    }
    if (!ctx.dataLoaders.job) {
      const dataOptions = this.toDataOptions(ctx);
      ctx.dataLoaders.job = createJobDataLoaders(dataOptions);
    }
    return ctx.dataLoaders.job;
  }

  /**
   * FieldResolver for many-to-one relationship (job → account)
   */
  @FieldResolver()
  async account(
    @Root() job: JobModel & JobSchema,
    @Ctx() ctx: IGraphQLContext
  ) {
    if (!job.accountId) return null;
    const loaders = this.getDataLoaders(ctx);
    return loaders.accountLoader.load(job.accountId);
  }

  /**
   * FieldResolver for one-to-many relationship (job → jobDetails)
   */
  @FieldResolver()
  async jobDetails(
    @Root() job: JobModel & JobSchema,
    @Ctx() ctx: IGraphQLContext
  ) {
    const loaders = this.getDataLoaders(ctx);
    return loaders.jobDetailsLoader.load(job.id);
  }

  // Repeat for all relationships...
}
```

### Step 6: Remove Eager Loading

Remove any `setSchemaRelations` or manual relation loading from queries:

```typescript
// BEFORE (causes N+1 problem)
@Query(() => PaginatedJobs)
async paginatedJobs(
  @Ctx() ctx: IGraphQLContext,
  @Info() info: unknown,  // Used for setSchemaRelations
  @Arg('pageArg') pageArg: PageArg
) {
  const dataOptions = this.toDataOptions(ctx);

  // ❌ Remove this - causes eager loading
  setSchemaRelations(info, dataOptions, JobModel.name);

  return this.service.findAndCount(pageArg, dataOptions);
}

// AFTER (uses DataLoader FieldResolvers)
@Query(() => PaginatedJobs)
async paginatedJobs(
  @Ctx() ctx: IGraphQLContext,
  @Arg('pageArg') pageArg: PageArg
) {
  const dataOptions = this.toDataOptions(ctx);

  // ✅ No manual relations - FieldResolvers handle it
  return this.service.findAndCount(pageArg, dataOptions);
}
```

---

## Code Examples

### Example 1: Simple Many-to-One Relationship

Loading a job's account:

```typescript
// JobResolver.ts

@FieldResolver()
async account(
  @Root() job: JobModel & JobSchema,
  @Ctx() ctx: IGraphQLContext
) {
  // Null check - return early if no relationship
  if (!job.accountId) return null;

  // Get loaders (creates on first call, caches for request)
  const loaders = this.getDataLoaders(ctx);

  // Load account by ID (batched automatically)
  return loaders.accountLoader.load(job.accountId);
}
```

**GraphQL Query:**
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account {  # FieldResolver triggered here
        id
        name
      }
    }
  }
}
```

**Database Queries:**
```sql
-- Query 1: Load jobs
SELECT * FROM jobs LIMIT 10;

-- Query 2: Load accounts (batched)
SELECT * FROM accounts WHERE id IN ('id1', 'id2', ..., 'id10');
```

### Example 2: One-to-Many Relationship

Loading a job's details:

```typescript
// JobResolver.ts

@FieldResolver()
async jobDetails(
  @Root() job: JobModel & JobSchema,
  @Ctx() ctx: IGraphQLContext
) {
  const loaders = this.getDataLoaders(ctx);

  // Load all job details for this job (batched by jobId)
  return loaders.jobDetailsLoader.load(job.id);
}
```

**GraphQL Query:**
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      jobDetails {  # FieldResolver triggered here
        id
        area
        frequency
      }
    }
  }
}
```

**Database Queries:**
```sql
-- Query 1: Load jobs
SELECT * FROM jobs LIMIT 10;

-- Query 2: Load job details (batched)
SELECT * FROM job_details WHERE jobId IN ('id1', 'id2', ..., 'id10');
```

### Example 3: Nested Relations with Eager Loading

Loading account with its nested status and primaryContact:

```typescript
// DataLoaderUtils.ts

export function createJobDataLoaders(
  dataOptions?: DataOptionsDto
): JobDataLoaders {
  // Configure account loader to include nested relations
  const accountDataOptions: DataOptionsDto = {
    ...(dataOptions || {}),
    findManyOptions: {
      ...(dataOptions?.findManyOptions || {}),
      relations: ['status', 'primaryContact'],  // Eager load
    },
  };

  return {
    accountLoader: createEntityLoader(AccountModel, accountDataOptions),
    // ... other loaders
  };
}
```

**GraphQL Query:**
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account {
        id
        name
        status {          # Loaded with account (nested relation)
          name
        }
        primaryContact {  # Loaded with account (nested relation)
          firstName
          lastName
        }
      }
    }
  }
}
```

**Database Queries:**
```sql
-- Query 1: Load jobs
SELECT * FROM jobs LIMIT 10;

-- Query 2: Load accounts with nested relations (single batched query)
SELECT a.*, s.*, c.*
FROM accounts a
LEFT JOIN workflow_statuses s ON a.statusId = s.id
LEFT JOIN contacts c ON a.primaryContactId = c.id
WHERE a.id IN ('id1', 'id2', ..., 'id10');
```

### Example 4: Multiple Relationships in One Query

Loading multiple relationships efficiently:

```typescript
// GraphQL Query
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account { id name }        # FieldResolver 1
      site { id name }           # FieldResolver 2
      contact { id firstName }   # FieldResolver 3
      jobDetails { id area }     # FieldResolver 4
      jobBillings { id amount }  # FieldResolver 5
    }
  }
}
```

**Database Queries (only 6 total):**
```sql
-- 1. Load jobs
SELECT * FROM jobs LIMIT 10;

-- 2. Load accounts (batched)
SELECT * FROM accounts WHERE id IN (...);

-- 3. Load sites (batched)
SELECT * FROM sites WHERE id IN (...);

-- 4. Load contacts (batched)
SELECT * FROM contacts WHERE id IN (...);

-- 5. Load job details (batched by jobId)
SELECT * FROM job_details WHERE jobId IN (...);

-- 6. Load job billings (batched by jobId)
SELECT * FROM job_billings WHERE jobId IN (...);
```

**Without DataLoader**: 1 + (10 × 5) = **51 queries**
**With DataLoader**: **6 queries**

---

## Best Practices

### 1. Lazy Initialization Pattern

Always create DataLoaders lazily per request:

```typescript
// ✅ GOOD - Lazy initialization in resolver
private getDataLoaders(ctx: IGraphQLContext) {
  if (!ctx.dataLoaders) {
    ctx.dataLoaders = {};
  }
  if (!ctx.dataLoaders.job) {
    const dataOptions = this.toDataOptions(ctx);
    ctx.dataLoaders.job = createJobDataLoaders(dataOptions);
  }
  return ctx.dataLoaders.job;
}

// ❌ BAD - Creating in server.ts or globally
// DataLoaders must be request-scoped!
const globalLoaders = createJobDataLoaders();
```

### 2. Null Checks for Optional Relationships

Always check if the foreign key exists before loading:

```typescript
// ✅ GOOD - Null check
@FieldResolver()
async account(@Root() job: JobModel & JobSchema, @Ctx() ctx: IGraphQLContext) {
  if (!job.accountId) return null;  // Early return
  const loaders = this.getDataLoaders(ctx);
  return loaders.accountLoader.load(job.accountId);
}

// ❌ BAD - No null check
@FieldResolver()
async account(@Root() job: JobModel & JobSchema, @Ctx() ctx: IGraphQLContext) {
  const loaders = this.getDataLoaders(ctx);
  return loaders.accountLoader.load(job.accountId);  // Might be undefined!
}
```

### 3. Use Nested Relations for Frequently Accessed Data

Configure loaders with nested relations to avoid additional DataLoaders:

```typescript
// ✅ GOOD - Account loader includes frequently accessed nested data
const accountDataOptions: DataOptionsDto = {
  ...(dataOptions || {}),
  findManyOptions: {
    ...(dataOptions?.findManyOptions || {}),
    relations: ['status', 'primaryContact'],  // Common use case
  },
};

return {
  accountLoader: createEntityLoader(AccountModel, accountDataOptions),
};

// ❌ BAD - Requires separate DataLoaders for status and primaryContact
return {
  accountLoader: createEntityLoader(AccountModel, dataOptions),
  accountStatusLoader: createEntityLoader(WorkflowStatusModel, dataOptions),
  accountContactLoader: createEntityLoader(ContactModel, dataOptions),
};
```

### 4. Remove Eager Loading from Queries

Don't mix eager loading with DataLoader FieldResolvers:

```typescript
// ❌ BAD - Conflict between eager loading and FieldResolvers
@Query(() => PaginatedJobs)
async paginatedJobs(@Ctx() ctx: IGraphQLContext, @Info() info: unknown) {
  const dataOptions = this.toDataOptions(ctx);

  // This loads relations eagerly...
  setSchemaRelations(info, dataOptions, JobModel.name);

  // ...then FieldResolvers try to load them again!
  return this.service.findAndCount(pageArg, dataOptions);
}

// ✅ GOOD - Let FieldResolvers handle all relation loading
@Query(() => PaginatedJobs)
async paginatedJobs(@Ctx() ctx: IGraphQLContext) {
  const dataOptions = this.toDataOptions(ctx);
  // No manual relation loading - FieldResolvers do it
  return this.service.findAndCount(pageArg, dataOptions);
}
```

### 5. Consistent Naming Convention

Follow consistent naming for loaders:

```typescript
// ✅ GOOD - Clear, consistent naming
export interface JobDataLoaders {
  accountLoader: DataLoader<string, AccountModel | null>;      // many-to-one
  siteLoader: DataLoader<string, SiteModel | null>;            // many-to-one
  jobDetailsLoader: DataLoader<string, JobDetailsModel[]>;     // one-to-many
  jobBillingsLoader: DataLoader<string, JobBillingModel[]>;    // one-to-many
}

// ❌ BAD - Inconsistent naming
export interface JobDataLoaders {
  loadAccount: DataLoader<string, AccountModel | null>;
  getSite: DataLoader<string, SiteModel | null>;
  details: DataLoader<string, JobDetailsModel[]>;
}
```

### 6. Use Intersection Types in FieldResolvers

Combine Model and Schema types for proper typing:

```typescript
// ✅ GOOD - Intersection type
@FieldResolver()
async account(
  @Root() job: JobModel & JobSchema,  // Has both model and schema fields
  @Ctx() ctx: IGraphQLContext
) {
  // Can access job.accountId (from model) and job.id (from schema)
}

// ❌ BAD - Only schema type
@FieldResolver()
async account(
  @Root() job: JobSchema,  // Missing model fields!
  @Ctx() ctx: IGraphQLContext
) {
  // Can't access job.accountId!
}
```

### 7. Keep Generic Loaders in DataLoaderUtils

Don't create DataLoaders inline - use the generic factory functions:

```typescript
// ✅ GOOD - Use generic factory
export function createJobDataLoaders(dataOptions?: DataOptionsDto): JobDataLoaders {
  return {
    accountLoader: createEntityLoader(AccountModel, dataOptions),
  };
}

// ❌ BAD - Inline DataLoader creation
export function createJobDataLoaders(dataOptions?: DataOptionsDto): JobDataLoaders {
  return {
    accountLoader: new DataLoader(async (ids) => {
      const repository = appDataSource.getRepository(AccountModel);
      const entities = await repository.find({ where: { id: In([...ids]) } });
      // ... manual mapping logic
    }),
  };
}
```

---

## Testing

### Manual Testing with GraphQL

1. **Test without relationships** - Baseline query:
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      jobNo
    }
  }
}
```
Expected: 1 query

2. **Test single relationship** - One FieldResolver:
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account {
        id
        name
      }
    }
  }
}
```
Expected: 2 queries (1 for jobs, 1 batched for accounts)

3. **Test multiple relationships** - Multiple FieldResolvers:
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account { id name }
      site { id name }
      contact { id firstName }
    }
  }
}
```
Expected: 4 queries (1 for jobs, 3 batched for relationships)

4. **Test nested relationships** - Verify eager loading:
```graphql
query {
  paginatedJobs(pageArg: { skip: 0, take: 10 }) {
    data {
      id
      account {
        id
        name
        status { name }
        primaryContact { firstName }
      }
    }
  }
}
```
Expected: 2 queries (1 for jobs, 1 batched for accounts with nested relations)

### Enable Query Logging

Add to environment.ts or set environment variable:

```bash
SHOW_SQL=true
```

Or enable in datasource config:

```typescript
// src/datasource/config/database.ts
export const appDataSource = new DataSource({
  // ...
  logging: true,  // Enable query logging
  logger: 'advanced-console',
});
```

### Expected vs Actual Queries

**Scenario**: Load 100 jobs with 5 relationships

| Approach | Queries | Calculation |
|----------|---------|-------------|
| No optimization | 501 | 1 + (100 × 5) |
| Eager loading (setSchemaRelations) | 1 | 1 (but huge join) |
| DataLoader | 6 | 1 + 5 |

**DataLoader is the sweet spot**: Multiple efficient queries vs one massive join.

### Unit Testing DataLoaders

```typescript
// src/test/utils/DataLoaderUtils.test.ts

import { createJobDataLoaders } from '../../utils/DataLoaderUtils';
import { appDataSource } from '../../datasource/config/database';
import { JobModel } from '../../datasource/models/JobModel';
import { AccountModel } from '../../datasource/models/AccountModel';

describe('JobDataLoaders', () => {
  let loaders: ReturnType<typeof createJobDataLoaders>;

  beforeAll(async () => {
    await appDataSource.initialize();
  });

  afterAll(async () => {
    await appDataSource.destroy();
  });

  beforeEach(() => {
    // Create fresh loaders for each test
    loaders = createJobDataLoaders();
  });

  it('should batch account loads', async () => {
    const accountIds = ['id1', 'id2', 'id3'];

    // Request multiple accounts
    const promises = accountIds.map(id => loaders.accountLoader.load(id));

    // All loads should complete
    const accounts = await Promise.all(promises);

    expect(accounts).toHaveLength(3);
    expect(accounts[0]?.id).toBe('id1');
  });

  it('should cache within same request', async () => {
    const accountId = 'test-id';

    // Load same account twice
    const account1 = await loaders.accountLoader.load(accountId);
    const account2 = await loaders.accountLoader.load(accountId);

    // Should return same instance (cached)
    expect(account1).toBe(account2);
  });

  it('should handle null foreign keys', async () => {
    const result = await loaders.accountLoader.load('non-existent-id');
    expect(result).toBeNull();
  });

  it('should load one-to-many relationships', async () => {
    const jobId = 'test-job-id';

    const jobDetails = await loaders.jobDetailsLoader.load(jobId);

    expect(Array.isArray(jobDetails)).toBe(true);
  });
});
```

---

## Troubleshooting

### Problem: DataLoader not batching queries

**Symptoms:**
- Still seeing N+1 queries in logs
- Each relationship loads separately

**Causes:**
1. FieldResolvers not implemented
2. Eager loading still active (setSchemaRelations)
3. DataLoader not used in FieldResolver

**Solution:**
```typescript
// ✅ Ensure FieldResolver uses DataLoader
@FieldResolver()
async account(@Root() job: JobModel & JobSchema, @Ctx() ctx: IGraphQLContext) {
  if (!job.accountId) return null;
  const loaders = this.getDataLoaders(ctx);
  return loaders.accountLoader.load(job.accountId);  // Must use .load()
}

// ❌ Don't query directly
@FieldResolver()
async account(@Root() job: JobModel & JobSchema, @Ctx() ctx: IGraphQLContext) {
  // This bypasses DataLoader!
  return this.accountService.findById(job.accountId);
}
```

### Problem: "Cannot read property 'load' of undefined"

**Symptoms:**
- Runtime error when accessing loader
- `ctx.dataLoaders.job` is undefined

**Causes:**
1. DataLoaders not initialized in context
2. Typo in context property name
3. Factory function not called

**Solution:**
```typescript
// ✅ Lazy initialization handles missing context
private getDataLoaders(ctx: IGraphQLContext) {
  if (!ctx.dataLoaders) {
    ctx.dataLoaders = {};  // Initialize if missing
  }
  if (!ctx.dataLoaders.job) {
    const dataOptions = this.toDataOptions(ctx);
    ctx.dataLoaders.job = createJobDataLoaders(dataOptions);  // Create if missing
  }
  return ctx.dataLoaders.job;
}
```

### Problem: Stale data across requests

**Symptoms:**
- Changes in database not reflected in queries
- Old data returned even after updates

**Causes:**
1. DataLoaders cached globally (not per-request)
2. DataLoaders reused across requests

**Solution:**
```typescript
// ✅ GOOD - Request-scoped creation
private getDataLoaders(ctx: IGraphQLContext) {
  // Creates fresh loaders per request
  if (!ctx.dataLoaders.job) {
    ctx.dataLoaders.job = createJobDataLoaders(dataOptions);
  }
  return ctx.dataLoaders.job;
}

// ❌ BAD - Global DataLoaders
const globalLoaders = createJobDataLoaders();  // DON'T DO THIS!

@FieldResolver()
async account(@Root() job: JobModel & JobSchema) {
  return globalLoaders.accountLoader.load(job.accountId);  // Stale cache!
}
```

### Problem: TypeScript errors with intersection types

**Symptoms:**
- "Property 'accountId' does not exist on type 'JobSchema'"
- Type errors in FieldResolver @Root parameter

**Causes:**
1. Only using Schema type, not Model type
2. Missing intersection operator

**Solution:**
```typescript
// ✅ GOOD - Intersection type
@FieldResolver()
async account(
  @Root() job: JobModel & JobSchema,  // Both types
  @Ctx() ctx: IGraphQLContext
) {
  if (!job.accountId) return null;  // accountId from JobModel
  // ...
}

// ❌ BAD - Only schema
@FieldResolver()
async account(
  @Root() job: JobSchema,  // Missing model fields!
  @Ctx() ctx: IGraphQLContext
) {
  if (!job.accountId) return null;  // TypeScript error!
  // ...
}
```

### Problem: Org isolation not working

**Symptoms:**
- Users seeing data from other organizations
- Security violation

**Causes:**
1. Not passing dataOptions to createDataLoaders
2. dataOptions.dataIsolation not set

**Solution:**
```typescript
// ✅ GOOD - Pass dataOptions with org isolation
private getDataLoaders(ctx: IGraphQLContext) {
  if (!ctx.dataLoaders.job) {
    const dataOptions = this.toDataOptions(ctx);  // Includes org isolation
    ctx.dataLoaders.job = createJobDataLoaders(dataOptions);
  }
  return ctx.dataLoaders.job;
}

// ❌ BAD - No org isolation
private getDataLoaders(ctx: IGraphQLContext) {
  if (!ctx.dataLoaders.job) {
    ctx.dataLoaders.job = createJobDataLoaders();  // Missing dataOptions!
  }
  return ctx.dataLoaders.job;
}
```

### Problem: Nested relations not loading

**Symptoms:**
- account.status is null even though data exists
- Nested fields require additional queries

**Causes:**
1. Nested relations not configured in DataLoader
2. FieldResolvers needed for nested entity

**Solution:**
```typescript
// ✅ GOOD - Configure nested relations in DataLoader
export function createJobDataLoaders(dataOptions?: DataOptionsDto): JobDataLoaders {
  const accountDataOptions: DataOptionsDto = {
    ...(dataOptions || {}),
    findManyOptions: {
      ...(dataOptions?.findManyOptions || {}),
      relations: ['status', 'primaryContact'],  // Eager load nested data
    },
  };

  return {
    accountLoader: createEntityLoader(AccountModel, accountDataOptions),
  };
}

// ❌ BAD - No nested relations
return {
  accountLoader: createEntityLoader(AccountModel, dataOptions),  // Missing nested relations
};
```

### Problem: ESLint "Unexpected any" errors

**Symptoms:**
- ESLint errors in DataLoaderUtils.ts
- "@typescript-eslint/no-explicit-any" violations

**Causes:**
1. Using `any` type for TypeORM options
2. Generic function without proper types

**Solution:**
```typescript
// ✅ GOOD - Use FindManyOptions<T>
const findOptions: FindManyOptions<T> = {
  where,
  ...(dataOptions?.findManyOptions || {}),
} as FindManyOptions<T>;

// ❌ BAD - Using any
const findOptions: any = {  // ESLint error!
  where,
  ...(dataOptions?.findManyOptions || {}),
};

// For legitimate generic types, use eslint-disable:
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function createGenericOneToManyDataLoader<T extends Record<string, any>>(
  // ...
) {
```

---

## Performance Monitoring

### Query Count Analysis

Before implementing DataLoader, analyze query counts:

```typescript
// Enable query logging
SHOW_SQL=true

// Run query and count logs
query {
  paginatedJobs(pageArg: { skip: 0, take: 100 }) {
    data {
      account { name }
      site { name }
    }
  }
}
```

**Expected improvement:**
- **Before**: 201 queries (1 + 100 + 100)
- **After**: 3 queries (1 + 1 + 1)
- **Improvement**: 98.5% reduction

### Response Time Comparison

Measure with Apollo Server tracing:

```typescript
// server.ts
const server = new ApolloServer<IGraphQLContext>({
  plugins: [
    ApolloServerPluginInlineTrace(),  // Enable tracing
  ],
});
```

**Typical improvements:**
- Small datasets (10 records): 50-100ms → 20-30ms
- Medium datasets (100 records): 500-1000ms → 50-100ms
- Large datasets (1000 records): 5-10s → 200-500ms

### Memory Usage

DataLoader adds minimal memory overhead:
- Per-request cache: ~1-10KB per loader
- Batch arrays: Cleared after event loop tick
- Total overhead: <100KB per request

---

## Advanced Patterns

### Composite Keys

For loaders that need multiple keys:

```typescript
// Create composite key loader
function createCompositeKeyLoader<T>() {
  return new DataLoader<{ orgId: string; entityId: string }, T | null>(
    async (keys) => {
      const orgIds = keys.map(k => k.orgId);
      const entityIds = keys.map(k => k.entityId);

      const entities = await repository.find({
        where: {
          orgId: In(orgIds),
          id: In(entityIds),
        },
      });

      // Map back to keys
      return keys.map(key =>
        entities.find(e => e.id === key.entityId && e.orgId === key.orgId) || null
      );
    },
    {
      cacheKeyFn: (key) => `${key.orgId}:${key.entityId}`,
    }
  );
}
```

### Custom Caching Strategies

Implement custom cache with different TTL:

```typescript
import LRU from 'lru-cache';

const cache = new LRU({
  max: 500,
  ttl: 1000 * 60 * 5, // 5 minutes
});

const loader = new DataLoader(
  async (keys) => { /* ... */ },
  {
    cacheMap: cache,
  }
);
```

### Priming Cache

Pre-populate DataLoader cache with known data:

```typescript
// After loading jobs, prime account cache
const jobs = await this.service.findAll();

jobs.forEach(job => {
  if (job.account) {
    // Prime the cache
    ctx.dataLoaders.job.accountLoader.prime(job.accountId, job.account);
  }
});
```

---

## Migration Checklist

Use this checklist when implementing DataLoader for a new resolver:

- [ ] Install dataloader package
- [ ] Create DataLoader interface in DataLoaderUtils.ts
- [ ] Implement factory function (createXDataLoaders)
- [ ] Add to IGraphQLContext in GraphqlUtils.ts
- [ ] Add FieldResolver and Root imports to resolver
- [ ] Implement getDataLoaders() helper in resolver
- [ ] Add FieldResolvers for each relationship
- [ ] Remove setSchemaRelations calls from queries
- [ ] Remove @Info() parameters if only used for setSchemaRelations
- [ ] Run ESLint and fix any errors
- [ ] Test with GraphQL queries
- [ ] Enable query logging and verify batching
- [ ] Check response times and query counts
- [ ] Document any custom configurations

---

## Additional Resources

### Official Documentation
- **DataLoader GitHub**: https://github.com/graphql/dataloader
- **DataLoader NPM**: https://www.npmjs.com/package/dataloader
- **GraphQL Best Practices**: https://graphql.org/learn/best-practices/

### Related Files in This Project
- `/src/utils/DataLoaderUtils.ts` - DataLoader utilities and factories
- `/src/utils/GraphqlUtils.ts` - GraphQL context interface
- `/src/resolver/JobResolver.ts` - Job resolver with DataLoader implementation
- `/src/resolver/QualityAuditResolver.ts` - QualityAudit resolver with DataLoader

### Internal Documentation
- `/docs/README.md` - Project overview
- `/CLAUDE.md` - Project instructions and patterns

---

## Summary

DataLoader is a powerful pattern for optimizing GraphQL queries by batching and caching database operations. Key takeaways:

1. **Solves N+1 Problem** - Reduces queries from O(n) to O(1) per relationship type
2. **Request-Scoped** - Creates fresh DataLoaders per request, avoiding stale data
3. **Type-Safe** - Full TypeScript support with generic types
4. **Lazy Initialization** - Only creates loaders when needed
5. **Org Isolation** - Respects organization-level data security
6. **Nested Relations** - Supports eager loading of frequently accessed nested data
7. **Minimal Changes** - Uses FieldResolvers without changing existing service layer

**Performance Impact:**
- 95%+ reduction in database queries for paginated lists with relationships
- 70-90% improvement in response times
- Minimal memory overhead (<100KB per request)

**When to Use:**
- ✅ Many-to-one relationships (job → account)
- ✅ One-to-many relationships (job → jobDetails)
- ✅ Frequently queried relationships
- ✅ Paginated lists with nested data

**When NOT to Use:**
- ❌ Single queries with no relationships
- ❌ Search/filter operations
- ❌ Aggregations or computed fields

Follow this guide to implement DataLoader consistently across all resolvers in the ABMS microservice.

---

**Last Updated:** January 2025
**Version:** 1.0
**Maintainer:** CTO Development Team
