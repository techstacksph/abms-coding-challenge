# Stock Control and Stock Control Item GraphQL API

This document provides a set of GraphQL queries and mutations that can be used in Apollo Playground to test the CRUD functionality for both `stockControl` and `stockControlItem`.

---

### Helper Queries

Use these queries to get the IDs required for creating and updating records.

**1. Get Users**

```graphql
query PaginatedUsers {
  abmspaginatedUsers(pageArg: { take: 10, skip: 0 }) {
    data {
      id
      firstName
      lastName
    }
  }
}
```

**2. Get Locations**

```graphql
query PaginatedLocations {
  abmspaginatedLocations(pageArg: { take: 10, skip: 0 }) {
    data {
      id
      name
    }
  }
}
```

**3. Get Workflow Statuses for Stock Control**

```graphql
query PaginatedWorkflowStatuses {
  abmspaginatedWorkflowStatuses(
    pageArg: { take: 10, skip: 0 }
    searchArg: [
      {
        fieldName: "workflowProcess.workflow.module.code"
        searchValue: "stockcontrol"
        comparator: EQUAL
      }
    ]
  ) {
    data {
      id
      name
    }
  }
}
```

**Notes:**

*   You will need to replace placeholder IDs like `"YOUR_STOCK_CONTROL_ID"`, `"YOUR_LOCATION_ID"`, `"YOUR_ITEM_ID"`, and `"YOUR_STOCK_CONTROL_ITEM_ID"` with actual IDs from your system.
*   The `transDate` should be in `YYYY-MM-DD` format.
*   The `transType` for `createStockControl` can be one of `MANUAL_ADD`, `MANUAL_DEDUCT`, `TRANSFER`, `STOCK_COUNT`, or `SPOT_CHECK`.

---

### Stock Control

**1. Create Stock Control**

```graphql
mutation CreateStockControl {
  abmscreateStockControl(
    input: {
      transDate: "2025-09-29"
      transType: MANUAL_ADD
      userId: "bf90d3e7-06b1-478a-907e-f927841fca24"
      locationId: "YOUR_LOCATION_ID"
      statusId: "6b140f70-c77a-4f02-9236-b9886b00166a"
      note: "Test stock control"
    }
  ) {
    id
    scNo
    transDate
    transType
    status {
      id
      name
    }
  }
}
```

**2. Read Stock Controls (Paginated)**

```graphql
query PaginatedStockControls {
  abmspaginatedStockControls(
    pageArg: { take: 10, skip: 0 }
    searchArg: []
  ) {
    data {
      id
      scNo
      transDate
      transType
      status {
        id
        name
      }
    }
    total
  }
}
```

**3. Update Stock Control**

```graphql
mutation UpdateStockControl {
  abmsupdateStockControl(
    id: "YOUR_STOCK_CONTROL_ID"
    input: {
      note: "Updated test stock control"
    }
  ) {
    id
    scNo
    note
  }
}
```

**4. Delete Stock Control**

```graphql
mutation DeleteStockControl {
  abmsdeleteStockControl(id: "YOUR_STOCK_CONTROL_ID")
}
```

---

### Stock Control Item

**1. Create Stock Control Item**

```graphql
mutation CreateStockControlItem {
  abmscreateStockControlItem(
    input: {
      stockControlId: "YOUR_STOCK_CONTROL_ID"
      itemId: "YOUR_ITEM_ID"
      quantity: 10
      onStock: 5
      balance: 15
    }
  ) {
    id
    item {
      id
      name
    }
    quantity
    balance
  }
}
```

**2. Read Stock Control Items (Paginated)**

This query finds all items for a specific stock control.

```graphql
query PaginatedStockControlItems {
  abmspaginatedStockControlItems(
    pageArg: { take: 10, skip: 0 }
    searchArg: [
      {
        fieldName: "stockControlId"
        searchValue: "YOUR_STOCK_CONTROL_ID"
        comparator: EQUAL
      }
    ]
  ) {
    data {
      id
      item {
        id
        name
      }
      quantity
      balance
    }
    total
  }
}
```

**3. Update Stock Control Item**

```graphql
mutation UpdateStockControlItem {
  abmsupdateStockControlItem(
    id: "YOUR_STOCK_CONTROL_ITEM_ID"
    input: {
      quantity: 15
      balance: 20
    }
  ) {
    id
    quantity
    balance
  }
}
```

**4. Delete Stock Control Item**

```graphql
mutation DeleteStockControlItem {
  abmsdeleteStockControlItem(id: "YOUR_STOCK_CONTROL_ITEM_ID")
}
```