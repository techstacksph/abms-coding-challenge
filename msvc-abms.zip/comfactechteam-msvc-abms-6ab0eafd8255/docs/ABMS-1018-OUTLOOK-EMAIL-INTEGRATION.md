# ABMS-1018: Communication Logs - Email Outlook Integration

**Ticket**: https://ctoltd.atlassian.net/browse/ABMS-1018
**Status**: ✅ Implemented
**Date**: January 2025
**Developer**: Claude Code

---

## Overview

This document describes the implementation of **Outlook email integration for Communication Logs** using the **Pulsar message queue architecture**. When a communication log record of type "Email" is created in the system, it automatically queues the email for sending through the `msvc-abms-communication-media` microservice, which handles Microsoft Outlook integration.

## Architecture

The implementation follows the existing message queue pattern used for SMS and other communications:

```
CommunicationLog Created (commType='Email')
         ↓
CommunicationLogSubscriber.afterInsert()
         ↓
triggerOutlookEmailSend()
         ↓
1. Get CompanySetting (Email credentials)
2. Get MicrosoftAccount (with MAIL permission, if using Outlook)
3. Build MailerOptionDto with credentials
4. Publish to Pulsar (PulsarTopics.COMMUNICATION_MEDIA)
         ↓
msvc-abms-communication-media consumes message
         ↓
Sends email via Microsoft Graph API or SMTP
         ↓
Updates CommunicationLog status via callback
```

## Implementation Details

### 1. CommunicationLogSubscriber Updates

**File**: `src/datasource/subscribers/CommunicationLogSubscriber.ts`

#### Modified `afterInsert()` Method
Added email detection logic:
```typescript
if (entity.commType === 'Email' && entity.subjectEmail && entity.bodyEmail && entity.toEmail) {
  await this.triggerOutlookEmailSend(entity);
}
```

#### New `triggerOutlookEmailSend()` Method

**Step 1: Get Company Settings**
- Retrieves `CompanySetting` for the organization
- Checks `emailSettings` field (MICROSOFT_OUTLOOK, SMTP, etc.)

**Step 2: Parse Email Recipients**
- Splits comma-separated email addresses:
  - `toEmail` → `toRecipients[]`
  - `ccEmail` → `ccRecipients[]`
  - `bccEmail` → `bccRecipients[]`

**Step 3: Prepare Mailer Credentials**

For **Microsoft Outlook** (`CompanySettingsEmailSettings.MICROSOFT_OUTLOOK`):
1. Find `MicrosoftAccount` with `MAIL` permission scope
2. If found, use OAuth tokens:
   - `accessToken` (current token)
   - `refreshToken` (for token refresh)
   - `clientId`, `clientSecret`, `tenantId` (from CompanySettings)
3. If not found, fall back to manual M365 credentials from CompanySettings:
   - `outlookTenantID`
   - `outlookID`
   - `outlookSecret`

For **SMTP**:
- Use `mailHost`, `mailPort`, `appPassword` from CompanySettings

**Step 4: Publish to Pulsar**
```typescript
await pulsarProducerClient.produce(PulsarTopics.COMMUNICATION_MEDIA, {
  action: PulsarDataAction.PROCESS,
  data: {
    recipients: toRecipients,
    ccRecipients,
    bccRecipients,
    subject: entity.subjectEmail,
    content: entity.bodyEmail,
    sender: companySetting.mailSender,
    replyTo: entity.fromEmail || companySetting.mailerAccount,
    mailerCredentialOption: { /* credentials */ },
    metadata: {
      communicationLogId: entity.id,
      orgId: entity.orgId,
    },
  },
  subAction: 'email',
});
```

**Step 5: Status Tracking**
- Status initially remains `null` (pending)
- `msvc-abms-communication-media` updates status via callback:
  - `'delivered'` on success
  - `'failed'` on error
- If queueing fails, status set to `'failed'` immediately

### 2. Required Database Fields

#### CommunicationLogModel
Already has all required fields:
- `commType` (varchar) - Must be 'Email'
- `toEmail` (text) - Recipient email addresses (comma-separated)
- `ccEmail` (text) - CC email addresses (comma-separated, optional)
- `bccEmail` (text) - BCC email addresses (comma-separated, optional)
- `subjectEmail` (varchar) - Email subject
- `bodyEmail` (text) - Email body (HTML supported)
- `fromEmail` (varchar) - From email address (optional)
- `status` (varchar) - 'delivered', 'failed', or null/undefined for pending

#### CompanySettingModel
Has both Outlook and SMTP credential fields:

**Microsoft Outlook Fields**:
- `emailSettings` (varchar) - Set to `MICROSOFT_OUTLOOK`
- `tenantId` (varchar) - Azure AD Tenant ID (preferred)
- `clientId` (varchar) - Azure AD Client ID (preferred)
- `clientSecret` (varchar) - Azure AD Client Secret (preferred)
- `outlookTenantID` (varchar) - Fallback Azure AD Tenant ID
- `outlookID` (varchar) - Fallback Azure AD Client ID
- `outlookSecret` (varchar) - Fallback Azure AD Client Secret
- `mailerAccount` (varchar) - Sender email address
- `mailSender` (varchar) - Sender display name
- `customDisplayName` (varchar) - Custom sender name (optional)

**SMTP Fields** (if not using Outlook):
- `emailSettings` (varchar) - SMTP type
- `mailHost` (varchar) - SMTP server hostname
- `mailPort` (varchar) - SMTP port (e.g., '587')
- `appPassword` (varchar) - SMTP password
- `mailerAccount` (varchar) - SMTP username
- `mailSender` (varchar) - Sender display name

#### MicrosoftAccountModel (Optional, for OAuth)
If using Microsoft account OAuth:
- `microsoftAccount` (varchar) - Microsoft account email
- `userId` (uuid) - Associated user
- `accessToken` (varchar) - Current access token
- `refreshToken` (varchar) - Refresh token
- `tokenExpirationDate` (date) - Token expiration timestamp
- `permissionScopes` (simple-array) - Must include `'MAIL'`
- `email` (varchar) - Account email

## Configuration Requirements

### 1. Azure AD App Registration (For Microsoft Outlook)

To use Outlook integration, you need an Azure AD app with Microsoft Graph API permissions:

1. **Register App** in Azure Portal:
   - Go to Azure Active Directory → App registrations → New registration
   - Name: "ABMS Email Integration"
   - Supported account types: "Accounts in this organizational directory only"
   - Redirect URI: Your callback URL

2. **API Permissions** (Microsoft Graph):
   - **Mail.Send** (Delegated) - Send mail as a user
   - **Mail.ReadWrite** (Delegated) - Read and write user mail
   - **User.Read** (Delegated) - Sign in and read user profile
   - Click "Grant admin consent"

3. **Certificates & Secrets**:
   - Create new client secret
   - Copy the value immediately (you won't see it again)

4. **Save Credentials**:
   - Tenant ID (from Overview page)
   - Client ID (Application ID from Overview page)
   - Client Secret (from step 3)

### 2. Company Settings Configuration

**Option A: With Microsoft Account OAuth** (Recommended):

```sql
UPDATE companysettings
SET
  "emailSettings" = 'MICROSOFT_OUTLOOK',
  "tenantId" = '<your-tenant-id>',
  "clientId" = '<your-client-id>',
  "clientSecret" = '<your-client-secret>',
  "mailerAccount" = 'sales@company.com',
  "mailSender" = 'Company Sales Team'
WHERE "orgId" = '<your-org-id>';
```

Then create a `MicrosoftAccount` with OAuth tokens (via OAuth flow).

**Option B: Manual M365 Credentials** (No MicrosoftAccount needed):

```sql
UPDATE companysettings
SET
  "emailSettings" = 'MICROSOFT_OUTLOOK',
  "outlookTenantID" = '<your-tenant-id>',
  "outlookID" = '<your-client-id>',
  "outlookSecret" = '<your-client-secret>',
  "mailerAccount" = 'sales@company.com',
  "mailSender" = 'Company Sales Team'
WHERE "orgId" = '<your-org-id>';
```

**Option C: SMTP** (Gmail, SendGrid, etc.):

```sql
UPDATE companysettings
SET
  "emailSettings" = 'SMTP',  -- or 'GMAIL', 'SENDGRID', etc.
  "mailHost" = 'smtp.gmail.com',
  "mailPort" = '587',
  "appPassword" = '<app-password>',
  "mailerAccount" = 'sales@company.com',
  "mailSender" = 'Company Sales Team'
WHERE "orgId" = '<your-org-id>';
```

### 3. Microsoft Account Setup (Optional, for OAuth)

For the recommended OAuth approach:

1. **Create Microsoft Account** record:
   - User authenticates via OAuth flow
   - System stores `accessToken`, `refreshToken`, `tokenExpirationDate`
   - **IMPORTANT**: Must have `permissionScopes` = `['MAIL']` or `['MAIL', ...]`

2. **Verify Permission Scope**:
   ```sql
   SELECT "id", "email", "permissionScopes"
   FROM microsoftaccounts
   WHERE "orgId" = '<your-org-id>'
   AND 'MAIL' = ANY("permissionScopes");
   ```

3. **Token Refresh**:
   - `msvc-abms-communication-media` handles token refresh automatically
   - Uses `refreshToken` when `accessToken` expires (~1 hour)

### 4. Communication Media Microservice

Ensure `msvc-abms-communication-media` is running:

```bash
# Check if running
docker ps | grep msvc-cto-communication-media

# Start if not running
cd /Users/ctouser/CTO/msvc-abms-communication-media
yarn docker:dev:full
```

The communication media service will be available at `http://localhost:8086`.

## Usage

### Creating Communication Log with Email

**GraphQL Mutation**:
```graphql
mutation {
  abmsCreateCommunicationLog(
    communicationLog: {
      commType: "Email"
      toEmail: "recipient@example.com"
      ccEmail: "cc@example.com,cc2@example.com"  # Optional, comma-separated
      bccEmail: "bcc@example.com"                # Optional
      subjectEmail: "Your Quote Request"
      bodyEmail: "<h1>Hello</h1><p>Your quote is ready.</p>"
      fromEmail: "sales@company.com"             # Optional, for Reply-To
      accountId: "uuid-here"                     # Optional, link to record
      # ... other fields
    }
  ) {
    id
    status  # Initially null (pending), updated to 'delivered' or 'failed'
    subjectEmail
    toEmail
  }
}
```

**Bulk Creation**:
```graphql
mutation {
  abmsCreateCommunicationLogs(
    communicationLogs: [
      {
        commType: "Email"
        toEmail: "customer1@example.com"
        subjectEmail: "Invoice Ready"
        bodyEmail: "<p>Your invoice is ready for review.</p>"
        invoiceId: "uuid-here"
      },
      {
        commType: "Email"
        toEmail: "customer2@example.com"
        subjectEmail: "Quote Approved"
        bodyEmail: "<p>Your quote has been approved.</p>"
        quoteId: "uuid-here"
      }
    ]
  ) {
    id
    status
    toEmail
  }
}
```

### Status Tracking

The `status` field reflects delivery status:
- **`null` or `undefined`**: Pending (queued in Pulsar)
- **`"delivered"`**: Successfully sent via communication media service
- **`"failed"`**: Failed to send (check logs for error)

Query status:
```graphql
query {
  abmsFindCommunicationLogById(id: "uuid-here") {
    id
    commType
    status
    toEmail
    subjectEmail
    createdAt
    updatedAt
  }
}
```

## Error Handling

### Common Errors

1. **Missing Company Settings**:
   ```
   company_setting_not_found
   ```
   - **Solution**: Create CompanySettings record for the organization

2. **No Microsoft Credentials** (when using Outlook):
   ```
   no_microsoft_credentials_found
   ```
   - **Solution**: Configure `tenantId`, `clientId`, `clientSecret` OR `outlookTenantID`, `outlookID`, `outlookSecret` in CompanySettings
   - **Alternative**: Create MicrosoftAccount with OAuth tokens

3. **Pulsar Queue Error**:
   ```
   outlook_email_queue_error
   ```
   - **Solution**: Ensure Pulsar is running and accessible
   - Check `PULSAR_SERVICE_URL` environment variable
   - Verify network connectivity to Pulsar broker

4. **Communication Media Service Down**:
   - Emails remain in Pulsar queue
   - Will be processed when service restarts
   - **Solution**: Start `msvc-abms-communication-media`

### Logging

All email operations are logged with context:

**Queued Successfully**:
```json
{
  "level": "info",
  "message": "email_queued_for_sending_via_pulsar",
  "communicationLogId": "uuid",
  "toEmail": "recipient@example.com",
  "subject": "Quote Request",
  "topic": "COMMUNICATION_MEDIA"
}
```

**Queue Failure**:
```json
{
  "level": "error",
  "message": "outlook_email_queue_error",
  "communicationLogId": "uuid",
  "toEmail": "recipient@example.com",
  "subject": "Quote Request",
  "error": { ... }
}
```

**Check communication-media service logs**:
```bash
# Docker logs
docker logs -f msvc-cto-communication-media

# Or if running locally
cd /Users/ctouser/CTO/msvc-abms-communication-media
yarn dev
```

## Performance Considerations

### Timing Requirements (from ABMS-1018)

✅ **Message delivery triggered within 2 seconds**:
- Email queueing happens asynchronously in `afterInsert` hook
- Pulsar publish is fast (<100ms typically)
- No blocking operations before trigger

✅ **Status update within 30 seconds**:
- Communication media service processes messages quickly
- Status callback updates CommunicationLog
- Timeout configurable in communication media service

### Scalability

**Message Queue Benefits**:
- **Decoupled**: Main service doesn't wait for email sending
- **Resilient**: Messages persist in Pulsar if consumer is down
- **Scalable**: Can add multiple communication media workers
- **Reliable**: Pulsar guarantees message delivery

**Token Caching** (handled by communication media service):
- Access tokens valid for ~1 hour
- Automatic refresh reduces API calls
- Shared token cache across workers (if using Redis)

**Rate Limiting**:
- Microsoft Graph API limits:
  - **Mail.Send**: ~1500 requests/10 min per user
- Pulsar queue naturally smooths traffic spikes
- Consider implementing rate limiting in communication media service

**Concurrent Sends**:
- Each communication log processes independently
- Pulsar handles concurrent message consumption
- Database handles concurrency via transactions

## Testing

### Manual Testing

1. **Setup**:
   ```bash
   # Start infrastructure
   cd /Users/ctouser/CTO/msvc-abms
   yarn docker:infrastructure

   # Start communication media service
   cd /Users/ctouser/CTO/msvc-abms-communication-media
   yarn docker:dev:full

   # Start main ABMS service
   cd /Users/ctouser/CTO/msvc-abms
   yarn dev
   ```

2. **Configure Credentials**:
   - Update CompanySettings with Outlook or SMTP credentials
   - Create MicrosoftAccount with MAIL permission (if using OAuth)

3. **Test Cases**:
   ```bash
   # Test 1: Simple email
   - commType: Email
   - toEmail: test@example.com
   - subjectEmail: Test Email
   - bodyEmail: <p>Test message</p>
   - Expected: Queued to Pulsar, status updated to 'delivered'

   # Test 2: Email with CC/BCC
   - toEmail: test@example.com
   - ccEmail: cc1@example.com,cc2@example.com
   - bccEmail: bcc@example.com
   - Expected: All recipients receive email

   # Test 3: HTML body
   - bodyEmail: <h1>Title</h1><p>Paragraph</p><img src="...">
   - Expected: HTML rendered correctly in recipient inbox

   # Test 4: Invalid email
   - toEmail: invalid-email
   - Expected: Queued successfully, status updated to 'failed'

   # Test 5: No credentials
   - Remove outlookTenantID from CompanySettings
   - Expected: status = 'failed', warning logged

   # Test 6: Multiple recipients
   - toEmail: user1@example.com,user2@example.com,user3@example.com
   - Expected: All recipients receive email

   # Test 7: Communication media service down
   - Stop msvc-abms-communication-media
   - Create communication log
   - Expected: Queued successfully, processed when service restarts
   ```

4. **Verification**:
   - Check recipient inbox
   - Verify email content matches
   - Confirm CC/BCC recipients received copies
   - Check CommunicationLog status field
   - Monitor Pulsar queues: `http://localhost:8080` (Pulsar Admin)

### Monitoring Pulsar

Check message queue status:

```bash
# Access Pulsar Admin UI
open http://localhost:8080

# Or use Pulsar CLI
docker exec -it pulsar bin/pulsar-admin topics stats persistent://public/default/COMMUNICATION_MEDIA
```

## Monitoring & Troubleshooting

### Dashboard Queries

**Email delivery success rate** (last 24 hours):
```sql
SELECT
  COUNT(*) FILTER (WHERE status = 'delivered') as delivered,
  COUNT(*) FILTER (WHERE status = 'failed') as failed,
  COUNT(*) FILTER (WHERE status IS NULL) as pending,
  ROUND(
    COUNT(*) FILTER (WHERE status = 'delivered')::numeric /
    NULLIF(COUNT(*), 0) * 100,
    2
  ) as success_rate_percent
FROM communication_logs
WHERE "commType" = 'Email'
  AND "createdAt" >= NOW() - INTERVAL '24 hours'
  AND "deletedAt" IS NULL;
```

**Recent failures** (last hour):
```sql
SELECT
  id,
  "toEmail",
  "subjectEmail",
  "createdAt",
  "updatedAt",
  status
FROM communication_logs
WHERE "commType" = 'Email'
  AND status = 'failed'
  AND "createdAt" >= NOW() - INTERVAL '1 hour'
  AND "deletedAt" IS NULL
ORDER BY "createdAt" DESC
LIMIT 20;
```

**Pending emails** (stuck in queue):
```sql
SELECT
  id,
  "toEmail",
  "subjectEmail",
  "createdAt",
  EXTRACT(EPOCH FROM (NOW() - "createdAt")) as seconds_pending
FROM communication_logs
WHERE "commType" = 'Email'
  AND status IS NULL
  AND "createdAt" < NOW() - INTERVAL '5 minutes'
  AND "deletedAt" IS NULL
ORDER BY "createdAt" ASC;
```

### Troubleshooting Steps

1. **Email not sending**:
   - ✅ Check CompanySettings has email credentials
   - ✅ Verify MicrosoftAccount exists with MAIL permission (if using OAuth)
   - ✅ Ensure `msvc-abms-communication-media` is running
   - ✅ Check Pulsar is running and accessible
   - ✅ Review communication media service logs

2. **Status stuck as `null`**:
   - Check communication media service is consuming messages
   - Verify Pulsar topic exists and has subscribers
   - Check for errors in communication media service logs
   - Restart communication media service if needed

3. **Pulsar connection issues**:
   - Verify `PULSAR_SERVICE_URL` environment variable
   - Check Pulsar is running: `docker ps | grep pulsar`
   - Test Pulsar connectivity from main service
   - Check network configuration (local_bridge network)

4. **Invalid recipients**:
   - Validate email format before creating CommunicationLog
   - Communication media service validates on consumption
   - Check communication media logs for validation errors

## Security Considerations

### Token Storage
- **Access tokens** stored in database (short-lived, ~1 hour)
- **Refresh tokens** stored in database (long-lived, use cautiously)
- **Client secrets** in CompanySettings (encrypted at rest recommended)

### Message Queue Security
- Pulsar messages may contain sensitive data (email content)
- Consider enabling Pulsar TLS encryption
- Restrict Pulsar access to authorized services only

### Permissions
- Uses **delegated permissions** (user context) if using OAuth
- Respects **org-level data isolation**
- GraphQL resolvers use `@Auth()` decorator

### Email Content
- **No sanitization** of email body (assumes trusted input)
- **HTML injection risk** if user input not validated
- **Recommendation**: Sanitize `bodyEmail` before storage

## Architecture Benefits

### Why Pulsar Queue Pattern?

1. **Decoupling**: Main service doesn't wait for email sending
2. **Resilience**: Messages persist if consumer is down
3. **Scalability**: Easy to add more workers
4. **Reliability**: Guaranteed message delivery
5. **Consistency**: Matches existing SMS pattern
6. **Separation of Concerns**: Email logic in dedicated service

### Service Responsibilities

**msvc-abms** (This Service):
- Detect email communication logs
- Prepare email data and credentials
- Publish to Pulsar queue
- Track initial queueing status

**msvc-abms-communication-media**:
- Consume messages from Pulsar
- Handle Microsoft Graph API calls
- Manage token refresh
- Update communication log status
- Handle retries and errors

## Future Enhancements

### Short-term
1. **Email attachments** - Support file attachments in communication logs
2. **Email templates** - Reusable email templates with variables
3. **Email scheduling** - Schedule emails for future delivery
4. **Retry logic** - Automatic retry configuration in communication media service

### Long-term
1. **Read receipts** - Track when emails are opened
2. **Reply handling** - Process email replies
3. **Email threads** - Link related emails together
4. **Analytics dashboard** - Email metrics and insights
5. **A/B testing** - Test different email content
6. **Email signatures** - Automatic signature injection

## Related Tickets

- **ABMS-1007**: Communication Logs (Parent Epic)
- **ABMS-3723**: Communication Logs - SMS MessageMedia integration (Sister ticket, uses same Pulsar pattern)
- **ABMS-2893**: Quote - Send Quote (Blocked by this)
- **ABMS-3591**: Franchisee notification - Responses tab (Blocked by this)

## References

- **Microsoft Graph Mail API**: https://learn.microsoft.com/en-us/graph/api/user-sendmail
- **OAuth 2.0 Flow**: https://learn.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow
- **Apache Pulsar**: https://pulsar.apache.org/docs/
- **msvc-abms-communication-media**: `/Users/ctouser/CTO/msvc-abms-communication-media/README.md`

---

**Implementation Status**: ✅ Complete
**Architecture**: Pulsar Message Queue (Decoupled)
**Tested**: ⏳ Pending
**Deployed**: ⏳ Pending
**Documentation**: ✅ Complete

