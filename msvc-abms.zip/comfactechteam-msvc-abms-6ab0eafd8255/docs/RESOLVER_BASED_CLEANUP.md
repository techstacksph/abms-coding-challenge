# Resolver-Based Orphaned Reference Cleanup

## Overview

This system provides automated cleanup of orphaned foreign key references to soft-deleted records using TypeORM metadata introspection.

## Background

With the deletion prevention system in place, we now have a safe way to clean up existing orphaned references where:
1. A parent record was soft-deleted (before prevention was implemented)
2. Child records still reference the soft-deleted parent
3. These references should be set to NULL for data consistency

## Commands

There are only two commands you need to know:

### 1. Scan Mode (Dry Run)
```bash
yarn cleanup:resolver-scan
```
- **Purpose**: Identifies all orphaned references across the database
- **Safety**: Read-only operation, no changes made
- **Output**: Automatically generates timestamped log file in `logs/` directory
- **Reports**: Shows exactly what would be cleaned up

### 2. Fix Mode (Live Cleanup)
```bash
yarn cleanup:resolver-fix
```
- **Purpose**: Actually cleans up the orphaned references
- **Safety**: Requires user confirmation before making changes
- **Output**: Automatically generates timestamped log file in `logs/` directory
- **Action**: Sets orphaned foreign keys to NULL

## How It Works

### 1. Entity Discovery
- Scans all TypeORM entity metadata
- Identifies entities with soft delete capability (`deletedAt` column)
- Maps relationships between entities

### 2. Orphan Detection
- For each soft-delete enabled entity, finds records where `deletedAt IS NOT NULL`
- Searches all other tables for foreign keys pointing to these soft-deleted records
- Identifies "orphaned references" where child records reference deleted parents

### 3. Reference Cleanup
- In **scan mode**: Reports what would be cleaned
- In **fix mode**: Updates orphaned foreign keys to `NULL`
- Maintains audit trail of all operations

### 4. Comprehensive Logging
- Every operation is logged with timestamps
- Detailed reports saved to `logs/cleanup-resolver-{mode}-{timestamp}.log`
- Professional formatting for analysis and compliance

## Example Output

### Console Output
```
🧹 Starting orphaned reference cleanup by resolver...
📄 Output will be saved to: logs/cleanup-resolver-scan-2024-01-15T10-30-00.log

📋 Processing AccountModel (accounts)
🗑️  Found 12 soft-deleted records in accounts
🔗 Found 3 tables that reference accounts:
   - sites.accountId → accounts.id
   - contacts.accountId → accounts.id
   - notes.accountId → accounts.id

🔍 Checking sites.accountId...
   Found 5 orphaned references

🔍 Checking contacts.accountId...
   Found 3 orphaned references

🔍 Checking notes.accountId...
   Found 0 orphaned references

📊 CLEANUP REPORT
==================================================
🏷️  AccountModel (accounts)
   Soft-deleted records: 12
   Orphaned references found: 8
   🔍 DRY RUN - No changes made
```

### Log File Content
```
================================================================================
ORPHANED REFERENCE CLEANUP REPORT
Generated: 2024-01-15T10:30:00.000Z
Mode: DRY RUN
================================================================================

2024-01-15T10:30:00.123Z - 🧹 Starting orphaned reference cleanup by resolver...
2024-01-15T10:30:01.200Z - 📋 Processing AccountModel (accounts)
2024-01-15T10:30:01.250Z - 🔍 Found 5 orphaned references in sites.accountId
2024-01-15T10:30:01.251Z - 🔍 Found 3 orphaned references in contacts.accountId

2024-01-15T10:30:02.100Z - 📊 CLEANUP REPORT
2024-01-15T10:30:02.101Z - Total entities processed: 15
2024-01-15T10:30:02.102Z - Total orphaned references: 47
2024-01-15T10:30:02.103Z - Mode: DRY RUN - No changes made

================================================================================
Report completed: 2024-01-15T10:30:02.500Z
================================================================================
```

## Custom Output File

If you want to specify a custom log file location:

```bash
# Custom output file for scan
yarn cleanup:resolver-scan --output my-scan-report.log

# Custom output file for fix
yarn cleanup:resolver-fix --output my-cleanup-report.log
```

## Safety Features

- **Dry Run Default**: Scan mode is completely safe and read-only
- **User Confirmation**: Fix mode requires explicit confirmation
- **Transaction Safety**: All updates are wrapped in transactions
- **Comprehensive Logging**: Every operation is logged for audit trails
- **Error Handling**: Graceful handling of database errors with rollback

## Best Practices

1. **Always scan first**: Run `cleanup:resolver-scan` to see what will be affected
2. **Review logs**: Check the generated log files before running fix mode
3. **Backup database**: Consider taking a database backup before large cleanups
4. **Run during maintenance**: Schedule cleanup operations during low-traffic periods
5. **Monitor results**: Review the fix mode logs to ensure expected results

## Troubleshooting

### No Orphaned References Found
- This is normal if deletion prevention has been working correctly
- Indicates good data integrity

### Large Number of Orphaned References
- Review the scan log to understand which entities are affected
- Consider running cleanup in smaller batches if needed
- Verify that the references should indeed be nullified

### Database Errors
- All errors are logged with full details
- Operations are transactional and will rollback on failure
- Check database connectivity and permissions

## Integration

This cleanup system works alongside:
- **Deletion Prevention**: Prevents new orphaned references
- **Soft Delete System**: Maintains referential integrity
- **Audit Trail**: Provides complete operation history
- **Data Integrity Checks**: Ensures consistent database state