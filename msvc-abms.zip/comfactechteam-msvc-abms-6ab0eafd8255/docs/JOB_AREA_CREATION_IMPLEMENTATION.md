# Job Area Creation Implementation

**Implementation Date**: July 2025

## Overview

This implementation adds functionality to automatically create job areas per job schedule based on the Job's specifications when a user allocates the job. The feature applies to both one-off and recurring job allocations.

## Field Mapping

- **Job**: Current job being allocated
- **Job Schedule**: Current job schedule being created
- **Area**: Area from the job specifications that is related to the job schedule

## Implementation Details

### 1. Data Model Relationships

The implementation leverages existing relationships:
- `JobModel` has many `JobDetailsModel`
- `JobDetailsModel` has an `area` field and belongs to `DealOrderDetailModel`
- `DealOrderDetailModel` also has an `area` field
- `JobAreaModel` links `JobModel`, `JobScheduleModel`, and the `area` field
- `JobDetailsModel` has many `JobSpecificationModel` with service provider assignments
- `JobSpecificationModel` can have `serviceProviderAssignments` or fall back to `dealSpecification.days`

### 2. Key Changes Made

#### JobService Updates

1. **Added JobAreaService dependency** to the JobService constructor
2. **Added JobAreaModel import** for type safety
3. **Modified method signatures** to include jobAreas parameter:
   - `createScheduleForDate`
   - `generateSchedulesForFrequency`
   - `generateSchedulesForProvider`
   - `generateSchedulesForAllProviders`
   - `saveJobSchedulesToDatabase`

#### New Methods Added

1. **`extractAreasFromSpecifications`**: Extracts unique areas from job specifications
2. **`createJobAreasForSchedule`**: Creates job areas for a specific job schedule based on specifications

#### Updated Methods

1. **`createScheduleForDate`**: Now creates job areas for each schedule
2. **`saveJobSchedulesToDatabase`**: Now saves job areas to the database
3. **`deleteExistingJobSchedules`**: Updated to handle job area deletion (commented out but ready for use)
4. **`filterSpecsForCurrentDate`**: Enhanced to handle both `serviceProviderAssignments` and `dealSpecification.days`
5. **`initializeDateVariables`**: Fixed timezone handling using UTC methods

### 3. Workflow

1. When a job is allocated, the system extracts job specifications
2. For each job schedule created, the system:
   - Extracts areas from the specifications for that schedule
   - Creates a `JobAreaModel` record for each unique area
   - Links the job area to the job schedule and job
3. All job areas are saved to the database along with job schedules

### 4. Database Creation Flow

The actual database creation follows this specific flow:

#### Step 1: Job Area Object Creation (In Memory)
```typescript
// In createJobAreasForSchedule method (Lines 347-370)
private createJobAreasForSchedule(
  jobScheduleId: string,
  specsForThisDate: Record<string, unknown>[],
  jobId: string,
  dataOptions: DataOptionsDto,
  createdBy: string,
  jobAreas: Partial<JobAreaModel>[]  // ← Array populated with job area objects
): void {
  const areas = this.extractAreasFromSpecifications(specsForThisDate);
  
  for (const area of areas) {
    jobAreas.push({  // ← Job area objects created here
      jobId: jobId,
      jobScheduleId: jobScheduleId,
      area: area,
      completed: false,
      createdBy: createdBy,
      orgId: dataOptions.dataIsolation.orgId,
    });
  }
}
```

#### Step 2: Database Save Operation
```typescript
// In saveJobSchedulesToDatabase method (Lines 1303-1305)
private async saveJobSchedulesToDatabase(
  jobSchedules: Partial<JobScheduleModel>[],
  jobScheduleAssignees: Partial<JobScheduleAssigneeModel>[],
  jobAreas: Partial<JobAreaModel>[],  // ← Job areas array passed here
  shouldGenerateSchedules: boolean,
  job: JobModel
): Promise<void> {
  if (jobSchedules.length > 0 && shouldGenerateSchedules) {
    try {
      const jobScheduleRepository = appDataSource.getRepository(JobScheduleModel);
      const jobScheduleAssigneeRepository = appDataSource.getRepository(JobScheduleAssigneeModel);
      const jobAreaRepository = appDataSource.getRepository(JobAreaModel);  // ← Repository created

      await jobScheduleRepository.save(jobSchedules);
      await jobScheduleAssigneeRepository.save(jobScheduleAssignees);
      await jobAreaRepository.save(jobAreas);  // ← ACTUAL DATABASE INSERT HAPPENS HERE!

      logger.info('Successfully created job schedules', {
        assigneeCount: jobScheduleAssignees.length,
        jobId: job.id,
        scheduleCount: jobSchedules.length,
        areaCount: jobAreas.length,  // ← Logs how many areas were created
      });
    } catch (error) {
      // Error handling...
    }
  }
}
```

#### Complete Method Call Chain
1. **`createJobAreasForSchedule`** → Creates job area objects in memory
2. **`createScheduleForDate`** → Calls `createJobAreasForSchedule` for each schedule
3. **`generateSchedulesForFrequency`** → Calls `createScheduleForDate` for each date
4. **`generateSchedulesForProvider`** → Calls `generateSchedulesForFrequency`
5. **`generateSchedulesForAllProviders`** → Calls `generateSchedulesForProvider`
6. **`createJobSchedules`** → Calls `generateSchedulesForAllProviders`
7. **`saveJobSchedulesToDatabase`** → **ACTUALLY SAVES TO DATABASE** using `jobAreaRepository.save(jobAreas)`

**Key Point**: The actual database INSERT happens at **Line 1305** with `await jobAreaRepository.save(jobAreas);`

### 5. Area Extraction Logic

The system extracts areas from:
- `JobDetailsModel.area` field
- Areas are deduplicated per job schedule
- Each unique area creates a separate `JobAreaModel` record

### 6. Day Assignment Logic

The system supports two methods for day assignments:

#### Primary Method: Service Provider Assignments
- Uses `serviceProviderAssignments` table with day keys like `'Tu,Th'` (Tuesday, Thursday)
- Primary method for production scenarios
- Direct service provider to specification mapping

#### Fallback Method: Deal Specification Days
- Uses `dealSpecification.days` with full day names like `'Monday,Wednesday,Friday'`
- Fallback when `serviceProviderAssignments` is empty
- Converts day names to day keys for matching

### 7. Database Operations

- Job areas are created with the following fields:
  - `jobId`: Links to the job
  - `jobScheduleId`: Links to the job schedule
  - `area`: The area name from specifications
  - `completed`: Set to false by default
  - `createdBy`: User who allocated the job
  - `orgId`: Organization ID for data isolation

### 8. Error Handling

- Job area creation is wrapped in the same transaction as job schedule creation
- If job schedule creation fails, job areas are also rolled back
- Comprehensive logging for debugging and monitoring
- Proper timezone handling to prevent date conversion issues

## Testing

### Comprehensive Test Suite

A complete test suite has been implemented in `src/test/services/JobAreaCreation.test.ts` with **5 test cases**:

1. **`should create job areas when job schedules are allocated`**
   - Tests basic functionality with `dealSpecification.days`
   - Verifies job schedules and areas are created correctly
   - Validates area information and metadata

2. **`should handle multiple areas per job schedule`**
   - Tests multiple job details with different areas (Kitchen, Bathroom)
   - Verifies both areas are created and linked correctly
   - Tests service provider linking through junction table

3. **`should handle one-off job allocations`**
   - Tests one-off job type scenarios
   - Verifies job areas are created for single-day jobs
   - Ensures proper date handling for one-off jobs

4. **`should create job areas with correct metadata`**
   - Tests metadata validation (createdBy, orgId, completed status)
   - Verifies proper data isolation
   - Ensures audit trail is maintained

5. **`should handle serviceProviderAssignments with specific day assignments`**
   - Tests the primary data structure with `serviceProviderAssignments`
   - Uses day keys like `'Tu,Th'` (Tuesday, Thursday)
   - Verifies both primary and fallback area creation
   - Tests real-world production scenarios

### Test Data Setup

The test suite includes comprehensive test data creation:
- All required models with proper relationships
- Service providers linked through junction tables
- Job specifications with both assignment methods
- Proper date handling with UTC format
- Complete entity hierarchy (User, Account, Site, Contact, Deal, etc.)

### Key Testing Fixes Implemented

1. **Timezone Handling**: Fixed date conversion issues by using explicit UTC format
2. **Table Names**: Corrected `serviceproviderassignments` table name (no underscores)
3. **Required Fields**: Added all required fields for test data creation
4. **Relationships**: Properly linked service providers through junction tables
5. **Day Matching**: Enhanced `filterSpecsForCurrentDate` to handle both assignment methods

## Usage

The feature is automatically applied when:
1. A user calls the `allocateJob` mutation
2. The system generates job schedules (both manual and automatic via `generateNextPeriodSchedules`)
3. Both one-off and recurring job allocations are supported
4. Both `serviceProviderAssignments` and `dealSpecification.days` are supported

## Benefits

1. **Automatic Area Tracking**: Areas are automatically created based on job specifications
2. **Consistency**: Ensures all job schedules have corresponding area records
3. **Flexibility**: Supports multiple areas per job schedule
4. **Data Integrity**: Maintains referential integrity between jobs, schedules, and areas
5. **Audit Trail**: Tracks who created the job areas and when
6. **Dual Assignment Support**: Works with both primary and fallback day assignment methods
7. **Timezone Safety**: Proper UTC handling prevents date conversion issues
8. **Comprehensive Testing**: Full test coverage for all scenarios

## Technical Implementation Notes

### Date Handling
- All dates use explicit UTC format (`2025-01-01T00:00:00.000Z`) to prevent timezone issues
- `initializeDateVariables` uses UTC methods for consistent date normalization
- Proper handling of both local and UTC date conversions

### Service Provider Linking
- Service providers are linked through the `job_service_provider` junction table
- Raw SQL inserts are used for junction table operations
- Both `serviceProviderAssignments` and `jobDetail.serviceProvider` relationships are supported

### Day Matching Logic
- Supports both day keys (`'Tu,Th'`) and full day names (`'Monday,Wednesday,Friday'`)
- Automatic conversion between day formats
- Fallback logic ensures backward compatibility

## Future Enhancements

1. **Area Completion Tracking**: The `completed` field can be used to track area completion status
2. **Area Notes**: The `notes` field can be used for additional area-specific information
3. **Area Validation**: Could add validation to ensure areas exist in the system
4. **Bulk Operations**: Could add bulk area completion functionality
5. **Performance Optimization**: Could add caching for frequently accessed area data
6. **Advanced Scheduling**: Could add support for more complex scheduling patterns 