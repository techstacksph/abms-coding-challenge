# ABMS-1018: Test Plan - Email Outlook Integration

**Ticket**: https://ctoltd.atlassian.net/browse/ABMS-1018
**Implementation Doc**: [ABMS-1018-OUTLOOK-EMAIL-INTEGRATION.md](./ABMS-1018-OUTLOOK-EMAIL-INTEGRATION.md)
**Status**: Ready for Testing
**Date**: January 2025

---

## Requirements Coverage Analysis

### ✅ Fully Implemented

| Requirement | Implementation | Location |
|------------|---------------|----------|
| Email via Outlook Integration | Automatic trigger on email communication log creation | `CommunicationLogSubscriber.ts:72-86` |
| OAuth Token Support | MicrosoftAccount lookup with MAIL permission | `CommunicationLogSubscriber.ts:292-328` |
| Manual M365 Credentials Fallback | CompanySettings outlookTenantID/outlookID/outlookSecret | `CommunicationLogSubscriber.ts:331-356` |
| SMTP Fallback | Generic SMTP support | `CommunicationLogSubscriber.ts:358-366` |
| Metadata Logging | recipient, timestamp, subject, body, status | `CommunicationLogModel` fields |
| CC/BCC Recipients | Comma-separated parsing | `CommunicationLogSubscriber.ts:272-278` |
| Status Tracking | null → 'delivered' / 'failed' | `CommunicationLogModel.status` |
| 2-Second Trigger | Asynchronous Pulsar queue | `CommunicationLogSubscriber.ts:372-391` |
| Error Handling | Try-catch with status='failed' | `CommunicationLogSubscriber.ts:402-412` |

### ⚠️ Requires Testing

| Requirement | Implementation Status | Risk Level |
|------------|---------------------|-----------|
| 30-Second Status Update | Depends on communication-media service | Medium |
| Service Downtime Handling | Pulsar queue persistence | Medium |
| Multiple Recipients | Comma-separated parsing | Low |
| Invalid Email Format | Validation in communication-media | Low |
| Rate Limiting | Not implemented (future) | Low |

### 🔴 Out of Scope (Frontend/Future)

- Real-time UI feedback ("Sending...", "Sent", "Failed")
- Retry UI button
- SMS integration (already done in ABMS-3723)

---

## Test Environment Setup

### Prerequisites

1. **Infrastructure Running**:
   ```bash
   cd /Users/ctouser/CTO/msvc-abms
   yarn docker:infrastructure  # Postgres, Redis, Pulsar
   ```

2. **Communication Media Service Running**:
   ```bash
   cd /Users/ctouser/CTO/msvc-abms-communication-media
   yarn docker:dev:full
   # OR
   yarn dev
   ```

3. **Main Service Running**:
   ```bash
   cd /Users/ctouser/CTO/msvc-abms
   yarn dev
   ```

4. **GraphQL Playground**:
   - Open http://localhost:8083/graphql

---

## Test Cases

### Test Case 1: Send Email via OAuth MicrosoftAccount

**Priority**: 🔴 Critical
**Scenario**: Acceptance Criteria 1 - Sending an Email via Outlook Integration

**Prerequisites**:
- MicrosoftAccount exists with MAIL permission
- CompanySettings configured with clientId/clientSecret/tenantId
- Access token is valid

**Setup**:
```sql
-- Verify MicrosoftAccount exists
SELECT id, email, "permissionScopes", "accessToken", "refreshToken", "tokenExpirationDate"
FROM microsoftaccounts
WHERE "orgId" = '<your-org-id>'
  AND 'MAIL' = ANY("permissionScopes")
  AND "deletedAt" IS NULL;

-- Verify CompanySettings
SELECT "emailSettings", "clientId", "tenantId", "mailerAccount"
FROM companysettings
WHERE "orgId" = '<your-org-id>'
  AND "emailSettings" = 'MICROSOFT_OUTLOOK'
  AND "deletedAt" IS NULL;
```

**Test Steps**:
1. Create communication log via GraphQL:
   ```graphql
   mutation {
     abmsCreateCommunicationLog(
       communicationLog: {
         commType: "Email"
         toEmail: "test-recipient@example.com"
         subjectEmail: "Test Email from ABMS-1018"
         bodyEmail: "<h1>Test Email</h1><p>This is a test email sent via Outlook integration.</p>"
         accountId: "<account-uuid>"  # Optional
       }
     ) {
       id
       commType
       toEmail
       subjectEmail
       status
       createdAt
     }
   }
   ```

2. Check backend logs immediately:
   ```bash
   # Look for:
   # - "email_communication_log_detected"
   # - "Using Microsoft account for email"
   # - "email_queued_for_sending_via_pulsar"
   ```

3. Check communication-media logs:
   ```bash
   docker logs -f msvc-cto-communication-media | grep -E "(email|token|graph)"
   ```

4. Wait 30 seconds and query status:
   ```graphql
   query {
     abmsFindCommunicationLogById(id: "<communication-log-id>") {
       id
       status
       toEmail
       subjectEmail
       createdAt
       updatedAt
     }
   }
   ```

5. Check recipient inbox for email

**Expected Results**:
- ✅ Log shows "email_queued_for_sending_via_pulsar" within 2 seconds
- ✅ Status updates to `"delivered"` within 30 seconds
- ✅ Email appears in recipient inbox
- ✅ Email sender matches MicrosoftAccount email
- ✅ Subject and body match input

**Failure Modes**:
- If status stays `null` after 30s → communication-media service issue
- If status = `"failed"` → check communication-media logs for error
- If email not received → check spam folder, verify recipient email

---

### Test Case 2: Send Email via Manual M365 Credentials

**Priority**: 🟡 High
**Scenario**: Fallback when no MicrosoftAccount exists

**Prerequisites**:
- NO MicrosoftAccount with MAIL permission
- CompanySettings configured with outlookTenantID/outlookID/outlookSecret

**Setup**:
```sql
-- Delete MicrosoftAccount (if exists)
UPDATE microsoftaccounts
SET "deletedAt" = NOW()
WHERE "orgId" = '<your-org-id>'
  AND 'MAIL' = ANY("permissionScopes");

-- Configure manual credentials
UPDATE companysettings
SET
  "emailSettings" = 'MICROSOFT_OUTLOOK',
  "outlookTenantID" = '<your-tenant-id>',
  "outlookID" = '<your-client-id>',
  "outlookSecret" = '<your-client-secret>',
  "mailerAccount" = 'test@company.com'
WHERE "orgId" = '<your-org-id>';
```

**Test Steps**: Same as Test Case 1

**Expected Results**:
- ✅ Log shows "Using manual M365 credentials from company settings"
- ✅ Email sends successfully
- ✅ Status = `"delivered"`

---

### Test Case 3: Send Email with CC/BCC Recipients

**Priority**: 🟡 High
**Scenario**: Multiple recipients in different fields

**Test Steps**:
```graphql
mutation {
  abmsCreateCommunicationLog(
    communicationLog: {
      commType: "Email"
      toEmail: "primary@example.com,secondary@example.com"
      ccEmail: "cc1@example.com,cc2@example.com"
      bccEmail: "bcc@example.com"
      subjectEmail: "Test Email with CC/BCC"
      bodyEmail: "<p>This email has multiple recipients.</p>"
    }
  ) {
    id
    toEmail
    ccEmail
    bccEmail
    status
  }
}
```

**Expected Results**:
- ✅ All TO recipients receive email
- ✅ All CC recipients receive email (visible in CC field)
- ✅ BCC recipient receives email (not visible to others)
- ✅ Status = `"delivered"`

**Verification**:
- Check each recipient's inbox
- Verify CC recipients see other CC addresses
- Verify BCC recipient is hidden from others

---

### Test Case 4: Failed Delivery - Invalid Email

**Priority**: 🔴 Critical
**Scenario**: Acceptance Criteria 2 - Failed Delivery Handling

**Test Steps**:
```graphql
mutation {
  abmsCreateCommunicationLog(
    communicationLog: {
      commType: "Email"
      toEmail: "invalid-email-format"
      subjectEmail: "Test Failed Delivery"
      bodyEmail: "<p>This should fail.</p>"
    }
  ) {
    id
    toEmail
    status
  }
}
```

**Expected Results**:
- ✅ Email queued successfully (status = `null` initially)
- ✅ Status updates to `"failed"` within 30 seconds
- ✅ Error logged in communication-media service
- ⚠️ **NOTE**: Exact validation depends on communication-media service

**Verification**:
```bash
# Check logs for validation error
docker logs msvc-cto-communication-media | tail -50
```

---

### Test Case 5: Missing Credentials Error

**Priority**: 🟡 High
**Scenario**: No credentials configured

**Setup**:
```sql
-- Remove all Outlook credentials
UPDATE companysettings
SET
  "tenantId" = NULL,
  "clientId" = NULL,
  "clientSecret" = NULL,
  "outlookTenantID" = NULL,
  "outlookID" = NULL,
  "outlookSecret" = NULL
WHERE "orgId" = '<your-org-id>';
```

**Test Steps**: Create email communication log (same as Test Case 1)

**Expected Results**:
- ✅ Log shows "no_microsoft_credentials_found"
- ✅ Status = `"failed"` immediately
- ✅ Email NOT queued to Pulsar
- ✅ No attempt to send email

**Verification**:
```bash
# Check backend logs
grep "no_microsoft_credentials_found" /path/to/logs
```

---

### Test Case 6: Communication Media Service Downtime

**Priority**: 🔴 Critical
**Scenario**: Graceful service downtime handling

**Test Steps**:
1. Stop communication-media service:
   ```bash
   cd /Users/ctouser/CTO/msvc-abms-communication-media
   yarn docker:dev:down
   # OR
   docker stop msvc-cto-communication-media
   ```

2. Create email communication log (same as Test Case 1)

3. Verify message queued:
   ```bash
   # Check Pulsar Admin
   open http://localhost:8080
   # Look for messages in COMMUNICATION_MEDIA topic
   ```

4. Query status immediately:
   ```graphql
   query {
     abmsFindCommunicationLogById(id: "<communication-log-id>") {
       status
     }
   }
   ```
   - Expected: `status = null` (pending in queue)

5. Restart communication-media service:
   ```bash
   yarn docker:dev:full
   ```

6. Wait 30 seconds and query status again

**Expected Results**:
- ✅ Message queued successfully while service is down
- ✅ Status = `null` (pending)
- ✅ Message processed after service restart
- ✅ Status updates to `"delivered"` after restart
- ✅ Email delivered to recipient

**Failure Modes**:
- If status = `"failed"` immediately → queueing failed (Pulsar issue)
- If status stays `null` after restart → consumer not processing messages

---

### Test Case 7: Verify 30-Second Status Update Requirement

**Priority**: 🔴 Critical
**Scenario**: Non-functional requirement - status update timing

**Test Steps**:
1. Create email communication log (Test Case 1)
2. Record timestamp: `T0 = createdAt`
3. Poll status every 5 seconds:
   ```graphql
   query {
     abmsFindCommunicationLogById(id: "<communication-log-id>") {
       status
       createdAt
       updatedAt
     }
   }
   ```
4. Record timestamp when status changes: `T1 = updatedAt`
5. Calculate: `ΔT = T1 - T0`

**Expected Results**:
- ✅ ΔT ≤ 30 seconds for successful delivery
- ✅ ΔT ≤ 30 seconds for failed delivery

**Performance Baseline**:
- Typical: 2-5 seconds
- Acceptable: 5-20 seconds
- Warning: 20-30 seconds
- Failure: >30 seconds

**If Test Fails**:
- Check communication-media service performance
- Review Pulsar consumer lag
- Check Microsoft Graph API response times
- Consider optimizing token caching

---

### Test Case 8: HTML Email Body

**Priority**: 🟢 Low
**Scenario**: Rich HTML content with images

**Test Steps**:
```graphql
mutation {
  abmsCreateCommunicationLog(
    communicationLog: {
      commType: "Email"
      toEmail: "test@example.com"
      subjectEmail: "HTML Email Test"
      bodyEmail: """
        <html>
          <body>
            <h1 style="color: blue;">Welcome to ABMS</h1>
            <p>This is a <strong>rich HTML</strong> email with:</p>
            <ul>
              <li>Formatted text</li>
              <li>Lists</li>
              <li>Images</li>
            </ul>
            <img src="https://via.placeholder.com/300" alt="Test Image">
            <p>Best regards,<br>ABMS Team</p>
          </body>
        </html>
      """
    }
  ) {
    id
    status
  }
}
```

**Expected Results**:
- ✅ Email delivered successfully
- ✅ HTML rendered correctly in recipient inbox
- ✅ Images display (if using external URLs)
- ✅ Formatting preserved (colors, bold, lists)

---

### Test Case 9: Bulk Email Creation

**Priority**: 🟡 High
**Scenario**: Performance with multiple simultaneous emails

**Test Steps**:
```graphql
mutation {
  abmsCreateCommunicationLogs(
    communicationLogs: [
      {
        commType: "Email"
        toEmail: "recipient1@example.com"
        subjectEmail: "Bulk Email 1"
        bodyEmail: "<p>Message 1</p>"
      },
      {
        commType: "Email"
        toEmail: "recipient2@example.com"
        subjectEmail: "Bulk Email 2"
        bodyEmail: "<p>Message 2</p>"
      },
      {
        commType: "Email"
        toEmail: "recipient3@example.com"
        subjectEmail: "Bulk Email 3"
        bodyEmail: "<p>Message 3</p>"
      }
    ]
  ) {
    id
    status
    toEmail
  }
}
```

**Expected Results**:
- ✅ All emails queued within 2 seconds
- ✅ All statuses update within 30 seconds
- ✅ All emails delivered to recipients
- ✅ No rate limiting errors (under Microsoft limits)

**Performance Metrics**:
- Queueing: <500ms total
- Status updates: <30s per email
- No Pulsar queue backlog

---

### Test Case 10: SMTP Fallback (Non-Outlook)

**Priority**: 🟢 Low
**Scenario**: Using Gmail or other SMTP provider

**Setup**:
```sql
UPDATE companysettings
SET
  "emailSettings" = 'GMAIL',  -- or 'SMTP'
  "mailHost" = 'smtp.gmail.com',
  "mailPort" = '587',
  "appPassword" = '<gmail-app-password>',
  "mailerAccount" = 'sender@gmail.com'
WHERE "orgId" = '<your-org-id>';
```

**Test Steps**: Same as Test Case 1

**Expected Results**:
- ✅ Email sent via SMTP (not Microsoft Graph API)
- ✅ Status = `"delivered"`
- ✅ Logs show SMTP configuration used

---

## Monitoring Queries

### Dashboard Query: Email Success Rate (Last 24h)

```sql
SELECT
  COUNT(*) FILTER (WHERE status = 'delivered') as delivered,
  COUNT(*) FILTER (WHERE status = 'failed') as failed,
  COUNT(*) FILTER (WHERE status IS NULL) as pending,
  ROUND(
    COUNT(*) FILTER (WHERE status = 'delivered')::numeric /
    NULLIF(COUNT(*), 0) * 100,
    2
  ) as success_rate_percent
FROM communication_logs
WHERE "commType" = 'Email'
  AND "createdAt" >= NOW() - INTERVAL '24 hours'
  AND "deletedAt" IS NULL;
```

**Expected**: success_rate_percent ≥ 95%

---

### Dashboard Query: Recent Failures

```sql
SELECT
  id,
  "toEmail",
  "subjectEmail",
  "createdAt",
  "updatedAt",
  EXTRACT(EPOCH FROM ("updatedAt" - "createdAt")) as seconds_to_fail
FROM communication_logs
WHERE "commType" = 'Email'
  AND status = 'failed'
  AND "createdAt" >= NOW() - INTERVAL '1 hour'
  AND "deletedAt" IS NULL
ORDER BY "createdAt" DESC
LIMIT 20;
```

---

### Dashboard Query: Status Update Performance

```sql
SELECT
  id,
  "toEmail",
  "createdAt",
  "updatedAt",
  status,
  EXTRACT(EPOCH FROM ("updatedAt" - "createdAt")) as seconds_to_update
FROM communication_logs
WHERE "commType" = 'Email'
  AND "updatedAt" IS NOT NULL
  AND "createdAt" >= NOW() - INTERVAL '1 hour'
  AND "deletedAt" IS NULL
ORDER BY seconds_to_update DESC
LIMIT 20;
```

**Expected**: seconds_to_update ≤ 30 for all rows

---

### Dashboard Query: Stuck Messages

```sql
SELECT
  id,
  "toEmail",
  "subjectEmail",
  "createdAt",
  EXTRACT(EPOCH FROM (NOW() - "createdAt")) as seconds_pending
FROM communication_logs
WHERE "commType" = 'Email'
  AND status IS NULL
  AND "createdAt" < NOW() - INTERVAL '5 minutes'
  AND "deletedAt" IS NULL
ORDER BY "createdAt" ASC;
```

**Expected**: 0 rows (no stuck messages)

---

## Regression Testing

### Related Functionality

After implementing ABMS-1018, verify these existing features still work:

1. **SMS Communication Logs** (ABMS-3723):
   ```graphql
   mutation {
     abmsCreateCommunicationLog(
       communicationLog: {
         commType: "SMS"
         toSMS: "+61412345678"
         messageSMS: "Test SMS"
       }
     ) {
       id
       status
     }
   }
   ```
   - Expected: SMS still sends successfully

2. **Non-Email Communication Logs**:
   ```graphql
   mutation {
     abmsCreateCommunicationLog(
       communicationLog: {
         commType: "Phone Call"
         notes: "Called customer about quote"
       }
     ) {
       id
     }
   }
   ```
   - Expected: No email/SMS processing, just logging

3. **Existing Email Functionality**:
   - Test email from DealFollowUpService
   - Test email from JobScheduleService
   - Verify no impact on existing email flows

---

## Performance Benchmarks

### Target Metrics

| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Email queueing time | <100ms | 100-500ms | >500ms |
| Status update time (delivered) | <10s | 10-20s | >30s |
| Status update time (failed) | <5s | 5-15s | >30s |
| Success rate (24h) | >95% | 85-95% | <85% |
| Pulsar queue lag | <10 messages | 10-100 | >100 |

### Load Testing

**Scenario**: 100 emails created within 1 minute

**Test Steps**:
1. Create script to send 100 emails rapidly
2. Monitor Pulsar queue depth
3. Monitor communication-media service CPU/memory
4. Track status update times

**Expected Results**:
- All 100 emails queued successfully
- No errors or timeouts
- All statuses update within 2 minutes
- Pulsar queue clears within 5 minutes

---

## Test Execution Checklist

### Pre-Testing
- [ ] All services running (Postgres, Redis, Pulsar, msvc-abms, msvc-abms-communication-media)
- [ ] CompanySettings configured with valid credentials
- [ ] MicrosoftAccount created with MAIL permission (for OAuth tests)
- [ ] Test email addresses accessible for verification

### Core Test Cases
- [ ] Test Case 1: Send email via OAuth MicrosoftAccount
- [ ] Test Case 2: Send email via manual M365 credentials
- [ ] Test Case 3: Send email with CC/BCC recipients
- [ ] Test Case 4: Failed delivery - invalid email
- [ ] Test Case 5: Missing credentials error
- [ ] Test Case 6: Communication media service downtime
- [ ] Test Case 7: Verify 30-second status update requirement

### Optional Test Cases
- [ ] Test Case 8: HTML email body
- [ ] Test Case 9: Bulk email creation
- [ ] Test Case 10: SMTP fallback

### Regression Testing
- [ ] SMS communication logs still work
- [ ] Non-email communication logs still work
- [ ] Existing email functionality unaffected

### Performance Testing
- [ ] Monitor dashboard queries show healthy metrics
- [ ] No stuck messages in queue
- [ ] Status updates within 30 seconds consistently

### Post-Testing
- [ ] Document any issues found
- [ ] Update Jira ticket with test results
- [ ] Move ticket to "Testing" or "Done" status

---

## Known Limitations

1. **Token Refresh**: Handled by communication-media service, not tested in backend
2. **Rate Limiting**: Microsoft Graph API limits not enforced in backend
3. **Retry Logic**: Not implemented in backend, should be in communication-media
4. **Attachment Support**: Not implemented (future enhancement)
5. **Read Receipts**: Not implemented (future enhancement)

---

## Sign-Off

### Test Results Summary

| Test Case | Status | Notes |
|-----------|--------|-------|
| TC1: OAuth Email | ⏳ Pending | |
| TC2: Manual M365 | ⏳ Pending | |
| TC3: CC/BCC | ⏳ Pending | |
| TC4: Failed Delivery | ⏳ Pending | |
| TC5: Missing Credentials | ⏳ Pending | |
| TC6: Service Downtime | ⏳ Pending | |
| TC7: 30s Requirement | ⏳ Pending | |

**Overall Status**: ⏳ Ready for Testing

**Tested By**: _________________
**Date**: _________________
**Approved By**: _________________
**Date**: _________________

---

**Next Steps**:
1. Execute test cases in order
2. Document results in this file
3. Create bug tickets for any failures
4. Update ABMS-1018 ticket status
5. Deploy to staging environment
