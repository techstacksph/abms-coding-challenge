# Quick Setup Guide for ABMS Postman Collection

## 🚀 Get Started in 3 Steps

### Step 1: Import the Collection
1. Open Postman
2. Click **Import** button
3. Drag and drop `AccountCodeResolver_Sorting_Tests.postman_collection.json` or click to browse and select the file

### Step 2: Import the Environment
1. In Postman, click **Import** again
2. Select `ABMS_Environment.postman_environment.json`
3. The environment will be added to your environments list

### Step 3: Select Environment
1. In the top-right corner of Postman, click the environment dropdown
2. Select **"ABMS Development Environment"**
3. You're ready to test! 🎉

## 🔧 Customize URLs (Optional)

If you need to change the default URLs:

1. Click the **Environment** dropdown (top-right)
2. Click the **Edit** button (pencil icon)
3. Modify these variables:
   - `baseUrl`: Your GraphQL API host (without protocol)
   - `ABMS_PORT`: Your GraphQL API port
   - `authHost`: Your authentication service host (without protocol)
   - `authPort`: Your authentication service port
4. Click **Save**

## 🧪 Run Your First Test

1. Open the collection in Postman
2. Run **"1. Get Authentication Token"** first
3. This will automatically set the `authToken` variable
4. Now you can run any of the sorting tests!

## 📝 What Each Variable Does

- **baseUrl**: Where your GraphQL API is running (default: `localhost`)
- **ABMS_PORT**: Port for your GraphQL API (default: `3001`)
- **authHost**: Where your auth service is running (default: `localhost`)
- **authPort**: Port for your auth service (default: `8092`)
- **authToken**: Automatically populated when you authenticate (no need to set manually)

## 🆘 Troubleshooting

**Collection not working?**
- Make sure you've selected the "ABMS Development Environment"
- Verify your services are running on the configured ports
- Check that the authentication request runs successfully first

**Need to test against different environments?**
- Create a new environment with different URLs
- Or duplicate the existing environment and modify the URLs
