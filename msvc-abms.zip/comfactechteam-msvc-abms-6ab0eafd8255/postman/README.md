# ABMS Postman Collections

This folder contains a unified Postman collection for testing all ABMS GraphQL resolver sorting functionality.

## 🚀 Quick Start

1. **Import the Collection**: `ABMS_Unified_Sorting_Tests.postman_collection.json`
2. **Import the Environment**: `ABMS_Environment.postman_environment.json`
3. **Run Authentication**: Execute "Get Authentication Token" first
4. **Run Tests**: Execute any sorting tests for the resolvers you need

## 📁 Main Collection

### ABMS_Unified_Sorting_Tests.postman_collection.json

A comprehensive unified collection containing **192 sorting tests** across **22 GraphQL resolvers**, organized into logical categories:

#### 🔐 Authentication
- **Get Authentication Token** - JWT token retrieval for all API requests

#### 📊 Core Entity Resolvers (69 tests)
- **Account Sorting Tests** (12 tests) - Including relation sorting (location.name, status.name, etc.)
- **Contact Sorting Tests** (10 tests) - Including relation sorting (status.name, country.name, etc.)
- **Job Sorting Tests** (9 tests) - Including relation sorting
- **Case Sorting Tests** (8 tests) - Including relation sorting
- **Deal Sorting Tests** (10 tests) - Including relation sorting
- **Lead Sorting Tests** (10 tests) - Including relation sorting

#### 💰 Financial Resolvers (39 tests)
- **Bill Sorting Tests** (10 tests) - Including relation sorting
- **Invoice Sorting Tests** (10 tests) - Including relation sorting
- **Quote Sorting Tests** (10 tests) - Including relation sorting
- **Account Code Sorting Tests** (9 tests) - Basic field sorting

#### 📅 Activity & Events (20 tests)
- **Event Sorting Tests** (10 tests) - Including relation sorting
- **Task Sorting Tests** (10 tests) - Including relation sorting

#### 👥 User & System (19 tests)
- **User Sorting Tests** (10 tests) - Including relation sorting
- **Account Product Favorite Sorting Tests** (9 tests) - Including relation sorting

#### 🏪 Catalog & Reference Data (45 tests)
- **Item Sorting Tests** (10 tests) - Including relation sorting
- **Service Type Sorting Tests** (8 tests)
- **Area Sorting Tests** (7 tests) - Simple entity, no relations
- **Country Sorting Tests** (6 tests)
- **Source Sorting Tests** (6 tests)
- **Channel Sorting Tests** (6 tests)
- **Case Type Sorting Tests** (6 tests)
- **Unit of Measure Sorting Tests** (6 tests)

#### Test Coverage Per Resolver
Each resolver includes comprehensive sorting tests:
- **Basic Sorting**: ASC/DESC for primary fields
- **Multi-field Sorting**: Compound sorting logic
- **Relation Sorting**: Sorting by related entity fields (e.g., `account.name`, `status.name`)
- **Pagination with Sorting**: Sorting within paginated results
- **Search with Sorting**: Combined search and sort functionality
- **CSV Export with Sorting**: Sorted data export (where applicable)

## 📈 Migration Complete

Individual collections (22 files) have been successfully consolidated into the unified collection. All 192 tests are now organized in logical categories within the single collection file.

## Environment Setup

### Option 1: Import Environment File (Recommended)
1. Import the `ABMS_Environment.postman_environment.json` file into Postman
2. Select the "ABMS Development Environment" from the environment dropdown
3. The collection will automatically use the configured URLs

### Option 2: Manual Environment Setup
Create a Postman environment with these variables:

- `baseUrl`: `localhost` (GraphQL API host, without protocol)
- `ABMS_PORT`: `3001` (GraphQL API port)
- `authHost`: `localhost` (Authentication service host, without protocol)
- `authPort`: `8092` (Authentication service port)
- `authToken`: (automatically set by authentication request)

### Environment Variables Explained
- **baseUrl**: The main GraphQL API host where all sorting tests are executed (e.g., `localhost`)
- **ABMS_PORT**: The port for the GraphQL API (e.g., `3001`)
- **authHost**: The authentication service host for obtaining JWT tokens (e.g., `localhost`)
- **authPort**: The authentication service port for obtaining JWT tokens (e.g., `8092`)
- **authToken**: Automatically populated when you run the authentication request

## Notes

- The collection uses collection variables to store the JWT token
- All tests include validation scripts to verify response structure and sorting logic
- The collection is designed to test the sorting fixes implemented in ABMS-3892
- **Authentication**: Uses GET request with base64-encoded credentials in the URL path (e.g., `ZXVnZW5lQGF5ci1kZXY6Q3RvZGV2QDEyMw==` for `eugene@ayr-dev:Ctodev@123`)
- **GraphQL Format**: All requests now use Postman's native GraphQL mode instead of raw JSON, providing better syntax highlighting and validation
