# ABMS Deletion Prevention Test Suite

## Overview

This Postman collection tests the **BA requirement implementation** that prevents deletion of records when they have active references in other tables. The tests validate the automatic reference discovery system implemented in `BaseService.ts`.

## 🎯 What This Tests

### BA Requirement
> **Records cannot be deleted if they are referenced by other records.**

### Technical Implementation
- **Auto-discovery** of foreign key relationships using TypeORM metadata
- **Prevention logic** in `BaseService.handleCascadingDelete()`
- **Clear error messages** showing which tables have references
- **Successful deletion** when no references exist

## 📋 Test Scenarios

### 1. Setup Data (6 requests)
Creates a complete relationship hierarchy:
```
Account → Site → Note 1, Note 2
       → Note 3  → Contact
```

**Test Data Created (with unique identifiers):**
- **Account**: "Test Account {randomInt}-{timestamp}" (unique per run)
- **Site**: "Test Site {randomInt}-{timestamp}" (references Account)
- **Note 1**: "Test Note 1 {randomInt}" (references Site)
- **Note 2**: "Test Note 2 {randomInt}" (references Site)
- **Note 3**: "Test Note 3 {randomInt}" (references Account)
- **Contact**: "Test {randomInt} Contact {timestamp}" (references Site)


### 2. Deletion Prevention Tests (3 requests)
Tests that deletion is **blocked** when references exist:

#### ❌ Delete Site (Should Fail)
- **Expected**: Error with message like `"Cannot delete site: Active references exist in 1 jobs, 1 deals, 1 leads"`
- **Validates**: TypeORM metadata discovery finds all OneToMany relationships

#### ❌ Delete Contact (Should Fail)  
- **Expected**: Error with message like `"Cannot delete contact: Active references exist in 1 jobs, 1 deals"`
- **Validates**: System finds references across multiple tables

#### ❌ Delete Account (Should Fail)
- **Expected**: Error with message like `"Cannot delete account: Active references exist in 1 site"`
- **Validates**: Hierarchical reference detection

### 3. Successful Deletion Tests (6 requests)
Tests deletion in **correct order** (leaf to root):

#### ✅ Delete Job → ✅ Delete Deal → ✅ Delete Lead
- **Expected**: All succeed (no references to these records)
- **Validates**: Records without references can be deleted

#### ✅ Delete Contact → ✅ Delete Site → ✅ Delete Account  
- **Expected**: All succeed after removing references
- **Validates**: Deletion works once references are gone

### 4. Edge Case Tests (2 requests)
Tests error handling and edge scenarios:

#### ✅ Delete Non-Existent Record
- **Expected**: "Data not found" error
- **Validates**: Graceful handling of invalid IDs

#### ❌ Complex Reference Scenarios
- **Expected**: Clear error messages for multiple reference types
- **Validates**: System handles complex relationship hierarchies

## 🚀 How to Run Tests

### Prerequisites
1. **Environment Setup**: Import `ABMS_Environment.postman_environment.json` which provides:
   - `{{baseUrl}}` - ABMS API host (e.g., "localhost")
   - `{{ABMS_PORT}}` - ABMS API port (e.g., "3001") 
   - `{{authHost}}` - Authentication service host
   - `{{authPort}}` - Authentication service port (e.g., "8092")
   - `{{authToken}}` - JWT token (automatically set by authentication request)
2. **Database Access**: Tests create and delete real data
3. **Permissions**: User must have CREATE/DELETE permissions for all tested modules

### Execution Order
**⚠️ IMPORTANT**: Run requests in the exact order shown:
1. **🔐 Authentication** folder - Get JWT token (run this first!)
2. **Setup Data** folder - Creates test relationships
3. **Test Deletion Prevention** folder - Validates prevention logic
4. **Test Successful Deletions** folder - Validates successful deletion
5. **Edge Case Tests** folder - Tests error scenarios

### Expected Results

#### ✅ Success Indicators
- **Prevention Tests**: All return GraphQL errors with reference details
- **Successful Deletions**: All return `true` after references removed
- **Clear Messages**: Error messages specify exactly which tables have references

#### ❌ Failure Indicators  
- **No Errors When Expected**: Prevention logic not working
- **Deletion Succeeds When It Shouldn't**: Reference discovery failing
- **Unclear Error Messages**: Poor user experience

## 📊 Test Coverage

### Models with OneToMany Relationships Tested
- **AccountModel** → sites, contacts, jobs, deals, etc.
- **SiteModel** → jobs, deals, leads, notes, documents, etc.
- **ContactModel** → jobs, deals, cases, leads, etc.

### GraphQL Mutations Tested
- `abmsdeleteAccount` - Account deletion
- `abmsdeleteSite` - Site deletion  
- `abmsdeleteContact` - Contact deletion
- `abmsdeleteJob` - Job deletion
- `abmsdeleteDeal` - Deal deletion
- `abmsdeleteLead` - Lead deletion

### Relationship Types Covered
- **OneToMany**: Primary relationships (Site → Jobs)
- **ManyToOne**: Reverse relationships (Job → Site)
- **Complex Hierarchies**: Account → Site → Job chains
- **Multiple References**: Contact referenced by Jobs + Deals

## 🔍 Validation Points

### Error Message Format
```javascript
"Cannot delete {modelName}: Active references exist in {count} {tableName}, {count} {tableName}"
```

### Example Expected Errors
```javascript
"Cannot delete site: Active references exist in 1 jobs, 1 deals, 1 leads"
"Cannot delete contact: Active references exist in 1 jobs, 1 deals"  
"Cannot delete account: Active references exist in 1 site"
```

### Success Response Format
```javascript
{
  "data": {
    "abmsdeleteModelName": true
  }
}
```

## 🛠️ Troubleshooting

### Common Issues

**Tests Pass But Shouldn't**
- Check if `handleCascadingDelete` is being called in `softDelete`
- Verify TypeORM metadata is loading relationships correctly
- Ensure test data was created with proper foreign key references

**Error Messages Don't Match Expected Format**
- Check `discoverReferences` method is finding the right relationships
- Verify table names match between TypeORM metadata and database
- Ensure foreign key column names are correct

**Tests Fail Due to Permissions**
- Verify user has DELETE permissions for all tested modules
- Check authentication token is valid and not expired
- Ensure data isolation (orgId) is configured correctly

### Debug Information
Each test logs success/failure details to Postman console:
```javascript
console.log('✅ Site deletion correctly prevented:', errorMessage);
console.log('✅ Job deletion successful');
```

## 📈 Expected Test Results

### Summary
- **Authentication**: 1/1 should succeed and set JWT token
- **Setup Requests**: 6/6 should succeed
- **Prevention Tests**: 3/3 should fail with reference errors  
- **Success Tests**: 6/6 should succeed after references removed
- **Edge Cases**: 2/2 should handle errors gracefully

### Total: 18 requests testing comprehensive deletion prevention

This test suite provides **complete validation** of the BA requirement implementation, ensuring that the automatic reference protection system works correctly across all relationship types and scenarios! 🎉
