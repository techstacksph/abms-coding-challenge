# Stock Control Testing Guide - ABMS-4525

This guide provides instructions for testing the Stock Control creation functionality using the provided Postman collection, specifically for validating the fix for ABMS-4525.

## Overview

The fix for **ABMS-4525** addresses a GraphQL error that occurred when creating Stock Control records:
- **Error**: "cannot return null for non-nullable field abmsStockControl.notes"
- **Solution**: Made all relationship arrays nullable (items, documents, tasks, events, communicationLogs, notes)
- **Additional Fix**: Updated field names in StockControlModelDictionary (transactionDate → transDate, transactionType → transType)

## Prerequisites

1. **Running Services**
   - **msvc-authorization-abms** (Auth service): `http://localhost:8082`
   - **msvc-gw-apollo-abms** (Apollo Gateway): `http://localhost:3001/graphql`
   - **msvc-abms** (Backend microservice): `http://localhost:8083`
   - Database with required seed data

2. **Required Test Data**
   You'll need valid IDs for:
   - **User ID**: A valid user in the system
   - **Location ID**: A valid location
   - **Status ID**: A valid workflow status for stock control
   - **Item ID**: A valid inventory item (for item-related tests)
   - **Warehouse IDs**: Source and destination warehouses (for transfer tests)

3. **Authentication**
   - Valid authentication token with STOCK_CONTROL permissions

## Setup Instructions

### 1. Import Postman Collection

```bash
# Open Postman and import the collection file
File → Import → Stock_Control_Testing.postman_collection.json
```

The collection is organized into two folders:
- **Setup** - 6 requests to authenticate and gather required IDs
- **Stock Control Tests** - 10 test scenarios for Stock Control creation

### 2. Run Setup Requests (Automatic)

The Setup folder contains requests that **automatically save** required IDs to collection variables:

1. **0. Login - Get Auth Token**
   - Update the `credentials` variable with Base64 encoded `username:password`
     - Example: For `admin:password123`, encode to Base64: `YWRtaW46cGFzc3dvcmQxMjM=`
     - Online tool: https://www.base64encode.org/
   - Run the request to **msvc-authorization-abms** (REST API on port 8082)
   - Automatically saves: `authToken` and `username`

2. **0b. Get User ID**
   - Run this request (uses the token from step 1)
   - Calls `/v1/authenticate/token/permission/:token` endpoint
   - Automatically saves: `userId` (extracted from `userPermission.user_id`)

3. **1. Get Location ID**
   - Run this request (uses the token from step 1)
   - Automatically saves the first location's ID to `locationId`

4. **2. Get Workflow Status ID**
   - Run this request to get workflow statuses
   - **Auto-saves** the "Created" status from "Stock Control" workflow process
   - If Stock Control workflow is not found, you need to run migrations first:
     ```bash
     cd /Users/eugenecto/CTO/msvc-abms
     yarn migration:run
     ```
   - The migration creates 4 statuses: **Created**, **Submitted**, **Completed**, **Cancelled**

5. **3. Get Item ID**
   - Run this request
   - Automatically saves the first item ID to `itemId`

6. **4. Get Warehouse IDs**
   - Run this request
   - Automatically saves the first two warehouse IDs to `sourceWarehouseId` and `destinationWarehouseId`

**All variables are automatically populated!** You can verify them in Collection → Variables.

### 3. Manual Configuration (Optional)

If you prefer to manually set variables, configure them in (Collection → Variables):

| Variable | Description | Example |
|----------|-------------|---------|
| `graphqlUrl` | Apollo Gateway endpoint URL | `http://localhost:3001/graphql` |
| `authUrl` | Auth service endpoint URL | `http://localhost:8082` |
| `credentials` | Base64 encoded username:password | `YWRtaW46cGFzc3dvcmQ=` |
| `authToken` | Your authentication token (NO "Bearer" prefix) | `eyJhbGciOiJIUzI1NiIsInR5cCI6...` |
| `userId` | Valid user ID | `550e8400-e29b-41d4-a716-446655440000` |
| `locationId` | Valid location ID | `660e8400-e29b-41d4-a716-446655440001` |
| `statusId` | Valid workflow status ID | `770e8400-e29b-41d4-a716-446655440002` |
| `itemId` | Valid item ID | `880e8400-e29b-41d4-a716-446655440003` |
| `sourceWarehouseId` | Source warehouse ID | `990e8400-e29b-41d4-a716-446655440004` |
| `destinationWarehouseId` | Destination warehouse ID | `aa0e8400-e29b-41d4-a716-446655440005` |

### 3. Get Authentication Token (Using Setup Request)

The collection includes an automated login request that uses the **msvc-authorization-abms REST API**:

**Endpoint:** `POST http://localhost:8082/v1/authenticate/:credential`

**How it works:**
1. Encode your credentials as Base64: `username:password`
   ```bash
   # Example in terminal:
   echo -n "admin:password123" | base64
   # Output: YWRtaW46cGFzc3dvcmQxMjM=
   ```
2. Set the `credentials` variable to the Base64 string
3. Run request "0. Login - Get Auth Token"
4. The response contains `access_token` which is automatically saved to `authToken`

**Response format:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6...",
  "token_type": "bearer",
  "refresh_token": "...",
  "expires_in": 3600,
  "scope": "read write",
  "user_id": "...",
  "user_name": "admin",
  "jti": "..."
}
```

**IMPORTANT**: The Apollo Gateway expects the token in the Authorization header **without** the "Bearer" prefix. Just use the token value itself: `Authorization: <token>`

### 4. Manual Queries for IDs (Optional)

If you want to manually find IDs instead of using the Setup folder, use these GraphQL queries (via Apollo Gateway at http://localhost:3001/graphql):

#### Get User ID
```graphql
query {
  abmsPaginatedUsers(page: {skip: 0, take: 1}) {
    data {
      id
      username
    }
  }
}
```

#### Get Location ID
```graphql
query {
  abmsPaginatedLocations(page: {skip: 0, take: 1}) {
    data {
      id
      locationName
    }
  }
}
```

#### Get Workflow Status ID
```graphql
query {
  abmsPaginatedWorkflowStatuses(
    page: {skip: 0, take: 10}
    searchArg: [{fieldName: "workflowType", searchValue: "stock_control", comparator: "EQUAL"}]
  ) {
    data {
      id
      statusName
      workflowType
    }
  }
}
```

#### Get Item ID
```graphql
query {
  abmsPaginatedItems(page: {skip: 0, take: 1}) {
    data {
      id
      itemName
    }
  }
}
```

#### Get Warehouse IDs
```graphql
query {
  abmsPaginatedWarehouses(page: {skip: 0, take: 2}) {
    data {
      id
      warehouseName
    }
  }
}
```

## Quick Start

### Fastest Way to Get Started:

1. **Import** the Postman collection
2. **Encode your credentials** to Base64:
   ```bash
   echo -n "your-username:your-password" | base64
   ```
3. **Update the `credentials` variable** in Collection → Variables with the Base64 string
4. **Run all Setup requests** in order (0 through 4):
   - Request 0 calls REST API at port 8082 to get auth token
   - Request 0b calls REST API at port 8082 to get user ID from token permissions
   - Requests 1-4 call GraphQL at port 3001 to get location, status, item, and warehouse IDs
   - Watch the Console to see all variables being automatically saved
5. **Run Stock Control Tests** - All variables are already set!

## Test Scenarios

The **Stock Control Tests** folder includes 10 comprehensive test scenarios:

### 1. Create Stock Control - Minimal (No Relationships)
**Purpose**: Verify that Stock Control can be created without any relationship objects
**Key Test**: Confirms nullable relationships don't cause errors when not provided

### 2. Create Stock Control - With Items
**Purpose**: Create Stock Control and query the items relationship
**Key Test**: Items array returns null/empty without errors

### 3. Create Stock Control - Full with All Relations ⭐
**Purpose**: **CRITICAL TEST** - Creates Stock Control and queries ALL relationship fields
**Key Test**: This is the primary test for ABMS-4525 - verifies all nullable relationship arrays (items, documents, tasks, events, communicationLogs, notes) return null or empty arrays without throwing "cannot return null for non-nullable field" errors

**Expected Result**:
```json
{
  "data": {
    "abmsCreateStockControl": {
      "id": "...",
      "scNo": "SC000001",
      "items": null,          // or []
      "documents": null,      // or []
      "tasks": null,          // or []
      "events": null,         // or []
      "communicationLogs": null,  // or []
      "notes": null           // or []
    }
  }
}
```

### 4. Create Stock Control - Transfer Type
**Purpose**: Test Transfer transaction type with warehouses
**Transaction Type**: `TRANSFER`

### 5. Create Stock Control - As Template
**Purpose**: Test creating a reusable template
**Key Field**: `isTemplate: true`

### 6. Get Stock Control by ID - Full Relations
**Purpose**: Retrieve existing Stock Control with all relationships
**Key Test**: Verify nullable relationships work in read operations

### 7. List Stock Controls - Paginated
**Purpose**: Test paginated listing with relationships
**Key Test**: Confirm nullable relationships work in list queries

### 8. Create Stock Control Item
**Purpose**: Add items to an existing Stock Control
**Prerequisites**: Create a Stock Control first and use its ID

### 9. Update Stock Control
**Purpose**: Update existing Stock Control record
**Key Test**: Relationship arrays remain nullable after updates
**Note**: All fields in the update input are optional except `id`. You can update any combination of fields.

### 10. Test All Transaction Types
**Purpose**: Test all transaction type variations
**Transaction Types**:
- `MANUAL_ADD` - Manual stock addition
- `MANUAL_DEDUCT` - Manual stock deduction
- `TRANSFER` - Transfer between warehouses
- `STOCK_COUNT` - Physical stock count
- `SPOT_CHECK` - Spot check verification

## Running the Tests

### Option 1: Run Individual Tests
1. Select a request from the collection
2. Ensure variables are set correctly
3. Click "Send"
4. Review the response

### Option 2: Run All Tests
1. Right-click on the collection
2. Select "Run collection"
3. Review the test results

### Expected Success Criteria
All tests should:
- Return HTTP 200 status
- Have no GraphQL errors in response
- Return data object with requested fields
- Handle nullable relationships correctly (null or empty arrays)

## Troubleshooting

### Error: "cannot return null for non-nullable field"
**Cause**: The schema changes from ABMS-4525 are not deployed
**Solution**: Ensure you're testing against the development environment with the fix merged

### Error: "Unauthorized" or "Forbidden"
**Cause**: Invalid or missing authentication token
**Solution**:
1. Login through **msvc-authorization-abms** (http://localhost:8082/v1/authenticate/:credential)
2. Ensure `credentials` variable contains valid Base64 encoded `username:password`
3. Run the "0. Login - Get Auth Token" request
4. Verify the `authToken` variable is set (check Collection Variables)
5. Ensure user has STOCK_CONTROL permissions (READ, CREATE, UPDATE, DELETE)

### Error: "Foreign key constraint violation"
**Cause**: Invalid IDs in the request
**Solution**: Use the queries in Step 3 to get valid IDs

### Error: Stock Control workflow not found
**Cause**: The Stock Control workflow migration hasn't been run yet
**Solution**:
1. Check if migrations have been run:
   ```bash
   cd /Users/eugenecto/CTO/msvc-abms
   yarn migration:show
   ```
2. Run migrations:
   ```bash
   yarn migration:run
   ```
3. Verify the migration `ABMS4525STOCKCONTROLWORKFLOW1758719018758` has been executed
4. The migration creates:
   - Workflow: "Stock Control"
   - Workflow Process: "Stock Control"
   - Workflow Statuses: Created, Submitted, Completed, Cancelled
   - Workflow Actions: Submit, Complete, Cancel, Reopen, Add note, Send email, Send SMS, Log a call, Create a task, Create an event, Attach Documents

### Error: "Validation failed"
**Cause**: Missing required fields or invalid data types
**Solution**: Ensure all required fields are provided:
- `transDate` (Date)
- `transType` (StockControlTransactionType enum)
- `userId` (String UUID)
- `locationId` (String UUID)
- `statusId` (String UUID)

## Field Reference

### Stock Control Fields

| Field | Type | Required (Create) | Required (Update) | Description |
|-------|------|-------------------|-------------------|-------------|
| `scNo` | String | Auto-generated | No | Stock control number (SC000001) |
| `transDate` | Date | Yes | No | Transaction date (ISO 8601 format: `2025-01-15T00:00:00.000Z`) |
| `transType` | Enum | Yes | No | Transaction type |
| `note` | String | No | No | Optional notes |
| `sourceWarehouseId` | String | No | No | Source warehouse (for transfers) |
| `destinationWarehouseId` | String | No | No | Destination warehouse (for transfers) |
| `userId` | String | Yes | No | User who created the record |
| `locationId` | String | Yes | No | Location ID |
| `statusId` | String | Yes | No | Workflow status ID |
| `isTemplate` | Boolean | No | No | Mark as template (default: false) |

**Important**: When updating, all fields are optional except the `id` parameter (passed separately from the input). You can update any combination of fields.

**Important Date Format Notes:**
- Use ISO 8601 format: `YYYY-MM-DDTHH:mm:ss.sssZ`
- Example: `2025-01-15T00:00:00.000Z` (January 15, 2025 at midnight UTC)
- The database stores only the date part (YYYY-MM-DD)
- TypeORM transformer automatically converts between date and timestamp

### Transaction Types
- `MANUAL_ADD` - Manual addition to stock
- `MANUAL_DEDUCT` - Manual deduction from stock
- `TRANSFER` - Transfer between warehouses
- `STOCK_COUNT` - Physical stock count
- `SPOT_CHECK` - Spot check verification

### Nullable Relationships (Fixed in ABMS-4525)
These fields now return `null` or empty arrays when no data exists:
- `user` - User who created the record (nullable in case user is deleted)
- `location` - Location reference (nullable in case location is deleted)
- `status` - Workflow status (nullable in case status is deleted)
- `sourceWarehouse` - Source warehouse for transfers (nullable)
- `destinationWarehouse` - Destination warehouse for transfers (nullable)
- `items` - Stock control items array
- `documents` - Associated documents array
- `tasks` - Related tasks array
- `events` - Related events array
- `communicationLogs` - Communication logs array
- `notes` - Notes array

### Relationship Field Names
When querying relationship objects, use these field names:
- **Task** - Use `taskSubject` (NOT `taskName`)
- **Event** - Use `subject` (NOT `eventName`)
- **CommunicationLog** - Use `commType` (NOT `subject`)
- **Note** - Use `notes` (NOT `noteText`)

**Example Query:**
```graphql
{
  tasks {
    id
    taskSubject
  }
  events {
    id
    subject
  }
  communicationLogs {
    id
    commType
  }
  notes {
    id
    notes
  }
}
```

## Architecture Notes

### Apollo Gateway vs Direct Microservice Access

This collection uses the **Apollo Gateway** (http://localhost:3001/graphql) instead of directly accessing the microservice (http://localhost:8083/graphql) because:

1. **Authentication**: The gateway handles authentication and authorization
   - **Note**: Gateway expects token in Authorization header **without** "Bearer" prefix
   - Format: `Authorization: <token>` (NOT `Authorization: Bearer <token>`)
2. **Production-like**: Tests against the same endpoint used by the frontend
3. **Federation**: Tests the complete federated GraphQL schema
4. **Token Validation**: Gateway validates and passes authentication tokens to microservices

**Service Architecture:**
```
Step 1: Authenticate
Postman → msvc-authorization-abms (port 8082)
          POST /v1/authenticate/:credential
          ↓
       JWT Token

Step 2: Get User ID
Postman → msvc-authorization-abms (port 8082)
          GET /v1/authenticate/token/permission/:token
          ↓
       UserPermission { user_id, user_name, email, ... }

Step 3: GraphQL Operations
Postman → Apollo Gateway (port 3001) → msvc-abms (port 8083) → PostgreSQL
    (with Authorization: <token>)       ↓
                                 Token Validation
                                 Schema Federation
```

## Additional Notes

### After Creating a Stock Control
1. Save the returned `id` to the `stockControlId` variable
2. Use this ID for:
   - Request #6 (Get by ID)
   - Request #8 (Create Stock Control Item)
   - Request #9 (Update Stock Control)

### Testing Relationship Objects
To fully test the fix, create associated records:

1. **Create Stock Control** (Request #1)
2. **Create Stock Control Item** (Request #8) - adds to items array
3. **Get Stock Control by ID** (Request #6) - verify items array is populated

### Database Verification
You can verify the changes directly in PostgreSQL:

```sql
-- View created stock controls
SELECT * FROM stock_controls ORDER BY created_at DESC LIMIT 5;

-- View stock control items
SELECT sci.*, sc.sc_no
FROM stock_control_items sci
JOIN stock_controls sc ON sci.stock_control_id = sc.id
ORDER BY sci.created_at DESC LIMIT 5;
```

## GraphQL Schema Changes (ABMS-4525)

### Before Fix
```graphql
type abmsStockControl {
  notes: [abmsNote!]!  # Non-nullable array - caused errors
}
```

### After Fix
```graphql
type abmsStockControl {
  notes: [abmsNote!]  # Nullable array - returns null if empty
}
```

This change was applied to all relationship arrays: items, documents, tasks, events, communicationLogs, and notes.

## Important GraphQL Schema Notes

### Pagination Parameter Name
The `abmspaginatedStockControls` query uses `page` (NOT `pageArg`) as the parameter name:
```graphql
query PaginatedStockControls($page: abmsPageArg!) {
  abmspaginatedStockControls(page: $page) {
    # ...
  }
}
```

### User Field Names
The User schema uses `userName` (NOT `username`):
```graphql
user {
  id
  userName  # Correct - camelCase with capital N
  email
}
```

## Support

If you encounter issues:
1. Check the GraphQL response for detailed error messages
2. Verify all environment variables are set correctly
3. Ensure the development environment has the latest code
4. Check database for valid test data
5. Verify authentication token is valid and has correct permissions

---

**Last Updated**: October 21, 2025
**ABMS Version**: Development (with ABMS-4525 fix)
**Auth Endpoint**: http://localhost:8082 (msvc-authorization-abms REST API)
**Gateway Endpoint**: http://localhost:3001/graphql (Apollo Gateway)
**Microservice Endpoint**: http://localhost:8083/graphql (msvc-abms - for internal use only)
