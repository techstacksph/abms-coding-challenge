/** @type {import('@ts-jest/dist/types').InitialOptionsTsJest} */
const baseConfig = require('./tsconfig.json');

const tsConfig = {
  ...baseConfig.compilerOptions,
  types: ['jest', 'node'],
};

module.exports = {
  globalSetup: './jest.global.setup.ts',
  moduleFileExtensions: ['ts', 'tsx', 'js'],
  //preset: 'ts-jest/presets/default-esm',
  preset: 'ts-jest',
  roots: ['<rootDir>/src/'],
  setupFilesAfterEnv: ['./jest.setup.js'],
  testEnvironment: 'node',
  testTimeout: 30000,
  transform: {
    '^.+\\.m?[tj]sx?$': [
      'ts-jest',
      {
        tsconfig: tsConfig,
        useESM: true,
      },
    ],
    '^.+\\.tsx?$': [
      'ts-jest',
      {
        tsconfig: tsConfig,
        useESM: true,
      },
    ],
  },
  transformIgnorePatterns: ['/node_modules/', './jest.setup.js'],
};
