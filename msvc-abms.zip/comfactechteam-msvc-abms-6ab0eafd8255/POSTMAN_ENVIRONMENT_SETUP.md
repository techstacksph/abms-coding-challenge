# Postman Environment Setup for ABMS Stock Control Testing

This guide explains how to set up and use the Postman collection and environments for testing the ABMS Stock Control module in both local and development environments.

## Files Overview

- **`Stock_Control_Testing.postman_collection.json`** - Comprehensive test collection for Stock Control operations
- **`ABMS_Local_Environment.postman_environment.json`** - Local development environment configuration
- **`ABMS_Development_Environment.postman_environment.json`** - Remote development environment configuration

## Environment URLs

### Local Environment
| Service | URL |
|---------|-----|
| **Apollo Gateway (GraphQL)** | http://localhost:3001/graphql |
| **Authorization Service** | http://localhost:8082 |

### Development Environment (AWS)
| Service | URL |
|---------|-----|
| **Apollo Gateway (GraphQL)** | https://m2hwwma6x2.ap-southeast-2.awsapprunner.com/graphql |
| **Authorization Service** | https://zzfwxcznvx.ap-southeast-2.awsapprunner.com |

## Setup Instructions

### 1. Import into Postman

#### Import Collection
1. Open Postman
2. Click **Import** button (top left)
3. Select **File** tab
4. Choose `Stock_Control_Testing.postman_collection.json`
5. Click **Import**

#### Import Environments
1. Click **Environments** in the sidebar (or the environment dropdown)
2. Click **Import**
3. Select **both** environment files:
   - `ABMS_Local_Environment.postman_environment.json` (for local testing)
   - `ABMS_Development_Environment.postman_environment.json` (for AWS development testing)
4. Click **Import**

### 2. Configure Your Credentials

The environment files do not include credentials for security. You need to add your own to each environment you plan to use:

1. Go to **Environments** in Postman
2. Select the environment you want to configure:
   - **ABMS Local Environment** (for local testing)
   - **ABMS Development Environment** (for AWS testing)
3. Find the `credentials` variable
4. Set the **Current Value** to your Base64-encoded credentials

#### How to Encode Credentials

Your credentials should be in the format `username:password`, then Base64 encoded.

**Option 1: Using Online Tool**
- Go to https://www.base64encode.org/
- Enter: `your-email@domain.com:your-password`
- Copy the encoded result

**Option 2: Using Command Line (Mac/Linux)**
```bash
echo -n 'your-email@domain.com:your-password' | base64
```

**Option 3: Using Node.js**
```javascript
Buffer.from('your-email@domain.com:your-password').toString('base64')
```

**Example:**
- Input: `eugene@ayr-dev:Ctodev@123`
- Base64: `ZXVnZW5lQGF5ci1kZXY6Q3RvZGV2QDEyMw==`

### 3. Select the Environment

1. In the top-right corner of Postman, click the environment dropdown
2. Select the environment you want to use:
   - **ABMS Local Environment** - for testing against your local services (localhost)
   - **ABMS Development Environment** - for testing against AWS development environment
3. Verify the environment is active (you should see the name displayed)

**Note:** You can easily switch between environments to test the same operations in different environments without changing the collection.

## Using the Collection

### Test Execution Order

The collection is organized into folders for easy testing:

#### **Setup Folder** (Run these first)
These requests automatically populate all the required IDs:

1. **0. Login - Get Auth Token**
   - Authenticates with the auth service
   - Automatically saves JWT token to `authToken` variable
   - Extracts username from JWT

2. **0b. Get User ID**
   - Retrieves user information from token
   - Automatically saves `userId` for Stock Control creation

3. **1. Get Location ID**
   - Fetches available locations
   - Automatically saves first location to `locationId` variable

4. **2. Get Workflow Status ID**
   - Fetches Stock Control workflow statuses
   - Automatically saves 'Created' status to `statusId` variable

5. **3. Get Item ID**
   - Fetches available items
   - Automatically saves first item to `itemId` variable

6. **4. Get Warehouse IDs**
   - Fetches available warehouses
   - Automatically saves to `sourceWarehouseId` and `destinationWarehouseId` variables

#### **Stock Control Tests Folder**
After running setup, you can execute these tests in any order:

1. **Create Stock Control - Minimal** - Basic creation without relationships
2. **Create Stock Control - With Items** - Creation and query items relationship
3. **Create Stock Control - Full with All Relations** - Query all nullable relationships
4. **Create Stock Control - Transfer Type** - Transfer between warehouses
5. **Create Stock Control - As Template** - Create as reusable template
6. **Get Stock Control by ID** - Retrieve with full relations
7. **List Stock Controls - Paginated** - List with pagination
8. **Create Stock Control Item** - Add item to existing Stock Control
9. **Update Stock Control** - Update existing record
10. **Test All Transaction Types** - Test different transaction types

### Running Tests

#### Option 1: Run Collection with Collection Runner
1. Click on the **Stock Control Testing** collection
2. Click **Run** button
3. Select **ABMS Development Environment**
4. Select which requests to run (or run all)
5. Click **Run Stock Control Testing**

#### Option 2: Run Individual Requests
1. Expand the **Setup** folder
2. Run requests 0, 0b, 1, 2, 3, 4 in order
3. Then run any test from **Stock Control Tests** folder

### Automatic Variable Population

Most variables are automatically populated by the test scripts:

- ✅ `authToken` - Set by login request
- ✅ `username` - Extracted from JWT
- ✅ `userId` - Set by token validation
- ✅ `locationId` - Set by location query
- ✅ `statusId` - Set by status query
- ✅ `itemId` - Set by item query
- ✅ `sourceWarehouseId` - Set by warehouse query
- ✅ `destinationWarehouseId` - Set by warehouse query
- ✅ `stockControlId` - Set after creating Stock Control

Only the `credentials` variable needs to be manually configured.

## Environment Variables Reference

| Variable | Description | Auto-Populated | Required For |
|----------|-------------|----------------|--------------|
| `graphqlUrl` | Apollo Gateway GraphQL endpoint | ✅ Pre-configured | All GraphQL requests |
| `authUrl` | Authorization service endpoint | ✅ Pre-configured | Authentication |
| `credentials` | Base64 encoded username:password | ❌ **Manual setup required** | Login |
| `authToken` | JWT authentication token | ✅ After login | All GraphQL requests |
| `username` | Username from JWT | ✅ After login | Info only |
| `userId` | User UUID | ✅ After token validation | Stock Control creation |
| `locationId` | Location UUID | ✅ After location query | Stock Control creation |
| `statusId` | Workflow Status UUID | ✅ After status query | Stock Control creation |
| `itemId` | Item UUID | ✅ After item query | Stock Control Item creation |
| `stockControlId` | Created Stock Control UUID | ✅ After creation | Update/Query operations |
| `sourceWarehouseId` | Source Warehouse UUID | ✅ After warehouse query | Transfer operations |
| `destinationWarehouseId` | Destination Warehouse UUID | ✅ After warehouse query | Transfer operations |
| `transType` | Transaction type | ✅ Pre-configured | Transaction type testing |

## Testing Different Scenarios

### Test Scenario 1: Minimal Stock Control Creation
```
1. Run Setup folder (requests 0-4)
2. Run "1. Create Stock Control - Minimal"
```
**Expected:** Stock Control created with only required fields, no items/documents/notes

### Test Scenario 2: Full Relationships Test
```
1. Run Setup folder (requests 0-4)
2. Run "3. Create Stock Control - Full with All Relations"
```
**Expected:** All nullable relationships return null or empty arrays without errors

### Test Scenario 3: Transfer Between Warehouses
```
1. Run Setup folder (requests 0-4)
2. Run "4. Create Stock Control - Transfer Type"
```
**Expected:** Stock Control created with source and destination warehouses

### Test Scenario 4: Template Creation
```
1. Run Setup folder (requests 0-4)
2. Run "5. Create Stock Control - As Template"
```
**Expected:** Stock Control created with `isTemplate: true`

### Test Scenario 5: Add Items to Stock Control
```
1. Run Setup folder (requests 0-4)
2. Run "1. Create Stock Control - Minimal"
3. Run "8. Create Stock Control Item"
```
**Expected:** Item added to the created Stock Control

### Test Scenario 6: Update Stock Control
```
1. Run Setup folder (requests 0-4)
2. Run "1. Create Stock Control - Minimal"
3. Run "9. Update Stock Control"
```
**Expected:** Stock Control updated with new note

## Troubleshooting

### Issue: "Authentication failed" or 401 errors

**Solution:**
1. Verify your `credentials` variable is correctly set
2. Ensure credentials are Base64 encoded
3. Check username/password are correct for development environment
4. Re-run "0. Login - Get Auth Token"

### Issue: "Cannot return null for non-nullable field"

**Solution:**
This error should be fixed by ABMS-4525. If you still see it:
1. Verify you're testing on the development branch with the latest changes
2. Check that the fix has been deployed to development environment
3. Ensure you're querying with the correct relationships

### Issue: Variables not auto-populating

**Solution:**
1. Check the **Console** tab in Postman to see script execution logs
2. Ensure test scripts are enabled in Settings > General > Script execution
3. Verify responses are successful (200 status)
4. Re-run setup requests in order

### Issue: "User ID not found" or "Location ID not found"

**Solution:**
1. Run the Setup folder requests in order (0 → 0b → 1 → 2 → 3 → 4)
2. Check Console logs for specific error messages
3. Verify your user has access to locations/items in development environment

### Issue: Stock Control workflow status not found

**Solution:**
1. The Stock Control workflow might not exist in development environment
2. Contact the development team to run migrations
3. Or use a different workflow status ID manually

## Additional Notes

### Security Best Practices
- **Never commit the environment file with real credentials**
- Keep credentials in the "Current Value" column only (not "Initial Value")
- Consider using Postman's secret variables for sensitive data
- Rotate credentials regularly

### Date Format
All date fields use ISO 8601 format with timezone:
```
2025-01-15T00:00:00.000Z
```

### Transaction Types
Available transaction types for `transType` variable:
- `MANUAL_ADD` - Manual addition to stock
- `MANUAL_DEDUCT` - Manual reduction from stock
- `TRANSFER` - Transfer between warehouses
- `STOCK_COUNT` - Physical stock count
- `SPOT_CHECK` - Random spot check

## Support

For issues or questions:
1. Check the [STOCK_CONTROL_TESTING_README.md](./STOCK_CONTROL_TESTING_README.md) for detailed API documentation
2. Review the GraphQL schema at: https://m2hwwma6x2.ap-southeast-2.awsapprunner.com/graphql
3. Contact the development team

---

**Last Updated:** January 2025
**Tested with:** Postman 10.0+
**ABMS Version:** Development (ABMS-4525 branch)
