# CLAUDE.md - ABMS Backend Microservice Guide

## Project Overview

**msvc-abms (msvc-cto-bo)** - Apollo Federated GraphQL Microservice for the ABMS (At Your Request) ecosystem. This service provides the core backend functionality for account and business management.

**Purpose:** Comprehensive backend API for CTO's account management, job scheduling, billing, inventory, and business process automation.

## Important Guidelines

### Repository Information

- **Version Control:** Bitbucket (not GitHub)
- **Repository:** bitbucket.org:comfactechteam/msvc-abms
- **Default Branch:** development

### Git Commit Messages

**IMPORTANT:** Do NOT include Claude Code attribution in commit messages or pull request descriptions.

❌ **WRONG:**
```
Fix email sending

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

✅ **CORRECT:**
```
Fix email sending with custom display names

- Add support for custom sender display names
- Fix SMTP from field format
```

### Pull Request Guidelines

- **Platform:** Bitbucket (use Bitbucket MCP tools when available)
- **Creating PRs:** Use the git push output link or Bitbucket web UI
- **MCP Tools Available:**
  - `mcp__bitbucket__bb_search` - Search repositories and PRs
  - `mcp__bitbucket__bb_ls_repos` - List repositories
  - `mcp__bitbucket__bb_get_pr` - Get PR details
- **Title:** Use Jira ticket format: `ABMS-XXX: Brief description`
- **Description:** Provide clear summary of changes without AI attribution
- **No Claude attribution:** Do not add any mentions of Claude Code, AI assistance, or co-authorship

## Technology Stack

- **Runtime:** Node.js 18.17.1
- **Language:** TypeScript 5.2.2
- **API:** GraphQL (Apollo Server 4.9.3, Type-GraphQL)
- **Federation:** Apollo Federation (@apollo/gateway 2.5.4)
- **Database:** PostgreSQL 13+ (TypeORM 0.3.17)
- **Message Queue:** Apache Pulsar 3.0 (pulsar-client 1.9.0)
- **Queue Management:** BullMQ
- **DI:** TypeDI (dependency injection)
- **Testing:** Jest 29.6.4
- **Linting:** ESLint 8.48.0 + Prettier

## Key Concepts

### 1. Apollo Federation

This service is an **Apollo Federation subgraph**:
- Integrates with `msvc-gw-apollo-abms` (API Gateway)
- Uses `@apollo/subgraph` for federation support
- Provides core business domain schema
- Can extend types from other subgraphs

### 2. TypeGraphQL Architecture

**Type-safe GraphQL** using decorators:
- `@ObjectType()` - Define GraphQL object types
- `@InputType()` - Define input types for mutations
- `@Resolver()` - Define GraphQL resolvers
- `@Query()` / `@Mutation()` - Define operations
- `@Arg()` - Define arguments
- `@Ctx()` - Access context

### 3. TypeORM Database Layer

**ORM for PostgreSQL**:
- Entity models with decorators (`@Entity`, `@Column`, etc.)
- Migration-based schema management
- Query builder for complex queries
- Relationship management (`@OneToMany`, `@ManyToOne`, etc.)

### 4. Service Layer Pattern

**Business logic separation**:
- Resolvers → handle GraphQL operations
- Services → contain business logic
- Models → database entities
- DTOs → data transfer objects

### 5. Permission-Based Authorization

**Fine-grained access control**:
- `@Auth()` decorator on resolvers
- Permission types (e.g., `PermissionType.ACCOUNT_CODE`)
- Permission actions (READ, CREATE, UPDATE, DELETE)
- Org-level data isolation

## Project Structure

```
src/
├── server.ts                # Application entry point
├── environment.ts           # Environment configuration
│
├── resolver/                # GraphQL resolvers (234 files)
│   ├── BaseResolver.ts      # Base class for all resolvers
│   ├── AccountResolver.ts   # Example resolver
│   └── ...                  # Domain-specific resolvers
│
├── services/                # Business logic layer (244 files)
│   ├── BaseService.ts       # Base class for all services
│   ├── AccountService.ts    # Example service
│   └── ...                  # Domain-specific services
│
├── schema/                  # GraphQL schema definitions (234 files)
│   ├── BaseSchema.ts        # Base schema types
│   ├── AccountSchema.ts     # Example schema
│   └── ...                  # Domain-specific schemas
│
├── datasource/              # Database layer
│   ├── config/              # TypeORM configuration
│   ├── models/              # TypeORM entity models
│   ├── migrations/          # Database migrations (729 files)
│   └── subscribers/         # TypeORM event subscribers
│
├── model-dictionary/        # Shared type definitions
├── dto/                     # Data transfer objects
├── enums/                   # Enumeration types
├── constants/               # Application constants
├── utils/                   # Utility functions
├── client/                  # External service clients
│   ├── authorization/       # Auth service client
│   └── pulsar/              # Message queue client
│
├── queue/                   # Background job processing
│   └── workers/             # Queue workers
│
├── controller/              # REST controllers (if any)
├── errors/                  # Custom error classes
├── docs/                    # Documentation
└── test/                    # Test files
    ├── services/            # Service tests
    └── utils/               # Test utilities
```

## Development Commands

### Core Development
```bash
yarn dev                     # Start development server (nodemon)
yarn build                   # Build TypeScript to dist/
yarn start                   # Run production build
```

### Docker Development
```bash
# Full setup (infrastructure + microservice)
yarn docker:dev:full         # Start everything

# Step-by-step
yarn docker:infrastructure   # Start Postgres, Redis, Pulsar
yarn docker:dev              # Start microservice only
yarn docker:dev:down         # Stop microservice
yarn docker:infrastructure:down  # Stop infrastructure

# Individual services
docker-compose -f docker-compose-postgres.yml up -d
docker-compose -f docker-compose-redis.yml up -d
docker-compose -f docker-compose-pulsar.yml up -d
```

### Database Migrations
```bash
# Generate migration from schema changes
name=AddUserRelatedEmployee yarn migration:generate

# Create empty migration template
name=AddCustomLogic yarn migration:create

# Run pending migrations
yarn migration:run

# Revert last migration
yarn migration:revert

# Show migration status
yarn migration:show
```

### Code Quality
```bash
yarn lint                    # Run ESLint + fix issues
yarn test                    # Run Jest tests
yarn test:coverage           # Generate coverage report
```

## Creating a New GraphQL Endpoint

### Step-by-Step Guide

When creating a new endpoint (e.g., adding a "RelatedEmployee" field to User), follow this pattern:

---

### 1️⃣ **Database Migration**

Create a migration to modify the database schema.

**Command:**
```bash
name=AddUserRelatedEmployee yarn migration:generate
```

**Example:** `src/datasource/migrations/1234567890123-AddUserRelatedEmployee.ts`
```typescript
import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddUserRelatedEmployee1234567890123 implements MigrationInterface {
  name = 'AddUserRelatedEmployee1234567890123';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ADD "relatedEmployeeId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD CONSTRAINT "FK_user_related_employee" FOREIGN KEY ("relatedEmployeeId") REFERENCES "employees"("id") ON DELETE SET NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" DROP CONSTRAINT "FK_user_related_employee"`
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "relatedEmployeeId"`
    );
  }
}
```

**Run migration:**
```bash
yarn migration:run
```

---

### 2️⃣ **TypeORM Model**

Update the entity model to reflect the database changes.

**File:** `src/datasource/models/UserModel.ts`
```typescript
import { Entity, Column, ManyToOne, JoinColumn } from 'typeorm';
import { BaseModel } from './BaseModel';
import { EmployeeModel } from './EmployeeModel';

@Entity('users')
export class UserModel extends BaseModel {
  @Column()
  username: string;

  @Column()
  email: string;

  // Add new relationship
  @Column({ type: 'uuid', nullable: true })
  relatedEmployeeId?: string;

  @ManyToOne(() => EmployeeModel, { nullable: true })
  @JoinColumn({ name: 'relatedEmployeeId' })
  relatedEmployee?: EmployeeModel;
}
```

**Key Patterns:**
- All models extend `BaseModel` (provides id, createdAt, updatedAt, etc.)
- Use `@Entity('table_name')` to map to database table
- Use `@Column()` for regular fields
- Use `@ManyToOne()`, `@OneToMany()`, `@ManyToMany()` for relationships
- Use `@JoinColumn()` to specify foreign key column name

---

### 3️⃣ **GraphQL Schema**

Define the GraphQL types for the new field.

**File:** `src/schema/UserSchema.ts`
```typescript
import { Field, InputType, ObjectType } from 'type-graphql';
import { BaseSchema } from './BaseSchema';
import { EmployeeSchema } from './EmployeeSchema';

@ObjectType()
export class UserSchema extends BaseSchema {
  @Field()
  username: string;

  @Field()
  email: string;

  // Add new field to output type
  @Field(() => String, { nullable: true })
  relatedEmployeeId?: string;

  @Field(() => EmployeeSchema, { nullable: true })
  relatedEmployee?: EmployeeSchema;
}

@InputType()
export class UserInputSchema {
  @Field()
  username: string;

  @Field()
  email: string;

  // Add new field to input type
  @Field(() => String, { nullable: true })
  relatedEmployeeId?: string;
}

@InputType()
export class UpdateUserInputSchema {
  @Field({ nullable: true })
  username?: string;

  @Field({ nullable: true })
  email?: string;

  @Field(() => String, { nullable: true })
  relatedEmployeeId?: string;
}
```

**Key Patterns:**
- `@ObjectType()` for query/mutation return types
- `@InputType()` for mutation input arguments
- `@Field()` decorator for each field
- Use `() => Type` for complex types and relationships
- Mark optional fields with `{ nullable: true }`

---

### 4️⃣ **Service Layer**

Add business logic to the service.

**File:** `src/services/UserService.ts`
```typescript
import { Service } from 'typedi';
import { UserModel } from '../datasource/models/UserModel';
import { EmployeeModel } from '../datasource/models/EmployeeModel';
import { BaseService } from './BaseService';

@Service()
export class UserService extends BaseService<UserModel> {
  constructor() {
    super(UserModel);
  }

  // Add custom method if needed
  async findUserWithRelatedEmployee(userId: string): Promise<UserModel | null> {
    return this.repository.findOne({
      where: { id: userId },
      relations: ['relatedEmployee'], // Load relationship
    });
  }

  // Business logic for bidirectional sync
  async updateRelatedEmployee(
    userId: string,
    relatedEmployeeId: string | null
  ): Promise<UserModel> {
    const user = await this.repository.findOne({ where: { id: userId } });
    if (!user) {
      throw new Error('User not found');
    }

    // Clear old relationship if exists
    if (user.relatedEmployeeId) {
      const oldEmployee = await this.dataSource
        .getRepository(EmployeeModel)
        .findOne({ where: { id: user.relatedEmployeeId } });

      if (oldEmployee && oldEmployee.relatedUserId === userId) {
        oldEmployee.relatedUserId = null;
        await this.dataSource.getRepository(EmployeeModel).save(oldEmployee);
      }
    }

    // Set new relationship
    user.relatedEmployeeId = relatedEmployeeId;

    // Update bidirectional relationship
    if (relatedEmployeeId) {
      const newEmployee = await this.dataSource
        .getRepository(EmployeeModel)
        .findOne({ where: { id: relatedEmployeeId } });

      if (newEmployee) {
        newEmployee.relatedUserId = userId;
        await this.dataSource.getRepository(EmployeeModel).save(newEmployee);
      }
    }

    return this.repository.save(user);
  }
}
```

**Key Patterns:**
- All services extend `BaseService<Model>`
- Use `@Service()` decorator for dependency injection
- Constructor calls `super(Model)` to initialize base service
- Access repository via `this.repository`
- Use `relations: []` to load related entities
- Keep business logic in services, not resolvers

---

### 5️⃣ **GraphQL Resolver**

Expose the service methods as GraphQL operations.

**File:** `src/resolver/UserResolver.ts`
```typescript
import 'reflect-metadata';
import { Arg, Ctx, Info, Mutation, Query, Resolver } from 'type-graphql';
import { Service } from 'typedi';
import { SchemaPrefix } from '../constants/SchemaConstants';
import { UserSchema, UserInputSchema, UpdateUserInputSchema } from '../schema/UserSchema';
import { UserService } from '../services/UserService';
import { Auth } from '../utils/AuthUtils';
import { IGraphQLContext } from '../utils/GraphqlUtils';
import BaseResolver, {
  PermissionAction,
  PermissionType,
} from './BaseResolver';

@Service()
@Resolver(() => UserSchema)
export default class UserResolver extends BaseResolver {
  readonly MODULE_NAME = 'User';

  constructor(private service: UserService) {
    super();
  }

  @Auth(PermissionType.USER, PermissionAction.READ)
  @Query(() => UserSchema, {
    name: `${SchemaPrefix}findUserById`,
  })
  async findUserById(
    @Ctx() ctx: IGraphQLContext,
    @Info() info: unknown,
    @Arg('id') id: string
  ): Promise<UserSchema | undefined> {
    const dataOptions = this.toDataOptions(ctx);

    // Include relatedEmployee relationship
    dataOptions.findOneOptions.relations = ['relatedEmployee'];

    const result = await this.service.findById(id, dataOptions);
    return result || undefined;
  }

  @Auth(PermissionType.USER, PermissionAction.CREATE)
  @Mutation(() => UserSchema, {
    name: `${SchemaPrefix}createUser`,
  })
  async createUser(
    @Ctx() ctx: IGraphQLContext,
    @Arg('data') data: UserInputSchema
  ): Promise<UserSchema> {
    const dataOptions = this.toDataOptions(ctx);

    const result = await this.service.create(data, dataOptions);

    return result;
  }

  @Auth(PermissionType.USER, PermissionAction.UPDATE)
  @Mutation(() => UserSchema, {
    name: `${SchemaPrefix}updateUser`,
  })
  async updateUser(
    @Ctx() ctx: IGraphQLContext,
    @Arg('id') id: string,
    @Arg('data') data: UpdateUserInputSchema
  ): Promise<UserSchema> {
    const dataOptions = this.toDataOptions(ctx);

    // Use custom service method for bidirectional sync
    if (data.relatedEmployeeId !== undefined) {
      return this.service.updateRelatedEmployee(id, data.relatedEmployeeId);
    }

    const result = await this.service.update(id, data, dataOptions);
    return result;
  }

  @Auth(PermissionType.USER, PermissionAction.DELETE)
  @Mutation(() => Boolean, {
    name: `${SchemaPrefix}deleteUser`,
  })
  async deleteUser(
    @Ctx() ctx: IGraphQLContext,
    @Arg('id') id: string
  ): Promise<boolean> {
    const dataOptions = this.toDataOptions(ctx);
    await this.service.delete(id, dataOptions);
    return true;
  }

  // Paginated list with sorting and search
  @Auth(PermissionType.USER, PermissionAction.READ)
  @Query(() => PaginatedUsers, {
    name: `${SchemaPrefix}users`,
  })
  async users(
    @Ctx() ctx: IGraphQLContext,
    @Arg('pageArg', () => PageArg, { nullable: true }) pageArg?: PageArg,
    @Arg('sortArg', () => [SortArg], { nullable: true }) sortArg?: SortArg[],
    @Arg('searchArg', () => [SearchArg], { nullable: true }) searchArg?: SearchArg[]
  ): Promise<PaginatedUsers> {
    const dataOptions = this.toDataOptions(ctx);

    // Add pagination
    if (pageArg) {
      dataOptions.findManyOptions.skip = pageArg.skip;
      dataOptions.findManyOptions.take = pageArg.take;
    }

    // Add sorting - ALWAYS use BaseResolver method
    if (sortArg) {
      const sorting = this.toSortObject(sortArg);
      dataOptions.findManyOptions.order = sorting;
    }

    // Add search filters
    if (searchArg) {
      const where = toWhereObject(searchArg);
      dataOptions.findManyOptions.where = where;
    }

    // Include relations
    dataOptions.findManyOptions.relations = ['relatedEmployee'];

    const [data, total] = await this.service.findAndCount(dataOptions);

    return {
      data,
      total,
      page: pageArg?.skip || 0,
      pageSize: pageArg?.take || total,
    };
  }
}
```

**Key Patterns:**
- All resolvers extend `BaseResolver`
- Use `@Service()` for dependency injection
- Use `@Resolver(() => Schema)` to define resolver
- Inject service via constructor
- Use `@Auth()` decorator for permissions
- Use `@Query()` for read operations
- Use `@Mutation()` for write operations
- Prefix query/mutation names with `SchemaPrefix` (e.g., `abms`)
- ALWAYS use `this.toDataOptions(ctx)` for org-level data isolation
- ALWAYS use `this.toSortObject(sortArg)` for sorting (from BaseResolver)

---

### 6️⃣ **Testing**

Write tests for the new functionality.

**File:** `src/test/services/UserService.test.ts`
```typescript
import { UserService } from '../../services/UserService';
import { DataSource } from 'typeorm';
import { UserModel } from '../../datasource/models/UserModel';

describe('UserService', () => {
  let service: UserService;
  let dataSource: DataSource;

  beforeAll(async () => {
    // Setup test database connection
    dataSource = await createTestDataSource();
    service = new UserService();
  });

  afterAll(async () => {
    await dataSource.destroy();
  });

  it('should find user with related employee', async () => {
    const user = await service.findUserWithRelatedEmployee('user-id');
    expect(user).toBeDefined();
    expect(user?.relatedEmployee).toBeDefined();
  });

  it('should update related employee with bidirectional sync', async () => {
    const userId = 'test-user-id';
    const employeeId = 'test-employee-id';

    const updatedUser = await service.updateRelatedEmployee(userId, employeeId);

    expect(updatedUser.relatedEmployeeId).toBe(employeeId);
    // Verify bidirectional relationship
    const employee = await dataSource
      .getRepository(EmployeeModel)
      .findOne({ where: { id: employeeId } });
    expect(employee?.relatedUserId).toBe(userId);
  });
});
```

---

## Common Patterns and Best Practices

### 1. Resolver Best Practices

✅ **ALWAYS extend BaseResolver:**
```typescript
@Service()
@Resolver(() => UserSchema)
export default class UserResolver extends BaseResolver {
  readonly MODULE_NAME = 'User';
  constructor(private service: UserService) {
    super();
  }
}
```

✅ **ALWAYS use toDataOptions for org-level isolation:**
```typescript
const dataOptions = this.toDataOptions(ctx);
const result = await this.service.findById(id, dataOptions);
```

✅ **ALWAYS use toSortObject for sorting:**
```typescript
if (sortArg) {
  const sorting = this.toSortObject(sortArg);
  dataOptions.findManyOptions.order = sorting;
}
```

❌ **NEVER implement manual sorting:**
```typescript
// ❌ WRONG - Don't do this
const sorting = {};
for (const sort of sortArg) {
  sorting[sort.field] = sort.direction;
}
```

### 2. Service Best Practices

✅ **Extend BaseService:**
```typescript
@Service()
export class UserService extends BaseService<UserModel> {
  constructor() {
    super(UserModel);
  }
}
```

✅ **Use repository for database operations:**
```typescript
// Good - uses inherited repository
const user = await this.repository.findOne({ where: { id } });
```

✅ **Load relationships explicitly:**
```typescript
const user = await this.repository.findOne({
  where: { id },
  relations: ['relatedEmployee', 'department'],
});
```

### 3. Migration Best Practices

✅ **Always provide `down` method:**
```typescript
public async down(queryRunner: QueryRunner): Promise<void> {
  // Reverse all changes from `up` method
  await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "relatedEmployeeId"`);
}
```

✅ **Use descriptive names:**
```typescript
// Good
name=AddUserRelatedEmployee yarn migration:generate

// Bad
name=migration yarn migration:generate
```

✅ **Test migrations:**
```bash
yarn migration:run    # Apply
yarn migration:revert # Rollback
yarn migration:run    # Re-apply to verify
```

### 4. Schema Best Practices

✅ **Use separate Input and Output types:**
```typescript
@ObjectType()  // For query results
export class UserSchema { }

@InputType()   // For mutation inputs
export class UserInputSchema { }
```

✅ **Mark optional fields properly:**
```typescript
@Field(() => String, { nullable: true })
relatedEmployeeId?: string;
```

✅ **Use type functions for relationships:**
```typescript
@Field(() => EmployeeSchema, { nullable: true })
relatedEmployee?: EmployeeSchema;
```

## Environment Variables

### Required
```bash
# Server
PORT=8083
NODE_ENV=local
APP_HOST_NAME=localhost:8083/

# Database
DATABASE_HOSTNAME=localhost
DATABASE_NAME=CTO_BackOffice
DATABASE_PORT=5432
DATABASE_USERNAME=root
DATABASE_PASSWORD=root

# GraphQL
TENANT_PREFIX=abms

# Services
AUTH_API_URL=http://localhost:8082
SCHEDULER_URL=http://localhost:8082
MFE_ROOT_URL=http://localhost:3005

# Logging
LOG_LEVEL=info
SHOW_SQL=false

# System
SYSTEM_ID=msvc-cto-bo
```

### Optional
```bash
# Redis (for caching)
REDIS_HOST=localhost
REDIS_PORT=6379

# Pulsar (for messaging)
PULSAR_SERVICE_URL=pulsar://localhost:6650
```

## Testing

### Running Tests
```bash
# All tests
yarn test

# Specific test file
yarn test src/test/services/UserService.test.ts

# With coverage
yarn test:coverage

# Watch mode
yarn test --watch
```

### Test Structure
```
src/test/
├── services/           # Service unit tests
│   ├── UserService.test.ts
│   └── ...
├── utils/              # Utility function tests
├── manual/             # Manual test scripts
└── server-test-data/   # Test fixtures
```

## Troubleshooting

### Common Issues

**1. Migration fails:**
```bash
# Check migration status
yarn migration:show

# Revert and try again
yarn migration:revert
yarn migration:run
```

**2. TypeORM sync issues:**
```bash
# NEVER use synchronize: true in production
# Always use migrations for schema changes
```

**3. GraphQL schema conflicts:**
```bash
# Check for duplicate type definitions
# Ensure all @ObjectType names are unique
```

**4. Permission errors:**
```bash
# Verify @Auth decorator is present
# Check permission type and action match database
```

**5. Docker development issues:**
```bash
# Restart everything
yarn docker:dev:down
yarn docker:infrastructure:down
yarn docker:dev:full
```

## API Documentation

### GraphQL Playground

**Local:** http://localhost:8083/graphql

### Sample Queries

**Find user by ID:**
```graphql
query {
  abmsFindUserById(id: "user-uuid") {
    id
    username
    email
    relatedEmployeeId
    relatedEmployee {
      id
      fullName
    }
  }
}
```

**Create user:**
```graphql
mutation {
  abmsCreateUser(data: {
    username: "john.doe"
    email: "john@example.com"
    relatedEmployeeId: "employee-uuid"
  }) {
    id
    username
    email
  }
}
```

**Update user:**
```graphql
mutation {
  abmsUpdateUser(
    id: "user-uuid"
    data: {
      relatedEmployeeId: "new-employee-uuid"
    }
  ) {
    id
    relatedEmployeeId
  }
}
```

**List users with pagination and sorting:**
```graphql
query {
  abmsUsers(
    pageArg: { skip: 0, take: 10 }
    sortArg: [
      { field: "username", direction: "ASC" }
    ]
    searchArg: [
      { fieldName: "email", searchValue: "@example.com", comparator: "LIKE" }
    ]
  ) {
    data {
      id
      username
      email
      relatedEmployee {
        fullName
      }
    }
    total
    page
    pageSize
  }
}
```

## Best Practices Summary

### Development Workflow
1. Create database migration
2. Update TypeORM model
3. Update GraphQL schema
4. Implement service logic
5. Implement resolver
6. Write tests
7. Run tests and linting
8. Create PR

### Code Quality
- **TypeScript:** Strict mode, no `any` types
- **Linting:** Run `yarn lint` before committing
- **Testing:** Maintain test coverage above 70%
- **Documentation:** Document complex business logic

### Performance
- **Use relations wisely:** Only load what you need
- **Pagination:** Always implement for list queries
- **Indexing:** Add database indexes for frequently queried fields
- **Caching:** Consider Redis for expensive queries

### Security
- **Authentication:** All resolvers must have `@Auth()` decorator
- **Data isolation:** Always use `this.toDataOptions(ctx)`
- **Input validation:** Use TypeGraphQL validation decorators
- **SQL injection:** TypeORM parameterizes queries automatically

## Additional Resources

- **TypeGraphQL Docs:** https://typegraphql.com/
- **TypeORM Docs:** https://typeorm.io/
- **Apollo Federation:** https://www.apollographql.com/docs/federation/
- **Project Docs:** `/docs` folder
- **Postman Collections:** `/postman` folder

---

**Last Updated:** January 2025
**Status:** ✅ Production Ready
**Maintainer:** CTO Development Team
