# msvc-cto-bo

Version: 1.0.0.0

This project contains the source code for an Apollo federated GraphQL microservice. Its purpose is to support CTO's ecosystem of microservices.

## Installation

Node.js v18.17.1 is required to run this project.

**Node** : v18.17.1

 **NPM** : 9.6.7

 **Yarn** : 1.22.19

* Yarn will be used for executing command in package.json such as `yarn test`, `yarn dev`, `yarn build`, it will also be used or the installation of packages `yarn install`.

 **TypeScript** : 5.2.2

 **Jest** : 29.6.4

 **eslint** : 8.48.0

 **Apollo Server** : 4.9.3

 **Apollo Gateway** : 2.5.4

**Pulsar Clien**t: 1.9.0

**TypeORM:** ^0.3.17

### Fundamental tooling

1. **Language:** TypeScript
2. **Linter:** eslint
3. **Formatter:** Prettier
4. **Testing:** Jest
5. TypeORM: version 0.3.17 [see docs](https://www.npmjs.com/package/typeorm/v/0.2.45)

## Docker Development Setup (Hot Reload)

For local development with automatic code reloading, use the development Docker setup:

### Prerequisites
- Docker and Docker Compose installed
- The `local_bridge` network is automatically created by the infrastructure script
- No manual setup required - the scripts handle everything!

### Running Development Environment

#### Quick Start (Everything at once):
```bash
# Start all infrastructure services + development container
yarn docker:dev:full
# or
npm run docker:dev:full
```

#### Step-by-step approach:
```bash
# 1. Start infrastructure services (PostgreSQL, Redis, Pulsar)
yarn docker:infrastructure

# 2. Start development container with hot reload
yarn docker:dev

# Stop development container
yarn docker:dev:down

# Stop all infrastructure services
yarn docker:infrastructure:down
```

#### Available Scripts:
- `yarn docker:dev:full` - Start everything (infrastructure + dev container)
- `yarn docker:dev` - Start only the microservice (assumes infrastructure running)
- `yarn docker:dev:down` - Stop the microservice
- `yarn docker:dev:restart` - Restart the microservice
- `yarn docker:infrastructure` - Start PostgreSQL, Redis, Pulsar services
- `yarn docker:infrastructure:down` - Stop all infrastructure services

### Development Features
- **Hot Reload**: Code changes in `src/` folder automatically restart the server
- **Separate Database**: Uses `DOCKER_MSVC_ABMS` database (isolated from production)
- **Auto Database Creation**: Creates the database automatically if it doesn't exist
- **Network Integration**: Maintains connectivity with other microservices on `local_bridge`
- **Volume Mounts**: Source code changes reflect immediately without rebuilding image
- **Infrastructure Management**: Automatically starts PostgreSQL, Redis, and Pulsar services
- **Web UIs Available**:
  - Redis Commander: http://localhost:8888
  - Pulsar Express: http://localhost:3000
  - Your API: http://localhost:8083

### Development vs Production
- **Development**: `docker-compose.dev.yml` - Uses `yarn dev` with nodemon for hot reloading
- **Production**: `docker-compose.yml` - Uses `yarn start` with built code

### Environment Variables Configuration
The development setup includes all necessary environment variables:
- `TENANT_PREFIX`: Set to `abms` for GraphQL schema prefixing
- `MFE_ROOT_URL`: Points to frontend at `http://localhost:3005`
- `AUTH_API_URL`: Authorization service at `http://msvc-authorization:8082`
- `SCHEDULER_URL`: Scheduler service at `http://msvc-scheduler-abms:8083`
- Database, Pulsar, and other service connections

### Troubleshooting & Updates
If you add new environment variables to `src/environment.ts`:
1. Add the corresponding environment variable to `docker-compose.dev.yml`
2. Restart the development container: `docker-compose -f docker-compose.dev.yml down && docker-compose -f docker-compose.dev.yml up`

If you modify dependencies in `package.json`:
1. Rebuild the development image: `docker-compose -f docker-compose.dev.yml up --build`

## Non-Docker Development (Local Setup)

If you prefer to run without Docker, you'll need to:

### .env Configuration
Create a `.env` file in the root folder with these variables:

```bash
APP_HOST_NAME=localhost:8083/
DATABASE_HOSTNAME=localhost
DATABASE_NAME=CTO_BackOffice
DATABASE_PASSWORD=root
DATABASE_PORT=5432
DATABASE_USERNAME=root
LOG_LEVEL=info
NODE_ENV=local
PORT=8083
SHOW_SQL=false
SYSTEM_ID=msvc-cto-bo
TENANT_PREFIX=abms
AUTH_API_URL=http://localhost:8082
SCHEDULER_URL=http://localhost:8082
MFE_ROOT_URL=http://localhost:3005
```

### Local Development Commands
```bash
# Install dependencies
yarn install

# Run in development mode with nodemon
yarn dev

# Build and run in production mode
yarn build
yarn start
```

Please ensure that you have linted and run all tests against your code prior to submitting a merge request.

* `yarn lint`
* `yarn test`

### Docker build

The Dockerfile also requires Nexus credentials. To build the image locally, please ensure that you export environment variables with your Nexus credentials, and then pass them to the build command via a build arg, like so:

#### For all platform

* `docker build -t msvc-cto-bo:latest . --progress=plain`

#### For amd64 platform

* `docker build -t msvc-cto-bo:latest . --progress=plain --platform linux/amd64`

### Database Migration [see docs](https://typeorm.io/migrations)

* Generate migration script from existing database `name={migration-filename} yarn migration:generate`
* Create migration script template `name={migration-filename} yarn migration:create`
* Run migration script `yarn migration:run`
* Revert last migrated script `yarn migration:revert`
* Show migrated script `yarn migration:show`

## API Testing

### Postman Collections

Postman collections for testing the GraphQL API endpoints are located in the `postman/` folder. These collections provide comprehensive test coverage for various API functionalities.

* **AccountCodeResolver_Sorting_Tests**: Tests for AccountCodeResolver sorting functionality including single field, multi-field, pagination, search, and CSV export with sorting.
* **ABMS_Environment**: Environment file with pre-configured variables for easy setup (baseUrl, ABMS_PORT, authHost, authPort).

For detailed information about each collection and setup instructions, see the [Postman Collections README](postman/README.md).

## Docker compose files included in the code base

Make sure to create docker network local bridge by executing `docker network create local_bridge --driver bridge`

* **POSTGRES**: To run execute `docker compose -f docker-compose-postgres.yml up -d`, to stop `docker compose -f docker-compose-postgres.yml down`
* **REDIS**: To run execute `docker compose -f docker-compose-redis.yml up -d`, to stop `docker compose -f docker-compose-redis.yml down`
* **PULSAR**: To run execute `docker compose -f docker-compose-pulsar.yml up -d`, to stop `docker compose -f docker-compose-pulsar.yml down`
* **MSVC-MICROSERVICE**: To run execute `docker compose up -d`, to stop `docker compose down` since the default `docker-compose.yml` contains the microservice config file
