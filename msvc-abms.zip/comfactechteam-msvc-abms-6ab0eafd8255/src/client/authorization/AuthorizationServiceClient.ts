import axios, { AxiosError } from 'axios';
import { GraphQLError as ApolloError } from 'graphql';
import { Service } from 'typedi';

import { ApiErrorResponseDto } from '../../dto/ApiErrorResponseDto';
import { DataOptionsDto } from '../../dto/DataOptionsDto';
import { RegisterUserDto, UpdateUserDto } from '../../dto/RegisterUserDto';
import { UpdatePasswordDto } from '../../dto/UpdatePasswordDto';
import environment from '../../environment';
import { logger } from '../../utils/LoggerUtils';

export class AuthorizationClientError extends ApolloError {
  constructor(message: string, code = 'AUTHORIZATION_CLIENT_ERROR') {
    super(message, { extensions: { code: 'INSUFFICIENT_PERMISSIONS_ERROR' } });
  }

  public name = 'AuthorizationClientError';
}

@Service()
export class AuthorizationServiceClient {
  private baseUrl = environment.AUTH_API_URL;

  async changePassword(
    dataOptions: DataOptionsDto,
    changePasswordInfo: UpdatePasswordDto
  ): Promise<boolean> {
    try {
      const data: UpdatePasswordDto = changePasswordInfo;
      const response = await axios({
        data,
        headers: {
          Authorization: dataOptions.dataIsolation.orgId,
        },
        method: 'PATCH',
        url: `${this.baseUrl}/v1/auth/user/change-password`,
      });
      if (response) {
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    } catch (error) {
      const err = error as AxiosError;
      if (err.response) {
        const errorResponse = err.response?.data as ApiErrorResponseDto;
        throw new AuthorizationClientError(
          `${errorResponse.message}`,
          errorResponse.errors as string
        );
      } else {
        throw new AuthorizationClientError(
          `Unable to change password - ${err.message}`,
          err.code as string
        );
      }
    }
  }

  async registerUser(
    dataOptions: DataOptionsDto,
    user: RegisterUserDto
  ): Promise<boolean> {
    try {
      const data: RegisterUserDto = user;
      const url = `${this.baseUrl}/v1/auth/user`;

      logger.debug('register_user', {
        params: { data, dataOptions, url },
      });

      logger.error('payload: ' + JSON.stringify(data));
      logger.error('AUTH_API_URL: ' + this.baseUrl);
      logger.error('Full URL: ' + url);

      const response = await axios({
        data,
        headers: {
          Authorization: dataOptions.dataIsolation.orgId,
        },
        method: 'POST',
        url,
      });

      logger.debug('register_user_response', {
        status: response.status,
        statusText: response.statusText,
      });

      if (response) {
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    } catch (error) {
      logger.error(
        'url: ' +
          `${this.baseUrl}/v1/auth/user orgId: ${dataOptions.dataIsolation.orgId}`
      );
      logger.error('register_user_error: ' + error);
      logger.error('register_user_error', {
        error: (error as Error).message,
      });
      const err = error as AxiosError;
      if (err.response) {
        const errorResponse = err.response?.data as ApiErrorResponseDto;
        throw new AuthorizationClientError(
          `${errorResponse.message}`,
          errorResponse.errors as string
        );
      } else {
        throw new AuthorizationClientError(
          `${err.message}`,
          err.code as string
        );
      }
    }
  }

  async updateUser(
    dataOptions: DataOptionsDto,
    user: UpdateUserDto
  ): Promise<boolean> {
    try {
      const data: UpdateUserDto = user;

      logger.debug('update_auth_user', {
        params: { data, dataOptions, url: `${this.baseUrl}/v1/auth/user` },
      });

      const response = await axios({
        data,
        headers: {
          Authorization: dataOptions.dataIsolation.orgId,
        },
        method: 'PATCH',
        url: `${this.baseUrl}/v1/auth/user`,
      });

      logger.debug('update_auth_user_response', {
        status: response.status,
        statusText: response.statusText,
      });

      if (response) {
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    } catch (error) {
      const err = error as AxiosError;
      logger.debug('update_user_err', {
        status: err.status,
        statusText: err.message,
      });
      if (err.response) {
        const errorResponse = err.response?.data as ApiErrorResponseDto;
        throw new AuthorizationClientError(
          `${errorResponse.message}`,
          errorResponse.error_code.toString()
        );
      } else {
        throw new AuthorizationClientError(
          `${err.message}`,
          err.code as string
        );
      }
    }
  }

  /**
   * Admin-initiated password reset (no old password required)
   * This method generates a reset token and immediately uses it to set the new password
   */
  async adminSetPassword(
    dataOptions: DataOptionsDto,
    resetInfo: { userName: string; email: string; newPassword: string }
  ): Promise<boolean> {
    try {
      // Step 1: Generate reset token
      const tokenResponse = await axios({
        data: {
          email: resetInfo.email,
          loginName: resetInfo.userName,
          host: environment.MAIN_APP_HOST_NAME || 'localhost',
        },
        headers: {
          Authorization: dataOptions.dataIsolation.orgId,
        },
        method: 'POST',
        url: `${this.baseUrl}/v1/auth/user/generate-token`,
      });

      logger.debug('admin_set_password_token_generated', {
        status: tokenResponse.status,
      });

      const token = tokenResponse.data?.token;
      if (!token) {
        throw new AuthorizationClientError(
          'Failed to generate password reset token',
          'TOKEN_GENERATION_FAILED'
        );
      }

      // Step 2: Use token to set new password
      const passwordResponse = await axios({
        data: {
          token,
          newPassword: resetInfo.newPassword,
        },
        headers: {
          Authorization: dataOptions.dataIsolation.orgId,
        },
        method: 'PATCH',
        url: `${this.baseUrl}/v1/auth/user/change-password-token`,
      });

      logger.debug('admin_set_password_success', {
        status: passwordResponse.status,
      });

      return Promise.resolve(true);
    } catch (error) {
      const err = error as AxiosError;
      logger.error('admin_set_password_error', {
        status: err.status,
        message: err.message,
      });
      if (err.response) {
        const errorResponse = err.response?.data as ApiErrorResponseDto;
        throw new AuthorizationClientError(
          `${errorResponse.message || 'Failed to reset password'}`,
          errorResponse.error_code?.toString() || 'PASSWORD_RESET_FAILED'
        );
      } else {
        throw new AuthorizationClientError(
          `${err.message}`,
          err.code as string
        );
      }
    }
  }
}
