import 'reflect-metadata';

import { Client } from 'pulsar-client';
import { Container } from 'typeorm-typedi-extensions';

import { PulsarTopics } from '../../../enums/PulsarTopics';
import environment from '../../../environment';
import { OrganizationService } from '../../../services/OrganizationService';
import { PulsarConsumerService } from '../../../services/PulsarConsumerService';
import { logger } from '../../../utils/LoggerUtils';

export class SampleSubscriberClient {
  public readonly TOPIC: string;
  public readonly SUBSCRIPTION: string;
  public readonly pulsarClient: Client;
  private organizationService: OrganizationService;
  private pulsarConsumerService: PulsarConsumerService;

  constructor(client: Client) {
    this.TOPIC =
      environment.PULSAR_TENANT && environment.PULSAR_NAMESPACE
        ? `persistent://${environment.PULSAR_TENANT}/${environment.PULSAR_NAMESPACE}/${PulsarTopics.BACK_OFFICE}`
        : PulsarTopics.BACK_OFFICE;
    this.SUBSCRIPTION = 'default-subscription';
    this.pulsarClient = client;
    this.organizationService = Container.get(OrganizationService);
    this.pulsarConsumerService = Container.get(PulsarConsumerService);
  }

  async listen(): Promise<void> {
    logger.info('sample_subscriber_started_listening');

    await this.pulsarClient.subscribe({
      ackTimeoutMs: 10000,
      listener: async (msg, msgConsumer) => {
        const data = JSON.parse(msg.getData().toString());
        logger.info('pulsar_subscriber', {
          data: data,
          message_id: msg.getMessageId().toString(),
          topic: this.TOPIC,
        });
        try {
          await this.pulsarConsumerService.processMessage(data);
          msgConsumer.acknowledge(msg);
        } catch (error) {
          logger.error('pulsar_subscriber_error', {
            data: data,
            error: (error as Error).message,
            message_id: msg.getMessageId().toString(),
            topic: this.TOPIC,
          });
        }
      },
      subscription: this.SUBSCRIPTION,
      subscriptionType: 'Shared',
      topic: this.TOPIC,
    });
  }
}
