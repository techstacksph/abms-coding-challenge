import 'reflect-metadata';

import * as Pulsar from 'pulsar-client';
import { Service } from 'typedi';
import { IsNull } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';

import { MailerTransportOptionDto, smtpType } from '../../../dto/MailerDto';
import { PulsarMessageDto } from '../../../dto/PulsarMessageDto';
import { CompanySettingsEmailSettings } from '../../../enums/CompanySettingEnum';
import { PulsarTopics } from '../../../enums/PulsarTopics';
import environment from '../../../environment';
import { CompanySettingService } from '../../../services/CompanySettingService';
import { TestIds } from '../../../test/SampleData';
import { logger } from '../../../utils/LoggerUtils';

@Service()
export class PulsarProducerClient {
  private client: Pulsar.Client | null = null;
  private producers: Map<string, Pulsar.Producer> = new Map();
  private isInitialized = false;
  private initializationPromise: Promise<void> | null = null;

  constructor() {
    // Initialize lazily when first message is sent
  }

  private buildPulsarConfig(): Pulsar.ClientConfig {
    const config: Pulsar.ClientConfig = {
      serviceUrl: environment.PULSAR_SERVICE_URL,
      operationTimeoutSeconds: 60,
    };

    if (environment.PULSAR_AUTH_TOKEN) {
      config.authentication = {
        method: 'token',
        token: environment.PULSAR_AUTH_TOKEN,
      };
    }

    if (environment.PULSAR_TLS_ENABLED) {
      if (environment.PULSAR_TLS_TRUST_CERT_PATH) {
        config.tlsTrustCertsFilePath = environment.PULSAR_TLS_TRUST_CERT_PATH;
      }
      config.tlsValidateHostname = true;
      config.tlsAllowInsecureConnection = false;
    }

    return config;
  }

  private async initialize(): Promise<void> {
    if (this.isInitialized) return;

    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = (async () => {
      try {
        const config = this.buildPulsarConfig();
        this.client = new Pulsar.Client(config);
        this.isInitialized = true;
        logger.info('Pulsar client initialized successfully');
      } catch (error) {
        logger.error('Failed to initialize Pulsar client', { error });
        throw error;
      }
    })();

    return this.initializationPromise;
  }

  private async getProducer(topic: PulsarTopics): Promise<Pulsar.Producer> {
    const topicName =
      environment.PULSAR_TENANT && environment.PULSAR_NAMESPACE
        ? `persistent://${environment.PULSAR_TENANT}/${environment.PULSAR_NAMESPACE}/${topic}`
        : topic;

    if (this.producers.has(topicName)) {
      return this.producers.get(topicName)!;
    }

    await this.initialize();

    if (!this.client) {
      throw new Error('Pulsar client not initialized');
    }

    const producer = await this.client.createProducer({
      topic: topicName,
    });

    this.producers.set(topicName, producer);
    logger.debug('Created new producer for topic', { topic: topicName });

    return producer;
  }

  async produce(
    topic: PulsarTopics,
    message: PulsarMessageDto
  ): Promise<string | null> {
    try {
      const producer = await this.getProducer(topic);

      // GET MAILER CREDENTIALS FROM COMPANY SETTINGS
      if (
        topic == PulsarTopics.COMMUNICATION_MEDIA &&
        message.subAction == 'email'
      ) {
        if (!message.data.mailerCredentialOption) {
          const mailerCredentialOption = await this.getCompanySettings();
          if (mailerCredentialOption?.mailerCredentialOption) {
            // SET MAILER CREDENTIAL OPTIONS
            Object.assign(message.data, {
              mailerCredentialOption:
                mailerCredentialOption?.mailerCredentialOption,
              replyTo: mailerCredentialOption?.autoReply,
              sender: mailerCredentialOption?.mailerCredentialOption?.username,
            });
          }
        }
      }

      const messageResult = await producer.send({
        data: Buffer.from(JSON.stringify(message)),
      });

      logger.info('pulsar_producer', {
        data: message,
        message_id: messageResult.toString(),
        topic: topic,
      });

      return messageResult.toString();
    } catch (error) {
      logger.error('error', { error });
      return null;
    }
  }

  // Fire-and-forget method for non-critical messages
  produceAsync(topic: PulsarTopics, message: PulsarMessageDto): void {
    // Don't await - fire and forget
    this.produce(topic, message)
      .then((messageId) => {
        if (messageId) {
          logger.debug('Message sent asynchronously', {
            messageId,
            topic,
            objectName: message.objectName,
          });
        }
      })
      .catch((error) => {
        logger.warn('Async message send failed', {
          error: error instanceof Error ? error.message : 'Unknown error',
          topic,
          objectName: message.objectName,
        });
      });
  }

  async getCompanySettings(): Promise<{
    autoReply: string;
    mailerCredentialOption: MailerTransportOptionDto;
  } | null> {
    const mailerCredentialOption = {};
    const response = {} as {
      autoReply: string;
      mailerCredentialOption: MailerTransportOptionDto;
    };
    try {
      const companySettingService: CompanySettingService = Container.get(
        CompanySettingService
      );
      const companySettings = await companySettingService
        .getRepository()
        .findOne({
          where: {
            deletedAt: IsNull(),
            orgId: TestIds.ORGANIZATION_ID,
          },
        });

      if (companySettings) {
        const isOutlook =
          companySettings?.emailSettings ==
          CompanySettingsEmailSettings.MICROSOFT_OUTLOOK;

        Object.assign(mailerCredentialOption, {
          customDisplayName: companySettings?.customDisplayName,
          host: companySettings?.mailHost,
          m365: isOutlook
            ? {
                clientId: companySettings?.clientId,
                clientSecret: companySettings?.clientSecret,
                tenantId: companySettings?.tenantId,
              }
            : undefined,
          mailSender: companySettings?.mailSender,
          password: companySettings?.appPassword,
          port: Number(companySettings?.mailPort),
          smtpType: isOutlook ? smtpType.M365 : smtpType.OTHERS,
          username: companySettings?.mailerAccount,
        });

        Object.assign(response, {
          autoReply: companySettings?.mailerAccount,
          mailerCredentialOption,
        });
      }

      return response;
    } catch (error) {
      logger.error('get_company_settings_error', { error });
      throw error;
    }
  }

  async close(): Promise<void> {
    try {
      // Close all producers
      const closePromises = Array.from(this.producers.values()).map(
        (producer) =>
          producer
            .close()
            .catch((err) =>
              logger.warn('Error closing producer', { error: err })
            )
      );
      await Promise.all(closePromises);
      this.producers.clear();

      // Close client
      if (this.client) {
        await this.client.close();
        this.client = null;
      }

      this.isInitialized = false;
      this.initializationPromise = null;
      logger.info('Pulsar client closed successfully');
    } catch (error) {
      logger.error('Error during Pulsar client shutdown', { error });
    }
  }
}
