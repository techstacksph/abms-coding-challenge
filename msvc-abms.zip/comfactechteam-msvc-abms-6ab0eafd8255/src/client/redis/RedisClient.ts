import 'reflect-metadata';

import * as redis from 'redis';
import { Service } from 'typedi';

import environment from '../../environment';
import { logger } from '../../utils/LoggerUtils';

@Service()
export class RedisClient {
  private readonly EXPIRATION_DEFAULT = 86400; // 24 hours
  private readonly REDIS_PREFIX_KEY = environment.REDIS_PREFIX || 'abms';

  async setValue(
    key: string,
    val: string,
    exSec?: number
  ): Promise<string | null> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });

    try {
      await redisClient.connect();
      const expireSec = exSec ?? this.EXPIRATION_DEFAULT;
      const result = await redisClient.set(
        `${this.REDIS_PREFIX_KEY}:${key}`,
        val,
        { EX: expireSec }
      );
      await redisClient.quit();
      return result;
    } catch (error) {
      await redisClient.quit();
      logger.error('redis_set_error', { key, error });
      throw error;
    }
  }

  async getValue(key: string): Promise<string | null> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });

    try {
      await redisClient.connect();
      const result = await redisClient.get(`${this.REDIS_PREFIX_KEY}:${key}`);
      await redisClient.quit();
      return result;
    } catch (error) {
      await redisClient.quit();
      logger.error('redis_get_error', { key, error });
      throw error;
    }
  }

  async delValue(key: string): Promise<boolean> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });

    try {
      await redisClient.connect();
      const result = await redisClient.del(`${this.REDIS_PREFIX_KEY}:${key}`);
      await redisClient.quit();
      return result > 0;
    } catch (error) {
      await redisClient.quit();
      logger.error('redis_delete_error', { key, error });
      throw error;
    }
  }

  async getTTL(key: string): Promise<number> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });

    try {
      await redisClient.connect();
      const result = await redisClient.ttl(`${this.REDIS_PREFIX_KEY}:${key}`);
      await redisClient.quit();
      return result;
    } catch (error) {
      await redisClient.quit();
      logger.error('redis_get_ttl_error', { key, error });
      throw error;
    }
  }
}
