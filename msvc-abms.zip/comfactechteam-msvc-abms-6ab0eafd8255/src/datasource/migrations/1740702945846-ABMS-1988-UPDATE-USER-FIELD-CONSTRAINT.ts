import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1988UPDATEUSERFIELDCONSTRAINT1740702945846
  implements MigrationInterface
{
  name = 'ABMS1988UPDATEUSERFIELDCONSTRAINT1740702945846';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "users" SET "groupId" = '${TestIds.DEFAULT_GROUP_ID}' WHERE "groupId" IS NULL`
    );
    await queryRunner.query(
      `UPDATE "users" SET "roleId" = '${TestIds.ADMIN_USER_ROLE_ID}' WHERE "roleId" IS NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "groupId" SET NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "roleId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "roleId" DROP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "groupId" DROP NOT NULL`
    );
  }
}
