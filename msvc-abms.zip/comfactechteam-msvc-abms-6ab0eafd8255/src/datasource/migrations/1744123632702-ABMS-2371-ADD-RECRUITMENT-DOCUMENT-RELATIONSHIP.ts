import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2371ADDRECRUITMENTDOCUMENTRELATIONSHIP1744123632702
  implements MigrationInterface
{
  name = 'ABMS2371ADDRECRUITMENTDOCUMENTRELATIONSHIP1744123632702';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documents" ADD "recruitmentId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "recruitmentId"`
    );
  }
}
