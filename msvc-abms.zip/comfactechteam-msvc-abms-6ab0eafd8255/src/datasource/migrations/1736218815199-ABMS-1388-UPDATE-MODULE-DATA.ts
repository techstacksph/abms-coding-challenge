import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1388UPDATEMODULEDATA1736218815199
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code IN (${MODULES.join(
        ','
      )})`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code IN (${MODULES.join(
        ','
      )})`
    );
  }
}
