import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXDEALSSPECIFICATIONS1741583302021
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Drop the unique constraint on specifications
    await queryRunner.query(`
          DROP INDEX IF EXISTS "UniqueIndexDeal_Specifications_Specifications";
        `);

    // Make variantId nullable
    await queryRunner.query(`
          ALTER TABLE "deal_specifications" 
          ALTER COLUMN "variantId" DROP NOT NULL;
        `);

    // Change specifications column type from citext to text
    await queryRunner.query(`
          ALTER TABLE "deal_specifications"
          ALTER COLUMN "specifications" TYPE text;
        `);

    await queryRunner.query(`
          ALTER TABLE "deal_order_details" 
          DROP COLUMN "itemId";
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Revert specifications column type back to citext
    await queryRunner.query(`
          ALTER TABLE "deal_specifications"
          ALTER COLUMN "specifications" TYPE citext;
        `);

    // Revert variantId to non-nullable
    await queryRunner.query(`
          ALTER TABLE "deal_specifications" 
          ALTER COLUMN "variantId" SET NOT NULL;
        `);

    // Recreate the unique index
    await queryRunner.query(`
          CREATE UNIQUE INDEX "UniqueIndexDeal_Specifications_Specifications" 
          ON "deal_specifications" ("specifications") 
          WHERE "deletedAt" IS NULL;
        `);
  }
}
