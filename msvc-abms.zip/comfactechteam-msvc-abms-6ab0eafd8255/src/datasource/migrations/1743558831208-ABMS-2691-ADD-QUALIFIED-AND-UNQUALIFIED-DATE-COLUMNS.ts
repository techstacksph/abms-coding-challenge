import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2691ADDQUALIFIEDANDUNQUALIFIEDDATECOLUMNS1743558831208
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "leads" ADD "qualifiedDate" date`);
    await queryRunner.query(`ALTER TABLE "leads" ADD "unqualifiedDate" date`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "leads" DROP COLUMN "unqualifiedDate"`
    );
    await queryRunner.query(`ALTER TABLE "leads" DROP COLUMN "qualifiedDate"`);
  }
}
