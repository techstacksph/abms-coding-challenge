import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1649RENAMEITEMVARIANTTYPETABLE1734585671341
  implements MigrationInterface
{
  name = 'ABMS1649RENAMEITEMVARIANTTYPETABLE1734585671341';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemvariantypes" RENAME TO "itemvarianttypes"`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('itemvarianttype', 'Item Variant Type', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'itemvarianttype'`
    );
    await queryRunner.query(
      `ALTER TABLE "itemvarianttypes" RENAME TO "itemvariantypes"`
    );
  }
}
