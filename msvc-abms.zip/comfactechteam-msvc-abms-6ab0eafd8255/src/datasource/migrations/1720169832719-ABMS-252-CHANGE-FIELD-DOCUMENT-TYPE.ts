import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS252CHANGEFIELDDOCUMENTTYPE1720169832719
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttype" ADD "documentTypeName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "documenttype" DROP COLUMN "documentType"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttype" DROP COLUMN "documentTypeName"`
    );
  }
}
