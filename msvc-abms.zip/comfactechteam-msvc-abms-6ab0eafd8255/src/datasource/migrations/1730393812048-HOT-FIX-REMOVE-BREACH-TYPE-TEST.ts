import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXREMOVEBREACHTYPETEST1730393812048
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexBreachTypeTest_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexBreachTypeTest_Code"`
    );
    await queryRunner.query(`DROP TABLE "breachtypestest"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'breachtypetest'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await null;
  }
}
