import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2465ADDRELATIONSHIPTOCOMMLOGS1742789433735
  implements MigrationInterface
{
  name = 'ABMS2465ADDRELATIONSHIPTOCOMMLOGS1742789433735';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "taskId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "smsId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "franchiseeNotificationId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "franchiseeNotificationId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "smsId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "taskId"`
    );
  }
}
