import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2517INVOICEAUTONUMBERROWID1744190125170
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN IF EXISTS "autoNumber"`
    );
    await queryRunner.query(
      `DROP INDEX IF EXISTS "UQ_b34cddc52972c035c9ace828966"`
    );

    await queryRunner.query(
      `ALTER TABLE "invoices" ADD COLUMN "autoNumber" INTEGER`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UQ_b34cddc52972c035c9ace828966" ON "invoices" ("autoNumber")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "UQ_b34cddc52972c035c9ace828966"`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN IF EXISTS "autoNumber"`
    );

    await queryRunner.query(
      `ALTER TABLE "invoices" ADD COLUMN "autoNumber" SERIAL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD CONSTRAINT "UQ_b34cddc52972c035c9ace828966" UNIQUE ("autoNumber")`
    );
  }
}
