import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const MODULE_CODE = 'royaltysheet';
const MODULE_NAME = 'Royalty sheet';

export class INITIALMODULEROYALTYSHEET1744116532311
  implements MigrationInterface
{
  name = 'INITIALMODULEROYALTYSHEET1744116532311';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "royaltysheets" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "locationId" uuid NOT NULL, CONSTRAINT "PK_1c30e3024b677d8c596a6d91253" PRIMARY KEY ("id"))`
    );

    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', '${MODULE_NAME}', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${MODULE_CODE}'`
    );
    await queryRunner.query(`DROP TABLE "royaltysheets"`);
  }
}
