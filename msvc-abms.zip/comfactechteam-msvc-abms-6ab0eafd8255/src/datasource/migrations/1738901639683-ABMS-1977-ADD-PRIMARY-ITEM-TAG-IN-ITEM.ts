import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1977ADDPRIMARYITEMTAGINITEM1738901639683
  implements MigrationInterface
{
  name = 'ABMS1977ADDPRIMARYITEMTAGINITEM1738901639683';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "items" ADD "primaryTagId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "items" DROP COLUMN "primaryTagId"`);
  }
}
