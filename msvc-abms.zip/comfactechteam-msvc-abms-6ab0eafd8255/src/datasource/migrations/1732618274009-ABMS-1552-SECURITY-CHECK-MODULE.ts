import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1552SECURITYCHECKMODULE1732618274009
  implements MigrationInterface
{
  name = 'ABMS1552SECURITYCHECKMODULE1732618274009';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "securitychecks" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "securityCheckId" uuid NOT NULL, "staffId" uuid, "date" TIMESTAMP, "documentFile" character varying, "expirationDate" TIMESTAMP, "accountId" uuid, CONSTRAINT "PK_3f34a69faa5227f03a5c8a55ea4" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('securitycheck', 'Security Check', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'securitycheck'`
    );
    await queryRunner.query(`DROP TABLE "securitychecks"`);
  }
}
