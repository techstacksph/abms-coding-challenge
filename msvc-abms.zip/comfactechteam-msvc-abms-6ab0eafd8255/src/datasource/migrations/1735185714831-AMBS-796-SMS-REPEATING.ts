import { MigrationInterface, QueryRunner } from 'typeorm';

export class AMBS796SMSREPEATING1735185714831 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE "smsrepeating" (
            "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
            "orgId" uuid,
            "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
            "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
            "deletedAt" TIMESTAMP,
            "createdBy" uuid,
            "updatedBy" uuid,
            "deletedBy" uuid,
            "recordLocked" boolean NOT NULL DEFAULT false,
            "lockedBy" uuid,
            "timeLocked" TIMESTAMP NOT NULL DEFAULT now(),
            "updatedByName" character varying,
            "createdByName" character varying,
            "startDate" TIMESTAMP,
            "startTime" TIMESTAMP,
            "finalFrequency" text,
            "endDate" TIMESTAMP,
            "frequency" character varying,
            "freqInt" integer,
            "days" text,
            "date" integer,
            "weekOrder" character varying,
            "dayWeek" character varying,
            "month" character varying,
            "year" character varying,
            CONSTRAINT "PK_4066c0df6a245de57f57dc92aa0" PRIMARY KEY ("id")
        )`);

    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN IF NOT EXISTS "smsRepeatingId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE sms DROP COLUMN IF EXISTS "startDate"`
    );
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "endDate"`);
    await queryRunner.query(
      `ALTER TABLE sms DROP COLUMN IF EXISTS "frequency"`
    );
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "freqInt"`);
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "days"`);
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "date"`);
    await queryRunner.query(
      `ALTER TABLE sms DROP COLUMN IF EXISTS "weekOrder"`
    );
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "dayWeek"`);
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "month"`);
    await queryRunner.query(`ALTER TABLE sms DROP COLUMN IF EXISTS "year"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "smsrepeating"`);

    await queryRunner.query(`ALTER TABLE sms ADD COLUMN "startDate" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE sms ADD COLUMN "endDate" TIMESTAMP`);
    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN "frequency" character varying`
    );
    await queryRunner.query(`ALTER TABLE sms ADD COLUMN "freqInt" integer`);
    await queryRunner.query(`ALTER TABLE sms ADD COLUMN "days" text`);
    await queryRunner.query(`ALTER TABLE sms ADD COLUMN "date" integer`);
    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN "weekOrder" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN "dayWeek" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN "month" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE sms ADD COLUMN "year" character varying`
    );
  }
}
