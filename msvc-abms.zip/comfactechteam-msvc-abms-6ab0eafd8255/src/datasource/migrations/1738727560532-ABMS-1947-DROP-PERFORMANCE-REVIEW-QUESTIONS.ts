import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1947DROPPERFORMANCEREVIEWQUESTIONS1738727560532
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestion_questionnaires" DROP CONSTRAINT "FK_9ae90c691487d91432f69d173ae"`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestion_questionnaires" DROP CONSTRAINT "FK_454944fef5798f12e9f2856b031"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_56f6572e0c0efcf906973dd12e"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_fd412bf18ecff3b5369155d20f"`
    );
    await queryRunner.query(`DROP TABLE "performancereviewquestion_ratings"`);
    await queryRunner.query(
      `DROP INDEX "public"."IDX_f868abdff5a7521a054b5ed4a0"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_f4dab97c2faea67fb5e03f7bd4"`
    );
    await queryRunner.query(`DROP TABLE "performancereviewquestion_questions"`);
    await queryRunner.query(
      `DROP INDEX "public"."IDX_9ae90c691487d91432f69d173a"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_454944fef5798f12e9f2856b03"`
    );
    await queryRunner.query(
      `DROP TABLE "performancereviewquestion_questionnaires"`
    );
    await queryRunner.query(`DROP TABLE "performancereviewquestions"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'performancereviewquestion'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "performancereviewquestions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "performanceReviewId" uuid NOT NULL, "ratingValue" integer, "comment" character varying, CONSTRAINT "PK_1710b8e6b8f0fc6e7a242494b61" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "performancereviewquestion_questionnaires" ("performanceReviewQuestionId" uuid NOT NULL, "questionnaireId" uuid NOT NULL, CONSTRAINT "PK_55619f22aa991c8a627c6b48c6f" PRIMARY KEY ("performanceReviewQuestionId", "questionnaireId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_454944fef5798f12e9f2856b03" ON "performancereviewquestion_questionnaires" ("performanceReviewQuestionId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_9ae90c691487d91432f69d173a" ON "performancereviewquestion_questionnaires" ("questionnaireId") `
    );
    await queryRunner.query(
      `CREATE TABLE "performancereviewquestion_questions" ("performanceReviewQuestionId" uuid NOT NULL, "questionId" uuid NOT NULL, CONSTRAINT "PK_1fc53ccc53487d39d568abf572d" PRIMARY KEY ("performanceReviewQuestionId", "questionId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_f4dab97c2faea67fb5e03f7bd4" ON "performancereviewquestion_questions" ("performanceReviewQuestionId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_f868abdff5a7521a054b5ed4a0" ON "performancereviewquestion_questions" ("questionId") `
    );
    await queryRunner.query(
      `CREATE TABLE "performancereviewquestion_ratings" ("performanceReviewQuestionId" uuid NOT NULL, "ratingId" uuid NOT NULL, CONSTRAINT "PK_491300b6eca24096296b2040b35" PRIMARY KEY ("performanceReviewQuestionId", "ratingId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_fd412bf18ecff3b5369155d20f" ON "performancereviewquestion_ratings" ("performanceReviewQuestionId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_56f6572e0c0efcf906973dd12e" ON "performancereviewquestion_ratings" ("ratingId") `
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestion_questionnaires" ADD CONSTRAINT "FK_454944fef5798f12e9f2856b031" FOREIGN KEY ("performanceReviewQuestionId") REFERENCES "performancereviewquestions"("id") ON DELETE CASCADE ON UPDATE CASCADE`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestion_questionnaires" ADD CONSTRAINT "FK_9ae90c691487d91432f69d173ae" FOREIGN KEY ("questionnaireId") REFERENCES "questionnaires"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'performancereviewquestion'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('performancereviewquestion', 'Performance Review Question', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }
}
