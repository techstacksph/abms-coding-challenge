import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1189ITEMS1729228201670 implements MigrationInterface {
  name = 'ABMS1189ITEMS1729228201670';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "items"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await null;
  }
}
