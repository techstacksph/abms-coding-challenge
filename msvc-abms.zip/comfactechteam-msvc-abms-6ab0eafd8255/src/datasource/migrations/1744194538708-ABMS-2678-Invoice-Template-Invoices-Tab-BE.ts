import { MigrationInterface, QueryRunner } from 'typeorm';

export class InvoiceTemplateInvoicesTabBE1744194538708
  implements MigrationInterface
{
  name = 'InvoiceTemplateInvoicesTabBE1744194538708';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "invoiceTemplateId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN "invoiceTemplateId"`
    );
  }
}
