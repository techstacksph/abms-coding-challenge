import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS647UPDATEDURATIONPRECISION1726456199648
  implements MigrationInterface
{
  name = 'ABMS647UPDATEDURATIONPRECISION1726456199648';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "duration" TYPE numeric(40,2)`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "duration" TYPE numeric(10,2)`
    );
  }
}
