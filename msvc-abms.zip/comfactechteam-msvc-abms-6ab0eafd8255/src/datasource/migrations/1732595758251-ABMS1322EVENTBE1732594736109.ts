import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1322EVENTBE1732594736109 implements MigrationInterface {
  name = ' ABMS1322EVENTBE1732594736109';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "startDateTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "endDateTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "willSendEmail"`
    );

    await queryRunner.query(
      `ALTER TABLE "events" ADD "startDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "startTime" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "endDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "endTime" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "sendEmail" boolean DEFAULT false`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "moduleId" uuid`);

    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "popupReminder"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "popupReminder" character varying DEFAULT 'FIFTEEN_MINUTES'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "popupReminder"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "popupReminder" numeric DEFAULT '15'`
    );

    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "moduleId"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "sendEmail"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "endTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "endDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "startTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "startDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "willSendEmail" boolean DEFAULT false`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "endDateTime" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "startDateTime" TIMESTAMP NOT NULL`
    );
  }
}
