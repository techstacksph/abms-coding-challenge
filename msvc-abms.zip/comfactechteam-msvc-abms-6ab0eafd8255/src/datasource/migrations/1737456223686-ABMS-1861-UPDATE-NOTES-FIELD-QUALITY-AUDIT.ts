import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1861UPDATENOTESFIELDQUALITYAUDIT1737456223686
  implements MigrationInterface
{
  name = 'ABMS1861UPDATENOTESFIELDQUALITYAUDIT1737456223686';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "qualityaudits" ADD "notes" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "qualityaudits" DROP COLUMN "notes"`);
  }
}
