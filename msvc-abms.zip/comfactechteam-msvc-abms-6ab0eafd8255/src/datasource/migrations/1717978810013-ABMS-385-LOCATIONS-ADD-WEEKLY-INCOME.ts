import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class ABMS385LOCATIONSADDWEEKLYINCOME1717978810013
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'locations',
      new TableColumn({
        default: 0,
        name: 'weeklyIncome',
        type: 'numeric(10,2)',
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn('locations', 'weeklyIncome');
  }
}
