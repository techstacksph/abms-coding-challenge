import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTBE1732714532386 implements MigrationInterface {
  name = ' ABMSEVENTBE1732714532386';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "custom"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "yearly"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "frequency"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "endDate"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "invoiceId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "eventRecurrenceId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "trainingId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "willSendReminder"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "campaignId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "recruitmentId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "willSendSMS"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "qualityAuditId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "caseId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "jobId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "purchaseOrderId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "salesOrderId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "accountId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "evaluationId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "duration"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "dealId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "leadId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "billId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "companyId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "relatedToId"`);
    await queryRunner.query(`ALTER TABLE "companies" DROP COLUMN "companyId"`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "frequency" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "year" character varying`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "recurrenceId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "relatedTo" uuid`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "startDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "startDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "endDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "endDate" TIMESTAMP`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "freqInt"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "freqInt" integer`
    );
    await queryRunner.query(`ALTER TABLE "eventrecurring" DROP COLUMN "date"`);
    await queryRunner.query(`ALTER TABLE "eventrecurring" ADD "date" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "eventrecurring" DROP COLUMN "date"`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "date" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "freqInt"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "freqInt" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "endDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "endDate" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "startDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "startDate" character varying NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "relatedTo"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "recurrenceId"`);
    await queryRunner.query(`ALTER TABLE "eventrecurring" DROP COLUMN "year"`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "frequency"`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "relatedToId" uuid NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "companyId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "billId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "leadId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "dealId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "duration" numeric(40,2) NOT NULL DEFAULT '0'`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "evaluationId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "accountId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "salesOrderId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "purchaseOrderId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "jobId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "caseId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "qualityAuditId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "willSendSMS" boolean DEFAULT false`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "recruitmentId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "campaignId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "willSendReminder" boolean DEFAULT false`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "trainingId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "eventRecurrenceId" uuid`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "invoiceId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "endDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "frequency" text`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "yearly" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "custom" character varying`
    );
  }
}
