import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXEMPLOYEESDATEFIELDS1738643451718
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "employees"
            ALTER COLUMN "startDate" TYPE TIMESTAMP,
            ALTER COLUMN "terminationDate" TYPE TIMESTAMP,
            ALTER COLUMN "dateOfBirth" TYPE TIMESTAMP;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "employees"
            ALTER COLUMN "startDate" TYPE DATE,
            ALTER COLUMN "terminationDate" TYPE DATE,
            ALTER COLUMN "dateOfBirth" TYPE DATE;
        `);
  }
}
