import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

export class ABMS1719CREATEITEMTAG1736242270303 implements MigrationInterface {
  name = 'ABMS1719CREATEITEMTAG1736242270303';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "itemtags" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, CONSTRAINT "PK_67d5133c3e588c02ea3ec9b9716" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "item_tags" ("itemId" uuid NOT NULL, "itemTagId" uuid NOT NULL, CONSTRAINT "PK_77b4053583e739920920d4a5360" PRIMARY KEY ("itemId", "itemTagId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_3ab057a60bc8b2697356a1f294" ON "item_tags" ("itemId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_eb0f01966839edcff4a00396ef" ON "item_tags" ("itemTagId") `
    );
    await queryRunner.query(`ALTER TABLE "items" DROP COLUMN "tags"`);
    const moduleExists: Array<ModuleModel> = await queryRunner.query(
      `SELECT * FROM "modules" WHERE "code" = 'itemtag'`
    );

    if (!moduleExists.length) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('itemtag', 'Item Tag', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "items" ADD "tags" text`);
    await queryRunner.query(
      `DROP INDEX "public"."IDX_eb0f01966839edcff4a00396ef"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_3ab057a60bc8b2697356a1f294"`
    );
    await queryRunner.query(`DROP TABLE "item_tags"`);
    await queryRunner.query(`DROP TABLE "itemtags"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'itemtag'`);
  }
}
