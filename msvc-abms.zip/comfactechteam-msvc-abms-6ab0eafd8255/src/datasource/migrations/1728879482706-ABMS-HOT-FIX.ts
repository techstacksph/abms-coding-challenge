import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSHOTFIX1728879482706 implements MigrationInterface {
  name = 'ABMSHOTFIX1728879482706';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ratingscales" DROP COLUMN "code"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ratingscales" ADD "code" citext`);
  }
}
