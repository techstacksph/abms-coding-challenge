import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

export class ABMS355ADDMARKETPLACEWORKFLOWALTERDATEAVAILABILITYCOLUMN1739515617193
  implements MigrationInterface
{
  name =
    'ABMS355ADDMARKETPLACEWORKFLOWALTERDATEAVAILABILITYCOLUMN1739515617193';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "marketplaces" DROP COLUMN "dateAvailability"`
    );
    await queryRunner.query(
      `ALTER TABLE "marketplaces" ADD "dateAvailability" TIMESTAMP NOT NULL`
    );

    /* WORKFLOWS */
    const MODULE_NAME = 'Marketplace';
    const MODULE_CODE = 'marketplace';

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length > 0) {
      const caseModule = module[0];
      const moduleId = caseModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${MODULE_NAME}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const values: Array<string> = [];
          const actions = ['For new franchisee', 'Remove'];

          actions.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

          if (workflowActions.length) {
            const status = [{ name: 'For sale' }];

            status.forEach(async (data) => {
              const { name } = data;

              await queryRunner.query(`
                  INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
            });
          }
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Marketplace';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${MODULE_NAME}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${MODULE_NAME}'`
    );

    await queryRunner.query(
      `ALTER TABLE "marketplaces" DROP COLUMN "dateAvailability"`
    );
    await queryRunner.query(
      `ALTER TABLE "marketplaces" ADD "dateAvailability" date NOT NULL`
    );
  }
}
