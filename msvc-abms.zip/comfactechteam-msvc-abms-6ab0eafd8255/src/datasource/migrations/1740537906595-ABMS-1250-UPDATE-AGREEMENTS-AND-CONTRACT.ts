import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1250UPDATEAGREEMENTSANDCONTRACT1740537906595
  implements MigrationInterface
{
  name = 'ABMS1250UPDATEAGREEMENTSANDCONTRACT1740537906595';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" DROP COLUMN "effectiveDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" ADD "effectiveDate" TIMESTAMP`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" DROP COLUMN "expirationDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" ADD "expirationDate" TIMESTAMP`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" DROP COLUMN "expirationDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" ADD "expirationDate" date`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" DROP COLUMN "effectiveDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" ADD "effectiveDate" date`
    );
  }
}
