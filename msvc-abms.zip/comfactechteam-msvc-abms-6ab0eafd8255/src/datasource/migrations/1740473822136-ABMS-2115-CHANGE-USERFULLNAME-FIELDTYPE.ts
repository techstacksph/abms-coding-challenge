import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2115CHANGEUSERFULLNAMEFIELDTYPE1740473822136
  implements MigrationInterface
{
  name = 'ABMS2115CHANGEUSERFULLNAMEFIELDTYPE1740473822136';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "usergroups"`);
    await queryRunner.query(`UPDATE "users" SET "groupId" = NULL`);

    await queryRunner.query(
      `ALTER TABLE "usergroups" DROP COLUMN "userFullName"`
    );
    await queryRunner.query(
      `ALTER TABLE "usergroups" ADD "userFullName" citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "usergroups" DROP COLUMN "userFullName"`
    );
    await queryRunner.query(
      `ALTER TABLE "usergroups" ADD "userFullName" character varying`
    );
  }
}
