import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS275COMPANIESMODULE1721631750335 implements MigrationInterface {
  name = 'ABMS275COMPANIESMODULE1721631750335';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "companies" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid,
          "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
          "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
          "deletedAt" TIMESTAMP,
          "createdBy" uuid,
          "updatedBy" uuid,
          "deletedBy" uuid,
          "recordLocked" boolean NOT NULL DEFAULT false,
          "lockedBy" uuid,
          "timeLocked" TIMESTAMP NOT NULL DEFAULT now(),
          "updatedByName" character varying,
          "companyName" character varying NOT NULL,
          "parentCompanyId" uuid,
          "fullName" character varying,
          "notes" character varying,
          "contactId" uuid,
          "phoneNo" character varying NOT NULL,
          "mobileNo" character varying,
          "email" character varying NOT NULL,
          "website" character varying,
          "companyId" uuid,
          "locationId" uuid,
          "accountId" uuid,
          "recordOwnerId" uuid,
          "industryId" uuid,
          "pFindAddress" character varying,
          "pStreetAddress" character varying,
          "pSuburb" character varying,
          "pCity" character varying,
          "pAreaId" character varying,
          "pRegion" character varying,
          "pPostalCode" character varying,
          "pCountry" character varying,
          "bFindAddress" character varying,
          "bStreetAddress" character varying,
          "bSuburb" character varying,
          "bCity" character varying,
          "bAreaId" character varying,
          "bRegion" character varying,
          "bPostalCode" character varying,
          "bCountry" character varying,
          "isSamePhysicalAddress" boolean DEFAULT false,
          CONSTRAINT "PK_8d12ff38fcc62aaba2cab748265" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('companies', 'Companies', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "companies"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'companies'`);
  }
}
