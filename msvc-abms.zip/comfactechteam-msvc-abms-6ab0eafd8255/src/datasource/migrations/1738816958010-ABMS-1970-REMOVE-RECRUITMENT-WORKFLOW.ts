import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

export class ABMS1970REMOVERECRUITMENTWORKFLOW1738816958010
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Recruitment';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${MODULE_NAME}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${MODULE_NAME}'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Recruitment';
    const MODULE_CODE = 'recruitment';
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const caseModule = module[0];
      const moduleId = caseModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${MODULE_NAME}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const values: Array<string> = [];
          const actions = [
            'Log a call',
            'Send SMS',
            'Send email',
            'Create a task',
            'Create an event',
            'Add note',
            'Attach Documents',
            'Generate Agreement',
          ];

          actions.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

          if (workflowActions.length) {
            const status = [
              {
                actions: ['Qualify', 'Unqualify'],
                name: 'Potential Franchisee',
              },
              { name: 'Qualify' },
              { name: 'Unqualify' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actions}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
              );

            if (workflowStatuses.length > 0) {
              const reviewAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Review'`
                );

              if (reviewAction.length > 0) {
                const reviewId = reviewAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Reviewed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${reviewId}'`
                  );
                }
              }

              const completeAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Complete'`
                );

              if (completeAction.length > 0) {
                const completeId = completeAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Completed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${completeId}'`
                  );
                }
              }
            }
          }
        }
      }
    }
  }
}
