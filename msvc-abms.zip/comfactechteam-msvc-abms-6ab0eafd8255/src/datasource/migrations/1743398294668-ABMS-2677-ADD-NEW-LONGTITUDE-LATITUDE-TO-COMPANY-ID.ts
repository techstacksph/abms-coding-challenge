import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2677ADDNEWLONGTITUDELATITUDETOCOMPANYID1743398294668
  implements MigrationInterface
{
  name = 'ABMS2677ADDNEWLONGTITUDELATITUDETOCOMPANYID1743398294668';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "longitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "latitude" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "latitude"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "longitude"`
    );
  }
}
