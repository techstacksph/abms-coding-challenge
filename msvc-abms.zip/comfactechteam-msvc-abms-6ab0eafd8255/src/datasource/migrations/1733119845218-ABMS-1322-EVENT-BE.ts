import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTBE1733119845218 implements MigrationInterface {
  name = 'ABMSEVENTBE1733119845218';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "modules" ADD "color" character varying`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "color" = '#fdd835' WHERE code = 'account'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "color" = '#ab47bc' WHERE code = 'communication_log'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "color" = '#51b749' WHERE code = 'lead'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "color" = '#ffa726' WHERE code = 'quote'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "modules" DROP COLUMN "color"`);
  }
}
