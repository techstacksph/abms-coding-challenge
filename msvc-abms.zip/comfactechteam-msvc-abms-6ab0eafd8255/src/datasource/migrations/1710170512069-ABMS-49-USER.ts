import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS49USER1710170512069 implements MigrationInterface {
  name = 'ABMS49USER1710170512069';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "users" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "lastName" character varying NOT NULL, "firstName" character varying NOT NULL, "email" character varying NOT NULL, "phone" text, "userName" character varying NOT NULL, "status" text NOT NULL DEFAULT 'ACTIVE', "profileImage" character varying, "timeZoneId" uuid, CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexUser_UserName" ON "users" ("userName") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexUser_UserName"`);
    await queryRunner.query(`DROP TABLE "users"`);
  }
}
