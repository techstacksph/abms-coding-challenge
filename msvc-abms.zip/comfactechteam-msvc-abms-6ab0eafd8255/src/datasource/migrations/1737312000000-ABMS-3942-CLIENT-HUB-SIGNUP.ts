import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS3942CLIENTHUBSIGNUP1737312000000
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Add userType column to users table (nullable with default 'ADMIN')
    await queryRunner.query(
      `ALTER TABLE "users" ADD "userType" character varying(50) DEFAULT 'ADMIN'`
    );

    // Create index for faster lookups on userType
    await queryRunner.query(
      `CREATE INDEX "IDX_users_userType" ON "users" ("userType") WHERE "deletedAt" IS NULL`
    );

    // Add "Customer Hub" role for CLIENT users (case-insensitive check)
    const roleExists = await queryRunner.query(
      `SELECT 1 FROM "userroles" WHERE LOWER("role") = LOWER('Customer Hub') AND "deletedAt" IS NULL`
    );

    if (roleExists.length === 0) {
      await queryRunner.query(
        `
          INSERT INTO "userroles"
          ("orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "updatedByName", "role", "description")
          VALUES
          ('${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, 'Customer Hub', 'Role for Client Hub portal users')
        `
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop index
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_users_userType"`);

    // Drop userType column
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "userType"`);

    // Remove "Customer Hub" role (case-insensitive)
    await queryRunner.query(
      `DELETE FROM "userroles" WHERE LOWER("role") = LOWER('Customer Hub')`
    );
  }
}
