import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATETAXCODEDECLARATION1737602775930
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "taxcodedeclarationdetails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "employeeId" uuid, "irdNo" character varying NOT NULL, "taxCode" character varying, "sourceOfIncome" character varying, "dateSigned" date, "taxDeclaration" boolean, "signature" character varying, "disclaimer" text, CONSTRAINT "REL_33084229c78ccaa7a2ff4d305e" UNIQUE ("employeeId"), CONSTRAINT "PK_32a6b8b80fc9e0a47638c8da165" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `ALTER TABLE "taxcodedeclarationdetails" ADD CONSTRAINT "FK_33084229c78ccaa7a2ff4d305e2" FOREIGN KEY ("employeeId") REFERENCES "employees"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'taxcodedeclarationdetails'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('taxcodedeclarationdetails', 'Tax Code Declaration', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "taxcodedeclarationdetails" DROP CONSTRAINT "FK_33084229c78ccaa7a2ff4d305e2"`
    );
    await queryRunner.query(`DROP TABLE "taxcodedeclarationdetails"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'taxcodedeclarationdetails'`
    );
  }
}
