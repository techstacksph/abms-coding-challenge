import { MigrationInterface, QueryRunner } from 'typeorm';

// import { TestIds } from '../../test/SampleData';

export class ABMS1650ADDEDWORKFLOWSTATUSITEM1734617234378
  implements MigrationInterface
{
  name = 'ABMS1650ADDEDWORKFLOWSTATUSITEM1734617234378';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "items" ADD COLUMN IF NOT EXISTS "notes" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "items" ADD COLUMN IF NOT EXISTS "statusId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "items" DROP COLUMN "statusId"`);
    await queryRunner.query(`ALTER TABLE "items" DROP COLUMN "notes"`);
  }
}
