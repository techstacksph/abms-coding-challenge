import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1322EVENTBE1732959979616 implements MigrationInterface {
  name = ' ABMS1322EVENTBE1732959979616';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "relatedToId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "eventTypeId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "eventTypeId" DROP NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "relatedToId"`);
  }
}
