import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS286ADDUPDATEDBYNAME1716766399295
  implements MigrationInterface
{
  name = 'ABMS286ADDUPDATEDBYNAME1716766399295';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "timezones" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "usergroups" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "functions" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "groups" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "departments" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "securityLevels" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "countries" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "systemsettings" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "persons" ADD "updatedByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN IF EXISTS "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "updatedByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "updatedByName"`);
    await queryRunner.query(`ALTER TABLE "users" ADD "updatedByName" text`);
    await queryRunner.query(
      `ALTER TABLE "persons" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "systemsettings" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "countries" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "securityLevels" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "departments" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(`ALTER TABLE "groups" DROP COLUMN "updatedByName"`);
    await queryRunner.query(
      `ALTER TABLE "functions" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "usergroups" DROP COLUMN "updatedByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "timezones" DROP COLUMN "updatedByName"`
    );
  }
}
