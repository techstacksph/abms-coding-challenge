import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS973CASEWATCHERJUNC1730395063069 implements MigrationInterface {
  name = 'ABMS973CASEWATCHERJUNC1730395063069';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "casewatchers" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "watcherId" uuid, "caseId" uuid, CONSTRAINT "PK_f19353d684d3a1ebb9ffd140b23" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "casewatchers"`);
  }
}
