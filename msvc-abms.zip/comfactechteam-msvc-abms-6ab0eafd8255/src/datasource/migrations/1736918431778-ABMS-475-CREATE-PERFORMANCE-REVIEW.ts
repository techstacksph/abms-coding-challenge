import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS475CREATEPERFORMANCEREVIEW1736918431778
  implements MigrationInterface
{
  name = 'ABMS475CREATEPERFORMANCEREVIEW1736918431778';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "performancereviews" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "perfReviewNo" character varying, "reviewPDF" character varying, "reviewDate" TIMESTAMP NOT NULL, "dueDate" TIMESTAMP NOT NULL, "notes" character varying, "score" double precision, "questionnaireId" uuid, "statusId" uuid NOT NULL, CONSTRAINT "PK_75fc36d2026ebb28ac72078c467" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "performancereview_questionnaires" ("performanceReviewId" uuid NOT NULL, "questionnaireId" uuid NOT NULL, CONSTRAINT "PK_bde60d13f1766798cfa2e333824" PRIMARY KEY ("performanceReviewId", "questionnaireId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_b9e886509fb265ee6fd2a4b095" ON "performancereview_questionnaires" ("performanceReviewId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_af76bd962bdcfc20be1d77efca" ON "performancereview_questionnaires" ("questionnaireId") `
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'performancereview'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('performancereview', 'Performance Review', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_af76bd962bdcfc20be1d77efca"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_b9e886509fb265ee6fd2a4b095"`
    );
    await queryRunner.query(`DROP TABLE "performancereview_questionnaires"`);
    await queryRunner.query(`DROP TABLE "performancereviews"`);

    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'performancereview'`
    );
  }
}
