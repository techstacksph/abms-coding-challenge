import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS262USERSUNREQUIREDEPTANDFUNCTION1716339543282
  implements MigrationInterface
{
  name = 'ABMS262USERSUNREQUIREDEPTANDFUNCTION1716339543282';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "departmentId" DROP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "functionId" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "functionId" SET NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "departmentId" SET NOT NULL`
    );
  }
}
