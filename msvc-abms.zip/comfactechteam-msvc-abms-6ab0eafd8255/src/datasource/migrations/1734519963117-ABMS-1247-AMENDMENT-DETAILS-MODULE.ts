import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1247AMENDMENTDETAILSMODULE1734519963117
  implements MigrationInterface
{
  name = 'ABMS1247AMENDMENTDETAILSMODULE1734519963117';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "amendmentdetails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "typeId" uuid, "accountId" uuid, "jobId" uuid, "value" numeric(10,2) NOT NULL DEFAULT '0', "details" character varying, "agreementId" uuid, CONSTRAINT "PK_73599f7b94a41a809352fc6b7a2" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('amendmentdetail', 'Amendment Detail', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'amendmentdetail'`
    );
    await queryRunner.query(`DROP TABLE "amendmentdetails"`);
  }
}
