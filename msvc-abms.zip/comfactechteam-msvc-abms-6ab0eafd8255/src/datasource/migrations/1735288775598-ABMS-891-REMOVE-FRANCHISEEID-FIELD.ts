import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS891REMOVEFRANCHISEEIDFIELD1735288775598
  implements MigrationInterface
{
  name = 'ABMS891REMOVEFRANCHISEEIDFIELD1735288775598';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" DROP COLUMN "franchiseeId"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" ADD COLUMN "franchiseeId" uuid`
    );
  }
}
