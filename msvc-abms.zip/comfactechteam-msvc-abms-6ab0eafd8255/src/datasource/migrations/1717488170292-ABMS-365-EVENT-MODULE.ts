import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS365EVENTMODULE1717488170292 implements MigrationInterface {
  name = 'ABMS365EVENTMODULE1717488170292';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "events" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "subject" character varying NOT NULL, "description" character varying, "startDateTime" TIMESTAMP NOT NULL, "endDateTime" TIMESTAMP NOT NULL, "duration" numeric(10,2) NOT NULL DEFAULT '0', "willSendEmail" boolean DEFAULT false, "willSendSMS" boolean DEFAULT false, "willSendReminder" boolean DEFAULT false, "relatedToId" uuid NOT NULL, "locationId" uuid, "accountId" uuid, "companyId" uuid, "leadId" uuid, "dealId" uuid, "campaignId" uuid, "jobId" uuid, "qualityAuditId" uuid, "caseId" uuid, "invoiceId" uuid, "billId" uuid, "evaluationId" uuid, "trainingId" uuid, "purchaseOrderId" uuid, "salesOrderId" uuid, "recruitmentId" uuid, "taskId" uuid, "eventRecurrenceId" uuid, "statusId" uuid, "eventTypeId" uuid, "frequency" text, CONSTRAINT "PK_40731c7151fe4be3116e45ddf73" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('event', 'Event', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "events"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'event'`);
  }
}
