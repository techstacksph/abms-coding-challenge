import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1768ADDNEWFIELDFRANCHISEENOTIF1736482529324
  implements MigrationInterface
{
  name = 'ABMS1768ADDNEWFIELDFRANCHISEENOTIF1736482529324';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" ADD "subjectLower" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" DROP COLUMN "subjectLower"`
    );
  }
}
