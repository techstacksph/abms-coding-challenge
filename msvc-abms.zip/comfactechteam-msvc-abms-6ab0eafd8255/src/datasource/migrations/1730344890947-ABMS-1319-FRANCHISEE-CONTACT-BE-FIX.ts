import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1319FRANCHISEECONTACTBEFIX1730344890947
  implements MigrationInterface
{
  name = 'ABMS1319FRANCHISEECONTACTBEFIX1730344890947';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "contacts"`);
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "statusId" SET NOT NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexContact_Email" ON "contacts" ("email") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexContact_Email"`);
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "statusId" DROP NOT NULL`
    );
  }
}
