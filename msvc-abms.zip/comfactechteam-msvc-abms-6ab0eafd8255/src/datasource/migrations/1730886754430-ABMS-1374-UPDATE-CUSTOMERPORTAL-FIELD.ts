import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1374UPDATECUSTOMERPORTALFIELD1730886754430
  implements MigrationInterface
{
  name = 'ABMS1374UPDATECUSTOMERPORTALFIELD1730886754430';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "customerportal"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "clientPortal" boolean NOT NULL DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "clientPortal"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "customerportal" boolean NOT NULL DEFAULT false`
    );
  }
}
