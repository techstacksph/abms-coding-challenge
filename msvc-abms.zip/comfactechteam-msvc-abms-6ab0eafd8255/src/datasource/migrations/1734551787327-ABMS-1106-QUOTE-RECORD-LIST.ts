import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1106QUOTERECORDLIST1734551787327
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const quotes = await queryRunner.query(
      `SELECT * FROM quote ORDER BY "dealId", "id"`
    );

    let prevDealId = null;
    let prevQuotesCount = 0;
    let countQniqueQuote = 0;

    for (let i = 0; i < quotes.length; i++) {
      const quote = quotes[i];

      if (quote.dealId !== prevDealId) {
        prevDealId = quote.dealId;
        prevQuotesCount = 1;
        countQniqueQuote++;
      } else {
        prevQuotesCount++;
      }

      const middlePaddedNumber = String(countQniqueQuote).padStart(6, '0');
      const generatedQuoteNumber = `Q-${middlePaddedNumber}-${prevQuotesCount}`;

      await queryRunner.query(`UPDATE quote SET "quoteNo" = $1 WHERE id = $2`, [
        generatedQuoteNumber,
        quote.id,
      ]);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
