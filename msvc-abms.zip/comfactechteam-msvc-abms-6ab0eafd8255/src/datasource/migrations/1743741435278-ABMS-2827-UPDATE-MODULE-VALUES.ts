import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2827UPDATEMODULEVALUES1743741435278
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Delivery & return' WHERE code = 'deliveryandreturn'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Job purchase' WHERE code = 'job_purchase'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Job schedule' WHERE code = 'job_schedule'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Purchase order' WHERE code = 'purchaseorder'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Quality audit' WHERE code = 'qualityaudit'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Sales order' WHERE code = 'salesorder'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Stock control' WHERE code = 'stockcontrol'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Delivery & Return' WHERE code = 'deliveryandreturn'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Job Purchases' WHERE code = 'job_purchase'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Job Schedules' WHERE code = 'job_schedule'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Purchase Order' WHERE code = 'purchaseorder'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Quality Audit' WHERE code = 'qualityaudit'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Sales Order' WHERE code = 'salesorder'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "name" = 'Stock Control' WHERE code = 'stockcontrol'`
    );
  }
}
