import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS921HOTFIXMODULE1728555873416 implements MigrationInterface {
  name = 'ABMS921HOTFIXMODULE1728555873416';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemSubcategory_Isno"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemCategory_Icno"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemCategory_Icno" ON "itemcategories" ("icno") WHERE ("deletedAt" IS NULL)`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemSubcategory_Isno" ON "itemsubcategories" ("isno") WHERE ("deletedAt" IS NULL)`
    );
  }
}
