import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS96USERGROUPSADDUSERFULLNAMEFIELD1739779516878
  implements MigrationInterface
{
  name = 'ABMS96USERGROUPSADDUSERFULLNAMEFIELD1739779516878';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "usergroups"`);
    await queryRunner.query(
      `ALTER TABLE "usergroups" ADD "userFullName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "usergroups" DROP COLUMN "userFullName"`
    );
  }
}
