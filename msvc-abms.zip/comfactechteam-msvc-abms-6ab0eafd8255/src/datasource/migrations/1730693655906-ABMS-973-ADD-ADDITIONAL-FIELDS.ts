import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS973ADDADDITIONALFIELDS1730693655906
  implements MigrationInterface
{
  name = 'ABMS973ADDADDITIONALFIELDS1730693655906';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "cases" ADD "caseIdentifier" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "cases" ADD "statusNotes" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "cases" DROP COLUMN "statusNotes"`);
    await queryRunner.query(`ALTER TABLE "cases" DROP COLUMN "caseIdentifier"`);
  }
}
