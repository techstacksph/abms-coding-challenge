import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS512SALESORDER1739990169435 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "salesorder" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying,"autoNumber" SERIAL, "soNo" character varying, "soDate" TIMESTAMP NOT NULL, "soAmount" numeric(10,2), "prefferedPickUpDateTime" TIMESTAMP, "customerId" uuid NOT NULL, "franchiseeId" uuid NOT NULL, "warehouseeId" uuid NOT NULL, "recordOwnerId" uuid NOT NULL, "locationId" uuid NOT NULL, "statusId" uuid NOT NULL, "customerReference" text, "invoiceAsPackage" boolean DEFAULT false, "orderType" character varying, "notes" text, "contactId" uuid, "siteId" uuid NOT NULL, "gstType" character varying, "totalAmountGSTExclfusive" numeric(10,2), "gst" numeric(10,2), "totalAmountGSTInclusive" numeric(10,2), "totalQuantity" integer, "drQuantity" integer, "backOrderQuantity" integer, "totalSOAmount" numeric(10,2), "totalPaid" numeric(10,2), "balanceDue" numeric(10,2), "laterPickupFee" numeric(10,2), "deliveryFee" numeric(10,2), CONSTRAINT "UQ_c9f8141e43573ed03f0aa4de72b" UNIQUE ("soNo"), CONSTRAINT "PK_55350ca9975caaaa52718791618" PRIMARY KEY ("id"))`
    );

    const salesOrder = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'salesorder'`
    );

    if (salesOrder.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('salesorder', 'Sales Order', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "salesorder"`);
  }
}
