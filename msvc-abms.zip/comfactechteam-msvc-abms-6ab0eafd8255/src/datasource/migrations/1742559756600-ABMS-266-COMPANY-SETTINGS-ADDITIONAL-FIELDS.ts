import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS266COMPANYSETTINGSADDITIONALFIELDS1742559756600
  implements MigrationInterface
{
  name = 'ABMS266COMPANYSETTINGSADDITIONALFIELDS1742559756600';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "outlookTenantID" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "sharePointSiteName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "sharePointUploadFolderName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "outlookAccessToken" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "outlookTokenExpiryDate" character varying`
    );

    // REMOVE NOT NULL CONSTRAINT TO customDisplayName COLUMN
    await queryRunner.query(
      `ALTER TABLE "companysettings" ALTER COLUMN "customDisplayName" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "outlookTokenExpiryDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "outlookAccessToken"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "sharePointUploadFolderName"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "sharePointSiteName"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "outlookTenantID"`
    );
  }
}
