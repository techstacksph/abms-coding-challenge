import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2326ADDLONGITUDELATITUDETOEVENT1742190856716
  implements MigrationInterface
{
  name = 'ABMS2326ADDLONGITUDELATITUDETOEVENT1742190856716';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "longitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "latitude" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "latitude"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "longitude"`);
  }
}
