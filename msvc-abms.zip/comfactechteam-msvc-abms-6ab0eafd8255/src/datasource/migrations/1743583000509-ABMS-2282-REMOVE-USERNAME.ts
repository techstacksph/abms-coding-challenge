import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2282REMOVEUSERNAME1743583000509 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IndexAuditTrail_Username"`);
    await queryRunner.query(
      `ALTER TABLE "audit_trails" DROP COLUMN "username"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "audit_trails" ADD "username" character varying NOT NULL`
    );
    await queryRunner.query(
      `CREATE INDEX "IndexAuditTrail_Username" ON "audit_trails" ("username")`
    );
  }
}
