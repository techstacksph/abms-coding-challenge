import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSCATEGORYSUBCATEGORTMODULES1729184168041
  implements MigrationInterface
{
  name = 'ABMSCATEGORYSUBCATEGORTMODULES1729184168041';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "category_subcategories" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "categoryId" uuid, "subCategoryId" uuid, CONSTRAINT "PK_f9cf6d050e322bc816a75cb5150" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "category_subcategories"`);
  }
}
