import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS842ITEMSUBCATEGORYMODULES1728288771541
  implements MigrationInterface
{
  name = 'ABMS842ITEMSUBCATEGORYMODULES1728288771541';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "itemsubcategories" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "code" citext, "autoNumber" SERIAL, "isno" character varying, "description" character varying, "active" boolean  DEFAULT false, "itemCategoryId" uuid, CONSTRAINT "PK_343328dffdc9428271faca57b02" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemSubcategory_Isno" ON "itemsubcategories" ("isno") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemSubcategory_Code" ON "itemsubcategories" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemSubcategory_Name" ON "itemsubcategories" ("name") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('itemsubcategory', 'Item Sub Category', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemsubcategories" DROP CONSTRAINT "FK_b7dfb3ed6cc2dd1001dc2b4237b"`
    );

    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemSubcategory_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemSubcategory_Code"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemSubcategory_Isno"`
    );
    await queryRunner.query(`DROP TABLE "itemsubcategories"`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexVariants_Name" ON "variants" ("name") WHERE ("deletedAt" IS NULL)`
    );
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'itemsubcategory'`
    );
  }
}
