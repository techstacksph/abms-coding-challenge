import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS71ADDSECURITYLEVEL1715748702528 implements MigrationInterface {
  name = 'ABMS71ADDSECURITYLEVEL1715748702528';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "securityLevels" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "name" character varying NOT NULL, "description" character varying, "configuration" text NOT NULL DEFAULT '{}', CONSTRAINT "PK_fc49f3cecd4de52bd4e09f37634" PRIMARY KEY ("id"))`
    );

    const seedData = [
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 0,
              userLockTimeInMins: 0,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: true,
              minPasswordLength: 6,
              requireLowercaseCharacter: true,
              requireNumber: false,
              requireSpecialCharacter: false,
              requireUppercaseCharacter: true,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 7200,
            },
          },
          record: {
            recordLockTimeInMins: 120,
          },
        },
        id: TestIds.SECURITY_LEVEL_LOW_ID,
        name: 'Low',
      },
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 5,
              userLockTimeInMins: 30,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: false,
              minPasswordLength: 8,
              requireLowercaseCharacter: false,
              requireNumber: true,
              requireSpecialCharacter: true,
              requireUppercaseCharacter: false,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 4320,
            },
          },
          record: {
            recordLockTimeInMins: 60,
          },
        },
        id: TestIds.SECURITY_LEVEL_MEDIUM_ID,
        name: 'Medium',
      },
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 3,
              userLockTimeInMins: 60,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: false,
              minPasswordLength: 8,
              requireLowercaseCharacter: false,
              requireNumber: true,
              requireSpecialCharacter: true,
              requireUppercaseCharacter: false,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 1440,
            },
          },
          record: {
            recordLockTimeInMins: 30,
          },
        },
        id: TestIds.SECURITY_LEVEL_HIGH_ID,
        name: 'High',
      },
    ];

    const seedValues = seedData.map((data) => {
      return `('${data.id}','${data.name}','${TestIds.ORGANIZATION_ID}','${
        TestIds.PERSON_ID
      }','${JSON.stringify(data.configuration)}')`;
    });

    await queryRunner.query(
      `
        INSERT INTO "securityLevels"
          ("id","name", "orgId", "createdBy", "configuration") 
        VALUES 
          ${seedValues.join(',')}
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "securityLevels"`);
  }
}
