import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1905UPDATEEMPLOYEE1737978281088 implements MigrationInterface {
  name = 'ABMS1905UPDATEEMPLOYEE1737978281088';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "employees" ADD "middleName" character varying`
    );
    await queryRunner.query(`ALTER TABLE "employees" ADD "areaId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "employees" DROP COLUMN "areaId"`);
    await queryRunner.query(`ALTER TABLE "employees" DROP COLUMN "middleName"`);
  }
}
