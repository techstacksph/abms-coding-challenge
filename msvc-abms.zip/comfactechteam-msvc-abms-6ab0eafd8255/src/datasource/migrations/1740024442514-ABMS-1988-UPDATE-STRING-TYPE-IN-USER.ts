import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1988UPDATESTRINGTYPEINUSER1740024442514
  implements MigrationInterface
{
  name = 'ABMS1988UPDATESTRINGTYPEINUSER1740024442514';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "lastName" TYPE citext`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "firstName" TYPE citext`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "email" TYPE citext`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "userName" TYPE citext`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "name" TYPE citext`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "jobTitle" TYPE citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "lastName" TYPE character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "firstName" TYPE character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "email" TYPE character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "userName" TYPE character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "name" TYPE character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "jobTitle" TYPE character varying`
    );
  }
}
