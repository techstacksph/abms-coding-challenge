import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1628M2MRELATIONSHIPS1734325014242
  implements MigrationInterface
{
  name = 'ABMS1628M2MRELATIONSHIPS1734325014242';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobscheduleassignees" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "assigneeId" uuid, "jobScheduleId" uuid, CONSTRAINT "PK_01f7b4b2a9ef13d0206cdfda056" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "jobschedulewatchers" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "watcherId" uuid, "jobScheduleId" uuid, CONSTRAINT "PK_b5efd7dc845f3b873e807170a6b" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "jobschedulestaffs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "staffId" uuid, "jobScheduleId" uuid, CONSTRAINT "PK_d5814bf2cbd4fd123275c5ae87e" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "jobschedulestaffs"`);
    await queryRunner.query(`DROP TABLE "jobschedulewatchers"`);
    await queryRunner.query(`DROP TABLE "jobscheduleassignees"`);
  }
}
