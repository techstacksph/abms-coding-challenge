import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1271FRANCHISEEONBOARDING1735831326316
  implements MigrationInterface
{
  name = 'ABMS1271FRANCHISEEONBOARDING1735831326316';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "franchiseeonboarding" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "onboardingNo" character varying, "franchiseeId" uuid, "statusId" uuid NOT NULL, "statusNotes" character varying, "checklistId" uuid, CONSTRAINT "PK_8b6d1ab2d5ed61e39491c7a7417" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('franchiseeonboarding', 'Franchisee Onboarding', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "franchiseeonboarding"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'franchiseeonboarding'`
    );
  }
}
