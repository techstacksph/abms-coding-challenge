import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS370USERROLEMODULE1717736728560 implements MigrationInterface {
  name = 'ABMS370USERROLEMODULE1717736728560';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "permissions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" character varying NOT NULL, "permissionType" character varying, "moduleId" uuid, "parentModuleId" uuid, "isDisplayed" boolean DEFAULT true, CONSTRAINT "PK_920331560282b8bd21bb02290df" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "userpermissions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "roleId" uuid, "permissionId" uuid, "hasPermission" boolean, CONSTRAINT "PK_d6ea444b4c16c9bbf0329702743" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "userroles" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "role" character varying NOT NULL, "description" character varying, CONSTRAINT "PK_0f5953feb835cabaab6de9f4148" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexUserRole_Name" ON "userroles" ("role") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "roleId"`);
    await queryRunner.query(`ALTER TABLE "users" ADD "roleId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "roleId"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "roleId" character varying`
    );

    await queryRunner.query(`DROP INDEX "public"."UniqueIndexUserRole_Name"`);
    await queryRunner.query(`DROP TABLE "userroles"`);
    await queryRunner.query(`DROP TABLE "userpermissions"`);
    await queryRunner.query(`DROP TABLE "permissions"`);
  }
}
