import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1400ADDITIONALACCOUNTFIELD1731646319658
  implements MigrationInterface
{
  name = 'ABMS1400ADDITIONALACCOUNTFIELD1731646319658';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "accountNumber" integer`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "accountNumber"`
    );
  }
}
