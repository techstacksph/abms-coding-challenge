import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS305ADDADDRESSFIELDINLOCATION1717398384303
  implements MigrationInterface
{
  name = 'ABMS305ADDADDRESSFIELDINLOCATION1717398384303';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "address" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "address"`);
  }
}
