import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1307UPDATECONTACTMODULEFIELDS1730163511848
  implements MigrationInterface
{
  name = 'ABMS1307UPDATECONTACTMODULEFIELDS1730163511848';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "contactAccountd"`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "contactAccountId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "findAddress" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "uploadPhoto" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "dateOfBirth" TIMESTAMP`
    );
    await queryRunner.query(`ALTER TABLE "contacts" ADD "startDate" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "contacts" ADD "endDate" TIMESTAMP`);
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "completionDate" TIMESTAMP`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "jobTitle" DROP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "email" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "email" SET NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ALTER COLUMN "jobTitle" SET NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "completionDate"`
    );
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "endDate"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "startDate"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "dateOfBirth"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "uploadPhoto"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "findAddress"`);
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "contactAccountId"`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "contactAccountd" uuid`
    );
  }
}
