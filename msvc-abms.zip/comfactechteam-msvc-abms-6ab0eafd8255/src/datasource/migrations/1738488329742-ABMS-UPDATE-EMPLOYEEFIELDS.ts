import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSUPDATEEMPLOYEEFIELDS1738488329742
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "employees" ADD "fullName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "employees" DROP COLUMN "fullName"`);
  }
}
