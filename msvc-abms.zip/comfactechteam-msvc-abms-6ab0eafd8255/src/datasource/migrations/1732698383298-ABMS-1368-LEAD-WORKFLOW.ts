import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

export class ABMS1368LEADWORKFLOW1732698383298 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Lead';
    const MODULE_CODE = 'lead';
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const caseModule = module[0];
      const moduleId = caseModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${MODULE_NAME}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const values: Array<string> = [];
          const actions = [
            'Log a call',
            'Send SMS',
            'Send email',
            'Create a task',
            'Create an event',
            'Add note',
            'Attach Documents',
            'Qualified',
            'Unqualified',
          ];

          actions.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

          if (workflowActions.length) {
            const status = [
              { actions: ['Qualified', 'Unqualified'], name: 'New' },
              { name: 'Qualified' },
              { name: 'Unqualified' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                await queryRunner.query(`
                  INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actions}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
                  INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
              );

            if (workflowStatuses.length > 0) {
              const qualifiedAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Qualified'`
                );

              if (qualifiedAction.length > 0) {
                const qualifyId = qualifiedAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Qualified'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }

              const unqualifiedAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Unqualified'`
                );

              if (unqualifiedAction.length > 0) {
                const unqualifiedId = unqualifiedAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Unqualified'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${unqualifiedId}'`
                  );
                }
              }
            }
          }
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Lead';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${MODULE_NAME}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${MODULE_NAME}'`
    );
  }
}
