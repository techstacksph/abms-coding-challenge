import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS337UPDATEFIELDNAMEINVEHICLE1732478969888
  implements MigrationInterface
{
  name = 'ABMS337UPDATEFIELDNAMEINVEHICLE1732478969888';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "vehicles" RENAME COLUMN "signWrittingRemovedDate" TO "signWritingRemovedDate"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "vehicles" RENAME COLUMN "signWritingRemovedDate" TO "signWrittingRemovedDate"`
    );
  }
}
