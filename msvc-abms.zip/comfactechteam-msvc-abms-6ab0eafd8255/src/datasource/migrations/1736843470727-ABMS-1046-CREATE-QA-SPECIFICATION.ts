import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1046CREATEQASPECIFICATION1736843470727
  implements MigrationInterface
{
  name = 'ABMS1046CREATEQASPECIFICATION1736843470727';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "qaspecifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "qualityAuditId" uuid NOT NULL, "qaAreaId" uuid NOT NULL, "specification" character varying NOT NULL, "assessment" character varying NOT NULL, "notes" character varying, CONSTRAINT "PK_003552737ac36717467766dafae" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('qaspecification', 'Qa Specification', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "qaspecifications"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'qaspecification'`
    );
  }
}
