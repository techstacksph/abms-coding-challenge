import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1991CREATENATIONALITYDATA1739732138991
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "nationalities"`);
    const data = [
      {
        code: 'AFGHAN',
        name: 'Afghan',
      },
      {
        code: 'ALBANIAN',
        name: 'Albanian',
      },
      {
        code: 'ALGERIAN',
        name: 'Algerian',
      },
      {
        code: 'AMERICAN',
        name: 'American',
      },
      {
        code: 'ANDORRAN',
        name: 'Andorran',
      },
      {
        code: 'ANGOLAN',
        name: 'Angolan',
      },
      {
        code: 'ANTIGUAN',
        name: 'Antiguan',
      },
      {
        code: 'ARGENTINIAN',
        name: 'Argentine',
      },
      {
        code: 'ARMENIAN',
        name: 'Armenian',
      },
      {
        code: 'AUSTRALIAN',
        name: 'Australian',
      },
      {
        code: 'AUSTRIAN',
        name: 'Austrian',
      },
      {
        code: 'AZERBAIJANI',
        name: 'Azerbaijani',
      },
      {
        code: 'BAHAMIAN',
        name: 'Bahamian',
      },
      {
        code: 'BAHRAINI',
        name: 'Bahraini',
      },
      {
        code: 'BANGLADESHI',
        name: 'Bangladeshi',
      },
      {
        code: 'BARBADIAN',
        name: 'Barbadian',
      },
      {
        code: 'BELARUSIAN',
        name: 'Belarusian',
      },
      {
        code: 'BELGIAN',
        name: 'Belgian',
      },
      {
        code: 'BELIZEAN',
        name: 'Belizean',
      },
      {
        code: 'BENINESE',
        name: 'Beninese',
      },
      {
        code: 'BHUTANESE',
        name: 'Bhutanese',
      },
      {
        code: 'BOLIVIAN',
        name: 'Bolivian',
      },
      {
        code: 'BOSNIAN',
        name: 'Bosnian',
      },
      {
        code: 'BOTSWANAN',
        name: 'Botswanan',
      },
      {
        code: 'BRAZILIAN',
        name: 'Brazilian',
      },
      {
        code: 'BRUNEIAN',
        name: 'Bruneian',
      },
      {
        code: 'BULGARIAN',
        name: 'Bulgarian',
      },
      {
        code: 'BURKINESE',
        name: 'Burkinese',
      },
      {
        code: 'BURUNDIAN',
        name: 'Burundian',
      },
      {
        code: 'CAMBODIAN',
        name: 'Cambodian',
      },
      {
        code: 'CAMEROONIAN',
        name: 'Cameroonian',
      },
      {
        code: 'CANADIAN',
        name: 'Canadian',
      },
      {
        code: 'CAPE_VERDEAN',
        name: 'Cape Verdean',
      },
      {
        code: 'CENTRAL_AFRICAN',
        name: 'Central African',
      },
      {
        code: 'CHADIAN',
        name: 'Chadian',
      },
      {
        code: 'CHILEAN',
        name: 'Chilean',
      },
      {
        code: 'CHINESE',
        name: 'Chinese',
      },
      {
        code: 'COLOMBIAN',
        name: 'Colombian',
      },
      {
        code: 'COMORAN',
        name: 'Comoran',
      },
      {
        code: 'CONGOLESE',
        name: 'Congolese',
      },
      {
        code: 'COSTA_RICAN',
        name: 'Costa Rican',
      },
      {
        code: 'CROATIAN',
        name: 'Croatian',
      },
      {
        code: 'CUBAN',
        name: 'Cuban',
      },
      {
        code: 'CYPRIOT',
        name: 'Cypriot',
      },
      {
        code: 'CZECH',
        name: 'Czech',
      },
      {
        code: 'DANISH',
        name: 'Danish',
      },
      {
        code: 'DJIBOUTIAN',
        name: 'Djiboutian',
      },
      {
        code: 'DOMINICAN',
        name: 'Dominican',
      },
      {
        code: 'ECUADORIAN',
        name: 'Ecuadorian',
      },
      {
        code: 'EGYPTIAN',
        name: 'Egyptian',
      },
      {
        code: 'EL_SALVADORAN',
        name: 'El Salvadoran',
      },
      {
        code: 'EQUATORIAL_GUINEAN',
        name: 'Equatorial Guinean',
      },
      {
        code: 'ERITREAN',
        name: 'Eritrean',
      },
      {
        code: 'ESTONIAN',
        name: 'Estonian',
      },
      {
        code: 'ETHIOPIAN',
        name: 'Ethiopian',
      },
      {
        code: 'FIJIAN',
        name: 'Fijian',
      },
      {
        code: 'FILIPINO',
        name: 'Filipino',
      },
      {
        code: 'FINNISH',
        name: 'Finnish',
      },
      {
        code: 'FRENCH',
        name: 'French',
      },
      {
        code: 'GABONESE',
        name: 'Gabonese',
      },
      {
        code: 'GAMBIAN',
        name: 'Gambian',
      },
      {
        code: 'GEORGIAN',
        name: 'Georgian',
      },
      {
        code: 'GHANAIAN',
        name: 'Ghanaian',
      },
      {
        code: 'GREEK',
        name: 'Greek',
      },
      {
        code: 'GRENADIAN',
        name: 'Grenadian',
      },
      {
        code: 'GUATEMALAN',
        name: 'Guatemalan',
      },
      {
        code: 'GUINEAN',
        name: 'Guinean',
      },
      {
        code: 'GUINEA_BISSAUAN',
        name: 'Guinea-Bissauan',
      },
      {
        code: 'HAITIAN',
        name: 'Haitian',
      },
      {
        code: 'HONDURAN',
        name: 'Honduran',
      },
      {
        code: 'HUNGARIAN',
        name: 'Hungarian',
      },
      {
        code: 'ICELANDIC',
        name: 'Icelander',
      },
      {
        code: 'INDIAN',
        name: 'Indian',
      },
      {
        code: 'INDONESIAN',
        name: 'Indonesian',
      },
      {
        code: 'IRANIAN',
        name: 'Iranian',
      },
      {
        code: 'IRAQI',
        name: 'Iraqi',
      },
      {
        code: 'IRISH',
        name: 'Irish',
      },
      {
        code: 'ISRAELI',
        name: 'Israeli',
      },
      {
        code: 'ITALIAN',
        name: 'Italian',
      },
      {
        code: 'IVORIAN',
        name: 'Ivorian',
      },
      {
        code: 'JAMAICAN',
        name: 'Jamaican',
      },
      {
        code: 'JAPANESE',
        name: 'Japanese',
      },
      {
        code: 'JORDANIAN',
        name: 'Jordanian',
      },
      {
        code: 'KAZAKH',
        name: 'Kazakh',
      },
      {
        code: 'KENYAN',
        name: 'Kenyan',
      },
      {
        code: 'KIRIBATI',
        name: 'Kiribati',
      },
      {
        code: 'KOREAN',
        name: 'Korean',
      },
      {
        code: 'KUWAITI',
        name: 'Kuwaiti',
      },
      {
        code: 'KYRGYZ',
        name: 'Kyrgyz',
      },
      {
        code: 'LAOTIAN',
        name: 'Laotian',
      },
      {
        code: 'LATVIAN',
        name: 'Latvian',
      },
      {
        code: 'LEBANESE',
        name: 'Lebanese',
      },
      {
        code: 'LESOTHOAN',
        name: 'Lesothoan',
      },
      {
        code: 'LIBERIAN',
        name: 'Liberian',
      },
      {
        code: 'LIBYAN',
        name: 'Libyan',
      },
      {
        code: 'LIECHTENSTEINER',
        name: 'Liechtensteinian',
      },
      {
        code: 'LITHUANIAN',
        name: 'Lithuanian',
      },
      {
        code: 'LUXEMBOURGER',
        name: 'Luxembourger',
      },
      {
        code: 'MACEDONIAN',
        name: 'Macedonian',
      },
      {
        code: 'MALAGASY',
        name: 'Malagasy',
      },
      {
        code: 'MALAWIAN',
        name: 'Malawian',
      },
      {
        code: 'MALAYSIAN',
        name: 'Malaysian',
      },
      {
        code: 'MALDIVIAN',
        name: 'Maldivian',
      },
      {
        code: 'MALIAN',
        name: 'Malian',
      },
      {
        code: 'MALTESE',
        name: 'Maltese',
      },
      {
        code: 'MARSHALLESE',
        name: 'Marshallese',
      },
      {
        code: 'MAURITANIAN',
        name: 'Mauritanian',
      },
      {
        code: 'MAURITIAN',
        name: 'Mauritian',
      },
      {
        code: 'MEXICAN',
        name: 'Mexican',
      },
      {
        code: 'MICRONESIAN',
        name: 'Micronesian',
      },
      {
        code: 'MOLDOVAN',
        name: 'Moldovan',
      },
      {
        code: 'MONACAN',
        name: 'Monacan',
      },
      {
        code: 'MONGOLIAN',
        name: 'Mongolian',
      },
      {
        code: 'MONTENEGRIN',
        name: 'Montenegrin',
      },
      {
        code: 'MOROCCAN',
        name: 'Moroccan',
      },
      {
        code: 'MOZAMBICAN',
        name: 'Mozambican',
      },
      {
        code: 'MYANMAR',
        name: 'Myanmar',
      },
      {
        code: 'NAMIBIAN',
        name: 'Namibian',
      },
      {
        code: 'NAURUAN',
        name: 'Nauruan',
      },
      {
        code: 'NEPALESE',
        name: 'Nepalese',
      },
      {
        code: 'NETHERLANDS',
        name: 'Dutch',
      },
      {
        code: 'NEW_ZEALANDER',
        name: 'New Zealander',
      },
      {
        code: 'NICARAGUAN',
        name: 'Nicaraguan',
      },
      {
        code: 'NIGERIAN',
        name: 'Nigerian',
      },
      {
        code: 'NIUEAN',
        name: 'Niuean',
      },
      {
        code: 'NORWEGIAN',
        name: 'Norwegian',
      },
      {
        code: 'OMANI',
        name: 'Omani',
      },
      {
        code: 'PAKISTANI',
        name: 'Pakistani',
      },
      {
        code: 'PALAUAN',
        name: 'Palauan',
      },
      {
        code: 'PANAMANIAN',
        name: 'Panamanian',
      },
      {
        code: 'PAPUA_NEW_GUINEAN',
        name: 'Papua New Guinean',
      },
      {
        code: 'PARAGUAYAN',
        name: 'Paraguayan',
      },
      {
        code: 'PERUVIAN',
        name: 'Peruvian',
      },
      {
        code: 'PHILIPPINE',
        name: 'Philippine',
      },
      {
        code: 'POLISH',
        name: 'Polish',
      },
      {
        code: 'PORTUGUESE',
        name: 'Portuguese',
      },
      {
        code: 'QATARI',
        name: 'Qatari',
      },
      {
        code: 'ROMANIAN',
        name: 'Romanian',
      },
      {
        code: 'RUSSIAN',
        name: 'Russian',
      },
      {
        code: 'RWANDAN',
        name: 'Rwandan',
      },
      {
        code: 'SAINT_KITTS_AND_NEVIS',
        name: 'Saint Kitts and Nevis',
      },
      {
        code: 'SAINT_LUCIA',
        name: 'Saint Lucia',
      },
      {
        code: 'SAINT_VINCENT',
        name: 'Saint Vincent',
      },
      {
        code: 'SAMOAN',
        name: 'Samoan',
      },
      {
        code: 'SAN_MARINESE',
        name: 'San Marinese',
      },
      {
        code: 'SAO_TOMEAN',
        name: 'Sao Tomean',
      },
      {
        code: 'SAUDI',
        name: 'Saudi',
      },
      {
        code: 'SENEGALESE',
        name: 'Senegalese',
      },
      {
        code: 'SERBIAN',
        name: 'Serbian',
      },
      {
        code: 'SEYCHELLOIS',
        name: 'Seychellois',
      },
      {
        code: 'SIERRA_LEONEAN',
        name: 'Sierra Leonean',
      },
      {
        code: 'SINGAPOREAN',
        name: 'Singaporean',
      },
      {
        code: 'SLOVAK',
        name: 'Slovak',
      },
      {
        code: 'SLOVENIAN',
        name: 'Slovenian',
      },
      {
        code: 'SOLOMON_ISLANDS',
        name: 'Solomon Islands',
      },
      {
        code: 'SOMALI',
        name: 'Somali',
      },
      {
        code: 'SOUTH_AFRICAN',
        name: 'South African',
      },
      {
        code: 'SOUTH_KOREAN',
        name: 'South Korean',
      },
      {
        code: 'SOUTH_SUDANESE',
        name: 'South Sudanese',
      },
      {
        code: 'SPANISH',
        name: 'Spanish',
      },
      {
        code: 'SRI_LANKAN',
        name: 'Sri Lankan',
      },
      {
        code: 'SUDANESE',
        name: 'Sudanese',
      },
      {
        code: 'SURINAMESE',
        name: 'Surinamese',
      },
      {
        code: 'SWAZI',
        name: 'Swazi',
      },
      {
        code: 'SWEDISH',
        name: 'Swedish',
      },
      {
        code: 'SWISS',
        name: 'Swiss',
      },
      {
        code: 'SYRIAN',
        name: 'Syrian',
      },
      {
        code: 'TAIWANESE',
        name: 'Taiwanese',
      },
      {
        code: 'TAJIK',
        name: 'Tajik',
      },
      {
        code: 'TANZANIAN',
        name: 'Tanzanian',
      },
      {
        code: 'THAI',
        name: 'Thai',
      },
      {
        code: 'TOGOLESE',
        name: 'Togolese',
      },
      {
        code: 'TONGAN',
        name: 'Tongan',
      },
      {
        code: 'TRINIDADIAN',
        name: 'Trinidadian',
      },
      {
        code: 'TUNISIAN',
        name: 'Tunisian',
      },
      {
        code: 'TURKMEN',
        name: 'Turkmen',
      },
      {
        code: 'TURKISH',
        name: 'Turkish',
      },
      {
        code: 'TUVALUAN',
        name: 'Tuvaluan',
      },
      {
        code: 'UGANDAN',
        name: 'Ugandan',
      },
      {
        code: 'UKRAINIAN',
        name: 'Ukrainian',
      },
      {
        code: 'URUGUAYAN',
        name: 'Uruguayan',
      },
      {
        code: 'UZBEK',
        name: 'Uzbek',
      },
      {
        code: 'VANUATUAN',
        name: 'Vanuatuan',
      },
      {
        code: 'VENEZUELAN',
        name: 'Venezuelan',
      },
      {
        code: 'VIETNAMESE',
        name: 'Vietnamese',
      },
      {
        code: 'YEMENI',
        name: 'Yemeni',
      },
      {
        code: 'ZAMBIAN',
        name: 'Zambian',
      },
      {
        code: 'ZIMBABWEAN',
        name: 'Zimbabwean',
      },
    ].map((a) => `('${a.name}', '${a.code}', '${TestIds.ORGANIZATION_ID}')`);

    await queryRunner.query(
      `INSERT INTO "nationalities" ("name", "code", "orgId") VALUES ${data.join(
        ','
      )}`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "nationalities"`);
  }
}
