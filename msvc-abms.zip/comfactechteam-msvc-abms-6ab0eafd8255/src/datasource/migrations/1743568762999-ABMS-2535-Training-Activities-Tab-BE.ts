import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2535TrainingActivitiesTabBE1743568762999
  implements MigrationInterface
{
  name = 'ABMS2535TrainingActivitiesTabBE1743568762999';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" ADD "trainingId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "trainingId"`);
  }
}
