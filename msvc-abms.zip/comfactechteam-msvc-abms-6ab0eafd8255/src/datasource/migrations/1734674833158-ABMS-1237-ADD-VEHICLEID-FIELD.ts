import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1237ADDVEHICLEIDFIELD1734674833158
  implements MigrationInterface
{
  name = 'ABMS1237ADDVEHICLEIDFIELD1734674833158';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseeagreements" ADD "vehicleId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseeagreements" DROP COLUMN "vehicleId"`
    );
  }
}
