import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1274CREATEONBOARDINGCHECKLIST1735936808915
  implements MigrationInterface
{
  name = 'ABMS1274CREATEONBOARDINGCHECKLIST1735936808915';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "onboardingchecklist" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "checklistId" uuid NOT NULL, "description" character varying, "taskId" uuid, "franchiseeOnboardingId" uuid, CONSTRAINT "PK_31cd36003a64506b0b9a60ca845" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('onboardingchecklist', 'Onboarding Checklist', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "onboardingchecklist"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'onboardingchecklist'`
    );
  }
}
