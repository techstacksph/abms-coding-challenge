import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2677ADDPLACEID1743068117807 implements MigrationInterface {
  name = 'ABMS2677ADDPLACEID1743068117807';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "placeId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "placeId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "placeId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "pPlaceId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bPlaceId" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "bPlaceId"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "pPlaceId"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "placeId"`);
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "placeId"`);
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "placeId"`
    );
  }
}
