import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS886ADDPRIMARYCONTACTNAME1729730990355
  implements MigrationInterface
{
  name = 'ABMS886ADDPRIMARYCONTACTNAME1729730990355';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "primaryContactName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "primaryContactName"`
    );
  }
}
