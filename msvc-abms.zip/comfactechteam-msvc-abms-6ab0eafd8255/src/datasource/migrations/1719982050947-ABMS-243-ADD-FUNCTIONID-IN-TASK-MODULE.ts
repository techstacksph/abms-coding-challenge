import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS243ADDFUNCTIONIDINTASKMODULE1719982050947
  implements MigrationInterface
{
  name = 'ABMS243ADDFUNCTIONIDINTASKMODULE1719982050947';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" ADD "functionId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "functionId"`);
  }
}
