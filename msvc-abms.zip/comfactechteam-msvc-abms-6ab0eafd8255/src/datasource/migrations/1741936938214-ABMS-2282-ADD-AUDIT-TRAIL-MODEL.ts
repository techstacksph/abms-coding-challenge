import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

const MODULE_CODE = 'audittrails';
export class ABMS2282ADDAUDITTRAILMODEL1741936938214
  implements MigrationInterface
{
  name = 'ABMS2282ADDAUDITTRAILMODEL1741936938214';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."audit_trails_actiontype_enum" AS ENUM('CREATE', 'UPDATE', 'DELETE', 'RESTORE')`
    );
    await queryRunner.query(
      `CREATE TABLE "audit_trails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "moduleName" character varying NOT NULL, "recordId" character varying NOT NULL, "actionType" "public"."audit_trails_actiontype_enum" NOT NULL, "content" character varying NOT NULL, "changes" jsonb, "username" character varying NOT NULL, CONSTRAINT "PK_91440e9d8998d3faf5f8cd6b9ab" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IndexAuditTrail_Username" ON "audit_trails" ("username") `
    );
    await queryRunner.query(
      `CREATE INDEX "UniqueIndexAuditTrail_CreatedAt" ON "audit_trails" ("createdAt") `
    );
    await queryRunner.query(
      `CREATE INDEX "UniqueIndexAuditTrail_ModuleName_RecordId" ON "audit_trails" ("moduleName", "recordId") `
    );

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length === 0) {
      await queryRunner.query(`
        INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', 'Audit Trail', '${TestIds.ORGANIZATION_ID}')`);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DELETE FROM "modules" WHERE code = '${MODULE_CODE}'
    `);
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAuditTrail_ModuleName_RecordId"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAuditTrail_CreatedAt"`
    );
    await queryRunner.query(`DROP INDEX "public"."IndexAuditTrail_Username"`);
    await queryRunner.query(`DROP TABLE "audit_trails"`);
    await queryRunner.query(
      `DROP TYPE "public"."audit_trails_actiontype_enum"`
    );
  }
}
