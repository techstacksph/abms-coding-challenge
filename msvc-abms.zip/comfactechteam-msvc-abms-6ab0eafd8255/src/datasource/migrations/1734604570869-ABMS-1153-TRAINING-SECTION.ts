import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

export class ABMS1153TRAININGSECTION1734604570869
  implements MigrationInterface
{
  name = 'ABMS1153TRAININGSECTION1734604570869';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "trainingsectiondetails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "trainingDetailsId" uuid NOT NULL, "trainingId" uuid NOT NULL, "description" text, "startDate" TIMESTAMP, "endDate" TIMESTAMP, "hours" integer, "statusId" uuid NOT NULL, "notes" text, CONSTRAINT "PK_8579e1597e81c7ff7204bcceec6" PRIMARY KEY ("id"))`
    );
    const moduleExists: Array<ModuleModel> = await queryRunner.query(
      `SELECT * FROM "modules" WHERE "code" = 'trainingsectiondetails'`
    );

    if (!moduleExists.length) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('trainingsectiondetails', 'Training Section Details', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "trainingsectiondetails"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'trainingsectiondetails'`
    );
  }
}
