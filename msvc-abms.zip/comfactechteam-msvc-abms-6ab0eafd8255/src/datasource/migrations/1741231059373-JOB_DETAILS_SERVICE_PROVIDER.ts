import { MigrationInterface, QueryRunner } from 'typeorm';

export class JOBDETAILSSERVICEPROVIDER1741231059373
  implements MigrationInterface
{
  name = 'JOBDETAILSSERVICEPROVIDER1741231059373';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "job_service_provider" ("jobdetailsId" uuid NOT NULL, "serviceProviderid" uuid NOT NULL, CONSTRAINT "PK_01262c5fb3e0b32b645e82c1e55" PRIMARY KEY ("jobdetailsId", "serviceProviderid"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_2bd6a3f979f386432f214c5c10" ON "job_service_provider" ("jobdetailsId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_59c2dd9fd157e563f2e80892e6" ON "job_service_provider" ("serviceProviderid") `
    );
    await queryRunner.query(
      `ALTER TABLE "jobdetails" DROP COLUMN "serviceProviderId"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_59c2dd9fd157e563f2e80892e6"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_2bd6a3f979f386432f214c5c10"`
    );
    await queryRunner.query(`DROP TABLE "job_service_provider"`);
  }
}
