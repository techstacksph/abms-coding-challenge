import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS663ADDUNIQUEFIELDCONSTRAINT1726547644230
  implements MigrationInterface
{
  name = 'ABMS663ADDUNIQUEFIELDCONSTRAINT1726547644230';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDocumentType_Name" ON "documenttypes" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexDocumentType_Name"`
    );
  }
}
