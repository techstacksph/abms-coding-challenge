import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1539ADDCONTACTFULLNAMEFIELDCONTACTACCOUNTS1732601059768
  implements MigrationInterface
{
  name = 'ABMS1539ADDCONTACTFULLNAMEFIELDCONTACTACCOUNTS1732601059768';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contactaccounts" ADD "contactFullName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contactaccounts" DROP COLUMN "contactFullName"`
    );
  }
}
