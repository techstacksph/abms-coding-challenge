import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1638DROPCANCELLATIONTABLE1736153660027
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexCancellationType_CancellationTypeName"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexCancellationTypeCode_CancellationTypeCode"`
    );
    await queryRunner.query(`DROP TABLE "cancellationType"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "cancellationType" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "cancellationType" citext NOT NULL, "code" citext, "description" text, CONSTRAINT "UQ_331658774621b56f26f246be95b" UNIQUE ("cancellationType"), CONSTRAINT "UQ_9c8b2e146f1fafccc91069c6369" UNIQUE ("code"), CONSTRAINT "PK_1df868801e5ce8a3f4bd5362867" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexCancellationTypeCode_CancellationTypeCode" ON "cancellationType" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexCancellationType_CancellationTypeName" ON "cancellationType" ("cancellationType") WHERE "deletedAt" IS NULL`
    );
  }
}
