import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS886REVERTPRIMARYCONTACT1729735963192
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "primaryContactName"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "primaryContactName" character varying`
    );
  }
}
