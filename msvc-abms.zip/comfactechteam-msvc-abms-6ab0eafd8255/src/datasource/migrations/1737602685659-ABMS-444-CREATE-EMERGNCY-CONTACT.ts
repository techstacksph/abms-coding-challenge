import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATEEMERGNCYCONTACT1737602685659
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "emergencycontacts" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "employeeId" uuid NOT NULL, "contactName" character varying NOT NULL, "relationship" character varying, "phoneNo" character varying, "mobileNo" character varying, CONSTRAINT "PK_12ccb1a15f40060ee28c0f41a37" PRIMARY KEY ("id"))`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'emergencycontact'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('emergencycontact', 'Emergency Contact', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "emergencycontacts"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'emergencycontact'`
    );
  }
}
