import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS735UPDATEDOCUMENTTYPEMODEL1726531259714
  implements MigrationInterface
{
  name = 'ABMS735UPDATEDOCUMENTTYPEMODEL1726531259714';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttype" RENAME COLUMN "documentTypeName" TO "name"`
    );
    await queryRunner.query(
      `ALTER TABLE "documenttype" ADD "code" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documenttype" DROP COLUMN "code"`);
    await queryRunner.query(
      `ALTER TABLE "documenttype" RENAME COLUMN "name" TO "documentTypeName"`
    );
  }
}
