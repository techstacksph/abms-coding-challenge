import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS877UPDATEPRIMARYCONTACT1728368381694
  implements MigrationInterface
{
  name = 'ABMS877UPDATEPRIMARYCONTACT1728368381694';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "primaryContactId" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "primaryContactId" SET NOT NULL`
    );
  }
}
