import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSLEAVESFIELDSHOTFIX1738779753883 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
                ALTER TABLE "leaves"
                ALTER COLUMN "dateFrom" TYPE TIMESTAMP,
                ALTER COLUMN "dateTo" TYPE TIMESTAMP;
            `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
                ALTER TABLE "leaves"
                ALTER COLUMN "dateFrom" TYPE DATE,
                ALTER COLUMN "dateTo" TYPE DATE;
            `);
  }
}
