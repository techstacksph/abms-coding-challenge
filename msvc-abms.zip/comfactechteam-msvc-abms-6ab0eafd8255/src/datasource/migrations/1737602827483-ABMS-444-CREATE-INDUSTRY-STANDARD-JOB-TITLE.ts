import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATEINDUSTRYSTANDARDJOBTITLE1737602827483
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "industrystandardjobtitles" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_3049b73b529df25f3721370f9d1" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexIndustryStandardJobTitle_Code" ON "industrystandardjobtitles" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexIndustryStandardJobTitle_Name" ON "industrystandardjobtitles" ("name") WHERE "deletedAt" IS NULL`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'industrystandardjobtitle'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('industrystandardjobtitle', 'Industry Standard Job Title', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexIndustryStandardJobTitle_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexIndustryStandardJobTitle_Code"`
    );
    await queryRunner.query(`DROP TABLE "industrystandardjobtitles"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'industrystandardjobtitle'`
    );
  }
}
