import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2496ADDCOLUMNASIGNEEJSONTOTASKANDEVENT1742876208230
  implements MigrationInterface
{
  name = 'ABMS2496ADDCOLUMNASIGNEEJSONTOTASKANDEVENT1742876208230';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" ADD "assigneeJson" json`);
    await queryRunner.query(`ALTER TABLE "events" ADD "assigneeJson" json`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "assigneeJson"`);
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "assigneeJson"`);
  }
}
