import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1383ADDLEADTONOTE1732852809363 implements MigrationInterface {
  name = 'ABMS1383ADDLEADTONOTE1732852809363';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" ADD "leadId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "leadId"`);
  }
}
