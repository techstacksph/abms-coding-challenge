import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1062UPDATEDOCUMENTMODEL1736824785779
  implements MigrationInterface
{
  name = 'ABMS1062UPDATEDOCUMENTMODEL1736824785779';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "file1" character varying NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "file2" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "file3" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "file4" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "file5" character varying`
    );
    await queryRunner.query(`ALTER TABLE "documents" ADD "accountId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "leadId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "dealId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "siteId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "jobId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "caseId" uuid`);
    await queryRunner.query(`ALTER TABLE "documents" ADD "trainingId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "franchiseeAgreementId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "qualityAuditId" uuid`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDeals_DocumentName" ON "documents" ("documentName") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexDeals_DocumentName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "qualityAuditId"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "franchiseeAgreementId"`
    );
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "trainingId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "caseId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "jobId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "siteId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "dealId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "leadId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "accountId"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "file5"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "file4"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "file3"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "file2"`);
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "file1"`);
  }
}
