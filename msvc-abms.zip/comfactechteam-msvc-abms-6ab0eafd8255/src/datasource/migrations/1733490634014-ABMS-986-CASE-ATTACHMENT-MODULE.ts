import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS986CASEATTACHMENTMODULE1733490634014
  implements MigrationInterface
{
  name = 'ABMS986CASEATTACHMENTMODULE1733490634014';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "caseattachments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "caseAttachment" character varying, "description" character varying, "caseId" uuid NOT NULL, CONSTRAINT "PK_509a2e21335596f02ba2af1cab9" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "caseattachments"`);
  }
}
