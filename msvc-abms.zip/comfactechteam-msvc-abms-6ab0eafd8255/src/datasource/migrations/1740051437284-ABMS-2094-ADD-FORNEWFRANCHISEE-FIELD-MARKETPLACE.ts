import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2094ADDFORNEWFRANCHISEEFIELDMARKETPLACE1740051437284
  implements MigrationInterface
{
  name = 'ABMS2094ADDFORNEWFRANCHISEEFIELDMARKETPLACE1740051437284';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "marketplaces" ADD "forNewFranchisee" boolean DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "marketplaces" DROP COLUMN "forNewFranchisee"`
    );
  }
}
