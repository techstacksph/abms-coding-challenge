import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1689ADDRELATIONSHIPSTOEVENT1733983618359
  implements MigrationInterface
{
  name = 'ABMS1689ADDRELATIONSHIPSTOEVENT1733983618359';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN IF EXISTS "moduleId"`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "accountId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "caseId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "dealId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "jobId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "qualityAuditId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "salesOrderId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "purchaseOrderId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "evaluationId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "recruitmentId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "trainingId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "leadId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "invoiceId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "billId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "billId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "invoiceId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "leadId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "trainingId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "recruitmentId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "evaluationId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "purchaseOrderId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "salesOrderId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "qualityAuditId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "jobId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "dealId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "caseId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "accountId"`);
    await queryRunner.query(`ALTER TABLE "events" ADD "moduleId" uuid`);
  }
}
