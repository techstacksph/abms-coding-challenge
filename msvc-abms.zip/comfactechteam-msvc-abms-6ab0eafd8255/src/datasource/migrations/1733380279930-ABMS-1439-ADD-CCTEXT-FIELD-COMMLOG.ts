import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1439ADDCCTEXTFIELDCOMMLOG1733380279930
  implements MigrationInterface
{
  name = 'ABMS1439ADDCCTEXTFIELDCOMMLOG1733380279930';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "ccEmailText" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "ccEmailText"`
    );
  }
}
