import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTRECURRINGBE1733372930107 implements MigrationInterface {
  name = ' ABMSEVENTRECURRINGBE1733372930107';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "eventrecurring" DROP COLUMN "days"`);
    await queryRunner.query(`ALTER TABLE "eventrecurring" ADD "days" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "eventrecurring" DROP COLUMN "days"`);
  }
}
