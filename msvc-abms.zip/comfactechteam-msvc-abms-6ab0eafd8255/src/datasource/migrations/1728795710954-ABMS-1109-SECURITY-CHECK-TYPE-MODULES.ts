import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1109SECURITYCHECKTYPEMODULES1728795710954
  implements MigrationInterface
{
  name = 'ABMS1109SECURITYCHECKTYPEMODULES1728795710954';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "securitychecktypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_bc8ee7dccb96e8dc338dca2af89" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSecurityCheckType_Code" ON "securitychecktypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSecurityCheckType_Name" ON "securitychecktypes" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('securitychecktype', 'Security Check Type', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexSecurityCheckType_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexSecurityCheckType_Code"`
    );
    await queryRunner.query(`DROP TABLE "securitychecktypes"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'securitychecktype'`
    );
  }
}
