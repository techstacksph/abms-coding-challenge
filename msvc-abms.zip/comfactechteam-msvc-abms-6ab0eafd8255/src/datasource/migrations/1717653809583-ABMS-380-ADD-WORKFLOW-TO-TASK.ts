import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

export class ABMS380ADDWORKFLOWTOTASK1717653809583
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'task'`
    );

    if (module.length > 0) {
      const task = module[0];
      const moduleId = task.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('Task', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );
      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = 'Task' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('Task', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );
        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = 'Task' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const values: Array<string> = [];
          const actions = [
            'Complete',
            'Cancel',
            'Add note',
            'Send email',
            'Send SMS',
            'Log a call',
            'Add Task',
            'Create Deal',
            'Attach Documents',
            'Resend Notification',
          ];

          actions.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

          if (workflowActions.length) {
            const status = [
              { actions: ['Complete', 'Cancel'], name: 'Open' },
              { name: 'Completed' },
              { name: 'Cancelled' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                await queryRunner.query(`
                  INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actions}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
                  INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
              );

            if (workflowStatuses.length > 0) {
              const completeAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Complete'`
                );
              if (completeAction.length > 0) {
                const completeId = completeAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Completed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${completeId}'`
                  );
                }
              }
              const cancelAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Cancel'`
                );
              if (cancelAction.length > 0) {
                const cancelId = cancelAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Cancelled'
                );
                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${cancelId}'`
                  );
                }
              }
            }
          }
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = 'Task'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = 'Task'`
    );
    await queryRunner.query(`DELETE FROM "workflows" WHERE "name" = 'Task'`);
  }
}
