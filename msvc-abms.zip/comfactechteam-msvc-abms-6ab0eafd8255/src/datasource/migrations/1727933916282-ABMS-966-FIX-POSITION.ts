import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS966FIXPOSITION1727933916282 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE positions
            ALTER COLUMN code DROP NOT NULL;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE positions
            ALTER COLUMN code SET NOT NULL;
        `);
  }
}
