import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSHOTFIXSALESORDERFIELDS1740587782509
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const columnExists = await queryRunner.hasColumn(
      'salesorder',
      'totalAmountGSTExclfusive'
    );
    if (columnExists) {
      await queryRunner.query(`
                ALTER TABLE salesorder 
                RENAME COLUMN "totalAmountGSTExclfusive" TO "totalAmountGSTExclusive"
            `);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const columnExists = await queryRunner.hasColumn(
      'salesorder',
      'totalAmountGSTExclusive'
    );
    if (columnExists) {
      await queryRunner.query(`
                ALTER TABLE salesorder 
                RENAME COLUMN "totalAmountGSTExclusive" TO "totalAmountGSTExclfusive"
            `);
    }
  }
}
