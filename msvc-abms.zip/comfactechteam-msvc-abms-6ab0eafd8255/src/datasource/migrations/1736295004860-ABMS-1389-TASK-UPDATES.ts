import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1389TASKUPDATES1736295004860 implements MigrationInterface {
  name = 'ABMS1389TASKUPDATES1736295004860';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "allDay" boolean DEFAULT false`
    );
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code NOT IN (${MODULES.join(
        ','
      )})`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code NOT IN (${MODULES.join(
        ','
      )})`
    );
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "allDay"`);
  }
}
