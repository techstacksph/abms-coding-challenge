import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS365ADDPOPUPREMINDERFIELD1724028207885
  implements MigrationInterface
{
  name = 'ABMS365ADDPOPUPREMINDERFIELD1724028207885';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "popupReminder" numeric DEFAULT '15'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "popupReminder"`);
  }
}
