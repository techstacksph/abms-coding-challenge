import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS266MICROSOFTACCOUNTMODULE1742446998658
  implements MigrationInterface
{
  name = 'ABMS266MICROSOFTACCOUNTMODULE1742446998658';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "microsoftaccounts" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "accessToken" character varying, "refreshToken" character varying, "tokenExpirationDate" TIMESTAMP, "email" character varying, "purpose" character varying, "userId" uuid, CONSTRAINT "PK_ea93cf5861edddabbcc45595b63" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexMicrosoftAccount_Email" ON "microsoftaccounts" ("email") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("name", "code", "orgId") VALUES ('Microsoft Account', 'microsoftaccount', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'other'`);

    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexMicrosoftAccount_Email"`
    );
    await queryRunner.query(`DROP TABLE "microsoftaccounts"`);
  }
}
