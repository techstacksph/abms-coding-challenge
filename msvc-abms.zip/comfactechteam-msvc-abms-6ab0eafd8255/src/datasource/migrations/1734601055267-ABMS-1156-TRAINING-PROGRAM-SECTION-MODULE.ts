import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1156TRAININGPROGRAMSECTIONMODULE1734601055267
  implements MigrationInterface
{
  name = 'ABMS1156TRAININGPROGRAMSECTIONMODULE1734601055267';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "trainingprogramsections" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "section" character varying, "description" character varying, "sectionId" character varying, "trainingProgramId" uuid, CONSTRAINT "PK_25aee1133ea4ec34b8c187a7aba" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('trainingprogramsection', 'Training Program Section', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'trainingprogramsection'`
    );
    await queryRunner.query(`DROP TABLE "trainingprogramsections"`);
  }
}
