import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2682InvoiceTemplateJobsTabBE1744130878300
  implements MigrationInterface
{
  name = 'ABMS2682InvoiceTemplateJobsTabBE1744130878300';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "jobs" ADD "invoiceTemplateId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "jobs" DROP COLUMN "invoiceTemplateId"`
    );
  }
}
