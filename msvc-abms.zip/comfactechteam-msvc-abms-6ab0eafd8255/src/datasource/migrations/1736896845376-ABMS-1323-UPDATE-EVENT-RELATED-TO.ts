import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1323UPDATEEVENTRELATEDTO1736896845376
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = false WHERE code NOT IN (${MODULES.join(
        ','
      )})`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = true WHERE code IN (${MODULES.join(
        ','
      )})`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULES: Array<string> = [
      "'account'",
      "'case'",
      "'deal'",
      "'job'",
      "'training'",
      "'lead'",
    ];
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = true WHERE code NOT IN (${MODULES.join(
        ','
      )})`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = false WHERE code IN (${MODULES.join(
        ','
      )})`
    );
  }
}
