import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1996REVIEWPERIODMODULE1739250778831
  implements MigrationInterface
{
  name = 'ABMS1996REVIEWPERIODMODULE1739250778831';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "reviewperiods" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "title" citext NOT NULL, "notes" character varying, "exPending" boolean DEFAULT false, "document1" character varying, "document2" character varying, "document3" character varying, "document4" character varying, "document5" character varying, "startDate" TIMESTAMP NOT NULL, "endEmployee" TIMESTAMP NOT NULL, "lookOutEmployee" TIMESTAMP NOT NULL, "endManager" TIMESTAMP NOT NULL, "lookOutManager" TIMESTAMP NOT NULL, "remindersBegin" TIMESTAMP NOT NULL, "overallScore" numeric(10,2) DEFAULT '0', "weightedScore" character varying DEFAULT 'YES', "performanceReviewId" uuid, CONSTRAINT "PK_b884b82960f55eeb3e768ddd4f2" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexReviewPeriod_Title" ON "reviewperiods" ("title") WHERE "deletedAt" IS NULL`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'reviewperiod'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('reviewperiod', 'Performance Review', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'reviewperiod'`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexReviewPeriod_Title"`
    );
    await queryRunner.query(`DROP TABLE "reviewperiods"`);
  }
}
