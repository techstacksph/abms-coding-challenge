import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2282REMOVEUNIQUE1743581350749 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "UniqueIndexAuditTrail_ModuleName_RecordId"`
    );
    await queryRunner.query(`DROP INDEX "UniqueIndexAuditTrail_CreatedAt"`);

    await queryRunner.query(
      `CREATE INDEX "IndexAuditTrail_ModuleName_RecordId" ON "audit_trails" ("moduleName", "recordId")`
    );
    await queryRunner.query(
      `CREATE INDEX "IndexAuditTrail_CreatedAt" ON "audit_trails" ("createdAt")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "IndexAuditTrail_ModuleName_RecordId"`);
    await queryRunner.query(`DROP INDEX "IndexAuditTrail_CreatedAt"`);

    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAuditTrail_ModuleName_RecordId" ON "audit_trails" ("moduleName", "recordId")`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAuditTrail_CreatedAt" ON "audit_trails" ("createdAt")`
    );
  }
}
