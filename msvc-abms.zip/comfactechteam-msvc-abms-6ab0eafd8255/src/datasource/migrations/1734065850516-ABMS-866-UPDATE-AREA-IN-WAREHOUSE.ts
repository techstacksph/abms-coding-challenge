import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS866UPDATEAREAINWAREHOUSE1734065850516
  implements MigrationInterface
{
  name = 'ABMS866UPDATEAREAINWAREHOUSE1734065850516';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "warehouses" DROP COLUMN "area"`);
    await queryRunner.query(`ALTER TABLE "warehouses" ADD "areaId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "warehouses" DROP COLUMN "areaId"`);
    await queryRunner.query(
      `ALTER TABLE "warehouses" ADD "area" character varying`
    );
  }
}
