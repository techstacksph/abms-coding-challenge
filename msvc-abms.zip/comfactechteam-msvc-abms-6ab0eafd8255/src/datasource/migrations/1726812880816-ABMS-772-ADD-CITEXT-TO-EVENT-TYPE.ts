import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS772ADDCITEXTTOEVENTTYPE1726812880816
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "eventtypes" ALTER COLUMN "name" TYPE citext;`
    );
    await queryRunner.query(
      `ALTER TABLE "eventtypes" ALTER COLUMN "code" TYPE citext;`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "eventtypes" ALTER COLUMN "name" TYPE character varying;`
    );
    await queryRunner.query(
      `ALTER TABLE "eventtypes" ALTER COLUMN "code" TYPE character varying;`
    );
  }
}
