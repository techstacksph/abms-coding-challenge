import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1904UPDATEPERFORMANCEREVIEW1737960539046
  implements MigrationInterface
{
  name = 'ABMS1904UPDATEPERFORMANCEREVIEW1737960539046';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviews" ADD "employeeId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviews" ADD "managerId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviews" DROP COLUMN "managerId"`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviews" DROP COLUMN "employeeId"`
    );
  }
}
