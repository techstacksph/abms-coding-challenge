import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS26UPDATELOCATIONFIELD1715914777550
  implements MigrationInterface
{
  name = 'ABMS26UPDATELOCATIONFIELD1715914777550';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" RENAME COLUMN "countryId" TO "countryCode"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "countryCode"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "countryCode" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "countryCode"`
    );
    await queryRunner.query(`ALTER TABLE "locations" ADD "countryCode" uuid`);
    await queryRunner.query(
      `ALTER TABLE "locations" RENAME COLUMN "countryCode" TO "countryId"`
    );
  }
}
