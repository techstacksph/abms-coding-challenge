import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMSJOBFORSALE1739171191452 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobforsales" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "jobId" uuid, "cleaningTime" TIME DEFAULT '17:30:00', "availabilityDate" TIMESTAMP, "monthlyIncome" numeric(10,2), "outrightFee" numeric(10,2), "installmentFee" numeric(10,2), "addInfo" text, CONSTRAINT "PK_b2bbb1524ca0f2d761d5cdc2246" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `CREATE TABLE "job_franchisee" ("jobforsalesId" uuid NOT NULL, "franchiseeId" uuid NOT NULL, CONSTRAINT "PK_8394e70078e270fe8b2f6ccf1a1" PRIMARY KEY ("jobforsalesId", "franchiseeId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_296bc60a3965eabcd978ee3392" ON "job_franchisee" ("jobforsalesId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_69e715d829affd3814095f6ade" ON "job_franchisee" ("franchiseeId") `
    );

    await queryRunner.query(`ALTER TABLE "leaves" ADD COLUMN "approver" TEXT`);

    const jobFranchisee = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'jobfranchisee'`
    );

    if (jobFranchisee.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobfranchisee', 'Job Franchisee', '${TestIds.ORGANIZATION_ID}')`
      );
    }

    const jobForSale = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'jobforsale'`
    );

    if (jobForSale.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobforsale', 'Job For Sale', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "IDX_69e715d829affd3814095f6ade"`
    );
    await queryRunner.query(
      `DROP INDEX IF EXISTS "IDX_296bc60a3965eabcd978ee3392"`
    );

    await queryRunner.query(`DROP TABLE IF EXISTS "job_franchisee"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "jobforsales"`);

    await queryRunner.query(`DELETE FROM "modules" WHERE code = 'jobforsale'`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE code = 'jobfranchisee'`
    );
  }
}
