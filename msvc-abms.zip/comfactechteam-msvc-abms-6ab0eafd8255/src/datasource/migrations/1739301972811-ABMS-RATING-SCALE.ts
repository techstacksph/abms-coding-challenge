import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSRATINGSCALE1739301972811 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ratingscales" DROP COLUMN "status"`);
    await queryRunner.query(
      `ALTER TABLE "ratingscales" ADD COLUMN "rating" INTEGER NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ratingscales" DROP COLUMN "rating"`);
    await queryRunner.query(
      `ALTER TABLE "ratingscales" ADD COLUMN "status" TYPE BOOLEAN`
    );
  }
}
