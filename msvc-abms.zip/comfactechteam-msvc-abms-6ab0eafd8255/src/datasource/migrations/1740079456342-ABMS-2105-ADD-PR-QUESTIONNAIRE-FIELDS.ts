import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2105ADDPRQUESTIONNAIREFIELDS1740079456342
  implements MigrationInterface
{
  name = 'ABMS=2105ADDPRQUESTIONNAIREFIELDS1740079456342';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestions" ADD "questionId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestions" ADD "questionnaireId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestions" DROP COLUMN "questionnaireId"`
    );
    await queryRunner.query(
      `ALTER TABLE "performancereviewquestions" DROP COLUMN "questionId"`
    );
  }
}
