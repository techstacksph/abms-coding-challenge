import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1332EVENTSBE1732158943173 implements MigrationInterface {
  name = ' ABMS1332EVENTSBE1732158943173';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "eventrecurring" ADD "taskId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "statusNotes" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "statusNotes"`);
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "taskId"`
    );
  }
}
