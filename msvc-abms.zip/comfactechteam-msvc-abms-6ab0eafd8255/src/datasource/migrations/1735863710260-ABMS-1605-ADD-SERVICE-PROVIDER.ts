import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1605ADDSERVICEPROVIDER1735863710260
  implements MigrationInterface
{
  name = 'ABMS1605ADDSERVICEPROVIDER1735863710260';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobdetails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "jobId" uuid, "serviceProviderId" uuid, "area" citext NOT NULL, "frequency" character varying NOT NULL, "notes" citext NOT NULL, "dealOrderDetailsId" uuid, CONSTRAINT "PK_7e65b25c0aa9ecdb009d69cc5fc" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "jobspecifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "jobId" uuid NOT NULL, "jobDetailsId" uuid NOT NULL, "dealSpecificationId" uuid NOT NULL, "specifications" citext NOT NULL, "time" TIME NOT NULL DEFAULT '17:30:00', "variantsId" uuid NOT NULL, CONSTRAINT "PK_ec308f64cc1c510987f6a067278" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "serviceproviderassignments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "jobSpecificationId" uuid NOT NULL, "serviceProviderId" uuid, "days" citext NOT NULL, CONSTRAINT "PK_a6357a64a59d9737b59a93ad5b7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobdetails', 'Job Details', '${TestIds.ORGANIZATION_ID}')`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobspecifications', 'Job Specifications', '${TestIds.ORGANIZATION_ID}')`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('serviceproviderassignments', 'Service Provider Assignments', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "serviceproviderassignments"`);
    await queryRunner.query(`DROP TABLE "jobspecifications"`);
    await queryRunner.query(`DROP TABLE "jobdetails"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'jobdetails'`
    );
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'jobspecifications'`
    );
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'serviceproviderassignments'`
    );
  }
}
