import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1189DROPUNIQUEINDEXFORITEMS1729228629449
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "public"."UniqueIndexItem_Name"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await null;
  }
}
