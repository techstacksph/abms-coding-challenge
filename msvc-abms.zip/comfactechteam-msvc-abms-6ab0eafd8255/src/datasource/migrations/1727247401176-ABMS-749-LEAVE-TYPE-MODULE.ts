import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS749LEAVETYPEMODULE1727247401176 implements MigrationInterface {
  name = 'ABMS749LEAVETYPEMODULE1727247401176';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "leavetypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_09efe523e7a5558ee1e63a635d7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexLeaveType_Code" ON "leavetypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexLeaveType_Name" ON "leavetypes" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('leavetype', 'Leave Type', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexLeaveType_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexLeaveType_Code"`);
    await queryRunner.query(`DROP TABLE "leavetypes"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'leavetype'`);
  }
}
