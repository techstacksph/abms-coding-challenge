import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1571ADDFIELDSCOMMLOGS1732849364032
  implements MigrationInterface
{
  name = 'ABMS1571ADDFIELDSCOMMLOGS1732849364032';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "from" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "fromEmail" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "bodyEmailPreview" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "bodyEmailPreview"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "fromEmail"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "from"`
    );
  }
}
