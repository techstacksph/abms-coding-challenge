import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1237ADDAGREEMENTIDTOACTIVITY1734447960255
  implements MigrationInterface
{
  name = 'ABMS1237ADDAGREEMENTIDTOACTIVITY1734447960255';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" ADD "agreementId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "agreementId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "agreementId"`
    );
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "agreementId"`);
  }
}
