import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS900PRICELISTMODULE1727743338286 implements MigrationInterface {
  name = 'ABMS900PRICELISTMODULE1727743338286';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "pricelists" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "description" character varying, "startDate" TIMESTAMP NOT NULL, "endDate" TIMESTAMP, "locationId" uuid, "isDefault" boolean DEFAULT false, "isActive" boolean DEFAULT false, CONSTRAINT "PK_f6086a54a739eb1b8cd6cf352f4" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexPriceList_Name" ON "pricelists" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('pricelist', 'Price List', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'pricelist'`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexPriceList_Name"`);
    await queryRunner.query(`DROP TABLE "pricelists"`);
  }
}
