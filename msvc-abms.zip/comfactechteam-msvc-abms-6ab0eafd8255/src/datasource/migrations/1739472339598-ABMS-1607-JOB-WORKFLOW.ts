import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

export class ABMS1607JOBWORKFLOW1739472339598 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Job';
    const MODULE_CODE = 'job';
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const jobModule = module[0];
      const moduleId = jobModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('Recurring', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('One-off', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId_I = workflowProcess[0].id;
          const workflowProcessId_II = workflowProcess[1].id;
          let values: Array<string> = [];
          const actions_I = [
            'Allocate',
            'Set job for sale',
            'Complete',
            'Cancel',
            'Set job for sale',
            'Reschedule job',
            'Transfer job',
            'Hold job',
            'Set job cancellation',
            'Setup invoice',
            'Setup invoice template',
            'Setup credit/debitnote',
            'Restart invoice',
            'Add to invoice template',
            'Add to invoice',
            'Update commission and amount',
            'Transfer key supervisor / key account',
            'Set up invoice',
            'Set up invoice',
            'Revert to allocated job',
            'Update commission and amount',
            'Set up invoice',
            'Revert to allocated job',
          ];

          actions_I.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId_I}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          values = [];

          const actions_II = [
            'Allocate',
            'Set job for sale',
            'Complete',
            'Cancel',
            'Setup invoice',
            'Setup credit/debitnote',
            'Add to invoice',
            'Update commission and amount',
            'Transfer key supervisor / key account',
          ];

          actions_II.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId_II}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions_wfI: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}'`
            );

          const workflowActions_wfII: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_II}'`
            );

          if (workflowActions_wfI.length) {
            const status = [
              { actions: ['Allocate', 'Set job for sale'], name: 'Created' },
              {
                actions: [
                  'Complete',
                  'Cancel',
                  'Set job for sale',
                  'Reschedule job',
                  'Transfer job',
                  'Hold job',
                  'Set job cancellation',
                  'Setup invoice',
                  'Setup invoice template',
                  'Setup credit/debitnote',
                  'Restart invoice',
                  'Add to invoice template',
                  'Add to invoice',
                  'Update commission and amount',
                  'Transfer key supervisor / key account',
                ],
                name: 'Allocated',
              },
              { actions: ['Set up invoice'], name: 'Cancel' },
              {
                actions: [
                  'Set up invoice',
                  'Revert to allocated job',
                  'Update commission and amount',
                ],
                name: 'On hold',
              },
              {
                actions: ['Set up invoice', 'Revert to allocated job'],
                name: 'Complete',
              },
              { name: 'Completed' },
              { name: 'Cancelled' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                const actionIds = workflowActions_wfI
                  .filter((action) => actions.includes(action.name))
                  .map((action) => action.id)
                  .join(',');

                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actionIds}', '${workflowProcessId_I}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId_I}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses_I: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId_I}'`
              );

            if (workflowStatuses_I.length > 0) {
              const allocateAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}' AND name = 'Allocate'`
                );

              if (allocateAction.length > 0) {
                const qualifyId = allocateAction[0].id;
                const nextStatus = workflowStatuses_I.find(
                  (a: WorkflowStatusModel) => a.name == 'Allocated'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }

              const completeAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}' AND name = 'Complete'`
                );

              if (completeAction.length > 0) {
                const qualifyId = completeAction[0].id;
                const nextStatus = workflowStatuses_I.find(
                  (a: WorkflowStatusModel) => a.name == 'Completed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }

              const cancelAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}' AND name = 'Cancel'`
                );

              if (cancelAction.length > 0) {
                const qualifyId = cancelAction[0].id;
                const nextStatus = workflowStatuses_I.find(
                  (a: WorkflowStatusModel) => a.name == 'Cancelled'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }

              const onHoldAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}' AND name = 'Hold job'`
                );

              if (onHoldAction.length > 0) {
                const qualifyId = onHoldAction[0].id;
                const nextStatus = workflowStatuses_I.find(
                  (a: WorkflowStatusModel) => a.name == 'On Hold'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }
            }
          }

          if (workflowActions_wfII.length) {
            const status = [
              { actions: ['Allocate', 'Set job for sale'], name: 'Created' },
              {
                actions: [
                  'Complete',
                  'Cancel',
                  'Setup invoice',
                  'Setup credit/debitnote',
                  'Restart invoice',
                  'Add to invoice',
                  'Update commission and amount',
                  'Transfer key supervisor / key account',
                ],
                name: 'Allocate',
              },
              { actions: ['Set up invoice'], name: 'Cancel' },
              {
                actions: ['Set up invoice', 'Revert to allocated job'],
                name: 'Complete',
              },
              { name: 'Completed' },
              { name: 'Cancelled' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                const actionIds = workflowActions_wfII
                  .filter((action) => actions.includes(action.name))
                  .map((action) => action.id)
                  .join(',');

                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actionIds}', '${workflowProcessId_II}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
                      INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId_II}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses_II: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId_II}'`
              );

            if (workflowStatuses_II.length > 0) {
              const completeAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_II}' AND name = 'Complete'`
                );

              if (completeAction.length > 0) {
                const qualifyId = completeAction[0].id;
                const nextStatus = workflowStatuses_II.find(
                  (a: WorkflowStatusModel) => a.name == 'Completed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }

              const cancelAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId_I}' AND name = 'Cancel'`
                );

              if (cancelAction.length > 0) {
                const qualifyId = cancelAction[0].id;
                const nextStatus = workflowStatuses_II.find(
                  (a: WorkflowStatusModel) => a.name == 'Cancelled'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${qualifyId}'`
                  );
                }
              }
            }
          }
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Job';
    const MODULE_CODE = 'job';

    const module: Array<{ id: string }> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length > 0) {
      const moduleId = module[0].id;

      const workflows: Array<{ id: string }> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflows.length > 0) {
        const workflowId = workflows[0].id;

        const workflowProcesses: Array<{ id: string }> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE "workflowId" = '${workflowId}'`
          );

        if (workflowProcesses.length > 0) {
          for (const process of workflowProcesses) {
            const workflowProcessId = process.id;

            // Delete workflow actions
            await queryRunner.query(
              `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

            // Delete workflow statuses
            await queryRunner.query(
              `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

            // Delete workflow processes
            await queryRunner.query(
              `DELETE FROM "workflowprocesses" WHERE id = '${workflowProcessId}'`
            );
          }
        }

        // Delete the workflow itself
        await queryRunner.query(
          `DELETE FROM "workflows" WHERE id = '${workflowId}'`
        );
      }
    }
  }
}
