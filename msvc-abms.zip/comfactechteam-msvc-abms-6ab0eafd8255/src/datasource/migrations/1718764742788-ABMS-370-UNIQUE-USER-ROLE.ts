import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS370UNIQUEUSERROLE1718764742788 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "userroles" ALTER COLUMN "role" TYPE citext;
        `);

    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "UniqueIndexUserRole_Name" ON "userroles" ("role") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
                ALTER TABLE "userroles" ALTER COLUMN "role" TYPE character varying;
            `);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexUserRole_Name"`);
  }
}
