import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1388DROPTASKMODULE1736217983448 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "tasks"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "tasks" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "subject" character varying NOT NULL, "description" character varying, "dueDate" TIMESTAMP NOT NULL, "willSendEmail" boolean DEFAULT false, "willSendSMS" boolean DEFAULT false, "willSendReminder" boolean DEFAULT false, "relatedToId" uuid NOT NULL, "locationId" uuid, "accountId" uuid, "companyId" uuid, "leadId" uuid, "dealId" uuid, "campaignId" uuid, "jobId" uuid, "qualityAuditId" uuid, "caseId" uuid, "invoiceId" uuid, "billId" uuid, "evaluationId" uuid, "trainingId" uuid, "purchaseOrderId" uuid, "salesOrderId" uuid, "recruitmentId" uuid, "eventId" uuid, "taskRecurrenceId" uuid, "statusId" uuid, "taskTypeId" uuid, "allDay" boolean DEFAULT false, "frequency" text, CONSTRAINT "PK_8d12ff38fcc62aaba2cab748772" PRIMARY KEY ("id"))`
    );
  }
}
