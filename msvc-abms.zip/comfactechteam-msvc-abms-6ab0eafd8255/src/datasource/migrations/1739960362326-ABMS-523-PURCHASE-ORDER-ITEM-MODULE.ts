import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

const MODULE_CODE = 'purchaseorderitem';

export class ABMS523PURCHASEORDERITEMMODULE1739960362326
  implements MigrationInterface
{
  name = 'ABMS523PURCHASEORDERITEMMODULE1739960362326';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "purchaseorderitems" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "purchaseOrderId" uuid NOT NULL, "referenceId" uuid, "soldToId" uuid, "itemId" uuid NOT NULL, "uomId" uuid, "quantity" integer NOT NULL DEFAULT '0', "unitPrice" numeric NOT NULL DEFAULT '0', "amount" numeric NOT NULL DEFAULT '0', "drQuantity" integer DEFAULT '0', "backOrderQuantity" integer DEFAULT '0', "deliveryDate" TIMESTAMP, "lineNo" integer NOT NULL DEFAULT '0', "statusId" uuid NOT NULL, "platformId" integer, CONSTRAINT "PK_70509a2f074f036c79db67522d8" PRIMARY KEY ("id"))`
    );

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module?.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', 'Purchase Order Item', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${MODULE_CODE}'`
    );
    await queryRunner.query(`DROP TABLE "purchaseorderitems"`);
  }
}
