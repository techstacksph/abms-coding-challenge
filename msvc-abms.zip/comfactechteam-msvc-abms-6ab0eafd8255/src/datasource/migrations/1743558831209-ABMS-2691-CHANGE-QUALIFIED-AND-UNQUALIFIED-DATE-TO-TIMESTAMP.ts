import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2691CHANGEQUALIFIEDANDUNQUALIFIEDDATETOTIMESTAMP1743558831209
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Change qualifiedDate from date to timestamp
    await queryRunner.query(
      `ALTER TABLE "leads" ALTER COLUMN "qualifiedDate" TYPE timestamp`
    );

    // Change unqualifiedDate from date to timestamp
    await queryRunner.query(
      `ALTER TABLE "leads" ALTER COLUMN "unqualifiedDate" TYPE timestamp`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Revert qualifiedDate back to date
    await queryRunner.query(
      `ALTER TABLE "leads" ALTER COLUMN "qualifiedDate" TYPE date`
    );

    // Revert unqualifiedDate back to date
    await queryRunner.query(
      `ALTER TABLE "leads" ALTER COLUMN "unqualifiedDate" TYPE date`
    );
  }
}
