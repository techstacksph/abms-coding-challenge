import { MigrationInterface, QueryRunner } from 'typeorm';

export class AMBS2539InvoiceActivitiesTabBE1744030588269
  implements MigrationInterface
{
  name = 'AMBS2539InvoiceActivitiesTabBE1744030588269';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" ADD "invoiceId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "invoiceId"`);
  }
}
