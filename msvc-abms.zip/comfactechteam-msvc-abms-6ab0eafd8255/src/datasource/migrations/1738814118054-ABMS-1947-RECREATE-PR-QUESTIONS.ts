import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1947RECREATEPRQUESTIONS1738814118054
  implements MigrationInterface
{
  name = 'ABMS1947RECREATEPRQUESTIONS1738814118054';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "performancereviewquestions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "performanceReviewId" uuid NOT NULL, "ratingId" uuid NOT NULL, "comment" character varying, CONSTRAINT "PK_1710b8e6b8f0fc6e7a242494b61" PRIMARY KEY ("id"))`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'performancereviewquestion'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('performancereviewquestion', 'Performance Review Question', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "performancereviewquestions"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'performancereviewquestion'`
    );
  }
}
