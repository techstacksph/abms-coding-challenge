import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS663ADDUNIQUECONSTRAINTTOCODE1726646056368
  implements MigrationInterface
{
  name = 'ABMS663ADDUNIQUECONSTRAINTTOCODE1726646056368';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDocumentType_Code" ON "documenttypes" ("code") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexDocumentType_Code"`
    );
  }
}
