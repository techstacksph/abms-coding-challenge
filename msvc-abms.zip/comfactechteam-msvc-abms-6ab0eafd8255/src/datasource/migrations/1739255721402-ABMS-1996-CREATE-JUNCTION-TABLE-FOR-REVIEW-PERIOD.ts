import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1996CREATEJUNCTIONTABLEFORREVIEWPERIOD1739255721402
  implements MigrationInterface
{
  name = 'ABMS1996CREATEJUNCTIONTABLEFORREVIEWPERIOD1739255721402';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "reviewperiodemployees" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "employeeId" uuid, "reviewPeriodId" uuid, CONSTRAINT "PK_6529ea74a051b65d3f731ecbd93" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "reviewperiodquestionnaires" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "questionnaireId" uuid, "reviewPeriodId" uuid, CONSTRAINT "PK_9a815a62a82d3b870c3ba9ff020" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "reviewperiodquestionnaires"`);
    await queryRunner.query(`DROP TABLE "reviewperiodemployees"`);
  }
}
