import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1792UPDATELOCATION1737999813203 implements MigrationInterface {
  name = 'ABMS1792UPDATELOCATION1737999813203';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "locations" ADD "platformId" integer`);
    await queryRunner.query(`ALTER TABLE "locations" ADD "countryId" uuid`);
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "areaId"`);
    await queryRunner.query(`ALTER TABLE "locations" ADD "areaId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "billingAccountId"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "billingAccountId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ALTER COLUMN "weeklyIncome" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" ALTER COLUMN "weeklyIncome" SET NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "billingAccountId"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "billingAccountId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "areaId"`);
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "areaId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "countryId"`);
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "platformId"`);
  }
}
