import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1442COMMLOGSETRECIPIENTNULL1731994544237
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ALTER COLUMN "recipient" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ALTER COLUMN "recipient" SET NOT NULL DEAULT ''`
    );
  }
}
