import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXDEALSORDERFIELDSNULL1744011144324
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "deal_order_details"
                ALTER COLUMN "area" DROP NOT NULL,
                ALTER COLUMN "quantity" DROP NOT NULL,
                ALTER COLUMN "amount" DROP NOT NULL,
                ALTER COLUMN "days" DROP NOT NULL,
                ALTER COLUMN "minimumCharge" DROP NOT NULL,
                ALTER COLUMN "profitMargin" DROP NOT NULL,
                ALTER COLUMN "dailyAmount" DROP NOT NULL,
                ALTER COLUMN "weeklyAmount" DROP NOT NULL,
                ALTER COLUMN "added" DROP NOT NULL;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "deal_order_details"
                ALTER COLUMN "area" SET NOT NULL,
                ALTER COLUMN "quantity" SET NOT NULL,
                ALTER COLUMN "amount" SET NOT NULL,
                ALTER COLUMN "days" SET NOT NULL,
                ALTER COLUMN "minimumCharge" SET NOT NULL,
                ALTER COLUMN "profitMargin" SET NOT NULL,
                ALTER COLUMN "dailyAmount" SET NOT NULL,
                ALTER COLUMN "weeklyAmount" SET NOT NULL,
                ALTER COLUMN "added" SET NOT NULL;
        `);
  }
}
