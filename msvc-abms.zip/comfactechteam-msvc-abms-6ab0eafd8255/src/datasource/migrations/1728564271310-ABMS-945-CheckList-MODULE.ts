import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS945CheckListMODULE1728564271310 implements MigrationInterface {
  name = 'ABMS945CheckListMODULE1728564271310';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "checklistinformations" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "description" character varying, CONSTRAINT "PK_3543c97b708ed814397706e2e82" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexCheckListInformation_Name" ON "checklistinformations" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE TABLE "checklists" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "checklist" citext NOT NULL, "description" character varying, "checkListInformationId" uuid, "checkListId" uuid, CONSTRAINT "PK_336ade2047f3d713e1afa20d2c6" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('checklists', 'Checklists', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "checklists"`);
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexCheckListInformation_Name"`
    );
    await queryRunner.query(`DROP TABLE "checklistinformations"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'checklists'`
    );
  }
}
