import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS25ADDUPDATEDBYNAMECOLUMN1711941758847
  implements MigrationInterface
{
  name = 'ABMS25ADDUPDATEDBYNAMECOLUMN1711941758847';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "updatedByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "updatedByName"`
    );
  }
}
