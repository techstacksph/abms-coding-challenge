import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

const MODULE_NAME = 'Purchase Order';
const MODULE_CODE = 'purchaseorder';

export class ABMS523PURCHASEORDERWORKFLOW1740045032238
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length > 0) {
      const purchaseOrderModule = module[0];
      const moduleId = purchaseOrderModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${MODULE_NAME}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const values: Array<string> = [];
          const actions = [
            'Approve',
            'Sent to supplier',
            'Partially delivered',
            'Delivered',
            'Rejected',
            'Cancelled',
            'Create delivery',
            'Create return',
            'Reviewed',
            'Log a call',
            'Send SMS',
            'Send email',
            'Create a task',
            'Create an event',
            'Add note',
            'Attach documents',
          ];

          actions.forEach((val) => {
            values.push(
              `('${val}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`
            );
          });

          await queryRunner.query(
            `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ${values.join(
              ','
            )}`
          );

          const workflowActions: Array<WorkflowActionModel> =
            await queryRunner.query(
              `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
            );

          if (workflowActions.length > 0) {
            const status = [
              {
                actions: ['Approve'],
                name: 'Created',
              },
              {
                actions: ['Sent to supplier'],
                name: 'Approved',
              },
              {
                actions: [
                  'Partially delivered',
                  'Delivered',
                  'Rejected',
                  'Cancelled',
                ],
                name: 'Sent to supplier',
              },
              {
                actions: ['Create delivery'],
                name: 'Partially delivered',
              },
              {
                actions: ['Create return'],
                name: 'Delivered',
              },
              { name: 'Returned' },
              { name: 'Cancelled' },
              { name: 'Rejected' },
              {
                actions: ['Reviewed'],
                name: 'Review in-progress',
              },
              { name: 'Reviewed' },
            ];

            status.forEach(async (data) => {
              const { name, actions } = data;
              if (actions) {
                await queryRunner.query(`
									INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actions}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              } else {
                await queryRunner.query(`
									INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
              }
            });

            const workflowStatuses: Array<WorkflowStatusModel> =
              await queryRunner.query(
                `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
              );

            if (workflowStatuses.length > 0) {
              const approveAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Approve'`
                );

              if (approveAction.length > 0) {
                const approveActionId = approveAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Approved'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${approveActionId}'`
                  );
                }
              }

              const sentToSupplierAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Sent to supplier'`
                );

              if (sentToSupplierAction.length > 0) {
                const sentToSupplierActionId = sentToSupplierAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Sent to supplier'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${sentToSupplierActionId}'`
                  );
                }
              }

              const partiallyDeliveredAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Partially delivered'`
                );

              if (partiallyDeliveredAction.length > 0) {
                const partiallyDeliveredActionId =
                  partiallyDeliveredAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Partially delivered'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${partiallyDeliveredActionId}'`
                  );
                }
              }

              const deliveredAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Delivered'`
                );

              if (deliveredAction.length > 0) {
                const deliveredActionId = deliveredAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Delivered'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${deliveredActionId}'`
                  );
                }
              }

              const rejectedAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Rejected'`
                );

              if (rejectedAction.length > 0) {
                const rejectedActionId = rejectedAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Rejected'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${rejectedActionId}'`
                  );
                }
              }

              const cancelledAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Cancelled'`
                );

              if (cancelledAction.length > 0) {
                const cancelledActionId = cancelledAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Cancelled'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${cancelledActionId}'`
                  );
                }
              }

              // PARTIALLY DELIVERED IS THE NEXT STATUS SINCE IT WILL BE ONLY SET TO "DELIVERED" ONCE ITEMS ARE ALL DELIVERED
              const createDeliveryAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Create delivery'`
                );

              if (createDeliveryAction.length > 0) {
                const createDeliveryActionId = createDeliveryAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Partially delivered'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${createDeliveryActionId}'`
                  );
                }
              }

              const createReturnAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Create return'`
                );

              if (createReturnAction.length > 0) {
                const createReturnActionId = createReturnAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Returned'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${createReturnActionId}'`
                  );
                }
              }

              const reviewedAction: Array<WorkflowActionModel> =
                await queryRunner.query(
                  `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}' AND name = 'Reviewed'`
                );

              if (reviewedAction.length > 0) {
                const reviewedActionId = reviewedAction[0].id;
                const nextStatus = workflowStatuses.find(
                  (a: WorkflowStatusModel) => a.name == 'Reviewed'
                );

                if (nextStatus) {
                  await queryRunner.query(
                    `UPDATE "workflowactions" SET "nextStatusId" = '${nextStatus.id}' WHERE "id"='${reviewedActionId}'`
                  );
                }
              }
            }
          }
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );

    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }

    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${MODULE_NAME}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${MODULE_NAME}'`
    );
  }
}
