import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS614EVENTRECURRINGMODULE1724225405104
  implements MigrationInterface
{
  name = 'ABMS614EVENTRECURRINGMODULE1724225405104';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "eventrecurring" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "eventId" uuid NOT NULL, "startDate" character varying NOT NULL, "endDate" character varying, "freqInt" character varying, "days" character varying, "date" character varying, "weekOrder" character varying, "dayWeek" character varying, "month" character varying, "yearly" character varying, "custom" character varying, CONSTRAINT "PK_dbc2439f100f1595e443e9a9135" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('eventrecurring', 'Event Recurring', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "eventrecurring"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'eventrecurring'`
    );
  }
}
