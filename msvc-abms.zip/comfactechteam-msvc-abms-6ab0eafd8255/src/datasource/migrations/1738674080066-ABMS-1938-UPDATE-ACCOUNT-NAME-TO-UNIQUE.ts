import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1938UPDATEACCOUNTNAMETOUNIQUE1738674080066
  implements MigrationInterface
{
  name = 'ABMS1938UPDATEACCOUNTNAMETOUNIQUE1738674080066';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "name" TYPE citext`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAccount_Name" ON "accounts" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "name" TYPE character varying`
    );
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexAccount_Name"`);
  }
}
