import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS853DOCUMENTTEMPLATEMODULE1739243852908
  implements MigrationInterface
{
  name = 'ABMS853DOCUMENTTEMPLATEMODULE1739243852908';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "documenttemplates" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "documentTypeId" uuid, "description" character varying, "file1" character varying NOT NULL, "file2" character varying, "file3" character varying, "file4" character varying, "file5" character varying, CONSTRAINT "PK_204b89ca416bba37e45a2632e62" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDocument_Name" ON "documenttemplates" ("name") WHERE "deletedAt" IS NULL`
    );

    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'documenttemplate'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('documenttemplate', 'Document Template', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'documenttemplate'`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexDeals_DocumentName"`
    );
    await queryRunner.query(`DROP TABLE "documenttemplates"`);
  }
}
