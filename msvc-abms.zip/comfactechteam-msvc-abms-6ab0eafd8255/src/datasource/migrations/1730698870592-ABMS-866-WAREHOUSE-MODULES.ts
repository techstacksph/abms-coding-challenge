import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS866WAREHOUSEMODULES1730698870592
  implements MigrationInterface
{
  name = 'ABMS866WAREHOUSEMODULES1730698870592';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "warehouses" ADD "locationId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" DROP COLUMN "locationId"`
    );
  }
}
