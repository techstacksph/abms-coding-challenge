import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSADDPAYMENTTERMSRELATEDITEM1741919936906
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE deal_order_details
            ADD COLUMN "relatedItemId" UUID NULL
        `);

    await queryRunner.query(`
        ALTER TABLE deals
        ADD COLUMN "serviceTypeId" UUID NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE deal_order_details
            DROP COLUMN "relatedItemId"
        `);

    await queryRunner.query(`
        ALTER TABLE deals
        DROP COLUMN "serviceTypeId"
    `);
  }
}
