import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1100DEALMODULES1730647334016 implements MigrationInterface {
  name = 'ABMS1100DEALMODULES1730647334016';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexDeal_No"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDeal_No" ON "deals" ("dealNo") WHERE ("deletedAt" IS NULL)`
    );
  }
}
