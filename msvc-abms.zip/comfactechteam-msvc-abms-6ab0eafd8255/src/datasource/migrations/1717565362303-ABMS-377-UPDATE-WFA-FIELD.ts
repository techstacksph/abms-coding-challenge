import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS377UPDATEWFAFIELD1717565362303 implements MigrationInterface {
  name = 'ABMS377UPDATEWFAFIELD1717565362303';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" RENAME COLUMN "workflowActionId" TO "workflowActionIds"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" DROP COLUMN "workflowActionIds"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" ADD "workflowActionIds" text`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" DROP COLUMN "workflowActionIds"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" ADD "workflowActionIds" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" RENAME COLUMN "workflowActionIds" TO "workflowActionId"`
    );
  }
}
