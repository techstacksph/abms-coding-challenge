import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS23CREATELOCATION1710845503244 implements MigrationInterface {
  name = 'ABMS23CREATELOCATION1710845503244';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "locations" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "name" character varying NOT NULL, "description" character varying, "streetAddress" character varying, "suburb" character varying, "city" character varying, "area" character varying, "region" character varying, "postalCode" character varying, "country" text DEFAULT 'New Zealand', "parentLocationId" uuid, "userIds" text, CONSTRAINT "PK_7cc1c9e3853b94816c094825e74" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexUser_Name" ON "locations" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexUser_Name"`);
    await queryRunner.query(`DROP TABLE "locations"`);
  }
}
