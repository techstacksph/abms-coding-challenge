import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1124CREATERECRUITMENT1737053561367
  implements MigrationInterface
{
  name = 'ABMS1124CREATERECRUITMENT1737053561367';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "rRecruitments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "recruitmentNo" citext, "contactId" uuid NOT NULL, "companyName" text, "date" date NOT NULL DEFAULT ('now'::text)::date, "type" text, "franchiseeType" text, "accountId" uuid, "agreementId" uuid, "salesPrice" double precision NOT NULL, "sourceId" uuid, "rating" character varying, "notes" text, "locationId" uuid NOT NULL, "recordOwnerId" uuid NOT NULL, "questionnaireId" uuid, "statusId" uuid NOT NULL, "closeDate" date, CONSTRAINT "PK_60ec4a388294352eb5ac9633eb7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "recruitment_servicetypes" ("recruitmentId" uuid NOT NULL, "serviceTypeId" uuid NOT NULL, CONSTRAINT "PK_b66348bde5987cbc209196801de" PRIMARY KEY ("recruitmentId", "serviceTypeId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_f513214833e577b8a6c2bd2278" ON "recruitment_servicetypes" ("recruitmentId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_a2d8875495e6abf6406e4d278f" ON "recruitment_servicetypes" ("serviceTypeId") `
    );
    await queryRunner.query(
      `ALTER TABLE "franchiseeagreements" ADD "generatedRecruitmentId" uuid`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'recruitment'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('recruitment', 'Recruitment', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseeagreements" DROP COLUMN "generatedRecruitmentId"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_a2d8875495e6abf6406e4d278f"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_f513214833e577b8a6c2bd2278"`
    );
    await queryRunner.query(`DROP TABLE "recruitment_servicetypes"`);
    await queryRunner.query(`DROP TABLE "rRecruitments"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'recruitment'`
    );
  }
}
