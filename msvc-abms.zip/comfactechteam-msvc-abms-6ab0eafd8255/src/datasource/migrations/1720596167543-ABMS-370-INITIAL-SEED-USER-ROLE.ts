import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS370INITIALSEEDUSERROLE1720596167543
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const roleExists = await queryRunner.query(
      `SELECT 1 FROM "userroles" WHERE "id"='${TestIds.ADMIN_USER_ROLE_ID}'`
    );

    if (roleExists.length === 0) {
      await queryRunner.query(
        `
          INSERT INTO "userroles"
          ("id", "orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "updatedByName", "role", "description") 
          VALUES 
          ('${TestIds.ADMIN_USER_ROLE_ID}', '${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT , DEFAULT, DEFAULT, 'Administrator', 'This is an administrator role')
        `
      );
    } else {
      await queryRunner.query(
        `
          UPDATE "userroles"
          SET 
            "orgId" = '${TestIds.ORGANIZATION_ID}',
            "updatedAt" = DEFAULT,
            "deletedAt" = DEFAULT,
            "createdBy" = '${TestIds.PERSON_ID}',
            "updatedBy" = DEFAULT,
            "deletedBy" = DEFAULT,
            "recordLocked" = DEFAULT,
            "lockedBy" = DEFAULT,
            "timeLocked" = DEFAULT,
            "updatedByName" = DEFAULT,
            "role" = 'Administrator',
            "description" = 'This is an administrator role'
          WHERE "id" = '${TestIds.ADMIN_USER_ROLE_ID}'
        `
      );
    }

    // ATTACH ADMIN USER ROLE TO EXISTING USERS
    await queryRunner.query(
      `UPDATE "users" SET "roleId" = '${TestIds.ADMIN_USER_ROLE_ID}'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`UPDATE "users" SET "roleId" = NULL`);
    await queryRunner.query(
      `DELETE FROM "userroles" WHERE "id"='${TestIds.ADMIN_USER_ROLE_ID}'`
    );
  }
}
