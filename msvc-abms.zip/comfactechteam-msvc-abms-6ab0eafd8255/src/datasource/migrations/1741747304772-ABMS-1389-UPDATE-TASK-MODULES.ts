import { MigrationInterface, QueryRunner } from 'typeorm';

const codes = [
  "'account'",
  "'case'",
  "'deal'",
  "'job'",
  "'qualityaudit'",
  "'salesorder'",
  "'purchaseorder'",
  "'evaluation'",
  "'recruitment'",
  "'training'",
  "'lead'",
  "'invoice'",
  "'bill'",
];
export class ABMS1389UPDATETASKMODULES1741747304772
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code IN (${codes.join(
        ','
      )});`
    );
    await queryRunner.query(
      `UPDATE "modules" SET name = 'Purchase Order' WHERE code = 'purchaseorder'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code IN (${codes.join(
        ','
      )})`
    );
    await queryRunner.query(
      `UPDATE "modules" SET name = 'Purchase Order Item' WHERE code = 'purchaseorder'`
    );
  }
}
