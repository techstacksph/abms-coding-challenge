import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS214ADDFIELDSTOUSER1716771127925 implements MigrationInterface {
  name = 'ABMS214ADDFIELDSTOUSER1716771127925';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ADD "roleId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "groupId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "lastLoginDateTime" TIMESTAMP`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "lastLoginDateTime"`
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "groupId"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "roleId"`);
  }
}
