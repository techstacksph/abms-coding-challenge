import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1008DEALUNIQUEINDEX1730912133292
  implements MigrationInterface
{
  name = 'ABMS1008DEALUNIQUEINDEX1730912133292';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDeals_Dealname" ON "deals" ("dealname") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexDeals_Dealname"`);
  }
}
