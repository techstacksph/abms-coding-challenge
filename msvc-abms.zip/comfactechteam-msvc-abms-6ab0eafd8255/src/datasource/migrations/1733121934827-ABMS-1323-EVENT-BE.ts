import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1323EVENTBE1733121934827 implements MigrationInterface {
  name = ' ABMS1323EVENTBE1733121934827';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "relatedTo"`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD COLUMN IF NOT EXISTS "relatedToId" uuid NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "relatedToId"`);
    await queryRunner.query(`ALTER TABLE "events" ADD "relatedTo" uuid`);
  }
}
