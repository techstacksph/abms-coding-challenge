import { MigrationInterface, QueryRunner } from 'typeorm';

export class PRFILTER1740709387863 implements MigrationInterface {
  name = 'PRFILTER1740709387863';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviews" ADD "departmentNames" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "performancereviews" ALTER COLUMN "autoNumber" SET NOT NULL`
    );
  }
}
