import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1250ADDEMPLOYEEINPUT1738566083250
  implements MigrationInterface
{
  name = 'ABMS1250ADDEMPLOYEEINPUT1738566083250';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" ADD "employeeId" uuid NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "agreementsandcontracts" DROP COLUMN "employeeId"`
    );
  }
}
