import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS252ALTERTASKMODULEFIELDRELATEDTO1720431305479
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "relatedToId"`);
    await queryRunner.query(`ALTER TABLE "tasks" ADD "relatedToId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "relatedToId"`);
  }
}
