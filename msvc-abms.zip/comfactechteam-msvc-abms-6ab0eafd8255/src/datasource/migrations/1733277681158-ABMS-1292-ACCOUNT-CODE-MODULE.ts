import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

export class ABMS1292ACCOUNTCODEMODULE1733277681158
  implements MigrationInterface
{
  name = 'ABMS1292ACCOUNTCODEMODULE1733277681158';
  code = 'accountcode';
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "accountcodes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "accountCode" citext, "accountName" citext NOT NULL, "code" citext NOT NULL, "description" character varying, "accountCategory" character varying NOT NULL, "accountType" character varying NOT NULL, CONSTRAINT "PK_e06ecb05985b436428febfdb8e8" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAccountCode_Code" ON "accountcodes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAccountCode_AccountName" ON "accountcodes" ("accountName") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAccountCode_AccountCode" ON "accountcodes" ("accountCode") WHERE "deletedAt" IS NULL`
    );

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${this.code}'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${this.code}', 'Account Code', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${this.code}'`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAccountCode_AccountCode"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAccountCode_AccountName"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAccountCode_Code"`
    );
    await queryRunner.query(`DROP TABLE "accountcodes"`);
  }
}
