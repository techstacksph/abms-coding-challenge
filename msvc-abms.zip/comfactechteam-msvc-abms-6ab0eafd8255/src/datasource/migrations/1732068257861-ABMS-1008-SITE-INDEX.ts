import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1008SITEINDEX1732068257861 implements MigrationInterface {
  name = 'ABMS1008SITEINDEX1732068257861';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "site" DROP COLUMN "primaryContactId"`
    );
    await queryRunner.query(`ALTER TABLE "site" ADD "primaryContactId" uuid`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSite_Name" ON "site" ("siteName") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_007faee701235662a9463c2f4e" ON "sms_franchisee" ("smsId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_c2839d166ef8d391281853208c" ON "sms_franchisee" ("franchiseeId") `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexSite_Name"`);
    await queryRunner.query(
      `ALTER TABLE "site" DROP COLUMN "primaryContactId"`
    );
    await queryRunner.query(
      `ALTER TABLE "site" ADD "primaryContactId" character varying`
    );
  }
}
