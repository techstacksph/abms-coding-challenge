import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1108SMSMANYTOMANTMODULES1730192101514
  implements MigrationInterface
{
  name = 'ABMS1108SMSMANYTOMANTMODULES1730192101514';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "sms_franchisee" ("smsId" uuid NOT NULL, "franchiseeId" uuid NOT NULL, CONSTRAINT "PK_935d85002761dfb870d85af3a34" PRIMARY KEY ("smsId", "franchiseeId"))`
    );
    await queryRunner.query(`ALTER TABLE "sms" DROP COLUMN "franchiseeId"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "sms_franchisee"`);
    await queryRunner.query(
      `ALTER TABLE "sms" ADD "franchiseeId" uuid NOT NULL`
    );
  }
}
