import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS997JOBM2MRELATIONS1734055851721 implements MigrationInterface {
  name = 'ABMS997JOBM2MRELATIONS1734055851721';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobowners" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "ownerId" uuid, "jobId" uuid, CONSTRAINT "PK_5c2811593608d0a2269c00cd544" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "jobserviceproviders" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "serviceProviderId" uuid, "jobId" uuid, CONSTRAINT "PK_78c66d050fa04dd80a2bf19af19" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "jobserviceproviders"`);
    await queryRunner.query(`DROP TABLE "jobowners"`);
  }
}
