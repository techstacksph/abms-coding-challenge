import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2282ADDRELATIONSHIPBETWEENAUDITTRAILANDMODULE1743652840688
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "IndexAuditTrail_ModuleName_RecordId"`
    );
    await queryRunner.query(
      `ALTER TABLE "audit_trails" RENAME COLUMN "moduleName" TO "moduleId"`
    );
    await queryRunner.query(`
            ALTER TABLE "audit_trails"
            ALTER COLUMN "moduleId" TYPE uuid USING "moduleId"::uuid
        `);
    await queryRunner.query(`
            ALTER TABLE "audit_trails" 
            ADD CONSTRAINT "FK_audit_trails_module" 
            FOREIGN KEY ("moduleId") 
            REFERENCES "modules"("id") 
            ON DELETE NO ACTION 
            ON UPDATE NO ACTION
        `);
    await queryRunner.query(`
            CREATE INDEX "IndexAuditTrail_ModuleId_RecordId" 
            ON "audit_trails" ("moduleId", "recordId")
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "IndexAuditTrail_ModuleId_RecordId"`
    );
    await queryRunner.query(
      `ALTER TABLE "audit_trails" DROP CONSTRAINT IF EXISTS "FK_audit_trails_module"`
    );
    await queryRunner.query(`
            ALTER TABLE "audit_trails"
            ALTER COLUMN "moduleId" TYPE character varying
        `);
    await queryRunner.query(
      `ALTER TABLE "audit_trails" RENAME COLUMN "moduleId" TO "moduleName"`
    );
    await queryRunner.query(`
            CREATE INDEX "IndexAuditTrail_ModuleName_RecordId" 
            ON "audit_trails" ("moduleName", "recordId")
        `);
  }
}
