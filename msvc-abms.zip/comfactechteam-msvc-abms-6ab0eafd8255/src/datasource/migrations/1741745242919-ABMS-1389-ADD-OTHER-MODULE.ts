import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1389ADDOTHERMODULE1741745242919 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "modules" ("name", "code", "orgId", "isIncludedInEvent", "isIncludedInTask") VALUES ('Other', 'other', '${TestIds.ORGANIZATION_ID}', true, true)`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'other'`);
  }
}
