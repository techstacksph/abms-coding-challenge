import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS690ADDCITEXTTODOCUMENTANDTASKTYPE1726743909083
  implements MigrationInterface
{
  name = 'ABMS690ADDCITEXTTODOCUMENTANDTASKTYPE1726743909083';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttypes" ALTER COLUMN "name" TYPE citext;`
    );
    await queryRunner.query(
      `ALTER TABLE "documenttypes" ALTER COLUMN "code" TYPE citext;`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" ALTER COLUMN "name" TYPE citext;`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" ALTER COLUMN "code" TYPE citext;`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttypes" ALTER COLUMN "name" TYPE character varying;`
    );
    await queryRunner.query(
      `ALTER TABLE "documenttypes" ALTER COLUMN "code" TYPE character varying;`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" ALTER COLUMN "name" TYPE character varying;`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" ALTER COLUMN "code" TYPE character varying;`
    );
  }
}
