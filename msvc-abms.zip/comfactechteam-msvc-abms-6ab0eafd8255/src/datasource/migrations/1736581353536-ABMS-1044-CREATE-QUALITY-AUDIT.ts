import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1044CREATEQUALITYAUDIT1736581353536
  implements MigrationInterface
{
  name = 'ABMS1044CREATEQUALITYAUDIT1736581353536';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "qualityaudits" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "qaNo" character varying, "locationId" uuid NOT NULL, "jobNo" uuid NOT NULL, "recordOwnerId" uuid NOT NULL, "statusId" uuid NOT NULL, "qaScore" double precision, "auditMonth" TIMESTAMP NOT NULL, "customerNotes" character varying, "franchiseeNotes" character varying, "rectificationDate" TIMESTAMP, "meetWithCustomer" boolean DEFAULT false, "reasonForNotMeeting" character varying, "whoDidYouMeet" character varying, CONSTRAINT "PK_33f179e9ff7edf244d5b3439da9" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('qualityaudit', 'Quality Audit', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "qualityaudits"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'qualityaudit'`
    );
  }
}
