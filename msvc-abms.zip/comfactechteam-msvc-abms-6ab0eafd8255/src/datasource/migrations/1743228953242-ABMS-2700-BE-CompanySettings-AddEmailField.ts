import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2700BECompanySettingsAddEmailField1743228953242
  implements MigrationInterface
{
  name = 'ABMS2700BECompanySettingsAddEmailField1743228953242';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "email" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "email"`
    );
  }
}
