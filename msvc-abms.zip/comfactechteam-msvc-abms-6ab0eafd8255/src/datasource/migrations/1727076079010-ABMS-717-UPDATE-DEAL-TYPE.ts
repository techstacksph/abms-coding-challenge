import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS717UPDATEDEALTYPE1727076079010 implements MigrationInterface {
  name = 'ABMS717UPDATEDEALTYPE1727076079010';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "dealtypes" ALTER COLUMN "name" TYPE citext;`
    );
    await queryRunner.query(
      `ALTER TABLE "dealtypes" ALTER COLUMN "code" TYPE citext;`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDealType_Code" ON "dealtypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDealType_Name" ON "dealtypes" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexDealType_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexDealType_Code"`);
    await queryRunner.query(
      `ALTER TABLE "dealtypes" ALTER COLUMN "name" TYPE character varying;`
    );
    await queryRunner.query(
      `ALTER TABLE "dealtypes" ALTER COLUMN "code" TYPE character varying;`
    );
  }
}
