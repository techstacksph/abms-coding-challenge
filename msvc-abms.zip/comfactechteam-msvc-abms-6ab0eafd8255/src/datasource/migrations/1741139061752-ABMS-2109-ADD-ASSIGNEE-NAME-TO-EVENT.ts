import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2109ADDASSIGNEENAMETOEVENT1741139061752
  implements MigrationInterface
{
  name = 'ABMS2109ADDASSIGNEENAMETOEVENT1741139061752';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "assigneeNames" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "assigneeNames"`);
  }
}
