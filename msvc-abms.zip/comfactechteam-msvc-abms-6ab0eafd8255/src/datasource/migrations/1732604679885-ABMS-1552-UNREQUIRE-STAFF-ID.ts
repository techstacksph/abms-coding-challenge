import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1552UNREQUIRESTAFFID1732604679885
  implements MigrationInterface
{
  name = 'ABMS1552UNREQUIRESTAFFID1732604679885';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "securitycheck" ALTER COLUMN "staffId" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "securitycheck" ALTER COLUMN "staffId" SET NOT NULL`
    );
  }
}
