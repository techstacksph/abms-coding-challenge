import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2693ADDITIONALSERVICETYPEFIELDS1744046586983
  implements MigrationInterface
{
  name = 'ABMS2693ADDITIONALSERVICETYPEFIELDS1744046586983';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "servicetypes" ADD "salesAccountCodeId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" ADD "expenseAccountCodeId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" ADD "workType" character varying NOT NULL DEFAULT 'RECURRING'`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" ADD "minimumCharge" boolean DEFAULT false`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" ADD "profitMargin" boolean DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "servicetypes" DROP COLUMN "profitMargin"`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" DROP COLUMN "minimumCharge"`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" DROP COLUMN "workType"`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" DROP COLUMN "expenseAccountCodeId"`
    );
    await queryRunner.query(
      `ALTER TABLE "servicetypes" DROP COLUMN "salesAccountCodeId"`
    );
  }
}
