import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1466SITE1731652685500 implements MigrationInterface {
  name = 'ABMS1466SITE1731652685500';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "areaId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "smsId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "noteId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "documentId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "logcallId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "companyId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "lastActivityId"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "jobId"`);
    await queryRunner.query(`ALTER TABLE "site" ADD "accountId" uuid`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "countryId"`);
    await queryRunner.query(`ALTER TABLE "site" ADD "countryId" uuid`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "dealId"`);
    await queryRunner.query(`ALTER TABLE "site" ADD "dealId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "dealId"`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "dealId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "countryId"`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "countryId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "contactTypes"`
    );
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "accountId"`);
    await queryRunner.query(`ALTER TABLE "site" ADD "jobId" character varying`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "lastActivityId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "site" ADD "companyId" uuid NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "logcallId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "site" ADD "documentId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "noteId" character varying`
    );
    await queryRunner.query(`ALTER TABLE "site" ADD "smsId" character varying`);
    await queryRunner.query(
      `ALTER TABLE "site" ADD "areaId" character varying`
    );
  }
}
