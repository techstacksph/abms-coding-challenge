import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS13221732850517971 implements MigrationInterface {
  name = ' ABMS13221732850517971';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" RENAME COLUMN "recurrenceId" TO "recurringId"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" RENAME COLUMN "recurringId" TO "recurrenceId"`
    );
  }
}
