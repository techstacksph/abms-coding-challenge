import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS2263PAYMENTTERMS1741691193514 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "paymentterms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "code" citext, "paymentTerm" citext NOT NULL, "description" character varying, CONSTRAINT "PK_a372c9b0a1566717ec9f64cc23c" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexPaymentTerm_PaymentTerm" ON "paymentterms" ("paymentTerm") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexPaymentTerm_Code" ON "paymentterms" ("code") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('paymentterm', 'Payment Term', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "paymentterms"`);
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexPaymentTerm_Code"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexPaymentTerm_PaymentTerm"`
    );
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'paymentterm'`
    );
  }
}
