import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1970CREATEJUNCTIONTABLEFORRECRUITMENTINTERESTEDSERVICES1739181040485
  implements MigrationInterface
{
  name =
    'ABMS1970CREATEJUNCTIONTABLEFORRECRUITMENTINTERESTEDSERVICES1739181040485';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "recruitmentservicetypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "recruitmentId" uuid, "serviceTypeId" uuid, CONSTRAINT "PK_099728a129e6d734f5b68bf1ddd" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "recruitmentservicetypes"`);
  }
}
