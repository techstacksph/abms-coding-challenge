import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS699UPDATECONTACTTYPESMODULE1727055961521
  implements MigrationInterface
{
  name = 'ABMS699UPDATECONTACTTYPESMODULE1727055961521';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contacttype" DROP COLUMN "contactTypeName"`
    );
    await queryRunner.query(
      `ALTER TABLE "contacttype" ADD "name" citext NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "contacttype" ADD "code" citext`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexContactType_Code" ON "contacttype" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexContactType_Name" ON "contacttype" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexContactType_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexContactType_Code"`
    );
    await queryRunner.query(`ALTER TABLE "contacttype" DROP COLUMN "code"`);
    await queryRunner.query(`ALTER TABLE "contacttype" DROP COLUMN "name"`);
    await queryRunner.query(
      `ALTER TABLE "contacttype" ADD "contactTypeName" character varying NOT NULL`
    );
  }
}
