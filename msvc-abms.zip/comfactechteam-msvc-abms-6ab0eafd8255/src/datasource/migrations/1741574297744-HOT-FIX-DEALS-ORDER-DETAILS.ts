import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXDEALSORDERDETAILS1741574297744
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "deal_specifications" DROP COLUMN "relatedSpecificationId"'
    );
    await queryRunner.query(
      'ALTER TABLE "deal_specifications" ADD COLUMN "variantId" uuid'
    );
  }
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "deal_specifications" ADD "relatedSpecificationId" uuid'
    );
    await queryRunner.query(
      'ALTER TABLE "deal_specifications" DROP COLUMN "variantId"'
    );
  }
}
