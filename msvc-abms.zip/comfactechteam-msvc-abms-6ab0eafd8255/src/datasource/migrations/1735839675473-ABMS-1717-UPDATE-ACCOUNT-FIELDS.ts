import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1717UPDATEACCOUNTFIELDS1735839675473
  implements MigrationInterface
{
  name = 'ABMS1717UPDATEACCOUNTFIELDS1735839675473';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "subconAccountNo" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "subconType" character varying`
    );
    await queryRunner.query(`ALTER TABLE "accounts" ADD "areaId" uuid`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "dealId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "dealId"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "areaId"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "subconType"`);
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "subconAccountNo"`
    );
  }
}
