import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS258UPDATELOCATIONFIELD1717374179361
  implements MigrationInterface
{
  name = 'ABMS258UPDATELOCATIONFIELD1717374179361';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "areaId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "billingAccountId" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "billingAccountId"`
    );
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "areaId"`);
  }
}
