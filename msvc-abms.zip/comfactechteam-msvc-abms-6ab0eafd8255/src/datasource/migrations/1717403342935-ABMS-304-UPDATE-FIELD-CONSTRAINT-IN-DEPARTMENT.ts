import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS304UPDATEFIELDCONSTRAINTINDEPARTMENT1717403342935
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "departments" ALTER COLUMN "name" TYPE citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "departments" ALTER COLUMN "name" TYPE character varying`
    );
  }
}
