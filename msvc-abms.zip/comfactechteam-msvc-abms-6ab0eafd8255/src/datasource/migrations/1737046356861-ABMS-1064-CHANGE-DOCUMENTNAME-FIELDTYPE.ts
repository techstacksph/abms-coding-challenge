import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1064CHANGEDOCUMENTNAMEFIELDTYPE1737046356861
  implements MigrationInterface
{
  name = 'ABMS1064CHANGEDOCUMENTNAMEFIELDTYPE1737046356861';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "documents"`);
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "documentName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "documentName" citext NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "documentTypeName" citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "documents"`);
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "documentName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "documentTypeName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "documentName" character varying NOT NULL`
    );
  }
}
