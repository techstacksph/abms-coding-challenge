import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATEKIWISAVERDETAILS1737602713360
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "kiwisaverdetails" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "employeeId" uuid, "kiwiSaver" character varying, "employerContribution" double precision, "employerContributionPercentage" double precision, "from" date, "to" date, "optOutDate" date, "reasonForIneligibility" character varying, "notes" text, CONSTRAINT "PK_6ea7f5330e650565aa5ecb368cb" PRIMARY KEY ("id"))`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'kiwisaverdetails'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('kiwisaverdetails', 'Kiwisaver Details', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "kiwisaverdetails"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'kiwisaverdetails'`
    );
  }
}
