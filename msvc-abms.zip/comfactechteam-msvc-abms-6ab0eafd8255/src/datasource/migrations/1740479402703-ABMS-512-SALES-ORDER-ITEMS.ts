import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS512SALESORDERITEMS1740479402703 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "salesorderitem" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "salesorderId" uuid NOT NULL, "uomId" uuid NOT NULL, "quantity" integer NOT NULL, "amount" numeric(10,2), "stockonhand" integer, "drQuantityId" uuid, "backOrderQuantity" integer, "statusId" uuid, CONSTRAINT "PK_81606a209092f9ab34886ea1fc2" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `CREATE TABLE "salesorderitem_item" ("salesorderitemId" uuid NOT NULL, "itemId" uuid NOT NULL, CONSTRAINT "PK_9512496e09b569275c87a979922" PRIMARY KEY ("salesorderitemId", "itemId"))`
    );

    await queryRunner.query(
      `CREATE INDEX "IDX_aed4b4ec124083e1fbeef20c62" ON "salesorderitem_item" ("salesorderitemId") `
    );

    await queryRunner.query(
      `CREATE INDEX "IDX_6bdfcad5b23f8dd40b56df8773" ON "salesorderitem_item" ("itemId") `
    );

    const salesOrderItems = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'salesorderitem'`
    );

    if (salesOrderItems.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('salesorderitem', 'Sales Order Items', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "salesorderitem"`);
  }
}
