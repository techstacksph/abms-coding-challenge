import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS555WAREHOUSEMODULE1727433715807 implements MigrationInterface {
  name = 'ABMS555WAREHOUSEMODULE1727433715807';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "warehouses" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(), 
        "orgId" uuid, 
        "createdAt" TIMESTAMP NOT NULL DEFAULT now(), 
        "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), 
        "deletedAt" TIMESTAMP, 
        "createdBy" uuid, 
        "updatedBy" uuid, 
        "deletedBy" uuid, 
        "recordLocked" boolean NOT NULL DEFAULT false, 
        "lockedBy" uuid, 
        "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), 
        "updatedByName" character varying, 
        "name" varchar(100) NOT NULL, 
        "code"  character varying, 
        "description" text, 
        "address" character varying, 
        "streetAddress" character varying, 
        "suburb" character varying, 
        "city" character varying, 
        "area" character varying, 
        "region" character varying, 
        "postalcode" integer, 
        "country" character varying,
        CONSTRAINT "PK_warehouse_id" PRIMARY KEY ("id")
      )`
    );

    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexWarehouse_Code" ON "warehouses" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexWarehouse_Name" ON "warehouses" ("name") WHERE "deletedAt" IS NULL`
    );

    // Inserting into the modules table
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('warehouses', 'Warehouses', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexWarehouse_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexWarehouse_Code"`);
    await queryRunner.query(`DROP TABLE "warehouses"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'warehouses'`
    );
  }
}
