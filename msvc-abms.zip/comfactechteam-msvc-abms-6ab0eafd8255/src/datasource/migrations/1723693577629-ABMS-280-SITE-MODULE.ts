import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS280SITEMODULE1723693577629 implements MigrationInterface {
  name = 'ABMS280SITEMODULE1723693577629';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "site" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "siteName" character varying NOT NULL, "notes" character varying, "phone" character varying, "mobile" character varying, "email" character varying, "secondaryEmail" character varying, "companyId" uuid NOT NULL, "primaryContactId" character varying, "dealId" character varying, "jobId" character varying, "logcallId" character varying, "smsId" character varying, "noteId" character varying, "documentId" uuid, "lastActivityId" character varying, "findStreet" character varying, "streetAddress" character varying, "suburb" character varying, "city" character varying, "areaId" character varying, "region" character varying, "postalCode" character varying, "countryId" character varying, "viewlocation" character varying, "address" character varying, CONSTRAINT "PK_635c0eeabda8862d5b0237b42b4" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "site"`);
  }
}
