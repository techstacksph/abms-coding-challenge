import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS379TASKWATCHERMODULE1717650963303
  implements MigrationInterface
{
  name = 'ABMS379TASKWATCHERMODULE1717650963303';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "taskwatchers" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "watcherId" uuid, "taskId" uuid, CONSTRAINT "PK_7496caec36a43e2cefa875d26aa" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('taskwatcher', 'Task Watcher', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "taskwatchers"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'taskwatcher'`
    );
  }
}
