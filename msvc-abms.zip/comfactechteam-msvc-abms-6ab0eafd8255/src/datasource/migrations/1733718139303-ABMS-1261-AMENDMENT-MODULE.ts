import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

//wrong name
export class ABMS1261AMENDMENTMODULE1733718139303
  implements MigrationInterface
{
  name = 'ABMS1261AMENDMENTMODULE1733718139303';
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "amendments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "code" citext, "description" text, CONSTRAINT "PK_232751b4529e81fd8a6b2847ace" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAmendmentCode_AmendmentCode" ON "amendments" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexAmendmentName_AmendmentName" ON "amendments" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('amendments', 'Amendments', '${TestIds.ORGANIZATION_ID}')`
    );
  }
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAmendmentName_AmendmentName"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexAmendmentCode_AmendmentCode"`
    );
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'amendment'`);
    await queryRunner.query(`DROP TABLE "amendments"`);
  }
}
