import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1695ALTERSERVICETYPE1734501491420
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexServiceTypeName_ServiceTypeName"`
    );

    await queryRunner.query(
      `ALTER TABLE "servicetypes" RENAME COLUMN "serviceType" TO "servicetype"`
    );

    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexServiceTypeName_ServiceTypeName" ON "servicetypes" ("servicetype") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexServiceTypeName_ServiceTypeName"`
    );

    await queryRunner.query(
      `ALTER TABLE "servicetypes" RENAME COLUMN "servicetype" TO "serviceType"`
    );

    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexServiceTypeName_ServiceTypeName" ON "servicetypes" ("serviceType") WHERE "deletedAt" IS NULL`
    );
  }
}
