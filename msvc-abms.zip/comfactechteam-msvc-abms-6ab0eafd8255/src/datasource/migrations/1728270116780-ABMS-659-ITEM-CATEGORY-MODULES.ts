import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS659ITEMCATEGORYMODULES1728270116780
  implements MigrationInterface
{
  name = 'ABMS659ITEMCATEGORYMODULES1728270116780';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "itemcategories" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "code" citext, "autoNumber" SERIAL, "icno" character varying, "description" character varying, "active" boolean NOT NULL DEFAULT false, "franchisee" boolean NOT NULL DEFAULT false, "customer" boolean NOT NULL DEFAULT false, CONSTRAINT "PK_a018d64098bb905a9909885d6d8" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemCategory_Icno" ON "itemcategories" ("icno") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemCategory_Code" ON "itemcategories" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItemCategory_Name" ON "itemcategories" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('itemcategory', 'Item Category', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemCategory_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemCategory_Code"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexItemCategory_Icno"`
    );
    await queryRunner.query(`DROP TABLE "itemcategories"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'itemcategory'`
    );
  }
}
