import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1388RECREATETASKMODULE1736220389727
  implements MigrationInterface
{
  name = 'ABMS1388RECREATETASKMODULE1736220389727';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "tasks" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "taskTypeId" uuid NOT NULL, "taskSubject" character varying NOT NULL, "description" character varying, "popupReminder" character varying, "sendEmail" boolean DEFAULT false, "sendSMS" boolean DEFAULT false, "startDate" TIMESTAMP NOT NULL, "startTime" TIMESTAMP NOT NULL, "statusId" uuid, "statusNotes" character varying, "relatedToId" uuid, "accountId" uuid, "caseId" uuid, "dealId" uuid, "jobId" uuid, "qualityAuditId" uuid, "salesOrderId" uuid, "purchaseOrderId" uuid, "evaluationId" uuid, "recruitmentId" uuid, "trainingId" uuid, "leadId" uuid, "invoiceId" uuid, "billId" uuid, CONSTRAINT "PK_8d12ff38fcc62aaba2cab748772" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`ALTER TABLE "notes" ADD "taskId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "taskId"`);
    await queryRunner.query(`DROP TABLE "tasks"`);
  }
}
