import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const MODULE_CODE = 'pricelistitem';
const MODULE_NAME = 'Price list item';

export class ABMS2695PRICELISTITEMMODULE1744085504581
  implements MigrationInterface
{
  name = 'ABMS2695PRICELISTITEMMODULE1744085504581';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "pricelistitems" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "priceListId" uuid NOT NULL, "itemId" uuid NOT NULL, "amount" numeric(10,2) NOT NULL DEFAULT '0', "uomId" uuid, "minimumCharge" numeric(10,2) DEFAULT '0', "profitMargin" numeric(10,2) DEFAULT '0', CONSTRAINT "PK_8e4cbf52edd1a2c6f3abe3dbcd4" PRIMARY KEY ("id"))`
    );

    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', '${MODULE_NAME}', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${MODULE_CODE}'`
    );
    await queryRunner.query(`DROP TABLE "pricelistitems"`);
  }
}
