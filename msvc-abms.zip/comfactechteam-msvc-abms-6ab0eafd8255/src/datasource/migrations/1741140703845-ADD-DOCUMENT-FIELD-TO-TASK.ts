import { MigrationInterface, QueryRunner } from 'typeorm';

export class ADDDOCUMENTFIELDTOTASK1741140703845 implements MigrationInterface {
  name = 'ADDDOCUMENTFIELDTOTASK1741140703845';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documents" ADD "taskId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "taskId"`);
  }
}
