import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1392ADDTASKASSIGNEES1737419060313
  implements MigrationInterface
{
  name = 'ABMS1392ADDTASKASSIGNEES1737419060313';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "assigneeNames" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "assigneeNames"`);
  }
}
