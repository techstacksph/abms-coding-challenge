import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2425ADDEVENTRELATIONSHIPTOCOMMLOGS1742793036564
  implements MigrationInterface
{
  name = 'ABMS2425ADDEVENTRELATIONSHIPTOCOMMLOGS1742793036564';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "eventId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "eventId"`
    );
  }
}
