import { MigrationInterface, QueryRunner } from 'typeorm';

import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

export class ABMS1436HOTFIX1734445886866 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Contact';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(`
        DELETE FROM "workflowstatuses" 
        WHERE 
          "workflowProcessId" = '${workflowProcessId}'
        AND 
          "name" = 'undefined'
      `);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await null;
  }
}
