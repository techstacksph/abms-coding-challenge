import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS881UPDATEACCOUNTFIELDS1729058876206
  implements MigrationInterface
{
  name = 'ABMS881UPDATEACCOUNTFIELDS1729058876206';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "gst"`);
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "gst" character varying`
    );
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "nzbn"`);
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "nzbn" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "nzbn"`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "nzbn" numeric`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "gst"`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "gst" numeric`);
  }
}
