import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1137UpdateContactBE1730262295990
  implements MigrationInterface
{
  name = ' ABMS1137UpdateContactBE1730262295990';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "contactLeadId"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "contacts" ADD "contactLeadId" uuid`);
  }
}
