import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATEEMPLOYEE1737548400512 implements MigrationInterface {
  name = 'ABMS444CREATEEMPLOYEE1737548400512';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "employees" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "code" character varying, "firstName" character varying NOT NULL, "lastName" character varying NOT NULL, "title" character varying, "email" character varying NOT NULL, "phoneNo" character varying, "mobileNo" character varying, "statusId" uuid, "notes" character varying, "locationId" uuid, "departmentId" uuid, "profilePicture" character varying, "preferredName" character varying, "gender" character varying, "nationalityId" uuid, "dateOfBirth" date, "martialStatus" character varying, "citizenship" boolean, "medicalCondition" boolean, "streetAddress" text, "findAddress" text, "suburb" character varying, "city" character varying, "region" character varying, "postalCode" character varying, "countryId" uuid, "userId" uuid, "employmentType" character varying, "startDate" date, "terminationDate" date, "jobTitleId" uuid, "industryStandardJobTitleId" uuid, "probationLength" integer, "primaryManagerId" uuid, "secondaryManagerId" uuid, "workPhoneNo" character varying, "workMobileNo" character varying, "workEmail" character varying, CONSTRAINT "PK_b9535a98350d5b26e7eb0c26af4" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "employee_departments" ("employeeId" uuid NOT NULL, "departmentId" uuid NOT NULL, CONSTRAINT "PK_b9a075ddc05186e6e670aa160de" PRIMARY KEY ("employeeId", "departmentId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_35bd4eb56c8462bf27244ab254" ON "employee_departments" ("employeeId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_d514712ac27e17a6b3e2fb3cd6" ON "employee_departments" ("departmentId") `
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'employee'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('employee', 'Employee', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_d514712ac27e17a6b3e2fb3cd6"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_35bd4eb56c8462bf27244ab254"`
    );
    await queryRunner.query(`DROP TABLE "employee_departments"`);
    await queryRunner.query(`DROP TABLE "employees"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'employee'`);
  }
}
