import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS387ADDUNIQUEGROUPNAME1718093964316
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "groups" ALTER COLUMN "name" TYPE citext;
        `);

    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "IndexUniqueGroup_Name" ON "groups" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "groups" ALTER COLUMN "name" TYPE character varying;
        `);
    await queryRunner.query(`DROP INDEX "public"."IndexUniqueGroup_Name"`);
  }
}
