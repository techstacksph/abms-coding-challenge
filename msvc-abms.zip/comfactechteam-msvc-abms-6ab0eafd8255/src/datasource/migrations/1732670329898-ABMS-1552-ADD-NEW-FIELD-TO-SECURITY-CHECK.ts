import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1552ADDNEWFIELDTOSECURITYCHECK1732670329898
  implements MigrationInterface
{
  name = 'ABMS1552ADDNEWFIELDTOSECURITYCHECK1732670329898';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "securitychecks" ADD "name" character varying NOT NULL DEFAULT ''`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "securitychecks" DROP COLUMN "name"`);
  }
}
