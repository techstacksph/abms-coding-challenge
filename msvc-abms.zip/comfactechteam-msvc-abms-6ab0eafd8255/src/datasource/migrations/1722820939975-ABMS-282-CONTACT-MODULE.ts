import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS282CONTACTMODULE1722820939975 implements MigrationInterface {
  name = 'ABMS282CONTACTMODULE1722820939975';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "contacts" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "firstName" character varying NOT NULL, "lastName" character varying NOT NULL, "jobTitle" character varying NOT NULL, "notes" character varying, "phone" character varying, "mobile" character varying, "email" character varying NOT NULL, "secondaryEmail" character varying, "preferredMethodOfCommunication" character varying, "doNotContact" boolean, "contactTypeId" uuid, "contactAccountd" uuid, "contactCompanyId" uuid, "siteId" uuid, "dealId" uuid, "contactLeadId" uuid, "statusId" uuid, "streetAddress" character varying, "suburb" character varying, "city" character varying, "areaId" uuid, "region" character varying, "postalCode" character varying, "countryId" uuid, "viewlocation" character varying, "address" character varying, CONSTRAINT "PK_b99cd40cfd66a99f1571f4f72e6" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('contact', 'Contacts', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "contacts"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'contact'`);
  }
}
