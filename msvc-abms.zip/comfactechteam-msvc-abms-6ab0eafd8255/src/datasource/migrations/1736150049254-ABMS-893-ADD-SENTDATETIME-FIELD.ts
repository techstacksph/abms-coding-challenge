import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS893ADDSENTDATETIMEFIELD1736150049254
  implements MigrationInterface
{
  name = 'ABMS893ADDSENTDATETIMEFIELD1736150049254';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" ADD "sentDateTime" TIMESTAMP`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" DROP COLUMN "sentDateTime"`
    );
  }
}
