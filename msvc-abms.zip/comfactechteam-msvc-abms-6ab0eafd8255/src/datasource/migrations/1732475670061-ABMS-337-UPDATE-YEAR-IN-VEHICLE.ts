import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS337UPDATEYEARINVEHICLE1732475670061
  implements MigrationInterface
{
  name = 'ABMS337UPDATEYEARINVEHICLE1732475670061';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "vehicles" DROP COLUMN "year"`);
    await queryRunner.query(
      `ALTER TABLE "vehicles" ADD "year" integer NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "vehicles" DROP COLUMN "year"`);
    await queryRunner.query(
      `ALTER TABLE "vehicles" ADD "year" TIMESTAMP NOT NULL`
    );
  }
}
