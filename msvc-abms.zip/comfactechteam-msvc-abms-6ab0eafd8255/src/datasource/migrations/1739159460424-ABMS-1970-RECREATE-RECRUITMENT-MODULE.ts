import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1970RECREATERECRUITMENTMODULE1739159460424
  implements MigrationInterface
{
  name = 'ABMS1970RECREATERECRUITMENTMODULE1739159460424';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "recruitments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "recruitmentNo" character varying, "contactId" uuid NOT NULL, "companyName" character varying, "date" TIMESTAMP NOT NULL, "type" character varying, "franchiseeType" character varying, "accountId" uuid, "agreementId" uuid, "salesPrice" numeric(10,2) NOT NULL DEFAULT '0', "sourceId" uuid, "rating" character varying, "notes" text, "locationId" uuid NOT NULL, "recordOwnerId" uuid NOT NULL, "questionnaireId" uuid, "statusId" uuid NOT NULL, CONSTRAINT "PK_4e63272ea2bc161c08ba2257e87" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "recruitments"`);
  }
}
