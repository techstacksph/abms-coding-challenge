import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1102UPDATEDEALWORKFLOWSTATUS1733236623267
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Update workflowactions table
    await queryRunner.query(`
          UPDATE workflowactions
          SET name = CASE
            WHEN name = 'Mark as Pending' THEN 'Pending'
            WHEN name = 'Close as Lost' THEN 'Close Lost'
            WHEN name = 'Close as Won' THEN 'Close Won'
            ELSE name
          END
          WHERE "workflowProcessId" = (
            SELECT id FROM workflowprocesses
            WHERE name = 'Deal'
          );
        `);

    // Update workflowstatuses table
    await queryRunner.query(`
          UPDATE workflowstatuses
          SET name = CASE
            WHEN name = 'Close Won' THEN 'Closed Won'
            WHEN name = 'Close Lost' THEN 'Closed Lost'
            ELSE name
          END
          WHERE "workflowProcessId" = (
            SELECT id FROM workflowprocesses
            WHERE name = 'Deal'
          );
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Revert workflowactions table changes
    await queryRunner.query(`
          UPDATE workflowactions
          SET name = CASE
            WHEN name = 'Pending' THEN 'Mark as Pending'
            WHEN name = 'Close Lost' THEN 'Close as Lost'
            WHEN name = 'Close Won' THEN 'Close as Won'
            ELSE name
          END
          WHERE "workflowProcessId" = (
            SELECT id FROM workflowprocesses
            WHERE name = 'Deal'
          );
        `);

    // Revert workflowstatuses table changes
    await queryRunner.query(`
          UPDATE workflowstatuses
          SET name = CASE
            WHEN name = 'Closed Won' THEN 'Close Won'
            WHEN name = 'Closed Lost' THEN 'Close Lost'
            ELSE name
          END
          WHERE "workflowProcessId" = (
            SELECT id FROM workflowprocesses
            WHERE name = 'Deal'
          );
        `);
  }
}
