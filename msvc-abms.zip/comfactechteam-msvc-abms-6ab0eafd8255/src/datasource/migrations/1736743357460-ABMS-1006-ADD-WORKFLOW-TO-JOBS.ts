import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

export class ABMS1006ADDWORKFLOWTOJOBS1736743357460
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const moduleName = 'Job';
    const moduleCode = 'job';

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${moduleCode}'`
    );
    if (module.length > 0) {
      const job = module[0];
      const moduleId = job.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${moduleName}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );
      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${moduleName}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${moduleName}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );
        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${moduleName}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;

          const status = [
            { actions: ['Created', 'Allocated', 'Completed', 'Cancelled'] },
            { name: 'Created' },
            { name: 'Allocated' },
            { name: 'Completed' },
            { name: 'Cancelled' },
          ];

          status.forEach(async (data) => {
            const { name, actions } = data;
            if (actions) {
              await queryRunner.query(`
                            INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ('${name}', '${actions}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
            } else {
              await queryRunner.query(`
                            INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
            }
          });
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const moduleName = 'Job';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${moduleName}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${moduleName}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${moduleName}'`
    );
  }
}
