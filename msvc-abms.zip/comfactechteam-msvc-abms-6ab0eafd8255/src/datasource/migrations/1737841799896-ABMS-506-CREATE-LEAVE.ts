import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS506CREATELEAVE1737841799896 implements MigrationInterface {
  name = 'ABMS506CREATELEAVE1737841799896';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "leaves" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "leaveNo" character varying, "employeeId" uuid NOT NULL, "leaveTypeId" uuid NOT NULL, "dateFrom" date NOT NULL, "dateTo" date, "hours" integer, "locationId" uuid, "departmentId" uuid, "approverId" uuid, "reason" character varying, "statusId" uuid, "notes" character varying, "documentFile" character varying, CONSTRAINT "PK_4153ec7270da3d07efd2e11e2a7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "leave_departments" ("leaveId" uuid NOT NULL, "departmentId" uuid NOT NULL, CONSTRAINT "PK_e21a475f18d6c7ecc2a5a7824ea" PRIMARY KEY ("leaveId", "departmentId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_809dd342fe93b7bc563828e4cb" ON "leave_departments" ("leaveId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_2c9d781a4a403cf2d02faa09d6" ON "leave_departments" ("departmentId") `
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'leave'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('leave', 'Leave', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_2c9d781a4a403cf2d02faa09d6"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_809dd342fe93b7bc563828e4cb"`
    );
    await queryRunner.query(`DROP TABLE "leave_departments"`);
    await queryRunner.query(`DROP TABLE "leaves"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'leave'`);
  }
}
