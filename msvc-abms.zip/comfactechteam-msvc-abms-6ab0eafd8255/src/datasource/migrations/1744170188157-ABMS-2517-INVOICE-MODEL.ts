import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const MODULE_CODE = 'invoice';
const MODULE_NAME = 'Invoice';

export class ABMS2517INVOICEMODEL1744170188157 implements MigrationInterface {
  name = 'ABMS2517INVOICEMODEL1744170188157';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "invoices" ADD "autoNumber" SERIAL`);
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD CONSTRAINT "UQ_b34cddc52972c035c9ace828966" UNIQUE ("autoNumber")`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "invoiceNo" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD CONSTRAINT "UQ_1a94a2eb122d90baad7ca28f654" UNIQUE ("invoiceNo")`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "accountId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "billingAccountId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "contactId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "invoiceDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "dueDate" TIMESTAMP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "notes" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "locationId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD "xeroId" uuid NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "invoices" ADD "salesOrderId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "invoiceTemplateId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "subType" character varying`
    );
    await queryRunner.query(`ALTER TABLE "invoices" ADD "statusId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "xeroStatus" character varying DEFAULT 'DRAFT'`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "type" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "gstType" character varying NOT NULL DEFAULT 'TAX_EXCLUSIVE'`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "subtotal" numeric(10,2) NOT NULL DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "gstAmount" numeric(10,2) NOT NULL DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" ADD IF NOT EXISTS "totalAmount" numeric(10,2) NOT NULL DEFAULT '0'`
    );

    const invoices = await queryRunner.query(
      `SELECT id FROM "modules" WHERE "code" = 'invoice'`
    );
    if (invoices.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', '${MODULE_NAME}', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "totalAmount"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "gstAmount"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "subtotal"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "gstType"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "type"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "xeroStatus"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "statusId"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "subType"`);
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN "invoiceTemplateId"`
    );
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN "salesOrderId"`
    );
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "xeroId"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "locationId"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "notes"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "dueDate"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "invoiceDate"`);
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "contactId"`);
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP COLUMN "billingAccountId"`
    );
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "accountId"`);
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP CONSTRAINT "UQ_1a94a2eb122d90baad7ca28f654"`
    );
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "invoiceNo"`);
    await queryRunner.query(
      `ALTER TABLE "invoices" DROP CONSTRAINT "UQ_b34cddc52972c035c9ace828966"`
    );
    await queryRunner.query(`ALTER TABLE "invoices" DROP COLUMN "autoNumber"`);
  }
}
