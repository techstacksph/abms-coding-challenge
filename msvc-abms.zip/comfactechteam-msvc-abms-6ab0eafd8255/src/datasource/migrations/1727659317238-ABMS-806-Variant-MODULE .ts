import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS806VARIANTMODULE1727659317238 implements MigrationInterface {
  name = 'ABMS806VARIANTMODULE1727659317238';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create the 'variants' table with the specified fields
    await queryRunner.query(
      `CREATE TABLE "variants" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(), 
        "orgId" uuid, 
        "createdAt" TIMESTAMP NOT NULL DEFAULT now(), 
        "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), 
        "deletedAt" TIMESTAMP, 
        "createdBy" uuid, 
        "updatedBy" uuid, 
        "deletedBy" uuid, 
        "recordLocked" boolean NOT NULL DEFAULT false, 
        "lockedBy" uuid, 
        "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), 
        "updatedByName" character varying, 
        "code" citext NOT NULL, 
        "name" citext NOT NULL, 
        "description" character varying, 
        CONSTRAINT "PK_variants_id" PRIMARY KEY ("id")
      )`
    );

    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexVariants_Code" ON "variants" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexVariants_Name" ON "variants" ("name") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('variant', 'Variant', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexVariants_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexVariants_Code"`);

    await queryRunner.query(`DROP TABLE "variants"`);

    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'variant'`);
  }
}
