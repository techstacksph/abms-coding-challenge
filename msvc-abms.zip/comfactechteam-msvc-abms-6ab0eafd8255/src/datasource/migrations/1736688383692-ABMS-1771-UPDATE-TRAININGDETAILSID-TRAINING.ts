import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1771UPDATETRAININGDETAILSIDTRAINING1736688383692
  implements MigrationInterface
{
  name = 'ABMS1771UPDATETRAININGDETAILSIDTRAINING1736688383692';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "trainings" ALTER COLUMN "trainingDetailsId" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "trainings" ALTER COLUMN "trainingDetailsId" SET NOT NULL`
    );
  }
}
