import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1467SITENAMEUNIQUE1733210627811 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const indexExists = await queryRunner.query(`
      SELECT 1
      FROM pg_indexes
      WHERE schemaname = 'public'
      AND indexname = 'UniqueIndexSite_Name';
    `);

    if (indexExists.length === 0) {
      await queryRunner.query(`
        CREATE UNIQUE INDEX "UniqueIndexSite_Name"
        ON "site" ("siteName")
        WHERE "deletedAt" IS NULL;
      `);
    }

    const environment = process.env.NODE_ENV || 'development';
    const columnType = environment === 'test' ? 'text' : 'citext';

    await queryRunner.query(`
      ALTER TABLE site
      ALTER COLUMN "siteName" TYPE ${columnType}
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const environment = process.env.NODE_ENV || 'development';
    const columnType = environment === 'test' ? 'text' : 'citext';

    await queryRunner.query(`
      ALTER TABLE "site"
      ALTER COLUMN "siteName" TYPE ${columnType}
    `);

    await queryRunner.query(`
      DROP INDEX IF EXISTS "UniqueIndexSite_Name";
    `);
  }
}
