import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS23LOCATIONMODULE1715665434248 implements MigrationInterface {
  name = 'ABMS23LOCATIONMODULE1715665434248';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "area"`);
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "franchiseeGroupEmail" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "orderGroupEmail" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "costToBuyRate" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "commissionRate" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFee" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFeeLimit" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "collectionFee" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "royaltyFee" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "technologyFee" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "enablePayNow" boolean`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "salesTarget" numeric(10,2) DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "leadsTarget" integer`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "portalPaymarkUrl" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "portalPaymarkAccountId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "portalPaymarkUsername" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "portalPaymarkPassword" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFeePaymarkUrl" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFeePaymarkAccountId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFeePaymarkUsername" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "brandFeePaymarkPassword" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "brandFeePaymarkPassword"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "brandFeePaymarkUsername"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "brandFeePaymarkAccountId"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "brandFeePaymarkUrl"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "portalPaymarkPassword"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "portalPaymarkUsername"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "portalPaymarkAccountId"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "portalPaymarkUrl"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "leadsTarget"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "salesTarget"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "enablePayNow"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "technologyFee"`
    );
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "royaltyFee"`);
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "collectionFee"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "brandFeeLimit"`
    );
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "brandFee"`);
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "commissionRate"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "costToBuyRate"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "orderGroupEmail"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "franchiseeGroupEmail"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "area" character varying`
    );
  }
}
