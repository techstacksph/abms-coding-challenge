import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1389ADDCOMPLETEWITHNOTESTOTASK1741781865914
  implements MigrationInterface
{
  name = 'ABMS1389ADDCOMPLETEWITHNOTESTOTASK1741781865914';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "willCompleteWithNotes" boolean DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "tasks" DROP COLUMN "willCompleteWithNotes"`
    );
  }
}
