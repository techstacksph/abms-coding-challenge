import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const MODULE_CODE = 'companysetting';

export class ABMS231COMPANYSETTINGSMODULE1741148007393
  implements MigrationInterface
{
  name = 'ABMS231COMPANYSETTINGSMODULE1741148007393';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "companysettings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "companyName" citext NOT NULL, "tradingName" citext NOT NULL, "website" character varying, "phone" character varying, "companyLogo" character varying, "streetAddress" character varying, "suburb" character varying, "city" character varying, "areaId" uuid, "region" character varying, "postalcode" character varying, "countryId" uuid, CONSTRAINT "PK_c1433f39c75912dbe00a7445910" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexCompanySetting_TradingName" ON "companysettings" ("tradingName") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexCompanySetting_CompanyName" ON "companysettings" ("companyName") WHERE "deletedAt" IS NULL`
    );

    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', 'Company Setting', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${MODULE_CODE}'`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexCompanySetting_CompanyName"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexCompanySetting_TradingName"`
    );
    await queryRunner.query(`DROP TABLE "companysettings"`);
  }
}
