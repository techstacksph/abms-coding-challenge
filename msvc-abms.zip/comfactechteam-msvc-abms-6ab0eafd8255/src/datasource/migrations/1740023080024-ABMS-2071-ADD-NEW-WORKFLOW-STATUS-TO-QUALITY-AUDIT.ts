import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

const WORKFLOW_NAME = 'in_progress';
const MODULE_NAME = 'Quality Audit';
const MODULE_CODE = 'qualityaudit';

export class ABMS2071ADDNEWWORKFLOWSTATUSTOQUALITYAUDIT1740023080024
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const caseModule = module[0];
      const moduleId = caseModule.id;

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;
        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );
        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          await queryRunner.query(`
                        INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${WORKFLOW_NAME}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const caseModule = module[0];
      const moduleId = caseModule.id;

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;
        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );
        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          await queryRunner.query(
            `DELETE FROM "workflowstatuses" WHERE "name" = '${WORKFLOW_NAME}' and "workflowProcessId" = '${workflowProcessId}'`
          );
        }
      }
    }
  }
}
