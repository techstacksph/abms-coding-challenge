import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1008DEALDetailsMODULES1730890073661
  implements MigrationInterface
{
  name = 'ABMS1008DEALDetailsMODULES1730890073661';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "deal_order_details" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "itemId" uuid, "area" character varying(100) NOT NULL, "quantity" integer NOT NULL DEFAULT '1', "amount" numeric(10,2) NOT NULL DEFAULT '0', "duration" integer, "frequency" text, "days" integer DEFAULT '0', "notes" text, "minimumCharge" numeric(10,2) NOT NULL DEFAULT '0', "profitMargin" numeric(5,2) NOT NULL DEFAULT '0', "dailyAmount" numeric(10,2) NOT NULL DEFAULT '0', "weeklyAmount" numeric(10,2) NOT NULL DEFAULT '0', "added" boolean NOT NULL DEFAULT true, "dealSpecificationId" uuid, "dealId" uuid, CONSTRAINT "PK_5d74c7f1379de914317c8e4aa5e" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "deal_order_details"`);
  }
}
