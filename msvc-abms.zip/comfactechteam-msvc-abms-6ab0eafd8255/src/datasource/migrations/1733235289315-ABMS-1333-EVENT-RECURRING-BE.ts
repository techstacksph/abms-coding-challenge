import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTRECURRINGBE1733235289315 implements MigrationInterface {
  name = ' ABMSEVENTRECURRINGBE1733235289315';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ALTER COLUMN "startDate" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ALTER COLUMN "startDate" SET NOT NULL`
    );
  }
}
