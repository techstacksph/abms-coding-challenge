import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS233EMAILSERVERSETTINGS1741655569631
  implements MigrationInterface
{
  name = 'ABMS233EMAILSERVERSETTINGS1741655569631';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "emailSettings" character varying NOT NULL DEFAULT 'MICROSOFT_OUTLOOK'`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "mailerAccount" character varying NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "tenantId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "clientId" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "clientSecret" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "mailHost" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "mailPort" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "appPassword" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "autoReply" character varying NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "mailSender" character varying NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "mailSender"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "autoReply"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "appPassword"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "mailPort"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "mailHost"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "clientSecret"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "clientId"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "tenantId"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "mailerAccount"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "emailSettings"`
    );
  }
}
