import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';

const MODULE_CODE = 'purchaseorder';

export class ABMS523PURCHASEORDERMODULE1740043674174
  implements MigrationInterface
{
  name = 'ABMS523PURCHASEORDERMODULE1740043674174';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "purchaseorders" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "poNo" character varying, "platformId" integer, "poDate" TIMESTAMP NOT NULL, "poFile" character varying, "supplierId" uuid NOT NULL, "contactId" uuid NOT NULL, "reference" character varying, "warehouseId" uuid NOT NULL, "deliveryAddress" character varying, "notes" character varying, "paymentTermId" uuid, "sendOrdersViaEmail" boolean DEFAULT false, "bulk" boolean DEFAULT false, "eta" TIMESTAMP, "recordOwnerId" uuid NOT NULL, "departmentId" uuid NOT NULL, "locationId" uuid NOT NULL, "salesOrderNoId" uuid, "customerId" uuid NOT NULL, "gstType" character varying NOT NULL, "subTotal" numeric NOT NULL DEFAULT '0', "gst" numeric NOT NULL DEFAULT '0', "totalAmount" numeric NOT NULL DEFAULT '0', "amountPaid" numeric NOT NULL DEFAULT '0', "balanceDue" numeric NOT NULL DEFAULT '0', "statusId" uuid NOT NULL, CONSTRAINT "PK_38e72a03b30ffdef902138bbf8c" PRIMARY KEY ("id"))`
    );

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module?.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('${MODULE_CODE}', 'Purchase Order Item', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = '${MODULE_CODE}'`
    );
    await queryRunner.query(`DROP TABLE "purchaseorders"`);
  }
}
