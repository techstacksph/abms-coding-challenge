import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1237FRANCHISEEAGREEMENTMODULE1734422911043
  implements MigrationInterface
{
  name = 'ABMS1237FRANCHISEEAGREEMENTMODULE1734422911043';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "agreements" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "agreementNo" character varying, "agreementType" character varying, "franchiseeId" uuid, "businessToPurchaseId" uuid, "franchiseeType" character varying NOT NULL, "workLevelType" character varying NOT NULL, "locationId" uuid, "agreementDate" TIMESTAMP NOT NULL, "originalCommencement" TIMESTAMP NOT NULL, "commencementDate" TIMESTAMP NOT NULL, "trainingStartDate" TIMESTAMP, "weeklyFeeInvoiceStartDate" TIMESTAMP, "notes" character varying, "installmentArrangement" character varying NOT NULL, "monthlyWorkLevelAmount" numeric(10,2) NOT NULL DEFAULT '0', "weeklyWorkLevelAmount" numeric(10,2) NOT NULL DEFAULT '0', "annualIncome" numeric(10,2) NOT NULL DEFAULT '0', "equipmentFee" numeric(10,2) NOT NULL DEFAULT '0', "franchiseeFee" numeric(10,2) NOT NULL DEFAULT '0', "royalty" numeric(10,2) NOT NULL DEFAULT '0', "collection" numeric(10,2) NOT NULL DEFAULT '0', "brand" numeric(10,2) NOT NULL DEFAULT '0', "technology" numeric(10,2) NOT NULL DEFAULT '0', "firstAveGrossWeeklyRevenue" numeric(10,2) DEFAULT '0', "firstAveNoOfWeeks" integer, "secondAveGrossWeeklyRevenue" numeric(10,2) DEFAULT '0', "secondAveNoOfWeeks" integer, "thirdAveGrossWeeklyRevenue" numeric(10,2) DEFAULT '0', "thirdAveNoOfYears" integer, "fourthAveGrossWeeklyRevenue" numeric(10,2) DEFAULT '0', "assignmentFee" numeric(10,2) DEFAULT '0', "possessionDate" TIMESTAMP, "businessPurchaseAmount" numeric(10,2) DEFAULT '0', "withVehicle" boolean NOT NULL DEFAULT false, "vehiclePurchaseAmount" numeric(10,2) DEFAULT '0', "statusId" uuid NOT NULL, "signedFile" character varying, "statusNotes" character varying, "renewalDate" TIMESTAMP, "expiryDateofEntireAgreement" TIMESTAMP, "parentAgreementId" uuid, "agreementPDF" character varying, CONSTRAINT "PK_4fe4989e5c557abc8905e3d683c" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('agreement', 'Agreement', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'agreement'`);
    await queryRunner.query(`DROP TABLE "agreements"`);
  }
}
