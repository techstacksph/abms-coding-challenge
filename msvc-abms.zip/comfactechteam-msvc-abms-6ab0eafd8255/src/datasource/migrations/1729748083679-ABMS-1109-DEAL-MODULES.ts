import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1109DEALMODULES1729748083679 implements MigrationInterface {
  name = 'ABMS1109DEALMODULES1729748083679';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "deals" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "dealNo" character varying, "autoNumber" SERIAL, "dealname" character varying NOT NULL, "dealTypeId" uuid NOT NULL, "notes" text, "targetCloseDate" date NOT NULL, "preferredStartDate" date, "accountId" uuid NOT NULL, "siteId" uuid NOT NULL, "contactId" uuid NOT NULL, "locationId" uuid NOT NULL, "recordOwnerId" uuid NOT NULL, "telesalesId" uuid, "premiseTypeId" uuid NOT NULL, "cleaningTime" character varying, "specialNotes" text, "worktype" character varying NOT NULL, "frequency" character varying, "days" integer, "daysPerWeek" text, "weeksPerAnnum" integer NOT NULL, "totalCleaningDuration" integer, "totalDailyAmount" numeric(10,2) NOT NULL DEFAULT '0', "totalWeeklyAmount" numeric(10,2) NOT NULL DEFAULT '0', "totalMonthlyAmount" numeric(10,2) NOT NULL DEFAULT '0', "priceAdjustment" numeric(10,2) DEFAULT '0', "reason" text, "costingAmount" numeric(10,2) DEFAULT '0', "statusId" uuid NOT NULL, "closeDate" date, "coverLetter" text, CONSTRAINT "PK_8c66f03b250f613ff8615940b4b" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDeal_No" ON "deals" ("dealNo") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('deal', 'Deal', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexDeal_No"`);
    await queryRunner.query(`DROP TABLE "deals"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'deal'`);
  }
}
