import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS2497INCLUDEMODULESINTASKANDEVENT1742955831781
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId", "isIncludedInTask", "isIncludedInEvent") VALUES ('bill', 'Bill', '${TestIds.ORGANIZATION_ID}', true, true)`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId", "isIncludedInTask", "isIncludedInEvent") VALUES ('deliveryandreturn', 'Delivery & Return', '${TestIds.ORGANIZATION_ID}', true, true)`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId", "isIncludedInTask", "isIncludedInEvent") VALUES ('stockcontrol', 'Stock Control', '${TestIds.ORGANIZATION_ID}', true, true)`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId", "isIncludedInTask", "isIncludedInEvent") VALUES ('outlook', 'Outlook', '${TestIds.ORGANIZATION_ID}', true, true)`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = true WHERE code IN ('invoice', 'job_purchase', 'job_schedule')`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code IN ('invoice', 'job_purchase', 'job_schedule')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = false WHERE code IN ('invoice', 'job_purchase', 'job_schedule')`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code IN ('invoice', 'job_purchase', 'job_schedule')`
    );

    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" IN ('bill', 'deliveryandreturn', 'stockcontrol', 'outlook')`
    );
  }
}
