import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1008COMMUNICATIONLOGSINDEX1730949587381
  implements MigrationInterface
{
  name = 'ABMS1008COMMUNICATIONLOGSINDEX1730949587381';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "caseId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "moduleId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "jobId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "qualityAuditId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "invoiceId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "billsId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "evaluationId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "trainingId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "purchaseOrderId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" ADD "salesOrderId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "salesOrderId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "purchaseOrderId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "trainingId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "evaluationId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "billsId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "invoiceId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "qualityAuditId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "jobId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "moduleId"`
    );
    await queryRunner.query(
      `ALTER TABLE "communication_logs" DROP COLUMN "caseId"`
    );
  }
}
