import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1147SPECIFICATIONDETAILSMODULES1729076025601
  implements MigrationInterface
{
  name = 'ABMS1147SPECIFICATIONDETAILSMODULES1729076025601';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "specificationdetail" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "specificationName" character varying(100), "itemId" uuid  NULL, CONSTRAINT "PK_31cfdac0e4056d14f4c5456d739" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "specificationdetail"`);
  }
}
