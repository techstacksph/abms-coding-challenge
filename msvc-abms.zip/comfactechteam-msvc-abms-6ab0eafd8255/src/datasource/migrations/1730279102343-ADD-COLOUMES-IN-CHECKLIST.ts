import { MigrationInterface, QueryRunner } from 'typeorm';

export class ADDCOLOUMESINCHECKLIST1730279102343 implements MigrationInterface {
  name = 'ADDCOLOUMESINCHECKLIST1730279102343';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "checklistinformations" ADD "statusId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "checklistinformations" DROP COLUMN "statusId"`
    );
  }
}
