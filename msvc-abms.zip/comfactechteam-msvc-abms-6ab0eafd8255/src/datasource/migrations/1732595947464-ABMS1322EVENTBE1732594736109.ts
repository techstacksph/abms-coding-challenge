import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1322EVENTBE1732594736109 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    return;
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
