import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2226ADDCUSTOMDISPLAYNAMEFIELDCOMPANYSETTINGS1741864427878
  implements MigrationInterface
{
  name = 'ABMS2226ADDCUSTOMDISPLAYNAMEFIELDCOMPANYSETTINGS1741864427878';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "customDisplayName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "customDisplayName"`
    );
  }
}
