import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS907ADDEXPORTFIELDSTOPRICELIST1728259679511
  implements MigrationInterface
{
  name = 'ABMS907ADDEXPORTFIELDSTOPRICELIST1728259679511';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "pricelists" ADD "locationName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "pricelists" ADD "effectivityDate" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "pricelists" DROP COLUMN "effectivityDate"`
    );
    await queryRunner.query(
      `ALTER TABLE "pricelists" DROP COLUMN "locationName"`
    );
  }
}
