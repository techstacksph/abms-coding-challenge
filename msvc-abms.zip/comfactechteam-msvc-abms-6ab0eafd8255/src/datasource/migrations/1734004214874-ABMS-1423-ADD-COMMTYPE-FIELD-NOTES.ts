import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1423ADDCOMMTYPEFIELDNOTES1734004214874
  implements MigrationInterface
{
  name = 'ABMS1423ADDCOMMTYPEFIELDNOTES1734004214874';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "notes" ADD "commType" character varying DEFAULT 'Note'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "commType"`);
  }
}
