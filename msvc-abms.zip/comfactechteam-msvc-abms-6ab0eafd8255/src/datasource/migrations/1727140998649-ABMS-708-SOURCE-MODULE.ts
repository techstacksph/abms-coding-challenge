import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS708SOURCEMODULE1727140998649 implements MigrationInterface {
  name = 'ABMS708SOURCEMODULE1727140998649';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "sources" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_85523beafe5a2a6b90b02096443" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSource_Code" ON "sources" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSource_Name" ON "sources" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('source', 'Source', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'source'`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexSource_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexSource_Code"`);
    await queryRunner.query(`DROP TABLE "sources"`);
  }
}
