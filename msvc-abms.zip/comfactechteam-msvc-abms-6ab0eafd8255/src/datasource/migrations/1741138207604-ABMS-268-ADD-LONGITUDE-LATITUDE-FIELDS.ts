import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS268ADDLONGITUDELATITUDEFIELDS1741138207604
  implements MigrationInterface
{
  name = 'ABMS268ADDLONGITUDELATITUDEFIELDS1741138207604';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "longitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "latitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "site" ADD "longitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "site" ADD "latitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "longitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "latitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "pLongitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "pLatitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bLongitude" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bLatitude" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "bLatitude"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "bLongitude"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "pLatitude"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "pLongitude"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "latitude"`);
    await queryRunner.query(`ALTER TABLE "contacts" DROP COLUMN "longitude"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "latitude"`);
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "longitude"`);
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "latitude"`);
    await queryRunner.query(`ALTER TABLE "locations" DROP COLUMN "longitude"`);
  }
}
