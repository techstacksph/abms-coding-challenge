import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2634AddLeadIdToAnswerTable1743554763144
  implements MigrationInterface
{
  name = 'ABMS2634AddLeadIdToAnswerTable1743554763144';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "answers" ADD "leadId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "answers" DROP COLUMN "leadId"`);
  }
}
