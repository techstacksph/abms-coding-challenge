import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1649UPDATEITEMMODULE1734497044923
  implements MigrationInterface
{
  name = 'ABMS1649UPDATEITEMMODULE1734497044923';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "itemvariantypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "variantTypeId" uuid, "itemId" uuid, CONSTRAINT "PK_9b0ec10f7aeccb43696d34482d4" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`ALTER TABLE "items" ADD "itemCode" citext`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItem_ItemCode" ON "items" ("itemCode") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexItem_ItemCode"`);
    await queryRunner.query(`ALTER TABLE "items" DROP COLUMN "itemCode"`);
    await queryRunner.query(`DROP TABLE "itemvariantypes"`);
  }
}
