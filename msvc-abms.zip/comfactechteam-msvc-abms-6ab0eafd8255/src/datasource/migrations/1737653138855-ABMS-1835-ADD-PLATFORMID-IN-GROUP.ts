import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1835ADDPLATFORMIDINGROUP1737653138855
  implements MigrationInterface
{
  name = 'ABMS1835ADDPLATFORMIDINGROUP1737653138855';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "groups" ADD "platformId" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "groups" DROP COLUMN "platformId"`);
  }
}
