import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS370INITIALSEEDUSERROLE1717751612226
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // CREATE INITIAL SEED FOR USER ROLES -- ADMIN
    await queryRunner.query(
      `
          INSERT INTO "userroles"
            ("id", "orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "updatedByName", "role", "description") 
          VALUES 
            ('${TestIds.ADMIN_USER_ROLE_ID}', '${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT , DEFAULT, DEFAULT,'Administrator','This is an administrator role')
        `
    );

    // ATTACH ADMIN USER ROLE TO EXISTING USERS
    await queryRunner.query(
      `UPDATE "users" SET "roleId" = '${TestIds.ADMIN_USER_ROLE_ID}'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`UPDATE "users" SET "roleId" = NULL`);
    await queryRunner.query(
      `DELETE FROM "userroles" WHERE "id"='${TestIds.ADMIN_USER_ROLE_ID}'`
    );
  }
}
