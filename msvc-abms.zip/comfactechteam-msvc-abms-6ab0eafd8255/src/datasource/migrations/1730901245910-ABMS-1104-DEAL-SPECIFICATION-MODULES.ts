import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1104DEALSPECIFICATIONMODULES1730901245910
  implements MigrationInterface
{
  name = 'ABMS1104DEALSPECIFICATIONMODULES1730901245910';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "deal_specifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "relatedSpecificationId" uuid NOT NULL, "specifications" citext NOT NULL, "days" character varying(100) NOT NULL, "dealOrderDetailsId" uuid NOT NULL, "dealId" uuid NOT NULL, CONSTRAINT "PK_20f0ddad6792377955b8e82f7ed" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexDeal_Specifications_Specifications" ON "deal_specifications" ("specifications") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexDeal_Specifications_Specifications"`
    );
    await queryRunner.query(`DROP TABLE "deal_specifications"`);
  }
}
