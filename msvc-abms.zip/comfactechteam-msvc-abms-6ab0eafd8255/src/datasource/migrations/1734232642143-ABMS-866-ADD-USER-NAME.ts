import { MigrationInterface, QueryRunner } from 'typeorm';

import { UserModel } from '../models/UserModel';

export class ABMS866ADDUSERNAME1734232642143 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "name" character varying`
    );
    const users: Array<UserModel> = await queryRunner.query(
      `SELECT id, "firstName", "lastName" FROM "users"`
    );

    for (const user of users) {
      const { firstName, lastName, id } = user;

      await queryRunner.query(
        `UPDATE "users" SET "name" = '${firstName} ${lastName}' WHERE id = '${id}'`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "name"`);
  }
}
