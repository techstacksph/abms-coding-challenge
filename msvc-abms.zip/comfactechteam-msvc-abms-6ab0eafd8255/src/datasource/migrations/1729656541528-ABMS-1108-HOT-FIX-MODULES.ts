import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1108HOTFIXMODULES1729656541528 implements MigrationInterface {
  name = 'ABMS1108HOTFIXMODULES1729656541528';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemscatalogues" ALTER COLUMN "file" TYPE varchar`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemscatalogues" ALTER COLUMN "file" TYPE varchar(100)`
    );
  }
}
