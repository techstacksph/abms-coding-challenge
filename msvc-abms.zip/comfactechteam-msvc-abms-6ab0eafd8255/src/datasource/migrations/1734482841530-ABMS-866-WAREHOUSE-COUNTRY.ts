import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS866WAREHOUSECOUNTRY1734482841530
  implements MigrationInterface
{
  name = 'ABMS866WAREHOUSECOUNTRY1734482841530';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" ADD COLUMN IF NOT EXISTS "countryId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "warehouses" DROP COLUMN "countryId"`);
  }
}
