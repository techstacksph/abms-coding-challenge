import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS216ADDGLOBALSEARCHTOMODULE1717030980771
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('globalsearch', 'Global Search', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'globalsearch'`
    );
  }
}
