import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS263UPDATEHIGHSECURITYLEVELSEED1716199360308
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const lvl3SecurityLevel = {
      authentication: {
        login: {
          maxFailedLogin: 3,
          userLockTimeInMins: 60,
        },
        password: {
          allowSamePassword: false,
          allowSequentialCharacters: false,
          minPasswordLength: 8,
          requireLowercaseCharacter: true,
          requireNumber: true,
          requireSpecialCharacter: true,
          requireUppercaseCharacter: true,
        },
        session: {
          inactivityInMin: 240,
          loginSession: 1440,
        },
      },
      record: {
        recordLockTimeInMins: 30,
      },
    };

    await queryRunner.query(
      `
        UPDATE "securityLevels" 
        SET "configuration" = '${JSON.stringify(lvl3SecurityLevel)}'
        WHERE "id"='${TestIds.SECURITY_LEVEL_HIGH_ID}'
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const lvl3SecurityLevel = {
      authentication: {
        login: {
          maxFailedLogin: 3,
          userLockTimeInMins: 60,
        },
        password: {
          allowSamePassword: false,
          allowSequentialCharacters: false,
          minPasswordLength: 8,
          requireLowercaseCharacter: false,
          requireNumber: true,
          requireSpecialCharacter: true,
          requireUppercaseCharacter: false,
        },
        session: {
          inactivityInMin: 240,
          loginSession: 1440,
        },
      },
      record: {
        recordLockTimeInMins: 30,
      },
    };

    await queryRunner.query(
      `
        UPDATE "securityLevels" 
        SET "configuration" = '${JSON.stringify(lvl3SecurityLevel)}'
        WHERE "id"='${TestIds.SECURITY_LEVEL_HIGH_ID}'
      `
    );
  }
}
