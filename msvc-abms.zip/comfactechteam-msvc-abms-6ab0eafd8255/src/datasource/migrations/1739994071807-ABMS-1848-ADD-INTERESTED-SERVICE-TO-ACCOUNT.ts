import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1848ADDINTERESTEDSERVICETOACCOUNT1739994071807
  implements MigrationInterface
{
  name = 'ABMS1848ADDINTERESTEDSERVICETOACCOUNT1739994071807';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "interestedServiceId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "interestedServiceId"`
    );
  }
}
