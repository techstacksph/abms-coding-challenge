import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS894ADDFIELDSFRANCHISEENOTIF1735816779538
  implements MigrationInterface
{
  name = 'ABMS894ADDFIELDSFRANCHISEENOTIF1735816779538';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" ADD "commType" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" ADD "recipientNames" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" DROP COLUMN "recipientNames"`
    );
    await queryRunner.query(
      `ALTER TABLE "franchiseenotifications" DROP COLUMN "commType"`
    );
  }
}
