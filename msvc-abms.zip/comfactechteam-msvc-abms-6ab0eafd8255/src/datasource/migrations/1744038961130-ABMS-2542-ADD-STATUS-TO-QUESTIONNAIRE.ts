import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2542ADDSTATUSTOQUESTIONNAIRE1744038961130
  implements MigrationInterface
{
  name = 'ABMS2542ADDSTATUSTOQUESTIONNAIRE1744038961130';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "questionnaires" ADD "statusId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "questionnaires" DROP COLUMN "statusId"`
    );
  }
}
