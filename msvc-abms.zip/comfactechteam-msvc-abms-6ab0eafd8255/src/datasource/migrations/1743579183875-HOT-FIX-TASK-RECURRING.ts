import { MigrationInterface, QueryRunner } from 'typeorm';

export class Migrations1743578972632 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "taskrecurrings" ALTER COLUMN "dayWeek" DROP DEFAULT;`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "taskrecurrings" ALTER COLUMN "dayWeek" SET DEFAULT '[]';`
    );
  }
}
