import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS834ADDCREATEDBYNAME1727666913368
  implements MigrationInterface
{
  name = 'ABMS834ADDCREATEDBYNAME1727666913368';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documenttypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "userroles" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "userpermissions" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "permissions" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowactions" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowprocesses" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "workflows" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "modules" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "taskassignees" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "taskreccuring" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "taskwatchers" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "functions" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "usergroups" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "groups" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "departments" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventwatchers" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "timezones" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventassignees" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "eventtypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "site" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companies" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contactcompanies" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacttype" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contactcontacttype" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "countries" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "breachtypestest" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "dealtypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "breachtypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "premisetypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "securityLevels" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "industries" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "leavetypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "suppliertypes" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "systemsettings" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "sources" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "trainingprograms" ADD "createdByName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "persons" ADD "createdByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "persons" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "trainingprograms" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "sources" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "systemsettings" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "suppliertypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "leavetypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "industries" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "securityLevels" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "premisetypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "breachtypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "dealtypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "breachtypestest" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "contacts" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "countries" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "contactcontacttype" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "contacttype" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "contactcompanies" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "companies" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "createdByName"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "createdByName"`);
    await queryRunner.query(
      `ALTER TABLE "eventtypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventrecurring" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventassignees" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "createdByName"`);
    await queryRunner.query(
      `ALTER TABLE "organizations" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "timezones" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "eventwatchers" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "departments" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(`ALTER TABLE "groups" DROP COLUMN "createdByName"`);
    await queryRunner.query(
      `ALTER TABLE "usergroups" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "functions" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "createdByName"`);
    await queryRunner.query(
      `ALTER TABLE "taskwatchers" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "tasktypes" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "taskreccuring" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "taskassignees" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "modules" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflows" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowprocesses" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowactions" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "workflowstatuses" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "permissions" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "userpermissions" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "userroles" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "locations" DROP COLUMN "createdByName"`
    );
    await queryRunner.query(
      `ALTER TABLE "documenttypes" DROP COLUMN "createdByName"`
    );
  }
}
