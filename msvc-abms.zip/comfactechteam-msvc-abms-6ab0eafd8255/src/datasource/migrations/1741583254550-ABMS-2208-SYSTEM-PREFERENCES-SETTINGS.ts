import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2208SYSTEMPREFERENCESSETTINGS1741583254550
  implements MigrationInterface
{
  name = 'ABMS2208SYSTEMPREFERENCESSETTINGS1741583254550';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "timezoneId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "securityLevelId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "docLogo" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "targetClose" integer DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "autoFollowup" integer DEFAULT '0'`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "salesTax" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "purchaseTax" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "smsKey" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "smsSecret" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "xeroApp" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "xeroID" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "xeroSecret" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "mapAPI" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "tinyKey" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "outlookID" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "outlookSecret" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "outlookSecret"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "outlookID"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "tinyKey"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "mapAPI"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "xeroSecret"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "xeroID"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "xeroApp"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "smsSecret"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "smsKey"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "purchaseTax"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "salesTax"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "autoFollowup"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "targetClose"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "docLogo"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "securityLevelId"`
    );
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "timezoneId"`
    );
  }
}
