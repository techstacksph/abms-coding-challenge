import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS998ADDJOBBILLING1735537720796 implements MigrationInterface {
  name = 'ABMS998ADDJOBBILLING1735537720796';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobbillings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "jobId" uuid NOT NULL, "serviceProviderId" uuid, "schedule" character varying NOT NULL, "cleaningTime" character varying NOT NULL, "hours" integer NOT NULL DEFAULT '0', "jobAmount" double precision NOT NULL DEFAULT '0', "commissionType" character varying NOT NULL, "commission" double precision NOT NULL DEFAULT '0', "payableAmount" double precision NOT NULL DEFAULT '0', CONSTRAINT "PK_d150cad0f166bfcd11ac1217803" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobbilling', 'Job Billing', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "jobbillings"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'jobbilling'`
    );
  }
}
