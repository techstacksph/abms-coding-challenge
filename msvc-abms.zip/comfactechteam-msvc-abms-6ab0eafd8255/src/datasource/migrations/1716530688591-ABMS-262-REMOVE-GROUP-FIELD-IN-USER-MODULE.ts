import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS262REMOVEGROUPFIELDINUSERMODULE1716530688591
  implements MigrationInterface
{
  name = 'ABMS262REMOVEGROUPFIELDINUSERMODULE1716530688591';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "userGroupIds"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" ADD "userGroupIds" text`);
  }
}
