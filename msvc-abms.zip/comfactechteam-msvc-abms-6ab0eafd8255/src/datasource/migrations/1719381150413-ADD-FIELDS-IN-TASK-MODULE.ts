import { MigrationInterface, QueryRunner } from 'typeorm';

export class ADDFIELDSINTASKMODULE1719381150413 implements MigrationInterface {
  name = 'ADDFIELDSINTASKMODULE1719381150413';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "reminder" character varying`
    );

    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "willCompleteWithNotes" boolean DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "reminder"`);
    await queryRunner.query(
      `ALTER TABLE "tasks" DROP COLUMN "willCompleteWithNotes"`
    );
  }
}
