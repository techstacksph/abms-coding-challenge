import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowActionModel } from '../models/WorkflowActionModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';
import { WorkflowStatusModel } from '../models/WorkflowStatusModel';

export class ABMS1059DEALWORKFLOW1730268956413 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Deal';
    const MODULE_CODE = 'deal';

    // Retrieve the module ID
    const module: ModuleModel[] = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = $1`,
      [MODULE_CODE]
    );

    if (module.length === 0) {
      return;
    }

    const moduleId = module[0].id;

    // Insert Workflow
    await queryRunner.query(
      `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ($1, $2, $3)`,
      [MODULE_NAME, moduleId, TestIds.ORGANIZATION_ID]
    );

    // Retrieve the workflow ID
    const workflow: WorkflowModel[] = await queryRunner.query(
      `SELECT id FROM "workflows" WHERE name = $1 AND "moduleId" = $2`,
      [MODULE_NAME, moduleId]
    );

    if (workflow.length === 0) {
      return;
    }

    const workflowId = workflow[0].id;

    // Insert Workflow Process
    await queryRunner.query(
      `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ($1, $2, $3)`,
      [MODULE_NAME, workflowId, TestIds.ORGANIZATION_ID]
    );

    // Retrieve the workflow process ID
    const workflowProcess: WorkflowProcessModel[] = await queryRunner.query(
      `SELECT id FROM "workflowprocesses" WHERE name = $1 AND "workflowId" = $2`,
      [MODULE_NAME, workflowId]
    );

    if (workflowProcess.length === 0) {
      return;
    }

    const workflowProcessId = workflowProcess[0].id;

    // Define Actions
    const actions = [
      'View',
      'Edit',
      'Delete',
      'Mark as Pending',
      'Close as Lost',
      'Close as Won',
    ];

    // Insert Actions
    for (const action of actions) {
      await queryRunner.query(
        `INSERT INTO "workflowactions" ("name", "workflowProcessId", "orgId") VALUES ($1, $2, $3)`,
        [action, workflowProcessId, TestIds.ORGANIZATION_ID]
      );
    }

    // Retrieve the inserted actions with their IDs
    const workflowActions: WorkflowActionModel[] = await queryRunner.query(
      `SELECT id, name FROM "workflowactions" WHERE "workflowProcessId" = $1`,
      [workflowProcessId]
    );

    // Define Statuses with associated Actions
    const statuses = [
      {
        actions: ['View', 'Edit', 'Delete', 'Mark as Pending', 'Close as Lost'],
        name: 'Created',
      },
      {
        actions: ['View', 'Close as Won', 'Close as Lost'],
        name: 'Pending',
      },
      { actions: ['View'], name: 'Close Won' },
      { actions: ['View'], name: 'Close Lost' },
    ];

    // Insert Statuses
    for (const status of statuses) {
      const { name, actions } = status;
      if (actions) {
        const actionIds = workflowActions
          .filter((action: WorkflowActionModel) =>
            actions.includes(action.name)
          )
          .map((action: WorkflowActionModel) => action.id);

        await queryRunner.query(
          `INSERT INTO "workflowstatuses" ("name", "workflowActionIds", "workflowProcessId", "orgId") VALUES ($1, $2, $3, $4)`,
          [name, actionIds, workflowProcessId, TestIds.ORGANIZATION_ID]
        );
      } else {
        await queryRunner.query(
          `INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ($1, $2, $3)`,
          [name, workflowProcessId, TestIds.ORGANIZATION_ID]
        );
      }
    }

    // Retrieve the inserted statuses with their IDs
    const workflowStatuses: WorkflowStatusModel[] = await queryRunner.query(
      `SELECT id, name FROM "workflowstatuses" WHERE "workflowProcessId" = $1`,
      [workflowProcessId]
    );

    // Map Actions to Next Statuses
    const actionStatusMap = [
      {
        actionName: 'Mark as Pending',
        currentStatus: 'Created',
        nextStatus: 'Pending',
      },
      {
        actionName: 'Close as Won',
        currentStatus: 'Pending',
        nextStatus: 'Close Won',
      },
      {
        actionName: 'Close as Lost',
        currentStatus: 'Created',
        nextStatus: 'Close Lost',
      },
      {
        actionName: 'Close as Lost',
        currentStatus: 'Pending',
        nextStatus: 'Close Lost',
      },
    ];

    for (const map of actionStatusMap) {
      const { actionName, nextStatus } = map;
      const action = workflowActions.find(
        (a: WorkflowActionModel) => a.name === actionName
      );
      const nextStatusObj = workflowStatuses.find(
        (s: WorkflowStatusModel) => s.name === nextStatus
      );

      if (action && nextStatusObj) {
        await queryRunner.query(
          `UPDATE "workflowactions" SET "nextStatusId" = $1 WHERE "id" = $2`,
          [nextStatusObj.id, action.id]
        );
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Deal';

    // Retrieve the workflow process ID
    const workflowProcess = await queryRunner.query(
      `SELECT id FROM "workflowprocesses" WHERE name = $1`,
      [MODULE_NAME]
    );

    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;

      // Delete Actions
      await queryRunner.query(
        `DELETE FROM "workflowactions" WHERE "workflowProcessId" = $1`,
        [workflowProcessId]
      );

      // Delete Statuses
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = $1`,
        [workflowProcessId]
      );
    }

    // Delete Workflow Processes
    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = $1`,
      [MODULE_NAME]
    );

    // Delete Workflows
    await queryRunner.query(`DELETE FROM "workflows" WHERE "name" = $1`, [
      MODULE_NAME,
    ]);
  }
}
