import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class SeedInitialOrganization1695125892508
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "organizations"
                ("id", "orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "code", "name", "description") 
            VALUES 
                ('${TestIds.ORGANIZATION_ID}', '${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT , DEFAULT, 'CTO','Comfac Technology Options','Comfac Technology Options')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "organizations" WHERE "id"='${TestIds.ORGANIZATION_ID}';`
    );
  }
}
