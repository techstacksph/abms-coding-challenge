import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1715QUOTESRECORDLISTQA1734630404437
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM quote`);

    const workflowProcess = await queryRunner.query(
      `SELECT id FROM workflowprocesses WHERE name = 'Deal'`
    );

    if (!workflowProcess.length) {
      return;
    }

    const workflowProcessId = workflowProcess[0].id;

    const statuses = await queryRunner.query(
      `SELECT id, name FROM workflowstatuses WHERE "workflowProcessId" = $1 AND name = 'Created'`,
      [workflowProcessId]
    );

    if (!statuses.length) {
      return;
    }

    const createdAtStatusId = statuses[0].id;

    await queryRunner.query(`DELETE FROM deals WHERE "statusId" = $1`, [
      createdAtStatusId,
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
