import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS758BREACHTYPEMODULETEST1727433714608
  implements MigrationInterface
{
  name = 'ABMS758BREACHTYPEMODULETEST1727433714608';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "breachtypestest" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_6fca309eed7310474298502016" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexBreachTypeTest_Code" ON "breachtypestest" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexBreachTypeTest_Name" ON "breachtypestest" ("name") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('breachtypetest', 'Breach Type Test', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexBreachTypeTest_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexBreachTypeTest_Code"`
    );
    await queryRunner.query(`DROP TABLE "breachtypestest"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'breachtypetest'`
    );
  }
}
