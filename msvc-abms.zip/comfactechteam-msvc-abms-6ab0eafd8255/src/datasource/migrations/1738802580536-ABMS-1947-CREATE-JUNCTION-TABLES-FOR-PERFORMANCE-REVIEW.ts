import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1947CREATEJUNCTIONTABLESFORPERFORMANCEREVIEW1738802580536
  implements MigrationInterface
{
  name = 'ABMS1947CREATEJUNCTIONTABLESFORPERFORMANCEREVIEW1738802580536';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "prquestionnaires" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "questionnaireId" uuid, "performanceReviewId" uuid, CONSTRAINT "PK_e144627823a846d20f5e70ff968" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "prdepartments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "departmentId" uuid, "performanceReviewId" uuid, CONSTRAINT "PK_360ead2e9285c0412a6c66cdc6c" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "prdepartments"`);
    await queryRunner.query(`DROP TABLE "prquestionnaires"`);
  }
}
