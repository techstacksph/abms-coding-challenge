import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1108SECURITYCHECKSMODULES1729482103144
  implements MigrationInterface
{
  name = 'ABMS1108SECURITYCHECKSMODULES1729482103144';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "securitycheck" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "securityCheckTypeId" uuid NOT NULL, "staffId" uuid NOT NULL, "accountId" uuid, "date" date  NULL, "documentFile" character varying, "expirationDate"  date NULL, CONSTRAINT "PK_40a98cbc71b7060b5721d19835f" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "securitycheck"`);
  }
}
