import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1947RECREATEPERFORMANCEREVIEW1738732584667
  implements MigrationInterface
{
  name = 'ABMS1947RECREATEPERFORMANCEREVIEW1738732584667';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "performancereviews" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "perfReviewNo" character varying, "reviewPDF" character varying, "reviewDate" TIMESTAMP NOT NULL, "dueDate" TIMESTAMP NOT NULL, "notes" character varying, "score" numeric(10,2) DEFAULT '0', "employeeId" uuid, "managerId" uuid, "statusId" uuid NOT NULL, CONSTRAINT "PK_75fc36d2026ebb28ac72078c467" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `ALTER TABLE "notes" ADD "performanceReviewId" uuid`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'performancereview'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('performancereview', 'Performance Review', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "notes" DROP COLUMN "performanceReviewId"`
    );
    await queryRunner.query(`DROP TABLE "performancereviews"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'performancereview'`
    );
  }
}
