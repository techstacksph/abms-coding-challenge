import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSUPDATEACCOUNTMODULE1728274799266
  implements MigrationInterface
{
  name = 'ABMSUPDATEACCOUNTMODULE1728274799266';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "pViewLocation" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bViewLocation" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "supplierAccountNo" character varying`
    );
    await queryRunner.query(`ALTER TABLE "accounts" ADD "accountCodeId" uuid`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "supplierTypeId" uuid`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "paymentTermId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "minimumLeadTime" numeric`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "maximumLeadTime" numeric`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bankAccountName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bankName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "bankAddress" character varying`
    );
    await queryRunner.query(`ALTER TABLE "accounts" ADD "recordOwnerId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "recordOwnerId"`
    );
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "bankAddress"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "bankName"`);
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "bankAccountName"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "maximumLeadTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "minimumLeadTime"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "paymentTermId"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "supplierTypeId"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "accountCodeId"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "supplierAccountNo"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "bViewLocation"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "pViewLocation"`
    );
    await queryRunner.query(`ALTER TABLE "companies" ADD "companyId" uuid`);
  }
}
