import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS444CREATEEMPLOYEMENTHISTORY1737602352172
  implements MigrationInterface
{
  name = 'ABMS444CREATEEMPLOYEMENTHISTORY1737602352172';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "employementhistory" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "employeeId" uuid NOT NULL, "jobTitleId" uuid NOT NULL, "employmentType" character varying NOT NULL, "startDate" date NOT NULL, "endDate" date, "statusId" uuid, "payDetailsId" uuid, CONSTRAINT "PK_eadfe0951705c5ab15dd367a7fd" PRIMARY KEY ("id"))`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'employementhistory'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('employementhistory', 'Employement History', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "employementhistory"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'employementhistory'`
    );
  }
}
