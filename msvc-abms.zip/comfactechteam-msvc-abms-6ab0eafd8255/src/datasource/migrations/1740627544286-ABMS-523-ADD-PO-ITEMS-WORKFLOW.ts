import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowModel } from '../models/WorkflowModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

const MODULE_NAME = 'Purchase Order Item';
const MODULE_CODE = 'purchaseorderitem';

export class ABMS523ADDPOITEMSWORKFLOW1740627544286
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );

    if (module.length > 0) {
      const purchaseOrderItemModule = module[0];
      const moduleId = purchaseOrderItemModule.id;

      await queryRunner.query(
        `INSERT INTO "workflows" ("name", "moduleId", "orgId") VALUES ('${MODULE_NAME}', '${moduleId}', '${TestIds.ORGANIZATION_ID}')`
      );

      const workflow: Array<WorkflowModel> = await queryRunner.query(
        `SELECT id FROM "workflows" WHERE name = '${MODULE_NAME}' AND "moduleId" = '${moduleId}'`
      );

      if (workflow.length > 0) {
        const workflowId = workflow[0].id;

        await queryRunner.query(
          `INSERT INTO "workflowprocesses" ("name", "workflowId", "orgId") VALUES ('${MODULE_NAME}', '${workflowId}', '${TestIds.ORGANIZATION_ID}')`
        );

        const workflowProcess: Array<WorkflowProcessModel> =
          await queryRunner.query(
            `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}' AND "workflowId" = '${workflowId}'`
          );

        if (workflowProcess.length > 0) {
          const workflowProcessId = workflowProcess[0].id;
          const status = [
            { name: 'Created' },
            { name: 'With DR' },
            { name: 'Delivered' },
          ];

          status.forEach(async (data) => {
            const { name } = data;

            await queryRunner.query(`
              INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${name}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
          });
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );

    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      await queryRunner.query(
        `DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}'`
      );
    }

    await queryRunner.query(
      `DELETE FROM "workflowprocesses" WHERE "name" = '${MODULE_NAME}'`
    );
    await queryRunner.query(
      `DELETE FROM "workflows" WHERE "name" = '${MODULE_NAME}'`
    );
  }
}
