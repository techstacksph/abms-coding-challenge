import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1330ADDMISSINGFIELDSINEVENT1738635098499
  implements MigrationInterface
{
  name = 'ABMS1330ADDMISSINGFIELDSINEVENT1738635098499';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "willCompleteWithNotes" boolean DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "willCompleteWithNotes"`
    );
  }
}
