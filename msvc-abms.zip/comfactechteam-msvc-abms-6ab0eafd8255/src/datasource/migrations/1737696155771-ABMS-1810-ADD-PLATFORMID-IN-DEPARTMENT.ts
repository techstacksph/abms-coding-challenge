import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1810ADDPLATFORMIDINDEPARTMENT1737696155771
  implements MigrationInterface
{
  name = 'ABMS1810ADDPLATFORMIDINDEPARTMENT1737696155771';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "departments" ADD "platformId" integer`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "departments" DROP COLUMN "platformId"`
    );
  }
}
