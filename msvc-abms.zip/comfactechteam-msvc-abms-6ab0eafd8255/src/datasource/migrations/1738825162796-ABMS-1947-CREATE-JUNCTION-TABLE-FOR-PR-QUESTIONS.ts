import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1947CREATEJUNCTIONTABLEFORPRQUESTIONS1738825162796
  implements MigrationInterface
{
  name = 'ABMS1947CREATEJUNCTIONTABLEFORPRQUESTIONS1738825162796';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "prqquestionnaires" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "performanceReviewQuestionId" uuid, "questionnaireId" uuid, CONSTRAINT "PK_d172bcc200c1b76b86a503610b6" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "prqquestions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "performanceReviewQuestionId" uuid, "questionId" uuid, "questionnaireId" uuid, CONSTRAINT "PK_0c5c440ed58237481b63a6f6e9e" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "prqquestions"`);
    await queryRunner.query(`DROP TABLE "prqquestionnaires"`);
  }
}
