import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1915REMOVEEVALUATIONEVALUATIONCOLUMN1739341464922
  implements MigrationInterface
{
  name = 'ABMS1915REMOVEEVALUATIONEVALUATIONCOLUMN1739341464922';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "evaluation" DROP COLUMN "evaluation"`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "evaluation" ADD "evaluation" TIMESTAMP NOT NULL`
    );
  }
}
