import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1734UPDATETAKSIDQUOTEIDCOMMUNICATIONLOGIDFIELDSEVENT1736099332811
  implements MigrationInterface
{
  name =
    'ABMS1734UPDATETAKSIDQUOTEIDCOMMUNICATIONLOGIDFIELDSEVENT1736099332811';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" ADD "quoteId" uuid`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD "communicationLogId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "communicationLogId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "quoteId"`);
  }
}
