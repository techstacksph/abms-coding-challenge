import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS71ADDSYSTEMSETTINGS1715748756852
  implements MigrationInterface
{
  name = 'ABMS71ADDSYSTEMSETTINGS1715748756852';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "systemsettings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "securityLevelId" uuid NOT NULL, CONSTRAINT "PK_364886df7d2d3f7f3a89a87689d" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      `
        INSERT INTO "systemsettings" 
          ("id","orgId", "securityLevelId") 
        VALUES 
          ('${TestIds.SYSTEM_SETTINGS_ID}', '${TestIds.ORGANIZATION_ID}', '${TestIds.SECURITY_LEVEL_HIGH_ID}')
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "systemsettings"`);
  }
}
