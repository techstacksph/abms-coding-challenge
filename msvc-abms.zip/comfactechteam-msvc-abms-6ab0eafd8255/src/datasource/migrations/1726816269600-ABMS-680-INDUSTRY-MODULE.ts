import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS680INDUSTRYMODULE1726816269600 implements MigrationInterface {
  name = 'ABMS680INDUSTRYMODULE1726816269600';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "industries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_f1626dcb2d58142d7dfcca7b8d1" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexIndustry_Code" ON "industries" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexIndustry_Name" ON "industries" ("name") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('industry', 'Industry', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'industry'`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexIndustry_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexIndustry_Code"`);
    await queryRunner.query(`DROP TABLE "industries"`);
  }
}
