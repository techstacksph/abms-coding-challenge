import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXCREATEDBYNAME1727670974925 implements MigrationInterface {
  name = 'HOTFIXCREATEDBYNAME1727670974925';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" ADD COLUMN IF NOT EXISTS "createdByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" DROP COLUMN "createdByName"`
    );
  }
}
