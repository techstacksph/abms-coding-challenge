import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1844CREATEJOBPURCHASE1738179373075
  implements MigrationInterface
{
  name = 'ABMS1844CREATEJOBPURCHASE1738179373075';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobpurchases" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "jobPurchaseNo" character varying, "platformId" integer, "monthlyWorkLevelCur" numeric NOT NULL DEFAULT '0', "monthlyIncomeCur" numeric NOT NULL DEFAULT '0', "weeklyWorkLevelCur" numeric NOT NULL DEFAULT '0', "weeklyIncomeCur" numeric NOT NULL DEFAULT '0', "collectionFeeCur" numeric NOT NULL DEFAULT '0', "royaltyFeeCur" numeric NOT NULL DEFAULT '0', "brandFeeCur" numeric NOT NULL DEFAULT '0', "techFeeCur" numeric NOT NULL DEFAULT '0', "monthlyWorkLevelNew" numeric NOT NULL DEFAULT '0', "monthlyIncomeNew" numeric NOT NULL DEFAULT '0', "weeklyWorkLevelNew" numeric NOT NULL DEFAULT '0', "weeklyIncomeNew" numeric NOT NULL DEFAULT '0', "collectionFeeNew" numeric NOT NULL DEFAULT '0', "royaltyFeeNew" numeric NOT NULL DEFAULT '0', "brandFeeNew" numeric NOT NULL DEFAULT '0', "techFeeNew" numeric NOT NULL DEFAULT '0', "deposit" boolean NOT NULL, "finance" boolean NOT NULL, "paymentMonth" numeric NOT NULL DEFAULT '0', "depositAmount" numeric NOT NULL DEFAULT '0', "monthlyDeposit" character varying NOT NULL, "statusId" uuid NOT NULL, CONSTRAINT "PK_5058c6583e0ad5fb40ac98ed6ef" PRIMARY KEY ("id"))`
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'jobpurchase'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('jobpurchase', 'Job Purchase', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "jobpurchases"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'jobpurchase'`
    );
  }
}
