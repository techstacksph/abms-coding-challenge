import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1437ADDMOBILEFIELDUSER1731908729145
  implements MigrationInterface
{
  name = 'ABMS1437ADDMOBILEFIELDUSER1731908729145';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ADD "mobile" character varying NOT NULL DEFAULT ''`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "mobile"`);
  }
}
