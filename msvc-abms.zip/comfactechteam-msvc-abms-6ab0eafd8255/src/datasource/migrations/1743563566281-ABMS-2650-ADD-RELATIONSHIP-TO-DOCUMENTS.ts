import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2650ADDRELATIONSHIPTODOCUMENTS1743563566281
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documents" ADD "purchaseOrderId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documents" DROP COLUMN "purchaseOrderId"`
    );
  }
}
