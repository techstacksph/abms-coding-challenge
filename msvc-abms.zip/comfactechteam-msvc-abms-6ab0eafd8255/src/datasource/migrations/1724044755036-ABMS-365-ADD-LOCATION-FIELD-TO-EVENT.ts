import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS365ADDLOCATIONFIELDTOEVENT1724044755036
  implements MigrationInterface
{
  name = 'ABMS365ADDLOCATIONFIELDTOEVENT1724044755036';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "locationText" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "locationText"`);
  }
}
