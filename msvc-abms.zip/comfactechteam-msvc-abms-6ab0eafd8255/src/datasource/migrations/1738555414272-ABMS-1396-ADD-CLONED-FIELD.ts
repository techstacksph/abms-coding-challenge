import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1396ADDCLONEDFIELD1738555414272 implements MigrationInterface {
  name = 'ABMS1396ADDCLONEDFIELD1738555414272';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" ADD "startTime2" TIMESTAMP`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "startTime2"`);
  }
}
