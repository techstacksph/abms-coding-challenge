import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { ModuleModel } from '../models/ModuleModel';
import { WorkflowProcessModel } from '../models/WorkflowProcessModel';

export class ABMSADDCREATEDWORKFLOW1740611203612 implements MigrationInterface {
  name = 'ABMSADDCREATEDWORKFLOW1740611203612';

  public async up(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Agreements And Contracts';
    const MODULE_CODE = 'agreementandcontract';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );

    const module: Array<ModuleModel> = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = '${MODULE_CODE}'`
    );
    if (module.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      ['Created'].forEach(async (data) => {
        await queryRunner.query(`
                    INSERT INTO "workflowstatuses" ("name", "workflowProcessId", "orgId") VALUES ('${data}', '${workflowProcessId}', '${TestIds.ORGANIZATION_ID}')`);
      });
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const MODULE_NAME = 'Agreements And Contracts';
    const workflowProcess: Array<WorkflowProcessModel> =
      await queryRunner.query(
        `SELECT id FROM "workflowprocesses" WHERE name = '${MODULE_NAME}'`
      );
    if (workflowProcess.length > 0) {
      const workflowProcessId = workflowProcess[0].id;
      ['Created'].forEach(async (data) => {
        await queryRunner.query(`
                        DELETE FROM "workflowstatuses" WHERE "workflowProcessId" = '${workflowProcessId}' AND "name" = '${data}'`);
      });
    }
  }
}
