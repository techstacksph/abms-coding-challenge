import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class MODULEDATAQUICKFIX1717662068630 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const data = [
      {
        code: 'country',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Country',
      },
      {
        code: 'department',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Department',
      },
      {
        code: 'function',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Function',
      },
      {
        code: 'group',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Group',
      },
      {
        code: 'location',
        isIncludedInEvent: true,
        isInludedInTask: true,
        name: 'Location',
      },
      {
        code: 'module',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Module',
      },
      {
        code: 'organization',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Organization',
      },
      {
        code: 'person',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Person',
      },
      {
        code: 'securityLevel',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Security Level',
      },
      {
        code: 'systemsettings',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'System Settings',
      },
      {
        code: 'timezone',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Timezone',
      },
      {
        code: 'usergroup',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'User Group',
      },
      {
        code: 'user',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'User',
      },
      {
        code: 'workflow',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Workflow',
      },
      {
        code: 'workflowstatus',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Workflow Status',
      },
      {
        code: 'workflowaction',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Workflow Action',
      },
      {
        code: 'workflowprocess',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Workflow Process',
      },
      {
        code: 'globalsearch',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Global Search',
      },
      {
        code: 'eventwatcher',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Event Watcher',
      },
      {
        code: 'eventassignee',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Event Assignee',
      },
      {
        code: 'taskassignee',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Task Assignee',
      },
      {
        code: 'taskwatcher',
        isIncludedInEvent: false,
        isInludedInTask: false,
        name: 'Task Watcher',
      },
    ];
    const seedValues: Array<string> = [];

    await queryRunner.query(
      `DELETE FROM "modules" WHERE code NOT IN ('event', 'task')`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'event'`
    );
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = true WHERE code = 'task'`
    );

    data.forEach((module) => {
      const { name, code, isIncludedInEvent, isInludedInTask } = module;
      seedValues.push(
        `('${code}', '${name}', '${TestIds.ORGANIZATION_ID}', ${isInludedInTask}, ${isIncludedInEvent})`
      );
    });

    await queryRunner.query(
      `INSERT INTO "modules" ("code","name", "orgId", "isIncludedInTask", "isIncludedInEvent") VALUES ${seedValues.join(
        ','
      )}`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
