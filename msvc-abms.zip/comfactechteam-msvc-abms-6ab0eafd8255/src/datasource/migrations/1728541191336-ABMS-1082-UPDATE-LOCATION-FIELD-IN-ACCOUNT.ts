import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1082UPDATELOCATIONFIELDINACCOUNT1728541191336
  implements MigrationInterface
{
  name = 'ABMS1082UPDATELOCATIONFIELDINACCOUNT1728541191336';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "accounts" WHERE "locationId" IS NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "locationId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ALTER COLUMN "locationId" DROP NOT NULL`
    );
  }
}
