import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1740TASKRECURRINGMODULE1736149845175
  implements MigrationInterface
{
  name = 'ABMS1740TASKRECURRINGMODULE1736149845175';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "taskrecurrings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "taskId" uuid, "startDate" TIMESTAMP, "endDate" TIMESTAMP, "frequency" character varying, "freqInt" integer, "days" character varying, "date" integer, "weekOrder" character varying, "dayWeek" text DEFAULT '[]', "month" character varying, "year" integer, CONSTRAINT "PK_66859449f957da41aa326ea1f0e" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('taskrecurring', 'Task Recurring', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "taskrecurrings"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'taskrecurring'`
    );
  }
}
