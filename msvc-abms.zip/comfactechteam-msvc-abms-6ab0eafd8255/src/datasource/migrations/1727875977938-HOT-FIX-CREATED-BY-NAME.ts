import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXCREATEDBYNAME1727875977938 implements MigrationInterface {
  name = 'HOTFIXCREATEDBYNAME1727875977938';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "positions" ADD "createdByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "positions" DROP COLUMN "createdByName"`
    );
  }
}
