import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSSUBCATEGIRYUPDATE1728961153864 implements MigrationInterface {
  name = 'ABMSSUBCATEGIRYUPDATE1728961153864';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemsubcategories" ADD COLUMN IF NOT EXISTS "itemCategoryId" uuid`
    );
    await queryRunner.query(
      `ALTER TABLE "itemsubcategories" ADD CONSTRAINT "FK_69bce82692ead20dff212da9a6a" FOREIGN KEY ("itemCategoryId") REFERENCES "itemcategories"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemsubcategories" DROP CONSTRAINT "FK_69bce82692ead20dff212da9a6a"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemsubcategories" DROP COLUMN "itemCategoryId"`
    );
  }
}
