import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS49TIMEZONEANDSEEDDATA1710170077271
  implements MigrationInterface
{
  name = 'ABMS49TIMEZONEANDSEEDDATA1710170077271';

  public async up(queryRunner: QueryRunner): Promise<void> {
    const seedData = [
      {
        abbreviation: 'ACDT',
        gmtOffset: 'GMT+10:30',
        name: 'Australian Central Daylight Savings Time',
      },
      {
        abbreviation: 'ACST',
        gmtOffset: 'GMT+9:30',
        name: 'Australian Central Standard Time',
      },
      { abbreviation: 'ACT', gmtOffset: 'GMT-5', name: 'Acre Time' },
      {
        abbreviation: 'ACWST',
        gmtOffset: 'GMT+8:45',
        name: 'Australian Central Western Standard Time',
      },
      {
        abbreviation: 'ADT',
        gmtOffset: 'GMT-3',
        name: 'Atlantic Daylight Time',
      },
      {
        abbreviation: 'AEDT',
        gmtOffset: 'GMT+11',
        name: 'Australian Eastern Daylight Savings Time',
      },
      {
        abbreviation: 'AEST',
        gmtOffset: 'GMT+10',
        name: 'Australian Eastern Standard Time',
      },
      { abbreviation: 'AFT', gmtOffset: 'GMT+4:30', name: 'Afghanistan Time' },
      {
        abbreviation: 'AKDT',
        gmtOffset: 'GMT-8',
        name: 'Alaska Daylight Time',
      },
      {
        abbreviation: 'AKST',
        gmtOffset: 'GMT-9',
        name: 'Alaska Standard Time',
      },
      { abbreviation: 'AMST', gmtOffset: 'GMT-3', name: 'Amazon Summer Time' },
      { abbreviation: 'AMT', gmtOffset: 'GMT-4', name: 'Amazon Time' },
      { abbreviation: 'AMT', gmtOffset: 'GMT+4', name: 'Armenia Time' },
      { abbreviation: 'ART', gmtOffset: 'GMT-3', name: 'Argentina Time' },
      {
        abbreviation: 'AST',
        gmtOffset: 'GMT-4',
        name: 'Atlantic Standard Time',
      },
      { abbreviation: 'AST', gmtOffset: 'GMT+3', name: 'Arabia Standard Time' },
      { abbreviation: 'AT', gmtOffset: 'GMT-4/GMT-3', name: 'Atlantic Time' },
      {
        abbreviation: 'AWST',
        gmtOffset: 'GMT+8',
        name: 'Australian Western Standard Time',
      },
      { abbreviation: 'AZOST', gmtOffset: 'GMT+0', name: 'Azores Summer Time' },
      {
        abbreviation: 'AZOT',
        gmtOffset: 'GMT-1',
        name: 'Azores Standard Time',
      },
      { abbreviation: 'AZT', gmtOffset: 'GMT+4', name: 'Azerbaijan Time' },
      { abbreviation: 'BDT', gmtOffset: 'GMT+8', name: 'Brunei Time' },
      { abbreviation: 'BIT', gmtOffset: 'GMT-12', name: 'Baker Island Time' },
      {
        abbreviation: 'BNT',
        gmtOffset: 'GMT+8',
        name: 'Brunei Darussalam Time',
      },
      { abbreviation: 'BOT', gmtOffset: 'GMT-4', name: 'Bolivia Time' },
      {
        abbreviation: 'BRST',
        gmtOffset: 'GMT-2',
        name: 'Brasilia Summer Time',
      },
      { abbreviation: 'BRT', gmtOffset: 'GMT-3', name: 'Brasilia Time' },
      { abbreviation: 'BST', gmtOffset: 'GMT+1', name: 'British Summer Time' },
      {
        abbreviation: 'BST',
        gmtOffset: 'GMT+6',
        name: 'Bangladesh Standard Time',
      },
      {
        abbreviation: 'BST',
        gmtOffset: 'GMT+11',
        name: 'Bougainville Standard Time',
      },
      { abbreviation: 'BTT', gmtOffset: 'GMT+6', name: 'Bhutan Time' },
      { abbreviation: 'CAT', gmtOffset: 'GMT+2', name: 'Central Africa Time' },
      {
        abbreviation: 'CCT',
        gmtOffset: 'GMT+6:30',
        name: 'Cocos Islands Time',
      },
      {
        abbreviation: 'CDT',
        gmtOffset: 'GMT-5',
        name: 'Central Daylight Time',
      },
      { abbreviation: 'CDT', gmtOffset: 'GMT-4', name: 'Cuba Daylight Time' },
      {
        abbreviation: 'CEST',
        gmtOffset: 'GMT+2',
        name: 'Central European Summer Time',
      },
      {
        abbreviation: 'CET',
        gmtOffset: 'GMT+1',
        name: 'Central European Time',
      },
      {
        abbreviation: 'CHADT',
        gmtOffset: 'GMT+13:45',
        name: 'Chatham Daylight Time',
      },
      {
        abbreviation: 'CHAST',
        gmtOffset: 'GMT+12:45',
        name: 'Chatham Standard Time',
      },
      {
        abbreviation: 'CHOST',
        gmtOffset: 'GMT+9',
        name: 'Choibalsan Summer Time',
      },
      {
        abbreviation: 'CHOT',
        gmtOffset: 'GMT+8',
        name: 'Choibalsan Standard Time',
      },
      {
        abbreviation: 'CHST',
        gmtOffset: 'GMT+10',
        name: 'Chamorro Standard Time',
      },
      { abbreviation: 'CHUT', gmtOffset: 'GMT+10', name: 'Chuuk Time' },
      {
        abbreviation: 'CIST',
        gmtOffset: 'GMT-8',
        name: 'Clipperton Island Standard Time',
      },
      {
        abbreviation: 'CIT',
        gmtOffset: 'GMT+8',
        name: 'Central Indonesia Time',
      },
      { abbreviation: 'CKT', gmtOffset: 'GMT-10', name: 'Cook Island Time' },
      { abbreviation: 'CLST', gmtOffset: 'GMT-3', name: 'Chile Summer Time' },
      { abbreviation: 'CLT', gmtOffset: 'GMT-4', name: 'Chile Standard Time' },
      {
        abbreviation: 'COST',
        gmtOffset: 'GMT-4',
        name: 'Colombia Summer Time',
      },
      { abbreviation: 'COT', gmtOffset: 'GMT-5', name: 'Colombia Time' },
      {
        abbreviation: 'CST',
        gmtOffset: 'GMT-6',
        name: 'Central Standard Time',
      },
      { abbreviation: 'CST', gmtOffset: 'GMT-5', name: 'Cuba Standard Time' },
      { abbreviation: 'CST', gmtOffset: 'GMT+8', name: 'China Standard Time' },
      { abbreviation: 'CT', gmtOffset: 'GMT-6/GMT-5', name: 'Central Time' },
      { abbreviation: 'CVT', gmtOffset: 'GMT-1', name: 'Cape Verde Time' },
      {
        abbreviation: 'CWST',
        gmtOffset: 'GMT+8:45',
        name: 'Central Western Standard Time',
      },
      {
        abbreviation: 'CXT',
        gmtOffset: 'GMT+7',
        name: 'Christmas Island Time',
      },
      { abbreviation: 'DAVT', gmtOffset: 'GMT+7', name: 'Davis Time' },
      {
        abbreviation: 'DDUT',
        gmtOffset: 'GMT+10',
        name: 'Dumont dUrville Time',
      },
      {
        abbreviation: 'EASST',
        gmtOffset: 'GMT-5',
        name: 'Easter Island Summer Time',
      },
      {
        abbreviation: 'EAST',
        gmtOffset: 'GMT-6',
        name: 'Easter Island Standard Time',
      },
      { abbreviation: 'EAT', gmtOffset: 'GMT+3', name: 'East Africa Time' },
      { abbreviation: 'ECT', gmtOffset: 'GMT-5', name: 'Ecuador Time' },
      {
        abbreviation: 'EDT',
        gmtOffset: 'GMT-4',
        name: 'Eastern Daylight Time',
      },
      {
        abbreviation: 'EEST',
        gmtOffset: 'GMT+3',
        name: 'Eastern European Summer Time',
      },
      {
        abbreviation: 'EET',
        gmtOffset: 'GMT+2',
        name: 'Eastern European Time',
      },
      {
        abbreviation: 'EGST',
        gmtOffset: 'GMT+0',
        name: 'Eastern Greenland Summer Time',
      },
      {
        abbreviation: 'EGT',
        gmtOffset: 'GMT-1',
        name: 'Eastern Greenland Time',
      },
      {
        abbreviation: 'EIT',
        gmtOffset: 'GMT+9',
        name: 'Eastern Indonesian Time',
      },
      {
        abbreviation: 'EST',
        gmtOffset: 'GMT-5',
        name: 'Eastern Standard Time',
      },
      { abbreviation: 'ET', gmtOffset: 'GMT-5/GMT-4', name: 'Eastern Time' },
      {
        abbreviation: 'FET',
        gmtOffset: 'GMT+3',
        name: 'Further-eastern European Time',
      },
      { abbreviation: 'FJT', gmtOffset: 'GMT+12', name: 'Fiji Time' },
      {
        abbreviation: 'FKST',
        gmtOffset: 'GMT-3',
        name: 'Falkland Islands Summer Time',
      },
      {
        abbreviation: 'FKT',
        gmtOffset: 'GMT-4',
        name: 'Falkland Islands Time',
      },
      {
        abbreviation: 'FNT',
        gmtOffset: 'GMT-2',
        name: 'Fernando de Noronha Time',
      },
      { abbreviation: 'GALT', gmtOffset: 'GMT-6', name: 'Galapagos Time' },
      { abbreviation: 'GAMT', gmtOffset: 'GMT-9', name: 'Gambier Islands' },
      {
        abbreviation: 'GET',
        gmtOffset: 'GMT+4',
        name: 'Georgia Standard Time',
      },
      { abbreviation: 'GFT', gmtOffset: 'GMT-3', name: 'French Guiana Time' },
      {
        abbreviation: 'GILT',
        gmtOffset: 'GMT+12',
        name: 'Gilbert Island Time',
      },
      { abbreviation: 'GIT', gmtOffset: 'GMT-9', name: 'Gambier Island Time' },
      { abbreviation: 'GMT', gmtOffset: 'GMT+0', name: 'Greenwich Mean Time' },
      { abbreviation: 'GST', gmtOffset: 'GMT+4', name: 'Gulf Standard Time' },
      { abbreviation: 'GST', gmtOffset: 'GMT-2', name: 'South Georgia Time' },
      { abbreviation: 'GYT', gmtOffset: 'GMT-4', name: 'Guyana Time' },
      {
        abbreviation: 'HADT',
        gmtOffset: 'GMT-9',
        name: 'Hawaii-Aleutian Daylight Time',
      },
      {
        abbreviation: 'HAST',
        gmtOffset: 'GMT-10',
        name: 'Hawaii-Aleutian Standard Time',
      },
      { abbreviation: 'HKT', gmtOffset: 'GMT+8', name: 'Hong Kong Time' },
      {
        abbreviation: 'HMT',
        gmtOffset: 'GMT+5',
        name: 'Heard and McDonald Islands Time',
      },
      { abbreviation: 'HOVST', gmtOffset: 'GMT+8', name: 'Khovd Summer Time' },
      { abbreviation: 'HOVT', gmtOffset: 'GMT+7', name: 'Khovd Standard Time' },
      { abbreviation: 'ICT', gmtOffset: 'GMT+7', name: 'Indochina Time' },
      { abbreviation: 'IDT', gmtOffset: 'GMT+3', name: 'Israel Daylight Time' },
      { abbreviation: 'IOT', gmtOffset: 'GMT+6', name: 'Indian Chagos Time' },
      {
        abbreviation: 'IRDT',
        gmtOffset: 'GMT+4:30',
        name: 'Iran Daylight Time',
      },
      { abbreviation: 'IRKT', gmtOffset: 'GMT+8', name: 'Irkutsk Time' },
      {
        abbreviation: 'IRST',
        gmtOffset: 'GMT+3:30',
        name: 'Iran Standard Time',
      },
      {
        abbreviation: 'IST',
        gmtOffset: 'GMT+5:30',
        name: 'Indian Standard Time',
      },
      { abbreviation: 'IST', gmtOffset: 'GMT+1', name: 'Irish Standard Time' },
      { abbreviation: 'IST', gmtOffset: 'GMT+2', name: 'Israel Standard Time' },
      { abbreviation: 'JST', gmtOffset: 'GMT+9', name: 'Japan Standard Time' },
      { abbreviation: 'KGT', gmtOffset: 'GMT+6', name: 'Kyrgyzstan time' },
      { abbreviation: 'KOST', gmtOffset: 'GMT+11', name: 'Kosrae Time' },
      { abbreviation: 'KRAT', gmtOffset: 'GMT+7', name: 'Krasnoyarsk Time' },
      { abbreviation: 'KST', gmtOffset: 'GMT+9', name: 'Korea Standard Time' },
      {
        abbreviation: 'LHDT',
        gmtOffset: 'GMT+11',
        name: 'Lord Howe Daylight Time',
      },
      {
        abbreviation: 'LHST',
        gmtOffset: 'GMT+10:30',
        name: 'Lord Howe Standard Time',
      },
      { abbreviation: 'LINT', gmtOffset: 'GMT+14', name: 'Line Islands Time' },
      { abbreviation: 'MAGT', gmtOffset: 'GMT+11', name: 'Magadan Time' },
      {
        abbreviation: 'MART',
        gmtOffset: 'GMT+9:30',
        name: 'Marquesas Islands Time',
      },
      { abbreviation: 'MAWT', gmtOffset: 'GMT+5', name: 'Mawson Station Time' },
      {
        abbreviation: 'MDT',
        gmtOffset: 'GMT-6',
        name: 'Mountain Daylight Time',
      },
      { abbreviation: 'MHT', gmtOffset: 'GMT+12', name: 'Marshall Islands' },
      {
        abbreviation: 'MIST',
        gmtOffset: 'GMT+11',
        name: 'Macquarie Island Station Time',
      },
      {
        abbreviation: 'MIT',
        gmtOffset: 'GMT-9:30',
        name: 'Marquesas Islands Time',
      },
      {
        abbreviation: 'MMT',
        gmtOffset: 'GMT+6:30',
        name: 'Myanmar Standard Time',
      },
      { abbreviation: 'MSK', gmtOffset: 'GMT+3', name: 'Moscow Time' },
      {
        abbreviation: 'MST',
        gmtOffset: 'GMT-7',
        name: 'Mountain Standard Time',
      },
      {
        abbreviation: 'MST',
        gmtOffset: 'GMT+8',
        name: 'Malaysia Standard Time',
      },
      { abbreviation: 'MT', gmtOffset: 'GMT-7/GMT-6', name: 'Mountain Time' },
      { abbreviation: 'MUT', gmtOffset: 'GMT+4', name: 'Mauritius Time' },
      { abbreviation: 'MVT', gmtOffset: 'GMT+5', name: 'Maldives Time' },
      { abbreviation: 'MYT', gmtOffset: 'GMT+8', name: 'Malaysia Time' },
      { abbreviation: 'NCT', gmtOffset: 'GMT+11', name: 'New Caledonia Time' },
      {
        abbreviation: 'NDT',
        gmtOffset: 'GMT-2:30',
        name: 'Newfoundland Daylight Time',
      },
      { abbreviation: 'NFT', gmtOffset: 'GMT+11', name: 'Norfolk Time' },
      { abbreviation: 'NPT', gmtOffset: 'GMT+5:45', name: 'Nepal Time' },
      { abbreviation: 'NRT', gmtOffset: 'GMT+12', name: 'Nauru Time' },
      {
        abbreviation: 'NST',
        gmtOffset: 'GMT-3:30',
        name: 'Newfoundland Standard Time',
      },
      { abbreviation: 'NT', gmtOffset: 'GMT-3:30', name: 'Newfoundland Time' },
      { abbreviation: 'NUT', gmtOffset: 'GMT-11', name: 'Niue Time' },
      {
        abbreviation: 'NZDT',
        gmtOffset: 'GMT+13',
        name: 'New Zealand Daylight Time',
      },
      {
        abbreviation: 'NZST',
        gmtOffset: 'GMT+12',
        name: 'New Zealand Standard Time',
      },
      { abbreviation: 'OMST', gmtOffset: 'GMT+6', name: 'Omsk Time' },
      { abbreviation: 'ORAT', gmtOffset: 'GMT+5', name: 'Oral Time' },
      {
        abbreviation: 'PDT',
        gmtOffset: 'GMT-7',
        name: 'Pacific Daylight Time',
      },
      { abbreviation: 'PET', gmtOffset: 'GMT+5', name: 'Peru Time' },
      { abbreviation: 'PETT', gmtOffset: 'GMT+12', name: 'Kamchatka Time' },
      {
        abbreviation: 'PGT',
        gmtOffset: 'GMT+10',
        name: 'Papua New Guinea Time',
      },
      {
        abbreviation: 'PHOT',
        gmtOffset: 'GMT+13',
        name: 'Phoenix Island Time',
      },
      {
        abbreviation: 'PhST',
        gmtOffset: 'GMT+8',
        name: 'Philippine Standard Time',
      },
      { abbreviation: 'PHT', gmtOffset: 'GMT+8', name: 'Philippine Time' },
      {
        abbreviation: 'PKT',
        gmtOffset: 'GMT+5',
        name: 'Pakistan Standard Time',
      },
      {
        abbreviation: 'PMDT',
        gmtOffset: 'GMT-2',
        name: 'Saint Pierre and Miquelon Daylight time',
      },
      {
        abbreviation: 'PMST',
        gmtOffset: 'GMT-3',
        name: 'Saint Pierre and Miquelon Standard Time',
      },
      {
        abbreviation: 'PONT',
        gmtOffset: 'GMT+11',
        name: 'Pohnpei Standard Time',
      },
      {
        abbreviation: 'PST',
        gmtOffset: 'GMT-8',
        name: 'Pacific Standard Time',
      },
      { abbreviation: 'PT', gmtOffset: 'GMT-8/GMT-7', name: 'Pacific Time' },
      { abbreviation: 'PWT', gmtOffset: 'GMT+9', name: 'Palau Time' },
      {
        abbreviation: 'PYST',
        gmtOffset: 'GMT-3',
        name: 'Paraguay Summer Time',
      },
      { abbreviation: 'PYT', gmtOffset: 'GMT-4', name: 'Paraguay Time' },
      { abbreviation: 'RET', gmtOffset: 'GMT+4', name: 'Réunion Time' },
      {
        abbreviation: 'ROTT',
        gmtOffset: 'GMT-3',
        name: 'Rothera Research Station Time',
      },
      {
        abbreviation: 'SAKT',
        gmtOffset: 'GMT+11',
        name: 'Sakhalin Island time',
      },
      { abbreviation: 'SAMT', gmtOffset: 'GMT+4', name: 'Samara Time' },
      {
        abbreviation: 'SAST',
        gmtOffset: 'GMT+2',
        name: 'South African Standard Time',
      },
      {
        abbreviation: 'SBT',
        gmtOffset: 'GMT+11',
        name: 'Solomon Islands Time',
      },
      { abbreviation: 'SCT', gmtOffset: 'GMT+4', name: 'Seychelles Time' },
      { abbreviation: 'SGT', gmtOffset: 'GMT+8', name: 'Singapore Time' },
      {
        abbreviation: 'SLST',
        gmtOffset: 'GMT+5:30',
        name: 'Sri Lanka Standard Time',
      },
      { abbreviation: 'SRET', gmtOffset: 'GMT+11', name: 'Srednekolymsk Time' },
      { abbreviation: 'SRT', gmtOffset: 'GMT-3', name: 'Suriname Time' },
      { abbreviation: 'SST', gmtOffset: 'GMT-11', name: 'Samoa Standard Time' },
      { abbreviation: 'SYOT', gmtOffset: 'GMT+3', name: 'Showa Station Time' },
      { abbreviation: 'TAHT', gmtOffset: 'GMT-10', name: 'Tahiti Time' },
      {
        abbreviation: 'TFT',
        gmtOffset: 'GMT+5',
        name: 'French Southern and Antarctic Time',
      },
      {
        abbreviation: 'THA',
        gmtOffset: 'GMT+7',
        name: 'Thailand Standard Time',
      },
      { abbreviation: 'TJT', gmtOffset: 'GMT+5', name: 'Tajikistan Time' },
      { abbreviation: 'TKT', gmtOffset: 'GMT+13', name: 'Tokelau Time' },
      { abbreviation: 'TLT', gmtOffset: 'GMT+9', name: 'Timor Leste Time' },
      { abbreviation: 'TMT', gmtOffset: 'GMT+5', name: 'Turkmenistan Time' },
      { abbreviation: 'TOT', gmtOffset: 'GMT+13', name: 'Tonga Time' },
      { abbreviation: 'TRT', gmtOffset: 'GMT+3', name: 'Turkey Time' },
      { abbreviation: 'TVT', gmtOffset: 'GMT+12', name: 'Tuvalu Time' },
      {
        abbreviation: 'ULAST',
        gmtOffset: 'GMT+9',
        name: 'Ulaanbaatar Summer Time',
      },
      {
        abbreviation: 'ULAT',
        gmtOffset: 'GMT+8',
        name: 'Ulaanbaatar Standard Time',
      },
      { abbreviation: 'USZ1', gmtOffset: 'GMT+2', name: 'Kaliningrad Time' },
      {
        abbreviation: 'UTC',
        gmtOffset: 'GMT',
        name: 'Coordinated Universal Time',
      },
      { abbreviation: 'UYST', gmtOffset: 'GMT-2', name: 'Uruguay Summer Time' },
      {
        abbreviation: 'UYT',
        gmtOffset: 'GMT-3',
        name: 'Uruguay Standard Time',
      },
      { abbreviation: 'UZT', gmtOffset: 'GMT+5', name: 'Uzbekistan Time' },
      {
        abbreviation: 'VET',
        gmtOffset: 'GMT-4',
        name: 'Venezuelan Standard Time',
      },
      { abbreviation: 'VLAT', gmtOffset: 'GMT+10', name: 'Vladivostok Time' },
      { abbreviation: 'VOLT', gmtOffset: 'GMT+4', name: 'Volgograd Time' },
      { abbreviation: 'VOST', gmtOffset: 'GMT+6', name: 'Vostok Station Time' },
      { abbreviation: 'VUT', gmtOffset: 'GMT+11', name: 'Vanuatu Time' },
      { abbreviation: 'WAKT', gmtOffset: 'GMT+12', name: 'Wake Island Time' },
      {
        abbreviation: 'WAST',
        gmtOffset: 'GMT+2',
        name: 'West Africa Summer Time',
      },
      { abbreviation: 'WAT', gmtOffset: 'GMT+1', name: 'West Africa Time' },
      {
        abbreviation: 'WEST',
        gmtOffset: 'GMT+1',
        name: 'Western European Summer Time',
      },
      {
        abbreviation: 'WET',
        gmtOffset: 'GMT+0',
        name: 'Western European Time',
      },
      {
        abbreviation: 'WFT',
        gmtOffset: 'GMT+12',
        name: 'Wallis and Futuna Time',
      },
      { abbreviation: 'WGST', gmtOffset: 'GMT-3', name: 'West Greenland Time' },
      {
        abbreviation: 'WGST',
        gmtOffset: 'GMT-2',
        name: 'West Greenland Summer Time',
      },
      {
        abbreviation: 'WIB',
        gmtOffset: 'GMT+7',
        name: 'Western Indonesia Time',
      },
      {
        abbreviation: 'WIT',
        gmtOffset: 'GMT+9',
        name: 'Eastern Indonesia Time',
      },
      {
        abbreviation: 'WST',
        gmtOffset: 'GMT+8',
        name: 'Western Standard Time',
      },
      { abbreviation: 'YAKT', gmtOffset: 'GMT+9', name: 'Yakutsk Time' },
      { abbreviation: 'YEKT', gmtOffset: 'GMT+5', name: 'Yekaterinburg Time' },
    ];

    const seedValues = seedData.map((data) => {
      return `(
        '${TestIds.ORGANIZATION_ID}', 
        DEFAULT, 
        DEFAULT, 
        DEFAULT, 
        '${TestIds.PERSON_ID}', 
        DEFAULT, 
        DEFAULT, 
        DEFAULT, 
        DEFAULT , 
        DEFAULT, 
        '${data.name}',
        '${data.abbreviation}',
        '${data.gmtOffset}'
      )`;
    });

    await queryRunner.query(
      `CREATE TABLE "timezones" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "name" citext NOT NULL, "description" character varying, "abbreviation" character varying, "gmtOffset" character varying, CONSTRAINT "PK_589871db156cc7f92942334ab7e" PRIMARY KEY ("id"))`
    );

    await queryRunner.query(
      ` INSERT INTO "timezones"
          ("orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "name", "abbreviation", "gmtOffset") 
          VALUES 
          ${seedValues.join(',')}
        `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "timezones"`);
  }
}
