import { MigrationInterface, QueryRunner } from 'typeorm';

export class HOTFIXDEALORDERDETAILS1743766281789 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "quantity" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "amount" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "days" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "minimumCharge" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "profitMargin" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "dailyAmount" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "weeklyAmount" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "added" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "relatedItemId" DROP DEFAULT`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Optional: Add defaults back if needed
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "quantity" SET DEFAULT 1`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "amount" SET DEFAULT 0.0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "days" SET DEFAULT 0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "minimumCharge" SET DEFAULT 0.0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "profitMargin" SET DEFAULT 0.0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "dailyAmount" SET DEFAULT 0.0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "weeklyAmount" SET DEFAULT 0.0`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "added" SET DEFAULT true`
    );
    await queryRunner.query(
      `ALTER TABLE "deal_order_details" ALTER COLUMN "relatedItemId" SET DEFAULT uuid_generate_v4()`
    );
  }
}
