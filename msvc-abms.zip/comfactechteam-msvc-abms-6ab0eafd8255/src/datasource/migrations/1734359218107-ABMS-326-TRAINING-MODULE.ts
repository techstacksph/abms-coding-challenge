import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS326TRAININGMODULE1734359218107 implements MigrationInterface {
  name = 'ABMS326TRAININGMODULE1734359218107';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "trainings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "trainingDate" TIMESTAMP NOT NULL, "franchiseeId" uuid NOT NULL, "notes" text, "trainerId" uuid NOT NULL, "orientationSignoff" text, "attendeesType" character varying NOT NULL, "attendeesId" uuid, "attendeeSignature" text, "statusId" uuid NOT NULL, "trainingDetailsId" uuid NOT NULL, CONSTRAINT "PK_b67237502b175163e47dc85018d" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "Unique_TrainingDate" ON "trainings" ("trainingDate") `
    );
    await queryRunner.query(
      `CREATE TABLE "training_details" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "trainingId" uuid NOT NULL, "trainingProgramId" uuid NOT NULL, "description" text, "trainedById" uuid NOT NULL, CONSTRAINT "PK_4b988cb6418a8027e59c2f83d1e" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "training_attendees" ("trainingId" uuid NOT NULL, "contactId" uuid NOT NULL, CONSTRAINT "PK_165fcdf633913d451b62bdcff63" PRIMARY KEY ("trainingId", "contactId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_f757b946cc7eaea8338d66cf81" ON "training_attendees" ("trainingId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_551a94ec31f79f190f984ccb0a" ON "training_attendees" ("contactId") `
    );

    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'training'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('training', 'Training', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_551a94ec31f79f190f984ccb0a"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_f757b946cc7eaea8338d66cf81"`
    );
    await queryRunner.query(`DROP TABLE "training_attendees"`);
    await queryRunner.query(`DROP TABLE "training_details"`);
    await queryRunner.query(`DROP INDEX "public"."Unique_TrainingDate"`);
    await queryRunner.query(`DROP TABLE "trainings"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'training'`);
  }
}
