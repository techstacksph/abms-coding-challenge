import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1093SITE1731987756376 implements MigrationInterface {
  name = 'ABMS1093SITE1731987756378';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "site" ADD "areaId" uuid`);
  }
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "areaId"`);
  }
}
