import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2827ADDRELATEDTOFIELDSINEVENT1743742241058
  implements MigrationInterface
{
  name = 'ABMS2827ADDRELATEDTOFIELDSINEVENT1743742241058';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ADD "deliveryAndReturnId" uuid`
    );
    await queryRunner.query(`ALTER TABLE "events" ADD "employeeId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "jobPurchaseId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "jobScheduleId" uuid`);
    await queryRunner.query(`ALTER TABLE "events" ADD "stockControlId" uuid`);

    await queryRunner.query(
      `ALTER TABLE "tasks" ADD "deliveryAndReturnId" uuid`
    );
    await queryRunner.query(`ALTER TABLE "tasks" ADD "employeeId" uuid`);
    await queryRunner.query(`ALTER TABLE "tasks" ADD "jobPurchaseId" uuid`);
    await queryRunner.query(`ALTER TABLE "tasks" ADD "jobScheduleId" uuid`);
    await queryRunner.query(`ALTER TABLE "tasks" ADD "stockControlId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "stockControlId"`
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "jobScheduleId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "jobPurchaseId"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "employeeId"`);
    await queryRunner.query(
      `ALTER TABLE "events" DROP COLUMN "deliveryAndReturnId"`
    );

    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "stockControlId"`);
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "jobScheduleId"`);
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "jobPurchaseId"`);
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "employeeId"`);
    await queryRunner.query(
      `ALTER TABLE "tasks" DROP COLUMN "deliveryAndReturnId"`
    );
  }
}
