import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1229VEHICLEMODULE1730348188711 implements MigrationInterface {
  name = 'ABMS1229VEHICLEMODULE1730348188711';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "vehicles" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "make" character varying NOT NULL, "model" character varying NOT NULL, "year" TIMESTAMP NOT NULL, "bodyStyle" character varying NOT NULL, "color" character varying NOT NULL, "registration" character varying NOT NULL, "signAppliedDate" TIMESTAMP, "signWrittingRemovedDate" TIMESTAMP, "expirationDate" TIMESTAMP, "notes" character varying, "accountId" uuid NOT NULL, CONSTRAINT "PK_18d8646b59304dce4af3a9e35b6" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('vehicle', 'Vehicle', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'vehicle'`);
    await queryRunner.query(`DROP TABLE "vehicles"`);
  }
}
