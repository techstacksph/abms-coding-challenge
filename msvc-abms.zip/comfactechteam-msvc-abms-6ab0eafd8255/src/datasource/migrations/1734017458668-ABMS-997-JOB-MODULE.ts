import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS997JOBMODULE1734017458668 implements MigrationInterface {
  name = 'ABMS997JOBMODULE1734017458668';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "jobs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "accountId" uuid NOT NULL, "siteId" uuid NOT NULL, "contactId" uuid NOT NULL, "dealId" uuid NOT NULL, "dealAmount" numeric(10,2) NOT NULL DEFAULT '0', "dealOwnerId" uuid NOT NULL, "telesalesId" uuid, "weeksPerAnnum" integer NOT NULL, "specialNotes" character varying, "locationId" uuid NOT NULL, "lookAfter" boolean, "keyAccountId" uuid NOT NULL, "supervisorId" uuid NOT NULL, "qaFrequency" character varying, "workType" character varying NOT NULL, "keyCollectDate" TIMESTAMP NOT NULL, "startDate" TIMESTAMP NOT NULL, "endDate" TIMESTAMP, "jobNo" character varying, "statusId" uuid NOT NULL, "completionDate" TIMESTAMP, "cancelledDate" TIMESTAMP, "lastQADate" TIMESTAMP, "firstInvoice" boolean, "tookoverDate" TIMESTAMP, "forSale" boolean, "jobAmount" numeric(10,2) DEFAULT '0', "payableAmount" numeric(10,2) DEFAULT '0', "cancellationTypeId" uuid, "tagInactiveAccount" boolean, CONSTRAINT "PK_cf0a6c42b72fcc7f7c237def345" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId", "isIncludedInEvent", "color") VALUES ('job', 'Job', '${TestIds.ORGANIZATION_ID}', true, '#00bcd4')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'job'`);
    await queryRunner.query(`DROP TABLE "jobs"`);
  }
}
