import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2691ADDRELATIONSHIPTOACCOUNT1743558656432
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "leads" ADD "accountId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "leads" DROP COLUMN "accountId"`);
  }
}
