import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1988UPDATEMOBILEINUSER1740022689566
  implements MigrationInterface
{
  name = 'ABMS1988UPDATEMOBILEINUSER1740022689566';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "mobile" DROP NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "mobile" SET NOT NULL`
    );
  }
}
