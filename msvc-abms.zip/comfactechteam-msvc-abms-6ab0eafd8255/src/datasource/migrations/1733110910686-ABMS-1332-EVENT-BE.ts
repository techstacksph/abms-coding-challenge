import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTBE1733110910686 implements MigrationInterface {
  name = ' ABMSEVENTBE1733110910686';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'account'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'communication_log'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'lead'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'quote'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code = 'account'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code = 'communication_log'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code = 'lead'`
    );

    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code = 'quote'`
    );
  }
}
