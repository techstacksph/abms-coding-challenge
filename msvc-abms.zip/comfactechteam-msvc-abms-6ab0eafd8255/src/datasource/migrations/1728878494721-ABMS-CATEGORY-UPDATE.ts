import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSCATEGORYUPDATE1728878494721 implements MigrationInterface {
  name = 'ABMSCATEGORYUPDATE1728878494721';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "customer"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "franchisee"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "franchiseeportal" boolean NOT NULL DEFAULT false`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "customerportal" boolean NOT NULL DEFAULT false`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "customerportal"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" DROP COLUMN "franchiseeportal"`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "franchisee" boolean NOT NULL DEFAULT false`
    );
    await queryRunner.query(
      `ALTER TABLE "itemcategories" ADD "customer" boolean NOT NULL DEFAULT false`
    );
  }
}
