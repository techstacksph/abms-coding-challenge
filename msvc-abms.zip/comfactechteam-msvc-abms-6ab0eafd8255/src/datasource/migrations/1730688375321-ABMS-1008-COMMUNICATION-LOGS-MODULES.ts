import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1008COMMUNICATIONLOGSMODULES1730688375321
  implements MigrationInterface
{
  name = 'ABMS1008COMMUNICATIONLOGSMODULES1730688375321';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "communication_logs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "commType" character varying NOT NULL, "accountId" uuid, "leadId" uuid, "dealId" uuid, "siteId" uuid, "recipient" character varying NOT NULL, "subjectEmail" character varying, "bodyEmail" text, "toEmail" text, "ccEmail" text, "bccEmail" text, "messageSMS" text, "toSMS" character varying, "callType" character varying, "subjectCall" character varying, "callOutcome" text, CONSTRAINT "PK_d20f31e44aa2108bd47d7a6f781" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('communication_log', 'Communication Logs', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'communication_log'`
    );
    await queryRunner.query(`DROP TABLE "communication_logs"`);
  }
}
