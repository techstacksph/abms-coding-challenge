import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2356TASKEVENTRELATION1742263366862
  implements MigrationInterface
{
  name = 'ABMS2356TASKEVENTRELATION1742263366862';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" ADD "eventId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "eventId"`);
  }
}
