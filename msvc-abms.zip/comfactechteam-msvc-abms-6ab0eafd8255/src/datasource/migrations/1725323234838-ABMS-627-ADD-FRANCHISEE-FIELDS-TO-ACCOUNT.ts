import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS627ADDFRANCHISEEFIELDSTOACCOUNT1725323234838
  implements MigrationInterface
{
  name = 'ABMS627ADDFRANCHISEEFIELDSTOACCOUNT1725323234838';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "legalName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "franchiseeType" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "regionalFranchisorId" uuid`
    );
    await queryRunner.query(`ALTER TABLE "accounts" ADD "startDate" TIMESTAMP`);
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "ayrMobile" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" ADD "ayrEmail" character varying`
    );
    await queryRunner.query(`ALTER TABLE "accounts" ADD "irdNo" numeric`);
    await queryRunner.query(`ALTER TABLE "accounts" ADD "recruitmentId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "recruitmentId"`
    );
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "irdNo"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "ayrEmail"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "ayrMobile"`);
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "startDate"`);
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "regionalFranchisorId"`
    );
    await queryRunner.query(
      `ALTER TABLE "accounts" DROP COLUMN "franchiseeType"`
    );
    await queryRunner.query(`ALTER TABLE "accounts" DROP COLUMN "legalName"`);
  }
}
