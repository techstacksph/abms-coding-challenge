import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS890FRANCHISEENOTIFICATIONMODULE1728312440328
  implements MigrationInterface
{
  name = 'ABMS890FRANCHISEENOTIFICATIONMODULE1728312440328';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "franchiseenotifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "subject" character varying NOT NULL, "message" text NOT NULL, "locationId" uuid, "franchiseeId" uuid, "sendSMS" boolean, "commId" uuid, "statusId" uuid, CONSTRAINT "PK_d7a1966d910b1b9b18840edbc0a" PRIMARY KEY ("id"))`
    );

    // Inserting into the modules table
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('franchiseenotifications', 'Franchisee Notifications', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "franchiseenotifications"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'franchiseenotifications'`
    );
  }
}
