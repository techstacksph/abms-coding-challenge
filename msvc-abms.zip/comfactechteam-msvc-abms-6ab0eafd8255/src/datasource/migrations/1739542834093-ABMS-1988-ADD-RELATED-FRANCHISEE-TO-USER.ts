import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1988ADDRELATEDFRANCHISEETOUSER1739542834093
  implements MigrationInterface
{
  name = 'ABMS1988ADDRELATEDFRANCHISEETOUSER1739542834093';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ADD "relatedFranchiseeAccountId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "relatedFranchiseeAccountId"`
    );
  }
}
