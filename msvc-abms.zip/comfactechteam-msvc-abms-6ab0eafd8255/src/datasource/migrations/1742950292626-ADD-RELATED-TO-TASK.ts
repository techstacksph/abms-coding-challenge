import { MigrationInterface, QueryRunner } from 'typeorm';

export class ADDRELATEDTOTASK1742950292626 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = true WHERE code = 'employee'`
    );
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = true WHERE code IN ('employee', 'evaluation', 'purchaseorder', 'qualityaudit', 'salesorder')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInTask" = false WHERE code = 'employee'`
    );
    await queryRunner.query(
      `UPDATE "modules" SET "isIncludedInEvent" = false WHERE code IN ('employee', 'evaluation', 'purchaseorder', 'qualityaudit', 'salesorder')`
    );
  }
}
