import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS690ADDUNIQUECONSTRAINTTOTASKTYPES1726720454399
  implements MigrationInterface
{
  name = 'ABMS690ADDUNIQUECONSTRAINTTOTASKTYPES1726720454399';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexTaskType_Code" ON "tasktypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexTaskType_Name" ON "tasktypes" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexTaskType_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexTaskType_Code"`);
  }
}
