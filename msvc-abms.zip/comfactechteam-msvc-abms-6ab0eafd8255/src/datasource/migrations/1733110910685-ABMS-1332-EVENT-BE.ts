import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSEVENTBE1733110910685 implements MigrationInterface {
  name = 'ABMSEVENTBE1733110910685';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "popupReminder" DROP DEFAULT`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "relatedToId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "relatedToId" DROP NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "events" ALTER COLUMN "popupReminder" SET DEFAULT 'FIFTEEN_MINUTES'`
    );
  }
}
