import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2464ADDPLACEIDTOSITES1742787555725
  implements MigrationInterface
{
  name = 'ABMS2464ADDPLACEIDTOSITES1742787555725';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "site" ADD "placeId" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "site" DROP COLUMN "placeId"`);
  }
}
