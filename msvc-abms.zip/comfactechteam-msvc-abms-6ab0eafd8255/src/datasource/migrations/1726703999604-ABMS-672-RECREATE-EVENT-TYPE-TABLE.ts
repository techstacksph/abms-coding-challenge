import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS672RECREATEEVENTTYPETABLE1726703999604
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "eventtypes"`);
    await queryRunner.query(
      `CREATE TABLE "eventtypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" character varying NOT NULL, "code" character varying, "description" character varying, CONSTRAINT "PK_678722eeb9545b4303fb78864b7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexEventType_Code" ON "eventtypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexEventType_Name" ON "eventtypes" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexEventType_Name"`);
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexEventType_Code"`);
    await queryRunner.query(`DROP TABLE "eventtypes"`);
    await queryRunner.query(
      `CREATE TABLE "eventtypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" character varying NOT NULL, "code" character varying, "description" character varying, CONSTRAINT "PK_678722eeb9545b4303fb78864b7" PRIMARY KEY ("id"))`
    );
  }
}
