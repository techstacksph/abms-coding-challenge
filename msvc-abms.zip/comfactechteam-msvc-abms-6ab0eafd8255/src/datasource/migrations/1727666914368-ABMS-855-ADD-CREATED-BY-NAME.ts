import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS834ADDCREATEDBYNAME1727666914368
  implements MigrationInterface
{
  name = 'ABMS834ADDCREATEDBYNAME1727666914368';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" ADD COLUMN IF NOT EXISTS "createdByName" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" DROP COLUMN "createdByName"`
    );
  }
}
