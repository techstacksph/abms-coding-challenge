import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS355CREATEMARKETPLACE1738180210313
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "marketplaces" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "marketplaceNo" character varying, "platformId" integer, "accountId" uuid NOT NULL, "locationId" uuid NOT NULL, "areaId" uuid NOT NULL, "suburb" character varying, "dateAvailability" date NOT NULL, "monthlyIncome" numeric NOT NULL DEFAULT '0', "outrightFee" numeric NOT NULL DEFAULT '0', "installmentFranchiseeFee" numeric NOT NULL DEFAULT '0', "addinfo" character varying, "cleaningSchedule" character varying NOT NULL, "cleaningDays" character varying, "jobId" uuid NOT NULL, "jobPurchaseId" uuid, "statusId" uuid NOT NULL, CONSTRAINT "PK_e4d5b8aa6ae255c4ce370792f79" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "marketplace_jobpurchases" ("marketplaceId" uuid NOT NULL, "jobPurchaseId" uuid NOT NULL, CONSTRAINT "PK_1d35adfd007c16f3a00ab1d3a79" PRIMARY KEY ("marketplaceId", "jobPurchaseId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_5315003fcd45d4c2088e123c95" ON "marketplace_jobpurchases" ("marketplaceId") `
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_19f206063f6820644132c65fb4" ON "marketplace_jobpurchases" ("jobPurchaseId") `
    );
    const module = await queryRunner.query(
      `SELECT id FROM "modules" WHERE code = 'marketplace'`
    );

    if (module.length == 0) {
      await queryRunner.query(
        `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('marketplace', 'Marketplace', '${TestIds.ORGANIZATION_ID}')`
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."IDX_19f206063f6820644132c65fb4"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_5315003fcd45d4c2088e123c95"`
    );
    await queryRunner.query(`DROP TABLE "marketplace_jobpurchases"`);
    await queryRunner.query(`DROP TABLE "marketplaces"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'marketplace'`
    );
  }
}
