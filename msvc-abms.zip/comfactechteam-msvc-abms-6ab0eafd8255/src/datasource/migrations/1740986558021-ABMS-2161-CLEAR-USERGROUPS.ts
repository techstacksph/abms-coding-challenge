import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { UserModel } from '../models/UserModel';

const defaultGroupId = TestIds.DEFAULT_GROUP_ID;

export class ABMS2161CLEARUSERGROUPS1740986558021
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "usergroups"`);

    const users: Array<UserModel> = await queryRunner.query(`
      SELECT id, "firstName", "lastName" FROM "users" WHERE "deletedAt" IS NULL
    `);

    for (let i = 0; i < users.length; i++) {
      const user = users[i];
      const { id, firstName, lastName } = user;

      await queryRunner.query(`
        UPDATE 
          "users"
        SET
          "groupId" = '${JSON.stringify([defaultGroupId])}'
        WHERE
          id = '${id}'
      `);

      await queryRunner.query(`
        INSERT INTO "usergroups"
          ("userId","groupId","userFullName", "orgId")
        VALUES
          ('${id}','${defaultGroupId}','${firstName} ${lastName}','${TestIds.ORGANIZATION_ID}')
      `);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "usergroups"`);

    await queryRunner.query(`
      UPDATE 
        "users"
      SET
        "groupId" = '${JSON.stringify([defaultGroupId])}'
      WHERE
        "deletedAt" IS NULL
    `);
  }
}
