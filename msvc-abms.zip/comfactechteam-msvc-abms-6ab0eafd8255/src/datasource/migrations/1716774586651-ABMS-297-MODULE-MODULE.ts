import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS297MODULEMODULE1716774586651 implements MigrationInterface {
  name = 'ABMS297MODULEMODULE1716774586651';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "modules" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "code" citext NOT NULL, "name" character varying NOT NULL, "isIncludedInTask" boolean DEFAULT false, "isIncludedInEvent" boolean DEFAULT false, CONSTRAINT "PK_7dbefd488bd96c5bf31f0ce0c95" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "IndexUnique_ModuleCode" ON "modules" ("code") WHERE "deletedAt" IS NULL`
    );

    const seedValues: Array<string> = [];
    const data = [
      { code: 'country', name: 'Country' },
      { code: 'department', name: 'Department' },
      { code: 'function', name: 'Function' },
      { code: 'group', name: 'Group' },
      { code: 'location', name: 'Location' },
      { code: 'module', name: 'Module' },
      { code: 'organization', name: 'Organization' },
      { code: 'person', name: 'Person' },
      { code: 'securityLevel', name: 'Security Level' },
      { code: 'systemsettings', name: 'System Settings' },
      { code: 'timezone', name: 'Time Zone' },
      { code: 'usergroup', name: 'User Group' },
      { code: 'user', name: 'User' },
    ];

    data.forEach((module) => {
      const { name, code } = module;
      seedValues.push(`('${name}', '${code}', '${TestIds.ORGANIZATION_ID}')`);
    });

    await queryRunner.query(
      `INSERT INTO "modules" ("code","name", "orgId") VALUES ${seedValues.join(
        ','
      )}`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."IndexUnique_ModuleCode"`);
    await queryRunner.query(`DROP TABLE "modules"`);
  }
}
