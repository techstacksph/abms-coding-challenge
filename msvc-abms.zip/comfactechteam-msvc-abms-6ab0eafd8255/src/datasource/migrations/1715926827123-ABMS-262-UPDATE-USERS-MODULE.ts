import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS262UPDATEUSERSMODULE1715926827123
  implements MigrationInterface
{
  name = 'ABMS262UPDATEUSERSMODULE1715926827123';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "profileImage"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "profilePic" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "jobTitle" character varying`
    );
    await queryRunner.query(`ALTER TABLE "users" ADD "setPassword" boolean`);
    await queryRunner.query(`ALTER TABLE "users" ADD "requireThis" boolean`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "locationId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "departmentId" uuid NOT NULL`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "functionId" uuid NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "users" ADD "userGroupIds" text`);
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "timeZoneId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "timeZoneId" DROP NOT NULL`
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "userGroupIds"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "functionId"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "departmentId"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "locationId"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "requireThis"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "setPassword"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "jobTitle"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "profilePic"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "profileImage" character varying`
    );
  }
}
