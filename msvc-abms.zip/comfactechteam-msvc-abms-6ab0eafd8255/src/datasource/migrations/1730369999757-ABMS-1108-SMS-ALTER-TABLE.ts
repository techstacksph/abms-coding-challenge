import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1108SMSALTERTABLE1730369999757 implements MigrationInterface {
  name = 'ABMS1108SMSALTERTABLE1730369999757';
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "sms" DROP COLUMN "startDate"`);
    await queryRunner.query(`ALTER TABLE "sms" ADD "startDate" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "sms" DROP COLUMN "endDate"`);
    await queryRunner.query(`ALTER TABLE "sms" ADD "endDate" TIMESTAMP`);
  }
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "sms" DROP COLUMN "endDate"`);
    await queryRunner.query(`ALTER TABLE "sms" ADD "endDate" date`);
    await queryRunner.query(`ALTER TABLE "sms" DROP COLUMN "startDate"`);
    await queryRunner.query(`ALTER TABLE "sms" ADD "startDate" date NOT NULL`);
  }
}
