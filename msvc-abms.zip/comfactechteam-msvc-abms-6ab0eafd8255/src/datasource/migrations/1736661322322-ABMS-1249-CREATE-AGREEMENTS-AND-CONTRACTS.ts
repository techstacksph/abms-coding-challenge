import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS1249CREATEAGREEMENTSANDCONTRACTS1736661322322
  implements MigrationInterface
{
  name = 'ABMS1249CREATEAGREEMENTSANDCONTRACTS1736661322322';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "leaves" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "autoNumber" SERIAL, "agreementsContractNo" character varying, "type" character varying NOT NULL, "documentBody" character varying, "effectiveDate" date, "expirationDate" date, "agreementPDF" character varying, "signedAgreement" character varying, "statusId" uuid, CONSTRAINT "PK_4153ec7270da3d07efd2e11e2a7" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('leave', 'Agreements And Contracts', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "leaves"`);
    await queryRunner.query(`DELETE FROM "modules" WHERE "code" = 'leave'`);
  }
}
