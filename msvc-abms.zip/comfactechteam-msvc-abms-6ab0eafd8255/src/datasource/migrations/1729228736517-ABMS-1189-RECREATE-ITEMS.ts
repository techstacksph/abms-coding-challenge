import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1189RECREATEITEMS1729228736517 implements MigrationInterface {
  name = 'ABMS1189RECREATEITEMS1729228736517';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "items" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "createdByName" character varying, "name" citext NOT NULL, "itemType" character varying NOT NULL, "description" character varying, "itemCategoryId" uuid NOT NULL, "itemSubcategoryId" uuid, "itemStatus" boolean DEFAULT false, "isKit" boolean DEFAULT false, "supplierId" uuid, "productImage" text, "serviceTypeId" uuid, "variantTypeId" uuid, "serviceProviderId" uuid, "brand" character varying, "modelNo" character varying, "countryId" uuid, "maxDemandPerDay" integer, "tags" text, "uomId" uuid, "size" character varying, "dimension" character varying, "weight" character varying, "color" character varying, "pricing" integer, "video" character varying, CONSTRAINT "PK_ba5885359424c15ca6b9e79bcf6" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexItem_Name" ON "items" ("name") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexItem_Name"`);
    await queryRunner.query(`DROP TABLE "items"`);
  }
}
