import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS866AREAINWAREHOUSE1734234353096 implements MigrationInterface {
  name = 'ABMS866AREAINWAREHOUSE1734234353096';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "warehouses" ADD IF NOT EXISTS "area" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "warehouses" DROP COLUMN "area"`);
  }
}
