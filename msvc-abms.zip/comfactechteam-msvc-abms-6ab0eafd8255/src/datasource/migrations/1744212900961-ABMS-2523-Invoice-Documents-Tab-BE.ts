import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS2523InvoiceDocumentsTabBE1744212900961
  implements MigrationInterface
{
  name = 'ABMS2523InvoiceDocumentsTabBE1744212900961';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documents" ADD "invoiceId" uuid`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documents" DROP COLUMN "invoiceId"`);
  }
}
