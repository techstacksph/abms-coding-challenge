import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS38UPDATEFIELDCONSTRAINT1717569238235
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "functions" ALTER COLUMN "name" TYPE citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "functions" ALTER COLUMN "name" TYPE character varying`
    );
  }
}
