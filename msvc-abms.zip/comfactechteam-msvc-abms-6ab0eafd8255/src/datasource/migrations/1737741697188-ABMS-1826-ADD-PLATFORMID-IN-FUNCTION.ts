import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1826ADDPLATFORMIDINFUNCTION1737741697188
  implements MigrationInterface
{
  name = 'ABMS1826ADDPLATFORMIDINFUNCTION1737741697188';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "functions" ADD "platformId" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "functions" DROP COLUMN "platformId"`);
  }
}
