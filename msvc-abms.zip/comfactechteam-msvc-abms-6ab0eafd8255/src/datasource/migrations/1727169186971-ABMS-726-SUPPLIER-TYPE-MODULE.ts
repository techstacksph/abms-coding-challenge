import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS726SUPPLIERTYPEMODULE1727169186971
  implements MigrationInterface
{
  name = 'ABMS726SUPPLIERTYPEMODULE1727169186971';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "suppliertypes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orgId" uuid, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdBy" uuid, "updatedBy" uuid, "deletedBy" uuid, "recordLocked" boolean NOT NULL DEFAULT false, "lockedBy" uuid, "timeLocked" TIMESTAMP NOT NULL DEFAULT now(), "updatedByName" character varying, "name" citext NOT NULL, "code" citext, "description" character varying, CONSTRAINT "PK_17c281f53c6862227d1c19b17ea" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSupplierType_Code" ON "suppliertypes" ("code") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexSupplierType_Name" ON "suppliertypes" ("name") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `INSERT INTO "modules" ("code", "name", "orgId") VALUES ('suppliertype', 'Supplier Type', '${TestIds.ORGANIZATION_ID}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexSupplierType_Name"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexSupplierType_Code"`
    );
    await queryRunner.query(`DROP TABLE "suppliertypes"`);
    await queryRunner.query(
      `DELETE FROM "modules" WHERE "code" = 'suppliertype'`
    );
  }
}
