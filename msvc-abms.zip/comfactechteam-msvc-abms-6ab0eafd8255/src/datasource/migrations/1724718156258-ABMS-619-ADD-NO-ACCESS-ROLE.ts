import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS619ADDNOACCESSROLE1724718156258 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const roleExists = await queryRunner.query(
      `SELECT 1 FROM "userroles" WHERE "role" = 'No Access'`
    );

    if (roleExists.length === 0) {
      await queryRunner.query(
        `
          INSERT INTO "userroles"
          ("orgId", "createdAt", "updatedAt", "deletedAt", "createdBy", "updatedBy", "deletedBy", "recordLocked", "lockedBy", "timeLocked", "updatedByName", "role", "description") 
          VALUES 
          ('${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT , DEFAULT, DEFAULT, 'No Access', 'This is a no access role')
        `
      );
    } else {
      await queryRunner.query(
        `
          UPDATE "userroles"
          SET 
            "orgId" = '${TestIds.ORGANIZATION_ID}',
            "updatedAt" = DEFAULT,
            "deletedAt" = DEFAULT,
            "createdBy" = '${TestIds.PERSON_ID}',
            "updatedBy" = DEFAULT,
            "deletedBy" = DEFAULT,
            "recordLocked" = DEFAULT,
            "lockedBy" = DEFAULT,
            "timeLocked" = DEFAULT,
            "updatedByName" = DEFAULT,
            "role" = 'No Access',
            "description" = 'This is a no access role'
          WHERE "role" = 'No Access'
        `
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "userroles" WHERE "role"='No Access'`);
  }
}
