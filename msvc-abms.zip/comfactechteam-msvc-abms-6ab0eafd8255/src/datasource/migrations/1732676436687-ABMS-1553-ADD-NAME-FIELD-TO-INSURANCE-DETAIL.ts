import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS1553ADDNAMEFIELDTOINSURANCEDETAIL1732676436687
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "insurancedetails" ADD "name" character varying NOT NULL DEFAULT ''`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "insurancedetails" DROP COLUMN "name"`
    );
  }
}
