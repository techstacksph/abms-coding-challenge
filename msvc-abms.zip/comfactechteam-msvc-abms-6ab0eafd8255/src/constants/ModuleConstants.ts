export const MODULE_CODES = {
  SALES_ORDER: 'salesorder',
} as const;

export type ModuleCodeKey = keyof typeof MODULE_CODES;
