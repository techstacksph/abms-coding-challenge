/**
 * QualityAudit entity relations configuration
 * Centralized source of truth for QualityAudit-related relations used by:
 * - QualityAuditResolver.getAvailableRelations()
 * - QualityAuditDataLoaders configuration
 */

/**
 * All available relations for QualityAudit entity
 * Used by both QualityAuditResolver and QualityAuditDataLoaders
 */
export const QUALITY_AUDIT_AVAILABLE_RELATIONS = [
  'job',
  'recordOwner',
  'location',
  'job.account',
  'job.account.franchiseeAgreements',
  'job.account.franchiseeAgreements.franchisee',
  'job.account.primaryContact',
  'job.site',
  'job.contact',
  'job.location',
  'job.keyAccount',
  'job.supervisor',
  'job.dealOwner',
  'job.telesales',
  'job.jobSchedules',
  'job.jobSchedules.status',
  'job.status',
  'job.jobSpecifications',
  'job.jobSpecifications.variants',
  'job.jobBillings',
  'job.jobBillings.serviceProvider',
  'status',
  'qaAreas',
  'qaSpecifications',
  'qaSpecifications.qaArea',
  'reviewedBy',
  'franchisees',
] as const;
