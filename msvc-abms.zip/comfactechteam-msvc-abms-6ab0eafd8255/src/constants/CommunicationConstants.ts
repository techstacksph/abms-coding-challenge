export const COMM_TYPES = {
  EMAIL: 'Email',
  SMS: 'SMS',
  CALLS: 'Calls',
} as const;

export const COMM_STATUS = {
  DELIVERED: 'delivered',
  FAILED: 'failed',
} as const;

export type CommunicationTypeKey = keyof typeof COMM_TYPES;
export type CommunicationStatusKey = keyof typeof COMM_STATUS;
