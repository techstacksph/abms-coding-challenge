export const SALES_ORDER_STATUS = {
  DELIVERED: 'delivered',
  READY_FOR_PICKUP: 'ready for pick-up',
} as const;

export const EMAIL_TEMPLATES = {
  NEW_ORDER: 'new-order',
  DELIVERED: 'delivered',
  READY_FOR_PICKUP: 'ready-for-pickup',
} as const;

export type SalesOrderStatusKey = keyof typeof SALES_ORDER_STATUS;
export type SalesOrderEmailTemplateKey = keyof typeof EMAIL_TEMPLATES;
