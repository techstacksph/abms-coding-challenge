import { PulsarTopics } from '../enums/PulsarTopics';

/**
 * Common configurations for scheduled jobs
 */
export const ScheduledJobSources = {
  /** Primary back office source for most scheduled jobs */
  BACK_OFFICE: PulsarTopics.BACK_OFFICE,
  /** Communication media source for email/SMS jobs */
  COMMUNICATION_MEDIA: PulsarTopics.COMMUNICATION_MEDIA,
  /** Authorization source for user/security related jobs */
  AUTHORIZATION: PulsarTopics.AUTHORIZATION,
} as const;

/**
 * Common object names for scheduled jobs
 */
export const ScheduledJobServices = {
  DEAL_FOLLOW_UP_SERVICE: 'DealFollowUpService',
  JOB_SERVICE: 'JobService',
  JOB_SCHEDULE_SERVICE: 'JobScheduleService',
  USER_SERVICE: 'UserService',
  EMAIL_SERVICE: 'EmailService',
  NOTIFICATION_AND_ALERT_SERVICE: 'NotificationAndAlertService',
  TASK_SERVICE: 'TaskService',
  EVENT_SERVICE: 'EventService',
  QUALITY_AUDIT_SERVICE: 'QualityAuditService',
  AGREEMENT_HISTORY_SERVICE: 'AgreementHistoryService',
  SECURITY_CHECK_EXPIRY_SERVICE: 'SecurityCheckExpiryService',
} as const;

/**
 * Scheduled job names for consistency across the application
 */
export const ScheduledJobNames = {
  GENERATE_JOB_SCHEDULES: 'GENERATE_JOB_SCHEDULES',
  DEAL_FOLLOW_UP_EMAILS: 'DEAL_FOLLOW_UP_EMAILS',
  TASK_REMINDER: 'TASK_REMINDER',
  EVENT_REMINDER: 'EVENT_REMINDER',
  OVERDUE_TASK_NOTIFICATION: 'OVERDUE_TASK_NOTIFICATION',
  AUTO_COMPLETE_OVERDUE_JOB_SCHEDULES: 'AUTO_COMPLETE_OVERDUE_JOB_SCHEDULES',
  GENERATE_MONTHLY_QUALITY_AUDITS: 'GENERATE_MONTHLY_QUALITY_AUDITS',
  GENERATE_WEEKLY_QA_EMAIL_ACTIVITIES: 'GENERATE_WEEKLY_QA_EMAIL_ACTIVITIES',
  GENERATE_AGREEMENT_HISTORY: 'GENERATE_AGREEMENT_HISTORY',
  EXPIRE_SECURITY_CHECKS: 'EXPIRE_SECURITY_CHECKS',
} as const;

/**
 * Common method names for scheduled jobs
 */
export const ScheduledJobMethods = {
  PROCESS_DEAL_FOLLOW_UP_EMAILS: 'processDealFollowUpEmails',
  GENERATE_NEXT_PERIOD_SCHEDULES: 'generateNextPeriodSchedules',
  PROCESS_USER_NOTIFICATIONS: 'processUserNotifications',
  UPDATE_JOB_STATUS_TO_CANCELLED: 'updateJobStatusToCancelled',
  TRANSFER_JOB: 'transferJob',
  PROCESS_PENDING_TRANSFERS: 'processPendingTransfers',
  PROCESS_TASK_REMINDER: 'processTaskReminder',
  PROCESS_EVENT_REMINDER: 'processEventReminder',
  SEND_TASK_REMINDER: 'sendTaskReminder',
  SEND_EVENT_REMINDER: 'sendEventReminder',
  SEND_OVERDUE_TASK_NOTIFICATIONS: 'sendOverdueTaskNotifications',
  AUTO_COMPLETE_OVERDUE_JOB_SCHEDULES: 'autoCompleteOverdueJobSchedules',
  GENERATE_MONTHLY_QUALITY_AUDITS: 'generateMonthlyQualityAudits',
  GENERATE_WEEKLY_QA_EMAIL_ACTIVITIES: 'generateWeeklyQAEmailActivities',
  GENERATE_AGREEMENT_HISTORY: 'generateMonthlyHistory',
  EXPIRE_SECURITY_CHECKS: 'expireSecurityChecks',
} as const;

/**
 * Pre-configured job data templates for common scheduled jobs
 */
export const ScheduledJobTemplates = {
  DEAL_FOLLOW_UP_EMAILS: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.PROCESS_DEAL_FOLLOW_UP_EMAILS,
    objectName: ScheduledJobServices.DEAL_FOLLOW_UP_SERVICE,
    objectId: 'processDealFollowUpEmails',
    data: {},
  },

  GENERATE_JOB_SCHEDULES: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.GENERATE_NEXT_PERIOD_SCHEDULES,
    objectName: ScheduledJobServices.JOB_SERVICE,
    objectId: 'generateNextPeriodSchedules',
    data: {},
  },

  PROCESS_PENDING_TRANSFERS: {
    type: 'TRANSFER_JOB' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.PROCESS_PENDING_TRANSFERS,
    objectName: ScheduledJobServices.JOB_SERVICE,
    objectId: 'processPendingTransfers',
    data: {},
  },

  TASK_REMINDER: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.SEND_TASK_REMINDER,
    objectName: ScheduledJobServices.TASK_SERVICE,
    objectId: 'sendTaskReminder',
    data: {},
  },

  EVENT_REMINDER: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.SEND_EVENT_REMINDER,
    objectName: ScheduledJobServices.EVENT_SERVICE,
    objectId: 'sendEventReminder',
    data: {},
  },

  OVERDUE_TASK_NOTIFICATION: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.SEND_OVERDUE_TASK_NOTIFICATIONS,
    objectName: ScheduledJobServices.TASK_SERVICE,
    objectId: 'sendOverdueTaskNotifications',
    data: {},
  },

  AUTO_COMPLETE_OVERDUE_JOB_SCHEDULES: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.AUTO_COMPLETE_OVERDUE_JOB_SCHEDULES,
    objectName: ScheduledJobServices.JOB_SCHEDULE_SERVICE,
    objectId: 'autoCompleteOverdueJobSchedules',
    data: {},
  },

  GENERATE_MONTHLY_QUALITY_AUDITS: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.GENERATE_MONTHLY_QUALITY_AUDITS,
    objectName: ScheduledJobServices.QUALITY_AUDIT_SERVICE,
    objectId: 'generateMonthlyQualityAudits',
    data: {},
  },

  GENERATE_WEEKLY_QA_EMAIL_ACTIVITIES: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.GENERATE_WEEKLY_QA_EMAIL_ACTIVITIES,
    objectName: ScheduledJobServices.QUALITY_AUDIT_SERVICE,
    objectId: 'generateWeeklyQAEmailActivities',
    data: {},
  },

  GENERATE_AGREEMENT_HISTORY: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.GENERATE_AGREEMENT_HISTORY,
    objectName: ScheduledJobServices.AGREEMENT_HISTORY_SERVICE,
    objectId: 'generateMonthlyHistory',
    data: {},
  },

  EXPIRE_SECURITY_CHECKS: {
    type: 'EXECUTE_FUNCTION' as const,
    source: ScheduledJobSources.BACK_OFFICE,
    name: ScheduledJobMethods.EXPIRE_SECURITY_CHECKS,
    objectName: ScheduledJobServices.SECURITY_CHECK_EXPIRY_SERVICE,
    objectId: 'expireSecurityChecks',
    data: {},
  },
} as const;

/**
 * Timezone configuration for scheduled jobs
 * All cron patterns are expressed in Pacific/Auckland local time
 * BullMQ automatically handles DST transitions when timezone is specified
 */
export const SCHEDULER_TIMEZONE = 'Pacific/Auckland';

/**
 * Common cron patterns for scheduled jobs
 * Times are in Pacific/Auckland LOCAL time
 *
 * IMPORTANT: These patterns use LOCAL time (not UTC)
 * When used with BullMQ's timezone option (tz: SCHEDULER_TIMEZONE),
 * jobs will ALWAYS run at the specified local time, regardless of DST.
 *
 * Example: DAILY_8AM will send emails at 8:00 AM Pacific/Auckland time
 * both during NZDT (UTC+13) and NZST (UTC+12) - NO manual adjustment needed!
 *
 * NOTE: Ensure all BullMQ job registrations include: { repeat: { pattern, tz: SCHEDULER_TIMEZONE } }
 */
export const ScheduledJobPatterns = {
  /** Daily at 12:00 AM (midnight) Pacific/Auckland */
  DAILY_MIDNIGHT: '0 0 * * *',
  /** Daily at 1:00 AM Pacific/Auckland */
  DAILY_1AM: '0 1 * * *',
  /** Daily at 6:00 AM Pacific/Auckland */
  DAILY_6AM: '0 6 * * *',
  /** Daily at 8:00 AM Pacific/Auckland */
  DAILY_8AM: '0 8 * * *',
  /** Daily at 5:00 PM Pacific/Auckland */
  DAILY_5PM: '0 17 * * *',
  /** Every hour at minute 0 */
  HOURLY: '0 * * * *',
  /** Every 15 minutes */
  EVERY_15_MINUTES: '*/15 * * * *',
  /** Every 30 minutes */
  EVERY_30_MINUTES: '*/30 * * * *',
  /** Every 5 minutes */
  EVERY_5_MINUTES: '*/5 * * * *',
  /** Every 10 minutes */
  EVERY_10_MINUTES: '*/10 * * * *',
  /** Weekly on Monday at 8:00 AM Pacific/Auckland */
  WEEKLY_MONDAY_8AM: '0 8 * * 1',
  /** Weekly on Friday at 8:00 AM Pacific/Auckland */
  WEEKLY_FRIDAY_8AM: '0 8 * * 5',
  /** Monthly on first day at 8:00 AM Pacific/Auckland */
  MONTHLY_FIRST_DAY_8AM: '0 8 1 * *',
  /** Monthly on 27th day at 8:00 AM Pacific/Auckland */
  MONTHLY_27TH_8AM: '0 8 27 * *',
  /** Monthly on 28th day at 8:00 AM Pacific/Auckland */
  MONTHLY_28TH_8AM: '0 8 28 * *',
  /** Monthly on 29th day at 8:00 AM Pacific/Auckland */
  MONTHLY_29TH_8AM: '0 8 29 * *',
} as const;
