import environment from '../environment';

export const SchemaPrefix = environment.TENANT_PREFIX;
