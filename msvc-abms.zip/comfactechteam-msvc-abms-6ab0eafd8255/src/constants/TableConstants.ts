export const AMENDMENT_TYPES = 'amendmenttypes';
export const INDEX_AMENDMENT_TYPE_NAME =
  'UniqueIndexAmendmentName_AmendmentTypeName';
export const INDEX_AMENDMENT_TYPE_CODE =
  'UniqueIndexAmendmentCode_AmendmentTypeCode';

export const SERVICE_TYPE = 'servicetypes';
export const INDEX_SERVICE_TYPE_NAME =
  'UniqueIndexServiceTypeName_ServiceTypeName';
export const INDEX_SERVICE_TYPE_CODE =
  'UniqueIndexServiceTypeCode_ServiceTypeCode';

export const CANCELLATION_TYPE = 'cancellationType';
export const INDEX_CANCELLATION_TYPE_NAME =
  'UniqueIndexCancellationType_CancellationTypeName';
export const INDEX_CANCELLATION_TYPE_CODE =
  'UniqueIndexCancellationTypeCode_CancellationTypeCode';

export const SERVICE_PROVIDER_ASSIGNMENTS = 'serviceproviderassignments';
export const JOB_DETAILS = 'jobdetails';
export const JOB_SPECIFICATION = 'jobspecifications';
