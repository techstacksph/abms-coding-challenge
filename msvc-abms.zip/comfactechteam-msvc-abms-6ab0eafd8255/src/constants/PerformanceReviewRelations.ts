/**
 * PerformanceReview entity relations configuration
 * Centralized source of truth for PerformanceReview-related relations
 */

export const PERFORMANCE_REVIEW_RELATIONS = [
  'status',
  'employee',
  'manager',
  'relatedManager',
  'performanceReviewQuestions',
  'performanceReviewQuestions.question',
  'performanceReviewQuestions.questionnaire',
  'prDepartments',
  'prDepartments.department',
  'prQuestionnaires',
  'prQuestionnaires.questionnaire',
  'reviewPeriodDetails',
] as const;
