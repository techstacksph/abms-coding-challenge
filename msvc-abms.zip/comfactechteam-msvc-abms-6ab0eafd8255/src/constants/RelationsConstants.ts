/**
 * Centralized relations configuration for resolvers and DataLoaders
 * This file re-exports all relation constants from individual files
 */

// Job relations
export { JOB_AVAILABLE_RELATIONS } from './JobRelations';

// QualityAudit relations
export { QUALITY_AUDIT_AVAILABLE_RELATIONS } from './QualityAuditRelations';
