/**
 * Job entity relations configuration
 * Centralized source of truth for Job-related relations used by:
 * - JobResolver.getAvailableRelations()
 * - JobDataLoaders configuration
 */

/**
 * All available relations for Job entity
 * Used by both JobResolver and JobDataLoaders
 */
export const JOB_AVAILABLE_RELATIONS = [
  'account',
  'account.status',
  'account.primaryContact',
  'site',
  'site.area',
  'contact',
  'deals.serviceType',
  'deals.serviceType.expenseAccountCode',
  'deals.serviceType.salesAccountCode',
  'deals.dealOrderDetails',
  'deals.dealOrderDetails.dealSpecifications',
  'deals.dealOrderDetails.dealSpecifications.variant',
  'deals.recordOwner',
  'dealOwner',
  'telesales',
  'location',
  'location.xeroAccount',
  'location.area',
  'keyAccount',
  'supervisor',
  'status',
  'serviceProviders',
  'serviceProviders.serviceProvider',
  'jobDetails',
  'jobDetails.dealOrderDetails',
  'jobDetails.serviceProvider',
  'jobDetails.jobSpecification',
  'jobDetails.jobSpecification.variants',
  'jobDetails.jobSpecification.serviceProviderAssignments',
  'jobDetails.jobSpecification.serviceProviderAssignments.serviceProvider',
  'jobDetails.jobSpecification.serviceProviderAssignments.jobSpecification',
  'jobDetails.jobSpecification.dealSpecification',
  'owners',
  'owners.owner',
  'invoiceTemplates',
  'billTemplate',
  'cases',
  'jobBillings',
  'jobBillings.serviceProvider',
  'creditDebitNotes',
  'salesOrders',
  'qualityAudits',
  'communicationLogs',
  'notes',
  'tasks',
  'events',
  'document',
  'jobAreas',
  'jobScheduleLogs',
  'jobProcessings',
  'jobToBatchJobTransfers',
  'jobToBatchJobTransfers.batchJobTransfer',
  'invoices',
  'allocatedJobs',
  'qaRecurring',
] as const;
