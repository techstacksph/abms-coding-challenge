# MSVC Communication Media

A microservice for handling communication and media functionality within the ABMS ecosystem, including SMS messaging, email communications, and media file management.

## Overview

This service provides comprehensive communication capabilities with the following key features:
- **SMS Messaging** with MessageMedia integration
- **Email Communications** with templating support
- **Media File Management** for handling uploads and storage
- **Secure API endpoints** with authentication
- **Apache Pulsar integration** for distributed messaging
- **Database persistence** with TypeORM and PostgreSQL

## Docker Development Environment (Recommended)

For the best development experience with hot reload and isolated environments, use the Docker development setup:

### Prerequisites for Docker Development
- Docker and Docker Compose
- Node.js 20+ (for local development)

### Quick Start with Docker

**Option 1: Full Development Environment (Recommended)**
Start all services including PostgreSQL, Redis, and Pulsar with hot reload:
```bash
yarn docker:dev:full
```
This will:
- Create the `local_bridge` Docker network
- Start PostgreSQL, Redis, and Pulsar services
- Build and start the communication media microservice with hot reload
- Automatically create the development database (`DOCKER_MSVC_COMMUNICATION_MEDIA`)
- Run database migrations
- Mount source code for instant reload on changes

**Option 2: Microservice Only**
If you have infrastructure running elsewhere:
```bash
yarn docker:dev
```

**Option 3: Infrastructure Only**
Start shared services (PostgreSQL, Redis, Pulsar) without the microservice:
```bash
yarn docker:infrastructure
```

### Docker Development Features

✅ **Hot Reload**: Code changes in `src/` automatically restart the server  
✅ **Isolated Database**: Separate `DOCKER_MSVC_COMMUNICATION_MEDIA` database for development  
✅ **Auto Database Creation**: Database created automatically if it doesn't exist  
✅ **Volume Mounts**: Source code, config files mounted for instant updates  
✅ **One Command Setup**: Everything starts with `yarn docker:dev:full`  
✅ **Web UIs Available**:
  - **Communication Media API**: http://localhost:8086
  - **Swagger Docs**: http://localhost:8086/api-docs
  - **Redis Commander**: http://localhost:8081 (if using full infrastructure)
  - **Pulsar Admin**: http://localhost:8080 (if using full infrastructure)

### Docker Management Commands

```bash
# Start full environment
yarn docker:dev:full

# Start microservice only
yarn docker:dev

# Start infrastructure only
yarn docker:infrastructure

# Stop and restart with rebuild
yarn docker:dev:restart

# Stop microservice
yarn docker:dev:down

# Stop infrastructure
yarn docker:infrastructure:down

# View logs
docker-compose -f docker-compose.dev.yml logs -f

# Access container shell
docker exec -it msvc-cto-communication-media sh
```

### Docker Development Configuration

The development environment uses:
- **Port**: 8086 (mapped to host)
- **Database**: `DOCKER_MSVC_COMMUNICATION_MEDIA` (auto-created)
- **Network**: `local_bridge` (shared with other microservices)
- **Node Version**: 20.13.1 (matches production)
- **Environment**: All required variables pre-configured

### Troubleshooting Docker Development

**Issue: Port already in use**
```bash
# Check what's using the port
lsof -i :8086
# Stop any existing containers
docker-compose -f docker-compose.dev.yml down
```

**Issue: Database connection fails**
```bash
# Restart infrastructure
yarn docker:infrastructure:down
yarn docker:infrastructure
```

**Issue: Hot reload not working**
- Ensure source code is mounted: check `docker-compose.dev.yml` volumes
- Restart the development container: `yarn docker:dev:restart`

**Issue: Node modules issues**
```bash
# Rebuild containers
docker-compose -f docker-compose.dev.yml build --no-cache
```

### Switching Between Docker and Local Development

**Docker Development (Recommended)**:
- Consistent environment across team
- Hot reload with volume mounts  
- Isolated database and dependencies
- One command setup

**Local Development**:
- Direct Node.js execution
- Requires local PostgreSQL, Redis, Pulsar
- Manual database setup
- Environment variables from `.env`

## Local Development Setup

### Prerequisites
- Node.js 20.13.1+ 
- PostgreSQL database
- Redis server
- Apache Pulsar (optional, for distributed messaging)

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   yarn install
   ```

3. Set up environment variables (copy from `environment.ts`)

4. Start the database and dependencies

5. Run database migrations:
   ```bash
   yarn migration:run
   ```

6. Start the development server:
   ```bash
   yarn dev
   ```

The service will be available at `http://localhost:8086`

## Available Scripts

**Development Scripts:**
- `yarn dev` - Start development server with hot reload (local)
- `yarn docker:dev:full` - Start full Docker development environment (recommended)
- `yarn docker:dev` - Start microservice in Docker only
- `yarn docker:infrastructure` - Start PostgreSQL, Redis, and Pulsar services

**Build Scripts:**
- `yarn build` - Build the TypeScript project
- `yarn clean` - Clean build artifacts

**Docker Management:**
- `yarn docker:dev:restart` - Restart development container with rebuild
- `yarn docker:dev:down` - Stop microservice container
- `yarn docker:infrastructure:down` - Stop infrastructure services

**Database Scripts:**
- `yarn migration:run` - Execute database migrations
- `yarn migration:generate` - Generate new migrations
- `yarn migration:create` - Create a new migration file
- `yarn migration:revert` - Revert the last migration

**Testing & Code Quality:**
- `yarn test` - Run the test suite
- `yarn test:local` - Run tests with local database
- `yarn lint` - Run linting and formatting
- `yarn format` - Format code with Prettier

## API Features

### SMS Messaging
- MessageMedia integration for SMS sending
- Delivery status callbacks
- Template-based messaging
- Bulk SMS capabilities

### Email Communications
- SMTP email sending
- HTML and text templates
- Attachment support
- Email queue management

### Media Management
- File upload handling
- Image processing and optimization
- Secure file storage
- Media metadata management

## Architecture

### Components
- **Communication Controllers**: REST API endpoints for SMS, email, and media
- **MessageMedia Service**: SMS provider integration
- **Email Service**: SMTP and template management
- **Media Service**: File handling and storage
- **Authentication Service**: API security and authorization

### Database
- PostgreSQL with TypeORM for data persistence
- Media metadata and communication logs
- Template storage and management
- Configurable connection settings

### Message Queue Integration
- Apache Pulsar for distributed communication events
- Reliable message delivery for notifications
- Event-driven communication workflows

## Configuration

Key environment variables:
- `DATABASE_URL` - PostgreSQL connection string
- `PULSAR_SERVICE_URL` - Apache Pulsar broker URL
- `SMS_MESSAGEMEDIA_*` - MessageMedia API configuration
- `MAILER_*` - SMTP email configuration
- `JWT_SECRET_KEY` - Authentication key
- `LOG_LEVEL` - Logging level (debug, info, warn, error)

## API Documentation

Swagger documentation is available at `/api-docs` when the service is running.

## Testing

Run the test suite:
```bash
yarn test
```

For local testing with a test database:
```bash
yarn test:local
```

## Docker Support

The service includes comprehensive Docker configuration:

**Development Files:**
- `Dockerfile.dev` - Development build with hot reload support
- `docker-compose.dev.yml` - Development environment with volume mounts
- `docker-entrypoint.dev.sh` - Development startup script with database auto-creation

**Production Files:**
- `Dockerfile` - Production build
- `docker-compose.yml` - Production environment
- `docker-entrypoint.sh` - Production startup script

**Infrastructure Files:**
- `docker-compose-postgres.yml` - PostgreSQL service
- `docker-compose-redis.yml` - Redis service  
- `docker-compose-pulsar.yml` - Apache Pulsar service

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite and linting
6. Submit a pull request

## License

ISC License