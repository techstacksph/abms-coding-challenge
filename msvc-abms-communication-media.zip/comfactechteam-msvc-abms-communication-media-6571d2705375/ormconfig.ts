import path from 'path';
import { DataSource, DataSourceOptions, LoggerOptions } from 'typeorm';

import environment from './src/environment';

const subscriber_path = path.join('src/datasource/subscribers/**/*.{js,ts}');
const entity_path = path.join('src/datasource/models/**/*.{js,ts}');
const migration_path = path.join('src/datasource/migrations/**/*.{js,ts}');

let sql_logger_options: LoggerOptions;
if (environment.SHOW_SQL) {
  sql_logger_options = true;
} else {
  sql_logger_options = false;
}

const dataSourceOptions: DataSourceOptions = {
  database: environment.DATABASE_NAME,
  entities: [entity_path],
  ...(['test', 'dev'].indexOf(environment.NODE_ENV.toLowerCase()) >= 0 && {
    extra: {
      ssl: {
        rejectUnauthorized: false,
      },
    },
  }),
  host: environment.DATABASE_HOSTNAME,
  logging: sql_logger_options,
  migrations: [migration_path],
  migrationsTableName: 'migrations',
  name: 'default',
  password: environment.DATABASE_PASSWORD,
  port: environment.DATABASE_PORT,
  subscribers: [subscriber_path],
  synchronize: false,
  type: 'postgres',
  username: environment.DATABASE_USERNAME,
};

export const appDataSource = new DataSource(dataSourceOptions);
