# msvc-cto-communication-media

Version: 1.0.0.0

 This project contains the source code for an Apollo federated GraphQL microservice. Its purpose is to support CTO's ecosystem of microservices.

## Installation

Node.js v18.17.1 is required to run this project.

**Node** : v18.17.1

 **NPM** : 9.6.7

 **Yarn** : 1.22.19

* Yarn will be used for executing command in package.json such as `yarn test`, `yarn dev`, `yarn build`, it will also be used or the installation of packages `yarn install`.

 **TypeScript** : 5.2.2

 **Jest** : 29.6.4

 **eslint** : 8.48.0

 **Apollo Server** : 4.9.3

 **Apollo Gateway** : 2.5.4

**Pulsar Client**: 1.9.0

**TypeORM:** ^0.3.17

## Fundamental tooling

1. **Language:** TypeScript
2. **Linter:** eslint
3. **Formatter:** Prettier
4. **Testing:** Jest
5. TypeORM: version 0.3.17 [see docs](https://www.npmjs.com/package/typeorm/v/0.2.45)

## .env Config

Create a .env file to the root folder with the following variables and sample.

* **APP_HOST_NAME**: This will be used in the swagger host
* **DATABASE_HOSTNAME**: Database hostname
* **DATABASE_NAME**: Database name
* **DATABASE_PASSWORD**: Databse password
* **DATABASE_PORT**: Datasbe port
* **DATABASE_SSL**: Datasbe SSL, if not using, do not include
* **DATABASE_USERNAME**: Datasbe user name
* **ENCRYPTION_KEY**: Authorization encryption key
* **JWT_ISSUER**: JWT issuer name
* **JWT_SECRET_KEY**: JWT secret key
* **LOG_LEVEL**: Log level
* **NODE_ENV**: Node environment
* **PORT**: Application port
* **REDIS_URL**: Redist url/hostname
* **SHOW_SQL**: Show SQL for debugging purpose
* **SWAGGER_SCHEMES**: swagger schemes
* **SYSTEM_ADMIN_SECRET**: Admin secret, super admin credential key
* **SYSTEM_ID**: Application name

```bash
APP_HOST_NAME=locahost:8080/
DATABASE_HOSTNAME=localhost
DATABASE_NAME=CTO_Authorization
DATABASE_PASSWORD=root
DATABASE_PORT=5432
DATABASE_SSL=
DATABASE_USERNAME=root
ENCRYPTION_KEY=1d7b31a4aa5811ecb9090242ac120002
JWT_ISSUER=CTO
JWT_SECRET_KEY=79da9c36-ab2b-11ec-b909-0242ac120002
LOG_LEVEL=info/error/debug
NODE_ENV=local/staging/production/test
PORT=8080
REDIS_URL=redis://localhost:6379
SHOW_SQL=false
SWAGGER_SCHEMES=http,https
SYSTEM_ADMIN_SECRET=this_is_the_system_admin_secret_internal_use_only
SYSTEM_ID=msvc-cto-communication-media
```

## Usage

To run the microservice locally with nodemon, such as in development:

```bash
yarn install
yarn dev
```

To build the service, and start the service in production mode:

* `yarn build`
* `yarn start`

Please ensure that you have linted and run all tests against your code prior to submitting a merge request.

* `yarn lint`
* `yarn test`

## Docker build

The Dockerfile also requires Nexus credentials. To build the image locally, please ensure that you export environment variables with your Nexus credentials, and then pass them to the build command via a build arg, like so:

### For all platform

* `docker build -t msvc-cto-communication-media:latest . --progress=plain`

### For amd64 platform

* `docker build -t msvc-cto-communication-media:latest . --progress=plain --platform linux/amd64`

### Database Migration [see docs](https://typeorm.io/migrations)

* Generate migration script from existing database `name={migration-filename} yarn migration:generate`
* Create migration script template `name={migration-filename} yarn migration:create`
* Run migration script `yarn migration:run`
* Revert last migrated script `yarn migration:revert`
* Show migrated script `yarn migration:show`

## Docker compose files included in the code base

Make sure to create docker network local bridge by executing `docker network create local_bridge --driver bridge`

* **POSTGRES**: To run execute `docker compose -f docker-compose-postgres.yml up -d`, to stop `docker compose -f docker-compose-postgres.yml down`
* **REDIS**: To run execute `docker compose -f docker-compose-redis.yml up -d`, to stop `docker compose -f docker-compose-redis.yml down`
* **PULSAR**: To run execute `docker compose -f docker-compose-pulsar.yml up -d`, to stop `docker compose -f docker-compose-pulsar.yml down`
* **MSVC-MICROSERVICE**: To run execute `docker compose up -d`, to stop `docker compose down` since the default `docker-compose.yml` contains the microservice config file
