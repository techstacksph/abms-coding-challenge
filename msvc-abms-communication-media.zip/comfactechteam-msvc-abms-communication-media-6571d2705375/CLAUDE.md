# CLAUDE.md - Communication Media Service Guide

## Project Overview

**msvc-abms-communication-media** - Communication media microservice that handles email and SMS sending for the ABMS ecosystem via Apache Pulsar.

**Purpose:** Process communication requests from Pulsar queue and send emails via SMTP/Microsoft 365 and SMS via external APIs.

## Technology Stack

- **Runtime:** Node.js 18+
- **Language:** TypeScript
- **Message Queue:** Apache Pulsar (pulsar-client)
- **Email:** Nodemailer (SMTP) + Microsoft Graph API (M365)
- **DI:** TypeDI (dependency injection)
- **Database:** PostgreSQL (TypeORM for audit logging)

## Key Concepts

### 1. Pulsar Consumer

This service consumes messages from the `COMMUNICATION_MEDIA` Pulsar topic sent by msvc-abms.

### 2. Email Sending

Supports two modes:
- **SMTP**: Using nodemailer with standard SMTP credentials
- **M365**: Using Microsoft Graph API with OAuth or client credentials

### 3. SMS Sending

Integrates with external SMS provider API (Message Media).

## Important Guidelines

### Repository Information

- **Version Control:** Bitbucket (not GitHub)
- **Repository:** bitbucket.org:comfactechteam/msvc-abms-communication-media
- **Default Branch:** development

### Git Commit Messages

**IMPORTANT:** Do NOT include Claude Code attribution in commit messages or pull request descriptions.

❌ **WRONG:**
```
Fix email sending

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

✅ **CORRECT:**
```
Fix email sending with custom display names

- Add support for custom sender display names
- Fix SMTP from field format
```

### Pull Request Guidelines

- **Platform:** Bitbucket (use Bitbucket MCP tools when available)
- **Creating PRs:** Use the git push output link or Bitbucket web UI
- **MCP Tools Available:**
  - `mcp__bitbucket__bb_search` - Search repositories and PRs
  - `mcp__bitbucket__bb_ls_repos` - List repositories
  - `mcp__bitbucket__bb_get_pr` - Get PR details
- **Title:** Use Jira ticket format: `ABMS-XXX: Brief description`
- **Description:** Provide clear summary of changes without AI attribution
- **No Claude attribution:** Do not add any mentions of Claude Code, AI assistance, or co-authorship

## Project Structure

```
src/
├── client/
│   ├── mailer/
│   │   └── MailerClient.ts          # Email sending logic (SMTP + M365)
│   └── sms/
│       └── MessageMediaClient.ts     # SMS sending logic
│
├── services/
│   ├── PulsarConsumerService.ts      # Main Pulsar message processor
│   └── MailerAuditService.ts         # Audit trail for sent emails
│
├── dto/
│   ├── MailerOptionDto.ts            # Email message structure
│   └── MessageMediaDto.ts            # SMS message structure
│
├── utils/
│   └── LoggerUtils.ts                # Logging configuration
│
└── environment.ts                     # Environment configuration
```

## Development

### Running Locally

```bash
# Start with Docker
yarn docker:dev

# Or run directly
yarn dev
```

### Environment Variables

```bash
# Pulsar
PULSAR_SERVICE_URL=pulsar://localhost:6650

# Database (for audit logs)
DATABASE_HOSTNAME=localhost
DATABASE_NAME=communication_media
DATABASE_PORT=5432
DATABASE_USERNAME=root
DATABASE_PASSWORD=root

# Default M365 Fallback
M365_CLIENT_ID=xxx
M365_CLIENT_SECRET=xxx
M365_TENANT_ID=xxx
M365_USER_EMAIL=no-reply@comfactechoptions.com

# SMS Provider
SMS_SERVICE_URL=https://api.messagemedia.com
SMS_SERVICE_AUTH=Bearer xxx
```

## Key Files

### MailerClient.ts

**Purpose:** Sends emails via SMTP or Microsoft 365

**Key Methods:**
- `sendEmail(option: MailerOptionDto)` - Main email sending method
- `sendMailM365(option: MailerOptionDto)` - M365-specific sending
- `refreshAccessToken()` - OAuth token refresh for M365

**SMTP Email Format:**
```typescript
from: `${option.sender} <${option.mailerCredentialOption.username}>`
```

**Important:** The `sender` field contains the display name (e.g., "Company Name", "Custom Display Name", or user's name).

### PulsarConsumerService.ts

**Purpose:** Consumes Pulsar messages and routes to appropriate handler

**Key Methods:**
- `processMessage(message: PulsarMessageDto)` - Main message processor
- `sendEmail(message: PulsarMessageDto)` - Email message handler
- `sendSMS(message: PulsarMessageDto)` - SMS message handler

**Message Structure:**
```typescript
{
  action: 'PROCESS',
  subAction: 'email' | 'sms',
  data: {
    sender: string,              // Display name for emails
    recipients: string[],
    subject: string,
    content: string,
    mailerCredentialOption: {
      smtpType: 'OTHERS' | 'M365',
      username: string,
      password?: string,          // For SMTP
      host?: string,              // For SMTP
      port?: number,              // For SMTP
      m365?: {                    // For M365
        clientId: string,
        clientSecret: string,
        tenantId: string,
        accessToken?: string,
        refreshToken?: string
      }
    }
  }
}
```

## Common Tasks

### Adding Email Logging

```typescript
logger.info('email_sent_successfully', {
  recipient: option.recipients,
  subject: option.subject,
  sender: option.sender
});
```

### Handling M365 Token Expiration

The MailerClient automatically:
1. Detects 403 errors
2. Attempts token refresh using refresh token
3. Retries email sending with new token
4. Logs failure if refresh fails

### Fallback to System Default Email

When using system default email (`no-reply@comfactechoptions.com`), the service automatically:
1. Detects the system email
2. Falls back to M365 environment variables
3. Uses M365 mode regardless of original smtpType

## Best Practices

### 1. Field Naming Consistency
- Backend sends: `sender` field (display name)
- Consumer reads: `sender` field (with fallback to `email_sender` for compatibility)

### 2. Error Handling
```typescript
try {
  await this.mailerClient.sendEmail(option);
} catch (error) {
  logger.error('email_send_failed', {
    error: error instanceof Error ? error.message : 'Unknown error',
    recipient: option.recipients
  });
  throw friendlyError(error, 'send_email');
}
```

### 3. Logging Best Practices
- Use structured logging with context objects
- Include relevant IDs for tracing
- Log at appropriate levels (info, warn, error, debug)

### 4. M365 vs SMTP Decision
- Check `mailerCredentialOption.smtpType`
- `M365` → Use Microsoft Graph API
- `OTHERS` → Use SMTP with nodemailer

## Troubleshooting

### Email Not Showing Display Name

**Check:**
1. Is `sender` field populated in Pulsar message?
2. Is PulsarConsumerService reading correct field?
3. Is MailerClient using correct format: `"${sender} <${username}>"`?

### M365 Authentication Errors

**Common Issues:**
1. Token expired → Automatic refresh should handle this
2. Invalid credentials → Check tenant/client IDs
3. Insufficient permissions → Ensure `Mail.Send` permission

### SMTP Connection Errors

**Common Issues:**
1. Wrong host/port → Verify SMTP settings
2. Authentication failure → Check username/password
3. TLS/SSL issues → Ensure correct port (587 for TLS, 465 for SSL)

## Related Documentation

- **Nodemailer:** https://nodemailer.com/
- **Microsoft Graph:** https://learn.microsoft.com/en-us/graph/api/user-sendmail
- **Apache Pulsar:** https://pulsar.apache.org/docs/

---

**Last Updated:** January 2025
**Status:** ✅ Production Ready
**Maintainer:** CTO Development Team
