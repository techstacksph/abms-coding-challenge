import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

/* eslint-disable no-unused-vars */
export class MessageDto {
  @IsString()
  content!: string;

  @IsString()
  destination_number!: string;

  @IsOptional()
  @IsBoolean()
  delivery_report?: boolean;

  @IsOptional()
  @IsString()
  callback_url?: string;
}

export class CredentialsDto {
  @IsString()
  apiKey!: string;

  @IsString()
  apiSecret!: string;
}

export class MessageMediaDto {
  @IsOptional()
  @ValidateNested()
  @Type(() => CredentialsDto)
  credentials?: CredentialsDto;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MessageDto)
  messages!: MessageDto[];

  @IsOptional()
  @IsString()
  communicationLogId?: string;

  @IsOptional()
  @IsString()
  orgId?: string;

  @IsOptional()
  @IsString()
  smsId?: string;
}

export class MessageMediaResponse {
  callback_url?: string;
  delivery_report?: boolean;
  destination_number!: string;
  message_id!: string;
  metadata?: string;
  status!: string;
  content!: string;
  source_number?: string;
}

export class VendorAccountIdDto {
  @IsString()
  vendor_id!: string;

  @IsString()
  account_id!: string;
}

export class MessageMediaWebhook {
  @ValidateNested()
  @Type(() => VendorAccountIdDto)
  vendor_account_id!: VendorAccountIdDto;

  @IsOptional()
  @IsString()
  callback_url?: string;

  @IsOptional()
  @IsString()
  delivery_report_id?: string;

  @IsOptional()
  @IsString()
  reply_id?: string;

  @IsString()
  source_number!: string;

  @IsString()
  date_received!: string;

  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsNumber()
  delay?: number;

  @IsOptional()
  @IsString()
  submitted_date?: string;

  @IsOptional()
  @IsString()
  original_text?: string;

  @IsOptional()
  @IsString()
  content?: string;

  @IsString()
  message_id!: string;

  @IsOptional()
  @IsString()
  error_code?: string;

  @IsOptional()
  @IsObject()
  meta_data?: object;
}
