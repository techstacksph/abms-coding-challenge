import { PulsarDataAction } from '../enums/DataActionEnum';

export class PulsarMessageDto {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data!: any;
  action!: PulsarDataAction;
  subAction?: string;
  objectName?: string;
}
