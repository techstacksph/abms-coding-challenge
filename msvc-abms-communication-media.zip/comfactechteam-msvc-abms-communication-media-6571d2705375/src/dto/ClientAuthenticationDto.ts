/* eslint-disable @typescript-eslint/no-explicit-any */
export class ClientAuthenticationDto {
  USER_ID!: string | null;
  USER_NAME!: string | null;
  ROLE!: string | null;
  PERMISSION!: any | null;
}
