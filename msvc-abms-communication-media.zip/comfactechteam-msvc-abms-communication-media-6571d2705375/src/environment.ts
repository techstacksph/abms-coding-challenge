/* eslint-disable sort-keys */
import { config as dotenvConfig } from 'dotenv';

dotenvConfig();

export default {
  APP_HOST_NAME:
    process.env.APP_HOST_NAME ?? `localhost:${process.env.PORT ?? 8080}/`,
  DATABASE_HOSTNAME: process.env.DATABASE_HOSTNAME ?? '',
  DATABASE_NAME: process.env.DATABASE_NAME ?? '',
  DATABASE_PASSWORD: process.env.DATABASE_PASSWORD ?? '',
  DATABASE_PORT: Number(process.env.DATABASE_PORT),
  DATABASE_SSL: process.env.DATABASE_SSL ?? '',
  DATABASE_USERNAME: process.env.DATABASE_USERNAME ?? '',
  DEBUG: process.env.DEBUG,

  ENCRYPTION_KEY:
    process.env.ENCRYPTION_KEY ?? '1d7b31a4aa5811ecb9090242ac120002', //  ADDED THIS DEFAULT VALUE SO AS TO NOT FAIL IN THE PIPELINE BUILD
  JWT_ISSUER: process.env.JWT_ISSUER ?? 'CTO',
  JWT_SECRET_KEY:
    process.env.JWT_SECRET_KEY ?? '79da9c36-ab2b-11ec-b909-0242ac120002',
  LOG_LEVEL: process.env.LOG_LEVEL ?? 'info',

  M365_CLIENT_ID: process.env.M365_CLIENT_ID ?? '',
  M365_CLIENT_SECRET: process.env.M365_CLIENT_SECRET ?? '',
  M365_TENANT_ID: process.env.M365_TENANT_ID ?? '',
  M365_USER_EMAIL: process.env.M365_USER_EMAIL ?? '',

  MAILER_HOST: process.env.MAILER_HOST ?? 'smtp.gmail.com',
  MAILER_PASSWORD: process.env.MAILER_PASSWORD ?? '',
  MAILER_PORT: process.env.MAILER_PORT ?? 587,
  MAILER_USERNAME: process.env.MAILER_USERNAME ?? '',
  NODE_ENV: (process.env.NODE_ENV as string) ?? '',
  PORT: process.env.PORT ?? 8080,
  PULSAR_SERVICE_URL:
    process.env.PULSAR_SERVICE_URL || 'pulsar://localhost:6650',
  PULSAR_AUTH_TOKEN: process.env.PULSAR_AUTH_TOKEN ?? '',
  PULSAR_TLS_ENABLED:
    (process.env.PULSAR_TLS_ENABLED ?? '').toLowerCase() === 'true',
  PULSAR_TLS_TRUST_CERT_PATH: process.env.PULSAR_TLS_TRUST_CERT_PATH ?? '',
  PULSAR_TENANT: process.env.PULSAR_TENANT ?? '',
  PULSAR_NAMESPACE: process.env.PULSAR_NAMESPACE ?? '',
  SHOW_SQL: (process.env.SHOW_SQL ?? ('' as string))
    .toLowerCase()
    .includes('true')
    ? true
    : false,
  SWAGGER_SCHEMES: process.env.SWAGGER_SCHEMES ?? 'http,https',
  SYSTEM_ADMIN_SECRET:
    process.env.SYSTEM_ADMIN_SECRET ?? '79da9c36-ab2b-11ec-b909-0242ac120003', //THIS SHOULD ALWAYS BE UUID BECAUSE THIS WILL BE THE VALUE OF CREATED/UPDATED/DELETED BY ID
  SYSTEM_ID: process.env.SYSTEM_ID,
  TENANT_PREFIX: process.env.TENANT_PREFIX ?? 'abms',
  SMS_MESSAGEMEDIA_APIKEY: process.env.SMS_MESSAGEMEDIA_APIKEY,
  SMS_MESSAGEMEDIA_APISECRET: process.env.SMS_MESSAGEMEDIA_APISECRET,
  SMS_MESSAGEMEDIA_ENDPOINT: process.env.SMS_MESSAGEMEDIA_ENDPOINT,
  SMS_MESSAGEMEDIA_CALLBACK_URL:
    process.env.SMS_MESSAGEMEDIA_CALLBACK_URL ??
    'https://ruc3x55jh6.ap-southeast-2.awsapprunner.com',
};
