import {
  BaseEntity,
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';

export abstract class BaseModel extends BaseEntity {
  @PrimaryColumn('uuid', { generated: 'uuid' })
  id!: string;

  @CreateDateColumn()
  createdAt?: Date;

  @UpdateDateColumn()
  updatedAt?: Date;

  @DeleteDateColumn()
  deletedAt?: Date;

  @Column({ nullable: true, type: 'uuid' })
  createdById?: string;

  @Column({ nullable: true, type: 'uuid' })
  updatedById?: string;

  @Column({ nullable: true, type: 'uuid' })
  deletedById?: string;

  @Column({ nullable: true, type: 'text' })
  createdByName?: string;

  @Column({ nullable: true, type: 'text' })
  updatedByName?: string;

  @Column({ nullable: true, type: 'text' })
  deletedByName?: string;
}
