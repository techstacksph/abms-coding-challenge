/* eslint-disable no-unused-vars */
import { Column, Entity } from 'typeorm';

import { MailerClientResult } from '../../dto/MailerOptionDto';
import { BaseModel } from './base/BaseModel';

@Entity('mailerAudits')
export class MailerAuditModel extends BaseModel {
  @Column({ nullable: false })
  messageId!: string;

  @Column({ nullable: false, type: 'simple-json' })
  mailerResponse!: MailerClientResult;
}
