/* eslint-disable no-unused-vars */
import { Column, Entity } from 'typeorm';

import { BaseModel } from './base/BaseModel';

@Entity('smsAudits')
export class SMSAuditModel extends BaseModel {
  @Column({ nullable: false })
  messageId!: string;

  @Column({ nullable: true, type: 'simple-json' })
  vendorAccountId!: string;

  @Column({ nullable: true })
  deliveryReportId?: string;

  @Column({ nullable: true })
  replyId?: string;

  @Column({ nullable: true })
  content?: string;

  @Column({ nullable: true })
  sourceNumber!: string;

  @Column({ nullable: false })
  destinationNumber!: string;

  @Column({ nullable: false })
  status!: string;

  @Column({ nullable: false, type: 'simple-json' })
  statusTrail!: string;

  @Column({ nullable: true })
  errorCode?: string;

  @Column({ nullable: false })
  callbackUrl!: string;

  @Column({ default: 0, nullable: false })
  delay!: number;

  @Column({ nullable: true })
  submittedDate?: string;

  @Column({ nullable: true })
  metaData?: string;

  @Column({ default: false, nullable: false })
  isDeliveryReport!: boolean;

  @Column({ nullable: true, type: 'uuid' })
  communicationLogId?: string;
}
