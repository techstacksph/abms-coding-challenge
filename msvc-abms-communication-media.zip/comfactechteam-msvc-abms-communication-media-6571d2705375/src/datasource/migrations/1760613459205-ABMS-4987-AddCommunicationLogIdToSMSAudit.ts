import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS4987AddCommunicationLogIdToSMSAudit1760613459205
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Add communicationLogId column to smsAudits table
    // This links SMS audit records back to the originating CommunicationLog
    // Enables reply tracking and Activities tab integration
    await queryRunner.query(`
            ALTER TABLE "smsAudits"
            ADD COLUMN "communicationLogId" uuid
        `);

    // Create index for faster lookups when querying by communicationLogId
    await queryRunner.query(`
            CREATE INDEX "IDX_smsAudits_communicationLogId"
            ON "smsAudits" ("communicationLogId")
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Remove index first
    await queryRunner.query(`
            DROP INDEX "IDX_smsAudits_communicationLogId"
        `);

    // Remove communicationLogId column
    await queryRunner.query(`
            ALTER TABLE "smsAudits"
            DROP COLUMN "communicationLogId"
        `);
  }
}
