/* eslint-disable sort-keys */
import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class CreateSMSAuditTable1743485871404 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'smsAudits',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'uuid',
            default: 'gen_random_uuid()',
          },
          {
            name: 'createdAt',
            type: 'timestamp',
            default: 'CURRENT_TIMESTAMP',
            isNullable: true,
          },
          {
            name: 'updatedAt',
            type: 'timestamp',
            default: 'CURRENT_TIMESTAMP',
            onUpdate: 'CURRENT_TIMESTAMP',
            isNullable: true,
          },
          {
            name: 'deletedAt',
            type: 'timestamp',
            isNullable: true,
          },
          {
            name: 'createdById',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'updatedById',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'deletedById',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'createdByName',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'updatedByName',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'deletedByName',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'messageId',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'vendorAccountId',
            type: 'jsonb',
            isNullable: true,
          },
          {
            name: 'deliveryReportId',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'replyId',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'content',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'sourceNumber',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'destinationNumber',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'status',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'statusTrail',
            type: 'jsonb',
            isNullable: false,
          },
          {
            name: 'errorCode',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'callbackUrl',
            type: 'varchar',
            isNullable: false,
          },
          {
            name: 'delay',
            type: 'integer',
            isNullable: true,
            default: 0,
          },
          {
            name: 'submittedDate',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'metaData',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'isDeliveryReport',
            type: 'boolean',
            isNullable: false,
            default: false,
          },
        ],
      })
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('smsAudits');
  }
}
