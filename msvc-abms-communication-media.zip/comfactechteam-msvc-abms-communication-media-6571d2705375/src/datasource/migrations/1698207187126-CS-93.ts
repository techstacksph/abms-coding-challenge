import { MigrationInterface, QueryRunner } from 'typeorm';

export class CS931698207187126 implements MigrationInterface {
  name = 'CS931698207187126';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "mailerAudits" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "messageId" character varying NOT NULL, "mailerResponse" text NOT NULL, CONSTRAINT "PK_9c4a3b115332e957bea786f72c0" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "mailerAudits"`);
  }
}
