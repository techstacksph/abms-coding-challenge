/* eslint-disable jest/no-focused-tests */

/* eslint-disable jest/no-disabled-tests */
import { DeepPartial } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';

import { MessageMediaClient } from '../../../client/sms/MessageMediaClient';
import { appDataSource } from '../../../datasource/config/database';
import { MailerAuditModel } from '../../../datasource/models/MailerAuditModel';
import {
  MessageMediaDto,
  MessageMediaResponse,
} from '../../../dto/MessageMediaDto';
import { RecordCUDDto } from '../../../dto/RecordAuditDto';
import environment from '../../../environment';
import { SmsAuditService } from '../../../services/SmsAuditService';

describe('MESSAGE MEDIA CLIENT', () => {
  let messageMediaClient: MessageMediaClient;

  const APIKEY = environment.SMS_MESSAGEMEDIA_APIKEY;
  const APISECRET = environment.SMS_MESSAGEMEDIA_APISECRET;

  beforeAll(async () => {
    if (!appDataSource.isInitialized) {
      await appDataSource.initialize();
    }

    jest.mock('../../../services/MailerAuditService');
    SmsAuditService.prototype.save = jest.fn(
      async (
        entity: DeepPartial<MailerAuditModel>,
        userDto: RecordCUDDto
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ): Promise<any> => {
        return { entity, userDto };
      }
    );

    if (environment.NODE_ENV === 'test') {
      jest.mock('../../../client/sms/MessageMediaClient');

      MessageMediaClient.prototype.sendSMS = jest.fn(
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        async (option: MessageMediaDto): Promise<MessageMediaResponse> => {
          const response = {} as MessageMediaResponse;
          return Promise.resolve(response);
        }
      );
    }

    messageMediaClient = Container.get(MessageMediaClient);
  });

  afterAll(async () => {
    await appDataSource.destroy();
  });

  test('DEFAULT CREDENTIALS', async () => {
    const option: MessageMediaDto = {
      messages: [
        {
          callback_url: 'http://sample-callback-url',
          content: 'Jest unit testing message',
          delivery_report: true,
          destination_number: '+63123456789',
        },
      ],
    };

    const response = await messageMediaClient.sendSMS(option);
    expect.objectContaining<MessageMediaResponse>(response);
  });

  test('SEND SMS', async () => {
    const option: MessageMediaDto = {
      credentials: {
        apiKey: APIKEY!,
        apiSecret: APISECRET!,
      },
      messages: [
        {
          callback_url: 'http://sample-callback-url',
          content: 'Jest unit testing message',
          delivery_report: true,
          destination_number: '+63123456789',
        },
      ],
    };
    const response = (await messageMediaClient.sendSMS(
      option
    )) as MessageMediaResponse;
    expect.objectContaining<MessageMediaResponse>(response);
  });
});
