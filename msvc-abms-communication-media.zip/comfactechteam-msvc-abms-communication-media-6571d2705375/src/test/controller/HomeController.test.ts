import { Application } from 'express';
import request from 'supertest';
import { Container } from 'typeorm-typedi-extensions';

import environment from '../../environment';
import { logger } from '../../utils/LoggerUtils';
import { AppServerUtils } from '../../utils/TestUtils';

describe('HOME CONTROLLER TEST', () => {
  let server: Application;
  let appServer: AppServerUtils;

  beforeAll(async () => {
    appServer = Container.get(AppServerUtils);
    server = await appServer.startServer();
  });

  afterAll(async () => {
    //
  });

  test('HOME TEST', async () => {
    const resp = await request(server)
      .get('/v1/home/status')
      .set({ Authorization: environment.SYSTEM_ADMIN_SECRET });

    // CHANGE TO DEBUG
    logger.debug('home_controller_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);
  });
});
