/* eslint-disable no-unused-vars */
export enum PulsarTopics {
  MICROSERVICE_APP_ID = 'COMMUNICATION_MEDIA', //  CHANGE TO THIS APPLICATION MICROSERVICE ID WHERE THIS APPLICATION WILL LISTEN TO
  BACK_OFFICE = 'AYR_BACK_OFFICE', // For sending status updates back to msvc-abms
}
