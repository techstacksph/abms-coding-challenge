/* eslint-disable no-unused-vars */
export enum ModelName {
  MAILER_AUDIT = 'MailerAuditModel',
  SMS_AUDIT = 'SMSAuditModel',
}
