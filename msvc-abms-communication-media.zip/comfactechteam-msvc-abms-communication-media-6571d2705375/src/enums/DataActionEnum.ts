/* eslint-disable no-unused-vars */
export enum DataActionEnum {
  CREATED = 'CREATED',
  UPDATED = 'UPDATED',
  DELETED = 'DELETED',
}

export enum PulsarDataAction {
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  PROCESS = 'PROCESS',
  UPDATE_COMMUNICATION_STATUS = 'UPDATE_COMMUNICATION_STATUS',
}
