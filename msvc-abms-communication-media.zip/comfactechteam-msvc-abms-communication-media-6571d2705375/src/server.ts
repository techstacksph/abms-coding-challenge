/* eslint-disable @typescript-eslint/no-unused-vars */
import 'reflect-metadata';

import cookieParser from 'cookie-parser';
import express from 'express';
import { Action, createExpressServer, useContainer } from 'routing-controllers';
import swaggerUi from 'swagger-ui-express';
import { Container } from 'typeorm-typedi-extensions';

import { PulsarListenerRegistry } from './client/pulsar/PulsarListenerRegistry';
import { ControllerInitializer } from './controller/ControllerInitializer';
import { appDataSource } from './datasource/config/database';
import { ClientAuthenticationDto } from './dto/ClientAuthenticationDto';
import environment from './environment';
import { CustomUnauthorizedError } from './errors/CustomUnauthorizedError';
import { AuthenticateRequestService } from './services/AuthenticateRequestService';
import { httpLogger, logger } from './utils/LoggerUtils';
import swaggerSpec from './utils/SwaggerUtils';

const startServer = async () => {
  const PORT = environment.PORT;

  useContainer(Container);

  const controllerInitializer: ControllerInitializer = Container.get(
    ControllerInitializer
  );

  const authenticateRequestService: AuthenticateRequestService = Container.get(
    AuthenticateRequestService
  );

  const app = createExpressServer({
    authorizationChecker: async (action: Action): Promise<boolean> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );

      if (!authenticate.valid) {
        throw new CustomUnauthorizedError('invalid_authorization');
      }
      return Promise.resolve(authenticate.valid);
    },
    classTransformer: true,
    controllers: controllerInitializer.controllers(),
    cors: true,
    currentUserChecker: async (
      action: Action
    ): Promise<ClientAuthenticationDto> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );

      if (authenticate.valid) {
        return {
          PERMISSION: {},
          ROLE: 'system_admin',
          USER_ID: authenticate.userId as string,
          USER_NAME: 'system_admin',
        };
      } else {
        return {
          PERMISSION: null,
          ROLE: null,
          USER_ID: null,
          USER_NAME: null,
        };
      }
    },
    defaultErrorHandler: false,
    validation: false,
  });

  app.use(httpLogger);
  app.use(cookieParser());
  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  app.use(
    '/v1/api-doc',
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec, {
      swaggerOptions: { defaultModelsExpandDepth: -1 },
    })
  );

  await new Promise<void>((resolve) => app.listen({ port: PORT }, resolve));
  logger.info('Environment config: ', {
    ...environment,
  });
  logger.info(`Visit API Docs http://localhost:${PORT}/v1/api-doc `);
  logger.info(`Server running at http://localhost:${PORT} `);
  return app;
};

appDataSource.initialize().then(async (connetion) => {
  logger.info(`Database connection is connected:`, {
    isInitialized: connetion.isInitialized,
  });
  if (!['test', 'local'].includes(environment.NODE_ENV.toLocaleLowerCase())) {
    //RUN PROCESS THAT NEEDED IN SERVER HERE
  }
  await startServer();

  const pulsarListenerRegistry = Container.get(PulsarListenerRegistry);
  pulsarListenerRegistry.startListen();
});
