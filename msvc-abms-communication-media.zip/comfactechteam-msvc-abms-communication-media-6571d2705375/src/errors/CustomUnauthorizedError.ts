import { UnauthorizedError } from 'routing-controllers';

export class CustomUnauthorizedError extends UnauthorizedError {
  constructor(msg: string) {
    super(msg);
    Object.setPrototypeOf(this, CustomUnauthorizedError.prototype);
    // Remove the problematic stack assignment
    Object.defineProperty(this, 'stack', {
      configurable: true,
      value: undefined,
      writable: true,
    });
  }
}
