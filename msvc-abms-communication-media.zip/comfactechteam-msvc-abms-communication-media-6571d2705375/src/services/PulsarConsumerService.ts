import 'reflect-metadata';

import Container, { Service } from 'typedi';

import { MailerClient } from '../client/mailer/MailerClient';
import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { MessageMediaClient } from '../client/sms/MessageMediaClient';
import { MailerOptionDto } from '../dto/MailerOptionDto';
import { MessageMediaDto, MessageMediaResponse } from '../dto/MessageMediaDto';
import { PulsarMessageDto } from '../dto/PulsarMessageDto';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import { logger } from '../utils/LoggerUtils';

@Service()
export class PulsarConsumerService {
  constructor(
    private readonly mailerClient: MailerClient,
    private readonly messageMediaClient: MessageMediaClient
  ) {}

  async processMessage(
    message: PulsarMessageDto
  ): Promise<NonNullable<unknown>> {
    logger.info('pulsar_processor', { message });

    switch (message.action) {
      case PulsarDataAction.PROCESS:
        switch (message.subAction) {
          case 'email':
            return Promise.resolve(await this.sendEmail(message));
          case 'sms':
            return Promise.resolve(await this.sendSMS(message));
          default:
            break;
        }
        break;
      default:
        break;
    }

    return Promise.resolve(false);
  }

  async sendEmail(message: PulsarMessageDto): Promise<boolean> {
    let result = false;
    logger.info('pulsar_email_data', { data: message.data });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let mailerCredentialOption: any | undefined = undefined;
    if (message.data.mailerCredentialOption) {
      mailerCredentialOption = message.data.mailerCredentialOption;
    }

    const option: MailerOptionDto = {
      attachments: message.data.attachments,
      bccRecipients: message.data.bccRecipients,
      ccRecipients: message.data.ccRecipients,
      content: message.data.content,
      mailerCredentialOption: mailerCredentialOption,
      metadata: message.data.metadata,
      recipients: message.data.recipients,
      replyTo: message.data.replyTo,
      sender: message.data.sender ?? message.data.email_sender,
      subject: message.data.subject,
    };

    try {
      await this.mailerClient.sendEmail(option);
      result = true;

      // Send success status update back to msvc-abms via Pulsar
      if (option.metadata?.communicationLogId) {
        await this.sendStatusUpdate({
          communicationLogId: option.metadata.communicationLogId,
          orgId: option.metadata.orgId,
          status: 'delivered',
          timestamp: new Date().toISOString(),
        });
      }
    } catch (error) {
      logger.error('email_send_failed', {
        communicationLogId: option.metadata?.communicationLogId,
        error: error instanceof Error ? error.message : 'Unknown error',
        recipients: option.recipients,
        subject: option.subject,
      });

      // Send failure status update back to msvc-abms via Pulsar
      if (option.metadata?.communicationLogId) {
        await this.sendStatusUpdate({
          communicationLogId: option.metadata.communicationLogId,
          error: error instanceof Error ? error.message : 'Unknown error',
          orgId: option.metadata.orgId,
          status: 'failed',
          timestamp: new Date().toISOString(),
        });
      }

      result = false;
    }

    return Promise.resolve(result);
  }

  private async sendStatusUpdate(data: {
    communicationLogId: string;
    orgId?: string;
    status: string;
    error?: string;
    timestamp: string;
  }): Promise<void> {
    try {
      const pulsarProducerClient = Container.get(PulsarProducerClient);
      await pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
        action: PulsarDataAction.UPDATE_COMMUNICATION_STATUS,
        data,
      });

      logger.info('communication_status_update_sent', {
        communicationLogId: data.communicationLogId,
        status: data.status,
      });
    } catch (error) {
      logger.error('failed_to_send_status_update', {
        communicationLogId: data.communicationLogId,
        error: error instanceof Error ? error.message : 'Unknown error',
        status: data.status,
      });
    }
  }

  async sendSMS(
    message: PulsarMessageDto
  ): Promise<MessageMediaResponse | boolean> {
    logger.info('pulsar_sms_data', { data: message.data });
    const option = message.data as MessageMediaDto & {
      metadata?: {
        communicationLogId?: string;
        orgId?: string;
        smsId?: string;
      };
    };

    try {
      const result = await this.messageMediaClient.sendSMS(option);

      // Send success status update back to msvc-abms via Pulsar (matching email pattern)
      if (option.metadata?.communicationLogId) {
        await this.sendStatusUpdate({
          communicationLogId: option.metadata.communicationLogId,
          orgId: option.metadata.orgId,
          status: 'delivered',
          timestamp: new Date().toISOString(),
        });
      }

      return Promise.resolve(result);
    } catch (error) {
      logger.error('sms_send_failed', {
        communicationLogId: option.metadata?.communicationLogId,
        destinationNumber: option.messages?.[0]?.destination_number,
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      // Send failure status update back to msvc-abms via Pulsar (matching email pattern)
      if (option.metadata?.communicationLogId) {
        await this.sendStatusUpdate({
          communicationLogId: option.metadata.communicationLogId,
          error: error instanceof Error ? error.message : 'Unknown error',
          orgId: option.metadata.orgId,
          status: 'failed',
          timestamp: new Date().toISOString(),
        });
      }

      return Promise.resolve(false);
    }
  }
}
