import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { MailerAuditModel } from '../datasource/models/MailerAuditModel';
import { ModelName } from '../enums/ModelObjectEnums';
import { BaseService } from './BaseService';

@Service()
export class MailerAuditService extends BaseService<MailerAuditModel, string> {
  constructor() {
    const organizationRepository =
      appDataSource.getRepository(MailerAuditModel);

    super(organizationRepository, ModelName.MAILER_AUDIT);
  }
}
