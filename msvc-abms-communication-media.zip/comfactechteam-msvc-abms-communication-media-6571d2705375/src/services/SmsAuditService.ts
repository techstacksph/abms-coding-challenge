import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { SMSAuditModel } from '../datasource/models/SMSAuditModel';
import { ModelName } from '../enums/ModelObjectEnums';
import { BaseService } from './BaseService';

@Service()
export class SmsAuditService extends BaseService<SMSAuditModel, string> {
  constructor() {
    const organizationRepository = appDataSource.getRepository(SMSAuditModel);

    super(organizationRepository, ModelName.SMS_AUDIT);
  }

  async findByMessageId(
    id: string,
    conditional?: object
  ): Promise<SMSAuditModel[]> {
    const results = this.find({
      where: { messageId: id, ...conditional },
    });

    return Promise.resolve(results);
  }
}
