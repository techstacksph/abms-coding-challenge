import 'reflect-metadata';

import { Request } from 'express';
import { Service } from 'typedi';

import environment from '../environment';
import { logger } from '../utils/LoggerUtils';

@Service()
export class AuthenticateRequestService {
  async authenticate(
    req: Request
  ): Promise<{ valid: boolean; userId: string | null }> {
    const token = req.headers.authorization;

    logger.debug('authenticate_request_token', { token });

    if (token && token == environment.SYSTEM_ADMIN_SECRET) {
      return Promise.resolve({
        userId: environment.SYSTEM_ADMIN_SECRET,
        valid: true,
      });
    } else {
      return Promise.resolve({
        userId: null,
        valid: false,
      });
    }
  }
}
