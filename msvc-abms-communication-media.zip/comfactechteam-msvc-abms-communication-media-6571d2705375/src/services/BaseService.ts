import {
  DeepPartial,
  FindManyOptions,
  FindOneOptions,
  FindOptionsWhere,
  In,
  ObjectLiteral,
  Repository,
} from 'typeorm';

import { PageArg, PaginatedData } from '../dto/PaginationDto';
import { RecordCUDDto } from '../dto/RecordAuditDto';
import { logger } from '../utils/LoggerUtils';
import { computePageCount } from '../utils/PaginationUtils';

export abstract class BaseService<T extends ObjectLiteral, ID extends string> {
  private readonly MAX_PAGE_SIZE = 50;
  private repository!: Repository<T>;
  private modelName: string;

  constructor(repository: Repository<T>, modelName: string) {
    this.repository = repository;
    this.modelName = modelName;
  }

  getModelName(): string {
    return this.modelName;
  }

  async save(entity: DeepPartial<T>, userDto: RecordCUDDto) {
    Object.assign(entity, {
      createdById: userDto.userId,
      createdByName: userDto.userName,
    });
    return Promise.resolve(await this.repository.save(entity));
  }

  async findById(id: ID): Promise<T | null> {
    return Promise.resolve(
      await this.repository.findOne({ where: { id: id } } as FindOneOptions)
    );
  }

  async findOne(options: FindOneOptions<T>): Promise<T | null> {
    return Promise.resolve(this.repository.findOne(options));
  }

  async findByIds(ids: ID[]): Promise<T[]> {
    const results = this.repository.findBy({
      id: In(ids),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as FindOptionsWhere<any>);
    return Promise.resolve(results);
  }

  async update(id: ID, entity: T, userDto: RecordCUDDto): Promise<T | null> {
    Object.assign(entity, {
      updatedById: userDto.userId,
      updatedByName: userDto.userName,
    });

    logger.debug('update_data', { entity });

    const result = await this.repository.update(id, entity);
    if ((result.affected as number) > 0) {
      return Promise.resolve(await this.findById(id));
    } else {
      return Promise.resolve(null);
    }
  }

  async softRemove(id: ID, userDto: RecordCUDDto): Promise<boolean> {
    const data = await this.findById(id);
    if (data) {
      Object.assign(data as T, {
        deletedById: userDto.userId,
        deletedByName: userDto.userName,
      });
      await this.update(id, data, userDto);
      await this.repository.softRemove(data);
      return Promise.resolve(true);
    } else {
      return Promise.resolve(false);
    }
  }

  async all(options?: FindManyOptions<T>): Promise<Array<T>> {
    if (options) {
      return this.find(options);
    }
    return Promise.resolve(await this.repository.find());
  }

  async find(options?: FindManyOptions<T>): Promise<Array<T>> {
    if (!options) {
      options = { take: this.MAX_PAGE_SIZE };
    }
    options.take = this.MAX_PAGE_SIZE;
    return Promise.resolve(await this.repository.find(options));
  }

  async findAndCount(
    pageArg: PageArg,
    options?: FindManyOptions<T>
  ): Promise<PaginatedData<T>> {
    const take: number =
      pageArg.take > this.MAX_PAGE_SIZE ? this.MAX_PAGE_SIZE : pageArg.take;

    const sorting = {};
    if (pageArg.sort) {
      for (const sort_info of pageArg.sort) {
        Object.assign(sorting, {
          [sort_info.field]: sort_info.direction,
        });
      }
    }

    const result = await this.repository.findAndCount({
      ...options,
      order: sorting,
      skip: pageArg.skip,
      take,
    });

    const paginated_result: PaginatedData<T> = {
      data: result[0],
      pageInfo: {
        count: result[1],
        pageCount: computePageCount(result[1], take),
        pageSize: take,
        skip: pageArg.skip,
        take,
      },
      sort: pageArg.sort ?? [],
    };

    return Promise.resolve(paginated_result);
  }
}
