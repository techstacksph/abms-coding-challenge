import { ValidationError } from 'class-validator';

export function errorValidationResponse(errors: ValidationError[]) {
  const messages = flattenValidationErrors(errors);
  /* eslint-disable sort-keys */
  return {
    statusCode: 400,
    error: 'Bad Request',
    message: messages,
  };
}

function flattenValidationErrors(
  errors: ValidationError[],
  parentPath = ''
): string[] {
  const result: string[] = [];

  for (const error of errors) {
    const path = parentPath
      ? `${parentPath}.${error.property}`
      : error.property;

    if (error.constraints) {
      result.push(
        ...Object.values(error.constraints).map((msg) => `${path}: ${msg}`)
      );
    }

    if (error.children && error.children.length > 0) {
      result.push(...flattenValidationErrors(error.children, path));
    }
  }

  return result;
}
