import swaggerJSDoc from 'swagger-jsdoc';

import environment from '../environment';

const options: swaggerJSDoc.Options = {
  apis: ['./swagger-doc/**/*.yaml'],
  definition: {
    host: `${environment.APP_HOST_NAME}`,
    info: {
      description: 'CTO Communication Media',
      title: 'Communication Media',
      version: '1.0.0',
    },
    schemes: environment.SWAGGER_SCHEMES.split(','),
  },
};

export default swaggerJSDoc(options);
