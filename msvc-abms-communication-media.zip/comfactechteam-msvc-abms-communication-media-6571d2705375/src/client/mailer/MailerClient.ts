import axios from 'axios';
import nodemailer from 'nodemailer';
import { Service } from 'typedi';

import { ClientSecretCredential } from '@azure/identity';
import { Client as m365Client } from '@microsoft/microsoft-graph-client';
import { TokenCredentialAuthenticationProvider } from '@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials';

import {
  MailerClientResult,
  MailerOptionDto,
  smtpType,
} from '../../dto/MailerOptionDto';
import environment from '../../environment';
import { MailerAuditService } from '../../services/MailerAuditService';
import { friendlyError } from '../../utils/ExceptionUtils';
import { logger } from '../../utils/LoggerUtils';

@Service()
export class MailerClient {
  constructor(private readonly mailerAuditService: MailerAuditService) {}

  /**
   * Build mail object for Microsoft Graph API
   */
  private buildMailObject(option: MailerOptionDto) {
    const recipients: { emailAddress: { address: string } }[] = [];
    const replyTo: { emailAddress: { address: string } }[] = [
      { emailAddress: { address: option.replyTo } },
    ];

    for (const reciver of option.recipients) {
      if (reciver && reciver.length > 0) {
        recipients.push({
          emailAddress: {
            address: reciver,
          },
        });
      }
    }

    // Build CC recipients array
    const ccRecipients: { emailAddress: { address: string } }[] = [];
    if (option.ccRecipients) {
      for (const ccRecipient of option.ccRecipients) {
        if (ccRecipient && ccRecipient.length > 0) {
          ccRecipients.push({
            emailAddress: {
              address: ccRecipient,
            },
          });
        }
      }
    }

    // Build BCC recipients array
    const bccRecipients: { emailAddress: { address: string } }[] = [];
    if (option.bccRecipients) {
      for (const bccRecipient of option.bccRecipients) {
        if (bccRecipient && bccRecipient.length > 0) {
          bccRecipients.push({
            emailAddress: {
              address: bccRecipient,
            },
          });
        }
      }
    }

    const attachments: {
      '@odata.type': string;
      contentBytes: string;
      contentId: string;
      contentType?: string;
      name: string;
    }[] = [];

    if (option.attachments) {
      for (const attachment of option.attachments) {
        attachments.push({
          '@odata.type': '#microsoft.graph.fileAttachment',
          contentBytes: attachment.content || attachment.path,
          contentId: attachment.cid,
          contentType: attachment.contentType,
          name: attachment.filename || attachment.cid,
        });
      }
    }

    const mailObject: {
      attachments: typeof attachments;
      body: { content: string; contentType: string };
      from: { emailAddress: { address: string; name: string } };
      replyTo: typeof replyTo;
      subject: string;
      toRecipients: typeof recipients;
      ccRecipients?: typeof ccRecipients;
      bccRecipients?: typeof bccRecipients;
    } = {
      attachments: attachments,
      body: {
        content: option.content,
        contentType: 'html',
      },
      from: {
        emailAddress: {
          address: option.mailerCredentialOption!.username,
          name: option.sender, // Display name (e.g., "Batman", "Company Name")
        },
      },
      replyTo: replyTo,
      subject: option.subject,
      toRecipients: recipients,
    };

    // Only include CC/BCC if they have recipients
    if (ccRecipients.length > 0) {
      mailObject.ccRecipients = ccRecipients;
    }
    if (bccRecipients.length > 0) {
      mailObject.bccRecipients = bccRecipients;
    }

    return mailObject;
  }

  /**
   * Diagnose Microsoft authentication errors and provide actionable insights
   */
  private diagnoseMicrosoftAuthError(error: any): string[] {
    const causes: string[] = [];
    const errorMessage = error?.message?.toLowerCase() || '';
    const errorCode = error?.code?.toLowerCase() || '';
    const statusCode = error?.statusCode;

    // Access Denied errors
    if (
      errorMessage.includes('access is denied') ||
      errorMessage.includes('access denied') ||
      statusCode === 401 ||
      statusCode === 403
    ) {
      causes.push(
        '❌ INVALID CLIENT_SECRET: The client secret is incorrect, expired, or does not match the app registration'
      );
      causes.push(
        '❌ INVALID CLIENT_ID: The client ID does not exist in the specified tenant'
      );
      causes.push(
        '❌ INVALID TENANT_ID: The tenant ID is incorrect or the app is not registered in this tenant'
      );
      causes.push(
        '❌ MISSING API PERMISSIONS: The app registration lacks "Mail.Send" permission in Microsoft Graph'
      );
      causes.push(
        '❌ PERMISSION NOT CONSENTED: Admin consent has not been granted for the Mail.Send permission'
      );
    }

    // User/Mailbox not found
    if (
      errorMessage.includes('mailbox not found') ||
      errorMessage.includes('user not found') ||
      errorMessage.includes('does not exist') ||
      statusCode === 404
    ) {
      causes.push(
        '❌ INVALID USERNAME: The email account does not exist in this Microsoft 365 tenant'
      );
      causes.push(
        '❌ USER NOT LICENSED: The user account exists but does not have an Exchange Online mailbox'
      );
    }

    // Invalid request
    if (
      errorMessage.includes('invalid_request') ||
      errorMessage.includes('invalid_client')
    ) {
      causes.push(
        '❌ MALFORMED CREDENTIALS: One or more credential values contain invalid characters or formatting'
      );
      causes.push(
        '❌ APP REGISTRATION MISCONFIGURED: The Azure AD app registration is not set up correctly'
      );
    }

    // Token/Authentication errors
    if (
      errorMessage.includes('token') ||
      errorCode.includes('unauthorized') ||
      errorCode.includes('unauthenticated')
    ) {
      causes.push(
        '❌ CLIENT_SECRET EXPIRED: The client secret has expired and needs to be regenerated in Azure Portal'
      );
      causes.push(
        '❌ APP DISABLED: The Azure AD app registration has been disabled or deleted'
      );
    }

    // Network/Connection errors
    if (
      errorMessage.includes('network') ||
      errorMessage.includes('timeout') ||
      errorMessage.includes('econnrefused')
    ) {
      causes.push(
        '⚠️ NETWORK ISSUE: Unable to reach Microsoft Graph API (check firewall/proxy settings)'
      );
    }

    // If no specific causes identified, provide general guidance
    if (causes.length === 0) {
      causes.push(
        '⚠️ UNKNOWN ERROR: Check Azure Portal app registration settings'
      );
      causes.push(
        '💡 Verify: 1) Client credentials are correct, 2) Mail.Send permission granted, 3) User exists in tenant'
      );
    }

    // Always add troubleshooting steps
    causes.push(
      '\n🔧 TROUBLESHOOTING STEPS:\n' +
        '  1. Go to Azure Portal → App Registrations → Your App\n' +
        '  2. Verify Client ID matches (Overview page)\n' +
        '  3. Check Tenant ID matches (Overview page)\n' +
        '  4. Generate new Client Secret (Certificates & secrets page) if expired\n' +
        '  5. Verify API Permissions → Microsoft Graph → Mail.Send (Application) is present\n' +
        '  6. Click "Grant admin consent" if permission shows "Not granted"\n' +
        '  7. Verify the email account exists in Microsoft 365 admin center'
    );

    return causes;
  }

  /**
   * Refresh Microsoft OAuth access token using refresh token
   */
  private async refreshAccessToken(
    tenantId: string,
    clientId: string,
    clientSecret: string,
    refreshToken: string
  ): Promise<{ accessToken: string; refreshToken: string } | null> {
    try {
      logger.info('Attempting to refresh Microsoft OAuth access token');

      const tokenEndpoint = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;

      const response = await axios.post(
        tokenEndpoint,
        new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
          scope: 'https://graph.microsoft.com/.default offline_access',
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      logger.info('Successfully refreshed Microsoft OAuth access token');

      return {
        accessToken: response.data.access_token,
        refreshToken: response.data.refresh_token || refreshToken, // Use new refresh token if provided
      };
    } catch (error) {
      logger.error('Failed to refresh Microsoft OAuth access token', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      return null;
    }
  }

  async sendEmail(option: MailerOptionDto): Promise<boolean> {
    logger.info('mailer_client_option', { option });

    // Log detailed credential info for debugging
    logger.info('mailer_credential_debug', {
      hasCredentialOption: !!option.mailerCredentialOption,
      isNull: option.mailerCredentialOption === null,
      isUndefined: option.mailerCredentialOption === undefined,
      credentialType: typeof option.mailerCredentialOption,
      credentialKeys: option.mailerCredentialOption
        ? Object.keys(option.mailerCredentialOption)
        : [],
      smtpType: option.mailerCredentialOption?.smtpType,
      username: option.mailerCredentialOption?.username,
      hasM365: !!option.mailerCredentialOption?.m365,
      m365Keys: option.mailerCredentialOption?.m365
        ? Object.keys(option.mailerCredentialOption.m365)
        : [],
      hasTenantId: !!option.mailerCredentialOption?.m365?.tenantId,
      hasClientId: !!option.mailerCredentialOption?.m365?.clientId,
      hasClientSecret: !!option.mailerCredentialOption?.m365?.clientSecret,
      tenantIdValue: option.mailerCredentialOption?.m365?.tenantId,
      clientIdValue: option.mailerCredentialOption?.m365?.clientId,
    });

    // Check if mailerCredentialOption is null, undefined, empty object, or missing smtpType
    const hasNoCredentials =
      !option.mailerCredentialOption ||
      option.mailerCredentialOption === null ||
      option.mailerCredentialOption === undefined ||
      (typeof option.mailerCredentialOption === 'object' &&
        option.mailerCredentialOption !== null &&
        Object.keys(option.mailerCredentialOption).length === 0) ||
      (option.mailerCredentialOption && !option.mailerCredentialOption.smtpType);

    // Check if using system default email (no-reply@comfactechoptions.com)
    const isUsingSystemDefaultEmail =
      option.mailerCredentialOption?.username ===
      'no-reply@comfactechoptions.com';

    // Only check M365 credentials if smtpType is M365
    const isM365Mode =
      option.mailerCredentialOption?.smtpType === smtpType.M365;

    // Check if M365 credentials are missing or contain placeholder values (only for M365 mode)
    const hasInvalidM365Credentials =
      isM365Mode &&
      (!option.mailerCredentialOption ||
        !option.mailerCredentialOption.m365 ||
        option.mailerCredentialOption.m365?.tenantId === 'Tenant ID' ||
        option.mailerCredentialOption.m365?.clientId === 'Client ID' ||
        option.mailerCredentialOption.m365?.clientSecret === 'Client secret' ||
        !option.mailerCredentialOption.m365?.tenantId ||
        !option.mailerCredentialOption.m365?.clientId ||
        !option.mailerCredentialOption.m365?.clientSecret);

    // Fallback to environment variables if:
    // 1. No credentials provided (null/undefined) OR
    // 2. M365 mode with invalid credentials OR
    // 3. Using system default email (no-reply@comfactechoptions.com)
    if (
      hasNoCredentials ||
      hasInvalidM365Credentials ||
      isUsingSystemDefaultEmail
    ) {
      logger.info(
        hasNoCredentials
          ? 'No mailerCredentialOption provided, falling back to environment variables'
          : isUsingSystemDefaultEmail
            ? 'Using system default email (no-reply@comfactechoptions.com), falling back to environment variables'
            : 'Invalid M365 credentials, falling back to environment variables'
      );

      const mailerCredentialOption = {
        m365: {
          clientId: environment.M365_CLIENT_ID,
          clientSecret: environment.M365_CLIENT_SECRET,
          tenantId: environment.M365_TENANT_ID,
        },
        smtpType: smtpType.M365,
        username: environment.M365_USER_EMAIL,
      };
      Object.assign(option, { mailerCredentialOption: mailerCredentialOption });
      return this.sendMailM365(option);
    }

    if (option.mailerCredentialOption?.smtpType == smtpType.M365) {
      return this.sendMailM365(option);
    }

    logger.info('mailer_credential_option', {
      credential_option: option.mailerCredentialOption,
    });

    // Validate that all required SMTP settings are provided via message
    if (
      !option.mailerCredentialOption?.host ||
      !option.mailerCredentialOption?.port ||
      !option.mailerCredentialOption?.username ||
      !option.mailerCredentialOption?.password
    ) {
      logger.warn(
        'Missing required SMTP settings in mailerCredentialOption. All host, port, username, and password must be provided via Pulsar message.',
        { mailerCredentialOption: option.mailerCredentialOption }
      );
      return false;
    }

    try {
      const transportOption = {
        auth: {
          pass: option.mailerCredentialOption.password,
          user: option.mailerCredentialOption.username,
        },
        host: option.mailerCredentialOption.host,
        port: Number(option.mailerCredentialOption.port),
      };

      logger.info('mailer_transport_options', { transportOption });

      const transporter = nodemailer.createTransport(transportOption);

      const message: {
        attachments: typeof option.attachments;
        from: string;
        html: string;
        replyTo: string;
        subject: string;
        to: string[];
        cc?: string[];
        bcc?: string[];
      } = {
        attachments: option.attachments,
        from: `${option.sender} <${option.mailerCredentialOption.username}>`,
        html: option.content,
        replyTo: option.replyTo,
        subject: option.subject,
        to: option.recipients,
      };

      // Add CC and BCC if present
      if (option.ccRecipients && option.ccRecipients.length > 0) {
        message.cc = option.ccRecipients;
      }
      if (option.bccRecipients && option.bccRecipients.length > 0) {
        message.bcc = option.bccRecipients;
      }

      logger.info('smtp_message_details', {
        from: message.from,
        sender: option.sender,
        username: option.mailerCredentialOption.username,
      });

      // WE WILL USE VOID SINCE THE SEND MAIL FUNCTION IS NON ASYNC METHOD
      transporter.sendMail(message, async (error, info) => {
        transporter.close();
        if (error) {
          throw friendlyError(error, 'send_mail_client');
        }
        //  SAVE EMAIL RESULT HERE AS NEEDED
        const result = info as unknown as MailerClientResult;
        await this.mailerAuditService.save(
          {
            mailerResponse: result,
            messageId: result.messageId,
          },
          {}
        );
        logger.info('email_sent_successfully_smtp', {
          communicationLogId: option.metadata?.communicationLogId,
          messageId: result.messageId,
          recipients: option.recipients,
          sender: option.sender,
          subject: option.subject,
        });
        logger.info('send_mail_client', { result });
      });
      transporter.close();
    } catch (error) {
      throw friendlyError(error, 'send_email');
    }

    return Promise.resolve(true);
  }

  async sendMailM365(option: MailerOptionDto): Promise<boolean> {
    if (!option.mailerCredentialOption?.m365) {
      return Promise.resolve(false);
    }

    const graphEndpoint = 'https://graph.microsoft.com';

    // Log detailed M365 credential validation BEFORE attempting authentication
    const m365Creds = option.mailerCredentialOption.m365;
    const credValidation = {
      tenantId: {
        value: m365Creds.tenantId,
        length: m365Creds.tenantId?.length || 0,
        isValidFormat: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(m365Creds.tenantId || ''),
        isEmpty: !m365Creds.tenantId || m365Creds.tenantId.trim() === '',
      },
      clientId: {
        value: m365Creds.clientId,
        length: m365Creds.clientId?.length || 0,
        isValidFormat: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(m365Creds.clientId || ''),
        isEmpty: !m365Creds.clientId || m365Creds.clientId.trim() === '',
      },
      clientSecret: {
        length: m365Creds.clientSecret?.length || 0,
        startsWithExpectedPattern: m365Creds.clientSecret?.startsWith('QOI8Q~') || false, // Based on your doc example
        isEmpty: !m365Creds.clientSecret || m365Creds.clientSecret.trim() === '',
        // Don't log the actual secret value for security
      },
      username: {
        value: option.mailerCredentialOption.username,
        isValidEmail: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(option.mailerCredentialOption.username || ''),
        domain: option.mailerCredentialOption.username?.split('@')[1],
        isEmpty: !option.mailerCredentialOption.username || option.mailerCredentialOption.username.trim() === '',
      },
      authMethod: m365Creds.accessToken ? 'OAuth_AccessToken' : 'ClientCredentials',
    };

    logger.info('m365_credential_validation_check', credValidation);

    // Validate each credential individually and provide specific error messages
    const validationErrors: string[] = [];

    if (credValidation.tenantId.isEmpty) {
      validationErrors.push('Tenant ID is empty or missing');
    } else if (!credValidation.tenantId.isValidFormat) {
      validationErrors.push(`Tenant ID has invalid UUID format: "${credValidation.tenantId.value}"`);
    }

    if (credValidation.clientId.isEmpty) {
      validationErrors.push('Client ID is empty or missing');
    } else if (!credValidation.clientId.isValidFormat) {
      validationErrors.push(`Client ID has invalid UUID format: "${credValidation.clientId.value}"`);
    }

    if (credValidation.clientSecret.isEmpty) {
      validationErrors.push('Client Secret is empty or missing');
    } else if (credValidation.clientSecret.length < 10) {
      validationErrors.push(`Client Secret appears too short (length: ${credValidation.clientSecret.length})`);
    }

    if (credValidation.username.isEmpty) {
      validationErrors.push('Username/Email is empty or missing');
    } else if (!credValidation.username.isValidEmail) {
      validationErrors.push(`Username is not a valid email format: "${credValidation.username.value}"`);
    }

    if (validationErrors.length > 0) {
      logger.error('m365_credential_validation_failed', {
        errors: validationErrors,
        credentialSummary: {
          tenantIdFormat: credValidation.tenantId.isValidFormat ? 'Valid UUID' : 'Invalid',
          clientIdFormat: credValidation.clientId.isValidFormat ? 'Valid UUID' : 'Invalid',
          clientSecretLength: credValidation.clientSecret.length,
          usernameFormat: credValidation.username.isValidEmail ? 'Valid email' : 'Invalid',
        },
      });
    } else {
      logger.info('m365_credentials_passed_basic_validation', {
        tenantId: credValidation.tenantId.value,
        clientId: credValidation.clientId.value,
        username: credValidation.username.value,
        clientSecretLength: credValidation.clientSecret.length,
      });
    }

    try {
      let client: m365Client;

      // If OAuth tokens are provided (from connected Microsoft account), check if token is expired
      if (option.mailerCredentialOption?.m365?.accessToken) {
        logger.info(
          'Using OAuth access token from connected Microsoft account'
        );

        // Check if token is expired by decoding JWT payload
        const tokenParts =
          option.mailerCredentialOption.m365.accessToken.split('.');
        if (tokenParts.length === 3) {
          try {
            const payload = JSON.parse(
              Buffer.from(tokenParts[1], 'base64').toString()
            );
            const expiryTime = payload.exp * 1000; // Convert to milliseconds
            const currentTime = Date.now();
            const isExpired = currentTime >= expiryTime;

            logger.info('access_token_expiry_check', {
              currentTime: new Date(currentTime).toISOString(),
              expiryTime: new Date(expiryTime).toISOString(),
              isExpired,
              timeUntilExpiry: expiryTime - currentTime,
            });

            // If token is expired and we have a refresh token, refresh it proactively
            if (isExpired && option.mailerCredentialOption.m365.refreshToken) {
              logger.info(
                'Access token expired, refreshing proactively before API call'
              );

              const newTokens = await this.refreshAccessToken(
                option.mailerCredentialOption.m365.tenantId as string,
                option.mailerCredentialOption.m365.clientId as string,
                option.mailerCredentialOption.m365.clientSecret as string,
                option.mailerCredentialOption.m365.refreshToken as string
              );

              if (newTokens) {
                // Update the option with new tokens
                option.mailerCredentialOption.m365.accessToken =
                  newTokens.accessToken;
                option.mailerCredentialOption.m365.refreshToken =
                  newTokens.refreshToken;

                logger.info(
                  'Access token refreshed successfully, proceeding with email send'
                );
              } else {
                logger.error('Failed to refresh expired access token');
                throw new Error('Failed to refresh expired access token');
              }
            }
          } catch (decodeError) {
            logger.warn('Failed to decode JWT token for expiry check', {
              error:
                decodeError instanceof Error
                  ? decodeError.message
                  : 'Unknown error',
            });
            // Continue anyway and let the Microsoft Graph SDK handle it
          }
        }

        client = m365Client.init({
          authProvider: (done) => {
            done(
              null,
              option.mailerCredentialOption?.m365?.accessToken as string
            );
          },
        });
      } else {
        // Otherwise, use client credentials flow (for service accounts)
        logger.info('Using client credentials flow for M365 authentication', {
          tenantId: m365Creds.tenantId,
          clientId: m365Creds.clientId,
          username: option.mailerCredentialOption.username,
        });

        const credential = new ClientSecretCredential(
          option.mailerCredentialOption?.m365.tenantId as string,
          option.mailerCredentialOption?.m365.clientId as string,
          option.mailerCredentialOption?.m365.clientSecret as string
        );
        const authProvider = new TokenCredentialAuthenticationProvider(
          credential,
          { scopes: ['https://graph.microsoft.com/.default'] }
        );

        client = m365Client.initWithMiddleware({
          authProvider: authProvider,
        });
      }

      const mail = this.buildMailObject(option);

      const result = await client
        .api(
          `${graphEndpoint}/v1.0/users/${option.mailerCredentialOption.username}/sendMail`
        )
        .post({ message: mail });

      logger.info('email_sent_successfully_m365', {
        communicationLogId: option.metadata?.communicationLogId,
        recipients: option.recipients,
        sender: option.sender,
        subject: option.subject,
      });
      logger.debug('m365_send_mail_result', { result });
    } catch (error) {
      // Extract detailed error information
      const errorObj = error as any;
      const errorDetails = {
        statusCode: errorObj.statusCode,
        code: errorObj.code,
        message: errorObj.message,
        body: errorObj.body,
        requestId: errorObj.requestId,
        date: errorObj.date,
        // Azure-specific error details
        errorType: errorObj.name,
        errorCode: errorObj.code,
        innerError: errorObj.innerError,
        // Full error object for debugging (limit size)
        fullError: JSON.stringify(errorObj, null, 2).substring(0, 2000),
      };

      // Log comprehensive error diagnostics
      logger.error('m365_send_email_failed_detailed', {
        errorDetails,
        credentialsDiagnostic: {
          tenantId: option.mailerCredentialOption?.m365?.tenantId,
          clientId: option.mailerCredentialOption?.m365?.clientId,
          clientSecretLength: option.mailerCredentialOption?.m365?.clientSecret?.length || 0,
          username: option.mailerCredentialOption?.username,
          authMethod: option.mailerCredentialOption?.m365?.accessToken ? 'OAuth' : 'ClientCredentials',
        },
        possibleCauses: this.diagnoseMicrosoftAuthError(errorObj),
      });

      // Check if error is 403 (token expired) and we have OAuth tokens
      const is403Error =
        errorObj.statusCode === 403 || errorObj.code === 'ErrorAccessDenied';
      const hasOAuthTokens =
        option.mailerCredentialOption?.m365?.accessToken &&
        option.mailerCredentialOption?.m365?.refreshToken;

      if (is403Error && hasOAuthTokens) {
        logger.warn('Access token expired, attempting to refresh and retry');

        // Try to refresh the access token
        const newTokens = await this.refreshAccessToken(
          option.mailerCredentialOption?.m365?.tenantId as string,
          option.mailerCredentialOption?.m365?.clientId as string,
          option.mailerCredentialOption?.m365?.clientSecret as string,
          option.mailerCredentialOption?.m365?.refreshToken as string
        );

        if (newTokens && option.mailerCredentialOption?.m365) {
          // Update the option with new tokens
          option.mailerCredentialOption.m365.accessToken =
            newTokens.accessToken;
          option.mailerCredentialOption.m365.refreshToken =
            newTokens.refreshToken;

          logger.info('Token refreshed successfully, retrying email send');

          // Retry sending email with new access token
          const clientRetry = m365Client.init({
            authProvider: (done) => {
              done(null, newTokens.accessToken);
            },
          });

          try {
            const mail = this.buildMailObject(option);
            const retryResult = await clientRetry
              .api(
                `${graphEndpoint}/v1.0/users/${option.mailerCredentialOption.username}/sendMail`
              )
              .post({ message: mail });

            logger.info('Email sent successfully after token refresh', {
              retryResult,
            });
            return Promise.resolve(true);
          } catch (retryError) {
            logger.error('Failed to send email after token refresh', {
              error: retryError,
            });
            throw friendlyError(retryError, 'send_email_after_refresh');
          }
        } else {
          logger.error(
            'Failed to refresh access token, cannot retry email send'
          );
          throw friendlyError(error, 'send_email_token_refresh_failed');
        }
      }

      throw friendlyError(error, 'send_email');
    }

    return Promise.resolve(true);
  }
}
