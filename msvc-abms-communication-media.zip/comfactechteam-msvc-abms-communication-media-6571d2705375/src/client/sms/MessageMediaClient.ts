/* eslint-disable @typescript-eslint/no-non-null-asserted-optional-chain */
import axios from 'axios';
import { Container, Service } from 'typedi';

import { PulsarProducerClient } from '../../client/pulsar/producer/PulsarProducerClient';
import { SMSAuditModel } from '../../datasource/models/SMSAuditModel';
import {
  MessageMediaDto,
  MessageMediaResponse,
  MessageMediaWebhook,
} from '../../dto/MessageMediaDto';
import { PulsarDataAction } from '../../enums/DataActionEnum';
import { PulsarTopics } from '../../enums/PulsarTopics';
import environment from '../../environment';
import { SmsAuditService } from '../../services/SmsAuditService';
import { friendlyError } from '../../utils/ExceptionUtils';
import { logger } from '../../utils/LoggerUtils';

@Service()
export class MessageMediaClient {
  constructor(private readonly smsAuditService: SmsAuditService) {}

  async sendSMS(option: MessageMediaDto): Promise<MessageMediaResponse> {
    let response: MessageMediaResponse;

    if (!option.credentials) {
      const defaultMessageMediaCredentials = {
        apiKey: environment.SMS_MESSAGEMEDIA_APIKEY,
        apiSecret: environment.SMS_MESSAGEMEDIA_APISECRET,
      };
      Object.assign(option, { credentials: defaultMessageMediaCredentials });
    }

    logger.info('messagemedia_credential', {
      credentials: option.credentials,
    });

    try {
      if (option.messages.length > 0) {
        option.messages.forEach((item) => {
          item.callback_url = environment.SMS_MESSAGEMEDIA_CALLBACK_URL;
          item.delivery_report = true;
        });
      }

      logger.info('messagemedia_sending_sms', {
        callbackUrl: environment.SMS_MESSAGEMEDIA_CALLBACK_URL,
        destinationNumbers: option.messages.map((m) => m.destination_number),
        messageCount: option.messages.length,
      });

      const result = await axios.post(
        environment.SMS_MESSAGEMEDIA_ENDPOINT!,
        { messages: option.messages },
        {
          auth: {
            password: option.credentials?.apiSecret!,
            username: option.credentials?.apiKey!,
          },
          headers: { 'Content-Type': 'application/json' },
        }
      );

      if (result.status == 202 && result.data.messages.length >= 0) {
        const messageMediaResponse = result.data
          .messages[0] as MessageMediaResponse;
        response = messageMediaResponse;

        const smsAudit = await this.smsAuditService.save(
          {
            callbackUrl: environment.SMS_MESSAGEMEDIA_CALLBACK_URL,
            communicationLogId: option.communicationLogId,
            content: messageMediaResponse.content,
            destinationNumber: messageMediaResponse.destination_number,
            isDeliveryReport: true,
            messageId: messageMediaResponse.message_id,
            status: messageMediaResponse.status,
            statusTrail: JSON.stringify([
              {
                dateReceived: `${new Date().toISOString()}`,
                status: messageMediaResponse.status,
              },
            ]),
          },
          {}
        );

        logger.debug('update_data', { smsAudit });
      } else {
        throw friendlyError(result, 'send_sms');
      }
    } catch (error) {
      logger.debug('update_data', { error });
      throw friendlyError(error, 'send_sms');
    }

    return Promise.resolve(response);
  }

  async receive(option: MessageMediaWebhook): Promise<boolean> {
    try {
      const isDeliveryReport = typeof option.reply_id === 'undefined';
      const smsAudits = (await this.smsAuditService.findByMessageId(
        option.message_id,
        { isDeliveryReport: true }
      )) as SMSAuditModel[];

      if (isDeliveryReport && smsAudits.length > 0) {
        const rawTrail = smsAudits.at(0)?.statusTrail;
        const updatedStatusTrailObj = Array.isArray(rawTrail) ? rawTrail : [{}];

        updatedStatusTrailObj.push({
          dateReceived: option.date_received,
          status: option.status,
        });

        const smsAuditId = smsAudits.at(0)?.id as string;

        const updateObj = {
          delay: option.delay,
          deliveryReportId: option.delivery_report_id,
          messageId: option.message_id,
          status: option.status,
          statusTrail: JSON.stringify(updatedStatusTrailObj),
          submittedDate: option.submitted_date,
          vendorAccountId: JSON.stringify(option.vendor_account_id),
        } as SMSAuditModel;

        await this.smsAuditService.update(smsAuditId, updateObj, {});
      } else if (!isDeliveryReport) {
        // This is a reply from the recipient
        // Save the reply to SMS audit trail
        await this.smsAuditService.save(
          {
            callbackUrl: option.callback_url,
            content: option.content,
            destinationNumber: option.source_number,
            isDeliveryReport: false,
            messageId: option.message_id,
            replyId: option.reply_id,
            sourceNumber: option.source_number,
            status: 'reply',
            statusTrail: JSON.stringify([
              {
                dateReceived: `${new Date().toISOString()}`,
                status: 'replied',
              },
            ]),
            vendorAccountId: JSON.stringify(option.vendor_account_id),
          },
          {}
        );

        logger.info('sms_reply_received', {
          content: option.content,
          messageId: option.message_id,
          replyId: option.reply_id,
          sourceNumber: option.source_number,
        });

        // Find the original SMS audit to get communicationLogId and other metadata
        if (smsAudits.length > 0) {
          const originalSmsAudit = smsAudits[0];

          // If we have the original CommunicationLog reference, send Pulsar message to create reply
          if (originalSmsAudit.communicationLogId) {
            try {
              const pulsarProducerClient = Container.get(PulsarProducerClient);

              await pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
                action: PulsarDataAction.PROCESS,
                data: {
                  communicationLogId: originalSmsAudit.communicationLogId,
                  content: option.content,
                  dateReceived: option.date_received,
                  messageId: option.message_id,
                  replyId: option.reply_id,
                  sourceNumber: option.source_number,
                },
                subAction: 'sms_reply',
              });

              logger.info('sms_reply_queued_for_comm_log_creation', {
                communicationLogId: originalSmsAudit.communicationLogId,
                messageId: option.message_id,
                replyId: option.reply_id,
              });
            } catch (pulsarError) {
              logger.error('failed_to_queue_sms_reply', {
                communicationLogId: originalSmsAudit.communicationLogId,
                error:
                  pulsarError instanceof Error
                    ? pulsarError.message
                    : 'Unknown error',
                messageId: option.message_id,
              });
            }
          } else {
            logger.warn('sms_reply_no_comm_log_link', {
              messageId: option.message_id,
              note: 'Original SMS has no communicationLogId - reply cannot be linked to Activities',
              replyId: option.reply_id,
            });
          }
        } else {
          logger.warn('sms_reply_no_original_sms_found', {
            messageId: option.message_id,
            note: 'Cannot find original SMS audit record',
            replyId: option.reply_id,
          });
        }
      } else {
        logger.debug('smsAudits', smsAudits);
        throw friendlyError(smsAudits, 'receive_reply_dr');
      }
    } catch (error) {
      logger.debug('update_data', { error });
      throw friendlyError(error, 'receive_reply_dr');
    }

    return Promise.resolve(true);
  }
}
