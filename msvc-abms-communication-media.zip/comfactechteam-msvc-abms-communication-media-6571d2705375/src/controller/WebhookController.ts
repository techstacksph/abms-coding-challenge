import 'reflect-metadata';

import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Body,
  CurrentUser,
  JsonController,
  Post,
  Res,
} from 'routing-controllers';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { MessageMediaClient } from '../client/sms/MessageMediaClient';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { MessageMediaWebhook } from '../dto/MessageMediaDto';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@JsonController('/v1/callback')
export class WebhookController {
  constructor(
    private readonly messageMediaClient: MessageMediaClient,
    private readonly pulsarProducerClient: PulsarProducerClient
  ) {}

  @Post('/sms')
  async receiveCallback(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() option: MessageMediaWebhook
  ) {
    // Log incoming webhook for debugging
    logger.info('sms_webhook_received', {
      hasReplyId: !!option.reply_id,
      messageId: option.message_id,
      replyId: option.reply_id,
      sourceNumber: option.source_number,
      type: option.reply_id ? 'sms_reply' : 'delivery_report',
    });

    const errors: ValidationError[] = await validate(option);
    if (errors.length) {
      logger.warn('sms_webhook_validation_failed', {
        errors: errors.map((e) => e.toString()),
        messageId: option.message_id,
      });
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      await this.messageMediaClient.receive(option);
      logger.info('sms_webhook_processed_successfully', {
        messageId: option.message_id,
        replyId: option.reply_id,
        type: option.reply_id ? 'sms_reply' : 'delivery_report',
      });
      return res.status(200).send({ message: 'message_received' });
    } catch (error) {
      logger.error('sms_webhook_processing_error', {
        error: (error as Error).message,
        messageId: option.message_id,
        replyId: option.reply_id,
        stack: (error as Error).stack,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'receive_reply_dr_sms',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
