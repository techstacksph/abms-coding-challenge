import { Get, JsonController } from 'routing-controllers';

import environment from '../environment';

@JsonController('/v1/home')
export class HomeController {
  @Get('/status')
  async status() {
    return { message: 'GOOD TO GO', server_name: environment.APP_HOST_NAME };
  }
}
