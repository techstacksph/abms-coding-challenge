import { Service } from 'typedi';

import { HomeController } from './HomeController';
import { MailerController } from './MailerController';
import { SMSController } from './SMSController';
import { WebhookController } from './WebhookController';

@Service()
export class ControllerInitializer {
  // eslint-disable-next-line @typescript-eslint/ban-types
  controllers(): Function[] | string[] {
    return [HomeController, MailerController, SMSController, WebhookController];
  }
}
