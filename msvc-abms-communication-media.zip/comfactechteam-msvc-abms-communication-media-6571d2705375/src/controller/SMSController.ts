import 'reflect-metadata';

import { plainToClass } from 'class-transformer';
import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  JsonController,
  Post,
  Res,
} from 'routing-controllers';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { MessageMediaClient } from '../client/sms/MessageMediaClient';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { MessageMediaDto, MessageMediaResponse } from '../dto/MessageMediaDto';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@Authorized()
@JsonController('/v1/auth')
export class SMSController {
  constructor(
    private readonly messageMediaClient: MessageMediaClient,
    private readonly pulsarProducerClient: PulsarProducerClient
  ) {}

  @Post('/sms')
  async sendSMS(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() option: MessageMediaDto
  ) {
    const messageMediaDto = plainToClass(MessageMediaDto, option);
    const errors: ValidationError[] = await validate(messageMediaDto);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const response = (await this.messageMediaClient.sendSMS(
        messageMediaDto
      )) as MessageMediaResponse;

      return res.status(200).send({ ...response });
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'send_sms',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Post('/sms-pulsar')
  async sendSmsPulsar(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() option: MessageMediaDto
  ) {
    const messageMediaDto = plainToClass(MessageMediaDto, option);
    const errors: ValidationError[] = await validate(messageMediaDto);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    logger.info('INFO_PULSAR_REQUEST', {
      action: PulsarDataAction.PROCESS,
      data: messageMediaDto,
      subAction: 'sms',
    });

    try {
      const result = await this.pulsarProducerClient.produce(
        PulsarTopics.MICROSERVICE_APP_ID,
        {
          action: PulsarDataAction.PROCESS,
          data: messageMediaDto,
          subAction: 'sms',
        }
      );
      logger.info('sms_sent_to_pulsar', {
        id: result?.toString(),
        result: result,
      });
      return res
        .status(200)
        .send({ id: result?.toString(), message: 'sms_sent_to_pulsar' });
    } catch (error) {
      logger.error('sms_failed_to_pulsar', {
        error: (error as Error).message,
      });
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'send_sms',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
