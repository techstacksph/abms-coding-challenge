import 'reflect-metadata';

import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  JsonController,
  Post,
  Res,
} from 'routing-controllers';

import { MailerClient } from '../client/mailer/MailerClient';
import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { MailerOptionDto } from '../dto/MailerOptionDto';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@Authorized()
@JsonController('/v1/auth/mailer')
export class MailerController {
  constructor(
    private readonly mailerClient: MailerClient,
    private readonly pulsarProducerClient: PulsarProducerClient
  ) {}

  @Post('/email')
  async sendEmail(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() option: MailerOptionDto
  ) {
    const errors: ValidationError[] = await validate(option);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      await this.mailerClient.sendEmail(option);
      return res.status(200).send({ message: 'email_received_for_process' });
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'send_email',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Post('/email-pulsar')
  async sendEmailPulsar(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() option: MailerOptionDto
  ) {
    const errors: ValidationError[] = await validate(option);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const result = await this.pulsarProducerClient.produce(
        PulsarTopics.MICROSERVICE_APP_ID,
        { action: PulsarDataAction.PROCESS, data: option, subAction: 'email' }
      );
      return res
        .status(200)
        .send({ id: result?.toString(), message: 'email_sent_to_pulsar' });
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'send_email',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
