#!/bin/sh
yarn migration:run
yarn start
