#!/bin/sh

# Wait for postgres to be ready
until pg_isready -h ${DATABASE_HOSTNAME} -p ${DATABASE_PORT} -U ${DATABASE_USERNAME}; do
  echo "Waiting for PostgreSQL..."
  sleep 2
done

echo "PostgreSQL is ready!"

# Create database if it doesn't exist
echo "Checking if database ${DATABASE_NAME} exists..."
DB_EXISTS=$(PGPASSWORD=${DATABASE_PASSWORD} psql -h ${DATABASE_HOSTNAME} -p ${DATABASE_PORT} -U ${DATABASE_USERNAME} -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='${DATABASE_NAME}'")

if [ "$DB_EXISTS" != "1" ]; then
  echo "Creating database ${DATABASE_NAME}..."
  PGPASSWORD=${DATABASE_PASSWORD} createdb -h ${DATABASE_HOSTNAME} -p ${DATABASE_PORT} -U ${DATABASE_USERNAME} ${DATABASE_NAME}
  echo "Database ${DATABASE_NAME} created successfully!"
else
  echo "Database ${DATABASE_NAME} already exists."
fi

# Run migrations and start development server
echo "Running migrations..."
yarn migration:run
echo "Starting development server..."
yarn dev