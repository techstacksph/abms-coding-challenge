# Docker Setup for FE-ABMS

This guide explains how to run the FE-ABMS application using Docker.

## 📋 Prerequisites

- **Docker** >= 20.10.0
- **Docker Compose** >= 2.0.0
- **Git**

## 🚀 Quick Start

### Option 1: Using Docker Compose (Recommended)

1. **Cl## Troubleshooting

### Common Issues

#### Proxy Configuration Issues

If authentication or API calls are not working properly:

1. **Check backend services are running**:
   ```bash
   # Test if backend services are accessible
   curl http://localhost:8080/health  # Apollo GraphQL service
   curl http://localhost:8092/health  # Auth service
   ```

2. **Test proxy configuration**:
   ```bash
   # Run the proxy test script
   ./test-proxy.sh
   ```

3. **For development mode**: Proxies are handled by Vite dev server
   - API calls to `/api/gw/*` are proxied to `http://host.docker.internal:8080`
   - API calls to `/api/auth/*` are proxied to `http://host.docker.internal:8092`
   - WebSocket calls to `/api/ws/*` are proxied to `ws://host.docker.internal:8080`

4. **For production mode**: Proxies are handled by Nginx
   - Check `nginx.conf` for proxy configuration
   - Ensure backend services are accessible from Docker container

5. **Docker networking issues**:
   - Use `host.docker.internal` instead of `localhost` in Docker containers
   - Ensure `extra_hosts` configuration is present in docker-compose.yml
   - On Linux, you may need to use the host network mode or gateway IP

#### Environment Variables

Make sure your `.env` file has the correct service URLs:
```bash
# For Docker development
REACT_APP_APOLLO_URI=http://host.docker.internal:8080/api/gw
REACT_APP_APOLLO_WS=ws://host.docker.internal:8080/api/ws  
REACT_APP_AUTH_URI=http://host.docker.internal:8092/api/auth
``` the repository and navigate to it**
   ```bash
   git clone <repository-url>
   cd fe-abms
   ```

2. **Make shell scripts executable**
   ```bash
   chmod +x docker.sh validate-docker.sh
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   # Edit .env with your configuration
   ```

4. **Validate Docker setup (optional but recommended)**
   ```bash
   ./validate-docker.sh
   # Or using yarn
   yarn docker:validate
   ```

5. **Start the application**

   **For Development:**
   ```bash
   # Using the helper script
   ./docker.sh dev
   
   # Or using yarn
   yarn docker:dev
   
   # Or using docker-compose directly
   docker-compose --profile dev up --build
   ```
   Access at: http://localhost:5173

   **For Production:**
   ```bash
   # Using the helper script
   ./docker.sh prod
   
   # Or using yarn
   yarn docker:prod
   
   # Or using docker-compose directly
   docker-compose --profile prod up --build
   ```
   Access at: http://localhost:80

### Option 2: Using Docker directly

1. **Build the image**
   ```bash
   docker build -t fe-abms:latest .
   ```

2. **Run the container**

   **For Development:**
   ```bash
   docker run -p 5173:5173 \
     --env-file .env \
     -v $(pwd):/app \
     -v /app/node_modules \
     fe-abms:latest
   ```

   **For Production:**
   ```bash
   docker run -p 80:80 \
     --env-file .env \
     fe-abms:latest
   ```

## 🛠 Docker Helper Script

The `docker.sh` script provides convenient commands for managing the Docker environment:

```bash
# Start development environment
./docker.sh dev

# Start production environment
./docker.sh prod

# Build Docker image
./docker.sh build

# Stop all containers
./docker.sh stop

# Clean up containers and images
./docker.sh clean

# View container logs
./docker.sh logs
```

## 📁 Docker Files Overview

### Dockerfile
Multi-stage Dockerfile with:
- **Development stage**: Hot-reload enabled Vite dev server
- **Production stage**: Optimized build served by Nginx

### docker-compose.yml
Contains three service profiles:
- **dev**: Development environment with hot-reload
- **prod**: Production environment on port 80
- **default**: Production environment on port 3000

### nginx.conf
Production Nginx configuration with:
- React Router support (SPA routing)
- Gzip compression
- Security headers
- Static asset caching
- Health check endpoint

### .dockerignore
Excludes unnecessary files from Docker build context

## 🔧 Configuration

### Environment Variables

Create a `.env` file based on `env.example`:

```bash
# Application Configuration
NODE_ENV=production
PORT=3000

# API Configuration
REACT_APP_APOLLO_URI=https://your-api.com/api/gw
REACT_APP_APOLLO_WS=wss://your-api.com/api/ws
REACT_APP_AUTH_URI=https://your-auth.com/api/auth
REACT_APP_API_URL=https://your-api.com
REACT_APP_API_TIMEOUT=30000

# Feature Configuration
REACT_APP_TENANT_PREFIX=your-tenant
REACT_APP_GOOGLE_API_KEY=your-google-api-key
REACT_APP_LOG_LEVEL=info
```

### Port Configuration

Default ports:
- **Development**: 5173
- **Production**: 80 (or 3000 for standalone)

To change ports, modify the `docker-compose.yml` file:

```yaml
ports:
  - "YOUR_PORT:5173"  # For development
  - "YOUR_PORT:80"    # For production
```

## 🏥 Health Checks

Both development and production containers include health checks:

```bash
# Check container health
docker ps

# Manual health check
curl http://localhost/health  # Production
curl http://localhost:5173/   # Development
```

## 📊 Monitoring and Logs

### View logs
```bash
# All containers
docker-compose logs -f

# Specific service
docker-compose logs -f fe-abms-dev

# Using helper script
./docker.sh logs
```

### Container stats
```bash
docker stats
```

## 🔄 Development Workflow

1. **Start development environment**
   ```bash
   ./docker.sh dev
   ```

2. **Make code changes** - Hot-reload is enabled

3. **View logs**
   ```bash
   ./docker.sh logs
   ```

4. **Stop when done**
   ```bash
   ./docker.sh stop
   ```

## 🚀 Production Deployment

### Build and deploy
```bash
# Build production image
docker build -t fe-abms:latest .

# Tag for registry (if using)
docker tag fe-abms:latest your-registry/fe-abms:v1.0.0

# Push to registry
docker push your-registry/fe-abms:v1.0.0

# Deploy
docker run -d \
  --name fe-abms-prod \
  -p 80:80 \
  --env-file .env \
  --restart unless-stopped \
  your-registry/fe-abms:v1.0.0
```

### Using Docker Compose in production
```bash
# Start in detached mode
docker-compose --profile prod up -d

# Update deployment
docker-compose --profile prod pull
docker-compose --profile prod up -d
```

## 🛠 Troubleshooting

### Common Issues

1. **Permission denied when running shell scripts**
   ```bash
   # Make scripts executable
   chmod +x docker.sh validate-docker.sh
   
   # Or use yarn commands instead
   yarn docker:dev
   yarn docker:validate
   ```

2. **Production build fails with dependency resolution errors**
   ```bash
   # This is a known issue with complex dependencies (@react-pdf, @ant-design)
   # and Yarn 4+ PnP in Docker environments
   
   # Workaround: Use development mode for testing
   ./docker.sh dev
   
   # For production deployment, consider:
   # - Building locally and copying dist/ to a simple nginx container
   # - Using npm instead of yarn for Docker builds
   # - Simplifying dependencies or adding missing peer dependencies
   ```

3. **Port already in use**
   ```bash
   # Check what's using the port
   lsof -i :5173  # or :80
   
   # Stop conflicting process or change port in docker-compose.yml
   ```

4. **Environment variables not loading**
   ```bash
   # Ensure .env file exists and has correct format
   cat .env
   
   # Rebuild containers
   docker-compose up --build
   ```

4. **Hot-reload not working in development**
   ```bash
   # Ensure volume mounts are correct
   docker-compose logs fe-abms-dev
   
   # Try rebuilding
   ./docker.sh clean
   ./docker.sh dev
   ```

5. **Build failures**
   ```bash
   # Clear Docker cache
   docker builder prune
   
   # Rebuild from scratch
   docker build --no-cache -t fe-abms:latest .
   ```

### Useful Commands

```bash
# Enter running container
docker exec -it <container-name> sh

# View container processes
docker top <container-name>

# Inspect container configuration
docker inspect <container-name>

# View Docker disk usage
docker system df

# Clean up unused resources
docker system prune
```

## 📝 Notes

- The development container uses volume mounts for hot-reload
- Production container serves static files via Nginx
- Both containers include health checks
- Environment variables are loaded from `.env` file
- The application supports React Router for SPA routing
