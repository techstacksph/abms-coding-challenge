import dayjs from 'dayjs';

import { SELECT_ACCOUNTS } from '@/graphql/accounts.gql';
import { SELECT_CASES } from '@/graphql/case.gql';
import { ALL_COMM_LOGS } from '@/graphql/communicationLogs.gql';
import { SELECT_DEALS } from '@/graphql/deals.gql';
import { ALL_EMPLOYEES } from '@/graphql/employee.gql';
import { ALL_FUNCTIONS } from '@/graphql/function.gql';
import { SELECT_JOBS } from '@/graphql/jobs.gql';
import { SELECT_LEADS } from '@/graphql/leads.gql';
import { ALL_LOCATIONS } from '@/graphql/location.gql';
import { ALL_PURCHASE_ORDERS } from '@/graphql/purchaseOrder.gql';
import { ALL_QUALITY_AUDIT_IDS_MIN } from '@/graphql/qualityAudit.gql';
import { ALL_QUOTES } from '@/graphql/quotes.gql';
import { ALL_RECRUITMENTS } from '@/graphql/recruitment.gql';
import { ALL_SALES_ORDERS } from '@/graphql/salesOrder.gql';
import { ALL_TASKS } from '@/graphql/tasks.gql';
import { ALL_INVOICES } from '@/graphql/invoice.gql';
import { ALL_BILLS } from '@/graphql/bills.gql';
import { SELECT_DELIVERY_RETURN } from '@/graphql/deliveriesAndReturns.gql';
import { ALL_EVALUATIONS } from '@/graphql/evaluations.gql';
import { ALL_TRAININGS } from '@/graphql/trainings.gql';
import { SELECT_BUSINESS_FOR_SALES } from '@/graphql/businessForSales.gql';
import { ALL_JOB_PURCHASES } from '@/graphql/jobPurchase.gql';
import { SELECT_STOCK_CONTROLS } from '@/graphql/stockControl.gql';
import { dateFormat } from '@/utils/date.utils';
import { ALL_LEAVES } from '@/graphql/leave.gql';

export const queryOptions = {
  function: ALL_FUNCTIONS,
  location: ALL_LOCATIONS, // From the "Location" module
  task: ALL_TASKS, // From the "Task" module
  account: SELECT_ACCOUNTS, // From the "Account" module
  communication_log: ALL_COMM_LOGS, // From the "Communication Logs" module
  lead: SELECT_LEADS, // From the "Leads" module
  Lead: SELECT_LEADS, // From the "Leads" module (capitalized)
  quote: ALL_QUOTES, // From the "Quote" module
  case: SELECT_CASES,
  deal: SELECT_DEALS,
  job: SELECT_JOBS,
  purchaseorder: ALL_PURCHASE_ORDERS, // From the "Purchase Orders" module
  qualityaudit: ALL_QUALITY_AUDIT_IDS_MIN, // From the "Quality Audits" module
  // receipt: ALL_RECEIPTS, // From the "Receipts" module
  recruitment: ALL_RECRUITMENTS, // From the "Recruitment" module
  salesorder: ALL_SALES_ORDERS,
  // statement: ALL_STATEMENTS, // From the "Statements" module
  deliveryandreturn: SELECT_DELIVERY_RETURN, // From the "Delivery & Return" module
  evaluation: ALL_EVALUATIONS, // From the "Evaluations" module
  training: ALL_TRAININGS, // From the "Trainings" module
  Training: ALL_TRAININGS, // From the "Trainings" module (capitalized)
  businessforsale: SELECT_BUSINESS_FOR_SALES, // From the "Business for Sale" module
  Businessforsale: SELECT_BUSINESS_FOR_SALES, // From the "Business for Sale" module (capitalized)
  jobpurchase: ALL_JOB_PURCHASES, // From the "Job Purchases" module
  Jobpurchase: ALL_JOB_PURCHASES, // From the "Job Purchases" module (capitalized)
  stock_control: SELECT_STOCK_CONTROLS, // From the "Stock Control" module
  // job: ALL_JOBS, // From the "Job" module
  // breache: ALL_BREACHES, // From the "Breaches" module
  // complaints: ALL_COMPLAINTS, // From the "Complaints" module
  invoice: ALL_INVOICES, // From the "Invoices" module
  Invoice: ALL_INVOICES, // From the "Invoices" module (capitalized)
  bill: ALL_BILLS, // From the "Bills" module
  // job_schedule: ALL_JOB_SCHEDULES, // From the "Job Schedules" module
  employee: ALL_EMPLOYEES,
  leave: ALL_LEAVES,
};

export const transformRelatedOptions = (relatedModule, data) => {
  // check
  switch (relatedModule) {
    case 'location':
      return data?.map(d => ({ label: `${d.name}`, value: d.id }));
    case 'task':
      return data?.map(d => ({
        label: `${d.taskSubject ?? d.subject}`,
        value: d.id,
      }));
    case 'quote':
      return data?.map(d => ({ label: `${d.quoteNo}`, value: d.id }));
    case 'lead':
    case 'Lead':
      return data?.map(d => ({
        label: d.lead,
        value: d.id,
      }));
    case 'communication_log':
      return data?.map(d => ({
        label: `${d.commType} | ${d.createdByName} - ${dayjs(
          d.createdAt
        ).format(dateFormat)}`,
        value: d.id,
      }));
    case 'deal':
      return data?.map(d => ({ label: `${d.dealNo}`, value: d.id }));
    case 'case':
      return data?.map(d => ({ label: `${d.caseNo}`, value: d.id }));
    case 'job':
      return data?.map(d => ({ label: `${d.jobNo}`, value: d.id }));
    case 'purchaseorder':
      return data?.map(d => ({ label: `${d.poNo}`, value: d.id }));
    case 'qualityaudit':
      return data?.map(d => ({ label: `${d.qaNo}`, value: d.id }));
    case 'salesorder':
      return data?.map(d => ({ label: `${d.soNo}`, value: d.id }));
    case 'recruitment':
      return data?.map(d => ({ label: `${d.recruitmentNo}`, value: d.id }));
    case 'employee':
      return data?.map(d => ({ label: `${d.fullName}`, value: d.id }));
    case 'invoice':
    case 'Invoice':
      return data?.map(d => ({ label: `${d.invoiceNo}`, value: d.id }));
    case 'bill':
      return data?.map(d => ({ label: `${d.billNo}`, value: d.id }));
    case 'deliveryandreturn':
      return data?.map(d => {
        const label = d.drNo || `ID: ${d.id}`;
        // // nathan to do check the actual label
        // if (d.purchaseOrder?.poNo) {
        //   label = `${d.purchaseOrder.poNo}`;
        // } else if (d.salesOrder?.soNo) {
        //   label = `${d.salesOrder.soNo}`;
        // } else if (d.pickUpLocation) {
        //   label = `${d.pickUpLocation} - ${label}`;
        // }
        return { label, value: d.id };
      });
    case 'evaluation':
      return data?.map(d => ({
        label: `${d.evaluationDate ? dayjs(d.evaluationDate).format(dateFormat) : 'No Data'}`,
        value: d.id,
      }));
    case 'training':
    case 'Training':
      return data?.map(d => ({
        label: `${d.trainingDate ? dayjs(d.trainingDate).format(dateFormat) : 'No Data'}`,
        value: d.id,
      }));
    case 'businessforsale':
    case 'Businessforsale':
      return data?.map(d => ({ label: `${d.businessNo}`, value: d.id }));
    case 'jobpurchase':
    case 'Jobpurchase':
      return data?.map(d => ({ label: `${d.jobPurchaseNo}`, value: d.id }));
    case 'stockcontrol':
    case 'stock_control':
      return data?.map(d => ({ label: `${d.scNo || d.id}`, value: d.id }));
    case 'leave':
      return data?.map(d => ({ label: `${d.leaveNo}`, value: d.id }));
    default:
      return data?.map(d => ({ label: d.name, value: d.id }));
  }
};
