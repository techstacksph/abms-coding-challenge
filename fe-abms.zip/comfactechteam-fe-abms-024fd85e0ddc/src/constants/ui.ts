/**
 * UI-related constants
 */

/**
 * Minimum number of characters required to trigger a search operation.
 * Used across input components (Select, MultipleSelection, ModuleActions, etc.)
 * to reduce unnecessary API calls and improve performance.
 */
export const MIN_SEARCH_LENGTH = 3;
export const PDF_TIME_OUT = 1800000; // 30 minutes
