export const DEFAULT_VALUE = 'N/A';
