import { StyleSheet, Font } from '@react-pdf/renderer';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from './base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

export const styles = StyleSheet?.create({
  tableOfContentcontainer: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: '1.91cm',
    fontFamily: 'Manrope',
  },
  tableOfContentContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 15,
    fontFamily: 'Manrope',
    fontWeight: 300,
  },
  tableOfContentContentText: {
    fontSize: 10,
    fontFamily: 'Manrope',
  },
  tableOfContentPageNumber: {
    fontSize: 10,
    fontWeight: 600,
    fontFamily: 'Manrope',
  },
  tableOfContentDotLine: {
    flex: 1,
    height: 1,
    marginBottom: 3,
    marginHorizontal: 4,
    borderBottom: '1 dotted black',
  },
  tableOfContentIndentedText: {
    paddingLeft: 20,
    fontWeight: 300,
  },
  page: {
    position: 'relative',
    backgroundColor: '#FFFFFF',
    fontFamily: 'Manrope',
    paddingTop: '3.27cm',
    paddingBottom: 80,
  },
  coverPage: {
    flexDirection: 'row',
    height: '100%',
    paddingBottom: 0,
  },
  leftColumn: {
    width: '50%',
    height: '100%',
    padding: 20,
    marginLeft: 30,
    paddingTop: 80,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  rightColumn: {
    width: '50%',
    height: '100%',
    position: 'relative',
  },
  header: {
    marginTop: '1.27cm',
    marginLeft: '1.91cm',
    zIndex: 100,
    width: 90,
  },
  headerText: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  proposalText: {
    fontSize: 14,
    marginBottom: 5,
    fontFamily: 'Antonio', // Now using Manrope
  },
  titleText: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    fontFamily: 'Antonio', // Now using Manrope
  },
  endTextTitle: {
    fontSize: 23,
    fontWeight: 'bold',
    marginBottom: 5,
    fontFamily: 'Manrope', // Now using Manrope
    color: '#fff',
  },
  endTextSubTitle: {
    fontSize: 10,
    fontWeight: 400,
    marginBottom: 5,
    fontFamily: 'Manrope', // Now using Manrope
    color: '#fff',
  },
  divider: {
    borderBottomWidth: 3,
    borderBottomColor: '#B5B5B5',
    marginTop: 5,
    marginBottom: 10,
    width: '100%',
  },
  dateText: {
    fontSize: 12,
    marginTop: 5,
  },
  imageCover: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  footerText: {
    fontSize: 10,
    marginBottom: 6,
    paddingLeft: '1.91cm',
    color: '#7f7f7f',
  },
  footerBar: {
    height: 15,
    backgroundColor: '#e6cca1', // Golden/bronze color
  },
  footerBar2: {
    height: 15,
    backgroundColor: '#F4F4F4', // GREY color
  },
  contentPage: {
    marginRight: '1.91cm',
    marginLeft: '1.91cm',
  },
  contentTitle: {
    fontSize: 16,
    marginBottom: 10,
  },
  contentText: {
    fontSize: 10,
    fontWeight: 200,
    textAlign: 'justify',
  },
  image: {
    width: '100%',
    marginTop: 10,
    marginBottom: 10,
  },
  subTitle: {
    fontSize: 10,
    fontWeight: 600,
    marginTop: 10,
    marginBottom: 5,
  },
  bulletList: {
    marginLeft: 10,
    marginTop: 5,
    marginBottom: 10,
  },
  bulletPoint: {
    fontSize: 10,
    marginBottom: 3,
  },
  contentTextBoldItalic: {
    fontSize: 10,
    fontWeight: 600,
    fontStyle: 'italic',
  },
  emphasisText: {
    fontSize: 10,
    fontWeight: 600,
    color: '#555555',
  },
  br: {
    marginTop: 10,
  },
  contentPageTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    fontFamily: 'Antonio',
    color: '#bca179',
    textAlign: 'center',
    marginTop: 20,
  },
  contentPageTitleSecondary: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    fontFamily: 'Antonio',
    color: '#000',
    textAlign: 'left',
  },

  areasTable: {
    marginTop: 10,
    marginBottom: 10,
    // width: '100%',
    backgroundColor: '#f4f4f4',
    padding: '10 20 10 20',
    borderRadius: 4,
  },
  areasRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  areasCell: {
    flex: 1,
    maxWidth: '6.08cm',
    paddingVertical: 4,
  },
  areaText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    color: '#333',
  },
  areaBullet: {
    color: '#bca179',
  },
  cleaningScheduleContainer: {
    marginTop: 20,
    marginBottom: 20,
    width: '100%',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f4f4f4',
    padding: 8,
  },
  tableHeaderCell: {
    flex: 5,
  },
  tableHeaderText: {
    color: 'black',
    fontFamily: 'Antonio',
    fontWeight: 'bold',
    fontSize: 12,
    textAlign: 'center',
  },
  dayCell: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  monthlyHeader: {
    backgroundColor: '#D6B77F',
    padding: 8,
  },
  monthlyText: {
    fontWeight: 600,
    fontSize: 12,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
    borderBottomStyle: 'solid',
    padding: 8,
  },
  tableCell: {
    flex: 5,
  },
  taskText: {
    fontSize: 10,
    fontStyle: 'italic',
    fontWeight: 300,
    fontFamily: 'Manrope',
  },
  starIcon: {
    width: 12,
    height: 12,
    objectFit: 'contain',
    borderRadius: 8,
  },
  starIconWrapper: {
    width: 12,
    height: 12,
    borderRadius: 8,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  notesSection: {
    marginTop: 10,
    padding: 8,
  },
  notesHeader: {
    fontWeight: 600,
    fontSize: 12,
    marginBottom: 5,
  },
  notesText: {
    fontSize: 10,
  },
  inlineTextBold: {
    fontWeight: 600,
  },
  listContainer: {
    marginTop: 10,
    marginBottom: 10,
    marginLeft: 40,
  },
  listItem: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  listNumber: {
    width: 20,
    fontWeight: 600,
  },
  listContent: {
    flex: 1,
  },
  listTitle: {
    fontWeight: 600,
  },
  listDescription: {
    marginTop: 3,
  },
  imageWithDescriptionContainer: {
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 15,
    alignItems: 'flex-start',
  },

  imageContainer: {
    marginRight: 15,
    padding: 5,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },

  descriptionContainer: {
    flex: 1,
  },

  descriptionTitle: {
    fontSize: 10,
    fontWeight: 600,
    marginBottom: 5,
    color: '#333',
  },

  descriptionText: {
    fontSize: 10,
    lineHeight: 1.5,
    color: '#555',
  },
  serviceImageContainer: {
    display: 'flex',
    position: 'relative',
  },
  serviceImage: {
    width: '12.89cm',
  },
  serviceImage2: {
    position: 'absolute',
    top: 0,
    right: -65,
    height: '100%',
    width: '6.53cm',
  },
  bold: {
    fontWeight: 600,
  },
  paragraph: {
    marginBottom: 10,
  },
  bulletItem: {
    flexDirection: 'row',
  },
  bullet: {
    marginRight: 5,
  },
  bulletText: {
    flex: 1,
  },
  endPageStyle: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    position: 'relative',
    padding: 0,
    margin: 0,
  },
  endPageBg: {
    position: 'absolute',
    top: -1,
    left: 0,
    right: -2,
    bottom: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  watermark: {
    position: 'absolute',
    fontSize: 30,
    color: 'gray',
    opacity: 0.1,
    transform: 'rotate(-45deg)',
  },
});
