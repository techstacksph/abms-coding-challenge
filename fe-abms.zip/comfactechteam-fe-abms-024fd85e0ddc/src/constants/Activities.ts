/* eslint-disable no-unused-vars */
export enum CallType {
  INBOUND = 'Inbound',
  OUTBOUND = 'Outbound',
  VOICEMAIL = 'Voicemail',
}

export enum CommTypesEnum {
  CALLS = 'Calls',
  EMAIL = 'Email',
  SMS = 'SMS',
  NOTE = 'Note',
}

export const CommTypes = {
  Email: 'email',
  SMS: 'sms',
  Calls: 'calls',
  Note: 'note',
};

// USED IN QUERYING ACTIVITIES OF A MODULE
/*
  EACH KEY OF THIS OBJECT IS THE PROP
  THAT IS PASSED TO ActivitiesList COMPONENT

  THIS SHOULD ALSO BE SYNCED TO THE FIELDS
  IN COMMLOG AND NOTE BE
*/
export const relatedModuleFieldMap = {
  account: 'accountId',
  agreementAndContract: 'agreementAndContractId',
  bill: 'billsId', // Note: communication_logs uses 'billsId', notes uses 'billId'
  businessForSale: 'businessToPurchaseId',
  businessforsale: 'businessToPurchaseId', // Using existing field until backend is updated
  case: 'caseId',
  company: 'companyId',
  creditDebit: 'creditDebitNoteId',
  deal: 'dealId',
  deliveriesAndReturns: 'deliveryAndReturnId',
  employee: 'employeeId',
  event: 'eventId',
  evaluation: 'evaluationId',
  franchiseeAgreement: 'franchiseeAgreementId',
  invoice: 'invoiceId',
  job: 'jobId',
  jobPurchase: 'jobPurchaseId',
  jobPurchaseApplication: 'jobPurchaseId',
  jobSchedule: 'jobScheduleId',
  lead: 'leadId',
  leaveManagement: 'leaveId',
  marketplace: 'marketplaceId',
  module: 'moduleId',
  performanceReview: 'performanceReviewId',
  purchaseOrder: 'purchaseOrderId',
  qualityAudit: 'qualityAuditId',
  recruitment: 'recruitmentId',
  royaltySheet: 'royaltySheetId',
  salesOrder: 'salesOrderId',
  site: 'siteId',
  sms: 'smsId',
  stockControl: 'stockControlId',
  stock_control: 'stockControlId',
  task: 'taskId',
  training: 'trainingId',
};

//USED TO MAP TO ACCESS ROUTE OF A MODULE
export const relatedModuleRouteMap = {
  lead: 'Leads',
  account: 'Account',
  purchaseOrder: 'Purchase Order',
  event: 'Events',
};

export const callTypeIcons = {
  Inbound: {
    name: 'call_received',
    color: '#52D2FC',
  },
  Outbound: {
    name: 'call_made',
    color: 'var(--green-400)',
  },
  Voicemail: {
    name: 'voicemail',
    color: '#7793FF',
  },
};

export const contentFieldNames = {
  Email: 'bodyEmail',
  SMS: 'messageSMS',
  Calls: 'callOutcome',
  Note: 'notes',
};

export enum ActivityLeadNotes {
  EVENT_CREATED = 'Event created',
  EVENT_COMPLETED = 'Event completed',
  EVENT_CANCELLED = 'Event cancelled',
  CALL_LOG_CREATED = 'Call log created',
  TASK_CREATED = 'Task created',
  LEAD_CREATED = 'Lead created',
  LEAD_QUALIFIED = 'Lead qualified',
  LEAD_UNQUALIFIED = 'Lead unqualified',
}

export enum ActivitySiteNotes {
  CLOSED_WON_QUOTE = 'Closed won quote',
  JOB_ALLOCATED = 'Job allocated',
  JOB_COMPLETED = 'Job completed',
  JOB_CANCELLED = 'Job cancelled',
  LEAD_CREATED = 'Lead created',
  LEAD_QUALIFIED = 'Lead qualified',
  LEAD_UNQUALIFIED = 'Lead unqualified',
}
