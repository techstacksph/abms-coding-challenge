import { Routes } from '@/mfe-utilities';

const SettingsRoutes = {
  Users: {
    list: '/settings/users',
    new: '/settings/users/new',
    edit: '/settings/users',
    view: '/settings/users',
  },
  Function: {
    list: Routes?.Functions?.list,
    new: Routes?.Functions?.new,
    edit: Routes?.Functions?.edit,
    view: Routes?.Functions?.view,
  },
  UserRoles: {
    list: '/settings/user-roles',
    new: '/settings/user-roles/new',
    edit: '/settings/user-roles',
    view: '/settings/user-roles',
  },
  CompanySettings: {
    list: Routes?.CompanySettings?.list,
    new: Routes?.CompanySettings?.new,
    edit: Routes?.CompanySettings?.edit,
    view: Routes?.CompanySettings?.view,
  },
  SystemPreferenceSettings: {
    list: Routes?.SystemPreferenceSettings?.list,
    new: Routes?.SystemPreferenceSettings?.new,
    edit: Routes?.SystemPreferenceSettings?.edit,
    view: Routes?.SystemPreferenceSettings?.view,
  },
  EmailSettings: {
    list: Routes?.EmailSettings?.list,
    new: Routes?.EmailSettings?.new,
    edit: Routes?.EmailSettings?.edit,
    view: Routes?.EmailSettings?.view,
  },
  RecycleBin: {
    list: Routes?.RecycleBin?.list,
    new: Routes?.RecycleBin?.new,
    edit: Routes?.RecycleBin?.edit,
    view: Routes?.RecycleBin?.view,
  },
  MicrosoftAccounts: {
    list: Routes?.MicrosoftAccounts?.list,
    new: Routes?.MicrosoftAccounts?.new,
    edit: Routes?.MicrosoftAccounts?.edit,
    view: Routes?.MicrosoftAccounts?.view,
  },
  XeroAccounts: {
    list: Routes?.XeroAccounts?.list,
    new: Routes?.XeroAccounts?.new,
    edit: Routes?.XeroAccounts?.edit,
    view: Routes?.XeroAccounts?.view,
    success: Routes?.XeroAccounts?.success,
  },
  ReviewPeriods: {
    list: Routes?.ReviewPeriods?.list,
    new: Routes?.ReviewPeriods?.new,
    edit: Routes?.ReviewPeriods?.edit,
    view: Routes?.ReviewPeriods?.view,
  },
  DealTemplates: {
    list: Routes?.DealTemplates?.list,
    new: Routes?.DealTemplates?.new,
    edit: Routes?.DealTemplates?.edit,
    view: Routes?.DealTemplates?.view,
  },
  Departments: {
    list: Routes?.Departments?.list,
    new: Routes?.Departments?.new,
    edit: Routes?.Departments?.edit,
    view: Routes?.Departments?.view,
  },
  Tests: {
    list: '/settings/tests',
    new: '/settings/tests/new',
    edit: '/settings/tests',
    view: '/settings/tests',
  },
};

// Helper functions for Settings routes
export const SettingsgetViewRoute = (routeName: string): string => {
  return SettingsRoutes[routeName]?.view || '';
};

export const SettingsgetListRoute = (routeName: string): string => {
  return SettingsRoutes[routeName]?.list || '';
};

export const SettingsgetNewRoute = (routeName: string): string => {
  return SettingsRoutes[routeName]?.new || '';
};

export const SettingsgetEditRoute = (routeName: string): string => {
  return SettingsRoutes[routeName]?.edit || '';
};

export default SettingsRoutes;
