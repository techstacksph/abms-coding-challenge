export type GenericProps = {
  id?: string;
  accountId?: string;
  contactId?: string;
  activityId?: string;
  location?: any;
  query?: any;
  queryUpdate?: any;
  input?: string;
  navigate?: (url: string) => void;
  onSuccess?: (id: string) => void;
  onError?: () => void;
  children?: React.ReactNode;
};
