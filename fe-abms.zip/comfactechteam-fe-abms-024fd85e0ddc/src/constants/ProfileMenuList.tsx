import {
  LockOutlined,
  PersonOutline,
  LogoutOutlined,
} from '@mui/icons-material';
import { logout } from '../services/auth.services';

export default [
  {
    key: 'manageProfile',
    label: 'Manage profile',
    icon: <PersonOutline htmlColor='#7B8B99' />,
    onClick: (navigate: any) => {
      navigate('/settings/manage-profile');
    },
  },
  {
    key: 'changePassword',
    label: 'Change password',
    icon: <LockOutlined htmlColor='#7B8B99' />,
  },
  {
    key: 'logout',
    label: 'Logout',
    onClick: () => logout(),
    icon: <LogoutOutlined htmlColor='#7B8B99' />,
  },
];
