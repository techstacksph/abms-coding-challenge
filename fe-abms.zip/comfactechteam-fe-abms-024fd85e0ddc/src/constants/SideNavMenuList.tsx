import React, { ReactNode } from 'react';

import { GoogleIcon, MaterialIcon } from '@/styled-components';

import { Routes, useProfile } from '@/mfe-utilities';
import { Stack } from '@mui/material';

import { Typography } from 'antd';

import SettingsRoute from './SettingsRoutes';

export interface Menu {
  key: string;
  icon?: string | ReactNode;
  label?: ReactNode;
  route?: string;
  type?: 'group';
  children?: Menu[];
  'data-cy': string;
}

export const SettingsMenuItems = (): Menu[] => {
  const profile = useProfile();
  const role = profile?.userRole?.role;
  return [
    {
      label: 'Admin & Security',
      key: 'admin-security',
      icon: null,
      children: [
        {
          label: 'Users',
          key: 'Users',
          icon: (
            <MaterialIcon
              name='account_circle'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: SettingsRoute.Users.list,
          'data-cy': 'users',
        },
        {
          label: 'Roles',
          key: 'roles',
          icon: (
            <GoogleIcon
              name='settings_account_box'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: SettingsRoute.UserRoles.list,
          'data-cy': 'roles',
        },
        ...(role === 'Administrator'
          ? [
              {
                label: 'Company settings',
                key: 'company_settings',
                icon: (
                  <GoogleIcon
                    name='source_environment'
                    $css='padding-inline: 4px; font-size: 24px;'
                  />
                ),
                route: SettingsRoute?.CompanySettings?.list,
                'data-cy': 'company_settings',
              },
              {
                label: (
                  <Stack>
                    <Typography>System preference</Typography>
                    <Typography>settings</Typography>
                  </Stack>
                ),
                key: 'system_preference_settings',
                icon: (
                  <GoogleIcon
                    name='manufacturing'
                    $css='padding-inline: 4px; font-size: 24px;'
                  />
                ),
                route: SettingsRoute?.SystemPreferenceSettings?.list,
                'data-cy': 'system_preference_settings',
              },
              {
                label: 'Email server settings',
                key: 'email_settings',
                icon: (
                  <GoogleIcon
                    name='local_post_office'
                    $css='padding-inline: 4px; font-size: 24px;'
                  />
                ),
                route: SettingsRoute?.EmailSettings?.list,
                'data-cy': 'email_settings',
              },
            ]
          : []),
        {
          label: 'Recycle bin',
          key: 'recycle_bin',
          icon: (
            <GoogleIcon
              name='recycling'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: SettingsRoute?.['RecycleBin']?.list,
          'data-cy': 'recycle_bin',
        },
      ],
      type: 'group',
      'data-cy': 'admin-security',
    },
    {
      label: 'Organisation Management',
      key: 'organisation-management',
      icon: null,
      children: [
        {
          label: 'Locations',
          key: 'Locations',
          icon: (
            <MaterialIcon
              name='place'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.Locations?.list,
          'data-cy': 'locations',
        },
        {
          label: 'Departments',
          key: 'Departments',
          icon: (
            <MaterialIcon
              name='apartment'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.Departments?.list,
          'data-cy': 'departments',
        },
        {
          label: 'Functions',
          key: 'Functions',
          icon: (
            <MaterialIcon
              name='psychology'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.Functions?.list,
          'data-cy': 'functions',
        },
        {
          label: 'Groups',
          key: 'Groups',
          icon: (
            <MaterialIcon
              name='diversity_3'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.Groups?.list,
          'data-cy': 'groups',
        },
      ],
      type: 'group',
      'data-cy': 'organisation-management',
    },
    {
      label: 'Productivity',
      key: 'productivity',
      icon: null,
      children: [
        {
          label: 'Document types',
          key: 'documentTypes',
          icon: (
            <MaterialIcon
              name='edit_document'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.DocumentTypes?.list,
          'data-cy': 'documentTypes',
        },
        {
          label: 'Event types',
          key: 'eventTypes',
          icon: (
            <MaterialIcon
              name='calendar_today'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Event types']?.list,
          'data-cy': 'eventTypes',
        },
        {
          label: 'Task types',
          key: 'tasktypes',
          icon: (
            <MaterialIcon
              name='task_alt'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['TaskTypes']?.list,
          'data-cy': 'tasktypes',
        },
        {
          label: 'Areas',
          key: 'area',
          icon: (
            <GoogleIcon
              name='circles_ext'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Area']?.list,
          'data-cy': 'area',
        },
        {
          label: 'Microsoft accounts',
          key: 'microsoft_accounts',
          icon: (
            <GoogleIcon
              name='contact_mail'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.['MicrosoftAccounts']?.list,
          'data-cy': 'microsoft_accounts',
        },
      ],
      type: 'group',
      'data-cy': 'productivity',
    },
    {
      label: 'Sales',
      key: 'sales',
      icon: null,
      children: [
        {
          label: 'Price lists',
          key: 'priceLists',
          icon: (
            <GoogleIcon
              name='price_change'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['PriceLists']?.list,
          'data-cy': 'priceLists',
        },
        {
          label: 'Supplier price lists',
          key: 'supplierPriceLists',
          icon: (
            <GoogleIcon
              name='universal_currency_alt'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['SupplierPriceLists']?.list,
          'data-cy': 'supplierPriceLists',
        },
        {
          label: 'Contact types',
          key: 'contactTypes',
          icon: (
            <MaterialIcon
              name='contacts'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Contact types']?.list,
          'data-cy': 'contactTypes',
        },
        {
          label: 'Case types',
          key: 'caseTypes',
          icon: (
            <MaterialIcon
              name='cases'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Case types']?.list,
          'data-cy': 'caseTypes',
        },
        {
          label: 'Industries',
          key: 'industries',
          icon: (
            <MaterialIcon
              name='factory'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Industries']?.list,
          'data-cy': 'industries',
        },
        {
          label: 'Deal types',
          key: 'dealTypes',
          icon: (
            <GoogleIcon
              name='heap_snapshot_multiple'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['DealTypes']?.list,
          'data-cy': 'dealTypes',
        },
        {
          label: 'Sources',
          key: 'sources',
          icon: (
            <MaterialIcon
              name='captive_portal'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Sources']?.list,
          'data-cy': 'sources',
        },
        {
          label: 'Channels',
          key: 'channels',
          icon: (
            <GoogleIcon
              name='network_node'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Channels']?.list,
          'data-cy': 'channels',
        },
        {
          label: 'Premise types',
          key: 'premiseTypes',
          icon: (
            <MaterialIcon
              name='home_work'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['PremiseTypes']?.list,
          'data-cy': 'premiseTypes',
        },
        {
          label: 'Cancellation types',
          key: 'cancellationType',
          icon: (
            <GoogleIcon
              name='cancel_presentation'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['CancellationType']?.list,
          'data-cy': 'cancellationType',
        },
        {
          label: 'Service types',
          key: 'servicetype',
          icon: (
            <GoogleIcon
              name='service_toolbox'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Service Types']?.list,
          'data-cy': 'serviceType',
        },
        {
          label: 'Variants',
          key: 'variants',
          icon: (
            <GoogleIcon
              name='edit_note'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Variants']?.list,
          'data-cy': 'variants',
        },
        {
          label: 'Deal templates',
          key: 'dealTemplates',
          icon: (
            <GoogleIcon
              name='table_edit'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['DealTemplates']?.list || '/settings/deal-templates',
          'data-cy': 'dealTemplates',
        },
      ],
      type: 'group',
      'data-cy': 'sales',
    },
    {
      label: 'Operations',
      key: 'operations',
      icon: null,
      children: [
        {
          label: 'Amendment types',
          key: 'amendment',
          icon: (
            <GoogleIcon
              name='amend'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Amendment Type']?.list,
          'data-cy': 'amendmentType',
        },
        {
          label: 'Breach types',
          key: 'breachTypes',
          icon: (
            <GoogleIcon
              name='gpp_maybe'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['BreachTypes']?.list,
          'data-cy': 'breachTypes',
        },
        {
          label: 'Insurance types',
          key: 'insuranceTypes',
          icon: (
            <GoogleIcon
              name='health_and_safety'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['InsuranceTypes']?.list,
          'data-cy': 'insuranceTypes',
        },
        {
          label: 'Security check types',
          key: 'securityCheckTypes',
          icon: (
            <GoogleIcon
              name='verified_user'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['SecurityCheckType']?.list,
          'data-cy': 'securityCheckTypes',
        },
        {
          label: 'Training programs',
          key: 'trainingPrograms',
          icon: (
            <GoogleIcon
              name='user_attributes'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['TrainingPrograms']?.list,
          'data-cy': 'trainingPrograms',
        },
        {
          label: 'Checklists',
          key: 'checklists',
          icon: (
            <GoogleIcon
              name='checklist'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Checklists']?.list,
          'data-cy': 'Checklists',
        },
        {
          label: 'Questionnaires',
          key: 'questionnaires',
          icon: (
            <GoogleIcon
              name='quiz'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Questionnaire']?.list,
          'data-cy': 'Questionnaires',
        },
      ],
      type: 'group',
      'data-cy': 'operations',
    },
    {
      label: 'Finance',
      key: 'finance',
      icon: null,
      children: [
        {
          label: 'Account codes',
          key: 'accountCode',
          icon: (
            <MaterialIcon
              name='badge'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Account code']?.list,
          'data-cy': 'accountCode',
        },
        {
          label: 'Payment terms',
          key: 'payment terms',
          icon: (
            <GoogleIcon
              name='payments'
              fill={false}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Payment terms']?.list,
          'data-cy': 'paymentTerm',
        },
        {
          label: 'Xero accounts',
          key: 'xero_accounts',
          icon: (
            <MaterialIcon
              name='people_alt'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.['XeroAccounts']?.list,
          'data-cy': 'xero_accounts',
        },
      ],
      type: 'group',
      'data-cy': 'finance',
    },
    {
      label: 'Purchasing & Inventory',
      key: 'purchasing-and-inventory',
      icon: null,
      children: [
        {
          label: 'UOMs',
          key: 'uoms',
          icon: (
            <GoogleIcon
              name='scale'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['UOM']?.list,
          'data-cy': 'uoms',
        },
        {
          label: 'Item categories',
          key: 'itemCategories',
          icon: (
            <GoogleIcon
              name='category'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Item categories']?.list,
          'data-cy': 'itemCategories',
        },
        {
          label: 'Item subcategories',
          key: 'itemSubcategories',
          icon: (
            <GoogleIcon
              name='change_history'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Item subcategories']?.list,
          'data-cy': 'itemSubcategories',
        },
        {
          label: 'Supplier types',
          key: 'supplierTypes',
          icon: (
            <GoogleIcon
              name='conveyor_belt'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Supplier types']?.list,
          'data-cy': 'supplierTypes',
        },
      ],
      type: 'group',
      'data-cy': 'purchasing-and-inventory',
    },
    {
      label: 'HR & Legal',
      key: 'hr-and-legal',
      icon: null,
      children: [
        {
          label: 'Document templates',
          key: 'document-template',
          icon: (
            <MaterialIcon
              name='contextual_token'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes?.DocumentTemplates?.list,
          'data-cy': 'document-template',
        },
        {
          label: 'Positions',
          key: 'positions',
          icon: (
            <GoogleIcon
              name='id_card'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Positions']?.list,
          'data-cy': 'positions',
        },
        {
          label: 'Leave types',
          key: 'leaveTypes',
          icon: (
            <GoogleIcon
              name='free_cancellation'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Leave types']?.list,
          'data-cy': 'leaveTypes',
        },
        {
          label: 'Leave balance',
          key: 'leaveBalance',
          icon: (
            <GoogleIcon
              name='avg_pace'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['Leave balance']?.list,
          'data-cy': 'leaveBalance',
        },
        {
          label: 'Rating scales',
          key: 'ratingScales',
          icon: (
            <GoogleIcon
              name='star'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['RatingScale']?.list,
          'data-cy': 'ratingScales',
        },
        {
          label: 'Review periods',
          key: 'review_periods',
          icon: (
            <GoogleIcon
              name='checkbook'
              fill={true}
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['ReviewPeriods']?.list,
          'data-cy': 'review_periods',
        },
      ],
      type: 'group',
      'data-cy': 'hr-and-legal',
    },
    {
      label: 'BMS settings',
      key: 'bms-settings',
      icon: null,
      children: [
        {
          label: 'Courses',
          key: 'courses',
          icon: (
            <GoogleIcon
              name='bookmark'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Courses?.list,
          'data-cy': 'courses',
        },
        {
          label: 'Manuals',
          key: 'manuals',
          icon: (
            <GoogleIcon
              name='developer_guide'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Manuals?.list,
          'data-cy': 'manuals',
        },
        {
          label: 'Videos',
          key: 'videos',
          icon: (
            <GoogleIcon
              name='animated_images'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Videos?.list,
          'data-cy': 'videos',
        },
        {
          label: 'FAQs',
          key: 'faqs',
          icon: (
            <GoogleIcon
              name='quiz'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Faq?.list,
          'data-cy': 'faqs',
        },
        {
          label: 'Modules',
          key: 'modules',
          icon: (
            <GoogleIcon
              name='contextual_token_add'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Modules?.list,
          'data-cy': 'modules',
        },
        {
          label: 'Tests',
          key: 'tests',
          icon: (
            <GoogleIcon
              name='checklist_rtl'
              $css='padding-inline: 4px; font-size: 24px;'
              fill={true}
            />
          ),
          route: Routes?.Tests?.list,
          'data-cy': 'tests',
        },
      ],
      type: 'group',
      'data-cy': 'bms-settings',
    },
    {
      label: 'Help Center',
      key: 'help-center',
      icon: null,
      children: [
        {
          label: 'Support tickets',
          key: 'supportTickets',
          icon: (
            <MaterialIcon
              name='inbox_text_person'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['SupportTickets']?.list,
          'data-cy': 'supportTickets',
        },
        {
          label: 'Support levels',
          key: 'supportLevels',
          icon: (
            <MaterialIcon
              name='local_activity'
              $css='padding-inline: 4px; font-size: 24px;'
            />
          ),
          route: Routes['SupportLevels']?.list,
          'data-cy': 'supportLevels',
        },
      ],
      type: 'group',
      'data-cy': 'help-center',
    },
  ];
};
