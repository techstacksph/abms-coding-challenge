/* eslint-disable no-unused-vars */
export enum Roles {
  SUPER_ADMIN = 'SUPER ADMIN',
  ADMINISTRATOR = 'ADMINISTRATOR',
  EMPLOYEE = 'EMPLOYEE',
}
