import type { MenuProps } from 'antd';

/* eslint-disable @typescript-eslint/no-unused-vars */
interface SideMenu {
  key: string;
  icon?: string;
  label?: string;
  route?: string;
  type?: 'group';
  children?: SideMenu[];
}

export const items: MenuProps['items'] = [];
