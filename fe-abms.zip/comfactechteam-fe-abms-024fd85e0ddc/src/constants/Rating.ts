/* eslint-disable no-unused-vars */
export enum RECRUITMENT_RATING {
  HOT = 'HOT',
  WARM = 'WARM',
  COLD = 'COLD',
}
