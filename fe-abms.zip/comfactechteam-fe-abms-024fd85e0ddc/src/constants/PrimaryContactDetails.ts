import ContactModel from '@/models/ContactModel';
import { labelSpan } from '@/utils/inputProps.util';

export const primaryContactDetails = (
  title,
  contacts: Array<ContactModel> = [],
  notFoundContent
) => ({
  title: title,
  showDivider: false,
  //showSectionTitle: false,
  // $titleCss: 'display:none; ',
  fields: [
    {
      type: 'select',
      title: 'Primary contact',
      field: 'primaryContactId',
      notFoundContent,
      props: {
        ...labelSpan,
        style: {
          margin: undefined,
        },
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      inputProps: {
        placeholder: 'Select and search',
        showSearch: true,
        options: contacts?.map(d => ({
          value: d.id,
          label: `${d.firstName} ${d.lastName}`,
        })),
        optionFilterProp: 'label',
        tagRender: () => null,
        $css: `
            [class$="select-selection-overflow"]::after {
              content: 'Search and select';
              color: rgb(0 0 0 / 25%);
            }
          `,
      },
    },
  ],
});
