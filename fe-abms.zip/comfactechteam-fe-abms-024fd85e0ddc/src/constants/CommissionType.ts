/* eslint-disable no-unused-vars */
export enum CommissionTypeEnum {
  PERCENTAGE = 'PERCENTAGE',
  FIXED_AMOUNT = 'FIXED_AMOUNT',
  NOT_APPLICABLE = 'NOT_APPLICABLE',
  // Legacy aliases for backward compatibility
  NA = 'NOT_APPLICABLE',
  FIXED = 'FIXED',  
}

export enum GSTTypeEnum {
  NO_TAX = 'NO_TAX',
  TAX_EXCLUSIVE = 'TAX_EXCLUSIVE',
  TAX_INCLUSIVE = 'TAX_INCLUSIVE',
  ZERO_RATED = 'ZERO_RATED',
}
