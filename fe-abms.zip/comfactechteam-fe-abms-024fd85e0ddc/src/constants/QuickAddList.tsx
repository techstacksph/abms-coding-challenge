import { GoogleIcon } from '@/styled-components';

import { getNewRoute } from '@/mfe-utilities';
import {
  GroupOutlined,
  ContactsOutlined,
  QueryStatsOutlined,
} from '@mui/icons-material';
import { navigate } from '@/utils/navigation.utils';

export const QuickAddList = [
  {
    icon: <GroupOutlined />,
    label: 'New Account',
    onClick: () => navigate(getNewRoute('Account')),
    to: getNewRoute('Account'),
  },
  {
    icon: <ContactsOutlined />,
    label: 'New Contact',
    onClick: () => navigate(getNewRoute('Contacts')),
    to: getNewRoute('Contacts'),
  },
  {
    icon: <QueryStatsOutlined />,
    label: 'New Lead',
    onClick: () => navigate(getNewRoute('Leads')),
    to: getNewRoute('Leads'),
  },
  {
    icon: <GoogleIcon name='heap_snapshot_multiple' fill />,
    label: 'New Deal',
    onClick: () => navigate(getNewRoute('Deals')),
    to: getNewRoute('Deals'),
  },
];
