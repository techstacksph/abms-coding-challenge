import { Routes } from '@/mfe-utilities';

const Menus = [
  'Dashboard',
  'Calendar',
  'Accounts',
  {
    name: 'Sales',
    path: '/sales',
  },
  // 'Jobs',
  {
    name: 'Jobs',
    path: '/jobs',
  },
  'Customer Service',
  'Finance',
  'HR & Compliance',
  {
    name: 'Purchasing & Inventory',
    path: '/purchasing&inventory/',
  },
  {
    name: 'Franchisee Management',
    path: '/franchisee-management',
  },
  'Documents',
];

export const NavMenuList = Menus.map(m => {
  const menuName = typeof m === 'string' ? m : m.name;
  const path = (Routes[menuName]?.list ?? `/${menuName.toLowerCase()}`).replace(
    /\s+/g,
    ''
  );

  return {
    label: menuName,
    path: typeof m === 'object' ? m?.path : path,
    key: menuName
      .toLowerCase()
      .replace(/[^\w\s-]/g, '') // Remove special characters except whitespace and hyphens
      .replace(/\s+/g, '-') // Replace whitespace with hyphens
      .replace(/-+/g, '-'),
  };
});
