import { createContext, useContext } from 'react';

import { GET_DEFAULT_COMPANY_SETTINGS } from '../graphql/companySettings';
import useQuery from '../hooks/useQuery';
import CompanySettings from '../models/CompanySettings';

const CompanyContext = createContext(null);

const CompanySettingsProvider = props => {
  const { data: companySettings } = useQuery({
    query: GET_DEFAULT_COMPANY_SETTINGS,
  });

  return (
    <CompanyContext.Provider value={companySettings}>
      {props.children}
    </CompanyContext.Provider>
  );
};

export const useCompanySettings = (): CompanySettings =>
  useContext(CompanyContext);

export default CompanySettingsProvider;
