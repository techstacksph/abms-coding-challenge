import React from 'react';

import { Text, MaterialIcon } from '@/styled-components';
import styled from 'styled-components';

import { Tag, Tooltip } from 'antd';

const StyledTag = styled(Tag)<{ $css?: string }>`
  & {
    padding: 4px 8px;
    border-radius: 8px;
    max-width: 100%;
    background: #fff;
    display: inline-flex;
    align-items: center;
    overflow: hidden;
  }

  &:hover {
    cursor: pointer;
    background: #f4f4f6;
  }

  ${({ $css }) => $css}
`;

const TextWrapper = styled.div`
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  flex: 1;

  & > span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: block;
  }
`;

const LinkTag = ({ data }: { data: string }) => {
  return (
    <Tooltip
      title={data}
      placement='top'
      mouseEnterDelay={0.2}
      overlayInnerStyle={{ whiteSpace: 'normal', wordBreak: 'break-word' }}
    >
      <div
        style={{
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          maxWidth: '100%',
        }}
      >
        <StyledTag
          icon={
            <MaterialIcon
              name='link'
              $css={`
                color: #878B97;
                margin-right: 4px;
                font-size: 16px;
                flex-shrink: 0;
              `}
            />
          }
        >
          <TextWrapper>
            <Text $type='xs' weight='semibold' color='#090A0B'>
              {data}
            </Text>
          </TextWrapper>
        </StyledTag>
      </div>
    </Tooltip>
  );
};

export default LinkTag;
