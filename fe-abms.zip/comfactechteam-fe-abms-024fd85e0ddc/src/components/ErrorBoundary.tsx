import React, { Component, ReactNode, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

import { Container, Text } from '@/styled-components';
import { Box, Button, Stack } from '@mui/material';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: React.ErrorInfo;
}

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
  resetKey?: string | number;
}

// Functional component wrapper for the error fallback UI
const ErrorFallback: React.FC<{
  error?: Error;
  errorInfo?: React.ErrorInfo;
  onReset?: () => void;
}> = ({ error, errorInfo, onReset }) => {
  const navigate = useNavigate();

  const handleGoBack = useCallback(() => {
    navigate(-1);
  }, [navigate]);

  const handleRefresh = useCallback(() => {
    window.location.reload();
  }, []);

  return (
    <Container>
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Stack spacing={3}>
          <Text size={24} weight='bold' color='var(--color-error)'>
            Something went wrong
          </Text>
          <Text size={16} color='var(--color-text-secondary)'>
            An unexpected error occurred. Please try refreshing the page or go
            back to the previous page.
          </Text>
          {error && process.env.NODE_ENV === 'development' && (
            <Box sx={{ textAlign: 'left', maxWidth: '600px', mx: 'auto' }}>
              <Text size={14} weight='bold' color='var(--color-error)'>
                Error Details (Development):
              </Text>
              <Text
                size={12}
                color='var(--color-text-secondary)'
                $css='font-family: monospace; white-space: pre-wrap;'
              >
                {error.toString()}
                {errorInfo?.componentStack}
              </Text>
            </Box>
          )}
          <Stack direction='row' spacing={2} justifyContent='center'>
            <Button
              variant='contained'
              onClick={handleRefresh}
              sx={{ alignSelf: 'center' }}
            >
              Refresh Page
            </Button>
            <Button
              variant='outlined'
              onClick={handleGoBack}
              sx={{ alignSelf: 'center' }}
            >
              Go Back
            </Button>
            {onReset && (
              <Button
                variant='outlined'
                onClick={onReset}
                sx={{ alignSelf: 'center' }}
              >
                Try Again
              </Button>
            )}
          </Stack>
        </Stack>
      </Box>
    </Container>
  );
};

// Functional wrapper component that uses hooks
const ErrorBoundaryWrapper: React.FC<ErrorBoundaryProps> = props => {
  const [resetKey, setResetKey] = useState(0);

  const handleReset = useCallback(() => {
    setResetKey(prev => prev + 1);
  }, []);

  return (
    <ErrorBoundaryClass
      {...props}
      resetKey={props.resetKey ?? resetKey}
      onReset={handleReset}
    />
  );
};

// The actual error boundary class component (required by React)
class ErrorBoundaryClass extends Component<
  ErrorBoundaryProps & { onReset?: () => void },
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps & { onReset?: () => void }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Update state so the next render will show the fallback UI
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log the error to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('ErrorBoundary caught an error:', error, errorInfo);
    }

    // Call the onError callback if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Update state with error info
    this.setState({ error, errorInfo });
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps & { onReset?: () => void }) {
    // Reset error state when resetKey changes
    if (prevProps.resetKey !== this.props.resetKey && this.state.hasError) {
      this.setState({
        hasError: false,
        error: undefined,
        errorInfo: undefined,
      });
    }
  }

  handleReset = () => {
    this.setState({
      hasError: false,
      error: undefined,
      errorInfo: undefined,
    });

    // Call the wrapper's reset function if provided
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  render() {
    if (this.state.hasError) {
      // Custom fallback UI
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default fallback UI
      return (
        <ErrorFallback
          error={this.state.error}
          errorInfo={this.state.errorInfo}
          onReset={this.handleReset}
        />
      );
    }

    return this.props.children;
  }
}

// Export the functional wrapper as the main component
export default ErrorBoundaryWrapper;
