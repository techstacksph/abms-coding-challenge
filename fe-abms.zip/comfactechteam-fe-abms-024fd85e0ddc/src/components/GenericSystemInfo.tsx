import React, { useCallback, useState } from 'react';

import SystemInfoAuditLog from '@/components/SystemInfoAuditLog';
import SystemInfoDetails from '@/components/SystemInfoDetails';
import { Stack } from '@mui/material';
import useGlobalOptions from '@/hooks/useGlobalOptions';
import User from '@/models/User';
import { Spin } from 'antd';
import Module from '@/models/Module';
import { SearchComparator } from '@/typings/module.types';
import { isValueValid } from '@/utils/helper.utils';

type FixedSearchItem = {
  fieldName: string | null;
  searchValue: string | null;
  comparator: string | null;
};

type GenericSystemInfoProps = {
  data: any;
  calledFrom: string;
  createdBy?: any;
  fixedSearch?: FixedSearchItem[];
};

const GenericSystemInfo = ({ data, calledFrom }: GenericSystemInfoProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const { users, usersLoading, modules, modulesLoading } = useGlobalOptions({
    users: true,
    modules: true,
  });

  const findUserById = useCallback(
    id => {
      if (!id) {
        return null;
      }
      return users.find((user: User) => user.id === id);
    },
    [users]
  );
  const findModule = useCallback(() => {
    if (!calledFrom) {
      return null;
    }
    return modules.find((module: Module) => module.code === calledFrom)?.id;
  }, [modules, calledFrom]);

  return (
    <Spin spinning={[isLoading, usersLoading, modulesLoading].includes(true)}>
      <Stack direction='column'>
        <SystemInfoDetails
          data={data}
          findUserById={findUserById}
          calledFrom={calledFrom}
        />

        {/* Audit Logs Section */}
        {data?.id && (
          <SystemInfoAuditLog
            recordId={data.id}
            calledFrom={calledFrom}
            fixedSearch={
              isValueValid(findModule())
                ? [
                    {
                      fieldName: 'moduleId',
                      searchValue: findModule(),
                      comparator: SearchComparator.EQUAL,
                    },
                  ]
                : []
            }
            findUserById={findUserById}
            setIsLoading={setIsLoading}
          />
        )}
      </Stack>
    </Spin>
  );
};

export default GenericSystemInfo;
