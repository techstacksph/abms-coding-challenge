import React from 'react';

import { Text, Icon, GoogleIcon } from '@/styled-components';

import Link from '@/components/Link';
import { Status } from '@/constants/Status';
import { getViewRoute } from '@/mfe-utilities';
import { Box, Stack } from '@mui/material';
import { haveData } from '@/utils/helper.utils';

import StatusTag from './StatusTag';

const ViewAccountCard = ({
  data,
  boxWidth = '100%',
}: {
  data: any;
  boxWidth?: string;
}) => {
  const capitalizeName = name => {
    if (!name || typeof name !== 'string') {
      return '';
    }
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  };

  return (
    <Stack direction='column' gap={2} width={boxWidth}>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: '100%' }}>
          <Stack direction='row' spacing={1}>
            {data ? (
              <>
                <Stack>
                  <Icon size='28px' color='var(--gray-400)'>
                    <GoogleIcon
                      name='source_environment'
                      fill={true}
                      $css={`
                      padding: 8px;
                      font-size: 28px !important;
                      background-color: #F4F4F6;
                      border-radius: 50%;
                    `}
                    />
                  </Icon>
                </Stack>
                <Stack
                  direction='column'
                  spacing='4px'
                  gap={0.5}
                  sx={{ width: '100%' }}
                >
                  <Link
                    ellipsis
                    to={`${getViewRoute('Account')}/${data?.id}`}
                    weight='medium'
                  >
                    {data?.name}
                  </Link>

                  <Text $type='sm' $css={'font-size: 14px; font-weight: 400;'}>
                    {capitalizeName(haveData(data?.accountType))}
                  </Text>
                  <Stack gap={0.5} direction='row'>
                    <Text color='#686D78'>Account status: </Text>
                    <StatusTag
                      status={Status[data?.status?.toUpperCase()]}
                      $css={'border:none;'}
                    />
                  </Stack>
                </Stack>
              </>
            ) : (
              <Stack direction='row' alignItems='center'>
                <Text color='var(--table-no-data)'>No data</Text>
              </Stack>
            )}
          </Stack>
        </Box>
      </Stack>
    </Stack>
  );
};

export default ViewAccountCard;
