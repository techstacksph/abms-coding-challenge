import React, { memo } from 'react';

import { MaterialIcon, Icon } from '@/styled-components';

import Link from './Link';

const LinkQuickCreate = ({ to }: { to: string }) => {
  return (
    <Link
      to={to}
      $css={`
        & > a {
          color: rgba(49, 55, 253, 1);
          background-color: #FFFFFF;
          width: 40px;
          height: 40px;
          border: 1px solid rgba(49, 55, 253, 1);
          padding: 8px;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 8px;
          margin-top: 12px;
          margin-left: 15px;

          &:hover {
            background-color: var(--gray-100);
          }
        }
      `}
    >
      <Icon $css='rotate: -90deg;'>
        <MaterialIcon iconClass='material-icons' name='add' />
      </Icon>
    </Link>
  );
};

export default memo(LinkQuickCreate);
