import React from 'react';

import { Text, Icon, Site } from '@/styled-components';

import Link from '@/components/Link';
import { getViewRoute } from '@/mfe-utilities';
import SitesModel from '@/models/SitesModel';
import { Box, Stack } from '@mui/material';
import { haveData } from '@/utils/helper.utils';
import { LastActivityText } from './LastActivity';

const ViewSiteCard = ({
  data,
  boxWidth = '100%',
  disableLink = false,
}: {
  data: SitesModel;
  boxWidth?: string;
  disableLink?: boolean;
}) => {
  return (
    <Stack direction='column' gap={2} width={boxWidth}>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: '100%' }}>
          <Stack direction='row' spacing={1}>
            {data ? (
              <>
                <Stack>
                  <Icon size='28px' color='var(--gray-400)'>
                    <Site />
                  </Icon>
                </Stack>
                <Stack
                  direction='column'
                  spacing='4px'
                  gap={0.5}
                  sx={{ width: '100%' }}
                >
                  {!disableLink ? (
                    <Link
                      ellipsis
                      to={`${getViewRoute('Account')}/${data?.accountId}/sites/${data?.id}`}
                      weight='medium'
                    >
                      {data?.siteName}
                    </Link>
                  ) : (
                    <Text $css='font-size: 14px; font-weight: 700; line-height: 20px; color: #090A0B;'>
                      {data?.siteName}
                    </Text>
                  )}
                  <Text
                    $type='sm'
                    $css={'font-size: 14px; font-weight: 400;'}
                    color='#686D78'
                  >
                    {data?.address
                      ? haveData(data.address)
                      : haveData(data?.fullAddress)}
                  </Text>
                  <LastActivityText
                    accountId={data?.accountId}
                    siteId={data?.id}
                    staticData={{
                      lastActivity: data?.lastActivity,
                      activityDate: data?.updatedAt ?? data?.createdAt,
                    }}
                  />
                  {/* <Text color='#686D78'>
                    Last activity:{' '}
                    <Text color='#3137FD'>
                      {data?.lastActivity ? (
                        <Link
                          to={`${getViewRoute('Account')}/${data?.accountId}/sites/${data?.id}`}
                          $css='color: #3137FD;'
                        >
                          {`${data?.lastActivity} ${dayjs(
                            data?.updatedAt ?? data?.createdAt
                          ).format(dateFormat)}`}
                        </Link>
                      ) : (
                        haveData(data?.lastActivity)
                      )}
                    </Text>
                  </Text> */}
                </Stack>
              </>
            ) : (
              <Stack direction='row' alignItems='center'>
                <Text color='var(--table-no-data)'>No data</Text>
              </Stack>
            )}
          </Stack>
        </Box>
      </Stack>
    </Stack>
  );
};

export default ViewSiteCard;
