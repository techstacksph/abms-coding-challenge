import React from 'react';
import { Outlet } from 'react-router-dom';
import TrailingSlashRedirect from './TrailingSlashRedirect';
import { ScrollToTop } from './ScrollToTop';

/**
 * Wrapper component that includes the TrailingSlashRedirect component
 * This ensures the redirect component is rendered within the Router context
 */
const RouterWrapper: React.FC = () => {
  return (
    <>
      <ScrollToTop />
      <TrailingSlashRedirect />
      <Outlet />
    </>
  );
};

export default RouterWrapper;
