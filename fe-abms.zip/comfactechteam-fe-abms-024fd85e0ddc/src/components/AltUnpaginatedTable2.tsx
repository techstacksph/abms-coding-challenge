import React, { useMemo, useState } from 'react';

import {
  ModuleTable,
  Button,
  Text,
  MaterialIcon,
  EmptyState,
} from '@/styled-components';

import { Stack } from '@mui/material';

import { Checkbox, Form } from 'antd';

import ActionButton from '../views/settings/common/components/ActionButton';
import CellForm from '../views/settings/common/components/CellForm';
import ModuleAlert, { ModuleRowSelection } from './ModuleAlert';
import { toSentenceCase } from '@/utils/string.utils';

export type SelectAllMenuTypes = 'all' | 'deselect';

const actionColumn = ({
  isRowEditing,
  onCancel,
  onEdit,
  onDelete,
  saveRecord,
}: {
  isRowEditing: (record: any) => boolean;
  onCancel: (record: any) => void;
  onEdit: (record: any) => void;
  onDelete: (record: any) => void;
  saveRecord: (record: any) => void;
}) => {
  return {
    title: '',
    dataIndex: 'actions',
    key: 'actions',
    width: 110,
    fixed: 'right',
    render: (_, record) => (
      <ActionButton
        isEditing={isRowEditing(record)}
        disabled={false}
        onCancel={() => onCancel(record)}
        submitType='button'
        onSubmit={() => saveRecord(record)}
        actions={[
          {
            key: 'edit',
            label: (
              <a
                onClick={() => {
                  onEdit(record);
                }}
              >
                <Stack direction='row' alignItems='center' spacing={1}>
                  <MaterialIcon
                    name='edit'
                    $css='font-weight: 400; font-size: 24px; color: #878B97'
                  />
                  <Text>Edit</Text>
                </Stack>
              </a>
            ),
          },
          {
            key: 'delete',
            label: (
              <a onClick={() => onDelete(record)}>
                <Stack direction='row' alignItems='center' spacing={1}>
                  <MaterialIcon
                    name='delete'
                    $css='font-weight: 400; font-size: 24px; color: #878B97'
                  />
                  <Text>Delete</Text>
                </Stack>
              </a>
            ),
          },
        ]}
      />
    ),
  };
};

const AltUnpaginatedTable2 = ({
  columns,
  fields,
  title,
  allData = [],
  setAllData,
  loading = false,
  form,
  setDeleteData,
  setterField,
  otherProps,
  fileName,
  buttonAlignment = 'left',
  tablePrefix = 'new',
}: {
  columns: Array<any>;
  fields: any;
  title: { plural: string; singular: string };
  allData?: Array<any>;
  loading: boolean;
  form: any;
  setAllData: React.Dispatch<React.SetStateAction<any>>;
  setDeleteData?: React.Dispatch<React.SetStateAction<any>>;
  setterField?: string;
  otherProps?: any;
  fileName?: string;
  buttonAlignment?: 'left' | 'center' | 'right';
  tablePrefix?: string;
}) => {
  const [selected, setSelectedInner] = useState<ModuleRowSelection<any>>({
    selected: [],
  });
  const [addingIds, setAddingIds] = useState<Array<string>>([]);
  const [editingIds, setEditingIds] = useState<Array<string>>([]);
  const [, setActiveButton] = useState<string>();
  const [tableIdx, setTableIdx] = useState<number>(1);

  const [selectionRenderKey, setSelectionRenderKey] = useState<number>(
    Math.random()
  );

  const selectedRendered = useMemo(() => {
    return selected;
  }, [selectionRenderKey]);

  const storeRecord = async (recordId?: string) => {
    const currentId = recordId;
    try {
      // Validate only the fields managed by this table row
      if (currentId) {
        const fieldNames = Object.keys(fields).map(k => [currentId, k]);
        await form.validateFields(fieldNames as any);
      } else {
        await form.validateFields(Object.keys(fields));
      }
    } catch {
      return;
    }

    const rowValues = currentId
      ? form.getFieldsValue([currentId])?.[currentId] || {}
      : form.getFieldsValue(Object.keys(fields));

    setAllData(prevData => {
      const fieldData = Object.assign([], prevData);
      const idx = fieldData.findIndex(a => a.id == currentId);

      if (idx > -1) {
        const updateFieldData = {
          id: currentId,
          ...rowValues,
        };

        fieldData[idx] = { ...fieldData[idx], ...updateFieldData };
      } else {
        const updateFieldData = {
          id: currentId,
          ...rowValues,
        };

        fieldData.push(updateFieldData);
      }

      return fieldData;
    });

    setAddingIds(prev => prev.filter(id => id !== currentId));
    setEditingIds(prev => prev.filter(id => id !== currentId));

    if (setterField && currentId && addingIds.includes(currentId)) {
      form.setFieldValue(setterField, null);
    }
  };

  const editRecord = record => {
    // Scope form values by row id to support multiple concurrent edit rows
    form.setFieldsValue({ [record.id]: record });
    if (otherProps && otherProps.setter)
      otherProps.setter(form.getFieldValue(setterField));
    setEditingIds(prev =>
      prev.includes(record.id) ? prev : [...prev, record.id]
    );
  };

  const setSelected = (
    value: React.SetStateAction<ModuleRowSelection<any>>
  ) => {
    setSelectedInner(value);
    setSelectionRenderKey(Math.random());
  };

  const setSelectedNoRerender = (
    value: React.SetStateAction<ModuleRowSelection<any>>
  ) => {
    setSelectedInner(value);
  };

  const onAdd = () => {
    //const length = [...allData].length;
    const newId = `${tablePrefix}-${tableIdx}`;
    const newData = {
      id: newId,
    };
    // Already using functional setState - this is correct
    setAllData(prevState => [...prevState, newData]);

    // Initialize scoped form values only for the new row
    form.setFieldsValue({ [newId]: newData });
    setEditingIds(prev => [...prev, newId]);
    setAddingIds(prev => [...prev, newId]);

    setTableIdx(Number(tableIdx) + 1);

    if (otherProps && otherProps.setter) otherProps.setter(null);
  };

  const onClickDelete = async () => {
    const ids = selected.selected.map(a => a.id);
    const toDeleteIds = ids.filter(
      a => !String(a).startsWith(tablePrefix + '-')
    );

    setDeleteData(prevState => [...prevState, ...toDeleteIds]);

    setAllData(prevData => {
      const fieldData = Object.assign([], prevData);
      for (const id of ids) {
        const idx = fieldData.findIndex(a => a.id == id);
        if (idx > -1) {
          fieldData.splice(idx, 1);
        }
      }
      return fieldData;
    });

    setSelected({ selected: [], type: 'multiple' });
  };

  const onCancel = async (recordId?: string) => {
    const currentId = recordId;
    setActiveButton('cancel');

    if (currentId && addingIds.includes(currentId)) {
      setAllData(prevState => prevState.filter(a => a.id !== currentId));
      setAddingIds(prev => prev.filter(id => id !== currentId));
    }
    if (currentId) {
      const fieldNames = Object.keys(fields).map(k => [currentId, k]);
      form.resetFields(fieldNames as any);
      setEditingIds(prev => prev.filter(id => id !== currentId));
    } else {
      // Fallback: clear all editing states
      setEditingIds([]);
      setAddingIds([]);
    }
  };

  const tableColumns = useMemo(() => {
    const actionCol = actionColumn({
      isRowEditing: record => editingIds.includes(record.id),
      onCancel: record => onCancel(record.id),
      onEdit: record => {
        editRecord(record);
      },
      onDelete: record =>
        setSelectedNoRerender({ selected: [record], type: 'single' }),
      saveRecord: record => {
        storeRecord(record.id);
      },
    });
    const tableCol = [...columns];
    tableCol.push(actionCol);

    return tableCol.map(c => {
      if (!fields[c.dataIndex]) return c;

      const style = c?.meta ? c.meta?.onCellStyle : {};

      return {
        ...c,
        onCell: record => ({
          key: record.id,
          formProps: {
            ...fields[c.dataIndex],
            // Scope form field by row id to avoid collisions
            field: [record.id, fields[c.dataIndex]?.field || c.dataIndex],
          },
          otherProps,
          fileName,
          isEditing: editingIds.includes(record.id),
          style: {
            ...style,
            textAlign: fields[c.dataIndex].type === 'number' ? 'right' : 'left',
          },
        }),
      };
    });
  }, [editingIds.join(','), addingIds.join(',')]);

  // Map buttonAlignment to justifyContent value
  const getJustifyContent = alignment => {
    switch (alignment) {
      case 'center':
        return 'center';
      case 'right':
        return 'flex-end';
      case 'left':
      default:
        return 'flex-start';
    }
  };

  return (
    <Form form={form} component={false}>
      <ModuleTable
        width='100px'
        columns={tableColumns}
        data={allData}
        emptyState={<EmptyState iconW='200px' title='No data to display.' />}
        loading={loading}
        rowSelection={{
          columnWidth: 40,
          onChange: (_, selected) =>
            setSelected({ selected, type: 'multiple' }),
          renderCell: (checked, record, index, originNode) => {
            return (
              <Checkbox
                {...originNode.props}
                disabled={editingIds.includes(record.id)}
              />
            );
          },
          selectedRowKeys: selectedRendered.selected.map(d => d.id),
          columnTitle: originNode => (
            <Checkbox
              {...originNode.props}
              onChange={e => {
                setSelected({
                  selected: e.target.checked ? allData : [],
                  type: 'multiple',
                });
              }}
              indeterminate={
                selectedRendered.selected.length > 0 &&
                selectedRendered.selected.length != allData.length
              }
              checked={
                selectedRendered.selected.length > 0 &&
                selectedRendered.selected.length === allData.length
              }
              disabled={editingIds.length > 0}
            />
          ),
        }}
        tableProps={{
          tableLayout: 'fixed',
          components: {
            body: {
              cell: CellForm,
            },
          },
          // summary: () => (
          //   <tr style={{ display: 'initial' }}>
          //     <td colSpan={columns.length}>

          //     </td>
          //   </tr>
          // ),
        }}
        hidePagination
      />
      <Stack
        padding='8px 0px'
        borderBottom='1px solid #D3D5D9'
        width='100%'
        direction='row'
        justifyContent={getJustifyContent(buttonAlignment)}
      >
        <Button
          type='text'
          icon={<MaterialIcon name='add' $css='color: #3137FD !important;' />}
          onClick={onAdd}
          $css='border-radius: 8px; padding: 8px 12px; color: #3137FD;border: 1px solid #3137FD; min-width: 120px;'
        >
          <Text
            $css='font-size: 14px; font-weight: 600;'
            weight='semibold'
            color='#3137FD'
          >
            {toSentenceCase(title.singular)}
          </Text>
        </Button>
      </Stack>
      <ModuleAlert
        loading={false}
        selected={selected}
        message={
          selected.type === 'single' ? (
            <Text>
              Are you sure you want to move{' '}
              {selected.selected?.[0]?.title || title.singular.toLowerCase()} to
              the recycle bin?
            </Text>
          ) : (
            <Text>
              Are you sure you want to move all selected action plan(s) to the
              recycle bin?
            </Text>
          )
        }
        title={
          selected.type === 'single'
            ? title.singular.toLowerCase()
            : title.plural.toLowerCase()
        }
        onDelete={async () => await onClickDelete()}
        onClose={() => setSelected({ selected: [], type: 'multiple' })}
        onExport={undefined}
      />
    </Form>
  );
};

export default AltUnpaginatedTable2;
