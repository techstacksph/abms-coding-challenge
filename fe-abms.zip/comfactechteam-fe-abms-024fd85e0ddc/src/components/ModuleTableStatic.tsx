import React, { useEffect, useState, useRef } from 'react';

import {
  ModuleTable as Table,
  Checkbox,
  Icon,
  Text,
  Select,
  EmptyState,
  MaterialIcon,
} from '@/styled-components';

import { Stack } from '@mui/material';
import { ModuleTableProps } from '@/typings/modulTable.types';

import { Dropdown } from 'antd';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

const RowsPerPage = ({ total, range, setPageSize, pageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        defaultValue={pageSize}
        options={[
          { label: '10', value: 10 },
          { label: '20', value: 20 },
          { label: '50', value: 50 },
          { label: '100', value: 100 },
        ]}
        onChange={val => setPageSize(val)}
        suffixIcon={
          <MaterialIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
          &[class*="-select-focused"] [class*="-select-selector"] {
            box-shadow: none;
          }
          [class$="select-selection-item"] {
            color: var(--color-text-primary) !important;
            font-size: 12px;
            padding-inline-end: 24px !important;
          }
          [class$="select-selector"] {
            gap: 4px;
            padding: 0 4px;
            border-width: 0 !important;
          }
        `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};

const ModuleTableStatic = ({
  columns,
  data,
  onChangeSelected,
  rowSelection,
  loading = false,
  onTableChange = undefined,
  otherTableProps = {},
  hidePagination = false,
}: ModuleTableProps) => {
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();
  const [selected, setSelected] = useState<any[]>([]);
  const [pageSize, setPageSize] = useState<number>(10);
  const currentPageData = useRef<any[]>([]);

  useEffect(() => {
    onSelectType('deselect');
    if (onChangeSelected) {
      onChangeSelected([], selectType);
    }
  }, []);

  // Handle row selection behavior
  const onSelectType = (type: SelectAllMenuTypes) => {
    setSelectType(type);
    let selectId = [];

    if (type === 'this') {
      selectId = currentPageData.current?.map(d => d.id);
      if (onChangeSelected) {
        onChangeSelected(currentPageData.current, type);
      }
    } else if (type === 'all') {
      selectId = data ? data?.map(v => v.id) : [];
      if (onChangeSelected) {
        onChangeSelected(data ?? [], type);
      }
    } else if (type === 'deselect') {
      if (onChangeSelected) {
        onChangeSelected([], type);
      }
    }

    setSelected(selectId);
  };

  const customRowSelection = {
    preserveSelectedRowKeys: true,
    columnWidth: 68,
    columnTitle: () => {
      if (rowSelection?.type === 'radio') return;

      return (
        <Dropdown
          menu={{
            items: [
              {
                key: 'thisPage',
                label: 'Select this page',
                onClick: () => onSelectType('this'),
              },
              {
                key: 'allPage',
                label: 'Select all page',
                onClick: () => onSelectType('all'),
              },
              {
                key: 'deselectAll',
                label: 'Deselect all',
                onClick: () => onSelectType('deselect'),
              },
            ],
          }}
          trigger={['click']}
        >
          <a role='button'>
            <Stack direction='row' alignItems='center' spacing={0.5}>
              <Checkbox
                checked={Boolean(selectType) && selectType != 'deselect'}
                $css={`
                  min-width: 24px !important;
                  height: 24px;
                  justify-content: center;  
                `}
              />
              <Icon color='var(--gray-600)'>
                <MaterialIcon name='arrow_drop_down' />
              </Icon>
            </Stack>
          </a>
        </Dropdown>
      );
    },
    selectedRowKeys: selected,
    onChange: keys => {
      setSelected(keys);
      if (onChangeSelected) {
        const cleanRows = data.filter(r => keys.includes(r.id));
        onChangeSelected(cleanRows, selectType);
      }
    },
  };

  return (
    <Table
      columns={columns}
      data={data}
      paginationText={'Rows per page'}
      showPaginationItems={false}
      onSelectAllMenu={type => setSelectType(type)}
      loading={loading}
      rowSelection={rowSelection?.type !== 'none' && customRowSelection}
      hidePagination={hidePagination}
      onChange={onTableChange}
      tableProps={{
        footer: currentPage => {
          currentPageData.current = currentPage;
          return;
        },
        pagination: {
          total: data.length,
          showSizeChanger: false,
          position: ['bottom', 'left'],
          pageSize: pageSize,
          defaultPageSize: 10,
          showTotal: (total, range) => (
            <RowsPerPage
              total={total}
              range={range}
              setPageSize={setPageSize}
              pageSize={pageSize}
            />
          ),
          itemRender: (_, type, originalElement) =>
            type === 'page' ? null : originalElement,
        },
        tableLayout: 'fixed',
        ...otherTableProps,
      }}
      emptyState={<EmptyState iconW='200px' title='No data to display.' />}
      {...otherTableProps}
    />
  );
};

export default ModuleTableStatic;
