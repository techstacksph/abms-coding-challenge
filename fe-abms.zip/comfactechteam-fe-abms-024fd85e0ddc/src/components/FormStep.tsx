import React from 'react';

import { Text } from '@/styled-components';

import { Box, Stack } from '@mui/material';

const FormStep = ({ number, label }: { number: number; label?: string }) => {
  return (
    <Stack direction='row' spacing={1}>
      <Box
        width='24px'
        height='24px'
        alignItems='center'
        justifyContent='center'
        borderRadius='50%'
        bgcolor='#F9B83A'
        color='#fff'
        display='flex'
      >
        {number}
      </Box>
      <Text $type='md' weight='bold'>
        {label}
      </Text>
    </Stack>
  );
};

export default FormStep;
