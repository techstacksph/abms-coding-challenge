import React from 'react';

import { Icon, Text } from '@/styled-components';

import Link from '@/components/Link';
import { getViewRoute } from '@/mfe-utilities';
import SitesModel from '@/models/SitesModel';
import { PinDropOutlined } from '@mui/icons-material';
import CloseIcon from '@mui/icons-material/Close';
import { Stack, Box } from '@mui/material';
import { haveData, isValueValid } from '@/utils/helper.utils';

import { FormInstance } from 'antd';
import dayjs from 'dayjs';
import { dateFormat } from '@/utils/date.utils';
import SiteLeadLastActivity from '@/views/accounts/accounts/view/tabs/sites/view/tabs/SiteInfo/SiteLeadLastActivity';

const SiteCard = ({
  record,
  form,
  fieldName,
  onEmpty = 'No selected site.',
  boxWidth = '55%',
  lastActivity,
  activityDate,
  selectedSiteId,
}: {
  record: Array<SitesModel>;
  form: FormInstance;
  fieldName: string;
  onEmpty?: string;
  boxWidth?: string;
  addressField?: string;
  lastActivity?: string;
  activityDate?: any;
  selectedSiteId?: string;
}) => {
  if (!form) {
    boxWidth = '100%';
  }
  const data: SitesModel | null = record.length > 0 ? record[0] : null;

  return (
    <>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: boxWidth }}>
          <Stack direction='row' spacing={1}>
            {record.length > 0 ? (
              <Stack
                direction={'row'}
                gap='4px'
                padding={1}
                width='100%'
                sx={{
                  ':hover': {
                    borderRadius: '8px',
                    backgroundColor: form ? '#F4F4F6' : 'transparent',
                  },
                }}
              >
                <Icon
                  size='56px'
                  color='var(--gray-400)'
                  $css={`
                      padding: 8px;
                      font-size: 44px !important; 
                      background-color: #F4F4F6;
                      border-radius: 50%;
                    `}
                >
                  <PinDropOutlined />
                </Icon>
                <Stack
                  direction='column'
                  spacing={'4px'}
                  sx={{ width: '100%' }}
                >
                  <Link
                    ellipsis
                    to={`${getViewRoute('Account')}/${data?.accountId}/sites/${data?.id}`}
                    weight='bold'
                    $css={{
                      maxWidth: '240px !important',
                      wordWrap: 'break-word',
                    }}
                  >
                    {data?.siteName}
                  </Link>
                  <Text
                    $type='sm'
                    $css={'font-size: 14px; font-weight: 400; color:#686D78'}
                  >
                    {haveData(data?.address || data?.fullAddress)}
                  </Text>
                  <SiteLeadLastActivity
                    siteId={selectedSiteId} />
                  {/* <Text
                    $type='sm'
                    $css={
                      'font-size: 14px; font-weight: 400; margin-left: 10px; color:#686D78'
                    }
                  >
                    Last activity:{' '}
                    {data?.lastActivity ? (
                      <Link to=''>
                        {`${data?.lastActivity} ${dayjs(
                          data?.updatedAt ?? data?.createdAt
                        ).format(dateFormat)}`}
                      </Link>
                    ) : (
                      haveData(data?.lastActivity)
                    )}
                  </Text> */}
                </Stack>
                {form && (
                  <CloseIcon
                    className='userRemove'
                    onClick={() => {
                      form.setFieldValue(fieldName, null);
                    }}
                    sx={{ color: '#878B97', width: '20px', height: '20px' }}
                  />
                )}
              </Stack>
            ) : (
              <Text
                style={{
                  textAlign: 'center',
                  width: '100%',
                  padding: '16px',
                  color: '#686D78',
                }}
              >
                {onEmpty}
              </Text>
            )}
          </Stack>
        </Box>
      </Stack>
    </>
  );
};

export default SiteCard;
