import React from 'react';

import styled from 'styled-components';

export const StyledMenu = styled.div`
  li {
    height: 40px;
    padding: 0px !important;
  }
`;

export const StyledMenuLink = styled.div`
  li {
    padding: 0px !important;
  }

  li span a[href] {
    display: block;
    width: 100%;
    padding: 9px 12px;
  }
`;

export const dropdownMenuRender = menu => <StyledMenu>{menu}</StyledMenu>;

export const dropdownLinkRender = menu => (
  <StyledMenuLink>{menu}</StyledMenuLink>
);
