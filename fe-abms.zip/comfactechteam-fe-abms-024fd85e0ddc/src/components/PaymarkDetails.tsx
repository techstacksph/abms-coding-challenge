import { Text, Link, Icon } from '@/styled-components';

import {
  AccountBalanceWalletOutlined,
  CheckCircle,
  LinkOffOutlined,
} from '@mui/icons-material';
import { Avatar, Box, Stack } from '@mui/material';

interface PaymarkDetailsProps {
  accountName?: string;
  accountId?: string;
  paymarkUrl?: string;
  unlinkable?: boolean;
  connectable?: boolean;
  noConnect?: boolean;
  onUnlink?: () => void;
}

const PaymarkDetails = ({
  accountName,
  accountId,
  paymarkUrl,
  unlinkable,
  connectable,
  noConnect,
  onUnlink,
}: PaymarkDetailsProps) => {
  return (
    <Stack
      border='1px solid var(--gray-100)'
      px={connectable ? 1 : 2.5}
      py={connectable ? 2.75 : 2.5}
      direction='row'
      justifyContent='space-between'
      alignItems='center'
      borderRadius={2}
      height={connectable ? '100%' : undefined}
    >
      {connectable ? (
        <Stack
          display='flex'
          alignItems='center'
          justifyContent='center'
          direction='row'
          spacing={0.5}
          m='auto'
        >
          {noConnect ? (
            <Text color='var(--color-text-secondary)'>
              No connected account
            </Text>
          ) : (
            <>
              <Text color='var(--color-text-secondary)'>Click </Text>
              <Text color='var(--color-text-primary)'>Connect Paymark</Text>
              <Text color='var(--color-text-secondary)'>
                to link your account
              </Text>
            </>
          )}
        </Stack>
      ) : (
        <>
          <Stack direction='row' spacing={1.5}>
            <Avatar sx={{ color: '#4C4F57', backgroundColor: '#E9EAEC' }}>
              <AccountBalanceWalletOutlined />
            </Avatar>
            <Stack spacing={0.5}>
              <Text $type='sm' weight='semibold'>
                {accountName}
              </Text>
              <Text $type='xs' color='var(--color-text-secondary)'>
                AccountID {accountId}
              </Text>
              <Text $type='xs' color='var(--color-text-secondary)'>
                {paymarkUrl}
              </Text>
              {unlinkable && (
                <Link onClick={() => onUnlink()}>
                  <Stack
                    direction='row'
                    alignItems='center'
                    spacing={0.25}
                    sx={{ cursor: 'pointer' }}
                  >
                    <LinkOffOutlined />
                    <Text color='inherit'>Unlink account</Text>
                  </Stack>
                </Link>
              )}
            </Stack>
          </Stack>
          <Box>
            <Icon color='var(--green-400)'>
              <CheckCircle />
            </Icon>
          </Box>
        </>
      )}
    </Stack>
  );
};

export default PaymarkDetails;
