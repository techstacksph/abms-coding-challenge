import React from 'react';

import { MaterialIcon, Icon, Text, GoogleIcon } from '@/styled-components';

import CloseIcon from '@mui/icons-material/Close';
import { Stack, Box } from '@mui/material';

import { FormInstance } from 'antd';

const UserCard = ({
  user,
  form,
  fieldName,
  onEmpty = 'No selected user.',
  boxWidth = '55%',
  stackStyleHover = {},
}: {
  user: Array<any>;
  form: FormInstance;
  fieldName: string;
  onEmpty?: string;
  boxWidth?: string;
  stackStyleHover?: any;
}) => {
  return (
    <>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: boxWidth }}>
          <Stack direction='row' spacing={1}>
            {user.length > 0 ? (
              <Stack
                direction={'row'}
                gap='4px'
                padding={1}
                width='100%'
                sx={{
                  ':hover': {
                    borderRadius: '8px',
                    backgroundColor: '#F4F4F6',
                    ...stackStyleHover,
                  },
                }}
                alignItems={'center'}
              >
                <Icon size='28px' color='var(--gray-400)'>
                  <GoogleIcon
                    name='person'
                    fill={true}
                    $css={`
                      padding: 8px;
                      font-size: 28px !important; 
                      background-color: #F4F4F6;
                      border-radius: 50%;
                    `}
                  />
                </Icon>
                <Stack
                  direction='column'
                  spacing={'4px'}
                  sx={{ width: '100%' }}
                >
                  <Text $type='sm' $css={'font-size: 14px; font-weight: 700;'}>
                    {user[0].firstName} {user[0].lastName}
                  </Text>
                  {user[0]?.jobTitle && (
                    <Text
                      $type='sm'
                      $css={'font-size: 14px; font-weight: 400;'}
                    >
                      {user[0]?.jobTitle}
                    </Text>
                  )}
                  {user[0]?.email && (
                    <Text
                      $type='sm'
                      $css={
                        'font-size: 14px; font-weight: 400; margin-left: 10px;'
                      }
                      ellipsis
                    >
                      <MaterialIcon
                        iconClass='material-icons'
                        name='mail'
                        $css='color: rgba(135, 139, 151, 1); font-size: 15px;'
                      />
                      {user[0]?.email}
                    </Text>
                  )}
                </Stack>
                <CloseIcon
                  className='userRemove'
                  onClick={() => {
                    form.setFieldValue(fieldName, null);
                  }}
                  sx={{
                    color: '#878B97',
                    width: '20px',
                    height: '20px',
                    cursor: 'pointer',
                  }}
                />
              </Stack>
            ) : (
              <Text
                style={{
                  textAlign: 'center',
                  width: '100%',
                  padding: '16px',
                  color: '#686D78',
                }}
              >
                {onEmpty}
              </Text>
            )}
          </Stack>
        </Box>
      </Stack>
    </>
  );
};

export default UserCard;
