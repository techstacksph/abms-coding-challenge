import React from 'react';

import { Text } from '@/styled-components';

import { Stack, Box, StackProps } from '@mui/material';

import { Spin } from 'antd';

const FormCardTab = ({
  title,
  loading = false,
  containerProps,
  children,
}: {
  title: string;
  loading?: boolean;
  containerProps?: StackProps;
  children: React.ReactNode;
}) => {
  return (
    <Box sx={{ width: '100%' }}>
      <Spin spinning={loading}>
        <Stack {...containerProps}>
          <Box borderBottom='1px solid var(--gray-200)' pb={1.5}>
            <Text $type='lg' weight='semibold'>
              {title}
            </Text>
          </Box>
          {children}
        </Stack>
      </Spin>
    </Box>
  );
};

export default FormCardTab;
