import { memo } from 'react';

import { Text } from '@/styled-components';

import useNavigate from '@/hooks/useNavigate';
import { Box, Stack } from '@mui/material';

interface data {
  name: string;
  id: string;
}

interface ChildModule {
  relatesTo: data[];
  relatedUrl: string;
  icon?: any;
}

const ChildRecordItem = memo((props: ChildModule) => {
  const { navigate } = useNavigate('View');
  return (
    <Stack direction='column' alignItems='left' spacing={1}>
      <Box>
        {props.relatesTo ? (
          props?.relatesTo?.map(relate => (
            <Text
              key={relate?.id}
              onClick={() => navigate(`${props?.relatedUrl}${relate?.id}`)}
              $css={`
                color: #3137FD;
                cursor: pointer;
                &:hover {
                  text-decoration: underline;
                }
              `}
            >
              {relate?.name}
            </Text>
          ))
        ) : (
          <Text color='var(--table-no-data)'>No data</Text>
        )}
      </Box>
    </Stack>
  );
});
ChildRecordItem.displayName = 'ChildRecordItem';

const ChildRecord = ({ childItems }: { childItems: Array<ChildModule> }) => {
  return (
    <Stack spacing={1}>
      {childItems.map((r, i) => (
        <ChildRecordItem key={i} {...r} />
      ))}
    </Stack>
  );
};

export default memo(ChildRecord);
