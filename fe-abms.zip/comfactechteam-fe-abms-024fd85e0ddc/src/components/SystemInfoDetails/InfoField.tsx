import { Text } from '@/styled-components';
import { Stack } from '@mui/material';

type InfoFieldProps = {
  label: string;
  value: string | React.ReactNode;
  isFirst?: boolean;
  isLast?: boolean;
};

const InfoField = ({
  label,
  value,
  isFirst = false,
  isLast = false,
}: InfoFieldProps) => {
  return (
    <Stack direction='row' alignItems='center'>
      <Stack
        alignItems='center'
        sx={{
          height: '52px',
          background: 'var(--gray-0)',
          ...(isFirst && { borderTopLeftRadius: '8px' }),
          ...(isLast && { borderBottomLeftRadius: '8px' }),
        }}
      >
        <Text
          style={{
            width: '168px',
            marginLeft: '20px',
            marginTop: '13px',
            color: '#686D78',
            fontWeight: '400',
          }}
        >
          {label}
        </Text>
      </Stack>
      <Stack alignItems='center' sx={{ height: '52px' }}>
        <Text style={{ marginLeft: '20px', marginTop: '13px' }}>{value}</Text>
      </Stack>
    </Stack>
  );
};

export default InfoField;
