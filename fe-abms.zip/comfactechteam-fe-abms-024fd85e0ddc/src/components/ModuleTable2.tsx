import React, { useEffect, useState, useRef } from 'react';

import {
  ModuleTable as Table,
  Checkbox,
  Icon,
  Text,
  Select,
  GoogleIcon,
  EmptyState,
  MaterialIcon,
} from '@/styled-components';

import useQuery from '@/hooks/useQuery';
import { Box, Stack } from '@mui/material';
import { ModuleTableProps } from '@/typings/modulTable.types';

import { Dropdown } from 'antd';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

const RowsPerPage = ({ total, range, setPageSize, pageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        defaultValue={pageSize}
        options={[
          {
            label: '10',
            value: 10,
          },
          {
            label: '20 ',
            value: 20,
          },
          {
            label: '50',
            value: 50,
          },
          {
            label: '100',
            value: 100,
          },
        ]}
        onChange={val => setPageSize(val)}
        suffixIcon={
          <GoogleIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
          &[class*="-select-focused"] [class*="-select-selector"] {
            box-shadow: none;
          }

          [class$="select-selection-item"] {
            color: var(--color-text-primary) !important;
            font-size: 12px;
            padding-inline-end: 24px !important;
          }
          [class$="select-selector"] {
            gap: 4px;
            padding: 0 4px;
            border-width: 0 !important;
          }
        `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};

const ModuleTable2 = ({
  columns,
  allQuery,
  onChangeSelected,
  searchFields,
  filterFields = [],
  refetch,
  nameField = 'name',
  onHandleData = null,
  transform = undefined,
  onTableChange = undefined,
  loading = false,
  otherTableProps = {},
  selectedProps,
  isSearching = false,
  tableLayout,
  ...props
}: ModuleTableProps & { isSearching?: boolean }) => {
  const {
    rowSelection,
    setAllQueryData,
    sortArg,
    getCheckboxProps,
    lengthPerPage = 20,
    skip = false,
  } = props as any;
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();
  const [selected, setSelected] = useState([]);
  const [pageSize, setPageSize] = useState<number>(lengthPerPage);
  const currentPageData = useRef([]);

  let searchArg = [];
  if (searchFields) searchArg = searchFields;

  for (const filterArr of filterFields) {
    if (filterArr && filterArr != null) {
      searchArg.push(filterArr);
    }
  }

  const {
    data: allData,
    loading: allLoading,
    refetch: allRequery,
  } = useQuery<Array<any>>({
    query: allQuery,
    options: {
      fetchPolicy: 'no-cache',
      variables: {
        sortArg: sortArg || [
          {
            field: nameField,
            direction: 'asc',
          },
        ],
        searchArg,
      },
    },
    transformData: data => (transform ? transform(data) : data),
    skip: skip,
  });

  // Use staticData if provided, otherwise use allData
  const dataSource = props.staticData ?? allData;

  const onSelectType = type => {
    let newSelectedRowKeys = Array.isArray(selectedProps)
      ? [...selectedProps]
      : [...selected];
    let newSelectedRows = [];
    const visibleRows = currentPageData.current;
    const visibleRowKeys = visibleRows.map(row => row.id);

    if (type === 'this') {
      if (!isSearching) {
        // Not searching: only select the visible page (replace selection)
        newSelectedRowKeys = [...visibleRowKeys];
        newSelectedRows = dataSource.filter(row =>
          newSelectedRowKeys.includes(row.id)
        );
      } else {
        // Searching: accumulate (add) visible items to selection
        visibleRowKeys.forEach(id => {
          if (!newSelectedRowKeys.includes(id)) newSelectedRowKeys.push(id);
        });
        newSelectedRows = dataSource.filter(row =>
          newSelectedRowKeys.includes(row.id)
        );
      }
    } else if (type === 'all') {
      if (!isSearching) {
        // Not searching: select all items in the full data set
        newSelectedRowKeys = dataSource.map(row => row.id);
        newSelectedRows = dataSource;
      } else {
        // Searching: accumulate (add) visible items to selection
        visibleRowKeys.forEach(id => {
          if (!newSelectedRowKeys.includes(id)) newSelectedRowKeys.push(id);
        });
        newSelectedRows = dataSource.filter(row =>
          newSelectedRowKeys.includes(row.id)
        );
      }
    } else if (type === 'deselect') {
      // Deselect all items (not just visible)
      newSelectedRowKeys = [];
      newSelectedRows = [];
    }

    setSelected(newSelectedRowKeys);
    if (onChangeSelected) {
      onChangeSelected(newSelectedRows);
    }
  };

  const customRowSelection = {
    preserveSelectedRowKeys: true,
    columnWidth: 68,
    selectedRowKeys: selectedProps ?? selected,
    getCheckboxProps,
    columnTitle: () => {
      if (rowSelection?.type === 'radio') return;

      // Always use currently visible (filtered) data for header checkbox state
      const currentIds = dataSource?.map(d => d.id) || [];
      const selectedOnPage = (selectedProps ?? selected).filter(id =>
        currentIds.includes(id)
      );
      const allSelected =
        selectedOnPage.length === currentIds.length && currentIds.length > 0;
      const noneSelected = selectedOnPage.length === 0;
      const indeterminate = !allSelected && !noneSelected;

      return (
        <Dropdown
          menu={{
            items: [
              {
                key: 'thisPage',
                label: 'Select this page',
                onClick: () => onSelectType('this'),
              },
              {
                key: 'allPage',
                label: 'Select all page',
                onClick: () => onSelectType('all'),
              },
              {
                key: 'deselectAll',
                label: 'Deselect all',
                onClick: () => onSelectType('deselect'),
              },
            ],
          }}
          trigger={['click']}
        >
          <a role='button'>
            <Stack direction='row' alignItems='center' spacing={0.5}>
              <Checkbox
                checked={allSelected}
                indeterminate={indeterminate}
                $css={`
                  min-width: 24px !important;
                  height: 24px;
                  justify-content: center;
                `}
              />
              <Icon color='var(--gray-600)'>
                <MaterialIcon name='arrow_drop_down' />
              </Icon>
            </Stack>
          </a>
        </Dropdown>
      );
    },
    onChange: (selectedRowKeys, selectedRows) => {
      setSelected(selectedRowKeys);
      if (onChangeSelected) {
        onChangeSelected(selectedRows);
      }
    },
    renderCell: (_, __, ___, originNode) => {
      if (rowSelection?.type === 'radio') return originNode;

      return (
        <Box
          display='flex'
          sx={{
            width: 24,
            height: 24,
            justifyContent: 'center',
          }}
        >
          {originNode}
        </Box>
      );
    },
  };

  useEffect(() => {
    if (setAllQueryData && allData) {
      setAllQueryData(allData);
    }

    if (onHandleData) {
      onHandleData(allData);
    }
  }, [allData]);

  useEffect(() => {
    if (refetch?.refetch) {
      allRequery();
      onSelectType('deselect');
      onChangeSelected([], selectType);
      setSelected([]);
      refetch.setRefetch(false);
    }
  }, [refetch?.refetch]);

  useEffect(() => {
    if (selectedProps !== undefined) {
      setSelected(selectedProps);
    }
  }, [selectedProps]);

  return (
    <Table
      columns={columns}
      data={dataSource}
      paginationText={'Rows per page'}
      showPaginationItems={false}
      onSelectAllMenu={type => setSelectType(type)}
      loading={[allLoading, loading].includes(true)}
      rowSelection={rowSelection === false ? undefined : customRowSelection}
      hidePagination
      onChange={onTableChange}
      tableProps={{
        footer: currentPage => {
          currentPageData.current = currentPage;
          return;
        },
        pagination: {
          total: dataSource?.length,
          showSizeChanger: false,
          position: ['bottom', 'left'],
          pageSize: pageSize,
          defaultPageSize: 10,
          showTotal: (total, range) => (
            <RowsPerPage
              total={total}
              range={range}
              setPageSize={setPageSize}
              pageSize={pageSize}
            />
          ),
          itemRender: (_, type, originalElement) =>
            type === 'page' ? null : originalElement,
        },
        tableLayout: tableLayout ? tableLayout : 'fixed',
        ...otherTableProps,
      }}
      emptyState={<EmptyState iconW='200px' title='No data to display.' />}
      {...props}
    />
  );
};

export default ModuleTable2;
