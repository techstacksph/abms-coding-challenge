import { ReactNode } from 'react';

import { labelSpan, required } from '@/utils/inputProps.util';

export const nameFields = {
  siteName: 'Site name',
  phone: 'Phone No.',
  mobile: 'Mobile',
  locationId: 'Location',
};

export const nameField = () => {
  return {
    showDivider: false,
    fields: [
      {
        title: 'Site name',
        type: 'text',
        field: 'siteName',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
    ],
  };
};

export const addressInformation = (findAddressElement: ReactNode) => ({
  title: 'Address information',
  showDivider: true,
  fields: [
    {
      title: 'Find address',
      type: 'custom',
      field: 'findStreet',
      element: findAddressElement,
      props: {
        ...labelSpan,
      },
      inputProps: {
        autoSize: {
          minRows: 3,
        },
      },
    },
    {
      title: 'Street address',
      type: 'textarea',
      field: 'streetAddress',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        autoSize: {
          minRows: 3,
        },
      },
    },
    {
      title: 'Longitude',
      type: 'text',
      field: 'longitude',
      ishidden: true,
    },
    {
      title: 'Latitude',
      type: 'text',
      field: 'latitude',
      ishidden: true,
    },
  ],
});

export const addressSecond = data => {
  return {
    fields: [
      {
        title: 'Suburb',
        field: 'suburb',
        type: 'text',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
      },
      {
        title: 'Area',
        type: 'select',
        field: 'areaId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Select',
          options: data['area']?.map(d => ({
            value: d.id,
            label: `${d.area}`,
          })),
        },
      },
      {
        title: 'City',
        field: 'city',
        type: 'text',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
      },
      {
        title: 'Region',
        field: 'region',
        type: 'text',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
      },
    ],
  };
};

export const postal = {
  title: 'Postal code',
  field: 'postalCode',
  type: 'text',
  required: true,
  props: {
    labelCol: {
      span: 24,
      style: {
        whiteSpace: 'nowrap',
      },
    },
    rules: [required],
  },
};

export const countryField = countries => ({
  title: 'Country',
  field: 'countryId',
  type: 'select',
  required: true,
  inputProps: {
    options: countries?.map(c => {
      return { value: c.id, label: c.name };
    }),
  },
  props: {
    ...labelSpan,
    rules: [required],
  },
});
