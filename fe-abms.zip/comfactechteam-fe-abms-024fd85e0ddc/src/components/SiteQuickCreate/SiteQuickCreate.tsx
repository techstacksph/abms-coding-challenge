import React, { useEffect } from 'react';

import {
  Form,
  FormButtons,
  useModal,
  MaterialIcon,
  Icon,
  useSnackbar,
} from '@/styled-components';

import { ALL_AREAS } from '@/graphql/area.gql';
import { ALL_COUNTRIES } from '@/graphql/country.gql';
import { CREATE_SITES } from '@/graphql/sites.gql';
import useMutation from '@/hooks/useMutation';
import useQuery from '@/hooks/useQuery';
import AreaModel from '@/models/AreaModel';
import CountryModel from '@/models/CountryModel';
import { Box } from '@mui/material';
import { errorMessages } from '@/utils/messages.utils';
import { formFullAddress } from '@/utils/string.utils';

import { Form as AntdForm } from 'antd';

import SiteDetails from './SiteDetails';

const SiteQuickCreate = ({
  handleSuccess,
  accountId,
  $sx = {},
}: {
  handleSuccess?: (val) => void;
  accountId?: string;
  $sx?: React.CSSProperties;
}) => {
  const [form] = AntdForm.useForm();
  const { snackbar } = useSnackbar();
  const { data: dbCountries } = useQuery<Array<CountryModel>>({
    query: ALL_COUNTRIES,
    options: {
      variables: {
        sortArg: [
          {
            field: 'name',
            direction: 'asc',
          },
        ],
      },
    },
  });

  const { data: dbAreas } = useQuery<Array<AreaModel>>({
    query: ALL_AREAS,
    options: {
      variables: {
        sortArg: [
          {
            field: 'area',
            direction: 'asc',
          },
        ],
      },
    },
    transformData: (data: AreaModel[]) => {
      return data?.filter(item => item.area);
    },
  });

  // Set default country when countries are loaded
  useEffect(() => {
    if (dbCountries && dbCountries.length > 0) {
      const defaultCountry = dbCountries.find(item => item.code === 'NZ');
      if (defaultCountry) {
        form.setFieldValue('countryId', defaultCountry.id);
        form.setFieldsValue({ countryId: defaultCountry.id });
      }
    }
  }, [dbCountries, form]);

  const [create] = useMutation({
    query: CREATE_SITES,
    successMessage: `${form.getFieldValue('siteName')} created successfully.`,
    onSuccess: (value: any) => {
      handleSuccess(value);
      closeModal();
      // Reset form and set default country for next use
      form.resetFields();
      if (dbCountries && dbCountries.length > 0) {
        const defaultCountry = dbCountries.find(item => item.code === 'NZ');
        if (defaultCountry) {
          form.setFieldValue('countryId', defaultCountry.id);
          form.setFieldsValue({ countryId: defaultCountry.id });
        }
      }
    },
    onError: err => {
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      const field = graphQLError?.extensions.field;

      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        const fieldValue = form.getFieldValue(field) || 'This value';
        form.setFields([
          {
            name: field,
            errors: [
              `${fieldValue} already exists. This field must be unique.`,
            ],
          },
        ]);

        snackbar({
          type: 'error',
          message: 'Error: Invalid data.',
        });
      }
      return;
    },
  });

  const onFinish = async values => {
    values['phone'] = values?.phone ? values?.phone.toString() : '';
    values['mobile'] = values?.mobile ? values?.mobile.toString() : '';
    const country: CountryModel | null = values?.countryId
      ? dbCountries.filter(item => item.id == values.countryId)[0]
      : null;

    if (country) {
      values['countryId'] = country?.id;
    }

    // Link site to account if accountId is provided
    if (accountId) {
      values['accountId'] = accountId;
    }

    values['address'] = formFullAddress({
      streetAddress: values.streetAddress,
      suburb: values.suburb,
      city: values.city,
      region: values.region,
      postalCode: values.postalCode,
      countryId: values.countryId,
      countryText: country?.name,
    });

    await create({
      variables: {
        site: values,
      },
    });
  };

  const onFinishFailed = errorInfo => {
    const isRequiredError =
      errorInfo?.errorFields?.findIndex(
        errorField =>
          errorField?.errors?.findIndex(error => error?.includes('required')) >
          -1
      ) > -1;

    if (isRequiredError) {
      return snackbar({
        type: 'error',
        message: 'Missing required field(s).',
      });
    }

    snackbar({
      type: 'error',
      message: 'Error: Invalid data.',
    });
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New site',
    message: (
      <Box sx={{ button: { width: 120 } }}>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFinishFailed}>
          <SiteDetails
            form={form}
            dbCountries={dbCountries}
            dbAreas={dbAreas}
          />
          <FormButtons
            saveAsDraft={false}
            onCancel={() => closeModal()}
            submitText='Save'
          />
        </Form>
      </Box>
    ),
    modalProps: {
      modalProps: {
        footer: null,
      },
    },
  });

  // Function to handle opening modal with proper form reset
  const handleOpenModal = () => {
    // Reset form first
    form.resetFields();

    // Set default country if available
    if (dbCountries && dbCountries.length > 0) {
      const defaultCountry = dbCountries.find(item => item.code === 'NZ');
      if (defaultCountry) {
        form.setFieldValue('countryId', defaultCountry.id);
        form.setFieldsValue({ countryId: defaultCountry.id });
      }
    }

    // Open modal
    openModal();
  };

  return (
    <>
      {contextModal}
      <Box
        sx={{
          color: 'rgba(49, 55, 253, 1)',
          backgroundColor: '#FFFFFF',
          width: '40px',
          height: '40px',
          border: '1px solid rgba(49, 55, 253, 1)',
          padding: '8px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: '8px',
          marginTop: '12px',
          marginLeft: '15px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
            cursor: 'pointer',
          },
          ...$sx,
        }}
        onClick={handleOpenModal}
      >
        <Icon $css='rotate: -90deg;'>
          <MaterialIcon iconClass='material-icons' name='add' />
        </Icon>
      </Box>
      {/* <Button
        ghost
        icon={
          <Icon $css="rotate: -90deg;">
            <MaterialIcon iconClass="material-icons" name="add" />
          </Icon>
        }
        $css={`
          margin-top: 12px;
          margin-left: 15px;
          color: rgba(49, 55, 253, 1) !important;
          background-color: #FFFFFF !important;
          width: 40px !important;
          height: 40px;
          border-color: rgba(49, 55, 253, 1) !important;

          ${$css}
        `}
        onClick={openModal}
      /> */}
      {/* <Spin spinning={tLoading || dbCloading || dbAloading}>
        <Form
          onFinish={onFinish}
          form={form}
          formProps={{
            onFinishFailed,
            onValuesChange,
            initialValues: {
              accountId: props?.id,
              countryId: 'NZ',
            },
          }}
        >
          <SiteContext.Provider
            value={{
              form,
              dbCountries,
              dbAreas,
            }}
          >
            {props.children}
          </SiteContext.Provider>
        </Form>
      </Spin> */}
    </>
  );
};

export default SiteQuickCreate;
