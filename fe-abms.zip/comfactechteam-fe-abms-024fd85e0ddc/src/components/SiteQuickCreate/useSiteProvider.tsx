import useFormFailed from '@/hooks/useFormFailed';
import { removeSpaceFirstCharacter } from '@/utils/form.utils';

import { Form } from 'antd';

import { nameFields } from './fields';

const useSiteProvider = () => {
  const onFinishFailed = useFormFailed(nameFields);
  const [form] = Form.useForm();

  const onValuesChange = changed => {
    const field = Object.keys(changed)[0];
    const value = changed[field];
    const newField = removeSpaceFirstCharacter(value);
    if (!newField) {
      form.setFieldValue(field, '');
    }
  };

  return { form, onFinishFailed, onValuesChange };
};

export default useSiteProvider;
