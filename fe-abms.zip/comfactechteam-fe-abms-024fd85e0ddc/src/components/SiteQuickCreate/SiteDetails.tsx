import React from 'react';

import { FormSection, FormInput } from '@/styled-components';

import FindAddress from '@/components/FindAddress';
import { Box, Stack } from '@mui/material';

import {
  addressInformation,
  addressSecond,
  countryField,
  nameField,
  postal,
} from './fields';

const SiteDetails = ({ form, dbCountries, dbAreas }) => {
  return (
    <>
      <Stack direction='column' spacing={2.5} width='100%'>
        <FormSection fields={nameField()} />
        <FormSection
          fields={addressInformation(
            <FindAddress
              form={form}
              fields={{
                findAddress: 'findStreet',
                street: 'streetAddress',
                city: 'city',
                region: 'region',
                postal: 'postalCode',
                suburb: 'suburb',
                country: 'countryId',
                longitude: 'longitude',
                latitude: 'latitude',
              }}
            />
          )}
        />
        <FormSection
          fields={addressSecond({ area: dbAreas })}
          col={2}
          row={2}
        />
        <Stack direction='row' spacing={2}>
          <Box sx={{ width: '25%' }}>
            <FormInput field={postal} />
          </Box>
          <Box sx={{ width: '75%' }}>
            <FormInput field={countryField(dbCountries)} />
          </Box>
        </Stack>
      </Stack>
    </>
  );
};

export default SiteDetails;
