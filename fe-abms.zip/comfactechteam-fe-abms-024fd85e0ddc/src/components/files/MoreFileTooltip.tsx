import React, { memo } from 'react';

import { Text, Icon } from '@/styled-components';

import { Box, Stack } from '@mui/material';
import { FileUpload } from '@/typings/inputField.types';
import { getFileTypeIcon } from '@/views/documents/common/services';

import { Tooltip } from 'antd';

const MoreFileTooltip = ({ files }: { files: Array<FileUpload> }) => {
  if (files.length === 0) return <></>;

  return (
    <Tooltip
      title={
        <Stack>
          <Text
            $type='xs'
            weight='medium'
            $css='color: var(--color-text-tertiary);'
          >
            Other files
          </Text>
          {files.map((f, i) => (
            <Stack
              direction='row'
              spacing={0.5}
              alignItems='flex-start'
              padding={1}
              key={i}
            >
              <Icon>{getFileTypeIcon(f)}</Icon>
              <Text>{f.name}</Text>
            </Stack>
          ))}
        </Stack>
      }
      color='#FFF'
      placement='rightTop'
      arrow={false}
    >
      <Box
        borderRadius={2}
        border='1px solid #D3D5D9'
        paddingX={1}
        paddingY={0.5}
        alignItems='center'
      >
        +{files.length}
      </Box>
    </Tooltip>
  );
};

export default memo(MoreFileTooltip);
