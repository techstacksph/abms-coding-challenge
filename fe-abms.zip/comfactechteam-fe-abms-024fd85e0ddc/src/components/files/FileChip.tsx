import React, { memo, useState } from 'react';

import { Icon, Text, MaterialIcon } from '@/styled-components';

import { Stack } from '@mui/material';
import { FileUpload } from '@/typings/inputField.types';
import { getFileTypeIcon } from '@/views/documents/common/services';

const FileChip = (props: FileUpload) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Stack
      direction='row'
      spacing={0.5}
      borderRadius={2}
      border='1px solid #D3D5D9'
      paddingX={1}
      paddingY={0.5}
      alignItems='center'
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Icon>{getFileTypeIcon(props)}</Icon>
      <Text
        $type='sm'
        $css={`
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
          max-width: ${props.hasClosed ? '143px' : '155px'};
        `}
      >
        {props.name}
      </Text>
      {props.hasClosed && (
        <Stack
          onClick={() => {
            props.onClose();
          }}
          sx={{
            width: 16,
            height: 16,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            opacity: isHovered ? 1 : 0,
            transition: 'opacity 0.2s ease',
            cursor: 'pointer',
          }}
        >
          <MaterialIcon
            name='close'
            $css='color: var(--icon-3); font-size: 14px;'
          />
        </Stack>
      )}
    </Stack>
  );
};

export default memo(FileChip);
