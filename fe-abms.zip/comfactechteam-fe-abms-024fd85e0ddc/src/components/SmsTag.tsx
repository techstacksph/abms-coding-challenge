import React from 'react';

import { StatusTag as BaseStatusTag } from '@/styled-components';

import { SmsOptions } from '@/constants/Status';

const SmsTag = ({ status = SmsOptions.SMS }: { status: SmsOptions }) => {
  let color;
  switch (status?.toUpperCase()) {
    case SmsOptions.SMS:
      color = 'var(--gray-400)';
      break;
    default:
      color = 'var(--gray-400)';
      break;
  }

  return (
    <>
      <BaseStatusTag
        $css={'text-transform: capitalize;'}
        color={color}
        label={status.toUpperCase()}
      />
    </>
  );
};

export default SmsTag;
