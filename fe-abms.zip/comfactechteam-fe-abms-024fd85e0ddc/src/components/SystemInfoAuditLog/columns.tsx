import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { dateTimeFormat } from '@/utils/date.utils';
import User from '@/models/User';
import { isValueValid } from '@/utils/helper.utils';
import NoData from '../NoData';
import { CaseType, convertCase, getFullName } from '@/utils/string.utils';

// Define default columns for audit logs
export const auditLogColumns = (findUserById: (id: string) => User | null) => [
  {
    title: 'Date and time',
    dataIndex: 'createdAt',
    key: 'createdAt',
    render: (createdAt: string) => (
      <Text>{dayjs(createdAt).format(dateTimeFormat)}</Text>
    ),
  },
  {
    title: 'Details',
    dataIndex: 'content',
    key: 'content',
    render: (content: string) => (
      <Text style={{ maxWidth: '300px', wordBreak: 'break-word' }}>
        {content}
      </Text>
    ),
  },
  {
    title: 'Activity',
    dataIndex: 'actionType',
    key: 'actionType',
    render: (actionType: string) => (
      <Text>{convertCase(actionType, CaseType.SENTENCE_CASE, true)}</Text>
    ),
  },
  {
    title: 'User',
    dataIndex: 'createdBy',
    key: 'createdBy',
    render: (createdBy: string, record: any) => {
      const createdByUser = findUserById(createdBy || record.createdBy);
      return isValueValid(createdByUser) ? (
        <Text>{getFullName(createdByUser)}</Text>
      ) : (
        <NoData />
      );
    },
  },
  {
    title: 'Role',
    dataIndex: 'createdBy',
    key: 'userRole',
    render: (role: string) => {
      const user = findUserById(role);
      return isValueValid(user) ? (
        <Text>
          {convertCase(user?.userRole?.role, CaseType.SENTENCE_CASE, true)}
        </Text>
      ) : (
        <NoData />
      );
    },
  },
];
