import React, { useEffect, useRef, useState } from 'react';

import environment from '@/config/environment';
import { ALL_COUNTRIES } from '@/graphql/country.gql';
import useQuery from '@/hooks/useQuery';
import CountryModel from '@/models/CountryModel';
import {
  Autocomplete, // LoadScript,
  useJsApiLoader,
} from '@react-google-maps/api';
import { setFieldValues } from '@/services/findaddress.service';
import { FindAddressFields } from '@/typings/find.address.types';
import { googleApiErrorMessages } from '@/utils/messages.utils';

import { FormInstance } from 'antd';

import GoogleApiLoader from './GoogleApiLoader';

const GOOGLE_API_KEY =
  environment.GOOGLE_API_KEY ?? 'AIzaSyD5peEU0aa8sKjHSw4S9XKnpFLabJ3gwRc';
const MAP_LIBRARIES: ['places'] = ['places'];

const FindAddress = ({
  onPlaceSelect,
  country = 'nz',
  form,
  fields,
  findAddressValue = null, // used in edit page only
  holderField,
}: {
  onPlaceSelect?: (place: google.maps.places.PlaceResult | null) => void;
  country?: string;
  form: FormInstance;
  fields: FindAddressFields;
  findAddressValue?: string;
  holderField?: string;
}) => {
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_API_KEY,
    libraries: MAP_LIBRARIES,
  });

  const [placeAutocomplete, setPlaceAutocomplete] =
    useState<google.maps.places.Autocomplete | null>(null);

  const { data: dbCountries } = useQuery<Array<CountryModel>>({
    query: ALL_COUNTRIES,
    options: {
      variables: {
        sortArg: [
          {
            field: 'name',
            direction: 'asc',
          },
        ],
      },
    },
  });

  const inputRef = useRef(null);

  const clearFieldErrors = () => {
    const allFields = [
      fields.suburb,
      fields.street,
      fields.city,
      fields.region,
      fields.postal,
      fields.country,
    ];

    const fieldUpdates = allFields.map(field => {
      const fieldValue = form.getFieldValue(field);
      return {
        name: field,
        errors: fieldValue ? [] : ['This field is required'],
      };
    });

    form.setFields(fieldUpdates);
  };

  const clearAddressFields = () => {
    form.setFieldValue('placeId', null);
    form.setFieldValue('findStreet', null);
    form.setFieldValue('findAddress', null);
    form.setFieldValue('address', null);
  };

  const onPlaceChanged = () => {
    const place: google.maps.places.PlaceResult = placeAutocomplete.getPlace();
    setFieldValues(place, fields, form, inputRef, holderField, dbCountries);
    if (place) {
      clearFieldErrors();
    }

    if (onPlaceSelect) onPlaceSelect(place);
  };

  useEffect(() => {
    // INTERCEPT CONSOLE ERRORS FOR GOOGLE ERRORS
    const console = window.console;

    if (!console && !isLoaded) return;
    const intercept = (method: string) => {
      const original = console[method];
      console[method] = function (...args) {
        // do sneaky stuff
        if (original.apply) {
          if (args[0]) {
            Object.keys(googleApiErrorMessages).forEach(error => {
              if (args[0]?.indexOf(error) > -1) {
                form.setFields([
                  {
                    name: fields.findAddress,
                    errors: [googleApiErrorMessages[error]],
                  },
                ]);

                return;
              }
            });
          }
          // Do this for normal browsers
          original.apply(console, args);
        } else {
          // Do this for IE
          const message = Array.prototype.slice.apply(args).join(' ');
          original(message);
        }
      };
    };
    const methods = ['error'];
    for (let i = 0; i < methods.length; i++) intercept(methods[i]);
  }, [isLoaded]);

  return (
    // <LoadScript
    //   id="google-maps-api-script-loader"
    //   googleMapsApiKey={GOOGLE_API_KEY}
    //   libraries={MAP_LIBRARIES}
    // >
    <GoogleApiLoader>
      <Autocomplete
        onLoad={(autocomplete: google.maps.places.Autocomplete) => {
          setPlaceAutocomplete(autocomplete);
        }}
        onPlaceChanged={onPlaceChanged}
        restrictions={{ country }}
        fields={['address_components', 'geometry', 'place_id']}
      >
        <input
          name={fields.findAddress}
          className='find-address-input'
          ref={inputRef}
          defaultValue={findAddressValue}
          onChange={e => {
            clearAddressFields();

            if (holderField) form.setFieldValue(holderField, e.target.value);
          }}
          onKeyDown={e => {
            if (e.key === 'Backspace' && window.getSelection()?.toString()) {
              clearAddressFields();
              if (holderField) form.setFieldValue(holderField, '');
            }
          }}
        />
      </Autocomplete>
    </GoogleApiLoader>
    // </LoadScript>
  );
};

export default FindAddress;
