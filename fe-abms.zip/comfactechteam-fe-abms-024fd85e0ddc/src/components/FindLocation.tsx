import React, { useEffect, useRef, useState } from 'react';

import environment from '@/config/environment';
import { useJsApiLoader } from '@react-google-maps/api';
import { setFieldValues } from '@/services/findaddress.service';
import { FindAddressFields } from '@/typings/find.address.types';

import { FormInstance } from 'antd';

const GOOGLE_API_KEY =
  environment.GOOGLE_API_KEY ?? 'AIzaSyD5peEU0aa8sKjHSw4S9XKnpFLabJ3gwRc';
const MAP_LIBRARIES: ['places'] = ['places'];

const FindLocation = ({
  findAddressValue,
  form,
  fields,
  country = 'nz',
  holderField,
}: {
  findAddressValue?: string;
  form: FormInstance;
  fields: FindAddressFields;
  country?: string;
  holderField?: string;
}) => {
  // Load Google Maps API immediately when component mounts
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_API_KEY,
    libraries: MAP_LIBRARIES,
  });

  const [placeAutocomplete, setPlaceAutocomplete] =
    useState<google.maps.places.Autocomplete | null>(null);
  const [isGoogleReady, setIsGoogleReady] = useState<boolean>(false);

  const inputRef = useRef<HTMLInputElement>(null);

  // Poll for Google Maps availability and initialize autocomplete manually
  useEffect(() => {
    if (isLoaded && !isGoogleReady) {
      const checkGoogleReady = () => {
        const googleAvailable =
          typeof window !== 'undefined' &&
          window.google &&
          window.google.maps &&
          window.google.maps.places;

        if (googleAvailable) {
          setIsGoogleReady(true);

          // Initialize autocomplete manually once Google is ready
          if (inputRef.current && !placeAutocomplete) {
            try {
              const autocomplete = new window.google.maps.places.Autocomplete(
                inputRef.current,
                {
                  componentRestrictions: { country },
                  fields: [
                    'formatted_address',
                    'name',
                    'geometry',
                    'place_id',
                    'address_components',
                  ],
                }
              );

              autocomplete.addListener('place_changed', () => {
                try {
                  const place = autocomplete.getPlace();
                  if (place && place.place_id) {
                    // Set location text field
                    if (fields.findAddress) {
                      form.setFieldValue(
                        fields.findAddress,
                        place.formatted_address || place.name
                      );
                      setFieldValues(
                        place,
                        fields,
                        form,
                        inputRef,
                        holderField
                      );
                    }
                  }
                } catch (error) {
                  console.log({ error });
                  // To action here
                }
              });

              setPlaceAutocomplete(autocomplete);
            } catch (error) {
              console.log({ error });
              // To action here
            }
          }
        } else {
          // Keep checking every 100ms until Google is available
          setTimeout(checkGoogleReady, 100);
        }
      };

      checkGoogleReady();
    }
  }, [isLoaded, isGoogleReady, country, fields, form, placeAutocomplete]);

  const clearAddressFields = () => {
    form.setFieldValue('locationText', null);
  };

  // Handle loading errors
  if (loadError) {
    return (
      <input
        name={fields.findAddress}
        className='find-address-input'
        ref={inputRef}
        defaultValue={findAddressValue}
        placeholder='Error loading Google Maps'
        disabled
      />
    );
  }

  // Show loading state until Google Maps is ready
  if (!isGoogleReady) {
    return (
      <input
        name={fields.findAddress}
        className='find-address-input'
        ref={inputRef}
        defaultValue={findAddressValue}
        placeholder='Loading Google Maps...'
        disabled
      />
    );
  }

  // Render the simple input - autocomplete is attached manually via useEffect
  return (
    <input
      name={fields.findAddress}
      className='find-address-input'
      ref={inputRef}
      defaultValue={findAddressValue}
      placeholder='Enter a location'
      onChange={() => {
        clearAddressFields();
      }}
      onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Backspace' && window.getSelection()?.toString()) {
          clearAddressFields();
        }
      }}
    />
  );
};

export default FindLocation;
