import { useEffect, useState } from 'react';

import dayjs from 'dayjs';

import { Content, Text } from '@/styled-components';

import ViewModuleSections from '@/components/modules/ViewModuleSections';
import environment from '@/config/environment';
import { FIND_USER_BY_ID } from '@/graphql/user.gql';
import useQuery from '@/hooks/useQuery';
import User from '@/models/User';
import { dateTimeFormat } from '@/utils/date.utils';
import { SortDirection, Stack } from '@mui/material';

import DataTable from '@/components/DataTable';

const TENANT_PREFIX = environment.TENANT_PREFIX;

type SystemInfoProps = {
  data: any;
  createdBy?: any;
  query?: any;
  columns?: any;
  paginatedQuery?: any;
  paginatedQueryNameField?: string;
  calledFrom?: string;
};

type CreatedBy = {
  firstName: string;
  lastName: string;
};

const defaultSortArg = [
  {
    field: 'name',
    direction: 'asc' as SortDirection,
  },
];

const SystemInfo = ({
  data,
  query,
  columns,
  paginatedQuery,
  paginatedQueryNameField,
  calledFrom,
}: SystemInfoProps) => {
  const [page, setPage] = useState<number>(1);
  const [createdByData, setCreatedByData] = useState<CreatedBy>();
  const { data: creator } = useQuery<User>({
    query: FIND_USER_BY_ID,
    options: {
      variables: {
        [`${TENANT_PREFIX}findUserByIdId`]: data?.createdBy,
      },
    },
  });
  useEffect(() => {
    if (creator) {
      setCreatedByData({
        firstName: creator?.firstName,
        lastName: creator?.lastName,
      });
    }
  }, [creator, data]);

  return (
    <Stack direction='column'>
      <ViewModuleSections
        title='System information'
        containerProps={{ width: '100%' }}
      >
        <Stack direction='row'>
          <Content style={{ padding: 0, marginRight: '20px' }}>
            <Stack direction='row' alignItems='center'>
              <Stack
                alignItems='center'
                sx={{
                  height: '52px',
                  background: 'var(--gray-0)',
                  borderTopLeftRadius: '8px',
                }}
              >
                <Text
                  style={{
                    width: '168px',
                    marginLeft: '20px',
                    marginTop: '13px',
                    color: '#686D78',
                    fontWeight: '400',
                  }}
                >
                  Created by
                </Text>
              </Stack>
              <Stack alignItems='center' sx={{ height: '52px' }}>
                <Text style={{ marginLeft: '20px', marginTop: '13px' }}>
                  {createdByData?.firstName} {createdByData?.lastName}
                </Text>
              </Stack>
            </Stack>
            <Stack direction='row' alignItems='center'>
              <Stack
                alignItems='center'
                sx={{
                  height: '52px',
                  background: 'var(--gray-0)',
                  borderBottomLeftRadius: '8px',
                }}
              >
                <Text
                  style={{
                    width: '168px',
                    marginLeft: '20px',
                    marginTop: '13px',
                    color: '#686D78',
                    fontWeight: '400',
                  }}
                >
                  Created at
                </Text>
              </Stack>
              <Stack alignItems='center' sx={{ height: '52px' }}>
                <Text style={{ marginLeft: '20px', marginTop: '13px' }}>
                  {dayjs(data?.createdAt).format(dateTimeFormat)}
                </Text>
              </Stack>
            </Stack>
          </Content>

          <Content style={{ padding: 0 }}>
            <Stack direction='row' alignItems='center'>
              <Stack
                alignItems='center'
                sx={{
                  height: '52px',
                  background: 'var(--gray-0)',
                  borderTopLeftRadius: '8px',
                }}
              >
                <Text
                  style={{
                    width: '168px',
                    marginLeft: '20px',
                    marginTop: '13px',
                    color: '#686D78',
                    fontWeight: '400',
                  }}
                >
                  Updated by
                </Text>
              </Stack>
              <Stack alignItems='center' sx={{ height: '52px' }}>
                <Text style={{ marginLeft: '20px', marginTop: '13px' }}>
                  {data?.updatedByName ? data?.updatedByName : 'No data'}
                </Text>
              </Stack>
            </Stack>
            <Stack direction='row' alignItems='center'>
              <Stack
                alignItems='center'
                sx={{
                  height: '52px',
                  background: 'var(--gray-0)',
                  borderBottomLeftRadius: '8px',
                }}
              >
                <Text
                  style={{
                    width: '168px',
                    marginLeft: '20px',
                    marginTop: '13px',
                    color: '#686D78',
                    fontWeight: '400',
                  }}
                >
                  Updated at
                </Text>
              </Stack>
              <Stack alignItems='center' sx={{ height: '52px' }}>
                <Text style={{ marginLeft: '20px', marginTop: '13px' }}>
                  {data?.updatedAt
                    ? dayjs(data?.updatedAt).format(dateTimeFormat)
                    : ''}
                </Text>
              </Stack>
            </Stack>
          </Content>
        </Stack>
      </ViewModuleSections>
      {paginatedQuery && query && columns && (
        <ViewModuleSections
          title='Audit logs'
          containerProps={{ width: '100%', marginTop: '30px' }}
        >
          <DataTable
            columns={columns}
            defaultPageSize={10}
            paginatedQuery={paginatedQuery}
            hasRowSelections={false}
            onChangeSelected={() => {}}
            allQuery={query}
            refetch={{}}
            searchFields={[]}
            setPage={setPage}
            page={page}
            onTableChange={(pagination, filters, sorter, extra) => {
              if (extra?.action === 'paginate') {
                setPage(pagination?.current);
              }
            }}
            sortArg={defaultSortArg}
            nameField={paginatedQueryNameField}
            calledFrom={calledFrom}
          />
        </ViewModuleSections>
      )}
    </Stack>
  );
};

export default SystemInfo;
