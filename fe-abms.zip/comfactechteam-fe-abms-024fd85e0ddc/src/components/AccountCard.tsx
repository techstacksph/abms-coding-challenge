import React from 'react';

import { GoogleIcon, Icon, Text } from '@/styled-components';

import Link from '@/components/Link';
import { Status } from '@/constants/Status';
import { getViewRoute } from '@/mfe-utilities';
import AccountModel from '@/models/AccountModel';
import CloseIcon from '@mui/icons-material/Close';
import { Stack, Box } from '@mui/material';

import { FormInstance } from 'antd';

import StatusTag from './StatusTag';

const AccountCard = ({
  record,
  form,
  fieldName,
  onEmpty = 'No selected account.',
  boxWidth = '55%',
  showStatus = true,
  basicTitle = false,
}: {
  record: Array<AccountModel>;
  form: FormInstance;
  fieldName: string;
  onEmpty?: string;
  boxWidth?: string;
  showStatus?: boolean;
  basicTitle?: boolean;
}) => {
  if (!form) {
    boxWidth = '100%';
  }
  const data: AccountModel | null = record.length > 0 ? record[0] : null;
  let converted: string = data?.accountType;
  if (data?.accountType)
    converted =
      String(data?.accountType)[0] +
      String(data?.accountType).substring(1).toLowerCase();
  return (
    <>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: boxWidth }}>
          <Stack direction='row' spacing={1}>
            {record.length > 0 ? (
              <Stack
                direction={'row'}
                gap='4px'
                padding={1}
                width='100%'
                sx={{
                  ':hover': {
                    borderRadius: '8px',
                    backgroundColor: form ? '#F4F4F6' : 'transparent',
                  },
                }}
              >
                <Icon size='28px' color='var(--gray-400)'>
                  <GoogleIcon
                    name='source_environment'
                    fill={true}
                    $css={`
                      padding: 8px;
                      font-size: 28px !important; 
                      background-color: #F4F4F6;
                      border-radius: 50%;
                    `}
                  />
                </Icon>
                <Stack
                  direction='column'
                  spacing={'4px'}
                  sx={{ width: '100%' }}
                >
                  {basicTitle ? (
                    <Text
                      $type='sm'
                      $css={'font-size: 14px; font-weight: 700;'}
                    >
                      {data?.name}
                    </Text>
                  ) : (
                    <Link
                      ellipsis
                      to={`${getViewRoute('Account')}/${data?.id}`}
                      weight='bold'
                      $css={{ maxWidth: '240px !important' }}
                    >
                      {data?.name}
                    </Link>
                  )}
                  <Text $type='sm' $css={'font-size: 14px; font-weight: 400;'}>
                    {converted}
                  </Text>

                  {showStatus && (
                    <Text
                      $type='sm'
                      $css={
                        'font-size: 14px; font-weight: 400; margin-left: 10px; color:#686D78'
                      }
                    >
                      Account status:{' '}
                      {
                        <StatusTag
                          status={Status[data?.status?.name]}
                          $css={`
                          border: none;
                        `}
                        />
                      }
                    </Text>
                  )}
                </Stack>
                {form && (
                  <CloseIcon
                    className='userRemove'
                    onClick={() => {
                      form.setFieldValue(fieldName, null);
                    }}
                    sx={{ color: '#878B97', width: '20px', height: '20px' }}
                  />
                )}
              </Stack>
            ) : (
              <Text
                style={{
                  textAlign: 'center',
                  width: '100%',
                  padding: '16px',
                  color: '#686D78',
                }}
              >
                {onEmpty}
              </Text>
            )}
          </Stack>
        </Box>
      </Stack>
    </>
  );
};

export default AccountCard;
