import React from 'react';

import { ModuleHeader, Button } from '@/styled-components';

import { Box, BoxProps, Stack } from '@mui/material';

const setButtonCSS = props => {
  let css = 'min-width: 120px;';

  if (props && props.saveButtonProps && props.saveButtonProps.css)
    css = `${css} ${props.saveButtonProps.css}`;

  return css;
};

const FormModuleHeader = (
  props: React.ComponentProps<typeof ModuleHeader> & {
    formType: 'new' | 'edit';
    saveButtonProps?: React.ComponentProps<typeof Button>;
    boxProps?: BoxProps;
  }
) => {
  return (
    <Box bgcolor='#fff' borderBottom='1px solid #EDF1F3' {...props?.boxProps}>
      <ModuleHeader
        endDisplay={
          <Stack direction='row' spacing={2} alignItems='center'>
            <Button
              ghost
              $css='width: 120px; color: var(--color-text-primary) !important;'
              onClick={props?.onBackClick}
            >
              Cancel
            </Button>
            <Button
              type='primary'
              htmlType='submit'
              $css={setButtonCSS(props)}
              {...props?.saveButtonProps}
            >
              {props.formType === 'new' ? 'Save' : 'Save Changes'}
            </Button>
          </Stack>
        }
        containerProps={{
          $css: `
            padding-top: 16px;
            padding-bottom: 16px;
            align-items: center;
            
            & [class*="-col"] > [class*="-space"],
            & [class*="-col"] > [class*="-space-item"] {
              display: flex !important
            } 
          `,
        }}
        {...props}
      />
    </Box>
  );
};

export default FormModuleHeader;
