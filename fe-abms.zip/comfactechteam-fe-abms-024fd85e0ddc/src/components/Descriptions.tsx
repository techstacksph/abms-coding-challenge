import React, { ComponentProps } from 'react';

import { Descriptions as BaseDescriptions, Text } from '@/styled-components';

import { Stack } from '@mui/material';

const Descriptions = (
  props: ComponentProps<typeof BaseDescriptions> & {
    hasSubHeader?: boolean;
    subHeader?: string | React.ReactNode;
    labelStyle?: any;
    contentStyle?: any;
    marginTop?: string | number;
    $subHeaderCss?: string;
  }
) => {
  const contentMargin: string | number = props?.marginTop || 0;
  return (
    <Stack
      spacing={2}
      sx={{ marginTop: contentMargin, borderBottom: 'none !important' }}
    >
      {props?.title && (
        <Text $type='sm' weight='medium'>
          {props?.title}
        </Text>
      )}
      {props?.subHeader && (
        <Text
          $type='sm'
          weight='semibold'
          $css={`font-size: 14px !important; ${props.$subHeaderCss}`}
        >
          {props?.subHeader}
        </Text>
      )}
      <BaseDescriptions
        labelStyle={{
          width: props?.labelStyle?.width ?? 160,
          maxWidth: props?.labelStyle?.maxWidth ?? 160,
          color: '#686D78',
          lineHeight: '20px',
          ...props?.labelStyle,
        }}
        contentStyle={{
          color: '#090A0B',
          lineHeight: '20px',
          ...props?.contentStyle,
          whiteSpace: 'pre-line',
        }}
        colon={false}
        {...props}
        title={undefined}
      />
    </Stack>
  );
};

export default Descriptions;
