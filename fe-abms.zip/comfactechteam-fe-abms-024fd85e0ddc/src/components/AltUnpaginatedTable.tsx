import React, { useMemo, useState, SetStateAction } from 'react';

import {
  ModuleTable,
  Button,
  Text,
  MaterialIcon,
  Select,
  GoogleIcon,
  Icon,
  EmptyState,
  Space,
} from '@/styled-components';

import { Box, Stack } from '@mui/material';

import { Checkbox, Dropdown, Form, Pagination } from 'antd';

import ActionButton from '../views/settings/common/components/ActionButton';
import CellForm from '../views/settings/common/components/CellForm';
import ModuleAlert, { ModuleRowSelection } from './ModuleAlert';
import { toSentenceCase } from '@/utils/string.utils';
import styled from 'styled-components';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

const StyledPagination = styled(Pagination)<{
  showPaginationItems?: string;
  $css?: string;
}>`
  & {
    color: var(--black-1) !important;
    font-size: 12px !important;
  }

  & li {
    margin: 0 !important;
  }

  & li[class$='-pagination-total-text'] {
    display: inline;
    padding: 0 8px;
  }

  & li[class*='-pagination-prev'],
  & li[class*='-pagination-next'] {
    padding: 0 4px;
    min-width: 31px;
  }

  & li[class$='-pagination-disabled'] {
    opacity: 0.5;
  }
  .theme-provider-pagination-item-link {
    width: 30px !important;
    height: 30px !important;
    margin-top: 4px !important;
  }
  ${({ showPaginationItems }) =>
    !showPaginationItems &&
    `
      & li[class*='-pagination-item'] {
        display: none !important;
      }
  `}

  ${({ $css }) => $css}
`;

const actionColumn = ({
  isRowEditing,
  onCancel,
  onEdit,
  onDelete,
  saveRecord,
}: {
  isRowEditing: (record: any) => boolean;
  onCancel: (record: any) => void;
  onEdit: (record: any) => void;
  onDelete: (record: any) => void;
  saveRecord: (record: any) => void;
}) => {
  return {
    title: '',
    dataIndex: 'actions',
    key: 'actions',
    width: 110,
    fixed: 'right',
    render: (_, record) => (
      <ActionButton
        isEditing={isRowEditing(record)}
        disabled={false}
        onCancel={() => onCancel(record)}
        submitType='button'
        onSubmit={() => saveRecord(record)}
        actions={[
          {
            key: 'edit',
            label: (
              <a
                onClick={() => {
                  onEdit(record);
                }}
              >
                <Stack direction='row' alignItems='center' spacing={1}>
                  <MaterialIcon
                    name='edit'
                    $css='font-weight: 400; font-size: 24px; color: #878B97'
                  />
                  <Text>Edit</Text>
                </Stack>
              </a>
            ),
          },
          {
            key: 'delete',
            label: (
              <a onClick={() => onDelete(record)}>
                <Stack direction='row' alignItems='center' spacing={1}>
                  <MaterialIcon
                    name='delete'
                    $css='font-weight: 400; font-size: 24px; color: #878B97'
                  />
                  <Text>Delete</Text>
                </Stack>
              </a>
            ),
          },
        ]}
      />
    ),
  };
};

const AltUnpaginatedTable = ({
  columns,
  fields,
  title,
  allData = [],
  setAllData,
  loading = false,
  form,
  setDeleteData,
  setterField,
  otherProps,
  fileName,
  buttonAlignment = 'left',
}: {
  columns: Array<any>;
  fields: any;
  title: { plural: string; singular: string };
  allData?: Array<any>;
  loading: boolean;
  form: any;
  setAllData: SetStateAction<any>;
  setDeleteData?: SetStateAction<any>;
  setterField?: string;
  otherProps?: any;
  fileName?: string;
  buttonAlignment?: 'left' | 'center' | 'right';
}) => {
  const [selected, setSelectedInner] = useState<ModuleRowSelection<any>>({
    selected: [],
  });
  const [addingIds, setAddingIds] = useState<Array<string>>([]);
  const [editingIds, setEditingIds] = useState<Array<string>>([]);
  const [, setActiveButton] = useState<string>();
  const [tableIdx, setTableIdx] = useState<number>(1);
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();

  const [selectionRenderKey, setSelectionRenderKey] = useState<number>(
    Math.random()
  );

  const selectedRendered = useMemo(() => {
    return selected;
  }, [selectionRenderKey]);

  const storeRecord = async (recordId?: string) => {
    const currentId = recordId;
    try {
      // Validate only the fields managed by this table row
      if (currentId) {
        const fieldNames = Object.keys(fields).map(k => [currentId, k]);
        await form.validateFields(fieldNames as any);
      } else {
        await form.validateFields(Object.keys(fields));
      }
    } catch {
      return;
    }

    const fieldData = Object.assign([], allData);
    const idx = fieldData.findIndex(a => a.id == currentId);
    if (idx > -1) {
      const rowValues = currentId
        ? form.getFieldsValue([currentId])?.[currentId] || {}
        : form.getFieldsValue(Object.keys(fields));
      const updateFieldData = {
        id: currentId,
        ...rowValues,
      };

      // Merge into existing record to preserve non-form fields (e.g., task, case)
      fieldData[idx] = { ...fieldData[idx], ...updateFieldData };

      setAllData(fieldData);
      setAddingIds(prev => prev.filter(id => id !== currentId));
      setEditingIds(prev => prev.filter(id => id !== currentId));
      // Notify parent to persist changes
      if (otherProps && typeof otherProps.onStoreRecord === 'function') {
        otherProps.onStoreRecord(updateFieldData);
      }
    } else {
      const rowValues = currentId
        ? form.getFieldsValue([currentId])?.[currentId] || {}
        : form.getFieldsValue(Object.keys(fields));
      const updateFieldData = {
        id: currentId,
        ...rowValues,
      };

      fieldData.push(updateFieldData);

      setAllData(fieldData);
      setAddingIds(prev => prev.filter(id => id !== currentId));
      setEditingIds(prev => prev.filter(id => id !== currentId));
      if (setterField && currentId && addingIds.includes(currentId)) {
        form.setFieldValue(setterField, null);
      }
      if (otherProps && typeof otherProps.onStoreRecord === 'function') {
        otherProps.onStoreRecord(updateFieldData);
      }
    }
  };

  const editRecord = record => {
    const transformed =
      otherProps && typeof otherProps.transformRecordForForm === 'function'
        ? otherProps.transformRecordForForm(record)
        : record;
    // Scope form values by row id to support multiple concurrent edit rows
    form.setFieldsValue({ [record.id]: transformed });
    if (otherProps && otherProps.setter)
      otherProps.setter(form.getFieldValue(setterField));
    setEditingIds(prev =>
      prev.includes(record.id) ? prev : [...prev, record.id]
    );
  };

  const setSelected = (
    value: React.SetStateAction<ModuleRowSelection<any>>
  ) => {
    setSelectedInner(value);
    setSelectionRenderKey(Math.random());
  };

  const setSelectedNoRerender = (
    value: React.SetStateAction<ModuleRowSelection<any>>
  ) => {
    setSelectedInner(value);
  };

  const onAdd = () => {
    //const length = [...allData].length;
    const newData = {
      id: `new-${tableIdx}`,
    };
    setAllData(prevState => [...prevState, newData]);

    // Initialize scoped form values only for the new row
    form.setFieldsValue({ [`new-${tableIdx}`]: newData });
    setEditingIds(prev => [...prev, `new-${tableIdx}`]);
    setAddingIds(prev => [...prev, `new-${tableIdx}`]);

    setTableIdx(Number(tableIdx) + 1);

    if (otherProps && otherProps.setter) otherProps.setter(null);
  };

  const onClickDelete = async () => {
    const ids = selected.selected.map(a => a.id);
    const toDeleteIds = ids.filter(a => !String(a).startsWith('new-'));

    // Check canDeleteRecord for each selected row before proceeding
    if (otherProps?.canDeleteRecord) {
      const blockedRecords = selected.selected.filter(
        record => !otherProps.canDeleteRecord(record)
      );
      if (blockedRecords.length > 0) {
        // Still call setDeleteData to trigger the error message callback
        // but don't remove rows from UI
        setDeleteData(prevState => [...prevState, ...toDeleteIds]);
        setSelected({ selected: [], type: 'multiple' });
        return;
      }
    }

    setDeleteData(prevState => [...prevState, ...toDeleteIds]);

    const fieldData = Object.assign([], allData);
    for (const id of ids) {
      const idx = fieldData.findIndex(a => a.id == id);
      if (idx > -1) {
        fieldData.splice(idx, 1);
      }
    }

    setAllData(fieldData);
    setSelected({ selected: [], type: 'multiple' });
  };

  const onCancel = async (recordId?: string) => {
    const currentId = recordId;
    setActiveButton('cancel');

    if (currentId && addingIds.includes(currentId)) {
      setAllData(prevState => prevState.filter(a => a.id !== currentId));
      setAddingIds(prev => prev.filter(id => id !== currentId));
    }
    if (currentId) {
      const fieldNames = Object.keys(fields).map(k => [currentId, k]);
      form.resetFields(fieldNames as any);
      setEditingIds(prev => prev.filter(id => id !== currentId));
    } else {
      // Fallback: clear all editing states
      setEditingIds([]);
      setAddingIds([]);
    }
  };

  const tableColumns = useMemo(() => {
    const actionCol = actionColumn({
      isRowEditing: record => editingIds.includes(record.id),
      onCancel: record => onCancel(record.id),
      onEdit: record => {
        editRecord(record);
      },
      onDelete: record =>
        setSelectedNoRerender({ selected: [record], type: 'single' }),
      saveRecord: record => {
        storeRecord(record.id);
      },
    });
    const tableCol = [...columns];
    tableCol.push(actionCol);

    return tableCol.map(c => {
      if (!fields[c.dataIndex]) return c;

      const style = c?.meta ? c.meta?.onCellStyle : {};

      return {
        ...c,
        onCell: record => ({
          key: record.id,
          formProps: {
            ...fields[c.dataIndex],
            // Scope form field by row id to avoid collisions
            field: [record.id, fields[c.dataIndex]?.field || c.dataIndex],
          },
          otherProps,
          fileName,
          isEditing: editingIds.includes(record.id),
          style: {
            ...style,
            textAlign: fields[c.dataIndex].type === 'number' ? 'right' : 'left',
          },
        }),
      };
    });
  }, [editingIds.join(','), addingIds.join(',')]);

  // Map buttonAlignment to justifyContent value
  const getJustifyContent = alignment => {
    switch (alignment) {
      case 'center':
        return 'center';
      case 'right':
        return 'flex-end';
      case 'left':
      default:
        return 'flex-start';
    }
  };

  return (
    <Form form={form} component={false}>
      <ModuleTable
        width='100px'
        columns={tableColumns}
        data={allData}
        emptyState={<EmptyState iconW='200px' title='No data to display.' />}
        loading={loading}
        rowSelection={{
          columnWidth: 68,
          onChange: (_, selectedRows) =>
            setSelected({ selected: selectedRows, type: 'multiple' }),
          renderCell: (checked, record, index, originNode) => {
            return (
              <div style={{ paddingRight: '22px' }}>
                <Checkbox
                  {...originNode.props}
                  disabled={editingIds.includes(record.id)}
                />
              </div>
            );
          },
          selectedRowKeys: selectedRendered.selected.map(d => d.id),
          columnTitle: () => {
            const handleSelectType = (type: SelectAllMenuTypes) => {
              setSelectType(type);
              if (type === 'this') {
                setSelected({ selected: allData, type: 'multiple' });
              } else if (type === 'all') {
                const allRecords = otherProps?.allRecords || allData;
                setSelected({ selected: allRecords, type: 'multiple' });
              } else {
                setSelected({ selected: [], type: 'multiple' });
              }
            };

            const totalCount = otherProps?.allRecords?.length ?? allData.length;
            const isChecked = Boolean(selectType) && selectType != 'deselect';
            const isIndeterminate =
              selectType === 'this' ||
              (selectedRendered.selected.length > 0 &&
                selectedRendered.selected.length !== totalCount &&
                selectType != 'all');

            return (
              <Dropdown
                menu={{
                  items: [
                    {
                      key: 'thisPage',
                      label: 'Select this page',
                      onClick: () => handleSelectType('this'),
                    },
                    {
                      key: 'allPage',
                      label: 'Select all page',
                      onClick: () => handleSelectType('all'),
                    },
                    {
                      key: 'deselectAll',
                      label: 'Deselect all',
                      onClick: () => handleSelectType('deselect'),
                    },
                  ],
                }}
                trigger={['click']}
              >
                <a role='button'>
                  <Stack direction='row' alignItems='center' spacing={0.5}>
                    <Checkbox
                      checked={isChecked}
                      indeterminate={isIndeterminate}
                    />
                    <Icon color='var(--gray-600)'>
                      <MaterialIcon name='arrow_drop_down' />
                    </Icon>
                  </Stack>
                </a>
              </Dropdown>
            );
          },
        }}
        tableProps={{
          tableLayout: 'fixed',
          components: {
            body: {
              cell: CellForm,
            },
          },
          // summary: () => (
          //   <tr style={{ display: 'initial' }}>
          //     <td colSpan={columns.length}>

          //     </td>
          //   </tr>
          // ),
        }}
        hidePagination
      />
      <Stack
        padding='8px 0px'
        borderBottom='1px solid #D3D5D9'
        width='100%'
        direction='row'
        justifyContent={getJustifyContent(buttonAlignment)}
      >
        <Button
          type='text'
          icon={<MaterialIcon name='add' />}
          onClick={onAdd}
          $css='border-radius: 8px; padding: 8px 12px; color: #3137FD;border: 1px solid #3137FD; min-width: 120px;'
        >
          <Text
            $css='font-size: 14px; font-weight: 600;'
            weight='semibold'
            color='#3137FD'
          >
            {toSentenceCase(title.singular)}
          </Text>
        </Button>
      </Stack>
      {otherProps?.pagination && (
        <Space align='center' $css={'column-gap: 0;'}>
          <Box
            sx={{
              padding: '0 8px',
              paddingLeft: '0px !important',
              height: '56px',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Text $type='xs' color='var(--color-text-primary)'>
              Rows per page
            </Text>
          </Box>
          <Select
            size='small'
            defaultValue={otherProps.pagination.pageSize}
            value={otherProps.pagination.pageSize}
            allowClear={false}
            options={[
              {
                label: '10',
                value: 10,
              },
              {
                label: '20 ',
                value: 20,
              },
              {
                label: '50',
                value: 50,
              },
              {
                label: '100',
                value: 100,
              },
            ]}
            onChange={value => {
              if (otherProps.pagination.onPageSizeChange) {
                otherProps.pagination.onPageSizeChange(value);
              }
            }}
            data-testid='module-table-page-size-select'
            suffixIcon={
              <GoogleIcon
                name='arrow_drop_down'
                $css={'color: var(--color-text-primary)'}
              />
            }
            $css={`
              /* SELECT STYLES WHEN FOCUSED */
              &[class*="-select-focused"] [class*="-select-selector"] {
                box-shadow: none;
              }

              [class$="select-selection-item"] {
                color: var(--black-1) !important;
                font-size: 12px;
                padding-inline-end: 24px !important;
              }
              [class$="select-selector"] {
                gap: 4px;
                padding: 0 4px;
                border-width: 0 !important;
              }

            `}
            data-cy='module-table-select-pagination'
          />
          <StyledPagination
            total={
              otherProps.pagination.pageInfo?.count ??
              otherProps?.allRecords?.length ??
              allData.length
            }
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total}`}
            pageSize={otherProps.pagination.pageSize}
            current={otherProps.pagination.page}
            onChange={p => otherProps.pagination.onPageChange?.(p)}
            showSizeChanger={false}
            itemRender={(_, type, originalElement) => {
              // if (type === 'prev') {
              //   return (
              //     <GoogleIcon
              //       name='arrow_back_ios_new'
              //       $css={'color: #7B8B99; font-size: 16px;'}
              //       data-testid='module-table-pagination-prev'
              //     />
              //   );
              // }
              // if (type === 'next') {
              //   return (
              //     <GoogleIcon
              //       name='arrow_forward_ios'
              //       $css={'color: #7B8B99; font-size: 16px;'}
              //       data-testid='module-table-pagination-next'
              //     />
              //   );
              // }
              return originalElement;
            }}
            data-cy='module-table-pagination'
            data-testid='module-table-pagination'
          />
        </Space>
      )}
      <ModuleAlert
        loading={false}
        selected={selected}
        message={
          selected.type === 'single' ? (
            <Text>
              Are you sure you want to move{' '}
              {selected.selected?.[0]?.title || title.singular.toLowerCase()} to
              the recycle bin?
            </Text>
          ) : (
            <Text>
              Are you sure you want to move all selected action plan(s) to the
              recycle bin?
            </Text>
          )
        }
        title={
          selected.type === 'single'
            ? title.singular.toLowerCase()
            : title.plural.toLowerCase()
        }
        onDelete={async () => await onClickDelete()}
        onClose={() => setSelected({ selected: [], type: 'multiple' })}
        onExport={undefined}
      />
    </Form>
  );
};

export default AltUnpaginatedTable;
