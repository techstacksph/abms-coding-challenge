import React, { memo } from 'react';

import { Icon, Text, GoogleIcon } from '@/styled-components';

import Link from '@/components/Link';
import { getListRoute } from '@/mfe-utilities';
import { Box, Stack } from '@mui/material';

const ListTaskItems = ({
  data,
  dataKey,
}: {
  data: Array<any>;
  dataKey: string | Array<string>;
}) => {
  return (
    <Stack justifyContent='space-between' marginTop='16px' maxWidth='500px'>
      <Text $type='sm' color='var(--color-text-secondary)'>
        Tasks
      </Text>
      <Box
        maxHeight='200px'
        overflow='auto'
        sx={{
          overflowX: 'hidden',
          '&::-webkit-scrollbar': {
            width: '16px',
            backgroundColor: 'transparent',
          },

          '&::-webkit-scrollbar-track': {
            backgroundColor: 'transparent',
            borderLeft: '1px solid #D3D5D9',
            borderRight: '1px solid #D3D5D9',
          },

          '&::-webkit-scrollbar-thumb': {
            background: 'rgba(167, 170, 178, 0.5)',
            borderRadius: '24px',
            border: '4px solid transparent',
            width: '4px',
            backgroundClip: 'padding-box',
          },

          scrollbarWidth: 'medium',
          scrollbarColor: 'rgba(167, 170, 178, 0.5) transparent',
        }}
      >
        {data &&
          data.map((task: any & { id: string }) => (
            <Stack
              key={task.id}
              direction='row'
              spacing={1}
              alignItems='center'
              borderRadius={2}
              px={0.5}
              py={1}
            >
              <Box
                sx={{
                  width: 24,
                  height: 24,
                  backgroundColor: '#F4F4F6',
                  borderRadius: 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  lineHeight: 0,
                  flexShrink: 0,
                }}
              >
                <Icon
                  size='xs'
                  color='#878B97'
                  $customIcon
                  $css={`
                    & [class^='Mui'] {
                      vertical-align: middle !important;
                      font-size: 16px; /* Explicitly set icon size if needed */
                    }
                  `}
                >
                  <GoogleIcon name='task_alt' />
                </Icon>
              </Box>
              <Text
                $type='sm'
                color='#3137FD'
                $css={`
                  cursor: pointer;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  display: block;
                  min-width: 0;
                `}
              >
                <Link
                  $css={{ fontWeight: 500 }}
                  to={`${getListRoute('Tasks')}/${task?.id}`}
                >
                  {Array.isArray(dataKey)
                    ? dataKey.map(k => task[k]).join(' ')
                    : task[dataKey]}
                </Link>
              </Text>
            </Stack>
          ))}
      </Box>
    </Stack>
  );
};

export default memo(ListTaskItems);
