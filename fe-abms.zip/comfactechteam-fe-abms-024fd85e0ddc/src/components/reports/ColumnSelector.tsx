import React, { useEffect, useState } from 'react';

import { styled } from 'styled-components';

import { Stack } from '@mui/material';

import { Divider, Form, Select } from 'antd';

import { Space } from '@/styled-components/components/containers';
import { GoogleIcon } from '@/styled-components/components/icons';
import Checkbox from '@/styled-components/components/inputs/Checkbox';
import { Text } from '@/styled-components/components/typography';

export interface ColumnOption {
  key: string;
  title: string;
  defaultVisible?: boolean;
}

export interface ColumnSelectorProps {
  columns: ColumnOption[];
  visibleColumns: string[];
  onChange: (visibleKeys: string[]) => void;
  disabled?: boolean;
}

const StyledSelect = styled(Select)<{ $css?: string }>`
  & [class$='-select-selector'] {
    border-color: var(--gray-300) !important;
    gap: 8px;
    min-width: 150px;
  }

  & [class$='-select-selector']:hover {
    border-color: var(--gray-600) !important;
  }

  & [class$='select-selector']:focus {
    border-color: var(--input-focus-border-color);
    outline-color: var(--input-focus-outline-color);
  }

  & [class$='-select-selection-item'] {
    background-color: transparent;
    margin: 0px;
    font-weight: 700 !important;
  }

  & [class$='-select-arrow'] {
    color: #7b8b99;
  }

  ${({ $css }) => $css}
`;

const ColumnSelector: React.FC<ColumnSelectorProps> = ({
  columns,
  visibleColumns,
  onChange,
  disabled,
}) => {
  const [selectedKeys, setSelectedKeys] = useState<string[]>(visibleColumns);

  useEffect(() => {
    setSelectedKeys(visibleColumns);
  }, [visibleColumns]);

  const handleChange = (value: unknown) => {
    const keys = value as string[];
    setSelectedKeys(keys);
    onChange(keys);
  };

  const handleSelectAllChange = (checked: boolean) => {
    const newKeys = checked ? columns.map(col => col.key) : [];
    setSelectedKeys(newKeys);
    onChange(newKeys);
  };

  const allSelected = selectedKeys.length === columns.length;
  const someSelected =
    selectedKeys.length > 0 && selectedKeys.length < columns.length;

  const arrowIcon = (
    <GoogleIcon name='arrow_drop_down' $css='color: rgba(135, 139, 151, 1);' />
  );

  return (
    <Form.Item style={{ margin: 0 }}>
      <StyledSelect
        mode='multiple'
        placeholder={
          <Space>
            <GoogleIcon name='view_column' $css='color: #7B8B99;' />
            <Text>Columns</Text>
          </Space>
        }
        onChange={handleChange}
        value={selectedKeys}
        maxTagCount={0}
        maxTagPlaceholder={() => (
          <Space>
            <GoogleIcon name='view_column' $css='color: #7B8B99;' />
            <Text>
              {selectedKeys.length === columns.length
                ? 'All columns'
                : `${selectedKeys.length} columns`}
            </Text>
          </Space>
        )}
        disabled={disabled}
        menuItemSelectedIcon={<></>}
        suffixIcon={arrowIcon}
        popupRender={menu => (
          <>
            <Stack sx={{ padding: '9px 12px' }}>
              <Checkbox
                onChange={handleSelectAllChange as any}
                checked={allSelected}
                indeterminate={someSelected}
              >
                Select/Deselect All
              </Checkbox>
            </Stack>
            <Divider style={{ margin: '0' }} />
            {menu}
          </>
        )}
      >
        {columns.map(col => (
          <Select.Option key={col.key} value={col.key} label={col.title}>
            <Stack direction='row' spacing={1} sx={{ float: 'left' }}>
              <Checkbox checked={selectedKeys.includes(col.key)} />
              <span>{col.title}</span>
            </Stack>
          </Select.Option>
        ))}
      </StyledSelect>
    </Form.Item>
  );
};

export default ColumnSelector;
