import React from 'react';

import { styled } from 'styled-components';

import { Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';

export interface NestedTableProps {
  columns: ColumnsType<any>;
  data: any[];
  rowKey?: string;
}

const StyledTable = styled(Table)`
  table thead {
    font-size: 14px;
    font-weight: 500;
  }

  table thead td,
  table thead th {
    border-bottom: 1px solid #e6eaec !important;
    font-weight: 500 !important;
  }

  table tbody tr > td {
    border-color: var(--gray-200) !important;
  }

  .ant-table {
    border: none !important;
  }
`;

const NestedTable: React.FC<NestedTableProps> = ({
  columns,
  data,
  rowKey = 'id',
}) => {
  return (
    <StyledTable
      columns={columns}
      dataSource={data}
      pagination={false}
      size='small'
      rowKey={rowKey}
    />
  );
};

export default NestedTable;
