import React from 'react';
import { Box, Divider, Grid, Stack } from '@mui/material';

import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components';
import Link from '@/components/Link';

export interface ReportItem {
  key: string;
  title: string;
  description?: string;
  route: string;
}

export interface ReportCardProps {
  title: string;
  items: ReportItem[];
  columns?: number;
}

const cardTitleCss = `
  color: #090A0B;
  font-family: "Hanken Grotesk";
  font-size: 16px;
  font-style: normal;
  font-weight: 600;
  line-height: 24px;
`;

const itemDescriptionCss = `
  color: var(--Colors-text-secondary, #686D78);
  font-family: "Hanken Grotesk";
  font-size: 12px;
  font-style: normal;
  font-weight: 400;
  line-height: 18px;
`;

const ReportCard: React.FC<ReportCardProps> = ({
  title,
  items,
  columns = 4,
}) => {
  const getGridSize = () => {
    const itemCount = items.length;

    // If items fit in one row, spread them evenly
    if (itemCount <= columns) {
      return Math.floor(12 / itemCount);
    }

    // Otherwise use the column-based calculation
    switch (columns) {
      case 1:
        return 12;
      case 2:
        return 6;
      case 3:
        return 4;
      case 4:
      default:
        return 3;
    }
  };

  return (
    <Card
      padding='20px'
      $css={`
        border: 1px solid #D3D5D9;
        border-radius: 12px;
      `}
    >
      <Stack>
        <Box>
          <Text $css={cardTitleCss}>{title}</Text>
          <Divider sx={{ marginTop: '8px', borderColor: '#D3D5D9' }} />
        </Box>
        <Grid container spacing={2} sx={{ marginTop: 0 }}>
          {items.map(item => (
            <Grid item xs={12} sm={6} md={getGridSize()} key={item.key}>
              <Stack
                spacing={0.5}
                sx={{
                  padding: '8px',
                  borderBottom: '1px solid #F4F4F6',
                }}
              >
                <Link
                  to={item.route}
                  weight='medium'
                  $css={`
                    color: #3137FD;
                    font-family: "Hanken Grotesk";
                    font-size: 14px;
                    font-style: normal;
                    font-weight: 500;
                    line-height: 20px;
                  `}
                >
                  {item.title}
                </Link>
                <Text $css={itemDescriptionCss}>
                  {item.description || 'Add description'}
                </Text>
              </Stack>
            </Grid>
          ))}
        </Grid>
      </Stack>
    </Card>
  );
};

export default ReportCard;
