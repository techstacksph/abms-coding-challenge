import React, {
  ChangeEventHandler,
  ReactNode,
  useMemo,
  useState,
  useEffect,
  useRef,
} from 'react';

import { styled } from 'styled-components';

import { MoreVert } from '@mui/icons-material';
import { Box, Grid } from '@mui/material';

import { Dropdown, Pagination, PaginationProps, Spin, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import { Space } from '@/styled-components/components/containers';
import {
  GoogleIcon,
  Icon,
  MaterialIcon,
} from '@/styled-components/components/icons';
import { Button, Input } from '@/styled-components/components/inputs';
import Select from '@/styled-components/components/inputs/Select';
import { Text } from '@/styled-components/components/typography';
import EmptyState from '@/styled-components/components/vectors/EmptyState';
import ModuleFilter, {
  MoreFilterWindowType,
} from '@/styled-components/components/module/ModuleFilter';
import {
  TableAction,
  TableFilters,
  TablePageInfo,
} from '@/styled-components/types/table.types';
import { isValueValid } from '@/utils/helper.utils';
import { MIN_SEARCH_LENGTH } from '@/constants/ui';

import ColumnSelector, { ColumnOption } from './ColumnSelector';
import NestedTable from './NestedTable';

export interface ReportTableColumn {
  key: string;
  title: string;
  dataIndex: string;
  width?: number;
  render?: (value: any, record: any, index: number) => ReactNode;
  sorter?: boolean;
  fixed?: 'left' | 'right';
  defaultVisible?: boolean;
}

export interface GroupConfig {
  childColumns: ColumnsType<any>;
  childDataKey: string;
  nestedBoxSx?: object;
}

export interface ReportTableProps {
  // Identity
  tableId?: string;

  // Data
  columns: ReportTableColumn[];
  data: any[];
  loading?: boolean;
  rowKey?: string;

  // Filters (similar to ModuleActions)
  filters?: TableFilters[];
  onChangeFilter?: (filters: object) => void;
  onSearch?: ChangeEventHandler<HTMLInputElement>;
  onDateTypeChange?: (field: string, dateType: string) => void;
  moreFilterWindowType?: MoreFilterWindowType;
  maxShownFilters?: number;
  $searchProps?: React.ComponentProps<typeof Input.Text>;
  filterContent?: ReactNode; // For additional custom filter content
  showSearch?: boolean; // Show/hide search input (default: true)

  // Features
  enableColumnSelector?: boolean;
  enableExpandableRows?: boolean;
  expandedRowRender?: (record: any) => ReactNode;
  groupConfig?: GroupConfig;
  enableVirtualScroll?: boolean;
  scrollY?: number;

  // Pagination
  pageInfo?: TablePageInfo;
  onChangePageSize?: (size: number) => void;
  paginationProps?: PaginationProps;
  hidePagination?: boolean;

  // Actions
  actions?: TableAction[];

  // Styling
  $css?: string;
}

const StyledTable = styled(Table)<{ $css?: string }>`
  width: 100%;

  table {
    width: 100% !important;
  }

  table tbody td:empty:before {
    content: 'No data';
    display: inline-block;
    color: var(--table-no-data);
  }

  table thead {
    font-size: 14px;
    font-weight: 500;
    height: 56px;
  }

  table thead td,
  table thead th {
    border-bottom: 1px solid #e6eaec !important;
    font-weight: 500 !important;
  }

  table thead tr th:first-child:not(.theme-provider-table-row-expand-icon-cell),
  table
    tbody
    tr
    td:first-child:not(.theme-provider-table-row-expand-icon-cell) {
    padding-left: 16px !important;
  }

  /* Custom expand column styles */
  .expand-col,
  th.expand-col,
  td.expand-col {
    width: 40px !important;
    min-width: 40px !important;
    max-width: 40px !important;
    padding: 0 8px !important;
    box-sizing: border-box !important;
  }

  table thead tr th:last-child,
  table tbody tr td:last-child {
    padding-right: 16px !important;
  }

  table tbody tr > td {
    height: 56px;
    border-color: var(--gray-200) !important;
  }

  table thead tr > th [class$='-checkbox-inner'],
  table tbody tr > td [class$='-checkbox-inner'] {
    border: 2px solid rgba(167, 170, 178, 1) !important;
    width: 18px;
    height: 18px;
  }

  table [class$='-checkbox-checked'] > [class$='-checkbox-inner'] {
    border: 2px solid #3137fd !important;
  }

  ${({ $css }) => $css}
`;

const StyledPagination = styled(Pagination)`
  & {
    color: var(--black-1) !important;
    font-size: 12px !important;
  }

  & li {
    margin: 0 !important;
  }

  & li[class$='-pagination-total-text'] {
    display: inline;
    padding: 0 8px;
  }

  & li[class*='-pagination-prev'],
  & li[class*='-pagination-next'] {
    padding: 0 4px;
    min-width: 31px;
  }

  & li[class$='-pagination-disabled'] {
    opacity: 0.5;
  }

  & li[class*='-pagination-item'] {
    display: none !important;
  }
`;

const ReportTable: React.FC<ReportTableProps> = ({
  columns,
  data = [],
  loading,
  rowKey = 'id',
  filters = [],
  onChangeFilter,
  onSearch,
  onDateTypeChange,
  moreFilterWindowType = 'popup',
  maxShownFilters = 10,
  $searchProps = { placeholder: 'Search' },
  filterContent,
  showSearch = true,
  enableColumnSelector = true,
  enableExpandableRows,
  expandedRowRender,
  groupConfig,
  enableVirtualScroll,
  scrollY = 500,
  pageInfo,
  onChangePageSize,
  paginationProps,
  hidePagination,
  actions,
  $css,
}) => {
  // Search change handler to enforce minimum of 3 characters before triggering onSearch
  const handleSearchChange: ChangeEventHandler<HTMLInputElement> = e => {
    const value = e.target.value;
    // Only trigger search if value is empty/null/undefined OR length >= MIN_SEARCH_LENGTH
    if (!isValueValid(value) || value.length >= MIN_SEARCH_LENGTH) {
      if (onSearch) onSearch(e);
    }
  };
  // Column visibility state
  const [visibleColumnKeys, setVisibleColumnKeys] = useState<string[]>(() => {
    return columns.filter(c => c.defaultVisible !== false).map(c => c.key);
  });

  // Track expanded rows for custom expand implementation
  const [expandedRows, setExpandedRows] = useState<React.Key[]>([]);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const toggleExpand = (key: React.Key) => {
    setExpandedRows(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  // Use MutationObserver to force expand column width in colgroup
  useEffect(() => {
    if ((!enableExpandableRows && !groupConfig) || !tableContainerRef.current)
      return;

    const fixExpandColumnWidth = () => {
      const colgroup = tableContainerRef.current?.querySelector('colgroup');
      if (colgroup && colgroup.firstElementChild) {
        const col = colgroup.firstElementChild as HTMLElement;
        col.style.setProperty('width', '40px', 'important');
        col.style.setProperty('min-width', '40px', 'important');
      }
    };

    // Fix immediately
    fixExpandColumnWidth();

    // Watch for changes and re-apply
    const observer = new MutationObserver(() => {
      fixExpandColumnWidth();
    });

    observer.observe(tableContainerRef.current, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'width'],
    });

    return () => observer.disconnect();
  }, [enableExpandableRows, groupConfig, data, loading]);

  // Filter columns based on visibility
  const visibleColumns = useMemo(() => {
    let cols: ColumnsType<any> = columns
      .filter(col => visibleColumnKeys.includes(col.key))
      .map(col => ({
        ...col,
        sortIcon: col.sorter
          ? () => <GoogleIcon name='unfold_more' $css='font-size: inherit;' />
          : undefined,
      }));

    // Add custom expand column as first column when expandable
    if (enableExpandableRows || groupConfig) {
      const expandColumn: ColumnsType<any>[0] = {
        title: '',
        key: '__expand__',
        width: 40,
        className: 'expand-col',
        onHeaderCell: () => ({
          style: { width: 40, minWidth: 40, maxWidth: 40, padding: '0 8px' },
          className: 'expand-col',
        }),
        onCell: () => ({
          style: { width: 40, minWidth: 40, maxWidth: 40, padding: '0 8px' },
          className: 'expand-col',
        }),
        render: (_, record) => {
          const key = record[rowKey];
          const isExpanded = expandedRows.includes(key);
          return (
            <Box
              onClick={() => toggleExpand(key)}
              sx={{
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <GoogleIcon
                name={isExpanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down'}
                $css='font-size: 20px;'
              />
            </Box>
          );
        },
      };
      cols = [expandColumn, ...cols];
    }

    // Add actions column if provided
    if (actions && actions.length > 0) {
      cols = [
        ...cols,
        {
          title: '',
          width: 50,
          key: 'actions',
          fixed: 'right',
          render: (_, record) => (
            <Dropdown
              trigger={['click']}
              menu={{
                items: actions
                  .filter(a => (a.show ? a.show(record) : true))
                  .map((a, i) => ({
                    key: a.field || i,
                    disabled:
                      typeof a.disabled === 'function'
                        ? a.disabled(record)
                        : a.disabled,
                    label: (
                      <a onClick={() => a.onClick?.(record)}>
                        <Space $css='color: var(--text-primary-black)'>
                          {a.icon && (
                            <Icon color={a.iconColor ?? '#878B97'}>
                              {a.icon}
                            </Icon>
                          )}
                          {a.title}
                        </Space>
                      </a>
                    ),
                  })),
              }}
              placement='bottomRight'
            >
              <Button
                type='text'
                $inTable
                icon={
                  <Icon color='var(--gray-500)'>
                    <MoreVert />
                  </Icon>
                }
              />
            </Dropdown>
          ),
        },
      ];
    }

    return cols;
  }, [
    columns,
    visibleColumnKeys,
    actions,
    enableExpandableRows,
    groupConfig,
    expandedRows,
    rowKey,
  ]);

  // Column options for selector
  const columnOptions: ColumnOption[] = columns.map(col => ({
    key: col.key,
    title: col.title,
    defaultVisible: col.defaultVisible,
  }));

  // Expandable config - uses our custom expand column, hides default icon
  const expandableConfig = useMemo(() => {
    if (!enableExpandableRows && !groupConfig) return undefined;

    return {
      expandedRowKeys: expandedRows,
      showExpandColumn: false, // Completely hide Ant Design's expand column - we use custom column
      expandedRowRender: groupConfig
        ? (record: any) => (
            <Box
              sx={{
                marginLeft: '40px',
                paddingY: '10px',
                ...groupConfig.nestedBoxSx,
              }}
            >
              <NestedTable
                columns={groupConfig.childColumns}
                data={record[groupConfig.childDataKey] || []}
              />
            </Box>
          )
        : expandedRowRender,
    };
  }, [enableExpandableRows, expandedRowRender, groupConfig, expandedRows]);

  return (
    <Space
      direction='vertical'
      $css={`
        width: 100%;
        background-color: #fff;
        border: 1px solid #D3D5D9;
        border-radius: 12px;
        ${$css}
      `}
      size={0}
    >
      {/* Filter Bar */}
      {(enableColumnSelector ||
        onSearch ||
        filters.length > 0 ||
        filterContent) && (
        <Box sx={{ padding: '16px' }}>
          <Grid container spacing={2} alignItems='center'>
            {/* Date filter first (if exists) */}
            {filters.filter(f => f.type === 'date').length > 0 && (
              <ModuleFilter
                filters={filters.filter(f => f.type === 'date')}
                onChangeFilter={onChangeFilter}
                onDateTypeChange={onDateTypeChange}
                disabled={loading}
                maxShownFilters={maxShownFilters}
                moreFilterWindowType={moreFilterWindowType}
                hasCustom={false}
              />
            )}
            {/* Flex spacer to push other filters to the right */}
            <Grid item sx={{ flex: 1 }} />
            {/* Column selector after date filter */}
            {enableColumnSelector && (
              <Grid item>
                <ColumnSelector
                  columns={columnOptions}
                  visibleColumns={visibleColumnKeys}
                  onChange={setVisibleColumnKeys}
                />
              </Grid>
            )}
            {/* Search input */}
            {showSearch && onSearch && (
              <Grid item>
                <Input.Text
                  allowClear={{
                    clearIcon: (
                      <span
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          backgroundColor: '#878b97',
                          color: '#FFFFFF',
                          borderRadius: '50%',
                          width: '15px',
                          height: '15px',
                        }}
                      >
                        <MaterialIcon name='clear' $css='font-size: 12px;' />
                      </span>
                    ),
                  }}
                  prefix={
                    <MaterialIcon
                      name='search'
                      $css='font-size: 18px; color: #878B97;'
                    />
                  }
                  onChange={handleSearchChange}
                  $css={`
                    width: 248px;
                    height: 40px !important;
                    [class$="input-prefix"] {
                      color: var(--gray-500);
                      margin-inline-end: 8px !important;
                    }
                    input::placeholder {
                      color: var(--gray-500);
                    }
                    [class$="input-group-addon"] {
                      background-color: #fff;
                    }
                  `}
                  disabled={loading}
                  data-cy='report-table-input-search'
                  {...$searchProps}
                />
              </Grid>
            )}
            {/* Other filters (non-date) */}
            {filters.filter(f => f.type !== 'date').length > 0 && (
              <ModuleFilter
                filters={filters.filter(f => f.type !== 'date')}
                onChangeFilter={onChangeFilter}
                onDateTypeChange={onDateTypeChange}
                disabled={loading}
                maxShownFilters={maxShownFilters}
                moreFilterWindowType={moreFilterWindowType}
                hasCustom={false}
              />
            )}
            {filterContent}
          </Grid>
        </Box>
      )}

      {/* Table */}
      <Spin spinning={loading} style={{ width: '100%' }}>
        <Box ref={tableContainerRef} sx={{ px: '20px', width: '100%' }}>
          <StyledTable
            size='small'
            dataSource={data}
            columns={visibleColumns}
            pagination={false}
            rowKey={rowKey}
            expandable={expandableConfig}
            virtual={enableVirtualScroll}
            scroll={enableVirtualScroll ? { y: scrollY } : undefined}
            locale={{ emptyText: <EmptyState /> }}
            $css={$css}
          />
        </Box>
      </Spin>

      {/* Pagination */}
      {!hidePagination && (
        <Space align='center' $css='column-gap: 0; padding: 8px 16px;'>
          <Box sx={{ padding: '0 8px', display: 'flex', alignItems: 'center' }}>
            <Text $type='xs' color='var(--color-text-primary)'>
              Rows per page
            </Text>
          </Box>
          <Select
            size='small'
            defaultValue={pageInfo?.pageCount ?? 10}
            allowClear={false}
            options={[
              { label: '10', value: 10 },
              { label: '20', value: 20 },
              { label: '50', value: 50 },
              { label: '100', value: 100 },
            ]}
            onChange={value => onChangePageSize?.(value)}
            suffixIcon={
              <GoogleIcon
                name='arrow_drop_down'
                $css='color: var(--color-text-primary)'
              />
            }
            $css={`
              &[class*="-select-focused"] [class*="-select-selector"] {
                box-shadow: none;
              }
              [class$="select-selection-item"] {
                color: var(--black-1) !important;
                font-size: 12px;
                padding-inline-end: 24px !important;
              }
              [class$="select-selector"] {
                gap: 4px;
                padding: 0 4px;
                border-width: 0 !important;
              }
            `}
          />
          <StyledPagination
            total={pageInfo?.count ?? 0}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total}`}
            pageSize={pageInfo?.pageSize ?? 10}
            itemRender={(_, type, originalElement) => {
              if (type === 'prev') {
                return (
                  <GoogleIcon
                    name='arrow_back_ios_new'
                    $css='color: #7B8B99; font-size: 16px;'
                  />
                );
              }
              if (type === 'next') {
                return (
                  <GoogleIcon
                    name='arrow_forward_ios'
                    $css='color: #7B8B99; font-size: 16px;'
                  />
                );
              }
              return originalElement;
            }}
            {...paginationProps}
          />
        </Space>
      )}
    </Space>
  );
};

export default ReportTable;
