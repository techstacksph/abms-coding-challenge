import React from 'react';

import { Text, Checkbox } from '@/styled-components';

import { Stack, Box } from '@mui/material';

type Props = {
  data: {
    leadQuestion: string;
    type: string;
    answer: string;
    id: string;
    options: string[];
  }[];
};

const cleanAndSplitCommaSeparated = str => {
  if (!str || typeof str !== 'string') return [];

  return str
    .split(',')
    .map(item => item.trim())
    .filter(item => item !== '');
};

const QuestionFieldsComponent = ({ data }: Props) => {
  const renderFields = data?.map((item, index: number) => {
    if (item?.type === 'FILL_IN_THE_BLANKS') {
      const parseAnswer = item.answer;
      const questionName = item.leadQuestion;
      const questionParts = questionName?.split('_');
      const answerValues = parseAnswer.split(', ');

      return (
        <Stack
          key={item.id || index}
          direction='row'
          alignItems='center'
          marginBottom={2}
        >
          <Box
            sx={{
              minWidth: '20px',
              minHeight: '20px',
              maxWidth: '20px',
              maxHeight: '20px',
              borderRadius: '50%',
              bgcolor: '#A7AAB2',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: '8px',
              fontSize: 12,
              color: '#fff',
            }}
          >
            <Text $css={'color:#fff'}>{index + 1}</Text>
          </Box>
          <Box>
            {questionParts.map((part, i) => (
              <React.Fragment key={i}>
                {i > 0 && <Text>{` ${answerValues[i - 1]} `}</Text>}
                <Text $css={'color:#686D78; font-weight: 500'}>{part}</Text>
              </React.Fragment>
            ))}
          </Box>
        </Stack>
      );
    } else if (item?.type === 'MULTIPLE_ANSWER') {
      const questionName = item.leadQuestion;
      const opt = item?.options?.map(option => {
        const optionName = Object.fromEntries(
          option?.split('|').map(part => part.split(':'))
        );
        return optionName;
      });
      const answer = item?.answer?.split(',').map(part => part?.trim());
      const options = opt
        .filter(option => answer?.includes(option?.id?.trim()))
        .map(option => option?.name);

      return (
        <Stack key={item.id || index} marginBottom={2}>
          <Stack direction='row' alignItems='center' marginBottom={1}>
            <Box
              sx={{
                minWidth: '20px',
                minHeight: '20px',
                maxWidth: '20px',
                maxHeight: '20px',
                width: '20px',
                height: '20px',
                borderRadius: '50%',
                bgcolor: '#A7AAB2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '8px',
                fontSize: 12,
                color: '#fff',
              }}
            >
              <Text $css={'color:#fff'}>{index + 1}</Text>
            </Box>
            <Text $css={'color:#686D78; font-weight: 500'}>{questionName}</Text>
          </Stack>

          {options.length === 0 ? (
            <Text $css={'margin-left: 28px; color: #9BADBC;'}>No data</Text>
          ) : (
            options.map((option, optIndex) => (
              <Stack
                key={optIndex}
                direction='row'
                alignItems='center'
                marginLeft={'28px'}
                gap={'8px'}
              >
                <Checkbox checked={true} disabled />
                <Text>{option}</Text>
              </Stack>
            ))
          )}
        </Stack>
      );
    } else if (item?.type === 'MULTIPLE_CHOICE') {
      const questionName = item.leadQuestion;
      const obj = Object.fromEntries(
        item.answer.split('|').map(part => part.split(':'))
      );
      const answerValues = obj.name;
      return (
        <Stack key={item.id || index} marginBottom={2}>
          <Stack direction='row' alignItems='center' marginBottom={1}>
            <Box
              sx={{
                minWidth: '20px',
                minHeight: '20px',
                maxWidth: '20px',
                maxHeight: '20px',
                borderRadius: '50%',
                bgcolor: '#A7AAB2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '8px',
                fontSize: 12,
                color: '#fff',
              }}
            >
              <Text $css={'color:#fff'}>{index + 1}</Text>
            </Box>
            <Text $css={'color:#686D78; font-weight: 500'}>{questionName}</Text>
          </Stack>
          <Text
            $css={`margin-left: 28px; ${
              answerValues === 'undefined' || answerValues === ''
                ? 'color: #9BADBC;'
                : ''
            }`}
          >
            {answerValues === 'undefined' || answerValues === ''
              ? 'No data'
              : answerValues}
          </Text>
        </Stack>
      );
    } else if (item?.type === 'ENUMERATION') {
      const questionName = item.leadQuestion;
      const cleanedAnswer = cleanAndSplitCommaSeparated(item.answer || '').join(
        ','
      );
      const answerValues = cleanedAnswer;

      return (
        <Stack key={item.id || index} marginBottom={2}>
          <Stack direction='row' alignItems='center' marginBottom={1}>
            <Box
              sx={{
                minWidth: '20px',
                minHeight: '20px',
                maxWidth: '20px',
                maxHeight: '20px',
                borderRadius: '50%',
                bgcolor: '#A7AAB2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '8px',
                fontSize: 12,
                color: '#fff',
              }}
            >
              <Text $css={'color:#fff'}>{index + 1}</Text>
            </Box>
            <Text $css={'color:#686D78; font-weight: 500'}>{questionName}</Text>
          </Stack>
          <Text $css={'margin-left: 28px'}>{answerValues || ''}</Text>
        </Stack>
      );
    } else {
      const parseAnswer = item.answer;
      const questionName = item.leadQuestion;
      const answerValues = parseAnswer;
      return (
        <Stack key={item.id || index} marginBottom={2}>
          <Stack direction='row' alignItems='center' marginBottom={1}>
            <Box
              sx={{
                minWidth: '20px',
                minHeight: '20px',
                maxWidth: '20px',
                maxHeight: '20px',
                borderRadius: '50%',
                bgcolor: '#A7AAB2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: '8px',
                fontSize: 12,
                color: '#fff',
              }}
            >
              <Text $css={'color:#fff'}>{index + 1}</Text>
            </Box>
            <Text $css={'color:#686D78; font-weight: 500'}>{questionName}</Text>
          </Stack>
          <Text $css={'margin-left: 28px'}>{answerValues || ''}</Text>
        </Stack>
      );
    }
  });

  return <>{renderFields}</>;
};

export default QuestionFieldsComponent;
