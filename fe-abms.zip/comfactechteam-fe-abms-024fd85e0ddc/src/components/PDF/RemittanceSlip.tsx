import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import { formatCurrency } from '@/utils/helper.utils';
import InvoiceModel from '@/models/InvoiceModel';

interface RemittanceSlipProps {
  data: InvoiceModel;
  companySettings?: any;
  tradingName?: string;
}

const styles = StyleSheet.create({
  remittanceContainer: {
    marginTop: 15,
    padding: 6,
    backgroundColor: '#f8f8f8',
    // borderRadius: 5,
    borderTop: 4,
    borderTopColor: '#BCA179',
    borderTopStyle: 'solid',
    minHeight: 0,
  },
  remittanceHeader: {
    fontSize: 10,
    fontWeight: 700,
    color: '#090A0B',
    marginBottom: 10,
    fontFamily: 'Manrope',
  },
  remittanceContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftSection: {
    flex: 1,
    marginRight: 20,
  },
  rightSection: {
    flex: 1,
  },
  companyBox: {
    // padding: 10,
    // backgroundColor: '#fff',
    // borderRadius: 3,
    marginBottom: 6,
  },
  companyName: {
    fontSize: 10,
    // fontWeight: 700,
    color: '#090A0B',
    fontFamily: 'Manrope',
    fontStyle: 'italic',
  },
  companyDetails: {
    fontSize: 10,
    color: '#090A0B',
    // marginTop: 2,
    fontFamily: 'Manrope',
  },
  invoiceDetails: {
    marginBottom: 10,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 2,
  },
  detailLabel: {
    fontSize: 10,
    color: '#090A0B',
    width: 'auto',
    fontFamily: 'Manrope',
    fontWeight: 400,
  },
  detailValue: {
    fontSize: 10,
    color: '#090A0B',
    flex: 1,
    fontFamily: 'Manrope',
    fontWeight: 700,
  },
  paymentSection: {
    marginBottom: 10,
  },
  paymentTitle: {
    fontSize: 10,
    color: '#090A0B',
    marginBottom: 6,
    fontFamily: 'Manrope',
  },
  paymentMethod: {
    fontSize: 10,
    color: '#090A0B',
    marginBottom: 4,
    lineHeight: 1.3,
    fontFamily: 'Manrope',
  },
  balanceSection: {
    paddingTop: 8,
  },
  balanceValue: {
    fontSize: 10,
    fontWeight: 700,
    color: '#090A0B',
  },
  balanceDueTitle: {
    fontSize: 10,
    fontWeight: 400,
    color: '#090A0B',
    marginBottom: 8,
    fontFamily: 'Manrope',
  },
  fillInSection: {
    marginTop: 8,
  },
  fillInRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  fillInLabel: {
    fontSize: 10,
    color: '#000',
    marginRight: 10,
  },
});

const RemittanceSlip: React.FC<RemittanceSlipProps> = ({
  data,
  companySettings,
  tradingName: propTradingName,
}) => {
  // Extract trading name - use prop if provided, otherwise extract from companySettings
  // ModuleStatus now fetches and transforms data[0], so it should be an object
  // Service layer also normalizes as fallback, so handle both for safety
  let tradingName: string | undefined = propTradingName;

  // If tradingName wasn't passed as prop or is empty, extract it from companySettings
  if (!tradingName && companySettings) {
    // Handle array format (if normalization didn't happen)
    if (Array.isArray(companySettings) && companySettings.length > 0) {
      tradingName = companySettings[0]?.tradingName;
    }
    // Handle object format (after transformData or service layer normalization)
    else if (
      companySettings &&
      typeof companySettings === 'object' &&
      companySettings.tradingName
    ) {
      tradingName = companySettings.tradingName;
    }
  }

  // Clean and validate
  if (tradingName && typeof tradingName === 'string') {
    tradingName = tradingName.trim();
    if (tradingName === '') {
      tradingName = undefined;
    }
  } else {
    tradingName = undefined;
  }

  // Calculate due date (typically 30 days from invoice date)
  const calculateDueDate = (invoiceDate: Date | string | undefined): string => {
    if (!invoiceDate) return '';
    const date = new Date(invoiceDate);
    date.setDate(date.getDate() + 30); // Add 30 days
    return formatDate2(date, dateFormat);
  };

  // Check if this is a bill - bills have billNo, invoices have invoiceNo or autoNumber
  // If it has invoiceNo or autoNumber, it's definitely an invoice, not a bill
  // Prioritize invoice detection: if invoiceNo or autoNumber exists, it's an invoice
  // Explicitly check for undefined/null to avoid false positives
  const hasInvoiceNo =
    data.invoiceNo !== undefined &&
    data.invoiceNo !== null &&
    String(data.invoiceNo).trim() !== '';
  const hasAutoNumber =
    data.autoNumber !== undefined &&
    data.autoNumber !== null &&
    String(data.autoNumber).trim() !== '';
  const hasBillNo = !!(data as any).billNo;
  const isBill = !hasInvoiceNo && !hasAutoNumber && hasBillNo;

  // Get the due date - use direct dueDate if available (bills), otherwise calculate
  const getDueDate = (): string => {
    if ((data as any).dueDate) {
      return formatDate2((data as any).dueDate, dateFormat);
    }
    return calculateDueDate(data.invoiceDate);
  };

  // Get account name for cheque (for bills, use account name; for invoices, always use "At Your Request")
  const getChequePayee = (): string => {
    // For invoices (has invoiceNo or autoNumber), always use "At Your Request"
    if (data.invoiceNo || data.autoNumber) {
      return 'At Your Request';
    }
    // For bills, use account name if available
    if (isBill && data.account?.name) {
      return data.account.name;
    }
    // Default fallback
    return 'At Your Request';
  };

  // Helper function to clean address strings that contain "undefined"
  // const cleanAddressString = (address: string | undefined): string => {
  //   if (!address) return '';

  //   // Split by comma, filter out "undefined" and empty parts, then rejoin
  //   return address
  //     .split(',')
  //     .map(part => part.trim())
  //     .filter(
  //       part =>
  //         part &&
  //         part.toLowerCase() !== 'undefined' &&
  //         part.toLowerCase() !== 'null'
  //     )
  //     .join(', ');
  // };

  return (
    <View style={styles.remittanceContainer}>
      <Text style={styles.remittanceHeader}>REMITTANCE SLIP</Text>

      <View style={styles.remittanceContent}>
        {/* Left Section */}
        <View style={styles.leftSection}>
          {/* Company/Account Information Box */}
          {isBill ? (
            <View style={styles.companyBox}>
              {data.account?.name && (
                <Text style={styles.companyName}>{data.account.name}</Text>
              )}

              {(data.account?.bStreetAddress ||
                data.account?.bSuburb ||
                data.account?.bPostalCode) && (
                <Text style={styles.companyDetails}>
                  {[
                    data.account?.bStreetAddress,
                    data.account?.bSuburb,
                    data.account?.bPostalCode,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </Text>
              )}
            </View>
          ) : (
            <View style={styles.companyBox}>
              {data.location?.billingAccount?.name && (
                <Text style={styles.companyName}>
                  {data.location.billingAccount.name}
                </Text>
              )}

              {tradingName && (
                <Text style={styles.companyDetails}>{tradingName}</Text>
              )}

              {(data.location?.billingAccount?.bStreetAddress ||
                data.location?.billingAccount?.bSuburb) && (
                <Text style={styles.companyDetails}>
                  {[
                    data.location?.billingAccount?.bStreetAddress,
                    data.location?.billingAccount?.bSuburb,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </Text>
              )}

              {(data.location?.billingAccount?.bCity ||
                data.location?.billingAccount?.bRegion ||
                data.location?.billingAccount?.bPostalCode) && (
                <Text style={styles.companyDetails}>
                  {[
                    data.location?.billingAccount?.bCity,
                    data.location?.billingAccount?.bRegion,
                    data.location?.billingAccount?.bPostalCode,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </Text>
              )}
            </View>
          )}

          {/* Invoice Details */}
          <View style={styles.invoiceDetails}>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>
                Invoice date:{' '}
                <Text style={styles.detailValue}>
                  {data.invoiceDate
                    ? formatDate2(data.invoiceDate, dateFormat)
                    : ''}
                </Text>
              </Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>
                Due Date: <Text style={styles.detailValue}>{getDueDate()}</Text>
              </Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>
                Invoice number:{' '}
                <Text style={styles.detailValue}>
                  {isBill
                    ? (data as any).billNo || ''
                    : data.invoiceNo || data.autoNumber || ''}
                </Text>
              </Text>
            </View>

            {/* Customer name - only show for invoices, not bills */}
            {!isBill && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>
                  Customer name:{' '}
                  <Text style={styles.detailValue}>
                    {data.account?.name || ''}
                  </Text>
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Right Section */}
        <View style={styles.rightSection}>
          {/* Payment Methods */}
          <View style={styles.paymentSection}>
            <Text style={styles.paymentTitle}>Payment methods:</Text>

            <Text style={styles.paymentMethod}>
              Internet direct credit:{' '}
              {isBill
                ? 'please use bill number as reference.'
                : `please use invoice number as reference and pay into ${data.location?.billingAccount?.bankAccountNo || '12-3110-0069942-000'}`}
            </Text>

            <Text style={styles.paymentMethod}>
              Cheque: please make the cheque out to {getChequePayee()} and post
              with remittance slip
            </Text>

            <View style={styles.balanceSection}>
              <Text style={styles.balanceDueTitle}>
                Balance Due:{' '}
                <Text style={styles.balanceValue}>
                  {formatCurrency(
                    (data.totalAmount || 0) - (data.paidAmount || 0)
                  )}
                </Text>
              </Text>
            </View>

            <View style={styles.fillInSection}>
              <View style={styles.fillInRow}>
                <Text style={styles.fillInLabel}>
                  Date Paid: ____________________
                </Text>
              </View>

              <View style={styles.fillInRow}>
                <Text style={styles.fillInLabel}>
                  Amount Enclose: ____________________
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

export default RemittanceSlip;
