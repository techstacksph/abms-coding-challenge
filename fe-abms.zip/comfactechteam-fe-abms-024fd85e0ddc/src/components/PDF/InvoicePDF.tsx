import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
} from '@react-pdf/renderer';

import { formatCurrency } from '@/utils/helper.utils';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import InvoiceModel from '@/models/InvoiceModel';
import { ayrLogo } from '@/constants/PDF/base64Images';

import RemittanceSlip from './RemittanceSlip';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 9,
    paddingTop: 30,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 30,
    lineHeight: 1.3,
  },
  topHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  leftTopHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 'auto',
    marginRight: 15,
    paddingTop: '16px',
    marginLeft: '3px',
  },
  companyInfo: {
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
  leftSection: {
    width: '50%',
  },
  rightSection: {
    width: '50%',
    alignItems: 'flex-end',
  },
  companyName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  tradingName: {
    fontSize: 8,
    fontWeight: 400,
    color: '#090A0B',
    // marginBottom: 8,
  },
  companyAddress: {
    fontSize: 8,
    color: '#090A0B',
    lineHeight: 1.3,
    textAlign: 'right',
    fontFamily: 'Manrope',
    width: '50%',
  },
  companyPhone: {
    fontSize: 8,
    color: '#000',
    // marginBottom: 6,
    fontFamily: 'Manrope',
  },
  companyEmail: {
    fontSize: 8,
    color: '#000',
    marginBottom: 6,
    fontFamily: 'Manrope',
  },
  invoiceTitle: {
    fontFamily: 'Antonio',
    fontSize: 28,
    color: '#D4A574',
  },
  invoiceDetailsSection: {
    marginBottom: 16,
    width: 'auto',
  },
  mainContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  leftColumn: {
    flex: 1,
    marginRight: 40,
  },
  rightColumn: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 700,
    color: '#000',
    marginBottom: 15,
  },
  billedToTitle: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
    // marginBottom: 15,
  },
  accountName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
    // marginBottom: 8,
  },
  billingAddress: {
    fontSize: 8,
    fontFamily: 'Manrope',
    color: '#000',
    // marginBottom: 8,
    lineHeight: 1.3,
  },
  attentionLine: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
    // marginBottom: 5,
  },
  attnLabel: {
    fontSize: 8,
    // fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  attnValue: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  billedToSection: {
    // marginTop: 20,
    marginBottom: 0,
  },
  detailRow: {
    flexDirection: 'row',
    // marginBottom: 5,
  },
  detailLabel: {
    width: 80,
    fontSize: 9,
    color: '#000',
  },
  detailLabels: {
    // width: 40,
    fontSize: 9,
    color: '#000',
  },
  detailValues: {
    fontSize: 9,
    color: '#000',
    flex: 1,
  },
  detailValue: {
    fontSize: 9,
    color: '#000',
    flex: 1,
  },

  table: {
    marginBottom: 20,
    borderTopWidth: 3,
    borderTop: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 8,
    paddingHorizontal: 5,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderBottomColor: '#eee',
    paddingVertical: 6,
    paddingHorizontal: 5,
  },
  tableHeaderCell: {
    fontSize: 9,
    fontWeight: 700,
    color: '#333',
  },
  tableCell: {
    fontSize: 9,
    color: '#333',
  },
  descriptionColumn: {
    flex: 3,
  },
  quantityColumn: {
    flex: 1,
    textAlign: 'center',
  },
  priceColumn: {
    flex: 1,
    textAlign: 'right',
  },
  amountColumn: {
    flex: 1,
    textAlign: 'right',
  },
  summary: {
    marginTop: 0,
    alignItems: 'flex-end',
  },
  summaryBox: {
    width: 200,
    padding: 0,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: 10,
  },
  summaryLabel: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    fontWeight: 700,
  },
  summaryValue: {
    fontSize: 9,
    color: '#090A0B',
    fontWeight: 700,
    fontFamily: 'Manrope',
  },

  balanceDueRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // marginTop: 5,
    backgroundColor: '#D4A574',
    padding: 8,
    borderRadius: 3,
  },
  balanceDueLabel: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  balanceDueValue: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  summarySection: {
    marginTop: 0,
  },
  commentsHeader: {
    marginBottom: 0,
    marginTop: 0, // Align with the first summary row (summaryBox padding + text position)
  },
  commentsText: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
  },
  commentsContent: {
    marginTop: 5,
    maxWidth: 300,
  },
  notesText: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    lineHeight: 1.3,
  },
  summaryTopBorder: {
    borderTopWidth: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
    marginBottom: 15,
    width: '100%',
  },
  commentsAndSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
});

interface InvoicePDFProps {
  data: InvoiceModel;
  companySettings?: any;
}

// Helper function to merge similar invoice details
const mergeInvoiceDetails = (invoiceDetails: any[]) => {
  if (!invoiceDetails || invoiceDetails.length === 0) return [];

  const merged: any[] = [];
  const processedDetails = [...invoiceDetails];

  processedDetails.forEach(detail => {
    // If dontMerge is true, add as separate item
    if (detail.dontMerge) {
      merged.push(detail);
      return;
    }

    // Look for existing item with same description
    const existingIndex = merged.findIndex(
      existing =>
        !existing.dontMerge &&
        existing.description === detail.description &&
        existing.unitPrice === detail.unitPrice
    );

    if (existingIndex >= 0) {
      // Merge with existing item
      merged[existingIndex] = {
        ...merged[existingIndex],
        qty: Number(merged[existingIndex].qty) + Number(detail.qty),
        lineAmount:
          Number(merged[existingIndex].lineAmount) + Number(detail.lineAmount),
      };
    } else {
      // Add as new item
      merged.push(detail);
    }
  });

  return merged;
};

const InvoicePDF: React.FC<InvoicePDFProps> = ({ data, companySettings }) => {
  const processedDetails = mergeInvoiceDetails(data.invoiceDetails || []);

  // Extract trading name from companySettings
  // ModuleStatus now fetches and transforms data[0], so it should be an object
  // Service layer also normalizes as fallback, so handle both for safety
  let tradingName: string | undefined = undefined;

  if (companySettings) {
    // Handle array format (if normalization didn't happen)
    if (Array.isArray(companySettings) && companySettings.length > 0) {
      tradingName = companySettings[0]?.tradingName;
    }
    // Handle object format (after transformData or service layer normalization)
    else if (companySettings.tradingName) {
      tradingName = companySettings.tradingName;
    }
  }

  // Clean and validate
  if (tradingName && typeof tradingName === 'string') {
    tradingName = tradingName.trim();
    if (tradingName === '') {
      tradingName = undefined;
    }
  } else {
    tradingName = undefined;
  }

  // Helper function to clean address strings that contain "undefined"
  // const cleanAddressString = (address: string | undefined): string => {
  //   if (!address) return '';

  //   // Split by comma, filter out "undefined" and empty parts, then rejoin
  //   return address
  //     .split(',')
  //     .map(part => part.trim())
  //     .filter(
  //       part =>
  //         part &&
  //         part.toLowerCase() !== 'undefined' &&
  //         part.toLowerCase() !== 'null'
  //     )
  //     .join(', ');
  // };

  // Calculate max table height based on available space
  // A4 page height: ~842pt
  // Fixed content: header (~80pt) + company info (~120pt) + summary (~120pt) + remittance slip (~200pt) = ~520pt
  // Padding: 30 top + 80 bottom = 110pt
  // Available for table: 842 - 520 - 110 = ~212pt
  const MAX_TABLE_HEIGHT = 200; // Maximum height for table content in points

  // Estimate row height based on description length
  // Base row height: ~20pt (for short descriptions)
  // Each ~50 characters adds ~1 line (~12pt per line)
  const estimateRowHeight = (description: string): number => {
    const baseHeight = 20; // Base height for row with padding
    const charsPerLine = 50; // Approximate characters per line in description column
    const lineHeight = 12; // Height per line of text
    const descriptionLength = description?.length || 0;
    const estimatedLines = Math.ceil(descriptionLength / charsPerLine) || 1;
    return baseHeight + (estimatedLines - 1) * lineHeight;
  };

  // Split items into pages based on actual estimated heights
  const pages: any[][] = [];
  let currentPageItems: any[] = [];
  let currentPageHeight = 0;

  processedDetails.forEach(detail => {
    const rowHeight = estimateRowHeight(detail.description || '');

    // If adding this item would exceed max height, start a new page
    if (
      currentPageHeight + rowHeight > MAX_TABLE_HEIGHT &&
      currentPageItems.length > 0
    ) {
      pages.push(currentPageItems);
      currentPageItems = [detail];
      currentPageHeight = rowHeight;
    } else {
      currentPageItems.push(detail);
      currentPageHeight += rowHeight;
    }
  });

  // Add the last page if it has items
  if (currentPageItems.length > 0) {
    pages.push(currentPageItems);
  }

  // If no items, still create one page
  if (pages.length === 0) {
    pages.push([]);
  }

  // Render template components (reusable across pages)
  const renderTemplate = (pageItems: any[]) => (
    <>
      {/* Top Header: Logo on left, TAX INVOICE on right - Fixed on all pages */}
      <View fixed style={styles.topHeader}>
        <View style={styles.leftTopHeader}>
          <Image src={ayrLogo} style={styles.logo} />
        </View>
        <Text style={styles.invoiceTitle}>TAX INVOICE</Text>
      </View>

      {/* Company Information - Two column layout - Fixed on all pages */}
      <View fixed style={styles.companyInfo}>
        <View style={styles.leftSection}>
          {/* Invoice Details - Left side only, vertical layout */}
          <View style={styles.invoiceDetailsSection}>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabels}>GST Invoice No:</Text>
              <Text style={styles.detailValue}>
                {data.invoiceNo || data.autoNumber || ''}
              </Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabels}>Date:</Text>
              <Text style={styles.detailValue}>
                {data.invoiceDate
                  ? formatDate2(data.invoiceDate, dateFormat)
                  : ''}
              </Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabels}>GST Reg. No:</Text>
              <Text style={styles.detailValue}>
                {data.location?.billingAccount?.gst || ''}
              </Text>
            </View>
          </View>

          {/* BILLED TO Section - Below the invoice details */}
          <View style={styles.billedToSection}>
            <Text style={styles.billedToTitle}>BILLED TO:</Text>

            {data.billingAccount?.name && (
              <Text style={styles.accountName}>{data.billingAccount.name}</Text>
            )}

            {(data.billingAccount?.bStreetAddress ||
              data.billingAccount?.bSuburb ||
              data.billingAccount?.bPostalCode) && (
              <Text style={styles.billingAddress}>
                {[
                  data.billingAccount?.bStreetAddress,
                  data.billingAccount?.bSuburb,
                  data.billingAccount?.bPostalCode,
                ]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            {data.invoiceContacts &&
              data.invoiceContacts.length > 0 &&
              data.invoiceContacts[0].contact && (
                <Text style={styles.attentionLine}>
                  <Text style={styles.attnLabel}>Attn: </Text>
                  <Text style={styles.attnValue}>
                    {data.invoiceContacts[0].contact.fullName ||
                      `${data.invoiceContacts[0].contact.firstName || ''} ${data.invoiceContacts[0].contact.lastName || ''}`}
                  </Text>
                </Text>
              )}
          </View>
        </View>

        <View style={styles.rightSection}>
          {data.location?.billingAccount?.legalName && (
            <Text style={styles.companyName}>
              {data.location.billingAccount.legalName}
            </Text>
          )}

          {tradingName ? (
            <Text style={styles.tradingName}>{tradingName}</Text>
          ) : null}

          {(data.location?.billingAccount?.bStreetAddress ||
            data.location?.billingAccount?.bSuburb) && (
            <Text style={styles.companyAddress}>
              {[
                data.location?.billingAccount?.bStreetAddress,
                data.location?.billingAccount?.bSuburb,
              ]
                .filter(Boolean)
                .join(', ')}
            </Text>
          )}

          {(data.location?.billingAccount?.bCity ||
            data.location?.billingAccount?.bRegion ||
            data.location?.billingAccount?.bPostalCode) && (
            <Text style={styles.companyAddress}>
              {[
                data.location?.billingAccount?.bCity,
                data.location?.billingAccount?.bRegion,
                data.location?.billingAccount?.bPostalCode,
              ]
                .filter(Boolean)
                .join(', ')}
            </Text>
          )}

          <Text style={styles.companyPhone}>
            DDI: {data.location?.billingAccount?.ayrMobile || ''}
          </Text>

          <Text style={styles.companyEmail}>
            Email: {data.location?.financeEmail || ''}
          </Text>
        </View>
      </View>

      {/* Invoice Items Table - Table header fixed on all pages */}
      <View style={styles.table}>
        <View fixed style={styles.tableHeader}>
          <Text style={[styles.tableHeaderCell, styles.descriptionColumn]}>
            Description
          </Text>
          <Text style={[styles.tableHeaderCell, styles.quantityColumn]}>
            QTY
          </Text>
          <Text style={[styles.tableHeaderCell, styles.priceColumn]}>
            Unit Price
          </Text>
          <Text style={[styles.tableHeaderCell, styles.amountColumn]}>
            Amount
          </Text>
        </View>

        {pageItems.map((detail, index) => (
          <View key={detail.id || index} style={styles.tableRow}>
            <Text style={[styles.tableCell, styles.descriptionColumn]}>
              {detail.description || ''}
            </Text>
            <Text style={[styles.tableCell, styles.quantityColumn]}>
              {detail.qty || 0}
            </Text>
            <Text style={[styles.tableCell, styles.priceColumn]}>
              {formatCurrency(detail.unitPrice || 0)}
            </Text>
            <Text style={[styles.tableCell, styles.amountColumn]}>
              {formatCurrency(detail.lineAmount || 0)}
            </Text>
          </View>
        ))}
      </View>

      {/* Comments and Invoice Summary Section - Fixed on all pages */}
      <View fixed style={styles.summarySection}>
        {/* Top Border */}
        <View style={styles.summaryTopBorder} />

        {/* Comments and Summary Row */}
        <View style={styles.commentsAndSummaryRow}>
          {/* Comments Section */}
          <View style={styles.commentsHeader}>
            <Text style={styles.commentsText}>COMMENTS:</Text>
            {(() => {
              if (!data.notes) return null;
              
              if (Array.isArray(data.notes) && data.notes.length > 0) {
                return (
                  <View style={styles.commentsContent}>
                    {data.notes
                      .filter((note: any) => note?.notes && typeof note.notes === 'string' && note.notes.trim())
                      .map((note: any, index: number) => (
                        <Text key={note.id || index} style={styles.notesText}>
                          {note.notes}
                        </Text>
                      ))}
                  </View>
                );
              }
              
              if (typeof data.notes === 'string') {
                const notesString = (data.notes as string).trim();
                return notesString ? (
                  <View style={styles.commentsContent}>
                    <Text style={styles.notesText}>{notesString}</Text>
                  </View>
                ) : null;
              }
              
              return null;
            })()}
          </View>

          {/* Invoice Summary */}
          <View style={styles.summary}>
            <View style={styles.summaryBox}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>
                  {formatCurrency(data.subtotal || 0)}
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Tax</Text>
                <Text style={styles.summaryValue}>
                  {formatCurrency(data.gstAmount || 0)}
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Total Amount</Text>
                <Text style={styles.summaryValue}>
                  {formatCurrency(data.totalAmount || 0)}
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Paid to date</Text>
                <Text style={styles.summaryValue}>
                  {formatCurrency(data.paidAmount || 0)}
                </Text>
              </View>
              <View style={styles.balanceDueRow}>
                <Text style={styles.balanceDueLabel}>Balance Due</Text>
                <Text style={styles.balanceDueValue}>
                  {formatCurrency(
                    (data.totalAmount || 0) - (data.paidAmount || 0)
                  )}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>

      {/* Remittance Slip - Fixed on every page to ensure it appears even on auto-generated pages */}
      <View fixed break={false} minPresenceAhead={300}>
        <RemittanceSlip
          data={data}
          companySettings={companySettings}
          tradingName={tradingName}
        />
      </View>
    </>
  );

  return (
    <Document>
      {pages.map((pageItems, pageIndex) => (
        <Page key={pageIndex} size='A4' style={styles.page}>
          {renderTemplate(pageItems)}
        </Page>
      ))}
    </Document>
  );
};

export default InvoicePDF;
