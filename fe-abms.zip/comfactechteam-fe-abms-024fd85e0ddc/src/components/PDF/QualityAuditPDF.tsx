import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
} from '@react-pdf/renderer';

import { formatDate2, dateFormat } from '@/utils/date.utils';
import QualityAuditModel from '@/models/QualityAuditModel';
import { ayrLogo } from '@/constants/PDF/base64Images';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 10,
    paddingTop: 40,
    paddingLeft: 40,
    paddingRight: 40,
    paddingBottom: 60,
    lineHeight: 1.4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    width: 100,
    height: 'auto',
  },
  title: {
    fontFamily: 'Antonio',
    fontSize: 28,
    color: '#D4A574',
    fontWeight: 700,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 700,
    color: '#1D1F22',
    marginBottom: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4A574',
    paddingBottom: 5,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  label: {
    fontSize: 10,
    fontWeight: 600,
    color: '#686D78',
    width: 150,
  },
  value: {
    fontSize: 10,
    color: '#090A0B',
    flex: 1,
  },
  table: {
    marginTop: 10,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F5',
    borderBottomWidth: 2,
    borderBottomColor: '#D4A574',
    paddingVertical: 8,
    paddingHorizontal: 5,
  },
  tableHeaderCell: {
    fontSize: 10,
    fontWeight: 700,
    color: '#1D1F22',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderBottomColor: '#E0E0E0',
    paddingVertical: 8,
    paddingHorizontal: 5,
  },
  tableCell: {
    fontSize: 9,
    color: '#090A0B',
  },
  areaColumn: {
    flex: 2,
  },
  assessmentColumn: {
    flex: 1,
  },
  specificationColumn: {
    flex: 3,
  },
  notesColumn: {
    flex: 2,
  },
  statusTag: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 600,
  },
  statusCreated: {
    backgroundColor: '#E3F2FD',
    color: '#1976D2',
  },
  statusInProgress: {
    backgroundColor: '#FFF3E0',
    color: '#F57C00',
  },
  statusComplete: {
    backgroundColor: '#E8F5E9',
    color: '#388E3C',
  },
  statusCancelled: {
    backgroundColor: '#FFEBEE',
    color: '#D32F2F',
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    textAlign: 'center',
    fontSize: 8,
    color: '#686D78',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingTop: 10,
  },
  subDetail: {
    marginLeft: 20,
    marginTop: 5,
    paddingLeft: 10,
    borderLeftWidth: 2,
    borderLeftColor: '#D4A574',
  },
  subDetailRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
});

interface QualityAuditPDFProps {
  data: QualityAuditModel;
}

const QualityAuditPDF: React.FC<QualityAuditPDFProps> = ({ data }) => {
  const getStatusStyle = (statusName: string) => {
    const status = statusName?.toLowerCase();
    if (status === 'created') return styles.statusCreated;
    if (status === 'in progress') return styles.statusInProgress;
    if (status === 'complete') return styles.statusComplete;
    if (status === 'cancelled') return styles.statusCancelled;
    return styles.statusCreated;
  };

  const formatAssessment = (assessment: string) => {
    if (assessment === 'STANDARD_ACHIEVE') return 'Standard Achieved';
    if (assessment === 'NEEDS_ATTENTION') return 'Needs Attention';
    return assessment;
  };

  // Group specifications by area
  const groupedData = () => {
    if (!data.qaAreas || !data.qaSpecifications) return [];

    return data.qaAreas.map(area => ({
      area,
      specifications: data.qaSpecifications.filter(
        spec => spec.qaAreaId === area.id
      ),
    }));
  };

  return (
    <Document>
      <Page size='A4' style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <Image src={ayrLogo} style={styles.logo} />
          <Text style={styles.title}>QUALITY AUDIT</Text>
        </View>

        {/* Audit Information Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Audit Information</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Quality Audit No:</Text>
            <Text style={styles.value}>{data.qaNo || 'N/A'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Status:</Text>
            <View style={[styles.statusTag, getStatusStyle(data.status?.name)]}>
              <Text>{data.status?.name || 'N/A'}</Text>
            </View>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Audit Month:</Text>
            <Text style={styles.value}>
              {data.auditMonth
                ? formatDate2(data.auditMonth, dateFormat)
                : 'N/A'}
            </Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Rectification Date:</Text>
            <Text style={styles.value}>
              {data.rectificationDate
                ? formatDate2(data.rectificationDate, dateFormat)
                : 'N/A'}
            </Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>QA Score:</Text>
            <Text style={styles.value}>{data.qaScore || 'N/A'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Record Owner:</Text>
            <Text style={styles.value}>
              {data.recordOwner?.fullName || 'N/A'}
            </Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Location:</Text>
            <Text style={styles.value}>{data.location?.name || 'N/A'}</Text>
          </View>
        </View>

        {/* Job Information Section */}
        {data.job && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Job Information</Text>
            <View style={styles.row}>
              <Text style={styles.label}>Job No:</Text>
              <Text style={styles.value}>{data.job.jobNo || 'N/A'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Site:</Text>
              <Text style={styles.value}>
                {data.job.site?.siteName || 'N/A'}
              </Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Address:</Text>
              <Text style={styles.value}>
                {data.job.site?.fullAddress || 'N/A'}
              </Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Account:</Text>
              <Text style={styles.value}>
                {data.job.account?.name || 'N/A'}
              </Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Contact:</Text>
              <Text style={styles.value}>
                {data.job.contact?.fullName || 'N/A'}
              </Text>
            </View>
          </View>
        )}

        {/* Customer Meeting Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Customer Meeting</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Meet with Customer:</Text>
            <Text style={styles.value}>
              {data.meetWithCustomer ? 'Yes' : 'No'}
            </Text>
          </View>
          {data.meetWithCustomer ? (
            <View style={styles.row}>
              <Text style={styles.label}>Who did you meet:</Text>
              <Text style={styles.value}>{data.whoDidYouMeet || 'N/A'}</Text>
            </View>
          ) : (
            <View style={styles.row}>
              <Text style={styles.label}>Reason for not meeting:</Text>
              <Text style={styles.value}>
                {data.reasonForNotMeeting || 'N/A'}
              </Text>
            </View>
          )}
        </View>

        {/* Job Specifications and Assessment */}
        {groupedData().length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              Job Specifications & Assessment
            </Text>
            {groupedData().map((item, index) => (
              <View key={index} style={{ marginBottom: 15 }}>
                <View style={styles.tableRow}>
                  <Text
                    style={[
                      styles.tableCell,
                      styles.areaColumn,
                      { fontWeight: 700 },
                    ]}
                  >
                    Area: {item.area.area || 'N/A'}
                  </Text>
                  <Text style={[styles.tableCell, styles.assessmentColumn]}>
                    {formatAssessment(item.area.assessment)}
                  </Text>
                </View>
                {item.specifications.length > 0 && (
                  <View style={styles.subDetail}>
                    {item.specifications.map((spec, specIndex) => (
                      <View key={specIndex} style={styles.subDetailRow}>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.tableCell}>
                            {spec.specification || 'N/A'}
                          </Text>
                          <Text
                            style={[
                              styles.tableCell,
                              { fontSize: 8, color: '#686D78', marginTop: 2 },
                            ]}
                          >
                            {formatAssessment(spec.assessment)}
                          </Text>
                          {spec.notes && (
                            <Text
                              style={[
                                styles.tableCell,
                                {
                                  fontSize: 8,
                                  marginTop: 3,
                                  fontStyle: 'italic',
                                },
                              ]}
                            >
                              Notes: {spec.notes}
                            </Text>
                          )}
                        </View>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            ))}
          </View>
        )}

        {/* Notes Section */}
        {(data.customerNotes || data.franchiseeNotes) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes</Text>
            {data.customerNotes && (
              <View style={styles.row}>
                <Text style={styles.label}>Customer Notes:</Text>
                <Text style={styles.value}>{data.customerNotes}</Text>
              </View>
            )}
            {data.franchiseeNotes && (
              <View style={styles.row}>
                <Text style={styles.label}>Franchisee Notes:</Text>
                <Text style={styles.value}>{data.franchiseeNotes}</Text>
              </View>
            )}
          </View>
        )}

        {/* Footer */}
        <View style={styles.footer}>
          <Text>
            Generated on {formatDate2(new Date().toISOString(), dateFormat)} |
            At Your Request - Quality Audit Report
          </Text>
        </View>
      </Page>
    </Document>
  );
};

export default QualityAuditPDF;
