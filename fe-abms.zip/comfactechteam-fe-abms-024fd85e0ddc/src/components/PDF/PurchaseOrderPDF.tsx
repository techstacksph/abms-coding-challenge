import React from 'react';

import { Document, Page, Text, View, Image, Font } from '@react-pdf/renderer';

import { formatCurrency } from '@/utils/helper.utils';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import PurchaseOrderModel from '@/models/PurchaseOrderModal';
import PurchaseOrderItemModel from '@/models/PurchaseOrderItemModel';
import { ayrLogo } from '@/constants/PDF/base64Images';
import { styles } from './SalesOrderPDF.styles';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

interface PurchaseOrderPDFProps {
  data: PurchaseOrderModel;
  purchaseOrderItems: PurchaseOrderItemModel[];
  companySettings?: any;
  locationData?: any;
}

const PurchaseOrderPDF: React.FC<PurchaseOrderPDFProps> = ({
  data,
  purchaseOrderItems,
  companySettings, // This is the normalized object from the service
}) => {
  // Extract trading name from companySettings
  // Service layer normalizes array to object, so handle both for safety
  let tradingName: string | undefined = undefined;

  if (companySettings) {
    // Handle array format (if normalization didn't happen)
    if (Array.isArray(companySettings) && companySettings.length > 0) {
      tradingName = companySettings[0]?.tradingName;
    }
    // Handle object format (after service layer normalization)
    else if (companySettings.tradingName) {
      tradingName = companySettings.tradingName;
    }
  }

  // Clean and validate
  if (tradingName && typeof tradingName === 'string') {
    tradingName = tradingName.trim();
    if (tradingName === '') {
      tradingName = undefined;
    }
  } else {
    tradingName = undefined;
  }

  // Get billing account from location
  // Note: If billingAccount is null but billingAccountId exists, the backend resolver
  // needs to properly populate the billingAccount relation in the GraphQL query
  const billingAccount = data.location?.billingAccount;

  // Helper function to clean address strings that contain "undefined"
  const cleanAddressString = (address: string | undefined): string => {
    if (!address) return '';

    // Split by comma, filter out "undefined" and empty parts, then rejoin
    return address
      .split(',')
      .map(part => part.trim())
      .filter(
        part =>
          part &&
          part.toLowerCase() !== 'undefined' &&
          part.toLowerCase() !== 'null'
      )
      .join(', ');
  };

  return (
    <Document>
      <Page size='A4' style={styles.page}>
        {/* Top Header: Logo on left, PURCHASE ORDER on right */}
        <View style={styles.topHeader}>
          <View style={styles.leftTopHeader}>
            <Image src={ayrLogo} style={styles.logo} />
          </View>
          <Text style={styles.invoiceTitle}>PURCHASE ORDER</Text>
        </View>

        {/* Company Information - Two column layout */}
        <View style={styles.companyInfo}>
          <View style={styles.leftSection}>
            {/* SUPPLIER Section */}
            <View style={styles.invoiceToSection}>
              <Text style={styles.billedToTitle}>SUPPLIER:</Text>
              {data.supplier?.name && (
                <Text style={styles.accountName}>{data.supplier.name}</Text>
              )}
            </View>

            {/* SHIPPED TO Section */}
            <View style={styles.invoiceToSection}>
              <Text style={styles.shippedToTitle}>SHIPPED TO:</Text>
              {data.warehouse?.name && (
                <Text style={styles.billingAddress}>{data.warehouse.name}</Text>
              )}
              {tradingName && (
                <Text style={styles.billingAddress}>{tradingName}</Text>
              )}
              {data.deliveryAddress && (
                <Text style={styles.billingAddress}>
                  {cleanAddressString(data.deliveryAddress)}
                </Text>
              )}
            </View>
          </View>

          <View style={styles.rightSection}>
            {billingAccount?.name && (
              <Text style={styles.companyName}>{billingAccount.name}</Text>
            )}

            {tradingName ? (
              <Text style={styles.tradingName}>{tradingName}</Text>
            ) : null}

            {(billingAccount?.bStreetAddress || billingAccount?.bSuburb) && (
              <Text style={styles.companyAddress}>
                {[billingAccount?.bStreetAddress, billingAccount?.bSuburb]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            {(billingAccount?.bCity ||
              billingAccount?.bRegion ||
              billingAccount?.bPostalCode) && (
              <Text style={styles.companyAddress}>
                {[
                  billingAccount?.bCity,
                  billingAccount?.bRegion,
                  billingAccount?.bPostalCode,
                ]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            <Text style={styles.companyPhone}>
              DDI: {billingAccount?.ayrMobile || ''}
            </Text>

            <Text style={styles.companyEmail}>
              Email: {data.location?.financeEmail || ''}
            </Text>

            <Text style={styles.companyPhone}>
              GST Reg. No.: {billingAccount?.gst || ''}
            </Text>

            <Text style={styles.companyPhone}>
              Purchase Order No.: {data.poNo || ''}
            </Text>

            <Text style={styles.companyPhone}>
              Date: {data.poDate ? formatDate2(data.poDate, dateFormat) : ''}
            </Text>
          </View>
        </View>

        {/* Purchase Order Items Table */}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderCell, styles.itemIdColumn]}>
              ITEM ID
            </Text>
            <Text style={[styles.tableHeaderCell, styles.descriptionColumn]}>
              DESCRIPTION
            </Text>
            <Text style={[styles.tableHeaderCell, styles.quantityColumn]}>
              QTY
            </Text>
            <Text style={[styles.tableHeaderCell, styles.priceColumn]}>
              UNIT PRICE
            </Text>
            <Text style={[styles.tableHeaderCell, styles.amountColumn]}>
              AMOUNT
            </Text>
          </View>

          {purchaseOrderItems.map((item, index) => {
            // Calculate unitPrice from amount/quantity if not available
            const unitPrice =
              item.unitPrice ||
              (item.quantity && item.amount ? item.amount / item.quantity : 0);

            // Get item data - handle both enriched items and items with item relation
            const itemData = item.item;
            const itemCode = itemData?.itemCode || '';
            const itemName = itemData?.name ? String(itemData.name).trim() : '';

            // Debug logging (remove in production)
            if (index === 0) {
              console.log('PDF - First item:', item);
              console.log('PDF - First item.item:', item.item);
              console.log('PDF - First item.itemCode:', itemCode);
              console.log('PDF - First itemName:', itemName);
            }

            return (
              <View key={item.id || index} style={styles.tableRow}>
                <Text style={[styles.tableCell, styles.itemIdColumn]}>
                  {itemCode}
                </Text>
                <Text style={[styles.tableCell, styles.descriptionColumn]}>
                  {itemName}
                </Text>
                <Text style={[styles.tableCell, styles.quantityColumn]}>
                  {item.quantity || 0}
                </Text>
                <Text style={[styles.tableCell, styles.priceColumn]}>
                  {formatCurrency(unitPrice)}
                </Text>
                <Text style={[styles.tableCell, styles.amountColumn]}>
                  {formatCurrency(item.amount || 0)}
                </Text>
              </View>
            );
          })}
        </View>

        {/* Comments and Purchase Order Summary Section */}
        <View style={styles.summarySection}>
          {/* Top Border */}
          <View style={styles.summaryTopBorder} />

          {/* Comments and Summary Row */}
          <View style={styles.commentsAndSummaryRow}>
            {/* Comments Header */}
            <View style={styles.commentsHeader}>
              <Text style={styles.commentsText}>COMMENTS:</Text>
              {data.notes && data.notes.trim() && (
                <View style={styles.commentsContent}>
                  <Text style={styles.notesText}>{data.notes}</Text>
                </View>
              )}
            </View>

            {/* Purchase Order Summary */}
            <View style={styles.summary}>
              <View style={styles.summaryBox}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Subtotal:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(Number(data.subTotal) || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Tax:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(Number(data.gst) || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Total Amount:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(Number(data.totalAmount) || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Paid to date:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(Number(data.amountPaid) || 0)}
                  </Text>
                </View>
                <View style={styles.balanceDueRow}>
                  <Text style={styles.balanceDueLabel}>Balance Due:</Text>
                  <Text style={styles.balanceDueValue}>
                    {formatCurrency(Number(data.balanceDue) || 0)}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Footer - Fixed on every page */}
        <View style={styles.footer} fixed>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text
              style={styles.footerLeft}
              render={({ pageNumber, totalPages }) =>
                `Page ${pageNumber} of ${totalPages}`
              }
            />
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={styles.footerRight}>PO No.: {data.poNo || ''}</Text>
            <Text style={[styles.footerRight, { marginLeft: 20 }]}>
              Balance Due: {formatCurrency(Number(data.balanceDue) || 0)}
            </Text>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default PurchaseOrderPDF;
