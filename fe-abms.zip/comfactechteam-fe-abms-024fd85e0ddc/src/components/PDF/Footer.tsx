import React from 'react';

import { Text, View } from '@react-pdf/renderer';

import { styles } from '../../constants/PDF/StyleSheet';

const Footer = ({ fixed = false }) => (
  <View style={styles.footer} fixed={fixed}>
    <Text style={styles.footerText}>0800 297 255</Text>
    <Text style={styles.footerText}>
      info@atyourrequest.co.nz | www.atyourrequest.co.nz
    </Text>
    <View style={styles.footerBar2} />
    <View style={styles.footerBar} />
  </View>
);

export default Footer;
