import React from 'react';

import { View, Image } from '@react-pdf/renderer';

import { styles } from '../../constants/PDF/StyleSheet';
import { ayrLogo } from '../../constants/PDF/base64Images';

const Header = ({ fixed = false }) => (
  <View
    style={[styles.header, fixed ? { position: 'absolute', top: 0 } : {}]}
    fixed={fixed}
  >
    <Image src={ayrLogo} style={{ width: '2.59cm', height: 'auto' }} />
  </View>
);

export default Header;
