import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image,
} from '@react-pdf/renderer';

import { formatDate2, dateFormat } from '@/utils/date.utils';
import JobsModel from '@/models/JobsModel';
import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';
import { star } from '@/constants/PDF/base64Images';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 10,
    paddingTop: 130,
    paddingLeft: 50,
    paddingRight: 50,
    paddingBottom: 150,
    lineHeight: 1.4,
  },
  topSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'absolute',
    top: 35,
    left: 50,
    right: 50,
  },
  leftInfo: {
    flexDirection: 'column',
    paddingTop: 20,
    columnGap: '4px',
    fontFamily: 'Manrope',
  },
  rightInfo: {
    flexDirection: 'column',
    alignItems: 'flex-end',
    fontFamily: 'Manrope',
  },
  infoText: {
    fontSize: 8,
    color: '#000000',
    fontWeight: 500,
    fontFamily: 'Manrope',
  },
  atYourRequest: {
    fontSize: 15,
    fontWeight: 700,
    letterSpacing: 1,
    color: '#000000',
  },
  titleBanner: {
    padding: 16,
    paddingTop: 0,
    textAlign: 'center',
    marginBottom: 15,
  },
  bannerText: {
    fontSize: 18,
    fontWeight: 800,
    color: '#BCA179',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
    marginBottom: 10,
  },
  label: {
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
  },
  value: {
    fontSize: 9,
    color: '#000000',
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    zIndex: 1000,
    position: 'absolute',
    left: 0,
    right: 0,
    top: 750,
    paddingLeft: 50,
    paddingRight: 50,
  },
  footerLeft: {
    flexDirection: 'column',
    fontSize: 8,
    color: '#686D78',
  },
  footerRight: {
    fontSize: 8,
    color: '#000000',
  },
  table: {
    width: '100%',
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    borderLeftWidth: 1,
    borderLeftColor: '#000000',
    borderTopWidth: 1,
    borderTopColor: '#000000',
  },
  tableHeaderCell: {
    backgroundColor: '#F2F2F2',
    padding: 8,
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    flex: 1,
  },
  dayHeaderCell: {
    backgroundColor: '#F2F2F2',
    padding: 8,
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    width: 40,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderLeftWidth: 1,
    borderLeftColor: '#000000',
  },
  tableBodyCell: {
    padding: 6,
    fontSize: 9,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    flex: 1,
  },
  dayCell: {
    padding: 6,
    fontSize: 9,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    width: 40,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  starIcon: {
    width: 10,
    height: 10,
  },
  frequencyRow: {
    flexDirection: 'row',
    borderLeftWidth: 1,
    borderLeftColor: '#000000',
    backgroundColor: '#FAFAFA',
  },
  frequencyCell: {
    padding: 6,
    fontSize: 9,
    fontWeight: 600,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
  },
  notesRow: {
    flexDirection: 'row',
    borderLeftWidth: 1,
    borderLeftColor: '#000000',
  },
  notesHeaderCell: {
    padding: 6,
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    width: 80,
  },
  notesCell: {
    padding: 6,
    fontSize: 9,
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#000000',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    flex: 1,
  },
});

interface JobSpecsServiceProviderPDFProps {
  data: JobsModel;
  serviceProviderId: string;
}

const JobSpecsServiceProviderPDF: React.FC<JobSpecsServiceProviderPDFProps> = ({
  data,
  serviceProviderId,
}) => {
  const days = ['M', 'T', 'W', 'TH', 'F', 'Sa', 'Su'];
  const dayMapping: Record<string, string> = {
    M: 'Monday',
    T: 'Tuesday',
    W: 'Wednesday',
    TH: 'Thursday',
    F: 'Friday',
    Sa: 'Saturday',
    Su: 'Sunday',
  };

  // Get service provider name
  const serviceProvider = data?.jobBillings?.find(
    billing => billing?.serviceProvider?.id === serviceProviderId
  )?.serviceProvider;

  // Get job details - filter by service provider
  const allJobDetails =
    data?.jobDetails?.length > 0
      ? data?.jobDetails
      : (data?.deal?.dealOrderDetails?.map(item => ({
          area: item?.area,
          frequency: item?.frequency,
          notes: item?.notes,
          serviceProvider: [],
          jobSpecification: item?.dealSpecifications?.map(dealSpec => {
            return {
              id: dealSpec?.id,
              specifications: dealSpec?.specifications,
              dealSpecification: dealSpec,
              serviceProviderAssignments: [],
            };
          }),
        })) ?? []);

  // Filter job details to only include those assigned to this service provider
  const jobDetails = allJobDetails
    .map(detail => {
      // Check if this detail has service provider assignments
      const hasServiceProvider =
        detail.serviceProvider?.some(sp => sp?.id === serviceProviderId) ||
        detail.jobSpecification?.some(spec =>
          spec.serviceProviderAssignments?.some(
            assignment => assignment.serviceProviderId === serviceProviderId
          )
        );

      if (!hasServiceProvider && detail.serviceProvider?.length > 0) {
        return null;
      }

      // Filter specifications to only include those assigned to this service provider
      const filteredSpecs = detail.jobSpecification?.filter(spec => {
        // If no service provider assignments, include all specs
        if (
          !spec.serviceProviderAssignments ||
          spec.serviceProviderAssignments.length === 0
        ) {
          return true;
        }
        // Otherwise, check if this service provider is assigned
        return spec.serviceProviderAssignments.some(
          assignment => assignment.serviceProviderId === serviceProviderId
        );
      });

      return {
        ...detail,
        jobSpecification: filteredSpecs,
      };
    })
    .filter(detail => detail !== null && detail.jobSpecification?.length > 0);

  // Helper function to check if a day should be marked
  const isDayIncluded = (
    spec: any,
    day: string,
    frequency?: string
  ): boolean => {
    // If frequency is "One-off", mark all days
    if (
      frequency?.toLowerCase() === 'one-off' ||
      frequency?.toLowerCase() === 'one off'
    ) {
      return true;
    }

    // Get days from serviceProviderAssignments for this specific service provider
    const assignments =
      spec?.serviceProviderAssignments?.filter(
        assignment => assignment.serviceProviderId === serviceProviderId
      ) || [];

    const allDays: string[] = [];

    assignments.forEach((assignment: any) => {
      if (assignment.days) {
        const assignmentDays = assignment.days
          .split(',')
          .map((d: string) => d.trim());
        allDays.push(...assignmentDays);
      }
    });

    // Check if the current day is in the list
    const dayName = dayMapping[day];
    return allDays.includes(dayName);
  };

  return (
    <Document>
      <Page style={styles.page}>
        {/* Top Section - Fixed on all pages */}
        <View style={styles.topSection} fixed>
          <View style={styles.leftInfo}>
            <Text style={styles.infoText}>Job No. {data.jobNo || 'N/A'}</Text>
            <Text style={styles.infoText}>
              Date:{' '}
              {data.startDate
                ? formatDate2(data.startDate, dateFormat)
                : data.createdAt
                  ? formatDate2(data.createdAt, dateFormat)
                  : 'N/A'}
            </Text>
            <Text style={styles.infoText}>
              Service Provider: {serviceProvider?.name || 'N/A'}
            </Text>
          </View>
          <View style={styles.rightInfo}>
            <Text style={styles.atYourRequest}>AT YOUR REQUEST</Text>
          </View>
        </View>

        {/* Title Banner */}
        <View style={styles.titleBanner}>
          <Text style={styles.bannerText}>WORK SPECIFICATIONS</Text>
        </View>

        {/* Customer and Site Information */}
        <View style={styles.section}>
          <Text style={{ fontSize: 9 }}>
            <Text style={styles.label}>CUSTOMER: </Text>
            <Text style={styles.value}>{data.account?.name || 'N/A'}</Text>
          </Text>
          <Text style={{ fontSize: 9 }}>
            <Text style={styles.label}>PHYSICAL ADDRESS: </Text>
            <Text style={styles.value}>
              {data.site?.fullAddress ||
                data.site?.address ||
                data.site?.streetAddress ||
                'N/A'}
            </Text>
          </Text>
          <Text style={{ fontSize: 9, marginBottom: 6 }}>
            <Text style={styles.label}>FRANCHISEE: </Text>
            <Text style={styles.value}>{serviceProvider?.name || 'N/A'}</Text>
          </Text>
          <Text style={{ fontSize: 9 }}>
            <Text style={styles.label}>KEY ACCOUNT MANAGER: </Text>
            <Text style={styles.value}>{data.keyAccount?.name || 'N/A'}</Text>
          </Text>
        </View>

        {/* Job Specifications Tables */}
        {jobDetails?.length > 0 ? (
          jobDetails.map((detail, areaIndex) => (
            <View key={areaIndex} style={styles.table} wrap={false}>
              {/* Table Header */}
              <View style={styles.tableHeader}>
                <View style={[styles.tableHeaderCell, { flex: 3 }]}>
                  <Text>{detail.area || 'N/A'}</Text>
                </View>
                {days.map((day, dayIndex) => (
                  <View key={dayIndex} style={styles.dayHeaderCell}>
                    <Text>{day}</Text>
                  </View>
                ))}
              </View>

              {/* Frequency Row */}
              <View style={styles.frequencyRow}>
                <View style={[styles.frequencyCell, { flex: 1 }]}>
                  <Text>{detail.frequency || 'N/A'}</Text>
                </View>
              </View>

              {/* Specification Rows */}
              {detail.jobSpecification?.length > 0 ? (
                detail.jobSpecification.map((spec, specIndex) => (
                  <View key={specIndex} style={styles.tableRow}>
                    <View style={[styles.tableBodyCell, { flex: 3 }]}>
                      <Text>{spec.specifications || 'N/A'}</Text>
                    </View>
                    {days.map((day, dayIndex) => (
                      <View key={dayIndex} style={styles.dayCell}>
                        {isDayIncluded(spec, day, detail.frequency) && (
                          <Image src={star} style={styles.starIcon} />
                        )}
                      </View>
                    ))}
                  </View>
                ))
              ) : (
                <View style={styles.tableRow}>
                  <View style={[styles.tableBodyCell, { flex: 1 }]}>
                    <Text>No specifications found</Text>
                  </View>
                </View>
              )}

              {/* Notes Row */}
              {detail.notes && (
                <View style={styles.notesRow}>
                  <View style={styles.notesHeaderCell}>
                    <Text>NOTES:</Text>
                  </View>
                  <View style={styles.notesCell}>
                    <Text>{detail.notes}</Text>
                  </View>
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.section}>
            <Text style={{ fontSize: 9 }}>
              No job specifications assigned to this service provider
            </Text>
          </View>
        )}

        {/* Footer - Fixed on every page */}
        <View style={styles.footer} fixed>
          <Text style={styles.footerLeft}>
            0800 297 266{'\n'}info@atyourrequest.co.nz | www.atyourrequest.co.nz
          </Text>
          <Text
            style={styles.footerRight}
            render={({ pageNumber, totalPages }) =>
              `Page ${pageNumber} of ${totalPages}`
            }
          />
        </View>
      </Page>
    </Document>
  );
};

export default JobSpecsServiceProviderPDF;
