/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image,
} from '@react-pdf/renderer';

import { formatDate2, dateFormat } from '@/utils/date.utils';
import CreditDebitNoteModel from '@/models/CreditDebitNoteModel';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';
import { ayrLogoWrap } from '@/views/sales/deals/view/tabs/quotes/QoutePages/common/logoAYRBase64';
import { formatCurrency } from '@/utils/helper.utils';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

Font.registerHyphenationCallback(word => [word]);

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 10,
    paddingTop: 60,
    paddingLeft: 50,
    paddingRight: 50,
    paddingBottom: 60,
    lineHeight: 1.4,
  },
  logo: {
    height: 80,
    width: 80,
    marginBottom: 5,
    marginTop: -20,
    objectFit: 'contain',
    alignSelf: 'flex-start',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 0,
    marginTop: -20,
  },
  leftInfo: {
    flexDirection: 'column',
    columnGap: '4px',
  },
  rightInfo: {
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'flex-start',
    fontFamily: 'Manrope',
    textAlign: 'right',
  },
  bannerText: {
    fontSize: 36,
    fontWeight: 500,
    color: '#BCA179',
    letterSpacing: 1,
    fontFamily: 'Antonio',
    marginTop: -10,
  },
  toSection: {
    marginBottom: 10,
  },
  toLabel: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    marginBottom: 2,
    fontFamily: 'Manrope',
  },
  toText: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    lineHeight: 1.5,
  },
  rightSection: {
    marginBottom: 15,
    alignItems: 'flex-end',
    textAlign: 'right',
  },
  rightSectionRow: {
    flexDirection: 'row',
    marginBottom: 2,
    justifyContent: 'flex-end',
  },
  rightLabel: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    marginRight: 5,
  },
  rightValue: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    textAlign: 'right',
  },
  rightValueDark: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    textAlign: 'right',
  },
  table: {
    width: '100%',
    marginTop: 10,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f2f2f2',
    borderTopWidth: 2,
    borderTopColor: '#b5b5b5',
  },
  tableHeaderCell: {
    padding: 6,
    paddingLeft: 0,
    fontSize: 9,
    fontWeight: 300,
    color: '#000000',
    fontFamily: 'Manrope',
    textAlign: 'left',
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  tableRow: {
    flexDirection: 'row',
  },
  tableBodyCell: {
    padding: 8,
    paddingLeft: 0,
    fontSize: 8,
    color: '#000000',
    fontFamily: 'Manrope',
    fontWeight: 300,
    textAlign: 'left',
    lineHeight: 1.3,
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  summarySection: {
    borderTopWidth: 2,
    borderTopColor: '#b5b5b5',
    marginTop: 100,
    paddingTop: 15,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 8,
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000000',
    textAlign: 'right',
    marginRight: 20,
  },
  summaryValue: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    textAlign: 'right',
    paddingHorizontal: 8,
    paddingVertical: 3,
    minWidth: 70,
    marginLeft: 40,
  },
  creditAdviceSection: {
    marginTop: 15,
    borderTopWidth: 2,
    borderTopColor: '#BCA179',
    paddingTop: 15,
    backgroundColor: '#f4f4f4',
  },
  creditAdviceTitle: {
    fontSize: 10,
    fontWeight: 700,
    color: '#000000',
    fontFamily: 'Manrope',
    paddingLeft: 10,
    marginTop: -10,
  },
  creditAdviceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 300,
  },
  creditAdviceLabel: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
  },
  creditAdviceValue: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
  },
  creditAdviceValueHighlight: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000000',
    paddingHorizontal: 4,
    paddingVertical: 2,
  },
  footer: {
    position: 'absolute',
    left: 50,
    right: 50,
    marginTop: 750,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    zIndex: 1000,
  },
  footerLeft: {
    flexDirection: 'column',
    fontSize: 8,
    color: '#686D78',
    fontWeight: 300,
  },
  footerRight: {
    fontSize: 8,
    color: '#686D78',
    fontWeight: 300,
  },
});

interface CreditDebitNotePDFProps {
  data: CreditDebitNoteModel;
  companySettings?: {
    phone?: string;
    email?: string;
    website?: string;
    tradingName?: string;
    companyName?: string;
  };
  locationBillingAccount?: {
    legalName?: string;
    billingAddress?: string;
    phone?: string;
    gst?: string;
    bStreetAddress?: string;
    bSuburb?: string;
    bCity?: string;
    bRegion?: string;
    bPostalCode?: string;
  };
  financeEmail?: string;
  type: 'DEBIT' | 'CREDIT';
  relatedAccountName?: string;
  relatedAccountBillingAddress?: {
    billingAddress?: string;
    bStreetAddress?: string;
    bSuburb?: string;
    bCity?: string;
    bRegion?: string;
    bPostalCode?: string;
  };
  relatedContactName?: string;
}

const CreditDebitNotePDF: React.FC<CreditDebitNotePDFProps> = ({
  data,
  companySettings,
  locationBillingAccount,
  financeEmail,
  type,
  relatedAccountName,
  relatedAccountBillingAddress,
  relatedContactName,
}) => {
  const isDebit = type === 'DEBIT';
  const isCredit = type === 'CREDIT';
  const title = isDebit ? 'Debit Note' : 'Credit Note';

  // KD1: Credit/Debit Note Number
  const getNoteNumber = () => {
    return isCredit
      ? data?.creditFileName ||
          `CN-${data?.creditDebitNo?.replace(/^(CN-|DN-)/, '') || '000000'}`
      : data?.debitFileName ||
          `DN-${data?.creditDebitNo?.replace(/^(CN-|DN-)/, '') || '000000'}`;
  };

  // KD2: Created at date
  const getDate = () => {
    if (data?.createdAt) {
      return formatDate2(data.createdAt, dateFormat);
    }
    return ' ';
  };

  // KD7: Billing account based on location - Legal name
  const getBillingAccountLegalName = () => {
    return locationBillingAccount?.legalName || ' ';
  };

  // KD8: Company settings - Trading name
  const getTradingName = () => {
    return companySettings?.companyName || ' ';
  };

  // KD3: Billing account based on location - GST
  const getGST = () => {
    return locationBillingAccount?.gst || ' ';
  };

  // KD9: Billing account based on location - billing address
  // Format: 1st row - [Street address] [Suburb], 2nd row - [City] [Region] [Postal code]
  const getBillingAddressLine1 = () => {
    const streetAddress = locationBillingAccount?.bStreetAddress || '';
    const suburb = locationBillingAccount?.bSuburb || '';
    const parts = [streetAddress, suburb].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const getBillingAddressLine2 = () => {
    const city = locationBillingAccount?.bCity || '';
    const region = locationBillingAccount?.bRegion || '';
    const postalCode = locationBillingAccount?.bPostalCode || '';
    const parts = [city, region, postalCode].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const hasBillingAddressFields = () => {
    return (
      locationBillingAccount?.bStreetAddress ||
      locationBillingAccount?.bSuburb ||
      locationBillingAccount?.bCity ||
      locationBillingAccount?.bRegion ||
      locationBillingAccount?.bPostalCode
    );
  };

  const getBillingAddress = () => {
    return locationBillingAccount?.billingAddress || ' ';
  };

  // KD10: Billing account based on location - phone
  const getBillingAccountPhone = () => {
    return locationBillingAccount?.phone || ' ';
  };

  // KD11: Finance email based on location
  const getFinanceEmail = () => {
    return financeEmail || ' ';
  };

  // KD4 (Credit): Account name (from job or sales order)
  const getAccountName = () => {
    if (relatedAccountName) {
      return relatedAccountName;
    }
    return ' ';
  };

  // KD5 (Credit): Related job/SO: Account - Billing address
  // Format: 1st row - [Street address] [Suburb], 2nd row - [City] [Region] [Postal code]
  const getRelatedBillingAddressLine1 = () => {
    const streetAddress = relatedAccountBillingAddress?.bStreetAddress || '';
    const suburb = relatedAccountBillingAddress?.bSuburb || '';
    const parts = [streetAddress, suburb].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const getRelatedBillingAddressLine2 = () => {
    const city = relatedAccountBillingAddress?.bCity || '';
    const region = relatedAccountBillingAddress?.bRegion || '';
    const postalCode = relatedAccountBillingAddress?.bPostalCode || '';
    const parts = [city, region, postalCode].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const hasRelatedBillingAddressFields = () => {
    return (
      relatedAccountBillingAddress?.bStreetAddress ||
      relatedAccountBillingAddress?.bSuburb ||
      relatedAccountBillingAddress?.bCity ||
      relatedAccountBillingAddress?.bRegion ||
      relatedAccountBillingAddress?.bPostalCode
    );
  };

  const getRelatedBillingAddress = () => {
    if (relatedAccountBillingAddress?.billingAddress) {
      return relatedAccountBillingAddress.billingAddress;
    }
    return ' ';
  };

  // KD6 (Credit): Related job/SO: contact name
  const getContactName = () => {
    if (relatedContactName) {
      return relatedContactName;
    }
    return ' ';
  };

  // KD4 (Debit): Service Provider
  const getServiceProvider = () => {
    return data?.serviceProvider || ' ';
  };

  // KD12: Notes
  const getNotes = () => {
    return data?.notes || ' ';
  };

  // Get amount based on type
  const getAmount = () => {
    if (isCredit) {
      return data?.creditAmount || 0;
    }
    return data?.debitAmount || 0;
  };

  // Get GST amount based on type
  // GST amount = Credit/Debit amount * 0.15
  const getGSTAmount = () => {
    if (isCredit) {
      return (data?.creditAmount || 0) * 0.15;
    }
    return (data?.debitAmount || 0) * 0.15;
  };

  // KD16/KD14: Subtotal
  const getSubtotal = () => {
    return getAmount();
  };

  // KD17/KD15: Tax (GST amount)
  const getTax = () => {
    return getGSTAmount();
  };

  // KD18/KD16: Total (Amount + GST Amount)
  const getTotal = () => {
    return getAmount() + getGSTAmount();
  };

  // KD19/KD17: Remaining Credit/Debit (Fixed 0)
  const getRemainingAmount = () => {
    return 0;
  };

  // KD20: Account name for Credit Advice
  const getCreditAdviceCustomer = () => {
    return getAccountName() || getBillingAccountLegalName();
  };

  // KD21: Outstanding balance
  const getOutstandingBalance = () => {
    return 0;
  };

  return (
    <Document
      title={
        isCredit
          ? data?.creditFileName ||
            `CN-${data?.creditDebitNo?.replace(/^(CN-|DN-)/, '') || '000000'}`
          : data?.debitFileName ||
            `DN-${data?.creditDebitNo?.replace(/^(CN-|DN-)/, '') || '000000'}`
      }
    >
      <Page style={styles.page}>
        {/* Header */}
        <View style={styles.header} fixed>
          <View style={styles.leftInfo}>
            <Image
              src={ayrLogoWrap}
              style={[styles.logo, { alignSelf: 'flex-start' }]}
            />
          </View>
          <View style={styles.rightInfo}>
            <Text style={styles.bannerText}>{title}</Text>
          </View>
        </View>

        {/* Main Content - Two Column Layout */}
        <View style={{ flexDirection: 'row', marginTop: -12 }}>
          {/* Left Column - Note Info and Customer/Service Provider */}
          <View style={{ width: '50%' }}>
            {/* Note No, Date, GST */}
            <View style={{ marginBottom: 10 }}>
              <View style={{ flexDirection: 'row' }}>
                <Text style={[styles.rightLabel, { marginRight: 5 }]}>
                  {isDebit ? 'Debit Note No:' : 'Credit Note No:'}
                </Text>
                <Text style={styles.rightValueDark}>{getNoteNumber()}</Text>
              </View>
              <View style={{ flexDirection: 'row' }}>
                <Text style={[styles.rightLabel, { marginRight: 5 }]}>
                  Date:
                </Text>
                <Text style={styles.rightValueDark}>{getDate()}</Text>
              </View>
              {getGST() && getGST() !== ' ' && (
                <View style={{ flexDirection: 'row' }}>
                  <Text style={[styles.rightLabel, { marginRight: 5 }]}>
                    GST Reg. No:
                  </Text>
                  <Text style={styles.rightValueDark}>{getGST()}</Text>
                </View>
              )}
            </View>

            {/* Credit to Section (for Credit Note) */}
            {isCredit && (
              <View style={styles.toSection}>
                <Text style={[styles.toLabel, { fontWeight: 600 }]}>
                  Credit to:
                </Text>
                <Text
                  style={[
                    styles.toText,
                    { fontWeight: 600, marginBottom: 2, fontSize: 8 },
                  ]}
                >
                  {getAccountName()}
                </Text>
                {hasRelatedBillingAddressFields() ? (
                  <>
                    {getRelatedBillingAddressLine1() && (
                      <Text style={[styles.toText]}>
                        {getRelatedBillingAddressLine1()}
                      </Text>
                    )}
                    {getRelatedBillingAddressLine2() && (
                      <Text style={[styles.toText]}>
                        {getRelatedBillingAddressLine2()}
                      </Text>
                    )}
                  </>
                ) : (
                  getRelatedBillingAddress() &&
                  getRelatedBillingAddress() !== ' ' && (
                    <Text style={[styles.toText]}>
                      {getRelatedBillingAddress()}
                    </Text>
                  )
                )}
                {getContactName() && getContactName() !== ' ' && (
                  <Text style={styles.toText}>Attn: {getContactName()}</Text>
                )}
              </View>
            )}

            {/* Service Provider Section (for Debit Note) */}
            {isDebit &&
              getServiceProvider() &&
              getServiceProvider() !== ' ' && (
                <View style={styles.toSection}>
                  <Text style={[styles.toText, { fontSize: 8 }]}>
                    {getServiceProvider()}
                  </Text>
                </View>
              )}
          </View>

          {/* Right Column - Company/Billing Account Details */}
          <View style={{ width: '50%' }}>
            <View style={styles.rightSection}>
              {/* For Debit Note: TO: prefix with Legal name */}
              {isDebit &&
                getBillingAccountLegalName() &&
                getBillingAccountLegalName() !== ' ' && (
                  <View style={{ marginBottom: 3 }}>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: 600,
                        color: '#000000',
                        textAlign: 'right',
                      }}
                    >
                      TO: {getBillingAccountLegalName()}
                    </Text>
                  </View>
                )}
              {/* For Credit Note: Legal name without TO: prefix */}
              {isCredit &&
                getBillingAccountLegalName() &&
                getBillingAccountLegalName() !== ' ' && (
                  <View style={{ marginBottom: 3 }}>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: 600,
                        color: '#000000',
                        textAlign: 'right',
                      }}
                    >
                      {getBillingAccountLegalName()}
                    </Text>
                  </View>
                )}
              {getTradingName() && getTradingName() !== ' ' && (
                <View style={{ marginBottom: 3 }}>
                  <Text
                    style={{
                      fontSize: 8,
                      fontWeight: 300,
                      color: '#000000',
                      textAlign: 'right',
                    }}
                  >
                    {getTradingName()}
                  </Text>
                </View>
              )}
              {hasBillingAddressFields() ? (
                <>
                  {getBillingAddressLine1() && (
                    <View style={{ marginBottom: 3 }}>
                      <Text
                        style={{
                          fontSize: 8,
                          fontWeight: 300,
                          color: '#000000',
                          textAlign: 'right',
                        }}
                      >
                        {getBillingAddressLine1()}
                      </Text>
                    </View>
                  )}
                  {getBillingAddressLine2() && (
                    <View style={{ marginBottom: 3 }}>
                      <Text
                        style={{
                          fontSize: 8,
                          fontWeight: 300,
                          color: '#000000',
                          textAlign: 'right',
                        }}
                      >
                        {getBillingAddressLine2()}
                      </Text>
                    </View>
                  )}
                </>
              ) : (
                getBillingAddress() &&
                getBillingAddress() !== ' ' && (
                  <View style={{ marginBottom: 3 }}>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: 300,
                        color: '#000000',
                        textAlign: 'right',
                      }}
                    >
                      {getBillingAddress()}
                    </Text>
                  </View>
                )
              )}
              {getBillingAccountPhone() && getBillingAccountPhone() !== ' ' && (
                <View style={[styles.rightSectionRow]}>
                  <Text style={styles.rightLabel}>DDI:</Text>
                  <Text style={styles.rightValueDark}>
                    {getBillingAccountPhone()}
                  </Text>
                </View>
              )}
              {getFinanceEmail() && getFinanceEmail() !== ' ' && (
                <View style={[styles.rightSectionRow, { marginBottom: 3 }]}>
                  <Text style={styles.rightLabel}>Email:</Text>
                  <Text style={styles.rightValueDark}>{getFinanceEmail()}</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* Items Table */}
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableHeader}>
            <View
              style={[
                styles.tableHeaderCell,
                { width: '50%', paddingLeft: 10 },
              ]}
            >
              <Text style={{ fontWeight: 700 }}>DESCRIPTION</Text>
            </View>
            <View
              style={[
                styles.tableHeaderCell,
                {
                  width: '10%',
                  textAlign: 'center',
                  justifyContent: 'center',
                  alignItems: 'center',
                  paddingRight: 10,
                },
              ]}
            >
              <Text style={{ fontWeight: 700 }}>QTY</Text>
            </View>
            <View
              style={[
                styles.tableHeaderCell,
                {
                  width: '20%',
                  textAlign: 'right',
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  paddingRight: 10,
                },
              ]}
            >
              <Text style={{ fontWeight: 700 }}>UNIT PRICE</Text>
            </View>
            <View
              style={[
                styles.tableHeaderCell,
                {
                  width: '20%',
                  textAlign: 'right',
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  paddingRight: 10,
                },
              ]}
            >
              <Text style={{ fontWeight: 700 }}>AMOUNT</Text>
            </View>
          </View>

          {/* Table Row - Item */}
          <View style={styles.tableRow} wrap={false}>
            <View
              style={[styles.tableBodyCell, { width: '50%', paddingLeft: 10 }]}
            >
              <Text>{getNotes()}</Text>
            </View>
            <View
              style={[
                styles.tableBodyCell,
                {
                  width: '10%',
                  textAlign: 'center',
                  justifyContent: 'center',
                  alignItems: 'center',
                  paddingRight: 10,
                },
              ]}
            >
              <Text>1</Text>
            </View>
            <View
              style={[
                styles.tableBodyCell,
                {
                  width: '20%',
                  textAlign: 'right',
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  paddingRight: 10,
                },
              ]}
            >
              <Text>{formatCurrency(getAmount())}</Text>
            </View>
            <View
              style={[
                styles.tableBodyCell,
                {
                  width: '20%',
                  textAlign: 'right',
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  paddingRight: 10,
                },
              ]}
            >
              <Text>{formatCurrency(getAmount())}</Text>
            </View>
          </View>
        </View>

        {/* Summary Section */}
        <View style={styles.summarySection}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Subtotal</Text>
            <Text style={styles.summaryValue}>
              {formatCurrency(getSubtotal())}
            </Text>
          </View>
          <View style={[styles.summaryRow, { marginTop: -5 }]}>
            <Text style={styles.summaryLabel}>Tax</Text>
            <Text style={styles.summaryValue}>{formatCurrency(getTax())}</Text>
          </View>
          <View style={[styles.summaryRow, { marginTop: -5 }]}>
            <Text style={styles.summaryLabel}>
              Less {isCredit ? 'Credit' : 'Debit'} to Invoice(s) / Refund(s)
            </Text>
            <Text style={styles.summaryValue}>
              {formatCurrency(getTotal())}
            </Text>
          </View>
          <View style={[styles.summaryRow, { marginTop: -5 }]}>
            <Text style={styles.summaryLabel}>
              Remaining {isCredit ? 'Credit' : 'Debit'}
            </Text>
            <Text style={styles.summaryValue}>
              {formatCurrency(getRemainingAmount())}
            </Text>
          </View>
        </View>

        {/* Credit Advice Section (only for Credit Note) */}
        {isCredit && (
          <View style={styles.creditAdviceSection}>
            <Text style={styles.creditAdviceTitle}>CREDIT ADVICE</Text>
            <View style={styles.creditAdviceRow}>
              <Text style={styles.creditAdviceLabel}>Customer: </Text>
              <Text style={styles.creditAdviceValueHighlight}>
                {getAccountName()}
              </Text>
            </View>
            <View style={styles.creditAdviceRow}>
              <Text style={styles.creditAdviceLabel}>Credit Note No: </Text>
              <Text style={styles.creditAdviceValue}>{getNoteNumber()}</Text>
            </View>
            <View style={styles.creditAdviceRow}>
              <Text style={styles.creditAdviceLabel}>Credit Amount: </Text>
              <Text style={styles.creditAdviceValueHighlight}>
                {formatCurrency(getTotal())}
              </Text>
            </View>
          </View>
        )}
      </Page>
    </Document>
  );
};

export default CreditDebitNotePDF;
