import { StyleSheet } from '@react-pdf/renderer';

export const styles = StyleSheet.create({
  page: {
    paddingTop: 30,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 40,
  },
  topHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  leftTopHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 'auto',
    marginRight: 15,
    paddingTop: '16px',
    marginLeft: '3px',
  },
  companyInfo: {
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
  leftSection: {
    width: '50%',
  },
  rightSection: {
    width: '50%',
    alignItems: 'flex-end',
  },
  companyName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  tradingName: {
    fontSize: 8,
    fontWeight: 400,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  companyAddress: {
    fontSize: 8,
    color: '#090A0B',
    lineHeight: 1.3,
    textAlign: 'right',
    fontFamily: 'Manrope',
  },
  companyPhone: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  companyEmail: {
    fontSize: 8,
    color: '#000',
    marginBottom: 6,
    fontFamily: 'Manrope',
  },
  invoiceTitle: {
    fontFamily: 'Antonio',
    fontSize: 28,
    color: '#D4A574',
  },
  invoiceDetailsSection: {
    marginBottom: 16,
    width: 'auto',
  },
  invoiceToTitle: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
  },
  billedToTitle: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
    marginBottom: 4,
  },
  shippedToTitle: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
    marginBottom: 4,
    marginTop: 12,
  },
  purchasedOrderTitle: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
    marginTop: 12,
  },
  poNumberText: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
  },
  accountName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  billingAddress: {
    fontSize: 8,
    fontFamily: 'Manrope',
    color: '#000',
    lineHeight: 1.3,
  },
  contactName: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  invoiceToSection: {
    marginBottom: 0,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  detailLabel: {
    width: 80,
    fontSize: 9,
    color: '#000',
  },
  detailLabels: {
    fontSize: 9,
    color: '#000',
  },
  detailValue: {
    fontSize: 9,
    color: '#000',
    flex: 1,
  },
  table: {
    marginBottom: 20,
    borderTopWidth: 3,
    borderTop: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 8,
    paddingHorizontal: 5,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderBottomColor: '#eee',
    paddingVertical: 6,
    paddingHorizontal: 5,
  },
  tableHeaderCell: {
    fontSize: 9,
    fontWeight: 700,
    color: '#333',
  },
  tableCell: {
    fontSize: 9,
    color: '#333',
  },
  itemIdColumn: {
    flex: 1,
    textAlign: 'left',
  },
  descriptionColumn: {
    flex: 2,
  },
  quantityColumn: {
    flex: 1,
    textAlign: 'center',
  },
  priceColumn: {
    flex: 1,
    textAlign: 'right',
  },
  amountColumn: {
    flex: 1,
    textAlign: 'right',
  },
  summary: {
    marginTop: 0,
    alignItems: 'flex-end',
  },
  summaryBox: {
    width: 200,
    padding: 0,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: 10,
  },
  summaryLabel: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    fontWeight: 400,
  },
  summaryValue: {
    fontSize: 9,
    color: '#090A0B',
    fontWeight: 400,
    fontFamily: 'Manrope',
  },
  balanceDueRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#D4A574',
    padding: 8,
    borderRadius: 3,
  },
  balanceDueLabel: {
    fontSize: 9,
    fontWeight: 400,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  balanceDueValue: {
    fontSize: 9,
    fontWeight: 400,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  summarySection: {
    marginTop: 0,
  },
  commentsHeader: {
    marginBottom: 0,
    marginTop: 0,
  },
  commentsText: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
  },
  commentsContent: {
    marginTop: 5,
    maxWidth: 300,
  },
  notesText: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    lineHeight: 1.3,
  },
  summaryTopBorder: {
    borderTopWidth: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
    marginBottom: 15,
    width: '100%',
  },
  commentsAndSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    position: 'absolute',
    bottom: 30,
    left: 30,
    right: 30,
    zIndex: 999, // <-- force render above content
  },
  footerLeft: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  footerRight: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  footerTextSpacing: {
    marginLeft: 20,
  },
});
