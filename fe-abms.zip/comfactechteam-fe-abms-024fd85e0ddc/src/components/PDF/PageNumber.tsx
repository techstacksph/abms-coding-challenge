import React from 'react';

import { Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  pageNumberContainer: {
    position: 'absolute',
    top: '1.27cm',
    right: '1.91cm',
    zIndex: 100,
  },
  pageNumber: {
    fontSize: 12,
    fontFamily: 'Antonio',
    fontWeight: 'bold',
    color: '#000000', // Changed to black
  },
});

const PageNumber = () => {
  return (
    <View style={styles.pageNumberContainer} fixed>
      <Text style={styles.pageNumber} render={({ pageNumber }) => pageNumber} />
    </View>
  );
};

export default PageNumber;
