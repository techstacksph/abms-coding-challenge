/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image,
} from '@react-pdf/renderer';

import { formatDate2, dateFormat } from '@/utils/date.utils';
import DeliveryReturnModel, {
  DeliveryReturnItemModel,
} from '@/models/DeliveryReturnModel';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';
import { ayrLogoWrap } from '@/views/sales/deals/view/tabs/quotes/QoutePages/common/logoAYRBase64';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

Font.registerHyphenationCallback(word => [word]);

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 10,
    paddingTop: 60,
    paddingLeft: 50,
    paddingRight: 50,
    paddingBottom: 60,
    lineHeight: 1.4,
  },
  logo: {
    height: 75,
    width: 75,
    marginBottom: 5,
    marginTop: -20,
    objectFit: 'contain',
    alignSelf: 'flex-start',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -20,
  },
  titleBanner: {
    textAlign: 'center',
    marginBottom: 20,
    marginTop: 5,
  },
  leftInfo: {
    flexDirection: 'column',
    columnGap: '4px',
  },
  rightInfo: {
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'flex-start',
    fontFamily: 'Manrope',
    textAlign: 'right',
  },
  bannerText: {
    fontSize: 36,
    fontWeight: 400,
    color: '#BCA179',
    letterSpacing: 1,
    fontFamily: 'Antonio',
    marginTop: -10,
  },
  shippedToSection: {},
  shippedToLabel: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    fontFamily: 'Manrope',
  },
  shippedToText: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    lineHeight: 1.5,
  },
  rightSection: {
    alignItems: 'flex-end',
    textAlign: 'right',
  },
  rightSectionRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  rightLabel: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    marginRight: 5,
  },
  rightValue: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    textAlign: 'right',
  },
  rightValueDark: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    textAlign: 'right',
  },
  table: {
    width: '100%',
    marginTop: 20,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f2f2f2',
    borderTopWidth: 2,
    borderTopColor: '#b5b5b5',
  },
  tableHeaderCell: {
    padding: 6,
    paddingLeft: 0,
    fontSize: 9,
    fontWeight: 300,
    color: '#000000',
    fontFamily: 'Manrope',
    textAlign: 'left',
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  tableRow: {
    flexDirection: 'row',
  },
  tableBodyCell: {
    padding: 8,
    paddingLeft: 0,
    fontSize: 8,
    color: '#000000',
    fontFamily: 'Manrope',
    fontWeight: 300,
    textAlign: 'left',
    lineHeight: 1.3,
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  commentsSection: {
    marginTop: 20,
    marginBottom: 20,
  },
  commentsLabel: {
    fontSize: 9,
    fontWeight: 300,
    color: '#000000',
    marginBottom: 5,
    borderTopWidth: 2,
    borderTopColor: '#b5b5b5',
    paddingTop: 5,
  },
  commentsBox: {
    minHeight: 80,
    padding: 8,
    paddingTop: 0,
  },
  commentsText: {
    fontSize: 8,
    fontWeight: 300,
    color: '#000000',
    lineHeight: 1.5,
  },
  footer: {
    position: 'absolute',
    left: 50,
    right: 50,
    marginTop: 750,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    zIndex: 1000,
  },
  footerLeft: {
    flexDirection: 'column',
    fontSize: 8,
    color: '#686D78',
    fontWeight: 300,
  },
  footerRight: {
    fontSize: 8,
    color: '#686D78',
    fontWeight: 300,
  },
});

interface DeliveryReturnPackingSlipPDFProps {
  data: DeliveryReturnModel;
  items: DeliveryReturnItemModel[];
  companySettings?: {
    phone?: string;
    email?: string;
    website?: string;
    tradingName?: string;
    companyName?: string;
  };
  locationBillingAccount?: {
    legalName?: string;
    billingAddress?: string;
    phone?: string;
    bStreetAddress?: string;
    bSuburb?: string;
    bCity?: string;
    bRegion?: string;
    bPostalCode?: string;
  };
  financeEmail?: string;
  customerBillingAccount?: any;
}

const DeliveryReturnPackingSlipPDF: React.FC<
  DeliveryReturnPackingSlipPDFProps
> = ({
  data,
  items,
  companySettings,
  locationBillingAccount,
  customerBillingAccount,
}) => {
  const finalData = data;
  const finalItems = items;
  const finalCompanySettings = companySettings;
  const finalLocationBillingAccount = locationBillingAccount;
  const finalFinanceEmail = data?.location?.financeEmail;
  // KD1: Account name - Customer name
  const getCustomerName = () => {
    return customerBillingAccount?.name || finalData?.customer?.name || ' ';
  };

  // KD2: Account - Billing address (Customer billing address)
  // Format: [Street address] [Suburb] [Postal code]
  const getCustomerBillingAddress = () => {
    const streetAddress =
      customerBillingAccount?.bStreetAddress ||
      finalData?.customer?.bStreetAddress ||
      '';
    const suburb =
      customerBillingAccount?.bSuburb || finalData?.customer?.bSuburb || '';
    const postalCode =
      customerBillingAccount?.bPostalCode ||
      finalData?.customer?.bPostalCode ||
      '';

    const parts = [streetAddress, suburb, postalCode].filter(Boolean);
    if (parts.length > 0) {
      return parts.join(' ');
    }
    return (
      customerBillingAccount?.billingAddress ||
      finalData?.customer?.billingAddress ||
      ' '
    );
  };

  // KD3: Billing account based on location - Legal name
  const getBillingAccountLegalName = () => {
    return finalLocationBillingAccount?.legalName || ' ';
  };

  // KD5: Billing account based on location - Billing address (Office address)
  // Format: 1st row - [Street address] [Suburb], 2nd row - [City] [Region] [Postal code]
  const getBillingAccountAddressLine1 = () => {
    const streetAddress = finalLocationBillingAccount?.bStreetAddress || '';
    const suburb = finalLocationBillingAccount?.bSuburb || '';
    const parts = [streetAddress, suburb].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const getBillingAccountAddressLine2 = () => {
    const city = finalLocationBillingAccount?.bCity || '';
    const region = finalLocationBillingAccount?.bRegion || '';
    const postalCode = finalLocationBillingAccount?.bPostalCode || '';
    const parts = [city, region, postalCode].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : '';
  };

  const hasBillingAccountAddressFields = () => {
    return (
      finalLocationBillingAccount?.bStreetAddress ||
      finalLocationBillingAccount?.bSuburb ||
      finalLocationBillingAccount?.bCity ||
      finalLocationBillingAccount?.bRegion ||
      finalLocationBillingAccount?.bPostalCode
    );
  };

  const getBillingAccountAddress = () => {
    return finalLocationBillingAccount?.billingAddress || ' ';
  };

  // KD6: Billing account based on location - Phone
  const getBillingAccountPhone = () => {
    return finalLocationBillingAccount?.phone || ' ';
  };

  // KD7: Finance email based on location
  const getFinanceEmail = () => {
    return finalFinanceEmail || ' ';
  };

  // KD8: SO # (Sales Order number)
  const getOrderNumber = () => {
    if (finalData?.relatedRecordType === 'SALES_ORDER') {
      return finalData?.salesOrder?.soNo || ' ';
    }
    return ' ';
  };

  // KD9 & KD10: SO date (Sales order date)
  const getSODate = () => {
    if (finalData?.salesOrder?.soDate) {
      return formatDate2(finalData.salesOrder.soDate, dateFormat);
    }
    return ' ';
  };

  // Promised Date
  const getPromisedDate = () => {
    if (finalData?.preferredPickupDateTime) {
      return formatDate2(finalData.preferredPickupDateTime, dateFormat);
    } else if (finalData?.drDate) {
      return formatDate2(finalData.drDate, dateFormat);
    }
    return ' ';
  };
  // KD12: Notes
  const getNotes = () => {
    return finalData?.drNotes || '';
  };

  return (
    <Document title={finalData?.drNo || 'Packing slip'}>
      <Page style={styles.page}>
        {/* Header */}
        <View style={styles.header} fixed>
          <View style={styles.leftInfo}>
            <Image
              src={ayrLogoWrap}
              style={[styles.logo, { alignSelf: 'flex-start' }]}
            />
          </View>
          <View style={styles.rightInfo}>
            <Text style={styles.bannerText}>PACKING SLIP</Text>
          </View>
        </View>

        {/* Main Content - Two Column Layout */}
        <View style={{ flexDirection: 'row', marginTop: -13 }}>
          <View style={{ width: '55%' }}>
            <View style={styles.shippedToSection}>
              <Text style={styles.shippedToLabel}>SHIPPED TO:</Text>
              <Text style={[styles.shippedToText, { fontWeight: 300 }]}>
                {getCustomerName()}
              </Text>
              <Text style={styles.shippedToText}>
                {getCustomerBillingAddress()}
              </Text>
            </View>
          </View>

          {/* Right Column - Details */}
          <View style={{ width: '45%' }}>
            <View style={styles.rightSection}>
              {getBillingAccountLegalName() &&
                getBillingAccountLegalName() !== ' ' && (
                  <View>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: 300,
                        color: '#000000',
                        textAlign: 'right',
                      }}
                    >
                      {getBillingAccountLegalName()}
                    </Text>
                  </View>
                )}
              {finalCompanySettings?.companyName && (
                <View>
                  <Text
                    style={{
                      fontSize: 8,
                      fontWeight: 300,
                      color: '#000000',
                      textAlign: 'right',
                    }}
                  >
                    {finalCompanySettings.companyName}
                  </Text>
                </View>
              )}
              {hasBillingAccountAddressFields() ? (
                <>
                  {getBillingAccountAddressLine1() && (
                    <View>
                      <Text
                        style={{
                          fontSize: 8,
                          fontWeight: 300,
                          color: '#000000',
                          textAlign: 'right',
                        }}
                      >
                        {getBillingAccountAddressLine1()}
                      </Text>
                    </View>
                  )}
                  {getBillingAccountAddressLine2() && (
                    <View>
                      <Text
                        style={{
                          fontSize: 8,
                          fontWeight: 300,
                          color: '#000000',
                          textAlign: 'right',
                        }}
                      >
                        {getBillingAccountAddressLine2()}
                      </Text>
                    </View>
                  )}
                </>
              ) : (
                getBillingAccountAddress() &&
                getBillingAccountAddress() !== ' ' && (
                  <View>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: 300,
                        color: '#000000',
                        textAlign: 'right',
                      }}
                    >
                      {getBillingAccountAddress()}
                    </Text>
                  </View>
                )
              )}
              {getBillingAccountPhone() && getBillingAccountPhone() !== ' ' && (
                <View style={[styles.rightSectionRow]}>
                  <Text style={styles.rightLabel}>DDI:</Text>
                  <Text style={styles.rightValueDark}>
                    {getBillingAccountPhone()}
                  </Text>
                </View>
              )}
              {/* KD7: Finance email based on location */}
              {getFinanceEmail() && getFinanceEmail() !== ' ' && (
                <View style={[styles.rightSectionRow]}>
                  <Text style={styles.rightLabel}>Email:</Text>
                  <Text style={styles.rightValueDark}>{getFinanceEmail()}</Text>
                </View>
              )}
              {/* KD8: SO # */}
              {getOrderNumber() && getOrderNumber() !== ' ' && (
                <View style={[styles.rightSectionRow, { marginTop: 12 }]}>
                  <Text style={styles.rightLabel}>Sales Order No:</Text>
                  <Text style={styles.rightValueDark}>{getOrderNumber()}</Text>
                </View>
              )}
              {/* KD9: SO date */}
              {getSODate() && getSODate() !== ' ' && (
                <View style={styles.rightSectionRow}>
                  <Text style={styles.rightLabel}>Date:</Text>
                  <Text style={styles.rightValueDark}>{getSODate()}</Text>
                </View>
              )}
              {/* KD10: Promised Date */}
              {getSODate() && getSODate() !== ' ' && (
                <View style={styles.rightSectionRow}>
                  <Text style={styles.rightLabel}>Promised Date:</Text>
                  <Text style={styles.rightValueDark}>{getSODate()}</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* Items Table */}
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableHeader}>
            <View style={[styles.tableHeaderCell, { width: '20%' }]}>
              <Text>ITEM ID</Text>
            </View>
            <View style={[styles.tableHeaderCell, { width: '60%' }]}>
              <Text>DESCRIPTION</Text>
            </View>
            <View
              style={[
                styles.tableHeaderCell,
                {
                  width: '20%',
                  textAlign: 'center',
                  justifyContent: 'center',
                  alignItems: 'center',
                },
              ]}
            >
              <Text>QTY</Text>
            </View>
          </View>

          {/* Table Rows */}
          {finalItems && finalItems.length > 0 ? (
            finalItems.map((item, index) => (
              <View key={index} style={styles.tableRow} wrap={false}>
                <View style={[styles.tableBodyCell, { width: '20%' }]}>
                  <Text>{item?.item?.itemCode || ' '}</Text>
                </View>
                <View style={[styles.tableBodyCell, { width: '60%' }]}>
                  <Text>{item?.item?.name || ' '}</Text>
                </View>
                <View
                  style={[
                    styles.tableBodyCell,
                    {
                      width: '20%',
                      textAlign: 'right',
                      justifyContent: 'flex-end',
                      alignItems: 'flex-end',
                    },
                  ]}
                >
                  <Text>{item?.drQuantity || 0}</Text>
                </View>
              </View>
            ))
          ) : (
            <View style={styles.tableRow} wrap={false}>
              <View
                style={[
                  styles.tableBodyCell,
                  { width: '100%', minHeight: 100 },
                ]}
              >
                <Text>No items found</Text>
              </View>
            </View>
          )}
        </View>

        {/* KD12: Notes - Comments Section */}
        <View style={styles.commentsSection} wrap={false}>
          <Text style={styles.commentsLabel}>COMMENTS:</Text>
          <View style={styles.commentsBox}>
            <Text style={styles.commentsText}>{getNotes()}</Text>
          </View>
        </View>

        {/* Footer */}
        <View style={styles.footer} fixed>
          <View style={{ flexDirection: 'column' }}>
            <Text
              style={styles.footerRight}
              render={({ pageNumber, totalPages }) =>
                `Page ${pageNumber} of ${totalPages}`
              }
            />
          </View>
          <Text style={[styles.footerLeft]}>SO No. : {getOrderNumber()}</Text>
        </View>
      </Page>
    </Document>
  );
};

export default DeliveryReturnPackingSlipPDF;
