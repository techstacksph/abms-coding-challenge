import React from 'react';

import { Document, Page, Text, View, Image, Font } from '@react-pdf/renderer';

import { formatCurrency } from '@/utils/helper.utils';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import SalesOrderModel from '@/models/SalesOrderModel';
import SalesOrderItemModel from '@/models/SalesOrderItemModel';
import { ayrLogo } from '@/constants/PDF/base64Images';
import { styles } from './SalesOrderPDF.styles';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

interface SalesOrderPDFProps {
  data: SalesOrderModel;
  salesOrderItems: SalesOrderItemModel[];
  companySettings?: any;
  purchaseOrderNo?: string;
}

const SalesOrderPDF: React.FC<SalesOrderPDFProps> = ({
  data,
  salesOrderItems,
  companySettings,
  purchaseOrderNo,
}) => {
  // Extract trading name from companySettings
  // ModuleStatus now fetches and transforms data[0], so it should be an object
  // Service layer also normalizes as fallback, so handle both for safety
  let tradingName: string | undefined = undefined;

  if (companySettings) {
    // Handle array format (if normalization didn't happen)
    if (Array.isArray(companySettings) && companySettings.length > 0) {
      tradingName = companySettings[0]?.tradingName;
    }
    // Handle object format (after transformData or service layer normalization)
    else if (companySettings.tradingName) {
      tradingName = companySettings.tradingName;
    }
  }

  // Clean and validate
  if (tradingName && typeof tradingName === 'string') {
    tradingName = tradingName.trim();
    if (tradingName === '') {
      tradingName = undefined;
    }
  } else {
    tradingName = undefined;
  }

  // Get billing account from location
  const billingAccount = data.location?.billingAccount;

  // Helper function to clean address strings that contain "undefined"
  const cleanAddressString = (address: string | undefined): string => {
    if (!address) return '';

    // Split by comma, filter out "undefined" and empty parts, then rejoin
    return address
      .split(',')
      .map(part => part.trim())
      .filter(
        part =>
          part &&
          part.toLowerCase() !== 'undefined' &&
          part.toLowerCase() !== 'null'
      )
      .join(', ');
  };

  return (
    <Document>
      <Page size='A4' style={styles.page}>
        {/* Top Header: Logo on left, SALES ORDER on right */}
        <View style={styles.topHeader}>
          <View style={styles.leftTopHeader}>
            <Image src={ayrLogo} style={styles.logo} />
          </View>
          <Text style={styles.invoiceTitle}>SALES ORDER</Text>
        </View>

        {/* Company Information - Two column layout */}
        <View style={styles.companyInfo}>
          <View style={styles.leftSection}>
            {/* BILLED TO Section */}
            {(() => {
              // Use customer first, if not available use franchisee
              const account = data.customer || data.franchisee;
              
              return (
                <View style={styles.invoiceToSection}>
                  <Text style={styles.billedToTitle}>BILLED TO:</Text>
                  {/* Account name (Customer first, if not available Franchisee) */}
                  {account?.name && (
                    <Text style={styles.accountName}>{account.name}</Text>
                  )}
                  {/* Account - Billing address (1st row: Street address + Suburb) */}
                  {(account?.bStreetAddress || account?.bSuburb) && (
                    <Text style={styles.billingAddress}>
                      {[account?.bStreetAddress, account?.bSuburb]
                        .filter(Boolean)
                        .join(', ')}
                    </Text>
                  )}
                  {/* Account - Billing address (2nd row: City + Region + Postal code) */}
                  {(account?.bCity ||
                    account?.bRegion ||
                    account?.bPostalCode) && (
                    <Text style={styles.billingAddress}>
                      {[
                        account?.bCity,
                        account?.bRegion,
                        account?.bPostalCode,
                      ]
                        .filter(Boolean)
                        .join(', ')}
                    </Text>
                  )}
                </View>
              );
            })()}

            {/* SHIPPED TO Section */}
            {(() => {
              // Use customer first, if not available use franchisee
              const account = data.customer || data.franchisee;
              
              return (
                <View style={styles.invoiceToSection}>
                  <Text style={styles.shippedToTitle}>SHIPPED TO:</Text>
                  {/* Account name (Customer first, if not available Franchisee) */}
                  {account?.name && (
                    <Text style={styles.accountName}>{account.name}</Text>
                  )}
                  {/* Account - Billing address (1st row: Street address + Suburb) */}
                  {(account?.bStreetAddress || account?.bSuburb) && (
                    <Text style={styles.billingAddress}>
                      {[account?.bStreetAddress, account?.bSuburb]
                        .filter(Boolean)
                        .join(', ')}
                    </Text>
                  )}
                  {/* Account - Billing address (2nd row: City + Region + Postal code) */}
                  {(account?.bCity ||
                    account?.bRegion ||
                    account?.bPostalCode) && (
                    <Text style={styles.billingAddress}>
                      {[
                        account?.bCity,
                        account?.bRegion,
                        account?.bPostalCode,
                      ]
                        .filter(Boolean)
                        .join(', ')}
                    </Text>
                  )}
                </View>
              );
            })()}

            {/* Purchased Order No. Section */}
            <View style={styles.invoiceToSection}>
              <Text style={styles.purchasedOrderTitle}>
                Purchased Order No.:
              </Text>
              <Text style={styles.poNumberText}>
                {data.customerReference || purchaseOrderNo ? `${data.customerReference || purchaseOrderNo}` : ''}
              </Text>
            </View>
          </View>

          <View style={styles.rightSection}>
            {(billingAccount?.legalName || billingAccount?.name) && (
              <Text style={styles.companyName}>
                {billingAccount.legalName || billingAccount.name}
              </Text>
            )}

            {tradingName ? (
              <Text style={styles.tradingName}>{tradingName}</Text>
            ) : null}

            {(billingAccount?.bStreetAddress || billingAccount?.bSuburb) && (
              <Text style={styles.companyAddress}>
                {[billingAccount?.bStreetAddress, billingAccount?.bSuburb]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            {(billingAccount?.bCity ||
              billingAccount?.bRegion ||
              billingAccount?.bPostalCode) && (
              <Text style={styles.companyAddress}>
                {[
                  billingAccount?.bCity,
                  billingAccount?.bRegion,
                  billingAccount?.bPostalCode,
                ]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            <Text style={styles.companyPhone}>
              DDI: {billingAccount?.ayrMobile || ''}
            </Text>

            <Text style={styles.companyEmail}>
              Email: {data.location?.financeEmail || ''}
            </Text>

            <Text style={styles.companyPhone}>
              GST Reg. No.: {billingAccount?.gst || ''}
            </Text>

            <Text style={styles.companyPhone}>
              Sales Order No.: {data.soNo || ''}
            </Text>

            <Text style={styles.companyPhone}>
              Date: {data.soDate ? formatDate2(data.soDate, dateFormat) : ''}
            </Text>

            <Text style={styles.companyPhone}>
              Promised Date:{' '}
              {data.soDate ? formatDate2(data.soDate, dateFormat) : ''}
            </Text>
          </View>
        </View>

        {/* Sales Order Items Table */}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderCell, styles.itemIdColumn]}>
              ITEM ID
            </Text>
            <Text style={[styles.tableHeaderCell, styles.descriptionColumn]}>
              DESCRIPTION
            </Text>
            <Text style={[styles.tableHeaderCell, styles.quantityColumn]}>
              QTY
            </Text>
            <Text style={[styles.tableHeaderCell, styles.priceColumn]}>
              UNIT PRICE
            </Text>
            <Text style={[styles.tableHeaderCell, styles.amountColumn]}>
              AMOUNT
            </Text>
          </View>

          {salesOrderItems.map((item, index) => {
            // Calculate unitPrice from amount/quantity if not available
            const unitPrice =
              item.unitPrice ||
              (item.quantity && item.amount ? item.amount / item.quantity : 0);

            // Get description - use item description if available, otherwise empty string
            const description = item.item?.description?.trim() || '';

            return (
              <View key={item.id || index} style={styles.tableRow}>
                <Text style={[styles.tableCell, styles.itemIdColumn]}>
                  {item.item?.itemCode || ''}
                </Text>
                <Text style={[styles.tableCell, styles.descriptionColumn]}>
                  {description}
                </Text>
                <Text style={[styles.tableCell, styles.quantityColumn]}>
                  {item.quantity || 0}
                </Text>
                <Text style={[styles.tableCell, styles.priceColumn]}>
                  {formatCurrency(unitPrice)}
                </Text>
                <Text style={[styles.tableCell, styles.amountColumn]}>
                  {formatCurrency(item.amount || 0)}
                </Text>
              </View>
            );
          })}
        </View>

        {/* Comments and Sales Order Summary Section */}
        <View style={styles.summarySection}>
          {/* Top Border */}
          <View style={styles.summaryTopBorder} />

          {/* Comments and Summary Row */}
          <View style={styles.commentsAndSummaryRow}>
            {/* Comments Header */}
            <View style={styles.commentsHeader}>
              <Text style={styles.commentsText}>COMMENTS:</Text>
              {data.notes && data.notes.trim() && (
                <View style={styles.commentsContent}>
                  <Text style={styles.notesText}>{data.notes}</Text>
                </View>
              )}
            </View>

            {/* Sales Order Summary */}
            <View style={styles.summary}>
              <View style={styles.summaryBox}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Subtotal:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(
                      data.totalAmountGSTExclusive || data.totalSOAmount || 0
                    )}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Tax:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.gst || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Total Amount:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.totalAmountGSTInclusive || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Paid to date:</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.totalPaid || 0)}
                  </Text>
                </View>
                <View style={styles.balanceDueRow}>
                  <Text style={styles.balanceDueLabel}>Balance Due:</Text>
                  <Text style={styles.balanceDueValue}>
                    {formatCurrency(data.balanceDue || 0)}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Footer - Fixed on every page */}
        <View style={styles.footer} fixed>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text
              style={styles.footerLeft}
              render={({ pageNumber, totalPages }) =>
                `Page ${pageNumber} of ${totalPages}`
              }
            />
            <Text style={[styles.footerLeft, { marginLeft: 20 }]}>
              Allocated PO No.:{data.customerReference || purchaseOrderNo ? `${data.customerReference || purchaseOrderNo}` : ''}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={styles.footerRight}>SO No.: {data.soNo || ''}</Text>
            <Text style={[styles.footerRight, { marginLeft: 20 }]}>
              Balance Due: {formatCurrency(data.balanceDue || 0)}
            </Text>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default SalesOrderPDF;
