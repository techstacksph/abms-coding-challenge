import React from 'react';

import { View, Text, Image } from '@react-pdf/renderer';

import { styles } from '../../constants/PDF/StyleSheet';
import { star } from '../../constants/PDF/base64Images';
import { DEFAULT_VALUE } from '../../constants/PDF/constants';

// Define interfaces for the cleaning schedule data
export interface DealSpecification {
  specifications: string;
  days: string;
}

const getUniqueDays = (obj: any, path: string): string => {
  // Get the array from the path
  const assignments = obj[path];

  if (!Array.isArray(assignments)) {
    return '';
  }

  // Extract all days from the assignments
  const allDays: string[] = [];

  assignments.forEach((assignment: any) => {
    if (assignment.days) {
      // Split the days string and add to array
      const days = assignment.days.split(',').map((day: string) => day.trim());
      allDays.push(...days);
    }
  });

  // Create a mapping from short day codes to full day names
  const dayMapping: Record<string, string> = {
    Mo: 'Monday',
    Tu: 'Tuesday',
    We: 'Wednesday',
    Th: 'Thursday',
    Fr: 'Friday',
    Sa: 'Saturday',
    Su: 'Sunday',
  };

  // Convert short codes to full names and get unique values
  const uniqueDayNames = [
    ...new Set(allDays.map(day => dayMapping[day] || day).filter(day => day)),
  ];

  return uniqueDayNames.join(', ');
};

// Helper function to determine if a day is included in the days string
const isDayIncluded = (days: string, day: string): boolean => {
  const daysMap: Record<string, string[]> = {
    M: ['Monday'],
    T: ['Tuesday'],
    W: ['Wednesday'],
    TH: ['Thursday'],
    F: ['Friday'],
    Sa: ['Saturday'],
    Su: ['Sunday'],
  };

  const dayNames = daysMap[day] || [];
  return dayNames.some(dayName => days?.includes(dayName));
};

export const WorkSpecificationTable = ({
  data,
  specificationField,
  daysField,
}: {
  data: any;
  specificationField: string;
  daysField: string;
  isDayFieldNested?: boolean;
}) => {
  const days = ['M', 'T', 'W', 'TH', 'F', 'Sa', 'Su'];

  return (
    <View
      style={styles.cleaningScheduleContainer}
      wrap={data[specificationField]?.length > 16 ? true : false}
    >
      <View style={styles.tableHeader}>
        <View style={styles.tableHeaderCell}>
          <Text style={styles.tableHeaderText}>{data?.area}</Text>
        </View>
        {days.map((day, index) => (
          <View key={index} style={styles.dayCell}>
            <Text style={styles.tableHeaderText}>{day}</Text>
          </View>
        ))}
      </View>

      <View style={styles.monthlyHeader}>
        <Text style={styles.monthlyText}>{data?.frequency}</Text>
      </View>

      {data[specificationField]?.length > 0 ? (
        data[specificationField]?.map((spec, index) => (
          <View key={index} style={styles.tableRow}>
            <View style={styles.tableCell}>
              <Text style={styles.taskText}>{spec.specifications}</Text>
            </View>
            {days.map((day, dayIndex) => (
              <View key={dayIndex} style={styles.dayCell}>
                {isDayIncluded(getUniqueDays(spec, daysField), day) && (
                  <View style={styles.starIconWrapper}>
                    <Image src={star} style={styles.starIcon} />
                  </View>
                )}
              </View>
            ))}
          </View>
        ))
      ) : (
        <View style={styles.tableRow}>
          <View style={styles.tableCell}>
            <Text style={styles.taskText}>No specifications found</Text>
          </View>
        </View>
      )}

      {data.notes && (
        <View style={styles.notesSection}>
          <Text style={styles.notesHeader}>NOTES:</Text>
          <Text style={styles.notesText}>{data?.notes || DEFAULT_VALUE}</Text>
        </View>
      )}
    </View>
  );
};
