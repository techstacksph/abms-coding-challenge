import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image,
} from '@react-pdf/renderer';

import { formatDate2, dateFormat } from '@/utils/date.utils';
import QualityAuditModel from '@/models/QualityAuditModel';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';
import { toSentenceCase } from '@/utils/string.utils';
import { dustPanBase64 } from '@/views/sales/deals/view/tabs/quotes/QoutePages/common/dustpanBase64';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Define styles matching the Quote PDF design
const styles = StyleSheet.create({
  // Cover Page Styles
  coverPageFullHeight: {
    height: '100%',
    width: '100%',
    paddingBottom: 0,
    position: 'relative',
  },
  coverPageBgImageFull: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  coverPageContentWrapper: {
    position: 'relative',
    width: '100%',
    minHeight: '100%',
  },
  coverPageGoldBar: {
    position: 'absolute',
    left: 80,
    top: 0,
    width: 5,
    height: '431px',
    backgroundColor: '#BCA179',
  },
  coverPageContent: {
    marginLeft: 108,
    marginRight: 54,
    paddingTop: 0,
  },
  coverPageTopSpacer: {
    marginTop: 210,
    marginBottom: 0,
  },
  coverPageTextGray: {
    fontSize: 18,
    fontFamily: 'Antonio',
    fontWeight: 700,
    lineHeight: 1.16,
    color: '#979797',
  },
  coverPageTextGold: {
    fontSize: 18,
    fontFamily: 'Antonio',
    fontWeight: 700,
    lineHeight: 1.16,
    color: '#BCA179',
  },
  coverPageSpacer: {
    marginTop: 15,
    marginBottom: 16,
  },
  coverPageProposalText: {
    fontSize: 14,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#1F1F1F',
  },
  coverPageCompanyName: {
    fontSize: 44,
    fontFamily: 'Antonio',
    fontWeight: 600,
    color: '#BCA179',
    letterSpacing: 0.44,
  },
  coverPageDetailsSpacer: {
    marginTop: 30,
  },
  coverPageDetailsText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#1F1F1F',
    marginBottom: 4,
  },
  // Content Page Styles (matching pdfPageUpdated from Quote PDF)
  pdfPageUpdated: {
    backgroundColor: '#FFFFFF',
    fontFamily: 'Manrope',
    paddingLeft: 109,
    paddingRight: 54,
    paddingTop: 80,
    paddingBottom: 65,
  },
  // Header with vertical line (matching Quote PDF)
  headerWithLineContainer: {
    position: 'absolute',
    top: 0,
    left: 81,
    zIndex: 100,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  headerVerticalLine: {
    width: 5,
    height: 170,
    backgroundColor: '#BCA179',
  },
  // Quotation Header styles
  quotationForText: {
    fontSize: 14,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#000',
    marginBottom: 4,
  },
  quotationCompanyName: {
    fontSize: 44,
    fontFamily: 'Antonio',
    fontWeight: 600,
    color: '#BCA179',
    letterSpacing: 0.44,
    marginBottom: 4,
  },
  quotationAddressText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#403b4d',
    lineHeight: 1.04,
    letterSpacing: -0.07,
    marginBottom: 4,
  },
  // Section Title styles (matching Quote PDF)
  sectionTitleContainer: {
    borderBottomWidth: 0.5,
    borderBottomColor: '#1F1F1F',
    paddingBottom: 10,
    marginTop: 15,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Antonio',
    fontWeight: 600,
    color: '#BCA179',
    textTransform: 'uppercase',
    lineHeight: 1.0,
    letterSpacing: 0.0007,
  },
  sectionTitleSuffix: {
    fontSize: 16,
    fontFamily: 'Antonio',
    fontWeight: 600,
    color: '#7A7A7A',
    textTransform: 'uppercase',
    lineHeight: 1.0,
    letterSpacing: 0.0007,
  },
  // Notes section
  notesSection: {
    marginTop: 5,
  },
  notesLabel: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#403b4d',
    lineHeight: 1.04,
    letterSpacing: -0.07,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  notesText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#1F1F1F',
    lineHeight: 1.5,
  },
  // Area Section styles (matching spec table)
  areaSection: {
    marginBottom: 3,
  },
  specTable: {
    marginBottom: 3,
  },
  specTableHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  specTableHeaderLeft: {
    width: '50%',
    paddingLeft: 8,
  },
  specTableHeaderRight: {
    width: '50%',
    paddingLeft: 8,
  },
  areaTitle: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 700,
    color: '#1F1F1F',
    lineHeight: 1.04,
    letterSpacing: 0,
    textAlign: 'justify',
    textTransform: 'uppercase',
  },
  specHeaderCell: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 700,
    color: '#1F1F1F',
    lineHeight: 1.04,
    letterSpacing: 0,
    textAlign: 'justify',
  },
  // Table header row (gray background #979797)
  frequencyRow: {
    flexDirection: 'row',
    backgroundColor: '#979797',
    minHeight: 22,
    paddingVertical: 4,
    marginTop: 4,
  },
  frequencyCell: {
    width: '50%',
    paddingLeft: 8,
    paddingVertical: 2,
  },
  frequencyText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 600,
    color: '#FFFFFF',
  },
  // Table row styles
  specTableRow: {
    flexDirection: 'row',
    minHeight: 13,
  },
  specCell: {
    width: '50%',
    paddingLeft: 8,
    paddingRight: 8,
    paddingVertical: 4,
    fontSize: 9,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#1F1F1F',
    lineHeight: 1.0,
    letterSpacing: -0.12,
    justifyContent: 'center',
  },
  assessmentCell: {
    width: '50%',
    paddingLeft: 8,
    paddingRight: 8,
    paddingVertical: 4,
    fontSize: 9,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#1F1F1F',
    lineHeight: 1.0,
    letterSpacing: -0.12,
    justifyContent: 'center',
  },
  // Notes row
  specNotesText: {
    fontSize: 9,
    fontFamily: 'Manrope',
    fontWeight: 700,
    color: '#1F1F1F',
    lineHeight: 1.4,
    letterSpacing: -0.07,
    marginTop: 8,
    marginBottom: 10,
    paddingLeft: 8,
  },
  // Needs Attention indicator
  needsAttentionText: {
    fontSize: 10,
    fontFamily: 'Manrope',
    fontWeight: 700,
    color: '#1F1F1F',
    lineHeight: 1.04,
    letterSpacing: 0,
    textAlign: 'left',
    textTransform: 'uppercase',
  },
  // Footer Styles
  footer: {
    position: 'absolute',
    bottom: 20,
    left: 109,
    right: 54,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  footerLeft: {
    fontSize: 8,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#7A7A7A',
    lineHeight: 1.4,
  },
  footerRight: {
    fontSize: 8,
    fontFamily: 'Manrope',
    fontWeight: 300,
    color: '#7A7A7A',
  },
});

interface QualityAuditCustomerPDFProps {
  data: QualityAuditModel;
  companySettings?: {
    phone?: string;
    email?: string;
    website?: string;
  };
}

const QualityAuditCustomerPDF: React.FC<QualityAuditCustomerPDFProps> = ({
  data,
  companySettings,
}) => {
  const formatAssessment = (assessment: string) => {
    if (assessment === 'STANDARD_ACHIEVE') return 'Standard Achieved';
    if (assessment === 'NEEDS_ATTENTION') return 'Needs Attention';
    return assessment;
  };

  // Group specifications by area
  const groupedData = () => {
    if (!data.qaAreas || !data.qaSpecifications) return [];

    return data.qaAreas.map(area => ({
      area,
      specifications: data.qaSpecifications.filter(
        spec => spec.qaAreaId === area.id
      ),
    }));
  };

  const companyName = data.job?.account?.name || data.job?.name || '';
  const contactPerson = data.job?.contact?.fullName || '';
  const fullAddress =
    data.job?.site?.fullAddress ||
    data.job?.site?.address ||
    data.job?.site?.streetAddress ||
    '';
  const auditorName =
    `${data.recordOwner?.firstName || ''} ${data.recordOwner?.lastName || ''}`.trim() ||
    data.recordOwner?.fullName ||
    data.recordOwner?.name ||
    '';
  const auditDate = data.auditMonth
    ? formatDate2(data.auditMonth, dateFormat)
    : data.createdAt
      ? formatDate2(data.createdAt, dateFormat)
      : '';
  const franchiseeName =
    data.job?.account?.name || data.job?.name || 'Franchisee';

  return (
    <Document>
      {/* Cover Page */}
      <Page size='A4'>
        <View style={styles.coverPageFullHeight}>
          <Image src={dustPanBase64} style={styles.coverPageBgImageFull} />
          <View style={styles.coverPageContentWrapper}>
            <View style={styles.coverPageGoldBar} />
            <View style={styles.coverPageContent}>
              <View style={styles.coverPageTopSpacer} />
              <Text style={styles.coverPageTextGray}>Premium </Text>
              <Text style={styles.coverPageTextGold}>Tailored </Text>
              <Text style={styles.coverPageTextGray}>Cleaning </Text>
              <Text style={styles.coverPageTextGray}>Solutions</Text>

              <View style={styles.coverPageSpacer} />

              <Text style={styles.coverPageProposalText}>
                At Your Request QUALITY AUDIT for
              </Text>

              <Text style={styles.coverPageCompanyName}>{companyName}</Text>

              <View style={styles.coverPageDetailsSpacer} />

              <Text style={styles.coverPageDetailsText}>
                Quality Audit No. {data.qaNo || ''}
              </Text>
              <Text style={styles.coverPageDetailsText}>
                Audit Date: {auditDate}
              </Text>
              <Text style={styles.coverPageDetailsText}>
                Auditor: {auditorName}
              </Text>
              {data.reviewedBy && (
                <Text style={styles.coverPageDetailsText}>
                  Reviewed by:{' '}
                  {`${data.reviewedBy?.firstName || ''} ${data.reviewedBy?.lastName || ''}`.trim()}
                </Text>
              )}
            </View>
          </View>
        </View>
      </Page>

      {/* Content Pages */}
      <Page size='A4' style={styles.pdfPageUpdated}>
        {/* Fixed Header with vertical gold line */}
        <View style={styles.headerWithLineContainer} fixed>
          <View style={styles.headerVerticalLine} />
        </View>

        {/* Quotation Header */}
        <View>
          <Text style={styles.quotationForText}>
            At Your Request QUALITY AUDIT for
          </Text>
          <Text style={styles.quotationCompanyName}>{companyName}</Text>
          {fullAddress && (
            <View style={{ width: '68%' }}>
              <Text style={styles.quotationAddressText}>{fullAddress}</Text>
            </View>
          )}
          {contactPerson && (
            <Text style={styles.quotationAddressText}>
              Contact: {contactPerson}
            </Text>
          )}
          {/* Summary Notes / Action Plan */}
          {data.customerNotes && (
            <View style={styles.notesSection}>
              <Text style={styles.notesLabel}>
                SUMMARY NOTES / ACTION PLAN:
              </Text>
              <Text style={styles.notesText}>{data.customerNotes}</Text>
            </View>
          )}
        </View>

        {/* Job Areas Section */}
        {groupedData().length > 0 && (
          <>
            <View style={styles.sectionTitleContainer}>
              <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
                <Text style={styles.sectionTitle}>JOB AREAS - </Text>
                <Text style={styles.sectionTitleSuffix}>{franchiseeName}</Text>
              </View>
            </View>

            {groupedData().map((item, areaIndex) => (
              <View
                key={areaIndex}
                style={styles.areaSection}
                wrap={false}
                minPresenceAhead={50}
              >
                <View style={styles.specTable}>
                  {/* Area Title Row */}
                  <View style={styles.specTableHeader}>
                    <View style={styles.specTableHeaderLeft}>
                      <Text style={styles.areaTitle}>
                        {item.area.area || 'Area'}
                      </Text>
                    </View>
                    <View style={styles.specTableHeaderRight}>
                      <Text style={styles.needsAttentionText}>
                        {formatAssessment(item.area.assessment).toUpperCase()}
                      </Text>
                    </View>
                  </View>

                  {/* Gray Header Row for columns */}
                  <View style={styles.frequencyRow}>
                    <View style={styles.frequencyCell}>
                      <Text style={styles.frequencyText}>
                        Job Specification
                      </Text>
                    </View>
                    <View style={styles.frequencyCell}>
                      <Text style={styles.frequencyText}>Assessments</Text>
                    </View>
                  </View>

                  {/* Specification Rows */}
                  {item.specifications.length > 0 ? (
                    item.specifications.map((spec, specIndex) => (
                      <View key={specIndex} style={styles.specTableRow}>
                        <View style={styles.specCell}>
                          <Text>{spec.specification || ''}</Text>
                        </View>
                        <View style={styles.assessmentCell}>
                          <Text>
                            {toSentenceCase(formatAssessment(spec.assessment))}
                          </Text>
                        </View>
                      </View>
                    ))
                  ) : (
                    <View style={styles.specTableRow}>
                      <View style={styles.specCell}>
                        <Text>No specifications</Text>
                      </View>
                      <View style={styles.assessmentCell}>
                        <Text>-</Text>
                      </View>
                    </View>
                  )}
                </View>

                {/* Area spacing */}
                <View style={{ marginBottom: 8 }} />
              </View>
            ))}
          </>
        )}

        {/* Footer */}
        <View style={styles.footer} fixed>
          <Text style={styles.footerLeft}>
            {companySettings?.phone || ''}
            {'\n'}
            {companySettings?.email || ''} | {companySettings?.website || ''}
          </Text>
          <Text
            style={styles.footerRight}
            render={({ pageNumber, totalPages }) =>
              `Page ${pageNumber} of ${totalPages}`
            }
          />
        </View>
      </Page>
    </Document>
  );
};

export default QualityAuditCustomerPDF;
