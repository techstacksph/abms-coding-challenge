import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image,
  Link,
} from '@react-pdf/renderer';

import JobsModel from '@/models/JobsModel';
import PreferredProductsModel from '@/models/PreferredProductsModel';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

import { ayrLogoWrap } from '@/views/sales/deals/view/tabs/quotes/QoutePages/common/logoAYRBase64';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Disable hyphenation to prevent words from breaking with hyphens
Font.registerHyphenationCallback(word => [word]);

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 10,
    paddingTop: 130,
    paddingLeft: 50,
    paddingRight: 50,
    paddingBottom: 150,
    lineHeight: 1.4,
  },
  topSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'absolute',
    top: 25,
    left: 50,
    right: 50,
  },
  leftInfo: {
    flexDirection: 'column',
    paddingTop: 20,
    columnGap: '4px',
    fontFamily: 'Manrope',
  },
  rightInfo: {
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'flex-start',
    fontFamily: 'Manrope',
  },
  logo: {
    height: 80,
    width: 80,
    marginBottom: 5,
    marginTop: -20,
    objectFit: 'contain',
    alignSelf: 'flex-start',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 700, // Antonio Bold
    color: '#BCA179', // Gold color from image
    fontFamily: 'Antonio',
    textAlign: 'center',
    marginTop: -10,
    marginBottom: 30,
    textTransform: 'uppercase',
  },
  section: {
    marginBottom: 10,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontSize: 9,
    fontWeight: 700,
    color: '#000000',
  },
  value: {
    fontSize: 9,
    color: '#000000',
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    zIndex: 1000,
    position: 'absolute',
    left: 50,
    right: 50,
    bottom: 35,
  },
  footerBands: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  footerBandGrey: {
    height: 18,
    backgroundColor: '#EFEFEF',
  },
  footerBandGold: {
    height: 18,
    backgroundColor: '#BCA179',
  },
  footerLeft: {
    flexDirection: 'column',
    fontSize: 8,
    color: '#686D78',
  },
  footerRight: {
    fontSize: 8,
    color: '#000000',
  },
  table: {
    width: '100%',
    marginBottom: 40,
    marginTop: 10,
  },
  tableRow: {
    flexDirection: 'row',
  },
  tableBodyRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#d6d6d6',
    borderTopWidth: 1,
    borderTopColor: '#d6d6d6',
  },
  tableHeaderCell: {
    backgroundColor: '#f2f2f2',
    padding: 2,
    fontSize: 9,
    fontWeight: 700,
    fontFamily: 'Manrope',
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#d6d6d6',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopWidth: 1,
    borderTopColor: '#d6d6d6',
    borderBottomWidth: 1,
    borderBottomColor: '#d6d6d6',
  },
  tableBodyCell: {
    padding: 6,
    fontSize: 9,
    fontFamily: 'Manrope',
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#d6d6d6',
    textAlign: 'left',
    lineHeight: 1.3,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'stretch',
    flexWrap: 'wrap',
  },
  tableBodyCell1: {
    padding: 6,
    fontSize: 9,
    fontFamily: 'Manrope',
    color: '#000000',
    borderRightWidth: 1,
    borderRightColor: '#d6d6d6',
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
});

interface PreferredProductsPDFProps {
  data: JobsModel;
  products: PreferredProductsModel[];
  companySettings?: {
    phone?: string;
    email?: string;
    website?: string;
  };
}

const PreferredProductsPDF: React.FC<PreferredProductsPDFProps> = ({
  data,
  products,
  companySettings,
}) => {
  return (
    <Document title='Preferred Products'>
      <Page style={styles.page}>
        {/* Top Section with Logo */}
        <View style={styles.topSection} fixed>
          <View style={styles.leftInfo}>
            <Image
              src={ayrLogoWrap}
              style={[styles.logo, { alignSelf: 'flex-start' }]}
            />
          </View>
          <View style={styles.rightInfo}>
            <Text
              style={{
                fontSize: 14,
                fontWeight: 600,
                color: '#000000',
                fontFamily: 'Manrope',
              }}
              render={({ pageNumber }) => `${pageNumber}`}
            />
          </View>
        </View>

        {/* Header Title */}
        <Text style={styles.headerTitle}>PREFERRED PRODUCTS</Text>

        {/* Customer and Site Information */}
        <View style={styles.section}>
          <Text style={{ fontSize: 9 }}>
            <Text style={styles.label}>CUSTOMER: </Text>
            <Text style={styles.value}>{data?.account?.name || ''}</Text>
          </Text>
          <Text style={{ fontSize: 9 }}>
            <Text style={styles.label}>PHYSICAL ADDRESS: </Text>
            <Text style={styles.value}>
              {data?.site?.fullAddress ||
                data?.site?.address ||
                data?.site?.streetAddress ||
                ''}
            </Text>
          </Text>
        </View>

        {/* Products Table */}
        <View style={styles.table}>
          <View style={[styles.tableRow]}>
            <View
              style={[
                styles.tableHeaderCell,
                { width: '7%', borderLeftWidth: 1, borderLeftColor: '#d6d6d6' },
              ]}
            >
              <Text>No.</Text>
            </View>
            <View style={[styles.tableHeaderCell, { width: '24%' }]}>
              <Text>Item Name</Text>
            </View>
            <View style={[styles.tableHeaderCell, { width: '19%' }]}>
              <Text>Item Code</Text>
            </View>
            <View style={[styles.tableHeaderCell, { width: '18%' }]}>
              <Text>Item Category</Text>
            </View>
            <View style={[styles.tableHeaderCell, { width: '20%' }]}>
              <Text>Item Subcategory</Text>
            </View>
            <View
              style={[
                styles.tableHeaderCell,
                {
                  width: '12%',
                  borderRightWidth: 1,
                  borderRightColor: '#d6d6d6',
                },
              ]}
            >
              <Text>Status</Text>
            </View>
          </View>

          {products?.map((product, index) => (
            <View key={index} style={styles.tableBodyRow} wrap={false}>
              <View
                style={[
                  styles.tableBodyCell1,
                  {
                    width: '7%',
                    borderLeftWidth: 1,
                    borderLeftColor: '#d6d6d6',
                  },
                ]}
              >
                <Text>{index + 1}</Text>
              </View>
              <View style={[styles.tableBodyCell, { width: '24%' }]}>
                <Text>{product?.item?.name || ''}</Text>
              </View>
              <View style={[styles.tableBodyCell, { width: '19%' }]}>
                <Text>
                  {product?.item?.itemCode || product?.itemCode || ''}
                </Text>
              </View>
              <View style={[styles.tableBodyCell, { width: '18%' }]}>
                <Text>{product?.itemCategory?.name || ''}</Text>
              </View>
              <View style={[styles.tableBodyCell, { width: '20%' }]}>
                <Text>{product?.itemSubcategory?.name || ''}</Text>
              </View>
              <View
                style={[
                  styles.tableBodyCell,
                  {
                    width: '12%',
                    borderRightWidth: 1,
                    borderRightColor: '#d6d6d6',
                  },
                ]}
              >
                <Text>{product?.status?.name || ''}</Text>
              </View>
            </View>
          ))}

          {(!products || products.length === 0) && (
            <View style={styles.tableBodyRow} wrap={false}>
              <View
                style={[
                  styles.tableBodyCell,
                  {
                    width: '100%',
                    borderRightWidth: 1,
                    borderRightColor: '#d6d6d6',
                    borderLeftWidth: 1,
                    borderLeftColor: '#d6d6d6',
                  },
                ]}
              >
                <Text>No preferred products found.</Text>
              </View>
            </View>
          )}
        </View>

        {/* Footer - Fixed on every page */}
        <View style={styles.footer} fixed>
          <Text style={styles.footerLeft}>
            {companySettings?.phone || ''}
            {'\n'}
            {companySettings?.email && (
              <Link
                src={`mailto:${companySettings.email}`}
                style={{ ...styles.footerLeft, textDecoration: 'none' }}
              >
                {companySettings.email}
              </Link>
            )}
            {companySettings?.email && ' | '}
            {companySettings?.website || ''}{' '}
          </Text>
        </View>
        <View style={styles.footerBands} fixed>
          <View style={styles.footerBandGrey} />
          <View style={styles.footerBandGold} />
        </View>
      </Page>
    </Document>
  );
};

export default PreferredProductsPDF;
