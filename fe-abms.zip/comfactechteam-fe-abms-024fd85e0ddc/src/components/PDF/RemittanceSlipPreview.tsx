import React from 'react';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import { formatCurrency } from '@/utils/helper.utils';
import InvoiceModel from '@/models/InvoiceModel';
import { useCompanySettings } from '@/context/CompanySettingsProvider';

interface RemittanceSlipPreviewProps {
  data: InvoiceModel;
}

const RemittanceSlipPreview: React.FC<RemittanceSlipPreviewProps> = ({
  data,
}) => {
  const companySettings = useCompanySettings();

  // Calculate due date (typically 30 days from invoice date)
  const calculateDueDate = (invoiceDate: Date | string | undefined): string => {
    if (!invoiceDate) return '';
    const date = new Date(invoiceDate);
    date.setDate(date.getDate() + 30); // Add 30 days
    return formatDate2(date, dateFormat);
  };

  const styles = {
    remittanceContainer: {
      marginTop: '40px',
      padding: '15px',
      backgroundColor: '#f8f8f8',
      borderRadius: '5px',
    },
    remittanceHeader: {
      fontSize: '14px',
      fontWeight: 'bold' as const,
      color: '#000',
      marginBottom: '15px',
      textAlign: 'center' as const,
    },
    remittanceContent: {
      display: 'flex',
      justifyContent: 'space-between',
    },
    leftSection: {
      flex: 1,
      marginRight: '20px',
    },
    rightSection: {
      flex: 1,
    },
    companyBox: {
      padding: '10px',
      backgroundColor: '#fff',
      borderRadius: '3px',
      marginBottom: '15px',
    },
    companyName: {
      fontSize: '12px',
      fontWeight: 'bold' as const,
      color: '#000',
      fontStyle: 'italic' as const,
    },
    companyDetails: {
      fontSize: '10px',
      color: '#000',
      marginTop: '2px',
    },
    invoiceDetails: {
      marginBottom: '15px',
    },
    detailRow: {
      display: 'flex',
      marginBottom: '3px',
    },
    detailLabel: {
      fontSize: '10px',
      color: '#000',
      width: '80px',
    },
    detailValue: {
      fontSize: '10px',
      color: '#000',
      flex: 1,
    },
    paymentSection: {
      marginBottom: '15px',
    },
    paymentTitle: {
      fontSize: '12px',
      fontWeight: 'bold' as const,
      color: '#000',
      marginBottom: '8px',
    },
    paymentMethod: {
      fontSize: '10px',
      color: '#000',
      marginBottom: '5px',
      lineHeight: '1.3',
    },
    balanceSection: {
      borderTop: '1px solid #ddd',
      paddingTop: '10px',
    },
    balanceRow: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: '3px',
    },
    balanceLabel: {
      fontSize: '10px',
      color: '#000',
    },
    balanceValue: {
      fontSize: '10px',
      fontWeight: 'bold' as const,
      color: '#000',
    },
    fillInSection: {
      marginTop: '10px',
    },
    fillInRow: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '5px',
    },
    fillInLabel: {
      fontSize: '10px',
      color: '#000',
      marginRight: '10px',
    },
    fillInLine: {
      flex: 1,
      borderBottom: '1px solid #000',
      height: '15px',
    },
    boldText: {
      fontWeight: 'bold' as const,
    },
    largeBoldText: {
      fontSize: '12px',
      fontWeight: 'bold' as const,
    },
    balanceDueTitle: {
      fontSize: '12px',
      fontWeight: 'bold' as const,
      color: '#000',
      marginBottom: '10px',
    },
  };

  return (
    <div style={styles.remittanceContainer}>
      <div style={styles.remittanceHeader}>REMITTANCE SLIP</div>

      <div style={styles.remittanceContent}>
        {/* Left Section */}
        <div style={styles.leftSection}>
          {/* Company Information Box */}
          <div style={styles.companyBox}>
            {(data.billingAccount?.legalName ||
              data.account?.legalName ||
              data.billingAccount?.location?.name ||
              data.account?.location?.name) && (
              <div style={styles.companyName}>
                {data.billingAccount?.legalName ||
                  data.account?.legalName ||
                  data.billingAccount?.location?.name ||
                  data.account?.location?.name}
              </div>
            )}

            {companySettings?.tradingName && (
              <div style={styles.companyDetails}>
                {companySettings.tradingName}
              </div>
            )}

            {(data.billingAccount?.billingAddress ||
              data.account?.billingAddress) && (
              <div style={styles.companyDetails}>
                {data.billingAccount?.billingAddress ||
                  data.account?.billingAddress}
              </div>
            )}
          </div>

          {/* Invoice Details */}
          <div style={styles.invoiceDetails}>
            <div style={styles.detailRow}>
              <span style={styles.detailLabel}>Invoice date:</span>
              <span style={styles.detailValue}>
                {data.invoiceDate
                  ? formatDate2(data.invoiceDate, dateFormat)
                  : ''}
              </span>
            </div>

            <div style={styles.detailRow}>
              <span style={styles.detailLabel}>Due Date:</span>
              <span style={styles.detailValue}>
                {calculateDueDate(data.invoiceDate)}
              </span>
            </div>

            <div style={styles.detailRow}>
              <span style={styles.detailLabel}>Invoice number:</span>
              <span style={styles.detailValue}>
                {data.autoNumber || data.invoiceNo || ''}
              </span>
            </div>

            <div style={styles.detailRow}>
              <span style={styles.detailLabel}>Customer name:</span>
              <span style={styles.detailValue}>{data.account?.name || ''}</span>
            </div>
          </div>

          {/* Balance Information */}
          <div style={styles.balanceSection}>
            <div style={styles.balanceRow}>
              <span style={styles.balanceLabel}>Balance Due:</span>
              <span style={styles.balanceValue}>
                {formatCurrency(data.totalAmount || 0)}
              </span>
            </div>

            {/* Fill-in fields */}
            <div style={styles.fillInSection}>
              <div style={styles.fillInRow}>
                <span style={styles.fillInLabel}>Date Paid:</span>
                <div style={styles.fillInLine} />
              </div>

              <div style={styles.fillInRow}>
                <span style={styles.fillInLabel}>Amount Enclose:</span>
                <div style={styles.fillInLine} />
              </div>
            </div>
          </div>
        </div>

        {/* Right Section */}
        <div style={styles.rightSection}>
          {/* Payment Methods */}
          <div style={styles.paymentSection}>
            <div style={styles.paymentTitle}>Payment methods:</div>

            <div style={styles.paymentMethod}>
              Internet direct credit: please use invoice number as reference and
              pay into 12-3110-0069942-000
            </div>

            <div style={styles.paymentMethod}>
              Cheque: please make the cheque out to At Your Request and post
              with remittance slip
            </div>

            <div style={styles.balanceSection}>
              <div style={styles.balanceDueTitle}>
                Balance Due:{' '}
                {formatCurrency(
                  (data.totalAmount || 0) - (data.paidAmount || 0)
                )}
              </div>
            </div>

            <div style={styles.fillInSection}>
              <div style={styles.fillInRow}>
                <span style={styles.fillInLabel}>
                  Date Paid: ____________________
                </span>
              </div>

              <div style={styles.fillInRow}>
                <span style={styles.fillInLabel}>
                  Amount Enclose: ____________________
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RemittanceSlipPreview;
