import React from 'react';

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
  Font,
} from '@react-pdf/renderer';

import { formatCurrency } from '@/utils/helper.utils';
import { formatDate2, dateFormat } from '@/utils/date.utils';
import BillModel from '@/models/BillModel';
import BillDetailsModel from '@/models/BillDetailsModel';
import { ayrLogo } from '@/constants/PDF/base64Images';

import RemittanceSlip from './RemittanceSlip';

import {
  antonioFontBold,
  antonioFontRegular,
  manropeFont,
  manropeFontBold,
  manropeBoldItalic,
  lightManrope,
  extraLightManrope,
  semiBoldManrope,
  manropeRegularItalic,
} from '@/constants/PDF/base64Fonts';

Font?.register({
  family: 'Manrope',
  fonts: [
    { src: semiBoldManrope, fontWeight: 600 },
    { src: extraLightManrope, fontWeight: 200 },
    { src: lightManrope, fontWeight: 300 },
    { src: manropeFont, fontWeight: 400 },
    { src: manropeFontBold, fontWeight: 700 },
    { src: manropeBoldItalic, fontWeight: 600, fontStyle: 'italic' },
    { src: manropeRegularItalic, fontWeight: 300, fontStyle: 'italic' },
  ],
});
Font?.register({
  family: 'Antonio',
  fonts: [
    { src: antonioFontRegular, fontWeight: 400 },
    { src: antonioFontBold, fontWeight: 700 },
  ],
});

// Define styles
const styles = StyleSheet.create({
  page: {
    fontFamily: 'Manrope',
    fontSize: 9,
    paddingTop: 30,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 30,
    lineHeight: 1.3,
  },
  topHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  leftTopHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 'auto',
    marginRight: 15,
    paddingTop: '16px',
    marginLeft: '3px',
  },
  companyInfo: {
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
  leftSection: {
    width: '50%',
  },
  rightSection: {
    width: '50%',
    alignItems: 'flex-end',
  },
  companyName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  tradingName: {
    fontSize: 8,
    fontWeight: 400,
    color: '#090A0B',
  },
  companyAddress: {
    fontSize: 8,
    color: '#090A0B',
    lineHeight: 1.3,
    textAlign: 'right',
    fontFamily: 'Manrope',
  },
  companyPhone: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  companyEmail: {
    fontSize: 8,
    color: '#000',
    marginBottom: 6,
    fontFamily: 'Manrope',
  },
  invoiceTitle: {
    fontFamily: 'Antonio',
    fontSize: 28,
    color: '#D4A574',
  },
  invoiceDetailsSection: {
    marginBottom: 16,
    width: 'auto',
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 700,
    color: '#000',
    marginBottom: 15,
  },
  invoiceToTitle: {
    fontSize: 8,
    fontWeight: 400,
    color: '#000',
    fontFamily: 'Manrope',
  },
  accountName: {
    fontSize: 8,
    fontWeight: 700,
    color: '#000',
    fontFamily: 'Manrope',
  },
  billingAddress: {
    fontSize: 8,
    fontFamily: 'Manrope',
    color: '#000',
    lineHeight: 1.3,
  },
  contactName: {
    fontSize: 8,
    color: '#000',
    fontFamily: 'Manrope',
  },
  invoiceToSection: {
    marginBottom: 0,
  },
  detailRow: {
    flexDirection: 'row',
  },
  detailLabel: {
    width: 80,
    fontSize: 9,
    color: '#000',
  },
  detailLabels: {
    fontSize: 9,
    color: '#000',
  },
  detailValue: {
    fontSize: 9,
    color: '#000',
    flex: 1,
  },
  table: {
    marginBottom: 15,
    borderTopWidth: 3,
    borderTop: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 8,
    paddingHorizontal: 5,
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderBottomColor: '#eee',
    paddingVertical: 6,
    paddingHorizontal: 5,
  },
  tableHeaderCell: {
    fontSize: 9,
    fontWeight: 700,
    color: '#333',
  },
  tableCell: {
    fontSize: 9,
    color: '#333',
  },
  descriptionColumn: {
    flex: 3,
  },
  quantityColumn: {
    flex: 1,
    textAlign: 'center',
  },
  priceColumn: {
    flex: 1,
    textAlign: 'right',
  },
  amountColumn: {
    flex: 1,
    textAlign: 'right',
  },
  summary: {
    marginTop: 0,
    alignItems: 'flex-end',
  },
  summaryBox: {
    width: 200,
    padding: 0,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: 10,
  },
  summaryLabel: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    fontWeight: 700,
  },
  summaryValue: {
    fontSize: 9,
    color: '#090A0B',
    fontWeight: 700,
    fontFamily: 'Manrope',
  },
  balanceDueRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#D4A574',
    padding: 8,
    borderRadius: 3,
  },
  balanceDueLabel: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  balanceDueValue: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
    fontFamily: 'Manrope',
  },
  summarySection: {
    marginTop: 0,
  },
  commentsHeader: {
    marginBottom: 0,
    marginTop: 0,
  },
  commentsText: {
    fontSize: 9,
    fontWeight: 700,
    color: '#090A0B',
  },
  commentsContent: {
    marginTop: 5,
    maxWidth: 300,
  },
  notesText: {
    fontSize: 9,
    color: '#090A0B',
    fontFamily: 'Manrope',
    lineHeight: 1.3,
  },
  summaryTopBorder: {
    borderTopWidth: 3,
    borderTopColor: '#B5B5B5',
    borderTopStyle: 'solid',
    marginBottom: 15,
    width: '100%',
  },
  commentsAndSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
  },
});

interface BillPDFProps {
  data: BillModel;
  billDetails: BillDetailsModel[];
  companySettings?: any;
}

const BillPDF: React.FC<BillPDFProps> = ({
  data,
  billDetails,
  companySettings,
}) => {
  // Extract trading name from companySettings
  // ModuleStatus now fetches and transforms data[0], so it should be an object
  // Service layer also normalizes as fallback, so handle both for safety
  let tradingName: string | undefined = undefined;

  if (companySettings) {
    // Handle array format (if normalization didn't happen)
    if (Array.isArray(companySettings) && companySettings.length > 0) {
      tradingName = companySettings[0]?.tradingName;
    }
    // Handle object format (after transformData or service layer normalization)
    else if (companySettings.tradingName) {
      tradingName = companySettings.tradingName;
    }
  }

  // Clean and validate
  if (tradingName && typeof tradingName === 'string') {
    tradingName = tradingName.trim();
    if (tradingName === '') {
      tradingName = undefined;
    }
  } else {
    tradingName = undefined;
  }

  // Helper function to clean address strings that contain "undefined"
  // const cleanAddressString = (address: string | undefined): string => {
  //   if (!address) return '';

  //   // Split by comma, filter out "undefined" and empty parts, then rejoin
  //   return address
  //     .split(',')
  //     .map(part => part.trim())
  //     .filter(
  //       part =>
  //         part &&
  //         part.toLowerCase() !== 'undefined' &&
  //         part.toLowerCase() !== 'null'
  //     )
  //     .join(', ');
  // };

  // Calculate paid amount from totalAmount and outstandingBalance
  const paidAmount = (data.totalAmount || 0) - (data.outstandingBalance || 0);

  // Adapter to convert Bill data to Invoice-like format for RemittanceSlip
  // Note: Do NOT set invoiceNo or autoNumber for bills - only billNo
  // This ensures RemittanceSlip correctly identifies it as a bill
  const remittanceData = {
    ...data,
    invoiceDate: data.invoice?.invoiceDate || data.billDate,
    dueDate: data.dueDate,
    billNo: data.billNo,
    paidAmount: paidAmount,
    // Explicitly set invoiceNo and autoNumber to undefined to ensure isBill check works
    invoiceNo: undefined,
    autoNumber: undefined,
  };

  return (
    <Document>
      <Page size='A4' style={styles.page}>
        {/* Top Header: Logo on left, TAX INVOICE on right */}
        <View style={styles.topHeader}>
          <View style={styles.leftTopHeader}>
            <Image src={ayrLogo} style={styles.logo} />
          </View>
          <Text style={styles.invoiceTitle}>TAX INVOICE</Text>
        </View>

        {/* Company Information - Two column layout */}
        <View style={styles.companyInfo}>
          <View style={styles.leftSection}>
            {/* Bill Details - Left side only, vertical layout */}
            <View style={styles.invoiceDetailsSection}>
              <Text style={styles.detailLabels}>BUYER-CREATED INVOICE</Text>
              <Text style={styles.detailLabels}>Inland Revenue approved</Text>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabels}>GST Invoice No:</Text>
                <Text style={styles.detailValue}>{data.billNo || ''}</Text>
              </View>

              <View style={styles.detailRow}>
                <Text style={styles.detailLabels}>Date:</Text>
                <Text style={styles.detailValue}>
                  {data.invoice?.invoiceDate
                    ? formatDate2(data.invoice.invoiceDate, dateFormat)
                    : data.billDate
                      ? formatDate2(data.billDate, dateFormat)
                      : ''}
                </Text>
              </View>
            </View>

            {/* INVOICE TO Section - Below the bill details */}
            <View style={styles.invoiceToSection}>
              <Text style={styles.invoiceToTitle}>INVOICE TO:</Text>

              {data.location?.billingAccount?.name && (
                <Text style={styles.accountName}>
                  {data.location.billingAccount.name}
                </Text>
              )}

              {(data.location?.billingAccount?.bStreetAddress ||
                data.location?.billingAccount?.bSuburb) && (
                <Text style={styles.billingAddress}>
                  {[
                    data.location?.billingAccount?.bStreetAddress,
                    data.location?.billingAccount?.bSuburb,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </Text>
              )}

              {(data.location?.billingAccount?.bCity ||
                data.location?.billingAccount?.bRegion ||
                data.location?.billingAccount?.bPostalCode) && (
                <Text style={styles.billingAddress}>
                  {[
                    data.location?.billingAccount?.bCity,
                    data.location?.billingAccount?.bRegion,
                    data.location?.billingAccount?.bPostalCode,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </Text>
              )}

              {data.billContacts &&
                data.billContacts.length > 0 &&
                data.billContacts[0].contact && (
                  <Text style={styles.contactName}>
                    ATTN: {data.billContacts[0].contact.fullName || ''}
                  </Text>
                )}
            </View>
          </View>

          <View style={styles.rightSection}>
            {data.account?.name && (
              <Text style={styles.companyName}>{data.account.name}</Text>
            )}

            {(data.account?.bStreetAddress ||
              data.account?.bSuburb ||
              data.account?.bPostalCode) && (
              <Text style={styles.companyAddress}>
                {[
                  data.account?.bStreetAddress,
                  data.account?.bSuburb,
                  data.account?.bPostalCode,
                ]
                  .filter(Boolean)
                  .join(', ')}
              </Text>
            )}

            <Text style={styles.companyPhone}>
              DDI:{' '}
              {data.account?.primaryContact?.phone}
            </Text>

            {data.billContacts &&
              data.billContacts.length > 0 &&
              data.billContacts[0].contact?.email && (
                <Text style={styles.companyEmail}>
                  Email: {data.billContacts[0].contact.email}
                </Text>
              )}
          </View>
        </View>

        {/* Bill Items Table */}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderCell, styles.descriptionColumn]}>
              Description
            </Text>
            <Text style={[styles.tableHeaderCell, styles.quantityColumn]}>
              QTY
            </Text>
            <Text style={[styles.tableHeaderCell, styles.priceColumn]}>
              Unit Price
            </Text>
            <Text style={[styles.tableHeaderCell, styles.amountColumn]}>
              Amount
            </Text>
          </View>

          {billDetails.map((detail, index) => (
            <View key={detail.id || index} style={styles.tableRow}>
              <Text style={[styles.tableCell, styles.descriptionColumn]}>
                {detail.description || ''}
              </Text>
              <Text style={[styles.tableCell, styles.quantityColumn]}>
                {detail.qty || 0}
              </Text>
              <Text style={[styles.tableCell, styles.priceColumn]}>
                {formatCurrency(detail.unitPrice || 0)}
              </Text>
              <Text style={[styles.tableCell, styles.amountColumn]}>
                {formatCurrency(detail.lineAmount || 0)}
              </Text>
            </View>
          ))}
        </View>

        {/* Comments and Bill Summary Section */}
        <View style={styles.summarySection}>
          {/* Top Border */}
          <View style={styles.summaryTopBorder} />

          {/* Comments and Summary Row */}
          <View style={styles.commentsAndSummaryRow}>
            {/* Comments Header */}
            <View style={styles.commentsHeader}>
              <Text style={styles.commentsText}>COMMENTS:</Text>
              {data.notes && data.notes.trim() && (
                <View style={styles.commentsContent}>
                  <Text style={styles.notesText}>{data.notes}</Text>
                </View>
              )}
            </View>

            {/* Bill Summary */}
            <View style={styles.summary}>
              <View style={styles.summaryBox}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Subtotal</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.subtotal || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Tax</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.gstAmount || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Total Amount</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(data.totalAmount || 0)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Paid to date</Text>
                  <Text style={styles.summaryValue}>
                    {formatCurrency(
                      (data.totalAmount || 0) - (data.outstandingBalance || 0)
                    )}
                  </Text>
                </View>
                <View style={styles.balanceDueRow}>
                  <Text style={styles.balanceDueLabel}>Balance Due</Text>
                  <Text style={styles.balanceDueValue}>
                    {formatCurrency(data.outstandingBalance || 0)}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Remittance Slip */}
        <View break={false}>
          <RemittanceSlip
            data={remittanceData as any}
            companySettings={companySettings}
            tradingName={tradingName}
          />
        </View>
      </Page>
    </Document>
  );
};

export default BillPDF;
