import React from 'react';

import { MaterialIcon, Text, Contact, Icon } from '@/styled-components';

import Link from '@/components/Link';
import { getViewRoute } from '@/mfe-utilities';
import ContactModel from '@/models/ContactModel';
import { Stack } from '@mui/material';
import { haveData } from '@/utils/helper.utils';

const ViewPrimaryContactCard = ({
  data,
  boxWidth = '100%',
  showContactIcon = false,
  disableLink = false,
  overflow = false,
}: {
  data: ContactModel;
  boxWidth?: string;
  showContactIcon?: boolean;
  disableLink?: boolean;
  overflow?: boolean;
}) => {
  return (
    <Stack direction={'row'} spacing={1} width={boxWidth}>
      {showContactIcon && (
        <Icon size='28px' color='var(--gray-400)'>
          <Contact />
        </Icon>
      )}
      <Stack direction='column' gap={0.5}>
        {!disableLink ? (
          <Link
            to={`${getViewRoute('Contacts')}/${data?.id}`}
            weight='medium'
            $css={'width: 100%'}
          >
            {data?.fullName}
          </Link>
        ) : (
          <Text $css='font-size: 14px; font-weight: 700; line-height: 20px; color: #090A0B;'>
            {data?.fullName}
          </Text>
        )}
        <Text color='#686D78'>{haveData(data?.jobTitle)}</Text>
        <Stack direction='row' gap={0.5}>
          <MaterialIcon
            iconClass='material-icons'
            name='phone'
            $css='color: #878B97; font-size: 15px;  margin-right: 4px; margin-top: 3px;'
          />
          <Text color='#090A0B'>{haveData(data?.phone)}</Text>
        </Stack>
        <Stack direction='row' gap={0.5}>
          <MaterialIcon
            iconClass='material-icons'
            name='smartphone'
            $css='color: #878B97; font-size: 15px;  margin-right: 4px; margin-top: 3px;'
          />
          <Text color='#090A0B'>{haveData(data?.mobile)}</Text>
        </Stack>
        <Stack direction='row' gap={0.5}>
          <MaterialIcon
            iconClass='material-icons'
            name='mail'
            $css='color: #878B97; font-size: 15px;  margin-right: 4px; margin-top: 3px;'
          />
          <Text
            color='#090A0B'
            $css={
              overflow
                ? 'white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'
                : ''
            }
          >
            {haveData(data?.email)}
          </Text>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default ViewPrimaryContactCard;
