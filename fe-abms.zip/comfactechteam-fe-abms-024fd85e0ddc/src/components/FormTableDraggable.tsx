import React, { useState, useMemo } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

import { GoogleIcon } from '@/styled-components';
import styled from 'styled-components';

import { Box } from '@mui/material';

import { Row, Col, Button } from 'antd';

const StyledBox = styled(Box)<{ $rowBodyCss?: string }>`
  ${({ $rowBodyCss }) => $rowBodyCss}
`;

const StyledRow = styled(Row)<{ $headerCss?: string }>`
  height: 56px;
  width: max-content;

  border-radius: 5px;
  background-color: #e9eaec;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;

  gap: 8px;

  flex-flow: nowrap;

  color: #494f59;

  ${({ $headerCss }) => $headerCss}
`;

const StyledCol = styled(Col)<{ $columnCss?: string }>`
  display: flex;
  align-items: center;

  ${({ $columnCss }) => $columnCss}
`;

const FormHeader = ({ columnDefs, $headerCss = '' }) => {
  return (
    <StyledRow $headerCss={$headerCss}>
      {columnDefs.map((col, index) => (
        <StyledCol key={index} $columnCss={col.$columnCss}>
          {col.title}
        </StyledCol>
      ))}
    </StyledRow>
  );
};

export const FormRow = ({ index, columnDefs }) => {
  const $rowBodyCss = `
        display: flex;
        flex-direction: row;
        align-items: center;
        flex-wrap: nowrap;
        gap: 8px;
        height: 56px;`;

  return (
    <StyledBox $rowBodyCss={$rowBodyCss}>
      {columnDefs.map((col, indexIn) => (
        <StyledBox key={indexIn} $rowBodyCss={col.$css || ''}>
          {typeof col.render === 'function' ? col.render(index || 0) : null}
        </StyledBox>
      ))}
    </StyledBox>
  );
};

const FormTableDraggable = ({
  fields = [],
  columnDefs = [],
  $headerCss = '',
  // $columnCss = '',
  // $rowBodyCss = '',
  // $innerBoxCss = '',
  // expandable = false,
  form = {} as any,
  formField = 'rows',
  showExpand = true,
  showCheckbox = true,
  showDelete = true,
  // onExpand = null,
  // onSelect = null,
  // onDelete = null,
  ExpandableComponent,
  isDraggable = true,
}) => {
  const [isCheckedAll, toggleCheckedAll] = useState<boolean>(false);

  const handleOnDragEnd = result => {
    const { source, destination } = result;
    if (!destination) return;

    const { [formField]: rows } = form.getFieldsValue();

    const reorderedItems = Array.from(rows);
    const [reorderedItem] = reorderedItems.splice(source.index, 1);
    reorderedItems.splice(destination.index, 0, reorderedItem);

    const dragDirection = source.index - destination.index;

    const updatedExpandedIds = expandedIds.map(item => {
      const index = parseInt(item.replace('ExpandedId', ''), 10);

      if (source.index == index) {
        return `ExpandedId${destination.index}`;
      }

      if (dragDirection > 0) {
        if (index < source.index && index >= destination.index) {
          return `ExpandedId${index + 1}`;
        }
      } else if (dragDirection < 0) {
        if (index > source.index && index <= destination.index) {
          return `ExpandedId${index - 1}`;
        }
      }

      return `ExpandedId${index}`;
    });

    const updatedCheckedId = checkedIds.map(item => {
      const index = parseInt(item.replace('CheckedId', ''), 10);

      if (source.index == index) {
        return `CheckedId${destination.index}`;
      }

      if (dragDirection > 0) {
        if (index < source.index && index >= destination.index) {
          return `CheckedId${index + 1}`;
        }
      } else if (dragDirection < 0) {
        if (index > source.index && index <= destination.index) {
          return `CheckedId${index - 1}`;
        }
      }

      return `CheckedId${index}`;
    });

    setCheckedId(updatedCheckedId);
    setExpandedId(updatedExpandedIds);

    form.setFieldsValue({
      [formField]: reorderedItems,
    });
  };

  const [expandedIds, setExpandedId] = useState<string[]>([]);
  const [checkedIds, setCheckedId] = useState<string[]>([]);

  const handleExpand = index => {
    const isExists = expandedIds.includes(`ExpandedId${index}`);

    let prev = [...expandedIds];
    if (isExists) {
      prev = prev.filter(item => item !== `ExpandedId${index}`);
    } else {
      prev = [...prev, `ExpandedId${index}`];
    }

    setExpandedId(prev);
  };

  const handleSelect = index => {
    const isExists = checkedIds.includes(`CheckedId${index}`);

    let prev = [...checkedIds];
    if (isExists) {
      prev = prev.filter(item => item !== `CheckedId${index}`);
    } else {
      prev = [...prev, `CheckedId${index}`];
    }

    setCheckedId(prev);
  };

  const handleSelectAll = () => {
    toggleCheckedAll(prev => !prev);
  };

  const handleDelete = index => {
    const { [formField]: data } = form.getFieldsValue();
    const newData = data.filter((_, ind) => ind != index);

    form.setFieldsValue({
      [formField]: newData,
    });
  };

  columnDefs = useMemo(() => {
    const prevCols = [...columnDefs];
    const extraCols = [];

    if (isDraggable) {
      extraCols.push({
        title: '',
        render: () => {
          return (
            <Box
              width={'40px'}
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#878B97',
              }}
            >
              <GoogleIcon
                name='drag_indicator'
                fill={true}
                $css={`
                  font-size: 24px;
                  cursor: grab;
                  opacity: 0.4;
                `}
              />
            </Box>
          );
        },
        $columnCss: 'width: 40px',
        $css: 'width: 40px',
      });
    }

    if (showCheckbox || showExpand) {
      extraCols.push({
        title: (
          <>
            {showCheckbox && (
              <>
                <Button
                  type='text'
                  icon={
                    isCheckedAll ? (
                      <GoogleIcon
                        name={'check_box'}
                        fill={true}
                        $css={`
                          font-size: 24px;
                          color: #3137fd;
                          background-color: #3137fd;
                          fill: #3137fd;
                        `}
                      />
                    ) : (
                      <GoogleIcon
                        name={'check_box_outline_blank'}
                        $css={'font-size: 24px; color: #494F59;'}
                      />
                    )
                  }
                  onClick={handleSelectAll}
                  style={{
                    padding: 0,
                    border: 'none',
                    background: 'transparent',
                    color: isCheckedAll ? '#3137fd' : '#494F59',
                  }}
                />
                <Button
                  type='text'
                  icon={
                    <GoogleIcon
                      name={'arrow_drop_down'}
                      $css={'font-size: 24px; color: #494F59;'}
                    />
                  }
                  style={{
                    padding: 0,
                    border: 'none',
                    background: 'transparent',
                    color: '#494F59',
                  }}
                />
              </>
            )}
          </>
        ),
        render: index => {
          const checked = checkedIds.includes(`CheckedId${index}`);
          const expanded = expandedIds.includes(`ExpandedId${index}`);

          return (
            <>
              {showCheckbox && (
                <Button
                  type='text'
                  icon={
                    checked ? (
                      <GoogleIcon
                        name={'check_box'}
                        fill={true}
                        $css={'font-size: 24px; color: #3137fd;'}
                      />
                    ) : (
                      <GoogleIcon
                        name={'check_box_outline_blank'}
                        $css={'font-size: 24px;'}
                      />
                    )
                  }
                  onClick={() => handleSelect(index)}
                  style={{
                    padding: 0,
                    border: 'none',
                    background: 'transparent',
                    color: checked ? '#3137fd' : '#494F59',
                  }}
                />
              )}

              {showExpand && (
                <Button
                  type='text'
                  icon={
                    expanded ? (
                      <GoogleIcon
                        name={'expand_more'}
                        $css={'font-size: 24px;'}
                      />
                    ) : (
                      <GoogleIcon
                        name={'chevron_right'}
                        $css={'font-size: 24px;'}
                      />
                    )
                  }
                  style={{
                    padding: 0,
                    margin: 0,
                    border: 'none',
                    background: 'transparent',
                    color: '#494F59',
                  }}
                  onClick={() => handleExpand(index)}
                />
              )}
            </>
          );
        },
        $columnCss: 'width: 72px',
        $css: 'width: 72px; display:flex; flex-direction: row;',
      });
    }

    const currentCols = [...extraCols, ...prevCols];

    if (showDelete) {
      currentCols.push({
        title: '',
        render: index => {
          return (
            <Button
              type='text'
              icon={
                <GoogleIcon
                  name={'delete'}
                  $css={'font-size: 24px; color: #878B97;'}
                />
              }
              style={{
                padding: 0,
                border: 'none',
                background: 'transparent',
                color: '#878B97',
              }}
              onClick={() => {
                handleDelete(index);
              }}
            />
          );
        },
        $columnCss: 'width: 50px',
      });
    }

    return [...currentCols];
  }, [
    isDraggable,
    showCheckbox,
    showExpand,
    showDelete,
    isCheckedAll,
    expandedIds,
    checkedIds,
  ]);

  return (
    <Box
      style={{
        width: '100%',
        overflowX: 'scroll',
      }}
    >
      <FormHeader columnDefs={columnDefs} $headerCss={$headerCss} />

      <DragDropContext onDragEnd={handleOnDragEnd}>
        <Droppable droppableId='orderDetails'>
          {provided => (
            <ul
              {...provided.droppableProps}
              ref={provided.innerRef}
              style={{
                listStyle: 'none',
                padding: 0,
                margin: 0,
                marginTop: '8px',
              }}
            >
              {fields.map(({ name, key }) => (
                <Draggable
                  key={key}
                  draggableId={`${key}orderDetail`}
                  index={key}
                  isDragDisabled={!isDraggable}
                >
                  {provided => (
                    <li
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      style={{
                        ...provided.draggableProps.style,
                      }}
                    >
                      <FormRow index={name} columnDefs={columnDefs} />
                      {expandedIds.includes(`ExpandedId${name}`) && (
                        <ExpandableComponent index={key} />
                      )}
                    </li>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </ul>
          )}
        </Droppable>
      </DragDropContext>
    </Box>
  );
};

export default FormTableDraggable;
