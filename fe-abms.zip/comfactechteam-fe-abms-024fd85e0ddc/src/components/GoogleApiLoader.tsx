import React, { ReactNode, useEffect } from 'react';

import environment from '@/config/environment';
import { useJsApiLoader } from '@react-google-maps/api';

const GOOGLE_API_KEY =
  environment.GOOGLE_API_KEY ?? 'AIzaSyD5peEU0aa8sKjHSw4S9XKnpFLabJ3gwRc';
const MAP_LIBRARIES: ['places'] = ['places'];

const GoogleApiLoader = ({
  children,
  onLoad,
}: {
  children: string | ReactNode;
  onLoad?: () => void;
}) => {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_API_KEY,
    libraries: MAP_LIBRARIES,
  });
  // const [isApiLoaded, setIsApiLoaded] = useState(isLoaded)
  // const [isScriptLoaded, setIsScriptLoaded] = useState(Boolean(window?.google));

  // const handleLoad = () => {
  //   setIsScriptLoaded(true);
  // };

  console.log('GOOGLE_API_KEY', GOOGLE_API_KEY);

  if (loadError) {
    // Handle loading errors here
    return <div>Error loading Google Maps API</div>;
  }

  /* eslint-disable react-hooks/rules-of-hooks */
  useEffect(() => {
    if (isLoaded && onLoad) {
      onLoad();
    }
  }, [isLoaded, onLoad]);

  // useEffect(() => {
  //   if (window?.google && isLoaded) {
  //     setIsScriptLoaded(true);
  //     setIsApiLoaded(true);
  //   }
  // }, [window?.google, isLoaded]);
  return (
    <>
      {/* {!isScriptLoaded && (
        <LoadScript
          googleMapsApiKey={GOOGLE_API_KEY}
          libraries={MAP_LIBRARIES}  // Load only once
          onLoad={handleLoad}
        >
          <div>Loading script...</div>
        </LoadScript>
      )} */}
      {isLoaded ? <>{children}</> : <div>Loading...</div>}
    </>
  );
};

export default GoogleApiLoader;
