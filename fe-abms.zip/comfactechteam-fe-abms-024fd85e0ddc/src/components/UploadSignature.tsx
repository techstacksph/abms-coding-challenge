import React, { useEffect, useRef } from 'react';
import { SignatureCanvas } from 'react-signature-canvas';

import { Button, Text, useModal, useSnackbar } from '@/styled-components';
import { styled } from 'styled-components';

import useImagePreview from '@/hooks/useImagePreview';
// import useImagePreview from '@/hooks/useImagePreview';
import { Box, Stack } from '@mui/material';

import {
  Row,
  Card,
  // message
} from 'antd';
import useCompanySettings from '@/hooks/useCompanySettings';
import { errorMessages } from '@/utils/messages.utils';

const StyledCard = styled(Card)`
  height: 100px;
  min-width: 100px;
  width: 100px;
  border: 1px dotted #d3d5d9;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  position: relative;
  padding: 0;
  overflow: hidden;

  .theme-provider-card-body {
    padding: 2px !important;
  }
`;

const UploadSignature = ({
  title = 'Signature',
  signature,
  setSignature,
  maxFileSizeKB,
}: {
  title?: string;
  subtitle?: string;
  signature?: string | null;
  setSignature?: React.Dispatch<React.SetStateAction<string | null>>;
  minimumFileSize?: number;
  maxFileSizeKB?: number; // Optional custom max file size in KB (overrides company settings)
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  // const { snackbar } = useSnackbar();
  const sigRef = useRef<SignatureCanvas>(null);
  const { Preview } = useImagePreview();
  const {
    maximumFileSizeValue: companyMaxFileSize,
    maximumFileSize: companyMaxFileSizeLabel,
  } = useCompanySettings();

  // Use custom max file size if provided, otherwise use company settings
  const maximumFileSizeValue = maxFileSizeKB || companyMaxFileSize;
  const maximumFileSize = maxFileSizeKB
    ? `${maxFileSizeKB} KB`
    : companyMaxFileSizeLabel;

  const { snackbar } = useSnackbar();
  const [openModal, closeModal, contextModal] = useModal({
    title: 'New signature',
    message: (
      <Stack direction={'column'} gap={2.5}>
        <Text weight='medium'>Direct signature</Text>
        <SignatureCanvas
          ref={sigRef}
          penColor='black'
          canvasProps={{
            style: { border: '1px dotted #D3D5D9', borderRadius: '8px' },
          }}
        />
        <Row style={{ justifyContent: 'space-between' }}>
          <Button
            ghost
            type='primary'
            $css={
              'width: 120px; color: #686D78 !important; border-color: #BEC0C6 !important'
            }
            onClick={() => {
              sigRef.current?.clear();
              setSignature(null);
            }}
          >
            Clear
          </Button>
          <Row style={{ gap: '16px' }}>
            <Button
              ghost
              type='primary'
              $css={
                'width: 120px; color: #686D78 !important; border-color: #BEC0C6 !important'
              }
              onClick={() => {
                closeModal();
              }}
            >
              Cancel
            </Button>
            <Button
              ghost
              type='primary'
              $css={
                'width: 120px; background-color: #3137FD !important; font-weight: 500; color: white !important;'
              }
              onClick={() => {
                setSignature(sigRef.current?.toDataURL('image/png'));
                closeModal();
              }}
            >
              Save
            </Button>
          </Row>
        </Row>
      </Stack>
    ),
    modalProps: {
      submitProps: {
        disabled: false,
        style: { display: 'none' },
      },
      cancelProps: {
        style: { display: 'none' },
      },
      submitText: 'Confirm',
    },
  });

  useEffect(() => {
    if ((contextModal.props as { open?: boolean })?.open && sigRef.current) {
      setTimeout(() => {
        const canvas = sigRef.current?.getCanvas();
        if (canvas) {
          const ctx = canvas.getContext('2d');
          const ratio = window.devicePixelRatio || 1;

          canvas.width = 501 * ratio;
          canvas.height = 150 * ratio;
          canvas.style.width = '501px';
          canvas.style.height = '150px';

          ctx?.scale(ratio, ratio);
        }
      }, 0);
    }
  }, [(contextModal.props as { open?: boolean })?.open]);

  const onClickUpload = () => {
    inputRef.current?.click();
  };

  const handleUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size against company settings
    if (file.size > maximumFileSizeValue * 1024) {
      snackbar({
        type: 'error',
        message: `${errorMessages.FILE_SIZE_EXCEEDED} ${maximumFileSize}`,
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (setSignature) setSignature(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <>
      {contextModal}
      <Stack sx={{ height: '100%', gap: '8px' }}>
        <Box>{title && <Text weight='medium'>{title}</Text>}</Box>
        <Stack direction={'row'} gap={4}>
          <StyledCard>
            {signature ? (
              <img
                src={signature}
                alt='Signature'
                style={{
                  height: '100px',
                  aspectRatio: 1,
                  objectFit: 'contain',
                }}
              />
            ) : (
              <Text $type='xs' color='var(--color-text-secondary)'>
                No signature
              </Text>
            )}
            <Preview />
          </StyledCard>

          <Stack direction='column'>
            <Text $type='xs' color='var(--color-text-secondary)'>
              File format: .PNG, .JPG, .JPEG <br />
              Max size is {maximumFileSize}.
            </Text>
            <Stack direction='row' gap={2} marginTop={2}>
              <Button type='primary' onClick={openModal}>
                New Signature
              </Button>
              <Button type='primary' onClick={onClickUpload}>
                Upload Photo
              </Button>
              {/* Hidden File Input */}
              <input
                type='file'
                accept='image/png, image/jpeg, image/jpg'
                ref={inputRef}
                style={{ display: 'none' }}
                onChange={handleUpload}
              />
            </Stack>
          </Stack>
        </Stack>
      </Stack>
    </>
  );
};

export default UploadSignature;
