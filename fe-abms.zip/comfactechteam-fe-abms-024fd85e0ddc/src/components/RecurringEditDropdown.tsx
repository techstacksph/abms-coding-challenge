/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { Dropdown, Button } from 'antd';
import type { MenuProps } from 'antd';
import { ModeEditOutlineOutlined } from '@mui/icons-material';
import { Icon } from '@/styled-components';

export type RecurringEditOption = 'this' | 'following' | 'all';

interface RecurringEditDropdownProps {
  onSelect: (option: RecurringEditOption) => void;
  buttonText?: string;
  buttonIcon?: React.ReactNode;
  type?: 'button' | 'link';
  disabled?: boolean;
  style?: React.CSSProperties;
  actionType?: 'edit' | 'delete';
  module?: 'task' | 'event';
}

const RecurringEditDropdown: React.FC<RecurringEditDropdownProps> = ({
  onSelect,
  buttonText = 'Edit',
  buttonIcon,
  type = 'button',
  disabled = false,
  style,
  actionType = 'edit',
  module = 'task',
}) => {
  const actionText = actionType === 'edit' ? 'Edit' : 'Delete';

  const items: MenuProps['items'] = [
    {
      key: 'this',
      label: (
        <div style={{ padding: '4px 0' }}>
          <div
            style={{ fontWeight: 500, color: '#1F2937', marginBottom: '4px' }}
          >
            This {module}
          </div>
          {/* <div style={{ fontSize: '12px', color: '#6B7280', maxWidth: '250px' }}>
            {actionText} only this occurrence. Other tasks in the series will be retained.
          </div> */}
        </div>
      ),
      onClick: () => onSelect('this'),
    },
    {
      key: 'following',
      label: (
        <div style={{ padding: '4px 0' }}>
          <div
            style={{ fontWeight: 500, color: '#1F2937', marginBottom: '4px' }}
          >
            This and all following {module}s
          </div>
          {/* <div style={{ fontSize: '12px', color: '#6B7280', maxWidth: '250px' }}>
            {actionText} this task and all future occurrences. Tasks prior to this will be retained.
          </div> */}
        </div>
      ),
      onClick: () => onSelect('following'),
    },
    {
      key: 'all',
      label: (
        <div style={{ padding: '4px 0' }}>
          <div
            style={{ fontWeight: 500, color: '#1F2937', marginBottom: '4px' }}
          >
            All {module}s in the series
          </div>
          {/* <div style={{ fontSize: '12px', color: '#6B7280', maxWidth: '250px' }}>
            {actionText} all tasks that are part of this recurring series.
          </div> */}
        </div>
      ),
      onClick: () => onSelect('all'),
    },
  ];

  const defaultIcon = (
    <Icon color='#878B97'>
      <ModeEditOutlineOutlined />
    </Icon>
  );

  return (
    <Dropdown menu={{ items }} trigger={['click']} placement='bottomLeft'>
      {type === 'button' ? (
        <Button
          icon={buttonIcon || defaultIcon}
          disabled={disabled}
          style={style}
        >
          {buttonText}
        </Button>
      ) : (
        <a onClick={e => e.preventDefault()} style={style}>
          {buttonIcon}
          {buttonText}
        </a>
      )}
    </Dropdown>
  );
};

export default RecurringEditDropdown;
