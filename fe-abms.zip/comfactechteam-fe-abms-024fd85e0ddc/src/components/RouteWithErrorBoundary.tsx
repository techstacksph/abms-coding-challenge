import React from 'react';
import { useLocation } from 'react-router-dom';

import ErrorBoundary from './ErrorBoundary';
import GenericErrorBoundary from './GenericErrorBoundary';

interface RouteWithErrorBoundaryProps {
  children: React.ReactNode;
  moduleName?: string;
  modulePath?: string;
  showGoToModule?: boolean;
  customMessage?: string;
  resetKey?: string | number;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

const RouteWithErrorBoundary: React.FC<RouteWithErrorBoundaryProps> = ({
  children,
  moduleName = 'Module',
  modulePath,
  showGoToModule = true,
  customMessage,
  resetKey,
  onError,
}) => {
  const location = useLocation();

  // Use the current path as the resetKey if none is provided
  // This ensures the error boundary resets on every page change
  const effectiveResetKey = resetKey ?? location.pathname;

  const defaultErrorHandler = (error: Error, errorInfo: React.ErrorInfo) => {
    console.error(`${moduleName} error:`, error);
    console.error('Error info:', errorInfo);
  };

  return (
    <ErrorBoundary
      resetKey={effectiveResetKey}
      fallback={
        <GenericErrorBoundary
          moduleName={moduleName}
          modulePath={modulePath}
          showGoToModule={showGoToModule}
          customMessage={customMessage}
        />
      }
      onError={onError || defaultErrorHandler}
    >
      {children}
    </ErrorBoundary>
  );
};

export default RouteWithErrorBoundary;
