import React from 'react';
import { Radio, Space } from 'antd';
import { Stack } from '@mui/material';
import { useModal } from '@/styled-components';

export type RecurringEditOption = 'this' | 'following' | 'all';

// Helper function to convert to sentence case
const toSentenceCase = (str: string): string => {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

interface UseRecurringEditModalProps {
  onConfirm: (option: RecurringEditOption) => void;
  onCancel?: () => void;
  title?: string;
  type?: 'edit' | 'delete';
}

export const useRecurringEditModal = ({
  onConfirm,
  onCancel,
  title = 'Edit recurring task',
  type = 'edit',
}: UseRecurringEditModalProps) => {
  const [selectedOption, setSelectedOption] =
    React.useState<RecurringEditOption>('this');

  const actionText = type === 'edit' ? 'Update' : 'Delete';
  const actionTextLower = type === 'edit' ? 'update' : 'delete';

  const [openModal, closeModal, contextModal] = useModal({
    title: toSentenceCase(title),
    message: (
      <Stack spacing={2} sx={{ py: 2 }}>
        <div style={{ marginBottom: '8px', color: '#494F5C' }}>
          This task is part of a recurring series. How would you like to{' '}
          {actionTextLower} it?
        </div>

        <Radio.Group
          onChange={e => setSelectedOption(e.target.value)}
          value={selectedOption}
          style={{ width: '100%' }}
        >
          <Space direction='vertical' style={{ width: '100%' }}>
            <Radio value='this' style={{ marginBottom: '12px' }}>
              <div>
                <div style={{ fontWeight: 500, color: '#1F2937' }}>
                  This task
                </div>
                <div style={{ fontSize: '13px', color: '#6B7280' }}>
                  {actionText} only this occurrence. Other tasks in the series
                  will be retained.
                </div>
              </div>
            </Radio>

            <Radio value='following' style={{ marginBottom: '12px' }}>
              <div>
                <div style={{ fontWeight: 500, color: '#1F2937' }}>
                  This and all following tasks
                </div>
                <div style={{ fontSize: '13px', color: '#6B7280' }}>
                  {actionText} this task and all future occurrences. Tasks prior
                  to this will be retained.
                </div>
              </div>
            </Radio>

            <Radio value='all'>
              <div>
                <div style={{ fontWeight: 500, color: '#1F2937' }}>
                  All tasks in the series
                </div>
                <div style={{ fontSize: '13px', color: '#6B7280' }}>
                  {actionText} all tasks that are part of this recurring series.
                </div>
              </div>
            </Radio>
          </Space>
        </Radio.Group>
      </Stack>
    ),
    onSubmit: () => {
      onConfirm(selectedOption);
      closeModal();
    },
    onCancel: () => {
      setSelectedOption('this');
      onCancel?.();
    },
    modalProps: {
      modalProps: {
        $css: `[class*="modal-content"] {
          width: 480px;
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          padding: 20px;
        }`,
      },
      submitProps: {
        style: {
          background: '#3137FD',
          fontWeight: 500,
        },
      },
      cancelProps: {
        style: {
          color: '#686D78',
          fontWeight: 500,
        },
      },
      submitText: 'Continue',
    },
  });

  return { openModal, closeModal, contextModal };
};

// Keep backward compatibility with existing code - deprecated, use useRecurringEditModal instead
interface RecurringEditModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: (option: RecurringEditOption) => void;
  title?: string;
  type?: 'edit' | 'delete';
}

const RecurringEditModal: React.FC<RecurringEditModalProps> = ({
  open,
  onClose,
  onConfirm,
  title = 'Edit recurring task',
  type = 'edit',
}) => {
  const handleConfirm = React.useCallback(
    (option: RecurringEditOption) => {
      onConfirm(option);
      onClose();
    },
    [onConfirm, onClose]
  );

  const { openModal, contextModal } = useRecurringEditModal({
    onConfirm: handleConfirm,
    onCancel: onClose,
    title,
    type,
  });

  // Track previous open state to only open when it changes from false to true
  const prevOpenRef = React.useRef(open);

  React.useEffect(() => {
    if (open && !prevOpenRef.current) {
      openModal();
    }
    prevOpenRef.current = open;
  }, [open, openModal]);

  return <>{contextModal}</>;
};

export default RecurringEditModal;
