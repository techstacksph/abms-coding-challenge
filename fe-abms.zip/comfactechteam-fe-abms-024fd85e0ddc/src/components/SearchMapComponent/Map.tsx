import React, { useState } from 'react';

import InfoOutlined from '@mui/icons-material/InfoOutlined';
import { GoogleMap, Marker } from '@react-google-maps/api';

import MapDetails, { mapDetails } from './MapDetails';
import { GOOGLE_MAP_ZOOM } from '@/enums/google-maps-enum';

type Props = {
  handleClick?: (e) => void;
  handleMapLoad: (e) => void;
  marker: google.maps.LatLngLiteral;
  mapDetails: mapDetails[];
  isModal: boolean;
  searchId?: string;
};

const infoStyle: React.CSSProperties = {
  width: 'fit-content',
  position: 'absolute',
  top: '10px',
  left: '10px',
  background: '#fff',
  padding: '3px',
  borderRadius: '5px',
  maxWidth: '314px',
  zIndex: 2,
};

const adjustPadding = {
  padding: '10px',
};

const mapOptions = {
  fullscreenControl: false,
  streetViewControl: false,
  mapTypeControl: false,
  cameraControl: false,
};

const Map = ({
  handleClick,
  handleMapLoad,
  marker,
  mapDetails,
  isModal,
  searchId,
}: Props) => {
  const [isOpenInfo, setIsOpenInfo] = useState<boolean>(true);
  const containerStyle = {
    width: '100%',
    height: isModal ? '562px' : '447px',
  };
  const openInfo = () => {
    if (mapDetails.length == 0) return;
    setIsOpenInfo(true);
  };
  return (
    <>
      <div className='map' style={{ position: 'relative' }}>
        <GoogleMap
          mapContainerStyle={{ ...containerStyle }}
          center={marker}
          zoom={GOOGLE_MAP_ZOOM}
          onClick={handleClick}
          onLoad={handleMapLoad}
          options={mapOptions}
        >
          {' '}
          <Marker position={marker} />
        </GoogleMap>
        <div
          style={{
            ...infoStyle,
            ...(isOpenInfo && mapDetails.length > 0 ? adjustPadding : {}),
          }}
        >
          {isModal && (
            <InfoOutlined
              sx={{
                color: '#7B8B99',
                marginBottom: isOpenInfo && mapDetails.length > 0 ? '10px' : 0,
              }}
              onClick={() => setIsOpenInfo(!isOpenInfo)}
            />
          )}

          {!isModal && mapDetails.length == 0 && (
            <InfoOutlined sx={{ color: '#7B8B99' }} onClick={openInfo} />
          )}

          {isOpenInfo && mapDetails.length > 0 && (
            <MapDetails
              details={mapDetails}
              isBigDescription={isModal}
              searchId={searchId}
              isModal={true}
            />
          )}
        </div>
      </div>
    </>
  );
};

export default Map;
