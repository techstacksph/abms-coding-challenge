import React, { ReactNode } from 'react';

import { Stack } from '@mui/material';

type Props = {
  children?: ReactNode;
  isMapActive: boolean;
};

const placeHolderStyle: React.CSSProperties = {
  position: 'absolute',
  top: '0',
  width: '100%',
  height: '100%',
  background: '#F4F4F6',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  color: '#131933',
};

const MapPlaceHolder = ({ children, isMapActive }: Props) => {
  return (
    <Stack
      style={{
        ...placeHolderStyle,
        ...(!isMapActive ? { zIndex: 3 } : {}),
      }}
    >
      {children}
    </Stack>
  );
};

export default MapPlaceHolder;
