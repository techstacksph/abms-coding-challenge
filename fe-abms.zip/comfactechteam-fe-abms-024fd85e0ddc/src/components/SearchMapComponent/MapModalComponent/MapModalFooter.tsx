import React, { useEffect, useState } from 'react';

import { useSnackbar, Button } from '@/styled-components';

import { ALL_COUNTRIES } from '@/graphql/country.gql';
import { CREATE_SITES } from '@/graphql/sites.gql';
import useMutation from '@/hooks/useMutation';
import useQuery from '@/hooks/useQuery';
import CountryModel from '@/models/CountryModel';
import { Stack } from '@mui/material';
import { formFullAddress } from '@/utils/string.utils';
import { useLeadForm } from '@/views/sales/leads/common/components/LeadFormProvider';

type Props = {
  closeModal: () => void;
  placeDetails: Record<string, string>;
  setInputValue: React.Dispatch<React.SetStateAction<string>>;
  setIsMapActive: React.Dispatch<React.SetStateAction<boolean>>;
  setIsSecMapActive: React.Dispatch<React.SetStateAction<boolean>>;
  setPlaceDetails: React.Dispatch<React.SetStateAction<[]>>;
};

const MapModalFooter = ({
  closeModal,
  placeDetails = {},
  setInputValue,
  setIsMapActive,
  setPlaceDetails,
  setIsSecMapActive,
}: Props) => {
  const { form, sites, refetchSites } = useLeadForm();
  const [isExisted, setIsExisted] = useState<Record<string, string>>({});

  const { snackbar } = useSnackbar();

  useEffect(() => {
    const data = sites.find(item => {
      return placeDetails?.siteName == item.siteName;
    });
    setIsExisted(data);
  }, [placeDetails]);

  const { data: dbCountries } = useQuery<Array<CountryModel>>({
    query: ALL_COUNTRIES,
    options: {
      variables: {
        sortArg: [
          {
            field: 'name',
            direction: 'asc',
          },
        ],
      },
    },
  });
  const [create] = useMutation({
    query: CREATE_SITES,
    successMessage: `${placeDetails.siteName} created successfully.`,
    onSuccess: (value: any) => {
      closeModal();
      refetchSites();
      // setInputValue('');
      // setIsMapActive(false);
      // setPlaceDetails([]);
      form.setFieldsValue({
        siteId: value.id,
        company: value?.siteName || 'N/A',
        notes: value?.notes || 'N/A',
      });
    },
    onError: err => {
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        snackbar({ type: 'error', message: 'The site already exists' });
        if (isExisted) {
          form.setFieldsValue({
            siteId: isExisted.id,
            company: isExisted?.siteName || 'N/A',
            notes: isExisted?.notes || 'N/A',
          });
        }
        closeModal();
      }
      return;
    },
  });
  const submitForm = () => {
    const country: CountryModel | null = placeDetails?.countryId
      ? dbCountries?.filter(item => item.code == placeDetails.countryId)[0]
      : null;

    if (country) {
      placeDetails['countryId'] = country?.id;
    }
    placeDetails['address'] = formFullAddress({
      streetAddress: placeDetails.streetAddress,
      suburb: placeDetails.suburb,
      city: placeDetails.city,
      region: placeDetails.region,
      postalCode: placeDetails.postalCode,
      countryId: placeDetails.countryId,
      countryText: country?.name || placeDetails?.countryText,
    });
    delete placeDetails.countryText;
    create({
      variables: {
        site: placeDetails,
      },
    });
  };
  const clearSearch = () => {
    setInputValue('');
    setIsMapActive(false);
    setPlaceDetails([]);
    setIsSecMapActive(false);
  };
  return (
    <>
      <Stack direction='row' spacing={2.5} justifyContent='space-between'>
        <Button
          ghost
          $css='width: 120px; color: #686D78 !important; border-color: #A7AAB2 !important; font-weight: 600; background: #FFFFFF !important; line-height: 20px;'
          onClick={clearSearch}
        >
          Clear
        </Button>
        <Stack spacing={2.5} direction={'row'}>
          <Button
            ghost
            $css='width: 120px; color: #686D78 !important; border-color: #A7AAB2 !important; font-weight: 600; background: #FFFFFF !important; line-height: 20px;'
            onClick={closeModal}
          >
            Cancel
          </Button>

          <Button
            type='primary'
            htmlType='submit'
            $css='width: 120px; border: 1px solid #3137FD !important; font-weight: 600; line-height: 20px;'
            onClick={submitForm}
          >
            Save
          </Button>
        </Stack>
      </Stack>
    </>
  );
};

export default MapModalFooter;
