import React from 'react';

import { Text } from '@/styled-components';

import { Stack } from '@mui/material';
import { Autocomplete } from '@react-google-maps/api';

import Map from './Map';
import { mapDetails } from './MapDetails';
import MapPlaceHolder from './MapModalComponent/MapPlaceHolder';

type Props = {
  autocompleteRef: React.MutableRefObject<google.maps.places.Autocomplete | null>;
  onPlaceChanged: () => void;
  handleClick: (e) => void;
  handleMapLoad: (e) => void;
  marker: google.maps.LatLngLiteral;
  mapDetails: mapDetails[];
  isMapActive: boolean;
  setIsMapActive: React.Dispatch<React.SetStateAction<boolean>>;
  inputValue: string;
  setInputValue: React.Dispatch<React.SetStateAction<string>>;
  setIsSecMapActive: React.Dispatch<React.SetStateAction<boolean>>;
};

const MapModal = ({
  autocompleteRef,
  handleClick,
  handleMapLoad,
  marker,
  onPlaceChanged,
  mapDetails,
  isMapActive,
  setIsMapActive,
  inputValue,
  setInputValue,
  setIsSecMapActive,
}: Props) => {
  const onPlaceChange = () => {
    setIsMapActive(true);
    setIsSecMapActive(true);
    onPlaceChanged();
  };
  const handleInputChange = e => {
    setInputValue(e.target.value);
  };
  return (
    <>
      <Stack sx={{ mb: 2 }} spacing={1}>
        <Text $css={'font-weight:500; margin-bottom:10px'}>Find address</Text>
        <Autocomplete
          onLoad={autocomplete => {
            autocompleteRef.current = autocomplete;
            autocomplete.setComponentRestrictions({ country: 'nz' });
          }}
          onPlaceChanged={onPlaceChange}
        >
          <input
            name={'test'}
            className='find-address-input'
            value={inputValue}
            onChange={e => handleInputChange(e)}
            placeholder=''
          />
        </Autocomplete>
      </Stack>
      <div style={{ marginTop: '16px', position: 'relative' }}>
        <MapPlaceHolder isMapActive={isMapActive}>
          <p>Enter address above to see results.</p>
        </MapPlaceHolder>
        <Map
          mapDetails={mapDetails}
          handleClick={handleClick}
          handleMapLoad={handleMapLoad}
          marker={marker}
          isModal={true}
        />
      </div>
    </>
  );
};

export default MapModal;
