import React from 'react';

import { Text, Button, MaterialIcon } from '@/styled-components';

import { Rating, Stack } from '@mui/material';
import { formatText } from '@/utils/helper.utils';
import { openExternalMap } from '@/utils/map.utils';

export type mapDetails = {
  type: string;
  details: {
    title: string;
    subTitle: string;
  };
};

export type Props = {
  details: mapDetails[];
  isBigDescription?: boolean;
  searchId?: string;
  clearMap?: () => void;
  isModal?: boolean;
  isView?: boolean;
};

const renderDetails = (params: mapDetails, index: number) => {
  const { details, type } = params;
  const isHeader = type === 'header';
  if (
    details.title == 'Rating' ||
    details.title == 'Reviews' ||
    type == 'header'
  )
    return;
  return (
    <Stack>
      <Text
        style={{
          fontWeight: 'normal',
          color: '#686D78',
          fontSize: '14px',
          maxWidth: '400px',
          wordWrap: 'break-word',
        }}
      >
        {details.title}
      </Text>
      <Text style={{ color: isHeader ? '#686D78' : '#090A0B' }}>
        {formatText(details.subTitle, index)}
      </Text>
    </Stack>
  );
};

const MapDetails = ({
  searchId,
  details,
  isBigDescription,
  clearMap,
  isModal,
  isView,
}: Props) => {
  return (
    <Stack>
      {isBigDescription ? (
        <>
          <Stack direction={'row'} spacing={2} justifyContent={'space-between'}>
            <Stack>
              {details.length > 0 && (
                <Text
                  style={{
                    fontWeight: '600',
                    color: '#090A0B',
                    fontSize: '16px',
                    maxWidth: isModal ? '290px' : '344px',
                    wordWrap: 'break-word',
                  }}
                >
                  {details[0].details?.title}
                </Text>
              )}
              {details.length > 0 && (
                <Text style={{ color: '#686D78' }}>
                  {formatText(details[0].details?.subTitle, 0)}
                </Text>
              )}
            </Stack>
            {!isModal && details.length > 0 && !isView && (
              <Button
                icon={<MaterialIcon name={'close'} />}
                ghost
                onClick={clearMap}
              />
            )}
          </Stack>
          <Stack
            spacing={1}
            sx={{
              maxHeight: '300px',
              overflowY: 'auto',
              overflowX: 'hidden',
            }}
          >
            {details.map((item, index) => (
              <Stack key={index}>{renderDetails(item, index)}</Stack>
            ))}
          </Stack>
        </>
      ) : (
        <Stack>
          <Text $css={'font-weight:bolder; font-size:16px;'}>
            {details[0].details.title}
          </Text>
          <Text $css={'font-size:12px; color:#5e5e5e; '}>
            {details[1].details.subTitle}
          </Text>
          <Stack direction={'row'} spacing={2}>
            <Text $css={'font-weight:bolder;  '}>
              {details[5].details.subTitle}
            </Text>
            <Rating
              readOnly
              value={Number(details[5].details.subTitle)}
              precision={0.5}
              size='small'
              sx={{
                fontSize: '14px',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            />
            <Text $css={'color:#1b6ef3'}>
              {details[6].details.subTitle + ' reviews'}{' '}
            </Text>
          </Stack>
          <Text
            $css={'color:#1b6ef3; cursor:pointer'}
            onClick={() => openExternalMap(searchId)}
          >
            View larger map
          </Text>
        </Stack>
      )}
    </Stack>
  );
};

export default MapDetails;
