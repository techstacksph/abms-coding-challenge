import React, { useEffect, useState } from 'react';

import { Text } from '@/styled-components';

import { Stack } from '@mui/material';
import { gotoDirection, openExternalMap } from '@/utils/map.utils';

type detailType = {
  placeId: string;
  details: any[];
};
type Props = {
  detail: detailType;
  coordinates: any;
};

const mapDetailStyle: React.CSSProperties = {
  minHeight: '115px',
  width: '300px',
  position: 'absolute',
  top: '0',
  left: '0',
  margin: '10px',
  padding: '9px 4px 9px 11px',
  background: '#fff',
};
const IconStyle = {
  width: '22px',
  height: '22px',
  overflow: 'hidden',
  backgroundImage:
    'url(https://maps.gstatic.com/mapfiles/embed/images/entity11.png)',
  backgroundSize: '70px 210px',
};
const navigateText: React.CSSProperties = {
  marginTop: '5px',
  textAlign: 'center',
  color: '#1a73e8',
  fontSize: '12px',
  maxWidth: '100px',
  overflow: 'hidden',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  cursor: 'pointer',
};
const MiniMapDetail = ({ detail, coordinates }: Props) => {
  const [placeDetail, setPlaceDetail] = useState<detailType | null>(null);

  useEffect(() => {
    if (detail) {
      setPlaceDetail(detail);
    }
  }, [detail]);

  if (!placeDetail) {
    return null;
  }
  return (
    <Stack style={mapDetailStyle} direction={'row'}>
      <Stack style={{ width: '70%' }}>
        <Text style={{ fontSize: '14px', fontWeight: '500' }}>
          {placeDetail?.details[0]?.title}
        </Text>
        <Text style={{ marginTop: '6px', fontSize: '12px', color: '#5b5b5b' }}>
          {placeDetail?.details[1]?.subTitle}
        </Text>
        <Text
          $type='xs'
          style={{
            color: '#1a73e8',
            paddingTop: '10px',
            justifyContent: 'left',
            fontSize: '12px',
            cursor: 'pointer',
          }}
          onClick={() => openExternalMap(placeDetail.placeId)}
          type='text'
        >
          View larger map
        </Text>
      </Stack>
      <Stack alignItems={'center'} style={{ width: '30%' }}>
        <div style={IconStyle}></div>
        <Text style={navigateText} onClick={() => gotoDirection(coordinates)}>
          Directions
        </Text>
      </Stack>
    </Stack>
  );
};

export default MiniMapDetail;
