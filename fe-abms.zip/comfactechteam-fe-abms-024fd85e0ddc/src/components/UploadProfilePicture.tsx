import { SetStateAction, useRef } from 'react';

import {
  Button,
  Space,
  Text,
  UploadImage,
  useSnackbar,
} from '@/styled-components';

import useImagePreview from '@/hooks/useImagePreview';
import { useMediaQuery, useTheme } from '@mui/material';

import { Col, Row } from 'antd';

import { validateProfileImage } from '../services/profileimageupload.services';
import ProfileIcon from './ProfileIcon';
import useCompanySettings from '@/hooks/useCompanySettings';
import { errorMessages } from '@/utils/messages.utils';

const UploadProfilePicture = ({
  title = 'Photo',
  subtitle,
  profilePicture,
  setProfilePicture,
}: {
  title?: string;
  subtitle?: string;
  profilePicture?: any;
  setProfilePicture?: SetStateAction<any>;
  minimumFileSize?: number;
}) => {
  const isMobile = useMediaQuery(useTheme().breakpoints.down('md'));
  const inputRef = useRef(null);
  const { Preview, onPreview } = useImagePreview();
  const { snackbar } = useSnackbar();
  const { maximumFileSizeValue, maximumFileSize } = useCompanySettings();

  const onClickUpload = () => {
    inputRef.current.querySelector('input[type="file"]').click();
  };

  const beforeUpload = (file: { size: number }) => {
    // Check company settings file size limit first
    if (file.size > maximumFileSizeValue * 1024) {
      snackbar({
        type: 'error',
        message: `${errorMessages.FILE_SIZE_EXCEEDED} ${maximumFileSize}`,
      });
      return false;
    }

    // Then check the profile image specific validation
    const profileImageValidation = validateProfileImage({ file });

    if (profileImageValidation?.status === 'error') {
      snackbar({
        type: profileImageValidation.status,
        message: profileImageValidation.message,
      });
    }
    return profileImageValidation.valid;
  };

  return (
    <>
      <Row style={{ width: '50%' }} gutter={[0, 16]}>
        <Col span={24}>
          {title && (
            <Text weight='medium' $css='display: block;'>
              {title}
            </Text>
          )}
          {subtitle && (
            <Text $type='xs' color='var(--color-text-secondary)'>
              {' '}
              {subtitle}{' '}
            </Text>
          )}
        </Col>
        <Col flex='auto'>
          <Row
            gutter={[32, 0]}
            style={isMobile ? { justifyContent: 'center' } : undefined}
          >
            <Col>
              <UploadImage
                beforeUpload={beforeUpload}
                onChange={({ fileList }) => setProfilePicture(fileList[0])}
                ref={inputRef}
                fileList={profilePicture && [profilePicture]}
                onPreview={onPreview}
              >
                {!profilePicture && <ProfileIcon />}
              </UploadImage>
              <Preview />
            </Col>
            <Col flex='auto'>
              <Space
                direction='vertical'
                $css={`width: 100%; text-align: ${
                  isMobile ? 'center' : 'left'
                };`}
                size={20}
              >
                <Text $type='xs' color='var(--color-text-secondary)'>
                  File format: .PNG, .JPG, .JPEG <br />
                  Max size is {maximumFileSize}.
                </Text>
                <Button type='primary' onClick={onClickUpload}>
                  Upload Photo
                </Button>
              </Space>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
};

export default UploadProfilePicture;
