import React, { useEffect, useState, useRef } from 'react';

import {
  ModuleTable as Table,
  Checkbox,
  Icon,
  Text,
  Select,
  GoogleIcon,
  EmptyState,
  MaterialIcon,
} from '@/styled-components';

import useQuery from '@/hooks/useQuery';
import { Box, Stack } from '@mui/material';
import { ModuleTableProps } from '@/typings/modulTable.types';

import { Dropdown } from 'antd';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

const RowsPerPage = ({ total, range, setPageSize, pageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        defaultValue={pageSize}
        options={[
          {
            label: '10',
            value: 10,
          },
          {
            label: '20 ',
            value: 20,
          },
          {
            label: '50',
            value: 50,
          },
          {
            label: '100',
            value: 100,
          },
        ]}
        onChange={val => setPageSize(val)}
        suffixIcon={
          <GoogleIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
          &[class*="-select-focused"] [class*="-select-selector"] {
            box-shadow: none;
          }

          [class$="select-selection-item"] {
            color: var(--color-text-primary) !important;
            font-size: 12px;
            padding-inline-end: 24px !important;
          }
          [class$="select-selector"] {
            gap: 4px;
            padding: 0 4px;
            border-width: 0 !important;
          }
        `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};

const ModuleTable = ({
  columns,
  allQuery,
  onChangeSelected,
  searchFields,
  filterFields = [],
  refetch,
  nameField = 'name',
  onHandleData = null,
  transform = undefined,
  onTableChange = undefined,
  loading = false,
  otherTableProps = {},
  selectedProps,
  hasRowSelections = true,
  ...props
}: ModuleTableProps) => {
  const {
    rowSelection,
    setAllQueryData,
    sortArg,
    lengthPerPage = 20,
    skip = false,
  } = props as any;
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();
  const [selected, setSelected] = useState([]);
  const [pageSize, setPageSize] = useState<number>(lengthPerPage);
  const currentPageData = useRef([]);

  let searchArg = [];
  if (searchFields) searchArg = searchFields;

  for (const filterArr of filterFields) {
    if (filterArr && filterArr != null) {
      searchArg.push(filterArr);
    }
  }

  const {
    data: allData,
    loading: allLoading,
    refetch: allRequery,
  } = useQuery<Array<any>>({
    query: allQuery,
    options: {
      fetchPolicy: 'no-cache',
      variables: {
        sortArg: sortArg || [
          {
            field: nameField,
            direction: 'asc',
          },
        ],
        searchArg,
      },
    },
    transformData: data => (transform ? transform(data) : data),
    skip: skip,
  });

  const onSelectType = async (type: SelectAllMenuTypes) => {
    setSelectType(type);

    let selectId = [];
    if (type === 'this') {
      selectId = currentPageData.current?.map(d => d.id);
      onChangeSelected(currentPageData.current, type);
    } else if (type === 'all') {
      selectId = allData ? allData?.map(v => v.id) : [];
      onChangeSelected(allData ?? [], type);
    } else if (type === 'deselect') {
      onChangeSelected([], type);
    }

    setSelected(selectId);
  };

  const customRowSelection = {
    preserveSelectedRowKeys: true,
    columnWidth: 68,
    selectedRowKeys: selected,
    getCheckboxProps: record => ({
      disabled: record.isGroupHeader,
      style: record.isGroupHeader ? { display: 'none' } : {},
    }),
    columnTitle: () => {
      if (rowSelection?.type === 'radio') return;

      const totalItems = allData?.length || 0;
      const selectedCount = selected.length;
      const isAllSelected = selectedCount > 0 && selectedCount === totalItems;
      const isIndeterminate = selectedCount > 0 && selectedCount < totalItems;

      return (
        <Dropdown
          menu={{
            items: [
              {
                key: 'thisPage',
                label: 'Select this page',
                onClick: () => onSelectType('this'),
              },
              {
                key: 'allPage',
                label: 'Select all page',
                onClick: () => onSelectType('all'),
              },
              {
                key: 'deselectAll',
                label: 'Deselect all',
                onClick: () => onSelectType('deselect'),
              },
            ],
          }}
          trigger={['click']}
        >
          <a role='button'>
            <Stack direction='row' alignItems='center' spacing={0.5}>
              <Checkbox
                checked={isAllSelected}
                indeterminate={isIndeterminate}
                $css={`
                  min-width: 24px !important;
                  height: 24px;
                  justify-content: center;  
                `}
              />
              <Icon color='var(--gray-600)'>
                <MaterialIcon name='arrow_drop_down' />
              </Icon>
            </Stack>
          </a>
        </Dropdown>
      );
    },
    onChange: keys => {
      setSelected(keys);
      if (onChangeSelected) {
        const cleanRows = allData.filter(r => keys.includes(r.id));
        onChangeSelected(cleanRows, selectType);
      }
    },
    renderCell: (_, record, ___, originNode) => {
      if (record.isGroupHeader) {
        return { children: null, props: { colSpan: 0 } };
      }
      if (rowSelection?.type === 'radio') return originNode;

      return (
        <Box
          display='flex'
          sx={{
            width: 24,
            height: 24,
            justifyContent: 'center',
          }}
        >
          {originNode}
        </Box>
      );
    },
  };

  useEffect(() => {
    if (setAllQueryData && allData) {
      setAllQueryData(allData);
    }

    if (onHandleData) {
      onHandleData(allData);
    }
  }, [allData]);

  useEffect(() => {
    if (refetch?.refetch) {
      allRequery();
      onSelectType('deselect');
      onChangeSelected([], selectType);
      setSelected([]);
      refetch.setRefetch(false);
    }
  }, [refetch?.refetch]);

  useEffect(() => {
    if (selectedProps !== undefined) {
      setSelected(selectedProps);
    }
  }, [selectedProps]);

  return (
    <Table
      columns={columns}
      data={props?.staticData ?? allData}
      paginationText={'Rows per page'}
      showPaginationItems={false}
      onSelectAllMenu={type => setSelectType(type)}
      loading={[allLoading, loading].includes(true)}
      rowSelection={hasRowSelections ? customRowSelection : undefined}
      hidePagination
      onChange={onTableChange}
      tableProps={{
        footer: currentPage => {
          currentPageData.current = currentPage;
          return;
        },
        pagination: {
          total: allData?.length,
          showSizeChanger: false,
          position: ['bottom', 'left'],
          pageSize: pageSize,
          defaultPageSize: 10,
          showTotal: (total, range) => (
            <RowsPerPage
              total={total}
              range={range}
              setPageSize={setPageSize}
              pageSize={pageSize}
            />
          ),
          itemRender: (_, type, originalElement) =>
            type === 'page' ? null : originalElement,
        },
        tableLayout: 'fixed',
        ...otherTableProps,
      }}
      emptyState={
        props?.emptyState ?? (
          <EmptyState iconW='200px' title='No data to display.' />
        )
      }
      {...props}
    />
  );
};

export default ModuleTable;
