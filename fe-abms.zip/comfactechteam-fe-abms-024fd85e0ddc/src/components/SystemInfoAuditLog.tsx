import { useMemo, useState } from 'react';

import DataTable from '@/components/DataTable';
import ViewModuleSections from '@/components/modules/ViewModuleSections';
import { auditLogColumns } from '@/components/SystemInfoAuditLog/columns';
import { AUDIT_TRAILS, PAGINATED_AUDIT_TRAILS } from '@/graphql/auditTrail.gql';
import { SortDirection } from '@mui/material';
import User from '@/models/User';
import { SearchComparator } from '@/typings/module.types';

type FixedSearchItem = {
  fieldName: string | null;
  searchValue: string | null;
  comparator: string | null;
};

type SystemInfoAuditLogProps = {
  recordId?: string;
  calledFrom?: string;
  fixedSearch?: FixedSearchItem[];
  findUserById: (id: string) => User | null;
  setIsLoading: (isLoading: boolean) => void;
};

const defaultSortArg = [
  {
    field: 'createdAt',
    direction: 'desc' as SortDirection,
  },
];

const SystemInfoAuditLog = ({
  calledFrom,
  fixedSearch,
  findUserById,
  setIsLoading,
  recordId,
}: SystemInfoAuditLogProps) => {
  const [page, setPage] = useState<number>(1);
  const [refetch, setRefetch] = useState<boolean>(false);

  // Create search arguments for audit logs
  // const auditLogSearchFields = () => {
  //   const searchArgs = [];

  //   // Always filter by recordId
  //   if (recordId) {
  //     searchArgs.push({
  //       fieldName: 'recordId',
  //       searchValue: recordId,
  //       comparator: SearchComparator.EQUAL,
  //     });
  //   }

  //   // Add any additional fixed search criteria
  //   if (fixedSearch && Array.isArray(fixedSearch)) {
  //     fixedSearch.forEach(search => {
  //       if (search.fieldName && search.searchValue && search.comparator) {
  //         searchArgs.push(search);
  //       }
  //     });
  //   }

  //   return searchArgs;
  // };

  const memoAuditLogSearach = useMemo(() => {
    const searchArgs = [];
    if (recordId) {
      searchArgs.push({
        fieldName: 'recordId',
        searchValue: recordId,
        comparator: SearchComparator.EQUAL,
      });
    }

    // Add any additional fixed search criteria
    if (fixedSearch && Array.isArray(fixedSearch)) {
      fixedSearch.forEach(search => {
        if (search.fieldName && search.searchValue && search.comparator) {
          if (search?.fieldName != 'recordId') {
            searchArgs.push(search);
          }
        }
      });
    }
    return searchArgs;
  }, [recordId, fixedSearch]);

  return (
    <ViewModuleSections
      title='Audit logs'
      containerProps={{ width: '100%', marginTop: '30px' }}
    >
      <DataTable
        columns={auditLogColumns(findUserById)}
        defaultPageSize={10}
        paginatedQuery={PAGINATED_AUDIT_TRAILS}
        hasRowSelections={false}
        onChangeSelected={() => {}}
        allQuery={AUDIT_TRAILS}
        refetch={{ refetch, setRefetch }}
        setPage={setPage}
        page={page}
        onTableChange={(pagination, filters, sorter, extra) => {
          if (extra?.action === 'paginate') {
            setPage(pagination?.current);
          }
        }}
        sortArg={defaultSortArg}
        nameField='paginatedAuditTrails'
        calledFrom={calledFrom}
        searchFields={[...memoAuditLogSearach]}
        setIsDataLoading={setIsLoading}
        module={'auditTrails'}
      />
    </ViewModuleSections>
  );
};

export default SystemInfoAuditLog;
