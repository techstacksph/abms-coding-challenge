import React, { ComponentProps } from 'react';

import { Descriptions as BaseDescriptions, Text } from '@/styled-components';

import { Stack } from '@mui/material';

const Descriptions = (
  props: ComponentProps<typeof BaseDescriptions> & {
    hasSubHeader?: boolean;
    subHeader?: string | React.ReactNode;
    labelStyle?: any;
    contentStyle?: any;
    marginTop?: string | number;
  }
) => {
  const boxCss = {
    boxSizing: 'border-box',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: 0,
    width: '45%',
    height: '100%',
    border: '1px solid #D3D5D9',
    background: '#f5f5f7',
    borderRadius: '8px',
    flex: 'none',
    order: 0,
    flexGrow: 1,
    contentMargin: props?.marginTop || 0,
  };

  return (
    <Stack spacing={2} sx={boxCss}>
      {props?.title && (
        <Text $type='sm' weight='medium'>
          {props?.title}
        </Text>
      )}
      {props?.subHeader && (
        <Text $type='sm' weight='bold' $css={'font-size: 14px !important;'}>
          {props?.subHeader}
        </Text>
      )}
      <BaseDescriptions
        labelStyle={{
          width: 160,
          color: 'var(--color-text-secondary)',
          lineHeight: '20px',
          // background: '#f5f5f7',
          padding: '16px',
          marginTop: '-1px',
          marginLeft: '-1px',
          // borderTopLeftRadius: '6px',
          ...props?.labelStyle,
        }}
        contentStyle={{
          background: '#fff',
          padding: '16px',
          color: 'var(--color-text-primary)',
          marginTop: '-1px',
          lineHeight: '20px',
          ...props?.contentStyle,
        }}
        colon={false}
        $css=" [class$='descriptions-item'] {
          padding-bottom: 0 !important;
        }"
        {...props}
        title={undefined}
      />
    </Stack>
  );
};

export default Descriptions;
