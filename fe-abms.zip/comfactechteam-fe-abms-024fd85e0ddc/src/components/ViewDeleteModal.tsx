import React, { SetStateAction, useEffect } from 'react';

import { DocumentNode } from 'graphql';

import { useModal, useSnackbar } from '@/styled-components';

import useMutation from '@/hooks/useMutation';
import useNavigate from '@/hooks/useNavigate';
import { getDeleteSuccessMessage } from '@/utils/message.helper.utils';

const ViewDeleteModal = ({
  recordName,
  open,
  deleteQuery,
  id,
  setOpen,
  deleteVar = 'id',
  redirection = './',
  deleteTitle = 'Delete ',
  message,
  customSuccessDeleteMessage,
  shouldDelete = true,
  errorMessage = '',
  onDelete,
  onLoadingChange,
  recurringDeleteOption,
  additionalDeleteVariables,
  refetchQueries,
  onSuccessCallback,
}: {
  recordName: string;
  open: boolean;
  deleteQuery: DocumentNode;
  id: string;
  deleteVar?: string;
  redirection?: string;
  deleteTitle?: string;
  message: any;
  setOpen: (open) => SetStateAction<any>;
  customSuccessDeleteMessage?: string;
  shouldDelete?: boolean;
  errorMessage?: string;
  onDelete?: () => void;
  onLoadingChange?: (loading: boolean) => void;
  recurringDeleteOption?: string;
  additionalDeleteVariables?: Record<string, any>;
  refetchQueries?: string[];
  onSuccessCallback?: () => void;
}) => {
  const { snackbar } = useSnackbar();
  const { navigate } = useNavigate('View');
  const [deleteRecord, { loading }] = useMutation({
    query: deleteQuery,
    options: {
      variables: {
        [deleteVar]: id,
        ...(recurringDeleteOption && { recurringDeleteOption }),
        ...(additionalDeleteVariables || {}),
      },
      ...(refetchQueries && { refetchQueries, awaitRefetchQueries: true }),
    },
    disableAlert: true,
    onSuccess: () => {
      snackbar({
        type: 'success',
        message:
          customSuccessDeleteMessage ||
          getDeleteSuccessMessage({
            recordName,
            isPlural: false,
          }),
      });
      setOpen(false);
      if (redirection) {
        navigate(redirection);
      }
      closeModal();
      // Call the onSuccessCallback if provided
      if (onSuccessCallback) {
        onSuccessCallback();
      }
    },
    onError: err => {
      snackbar({
        type: 'error',
        message: errorMessage || err.message,
      });
      setOpen(false);
      closeModal();
    },
  });

  // Notify parent component of loading state changes
  useEffect(() => {
    if (onLoadingChange) {
      onLoadingChange(loading);
    }
  }, [loading, onLoadingChange]);

  const validateDelete = async () => {
    if (shouldDelete) {
      if (onDelete) {
        onDelete();
      }
      await deleteRecord();
    } else {
      snackbar({
        type: 'error',
        message: errorMessage,
      });
      setOpen(false);
      closeModal();
    }
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: `Delete ${deleteTitle}`,
    type: 'warning',
    message: message,
    onSubmit: async () => await validateDelete(),
    onCancel: () => setOpen(false),
    modalProps: {
      submitProps: {
        disabled: loading,
      },
      submitText: 'Delete',
    },
  });

  useEffect(() => {
    if (open) openModal();
  }, [open]);

  return <>{contextModal}</>;
};

export default ViewDeleteModal;
