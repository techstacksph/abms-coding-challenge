import { useEffect } from 'react';

import {
  FormSection,
  Icon,
  MaterialIcon,
  Form,
  useModal,
  FormButtons,
  useSnackbar,
} from '@/styled-components';

import { SELECT_ITEM_CATEGORIES } from '@/graphql/itemCategory.gql';
import { QUICK_CREATE_ITEM_SUBCATEGORY } from '@/graphql/itemSubcategory.gql';
import useMutation from '@/hooks/useMutation';
import useQuery from '@/hooks/useQuery';
import ItemCategoryModel from '@/models/ItemCategoryModel';
import ItemSubcategoryModel from '@/models/ItemSubcategoryModel';
import { Box } from '@mui/material';
import { labelSpan, required } from '@/utils/inputProps.util';
import useFormFailed from '@/hooks/useFormFailed';

import { Form as AntdForm } from 'antd';

// Item subcategory fields for the quick create form
const fields = (
  itemCategories: Array<ItemCategoryModel> = [],
  parentCategoryId?: string,
  hideCategorySelect?: boolean
) => ({
  title: '',
  showDivider: false,
  $titleCss: 'display:none; ',
  fields: [
    {
      title: 'Name',
      type: 'text',
      field: 'name',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
    },
    // Only show item category field if parentCategoryId is not provided
    ...(parentCategoryId || hideCategorySelect
      ? []
      : [
          {
            title: 'Item category',
            type: 'select',
            field: 'itemCategoryId',
            required: true,
            props: {
              ...labelSpan,
              rules: [required],
              $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
            },
            inputProps: {
              placeholder: 'Select',
              options:
                itemCategories?.map(category => ({
                  label: category.name,
                  value: category.id,
                })) || [],
            },
          },
        ]),
    // {
    //   title: 'Code',
    //   type: 'text',
    //   field: 'code',
    //   props: {
    //     ...labelSpan,
    //     $css: `[class*="form-item-label"] {padding-bottom: 16px;}`,
    //   },
    //   inputProps: {
    //     placeholder: 'Enter code (optional)',
    //   },
    // },
    {
      title: 'Description',
      type: 'textarea',
      field: 'description',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      inputProps: {
        rows: 3,
      },
    },
  ],
});

export const ItemSubcategoryQuickCreate = ({
  handleSuccess,
  parentCategoryId,
  onDeferSave,
  hideItemCategorySelect,
  existingNames = [],
}: {
  handleSuccess?: (val: ItemSubcategoryModel) => void;
  parentCategoryId?: string;
  onDeferSave?: (val: { name: string; description?: string }) => void;
  hideItemCategorySelect?: boolean;
  existingNames?: string[];
}) => {
  const [form] = AntdForm.useForm();
  const onFinishFailed = useFormFailed<{
    name: string;
    itemCategoryId: string;
  }>({
    name: 'Name',
    itemCategoryId: 'Item category',
  });
  const { snackbar } = useSnackbar();
  useEffect(() => {
    form.setFieldsValue({
      active: true,
      ...(parentCategoryId && { itemCategoryId: parentCategoryId }),
    });
  }, [parentCategoryId]);

  const { data: itemCategories } = useQuery<Array<ItemCategoryModel>>({
    query: SELECT_ITEM_CATEGORIES,
    transformData: data =>
      data?.map(d => ({
        id: d.id,
        name: d.name,
      })),
    // Skip query if parentCategoryId is provided since we won't need the categories list
    skip: !!parentCategoryId,
  });

  const [createItemSubcategory] = useMutation({
    query: QUICK_CREATE_ITEM_SUBCATEGORY,
    successMessage: `${form.getFieldValue('name')} successfully created.`,
    onSuccess: (value: ItemSubcategoryModel) => {
      if (handleSuccess) {
        handleSuccess(value);
      }
      closeModal();
      form.resetFields();
    },
    onError: err => {
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      const field = graphQLError?.extensions.field;

      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        form.setFields([
          {
            name: field,
            errors: ['Name already exists. This field must be unique.'],
          },
        ]);
      }
      return;
    },
  });

  const onFinish = async values => {
    // Set default active status
    values['active'] = true;

    if (onDeferSave) {
      // Unique name validation for deferred saves (client-side)
      const name = (values?.name || '').trim();
      if (
        !name ||
        existingNames.map(n => n.toLowerCase()).includes(name.toLowerCase())
      ) {
        form.setFields([
          {
            name: 'name',
            errors: [
              !name
                ? 'This field is required.'
                : 'Name already exists. This field must be unique.',
            ],
          },
        ]);
        snackbar({ type: 'error', message: 'Error: Invalid data.' });
        return;
      }

      onDeferSave({ name, description: values?.description });
      snackbar({ type: 'success', message: `${name} successfully created.` });
      closeModal();
      form.resetFields();
      return;
    }

    // Ensure parentCategoryId is set if provided
    if (parentCategoryId) {
      values['itemCategoryId'] = parentCategoryId;
    }

    await createItemSubcategory({
      variables: {
        input: {
          ...values,
        },
      },
    });
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New subcategory',
    message: (
      <Box sx={{ button: { width: 120 }, width: '100%' }}>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFinishFailed}>
          <FormSection
            fields={fields(
              itemCategories,
              parentCategoryId,
              hideItemCategorySelect
            )}
            $css={'width: 100%;'}
          />
          <FormButtons
            saveAsDraft={false}
            onCancel={() => {
              form.resetFields();
              closeModal();
            }}
            submitText='Save'
          />
        </Form>
      </Box>
    ),
    modalProps: {
      modalProps: {
        $css: `[class*="modal-content"] {
          width: 600px;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }`,
        footer: null,
      },
    },
  });

  const handleOpenModal = () => {
    form.resetFields();
    form.setFieldsValue({
      active: true,
      ...(parentCategoryId && { itemCategoryId: parentCategoryId }),
    });
    openModal();
  };

  return (
    <>
      {contextModal}
      <Box
        sx={{
          color: 'rgba(49, 55, 253, 1)',
          backgroundColor: '#FFFFFF',
          width: '40px',
          height: '40px',
          border: '1px solid rgba(49, 55, 253, 1)',
          padding: '8px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: '8px',
          marginTop: '12px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
            cursor: 'pointer',
          },
        }}
        onClick={handleOpenModal}
      >
        <Icon $css='rotate: -90deg;'>
          <MaterialIcon iconClass='material-icons' name='add' />
        </Icon>
      </Box>
    </>
  );
};

export default ItemSubcategoryQuickCreate;
