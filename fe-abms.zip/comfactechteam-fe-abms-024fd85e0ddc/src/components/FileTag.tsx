import React from 'react';

import { GoogleIcon, Text } from '@/styled-components';

import { Tag } from 'antd';

const FileTag = ({
  title,
  icon,
  tagProps,
  textProps,
  iconProps,
  tagStyle,
  customIcon,
}: {
  title: string;
  icon?: any;
  tagProps?: any;
  textProps?: any;
  iconProps?: any;
  tagStyle?: any;
  customIcon?: any;
}) => {
  return (
    <Tag
      style={{
        borderRadius: '8px',
        display: 'flex',
        alignItems: 'center',
        gap: '4px',
        padding: '4px 8px',
        width: 'auto',
        minWidth: '82px',
        height: '26px',
        cursor: 'pointer',
        ...tagStyle,
      }}
      {...tagProps}
    >
      {customIcon ? (
        customIcon
      ) : (
        <GoogleIcon
          name={icon}
          size='24'
          $css={'color: rgba(135, 139, 151, 1); font-size: 16px;'}
          {...iconProps}
        />
      )}
      <Text
        $css={
          'font-size: 12px; font-weight: 600; color: #090A0B; line-height: 18px; white-space: nowrap;'
        }
        {...textProps}
      >
        {title}
      </Text>
    </Tag>
  );
};

export default FileTag;
