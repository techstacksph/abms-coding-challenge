import React from 'react';
import { Modal, Typography } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import styled from 'styled-components';

const { Text } = Typography;

export interface SessionTimeoutWarningProps {
  /**
   * Whether the warning dialog is visible
   */
  visible: boolean;

  /**
   * Remaining time in seconds
   */
  remainingTime: number;

  /**
   * Callback when user closes modal to extend session
   */
  onExtendSession: () => void;

  /**
   * Callback when timeout completes (automatic logout)
   */
  onLogout: () => void;
}

const StyledModal = styled(Modal)`
  .ant-modal-content {
    border-radius: 20px;
    padding: 48px 64px;
  }

  .ant-modal-header {
    border-bottom: none;
    padding: 0;
    margin-bottom: 40px;
  }

  .ant-modal-body {
    padding: 0;
  }

  .ant-modal-footer {
    display: none;
  }

  .ant-modal-close {
    top: 24px;
    right: 24px;
    width: 40px;
    height: 40px;
    border-radius: 8px;
    border: 1px solid #e8e8e8;
    background: #ffffff;

    &:hover {
      background: #f5f5f5;
    }

    .ant-modal-close-x {
      width: 40px;
      height: 40px;
      line-height: 40px;
      font-size: 20px;
      color: #1f2937;
    }
  }
`;

const ContentWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 48px;
`;

const CircularTimer = styled.div`
  position: relative;
  width: 160px;
  height: 160px;
  flex-shrink: 0;
`;

const CircularProgress = styled.svg`
  width: 160px;
  height: 160px;
  transform: rotate(-90deg);
`;

const CircleBackground = styled.circle`
  fill: none;
  stroke: #e5e7eb;
  stroke-width: 12;
`;

const CircleProgress = styled.circle`
  fill: none;
  stroke: #2563eb;
  stroke-width: 12;
  stroke-linecap: round;
  transition: stroke-dashoffset 1s linear;
`;

const TimerText = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-family:
    'Inter',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    sans-serif;
  font-size: 48px;
  font-weight: 600;
  color: #1f2937;
  line-height: 1;
`;

const MessageText = styled(Text)`
  font-family:
    'Inter',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 21px;
  color: #1f2937;
  display: block;
`;

/**
 * Session Timeout Warning Dialog
 *
 * Shows a minimal warning dialog when session is about to expire due to inactivity.
 * User can close the modal to extend their session, or let it timeout for automatic logout.
 *
 * Design matches UI/UX specifications from ABMS-299:
 * - Circular countdown timer showing seconds remaining
 * - Simple message instructing user to close modal to stay signed in
 * - Clean, minimal design with Inter font typography
 * - Close button (X) is the only interaction - closes modal to extend session
 *
 * @example
 * ```tsx
 * <SessionTimeoutWarning
 *   visible={showWarning}
 *   remainingTime={120}
 *   onExtendSession={handleExtendSession}
 *   onLogout={handleLogout}
 * />
 * ```
 */
export const SessionTimeoutWarning: React.FC<SessionTimeoutWarningProps> = ({
  visible,
  remainingTime,
  onExtendSession,
}) => {
  const totalWarningTime = 120; // 2 minutes in seconds

  // Calculate circular progress (0-1 range for stroke-dashoffset)
  const progressPercent = Math.max(0, remainingTime / totalWarningTime);

  // Circle parameters for SVG
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressPercent);

  return (
    <StyledModal
      open={visible}
      title='Session timeout'
      closable={true}
      closeIcon={<CloseOutlined />}
      onCancel={onExtendSession}
      maskClosable={true}
      keyboard={true}
      footer={null}
      width={800}
      centered
    >
      <ContentWrapper>
        <CircularTimer>
          <CircularProgress>
            <CircleBackground cx='80' cy='80' r={radius} />
            <CircleProgress
              cx='80'
              cy='80'
              r={radius}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
            />
          </CircularProgress>
          <TimerText>{remainingTime}s</TimerText>
        </CircularTimer>

        <MessageText>
          You are about to be logged off due to inactivity. Close this modal to
          stay signed in.
        </MessageText>
      </ContentWrapper>
    </StyledModal>
  );
};

export default SessionTimeoutWarning;
