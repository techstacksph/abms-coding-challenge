import React, { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

export const ScrollToTop = () => {
  const topElementRef = useRef<HTMLDivElement>(null);
  const path = useLocation();

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      const rootEl = topElementRef.current;
      const closestScrollable = (rootEl?.closest('.ant-layout-content') ||
        document.querySelector('.ant-layout-content')) as HTMLElement | null;

      if (
        closestScrollable &&
        typeof closestScrollable.scrollTo === 'function'
      ) {
        closestScrollable.scrollTo({ top: 0, left: 0, behavior: 'auto' });
      } else {
        window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
      }
    }, 100);

    return () => clearTimeout(timeoutId);
  }, [path]);

  return (
    <div
      ref={topElementRef}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        height: '1px',
        width: '1px',
        opacity: 0,
        pointerEvents: 'none',
        zIndex: 1000,
      }}
    />
  );
};
