import { Stack } from '@mui/material';

const EmptyTab = () => {
  return <Stack direction='row'>This module is in progress</Stack>;
};

export default EmptyTab;
