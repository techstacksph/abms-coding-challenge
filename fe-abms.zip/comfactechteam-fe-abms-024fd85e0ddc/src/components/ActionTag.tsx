import React, { ReactNode } from 'react';

import { Text, MaterialIcon } from '@/styled-components';
import styled from 'styled-components';

import { Stack } from '@mui/material';

import { Badge, Tag } from 'antd';
import { convertCase } from '@/utils/string.utils';

const StyledBadge = styled(Badge)`
  span {
    width: 8px !important;
    height: 8px !important;
  }
`;

export const StyledTag = styled(Tag)<{ $css?: string }>`
  padding: 4px 8px;
  width: max-content;
  height: 26px;
  border-radius: 6px !important;
  ${({ $css }) => $css}
`;

export const DescriptionTag = ({
  label,
  type = 'xs',
  weight = 'medium',
  height = '16px',
}: {
  label?: string;
  type?: string;
  weight?: string;
  height?: string;
}) => {
  return (
    <StyledTag>
      <Stack
        direction={'row'}
        justifyContent={'center'}
        alignItems={'center'}
        height={height}
      >
        <Text $type={type} weight={weight}>
          {convertCase(label, undefined, true)}
        </Text>
      </Stack>
      {/* {convertCase(type, undefined, true)} */}
    </StyledTag>
  );
};

const ActionTag = ({
  label,
  color,
  variant = 'filled',
  textColor,
}: {
  label?: string | ReactNode;
  color?: string;
  variant?: 'outlined' | 'filled';
  textColor?: string;
}) => {
  return (
    <Stack spacing={color ? 1 : 0} direction='row' alignItems='center'>
      {variant == 'outlined' ? (
        <MaterialIcon
          name='circle'
          $css={`color: ${color}; font-size: 10px;`}
        />
      ) : (
        <StyledBadge color={color} />
      )}
      <Text $css={textColor ? `color: ${textColor};` : undefined}>{label}</Text>
    </Stack>
  );
};

export default ActionTag;
