import React from 'react';

import { useSystemSettings } from '@/mfe-utilities';

import useIdleTimer from '../hooks/useIdleTimer';

const IdleTimer = () => {
  const systemSettings = useSystemSettings();

  const sessionIdleTimeInMin =
    systemSettings?.securityLevel?.configuration?.authentication?.session
      ?.inactivityInMin ?? 240;

  const { idleModalContext } = useIdleTimer({
    sessionIdleTimeInMs: sessionIdleTimeInMin * 60 * 1000,
    modalIdleTimeInMs: 60 * 1000,
    modalConfig: {
      title: 'Session timeout',
      message:
        'You are about to be logged off due to inactivity. Close this modal to stay signed in. ',
    },
  });

  return <>{idleModalContext}</>;
};

export default IdleTimer;
