import React, { ReactNode, useEffect } from 'react';

import {
  useModal,
  ModuleAlert as Alert,
  Button,
  Icon,
  GoogleIcon,
} from '@/styled-components';

import { Stack } from '@mui/material';

export type ModalTypeSelection = 'single' | 'multiple';

export type ModuleRowSelection<T> = {
  selected: Array<T>;
  type?: ModalTypeSelection;
  action?: string;
};

const ModuleAlert = ({
  loading,
  selected,
  onDelete,
  onExport,
  title,
  message,
  onClose,
  modalProps,
  hideDeletePrefix = false,
  modalType = 'warning',
  customDeleteIconName = 'delete',
  hideDividers = false,
  customModalTitle = null,
  submitText = 'Delete',
  hideDelete = false,
}: {
  loading?: boolean;
  hideDividers?: boolean;
  selected: ModuleRowSelection<any>;
  onDelete: any;
  onExport?: () => void;
  title: string | ReactNode;
  message: string | ReactNode;
  onClose?: () => void;
  modalProps?: any;
  hideDeletePrefix?: boolean;
  modalType?: 'warning' | 'info';
  customDeleteIconName?: string;
  customModalTitle?: string;
  submitText?: string;
  hideDelete?: boolean;
}) => {
  const [openModal, closeModal, contextModal] = useModal({
    type: modalType,
    title: hideDeletePrefix
      ? typeof title === 'string'
        ? title
        : 'Delete'
      : customModalTitle
        ? customModalTitle
        : `Delete ${typeof title === 'string' ? title : 'Item'}`,
    message: message,
    onSubmit: async () => {
      if (onDelete) {
        await onDelete();
      }
      closeModal();
    },
    modalProps: {
      submitProps: {
        disabled: loading,
      },
      submitText,
      ...modalProps,
    },
  });

  useEffect(() => {
    if (selected.selected.length == 1 && selected.type == 'single') {
      openModal();
    }
  }, [selected]);

  return (
    <>
      <>{contextModal}</>
      {selected.type == 'multiple' && (
        <Alert
          hideDividers={hideDividers}
          minSelect={1}
          selectedCount={selected.selected.length}
          actions={
            <Stack spacing={2} direction='row'>
              {!hideDelete && (
                <Button
                  ghost
                  $css={`
                    color: #878B97!important;
                    border-color: transparent!important;
                    box-shadow: none!important;
                  `}
                  icon={
                    <Icon>
                      <GoogleIcon name={customDeleteIconName} />
                    </Icon>
                  }
                  onClick={() => openModal()}
                ></Button>
              )}
              <Button
                ghost
                icon={
                  <Icon>
                    <GoogleIcon name='file_download' />
                  </Icon>
                }
                $css='color: #1F272E !important; display: none !important;'
                onClick={() => onExport()}
              >
                Export
              </Button>
            </Stack>
          }
          onClose={onClose}
        />
      )}
    </>
  );
};

export default ModuleAlert;
