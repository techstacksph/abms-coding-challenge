export { RecordLockGuard, useRecordLockGuard } from './RecordLockGuard';
export type { RecordLockGuardProps } from './RecordLockGuard';
