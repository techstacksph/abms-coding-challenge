import React, { ReactNode, useEffect } from 'react';
import { Form } from 'antd';
import { useRecordLockContext } from '@/contexts/RecordLockContext';

export interface RecordLockGuardProps {
  /**
   * Children to render (usually form fields)
   */
  children: ReactNode;

  /**
   * Whether to disable form fields when record is locked by another user
   * Default: true
   */
  disableWhenLocked?: boolean;

  /**
   * Custom component to show when record is locked by another user
   * If not provided, children will be rendered with fields disabled
   */
  lockedComponent?: ReactNode;

  /**
   * Ant Design Form instance (optional)
   * If provided, will disable all form fields automatically
   */
  form?: any;
}

/**
 * Component that guards children based on record lock status
 *
 * Automatically disables form fields when record is locked by another user.
 * Works with both Ant Design forms and regular React components.
 *
 * @example
 * ```tsx
 * // Basic usage - automatically disables children
 * <RecordLockGuard>
 *   <Input name="name" />
 *   <Input name="email" />
 * </RecordLockGuard>
 * ```
 *
 * @example
 * ```tsx
 * // With Ant Design Form - auto-disables all fields
 * const [form] = Form.useForm();
 *
 * <RecordLockGuard form={form}>
 *   <Form.Item name="name">
 *     <Input />
 *   </Form.Item>
 * </RecordLockGuard>
 * ```
 *
 * @example
 * ```tsx
 * // Custom locked state component
 * <RecordLockGuard
 *   lockedComponent={<Alert message="This record is being edited by another user" />}
 * >
 *   <MyFormFields />
 * </RecordLockGuard>
 * ```
 */
export const RecordLockGuard: React.FC<RecordLockGuardProps> = ({
  children,
  disableWhenLocked = true,
  lockedComponent,
  form,
}) => {
  const { canEdit, lockInfo } = useRecordLockContext();

  // Auto-disable Ant Design Form fields when locked
  useEffect(() => {
    if (form && disableWhenLocked) {
      if (!canEdit) {
        // Get all form fields
        const fields = form.getFieldsValue();
        const fieldNames = Object.keys(fields);

        // Disable all fields
        fieldNames.forEach(fieldName => {
          form.setFields([
            {
              name: fieldName,
              errors: [],
            },
          ]);
        });
      }
    }
  }, [canEdit, form, disableWhenLocked]);

  // If record is locked by another user and custom component provided
  if (!canEdit && lockInfo?.isLocked && lockedComponent) {
    return <>{lockedComponent}</>;
  }

  // If record is locked by another user and should disable
  if (!canEdit && lockInfo?.isLocked && disableWhenLocked) {
    // Wrap children with disabled context
    return (
      <fieldset disabled style={{ border: 'none', margin: 0, padding: 0 }}>
        {children}
      </fieldset>
    );
  }

  // Normal rendering when user can edit
  return <>{children}</>;
};

/**
 * Hook to conditionally render based on lock status
 *
 * @example
 * ```tsx
 * const { canEdit } = useRecordLockGuard();
 *
 * return (
 *   <div>
 *     <Input disabled={!canEdit} />
 *     {canEdit && <Button>Save</Button>}
 *   </div>
 * );
 * ```
 */
export const useRecordLockGuard = () => {
  const { canEdit, lockInfo, isLoading } = useRecordLockContext();

  return {
    /**
     * Whether the current user can edit the record
     */
    canEdit,

    /**
     * Whether the record is locked
     */
    isLocked: lockInfo?.isLocked || false,

    /**
     * Whether the current user owns the lock
     */
    isOwnedByCurrentUser: lockInfo?.isOwnedByCurrentUser || false,

    /**
     * Who has the lock (if locked)
     */
    lockedBy: lockInfo?.lockedBy,

    /**
     * Whether lock operation is in progress
     */
    isLoading,

    /**
     * Full lock information
     */
    lockInfo,
  };
};
