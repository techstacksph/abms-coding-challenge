import React, { useEffect, useRef, useState } from 'react';

import {
  ModuleTable as Table,
  Checkbox,
  Icon,
  GoogleIcon,
  Text,
  Select,
  EmptyState,
  MaterialIcon,
} from '@/styled-components';

import usePaginatedQuery from '@/hooks/usePaginatedQuery';
import useQuery from '@/hooks/useQuery';
import { Box, Stack } from '@mui/material';

import { Dropdown } from 'antd';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

export const RowsPerPage = ({ total, range, setPageSize, defaultPageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        value={defaultPageSize}
        options={[
          {
            label: '10',
            value: 10,
          },
          {
            label: '20 ',
            value: 20,
          },
          {
            label: '50',
            value: 50,
          },
          {
            label: '100',
            value: 100,
          },
        ]}
        onChange={val => setPageSize(val)}
        suffixIcon={
          <GoogleIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
          &[class*="-select-focused"] [class*="-select-selector"] {
            box-shadow: none;
          }

          [class$="select-selection-item"] {
            color: var(--color-text-primary) !important;
            font-size: 12px;
            padding-inline-end: 24px !important;
          }
          [class$="select-selector"] {
            gap: 4px;
            padding: 0 4px;
            border-width: 0 !important;
          }
        `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};
//refer task-activityList for proper pagination sync
const AltModuleTable = ({
  columns,
  allQuery = null,
  onChangeSelected,
  searchFields,
  filterFields = [],
  refetch,
  nameField = 'name',
  onTableChange = undefined,
  sortArg,
  paginatedQuery,
  customArgs = {},
  page = 1,
  setPage,
  hasRowSelections = true,
  defaultPageSize = 20,
  onChangePageSize = undefined,
  hideSelectionColumnHeader = false,
  expandable = {},
  transformData = undefined,
  otherTableProps = {},
  loader = false,
  skipQueries = false,
  ...props
}) => {
  const { rowSelection, setAllQueryData } = props as any;
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();
  const [selected, setSelected] = useState([]);
  const [pageSize, setPageSize] = useState<number>(defaultPageSize);
  const currentPageData = useRef([]);

  // Update internal pageSize when defaultPageSize changes from parent
  useEffect(() => {
    setPageSize(defaultPageSize);
  }, [defaultPageSize]);

  let searchArg = [];
  if (searchFields && searchFields != '' && searchFields != null)
    searchArg = searchFields;

  for (const filterArr of filterFields) {
    if (filterArr && filterArr != null) {
      searchArg.push(filterArr);
    }
  }

  const {
    data,
    loading,
    refetch: requery,
  } = usePaginatedQuery({
    query: paginatedQuery,
    options: {
      skip: skipQueries,
      variables: {
        pageArg: {
          skip: (page - 1) * pageSize,
          take: pageSize,
          sort: [
            ...(sortArg || {
              field: nameField,
              direction: 'desc',
            }),
          ],
        },
        searchArg,
        sortArg,
        ...customArgs,
      },
    },
    transformData: data => (transformData ? transformData(data) : data),
  });

  const {
    data: allData,
    loading: allLoading,
    refetch: allRequery,
  } = useQuery<Array<any>>({
    skip: skipQueries,
    query: allQuery,
    options: {
      fetchPolicy: 'no-cache',
      variables: {
        sortArg: [
          ...(sortArg || {
            field: 'updatedAt',
            direction: 'desc',
          }),
        ],
        searchArg,
        ...customArgs,
      },
    },
    transformData: data => (transformData ? transformData(data) : data),
  });

  useEffect(() => {
    if (setAllQueryData) {
      setAllQueryData(allData);
    }
  }, [allData]);

  useEffect(() => {
    if (data?.data.length === 0) {
      const { count } = data.pageInfo;
      const updatedPageNumber = Math.ceil(count / pageSize);

      // SETTING CORRECT PAGE NUMBER (IMPORTANT IN DELETE)
      if (updatedPageNumber > 0) setPage(updatedPageNumber);
    }
  }, [data]);

  // Refetch effect
  useEffect(() => {
    if (refetch?.refetch) {
      if (!skipQueries) {
        requery();
        allRequery();
        onSelectType('deselect');
        onChangeSelected([], selectType);
        setSelected([]);
      }
      refetch?.setRefetch(false);
    }
  }, [refetch?.refetch]);

  // Handle page size changes
  const handlePageSizeChange = newSize => {
    setPageSize(newSize);
    if (onChangePageSize) {
      onChangePageSize(newSize);
    }
    setPage(1); // Reset to page 1 when changing page size
  };

  const onSelectType = async (type: SelectAllMenuTypes) => {
    setSelectType(type);

    let selectId = [];
    if (type === 'this') {
      selectId = data?.data.map((d: any) => d.id);
      onChangeSelected(data?.data, type);
    } else if (type === 'all') {
      selectId = allData ? allData?.map(v => v.id) : [];
      onChangeSelected(allData ?? [], type);
    } else if (type === 'deselect') {
      onChangeSelected([], type);
    }

    setSelected(selectId);
  };

  const customRowSelection = {
    preserveSelectedRowKeys: true,
    columnWidth: 68,
    columnTitle: () => {
      if (rowSelection?.type === 'radio' || hideSelectionColumnHeader) return;

      return (
        <Dropdown
          menu={{
            items: [
              {
                key: 'thisPage',
                label: 'Select this page',
                onClick: () => onSelectType('this'),
              },
              {
                key: 'allPage',
                label: 'Select all page',
                onClick: () => onSelectType('all'),
              },
              {
                key: 'deselectAll',
                label: 'Deselect all',
                onClick: () => onSelectType('deselect'),
              },
            ],
          }}
          trigger={['click']}
        >
          <a role='button'>
            <Stack direction='row' alignItems='center' spacing={0.5}>
              <Checkbox
                checked={Boolean(selectType) && selectType != 'deselect'}
                indeterminate={
                  selectType === 'this' ||
                  (selected.length > 0 &&
                    selected.length !== data?.pageInfo?.count &&
                    selectType != 'all')
                }
                $css={`
                  min-width: 24px !important;
                  height: 24px;
                  justify-content: center;  
                `}
              />
              <Icon color='var(--gray-600)'>
                <MaterialIcon name='arrow_drop_down' />
              </Icon>
            </Stack>
          </a>
        </Dropdown>
      );
    },
    selectedRowKeys: selected,
    onChange: keys => {
      setSelected(keys);
      if (onChangeSelected) {
        const cleanRows = allData.filter(r => keys.includes(r.id));
        onChangeSelected(cleanRows, selectType);
      }
    },
    renderCell: (checked, record, index, originNode) => {
      if (record.isGroupHeader) {
        return { children: null, props: { colSpan: 0 } };
      }
      if (rowSelection?.type === 'radio') return originNode;
      return (
        <Box
          display='flex'
          sx={{
            width: 24,
            height: 24,
            justifyContent: 'center',
          }}
        >
          {originNode}
        </Box>
      );
    },
    getCheckboxProps: record => ({
      disabled: record.isGroupHeader,
      style: record.isGroupHeader ? { display: 'none' } : {},
    }),
  };

  // SET CUSTOM SORT ICON
  columns = columns?.map(column => {
    return column?.sorter
      ? {
          ...column,
          sortIcon: () => (
            <GoogleIcon name='unfold_more' $css={'font-size: inherit;'} />
          ),
        }
      : column;
  });

  return (
    <Table
      columns={columns}
      data={
        transformData ? transformData(data?.data ?? []) : (data?.data ?? [])
      }
      paginationText={'Rows per page'}
      showTotal={false}
      paginationProps={{
        onPageChange: (page, pageSize) => {
          setPage(data?.pageInfo?.pageCount >= page ? page : 1);
          setPageSize(pageSize);
          if (onChangePageSize) {
            onChangePageSize(pageSize);
          }
        },
        showSizeChanger: false,
      }}
      onChange={onTableChange}
      pageInfo={data?.pageInfo}
      onSelectAllMenu={type => setSelectType(type)}
      loading={[loading, allLoading, loader].includes(true)}
      rowSelection={hasRowSelections ? customRowSelection : undefined}
      hidePagination
      onChangePageSize={handlePageSizeChange}
      tableProps={{
        footer: currentPage => {
          currentPageData.current = currentPage;
          return;
        },
        pagination: {
          total: data?.pageInfo?.count,
          showSizeChanger: false,
          position: ['bottom', 'left'],
          pageSize: pageSize,
          current: page,
          showTotal: (total, range) => (
            <RowsPerPage
              total={total}
              range={range}
              setPageSize={handlePageSizeChange}
              defaultPageSize={pageSize}
            />
          ),
          itemRender: (_, type, originalElement) =>
            type === 'page' ? null : originalElement,
        },
        tableLayout: 'fixed',
        expandable,
        ...otherTableProps,
      }}
      emptyState={<EmptyState iconW='200px' title='No data to display.' />}
      {...props}
    />
  );
};

export default AltModuleTable;
