import React from 'react';

import dayjs from 'dayjs';

import { Content } from '@/styled-components';

import InfoField from '@/components/SystemInfoDetails/InfoField';
import ViewModuleSections from '@/components/modules/ViewModuleSections';
import { dateTimeFormat } from '@/utils/date.utils';
import { Stack } from '@mui/material';
import User from '@/models/User';
import { isValueValid } from '@/utils/helper.utils';
import { getFullName } from '@/utils/string.utils';

type SystemInfoDetailsProps = {
  data: any;
  createdBy?: any;
  calledFrom?: string;
  findUserById: (id: string) => User | null;
};

const SystemInfoDetails = ({ data, findUserById }: SystemInfoDetailsProps) => {
  const createdBy = findUserById(data?.createdBy);
  const updatedBy = findUserById(data?.updatedBy);

  return (
    <ViewModuleSections
      title='System information'
      containerProps={{ width: '100%' }}
    >
      <Stack direction='row'>
        <Content style={{ padding: 0, marginRight: '20px' }}>
          <InfoField
            label='Created by'
            value={isValueValid(createdBy) ? getFullName(createdBy) : 'No data'}
            isFirst
          />
          <InfoField
            label='Created at'
            value={dayjs(data?.createdAt).format(dateTimeFormat)}
            isLast
          />
        </Content>

        <Content style={{ padding: 0 }}>
          <InfoField
            label='Updated by'
            value={isValueValid(updatedBy) ? getFullName(updatedBy) : 'No data'}
            isFirst
          />
          <InfoField
            label='Updated at'
            value={
              data?.updatedAt
                ? dayjs(data?.updatedAt).format(dateTimeFormat)
                : ''
            }
            isLast
          />
        </Content>
      </Stack>
    </ViewModuleSections>
  );
};

export default SystemInfoDetails;
