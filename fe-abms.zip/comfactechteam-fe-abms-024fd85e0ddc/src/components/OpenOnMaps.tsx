import React, { useEffect, useRef, useState } from 'react';

import { Text, MaterialIcon, useModal } from '@/styled-components';
import styled from 'styled-components';

// import environment from '@/config/environment';
import { Paper, Stack } from '@mui/material';
import { GoogleMap, Marker } from '@react-google-maps/api';
import { fetchPlaceDetails } from '@/utils/map.utils';

import { Tag } from 'antd';

import GoogleApiLoader from './GoogleApiLoader';
import MiniMapDetail from './SearchMapComponent/MiniMapDetail';
import { GOOGLE_MAP_ZOOM } from '@/enums/google-maps-enum';

const StyledTag = styled(Tag)<{ $css?: string }>`
  & {
    padding: 4px 8px;
    border-radius: 8px;
    width: max-content;
    background: #fff;
  }

  &:hover {
    cursor: pointer;
    background: #f4f4f6;
  }

  ${({ $css }) => $css}
`;

const containerStyle = {
  width: '96.5%',
  minWidth: '950px',
  height: '600px',
};

const mapOptions: google.maps.MapOptions = {
  zoomControl: true,
  mapTypeId: 'roadmap',
};

const OpenOnMaps = ({
  address,
  latitude,
  longitude,
  placeId,
}: {
  address?: string;
  latitude?: string;
  longitude?: string;
  placeId?: string;
}) => {
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [coordinates, setCoordinates] = useState({
    lat: -36.8914076,
    lng: 174.8514328,
  });
  const placesServiceRef = useRef<google.maps.places.PlacesService | null>(
    null
  );
  const [placeDetails, setPlaceDetails] = useState(null);

  const handleMapLoad = (map: google.maps.Map) => {
    placesServiceRef.current = new google.maps.places.PlacesService(map);
  };

  const [openModal, , contextModal] = useModal({
    title: 'View map',
    message: (
      <>
        {placeId ? (
          <Stack position={'relative'}>
            <GoogleApiLoader onLoad={() => setIsLoaded(true)}>
              <GoogleMap
                mapContainerStyle={containerStyle}
                center={coordinates}
                onLoad={handleMapLoad}
                zoom={GOOGLE_MAP_ZOOM}
                options={mapOptions}
              >
                {coordinates && <Marker position={coordinates} />}
              </GoogleMap>
            </GoogleApiLoader>
            <MiniMapDetail detail={placeDetails} coordinates={coordinates} />
          </Stack>
        ) : (
          <Paper
            sx={{
              width: '96.5%',
              minWidth: '950px',
              height: '600px',
              bgcolor: 'var(--gray-100)',
            }}
          />
        )}
      </>
    ),
    modalProps: {
      showFooter: false,
      modalProps: {
        style: {
          minWidth: '1000px',
        },
      },
    },
  });

  const getPlaceDetails = async (lat, lng) => {
    const service = new google.maps.places.PlacesService(
      document.createElement('div')
    );

    const request = {
      location: new google.maps.LatLng(lat, lng),
      radius: 50,
      fields: ['place_id', 'formatted_address', 'name'],
    };

    service.nearbySearch(request, async (results, status) => {
      if (
        status === google.maps.places.PlacesServiceStatus.OK &&
        results.length
      ) {
        try {
          const details = await fetchPlaceDetails({
            placeId: placeId,
            placesServiceRef,
          });
          setPlaceDetails(details);
        } catch (error) {
          console.error('Error fetching place details:', error);
        }
      }
    });
  };

  useEffect(() => {
    if (
      !['', undefined, null].includes(latitude) &&
      !['', undefined, null].includes(longitude) &&
      isLoaded
    ) {
      setCoordinates({
        lat: parseFloat(latitude),
        lng: parseFloat(longitude),
      });
    }
  }, [latitude, longitude, address, isLoaded]);

  useEffect(() => {
    if (isLoaded) {
      getPlaceDetails(coordinates.lat, coordinates.lng);
    }
  }, [isLoaded, coordinates]);

  return (
    <>
      {contextModal}
      <StyledTag
        icon={
          <MaterialIcon
            name='map'
            $css={`
            color: #878B97;
            margin-right: 4px; 
            font-size: 16px
          `}
          />
        }
        onClick={() => openModal()}
      >
        <Text $type='xs' weight='semibold' color='#090A0B'>
          Open on maps
        </Text>
      </StyledTag>
    </>
  );
};

export default OpenOnMaps;
