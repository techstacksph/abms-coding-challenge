import React from 'react';

import { BoxProps, StackProps, Stack, Box } from '@mui/material';

const ActionSplitLayout = ({
  leftPanel,
  rightPanel,
  direction = 'row',
  stackProps = {},
  leftBoxProps = {},
  rightBoxProps = {},
  borderLeft = true,
  borderLeftStyle = '1px solid var(--stroke-outline)',
}: {
  leftPanel: React.ReactNode;
  rightPanel: React.ReactNode;
  direction?: 'row' | 'column' | 'row-reverse' | 'column-reverse';
  stackProps?: StackProps;
  leftBoxProps?: BoxProps;
  rightBoxProps?: BoxProps;
  borderLeft?: boolean;
  borderLeftStyle?: string;
}) => {
  return (
    <Stack direction={direction} {...stackProps}>
      <Box sx={{ flexGrow: 1, flexShrink: 1, minWidth: 0 }} {...leftBoxProps}>
        {leftPanel}
      </Box>

      <Box
        borderLeft={borderLeft ? borderLeftStyle : undefined}
        sx={{
          marginY: '-20px',
          flexShrink: 0,
        }}
      >
        <Box
          paddingTop={'20px'}
          sx={{ flexShrink: 0, width: '200px' }}
          {...rightBoxProps}
        >
          {rightPanel}
        </Box>
      </Box>
    </Stack>
  );
};

export default ActionSplitLayout;
