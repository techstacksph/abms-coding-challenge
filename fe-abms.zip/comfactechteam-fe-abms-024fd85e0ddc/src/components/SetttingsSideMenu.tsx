import { useEffect, useLayoutEffect, useState } from 'react';

import { MaterialIcon } from '@/styled-components';
import { styled } from 'styled-components';

import SettingsRoutes from '@/constants/SettingsRoutes';
import { Menu as TMenu } from '@/constants/SideNavMenuList';
import { eventEmitter } from '@/utils/eventEmitter.utils';
import { Box, Stack, TextField, InputAdornment } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';

import { Layout, Menu } from 'antd';

const { Sider } = Layout;

const StyledMenu = styled(Menu)<{ $css?: string }>`
  border: none !important;

  & li [class*='-menu-item-group-title'] {
    padding: 4px 8px;
    font-size: 12px;
    font-weight: 500;
    color: var(--color-text-tertiary);
  }

  /*
    & ul[class*='-menu-item-group-list'] li {
      border-radius: 8px;
      gap: 4px;
    }
  */

  & li[role='menuitem'] {
    padding: 0 !important;
    padding-left: 8px !important;
  }

  & ul[class='ant-menu-item-group-list'] span[class='ant-menu-title-content'] {
    color: var(--color-text-primary) !important;
  }

  & ul[class='ant-menu-item-group-list'] li:hover {
    background-color: #f0f3ff !important;
  }

  & ul[class='ant-menu-item-group-list'] li:hover * {
    color: var(--color-primary) !important;
  }

  /* MENU ITEM ACTIVE */
  & ul[class='ant-menu-item-group-list'] li[class*='ant-menu-item-selected'] {
    background-color: #f0f3ff;
  }

  & li span[class*='material-symbols-outlined'],
  & li span[class*='material-icons'],
  & li span svg {
    color: #878b97;
  }

  & li[class*='-menu-item-selected'] span[class*='material-symbols-outlined'],
  & li[class*='-menu-item-selected'] span[class*='material-icons'],
  & li[class*='-menu-item-selected'] span svg {
    color: #3137fd;
  }

  &
    ul[class='ant-menu-item-group-list']
    li[class*='ant-menu-item-selected']
    span {
    color: #3137fd;
  }

  li:not([class$='menu-item-selected']) a {
    color: #090a0b !important;
  }

  li[class*='menu-item-selected'] a {
    color: #3137fd !important;
  }

  ${({ $css }) => $css}
`;

const SettingsSideMenu = props => {
  const { sideMenu, defaultMenu, selected, onSelectChange } = props;
  const navigate = useNavigate();
  const location = useLocation();
  const [isSettingsSidebarCollapsed, setIsSettingsSidebarCollapsed] = useState(
    () => {
      const saved = localStorage.getItem('settingsSidebarCollapsed');
      return saved ? JSON.parse(saved) : false;
    }
  );
  const [selectedState, setSelectedState] = useState<string | Array<string>>(
    selected || [defaultMenu]
  );
  const [height, setHeight] = useState<number>(window.innerHeight);
  const [isFormDirty, setIsFormDirty] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Check if this is the settings menu by looking for specific settings menu characteristics
  const isSettingsMenu = sideMenu?.some(
    item =>
      item.key === 'admin-security' ||
      item.children?.some(
        child =>
          child.key === 'Users' ||
          child.key === 'roles' ||
          child.key === 'locations'
      )
  );

  const toggleSettingsSidebar = () => {
    const newState = !isSettingsSidebarCollapsed;
    setIsSettingsSidebarCollapsed(newState);
    localStorage.setItem('settingsSidebarCollapsed', JSON.stringify(newState));
  };

  const handleWindowSizeChange = () => {
    setHeight(window.innerHeight - 10);
  };

  const findSideMenuKey = remainingUrl => {
    let key = null;

    // Collect all searchable items: top-level items without children + children of groups
    const allItems = [];

    sideMenu?.forEach(item => {
      if (item?.children) {
        // Add all children from groups
        item.children.forEach(child => {
          if (child.route) {
            allItems.push(child);
          }
        });
      } else if (item?.route) {
        // Add top-level items without children
        allItems.push(item);
      }
    });

    // Sort by route length (longest first) to match most specific routes first
    const sortedItems = allItems.sort(
      (a, b) => (b.route?.length || 0) - (a.route?.length || 0)
    );

    // Helper function to normalize routes by removing trailing slashes
    const normalizeRoute = route => route.replace(/\/$/, '');

    // Find the matching item - check if current path starts with the normalized route
    key = sortedItems.find(item => {
      if (!item.route) return false;
      const normalizedItemRoute = normalizeRoute(item.route);
      const normalizedCurrentUrl = normalizeRoute(remainingUrl);
      return normalizedCurrentUrl.startsWith(normalizedItemRoute);
    })?.key;

    return key;
  };

  useLayoutEffect(() => {
    window.addEventListener('resize', handleWindowSizeChange);
    return () => {
      window.removeEventListener('resize', handleWindowSizeChange);
    };
  }, []);

  useEffect(() => {
    // Only update based on URL if no explicit selection is provided
    if (!selected) {
      // Use location.pathname instead of parsing URL
      const currentPath = location.pathname;

      if (
        typeof selectedState == 'object' &&
        ['', undefined, null].includes(selectedState[0])
      ) {
        const result = findSideMenuKey(currentPath);
        if (!['', undefined, null].includes(result)) {
          setSelectedState(result);
        }
      } else {
        const result = findSideMenuKey(currentPath);
        if (!['', undefined, null].includes(result)) {
          setSelectedState(result);
        }
      }
    }
  }, [location.pathname, selected]);

  // Update selectedState when selected prop changes
  useEffect(() => {
    if (selected) {
      setSelectedState(selected);
    }
  }, [selected]);

  useEffect(() => {
    const handleFormDirtyChange = event => {
      setIsFormDirty(event.detail);
    };
    eventEmitter.addEventListener('formDirtyChange', handleFormDirtyChange);
    return () => {
      eventEmitter.removeEventListener(
        'formDirtyChange',
        handleFormDirtyChange
      );
    };
  }, []);

  const findMenuItemByKey = key => {
    let menuItem = null;
    sideMenu.forEach((_, idx) => {
      const sideMenuItems = sideMenu[idx]?.children || sideMenu[idx];

      // MENU ITEMS ARE GROUPED IF sideMenuItems IS AN ARRAY (children ARRAY)
      const item = Array.isArray(sideMenuItems)
        ? sideMenuItems.find(item => item.key === key)
        : sideMenuItems.key === key
          ? sideMenuItems
          : undefined;

      if (item && item != null) {
        menuItem = item;
      }
    });
    return menuItem;
  };

  const handleMenuItemClick = key => {
    const menuItem = findMenuItemByKey(key);

    if (
      location?.pathname === `${SettingsRoutes?.CompanySettings?.list}/edit` &&
      isFormDirty
    ) {
      eventEmitter.dispatchEvent(new CustomEvent('moveAway', { detail: true }));
    } else if (menuItem && menuItem.route) {
      if (onSelectChange) onSelectChange(key);
      navigate(menuItem.route);
    }
  };

  const filterMenuItems = (items: TMenu[], query: string): TMenu[] => {
    if (!query.trim()) return items;

    return items
      .map(group => {
        if (group.children) {
          const filteredChildren = group.children.filter(child => {
            const label =
              typeof child.label === 'string' ? child.label : child.key;
            const matchesSearch = label
              .toLowerCase()
              .includes(query.toLowerCase());
            const isCurrentlySelected = Array.isArray(selectedState)
              ? selectedState.includes(child.key)
              : selectedState === child.key;

            return matchesSearch || isCurrentlySelected;
          });

          if (filteredChildren.length > 0) {
            return { ...group, children: filteredChildren };
          }
          return null;
        }

        const label = typeof group.label === 'string' ? group.label : group.key;
        const matchesSearch = label.toLowerCase().includes(query.toLowerCase());
        const isCurrentlySelected = Array.isArray(selectedState)
          ? selectedState.includes(group.key)
          : selectedState === group.key;

        return matchesSearch || isCurrentlySelected ? group : null;
      })
      .filter(Boolean) as TMenu[];
  };

  const filteredSideMenu = isSettingsMenu
    ? filterMenuItems(sideMenu, searchQuery)
    : sideMenu;

  return (
    <Sider
      width={isSettingsSidebarCollapsed ? '80px' : '250px'}
      style={{
        background: '#fff',
        borderRight: '1px solid #D3D5D9',
        transition: 'width 0.3s ease',
      }}
    >
      <Box
        width={isSettingsSidebarCollapsed ? 80 : 256}
        height={height}
        p={isSettingsSidebarCollapsed ? 1 : 2.5}
        bgcolor='#fff'
        borderRight='1px solid #D3D5D9'
        sx={{
          overflowX: 'hidden',
          overflowY: 'scroll',
          scrollbarWidth: 'thin',
          scrollbarGutter: 'stable',
          scrollbarColor: '#D3D5D9 white',
          transition: 'all 0.3s ease',
        }}
      >
        <Stack>
          {isSettingsMenu && (
            <>
              {!isSettingsSidebarCollapsed ? (
                <Box sx={{ p: 1, mb: 1 }}>
                  <TextField
                    size='small'
                    placeholder='Search settings'
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position='start'>
                          <MaterialIcon
                            name='search'
                            $css='color: #878B97; font-size: 20px;'
                          />
                        </InputAdornment>
                      ),
                      endAdornment: searchQuery && (
                        <InputAdornment position='end'>
                          <div
                            onClick={() => setSearchQuery('')}
                            style={{
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              padding: '2px',
                              borderRadius: '4px',
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.backgroundColor = '#f0f3ff';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.backgroundColor =
                                'transparent';
                            }}
                          >
                            <MaterialIcon
                              name='close'
                              $css='color: #878B97; font-size: 20px; &:hover { color: #3137fd; }'
                            />
                          </div>
                        </InputAdornment>
                      ),
                      sx: {
                        borderRadius: '8px',
                        backgroundColor: '#f5f5f5',
                        '& .MuiOutlinedInput-notchedOutline': {
                          border: 'none',
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          border: 'none',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          border: '1px solid #3137fd',
                        },
                      },
                    }}
                  />
                </Box>
              ) : (
                <>
                  <Box
                    sx={{
                      p: 1,
                      mb: 1,
                      display: 'flex',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      borderRadius: '8px',
                      '&:hover': {
                        backgroundColor: '#f0f3ff',
                      },
                    }}
                    onClick={() => {
                      setIsSettingsSidebarCollapsed(false);
                      localStorage.setItem(
                        'settingsSidebarCollapsed',
                        JSON.stringify(false)
                      );
                    }}
                    title='Search settings'
                  >
                    <MaterialIcon
                      name='search'
                      $css='color: #878B97; font-size: 24px; &:hover { color: #3137fd; }'
                    />
                  </Box>
                  <Box
                    sx={{
                      width: '100%',
                      height: '1px',
                      backgroundColor: '#D3D5D9',
                      mb: 1,
                      mx: 1,
                    }}
                  />
                </>
              )}
            </>
          )}
          <StyledMenu
            theme='light'
            mode='inline'
            defaultSelectedKeys={selected || [defaultMenu]}
            selectedKeys={selectedState as Array<string>}
            inlineCollapsed={isSettingsSidebarCollapsed}
            items={filteredSideMenu.map((s: TMenu) => ({
              ...s,
              children: s.children?.map(c => ({
                ...c,
                label: isSettingsSidebarCollapsed ? null : (
                  <a
                    style={{
                      all: 'unset',
                    }}
                    href={c.route}
                    onClick={e => {
                      e.preventDefault(); // Prevent default navigation
                      handleMenuItemClick(c.key);
                    }}
                    onContextMenu={() => {
                      // Allow default browser context menu to appear
                      // The browser will show "Open in new tab" option
                    }}
                  >
                    {c.label}
                  </a>
                ),
                title: isSettingsSidebarCollapsed ? c.label : undefined,
              })),
              label: isSettingsSidebarCollapsed ? null : (
                <a
                  style={{
                    all: 'unset',
                  }}
                  href={s.route}
                  onClick={e => {
                    e.preventDefault(); // Prevent default navigation
                    handleMenuItemClick(s.key);
                  }}
                  onContextMenu={() => {
                    // Allow default browser context menu to appear
                    // The browser will show "Open in new tab" option
                  }}
                >
                  {s.label}
                </a>
              ),
              title: isSettingsSidebarCollapsed ? s.label : undefined,
            }))}
            onClick={({ key }) => {
              let menuItem = null;
              sideMenu.forEach((_, idx) => {
                const sideMenuItems = sideMenu[idx]?.children || sideMenu[idx];

                // MENU ITEMS ARE GROUPED IF sideMenuItems IS AN ARRAY (children ARRAY)
                const item = Array.isArray(sideMenuItems)
                  ? sideMenuItems.find(
                      item => item.key === key

                      // IF NOT GROUPED, JUST COMPARE KEY IF EQUAL
                    )
                  : sideMenuItems.key === key
                    ? sideMenuItems
                    : undefined;

                if (item && item != null) {
                  menuItem = item;
                }
              });
              if (
                location?.pathname ===
                  `${SettingsRoutes?.CompanySettings?.list}/edit` &&
                isFormDirty
              ) {
                eventEmitter.dispatchEvent(
                  new CustomEvent('moveAway', { detail: true })
                );
              } else if (menuItem && menuItem.route) {
                if (onSelectChange) onSelectChange(key);
                navigate(menuItem.route);
              }
            }}
            onSelect={select => {
              if (select.keyPath.length > 1) {
                setSelectedState(select.keyPath);
                if (onSelectChange) onSelectChange(select.keyPath[0]);
                return;
              }
              setSelectedState(select.keyPath[0]);
              if (onSelectChange) onSelectChange(select.keyPath[0]);
            }}
          />
        </Stack>
        {!isSettingsSidebarCollapsed && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: '244px',
            }}
          >
            <Box
              height='39px'
              sx={{ position: 'relative', width: 'fit-content' }}
            >
              <div
                onClick={toggleSettingsSidebar}
                style={{
                  position: 'absolute',
                  bottom: 0,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '24px',
                  height: '24px',
                  background: '#fff',
                  boxShadow: '0px 4px 20px 0px #192A421A',
                  borderRadius: '12px',
                  zIndex: 1000,
                  border: 'none',
                  outline: 'none',
                  userSelect: 'none',
                }}
              >
                <MaterialIcon
                  name='chevron_left'
                  $css={`
                    color: #878B97;
                    transition: color 0.3s ease;

                    &:hover {
                      color: #3137fd;
                    }
                  `}
                />
              </div>
            </Box>
          </Box>
        )}
        {isSettingsSidebarCollapsed && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: '64px',
            }}
          >
            <Box
              height='39px'
              sx={{ position: 'relative', width: 'fit-content' }}
            >
              <div
                onClick={toggleSettingsSidebar}
                style={{
                  position: 'absolute',
                  bottom: 0,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '24px',
                  height: '24px',
                  background: '#fff',
                  boxShadow: '0px 4px 20px 0px #192A421A',
                  borderRadius: '12px',
                  zIndex: 1000,
                  border: 'none',
                  outline: 'none',
                  userSelect: 'none',
                }}
              >
                <MaterialIcon
                  name='chevron_right'
                  $css={`
                    color: #878B97;
                    transition: color 0.3s ease;

                    &:hover {
                      color: #3137fd;
                    }
                  `}
                />
              </div>
            </Box>
          </Box>
        )}
      </Box>
    </Sider>
  );
};
export default SettingsSideMenu;
