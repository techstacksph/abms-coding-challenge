import React from 'react';

import { Text } from '@/styled-components';

import { Badge, BadgeProps } from 'antd';

function StatusIndicator({
  status,
  title,
  style,
  labelcss = '',
  customBadge = null,
}: BadgeProps & {
  labelcss?: string;
  status?: 'default' | 'success' | 'processing' | 'error' | 'warning';
  customBadge?: React.ReactNode;
}) {
  return (
    <div
      style={{
        border: '1px solid rgb(211, 213, 217)',
        padding: '4px 8px',
        borderRadius: '100px',
        display: 'flex',
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: 'fit-content',
        ...style,
      }}
    >
      {customBadge}
      {status && <Badge status={status} />}
      <Text $css={`margin-left:4px;${labelcss}`}>{title}</Text>
    </div>
  );
}

export default StatusIndicator;
