import React, { ReactNode } from 'react';

import { Text, Divider } from '@/styled-components';

import { Stack, Box } from '@mui/material';

const ViewModuleSections = ({
  title,
  children,
}: {
  title: string | ReactNode;
  children: ReactNode;
}) => {
  return (
    <Stack>
      <Box>
        <Text $type='md' weight='medium'>
          {title}
        </Text>
        <Divider $css='margin-block: 20px;' />
      </Box>
      {children}
    </Stack>
  );
};

export default ViewModuleSections;
