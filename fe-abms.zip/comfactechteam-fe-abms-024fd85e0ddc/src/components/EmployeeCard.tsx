import React from 'react';

import { GoogleIcon, Icon, Text } from '@/styled-components';

import Link from '@/components/Link';
import { getViewRoute } from '@/mfe-utilities';
import EmployeeModel from '@/models/EmployeeModel';
import CloseIcon from '@mui/icons-material/Close';
import { Stack, Box } from '@mui/material';

import { FormInstance } from 'antd';

const EmployeeCard = ({
  record,
  form,
  fieldName,
  onEmpty = 'No selected employee.',
  boxWidth = '55%',
  basicTitle = false,
}: {
  record: Array<EmployeeModel>;
  form?: FormInstance;
  fieldName: string;
  onEmpty?: string;
  boxWidth?: string;
  basicTitle?: boolean;
}) => {
  if (!form) {
    boxWidth = '100%';
  }
  const data: EmployeeModel | null = record.length > 0 ? record[0] : null;

  const getEmployeeName = () => {
    if (data?.fullName) return data.fullName;
    return `${data?.firstName ?? ''} ${data?.lastName ?? ''}`.trim();
  };

  return (
    <>
      <Stack
        justifyContent='space-between'
        sx={{ marginTop: '0px !important' }}
      >
        <Box sx={{ width: boxWidth }}>
          <Stack direction='row' spacing={1}>
            {record.length > 0 ? (
              <Stack
                direction={'row'}
                gap='4px'
                padding={1}
                width='100%'
                sx={{
                  ':hover': {
                    borderRadius: '8px',
                    backgroundColor: form ? '#F4F4F6' : 'transparent',
                  },
                }}
              >
                <Icon size='28px' color='var(--gray-400)'>
                  <GoogleIcon
                    name='person'
                    fill={true}
                    $css={`
                      padding: 8px;
                      font-size: 28px !important;
                      background-color: #F4F4F6;
                      border-radius: 50%;
                    `}
                  />
                </Icon>
                <Stack
                  direction='column'
                  spacing={'4px'}
                  sx={{ width: '100%' }}
                >
                  {basicTitle ? (
                    <Text
                      $type='sm'
                      $css={'font-size: 14px; font-weight: 700;'}
                    >
                      {getEmployeeName()}
                    </Text>
                  ) : (
                    <Link
                      ellipsis
                      to={`${getViewRoute('Employees')}/${data?.id}`}
                      weight='bold'
                      $css={{ maxWidth: '240px !important' }}
                    >
                      {getEmployeeName()}
                    </Link>
                  )}
                  {data?.email && (
                    <Text
                      $type='sm'
                      $css={'font-size: 14px; font-weight: 400;'}
                    >
                      {data.email}
                    </Text>
                  )}
                  {data?.location?.name && (
                    <Text
                      $type='sm'
                      $css={'font-size: 14px; font-weight: 400; color:#686D78'}
                    >
                      {data.location.name}
                    </Text>
                  )}
                </Stack>
                {form && (
                  <CloseIcon
                    className='userRemove'
                    onClick={() => {
                      form.setFieldValue(fieldName, null);
                    }}
                    sx={{ color: '#878B97', width: '20px', height: '20px' }}
                  />
                )}
              </Stack>
            ) : (
              <Text
                style={{
                  textAlign: 'center',
                  width: '100%',
                  padding: '16px',
                  color: '#686D78',
                }}
              >
                {onEmpty}
              </Text>
            )}
          </Stack>
        </Box>
      </Stack>
    </>
  );
};

export default EmployeeCard;
