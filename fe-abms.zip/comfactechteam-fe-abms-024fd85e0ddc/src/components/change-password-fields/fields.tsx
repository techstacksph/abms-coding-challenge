import { InputField } from '@/styled-components/types/input.types';

import SystemSettings from '../../models/SystemSettings';
import { containsConsectiveSequence } from '../../utils/string.utils';

export const newPasswordRuleList = (
  newPassword: string,
  systemSettings: Partial<SystemSettings>
) => {
  const passwordPolicy =
    systemSettings?.securityLevel?.configuration?.authentication?.password;

  const minPasswordLength = passwordPolicy?.minPasswordLength ?? 6;

  const newPasswordRuleList = [
    {
      text: `Must be at least ${minPasswordLength} characters`,
      condition: newPassword && newPassword?.length >= minPasswordLength,
      useRule: true,
    },
    {
      text: 'Must contain least 1 uppercase letter (A, B, C...)',
      condition: newPassword && /[A-Z]/.test(newPassword),
      useRule: passwordPolicy?.requireUppercaseCharacter ?? true,
    },
    {
      text: 'Must contain least 1 lowercase letter (a, b, c...)',
      condition: newPassword && /[a-z]/.test(newPassword),
      useRule: passwordPolicy?.requireLowercaseCharacter ?? true,
    },
    {
      text: 'Must contain atleast 1 number (1, 2, 3...)',
      condition: newPassword && /[0-9]/.test(newPassword),
      useRule: passwordPolicy?.requireNumber ?? true,
    },
    {
      text: 'Must contain atleast 1 special character ($, @, &...)',
      condition:
        newPassword &&
        // eslint-disable-next-line no-useless-escape
        /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/.test(newPassword),
      useRule: passwordPolicy?.requireSpecialCharacter ?? true,
    },
    {
      text: 'Must NOT contain sequential letters and numbers (abcd, 1234)',
      condition: newPassword && !containsConsectiveSequence(newPassword),
      useRule:
        passwordPolicy?.allowSequentialCharacters !== undefined
          ? !passwordPolicy.allowSequentialCharacters
          : true,
    },
  ];

  return newPasswordRuleList
    .map(rule => {
      if (rule.useRule) {
        return {
          text: rule.text,
          condition: rule.condition,
        };
      }
    })
    .filter(res => res);
};

export const newPasswordField: InputField = {
  title: 'New password',
  field: 'newPassword',
  type: 'password',
  rules: [
    { required: true, message: 'Please enter your new password' },
    {
      min: 8,
      message: 'Must be at least 8 characters',
    },
    {
      pattern: new RegExp(/^(?=.*[A-Z])(?=.*\d)/g),
      message: 'Incorrect format',
    },
    {
      // eslint-disable-next-line no-useless-escape
      pattern: new RegExp(/[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/),
      message: 'Must contain least 1 special character ($, @, %...)',
    },
    () => ({
      validator(_, value) {
        if (!containsConsectiveSequence(value)) {
          return Promise.resolve();
        }
        return Promise.reject(
          new Error(
            'Must not contain sequential letters and numbers (abcd, 1234)'
          )
        );
      },
    }),
  ],
  props: {
    labelCol: {
      span: 24,
    },
  },
};

export const cofirmNewPasswordField: InputField = {
  title: 'Confirm new password',
  field: 'confirmNewPassword',
  type: 'password',
  props: {
    labelCol: {
      span: 24,
    },
  },
  dependencies: ['newPassword'],
  rules: [
    {
      required: true,
      message: 'Please confirm your new password',
    },
    ({ getFieldValue }) => ({
      validator(_, value) {
        if (!value || getFieldValue('newPassword') === value) {
          return Promise.resolve();
        }
        return Promise.reject(new Error('Password does not match'));
      },
    }),
  ],
};
