import { ReactNode } from 'react';

import { Link as StyledLink } from '@/styled-components';

import { Link as RouterLink } from 'react-router-dom';

const Link = ({
  to,
  children,
  ellipsis,
  weight,
  $css,
  states,
}: {
  to: string;
  children: ReactNode;
  ellipsis?: boolean;
  weight?: string;
  $css?: any;
  states?: any;
}) => {
  return (
    <RouterLink
      to={to}
      style={{ color: 'inherit', textDecoration: 'none' }}
      state={{ back: location.pathname ?? '../', ...states }}
    >
      <StyledLink ellipsis={ellipsis} weight={weight} $css={$css}>
        {children}
      </StyledLink>
    </RouterLink>
  );
};
export default Link;
