import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

/**
 * Component that automatically redirects URLs with trailing slashes to clean URLs
 * This prevents issues with double slashes when constructing edit/view URLs
 *
 * Preserves query parameters and hash fragments during redirect to ensure
 * password reset links and other parameterized routes work correctly
 *
 * Based on the solution from: https://jasonwatmore.com/post/2020/03/23/react-router-remove-trailing-slash-from-urls
 * Adapted for React Router v6
 */
const TrailingSlashRedirect: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const { pathname, search, hash } = location;

    // Check if the current path has a trailing slash (excluding root path)
    if (pathname !== '/' && pathname.endsWith('/')) {
      // Remove the trailing slash and redirect while preserving query params and hash
      const cleanPath = pathname.slice(0, -1);
      navigate(
        {
          pathname: cleanPath,
          search: search, // Preserve query parameters
          hash: hash, // Preserve hash
        },
        { replace: true }
      );
    }
  }, [location.pathname, location.search, location.hash, navigate]);

  // This component doesn't render anything
  return null;
};

export default TrailingSlashRedirect;
