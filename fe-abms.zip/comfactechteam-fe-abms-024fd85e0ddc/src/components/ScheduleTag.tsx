import React from 'react';

import { StatusTag as BaseStatusTag } from '@/styled-components';

import { Status } from '@/constants/Status';

const ScheduleTag = ({ status = Status.ACTIVE }: { status: Status }) => {
  let color;
  switch (status?.toUpperCase()) {
    case Status.COMPLETED:
    case Status.ACTIVE:
      color = '#31D48B';
      break;
    case Status.INACTIVE:
    case Status.OPEN:
      color = 'var(--gray-400)';
      break;
    case Status.CANCELLED:
      color = '#EA3927';
      break;
    default:
      color = '#586C7F';
      break;
  }

  return (
    <BaseStatusTag
      $css={'text-transform: capitalize;'}
      color={color}
      label={status.toLowerCase()}
    />
  );
};

export default ScheduleTag;
