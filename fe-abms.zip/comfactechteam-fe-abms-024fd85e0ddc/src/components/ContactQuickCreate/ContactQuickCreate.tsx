import {
  FormSection,
  Button,
  Icon,
  MaterialIcon,
  Form,
  useModal,
  useSnackbar,
} from '@/styled-components';

import FormButtons from '@/components/FormButtons';
import environment from '@/config/environment';
import { CREATE_CONTACT_ACCOUNTS } from '@/graphql/contactAccount.gql';
import { CREATE_CONTACTS } from '@/graphql/contacts.gql';
import { GET_WORKFLOW_STATUS } from '@/graphql/module.gql';
import useMutation from '@/hooks/useMutation';
import useQuery from '@/hooks/useQuery';
import ContactModel from '@/models/ContactModel';
import WorkflowStatusModel from '@/models/WorkflowStatusModel';
import { Box } from '@mui/material';
import { graphQLErrorsMessage } from '@/services/errors.service';

import { FormInstance, Form as AntdForm, Spin } from 'antd';

import { emailField, fields } from './fields';

const { TENANT_PREFIX } = environment;

const ContactQuickCreate = ({
  parentForm,
  $css = '',
  iconSize = '24px',
}: {
  parentForm: FormInstance;
  $css?: string;
  iconSize?: string;
}) => {
  const [form] = AntdForm.useForm();
  const { snackbar } = useSnackbar();
  const [createContact, { loading: contactLoading }] =
    useMutation<ContactModel>({
      query: CREATE_CONTACTS,
      successMessage: 'Contact created successfully.',
      onError: error => {
        const message = graphQLErrorsMessage(error);
        snackbar({ type: 'error', message: 'Contact ' + message });
      },
    });

  const onFinish = async values => {
    try {
      const response = await createContact({
        variables: {
          contact: {
            ...values,
            statusId: data.find(d => d.name === 'Active').id,
          },
        },
      });
      const id = response.data?.[`${TENANT_PREFIX}createContact`]?.id;
      if (id) {
        parentForm.setFieldValue('quickContact', {
          ...values,
          id: id,
          statusId: data.find(d => d.name === 'Active').id,
        });
        parentForm.setFieldValue('primaryContactId', id);
        closeModal();
      }
    } catch {
      // Handle error if needed
    }
  };

  const { data } = useQuery<Array<WorkflowStatusModel>>({
    query: GET_WORKFLOW_STATUS,
    options: {
      variables: {
        code: 'contact',
      },
    },
  });

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New contact',
    message: (
      <Box sx={{ button: { width: 120 } }}>
        <Spin spinning={contactLoading}>
          <Form onFinish={onFinish} form={form}>
            <FormSection
              fields={fields()}
              fieldRowGutter={[16, 16]}
              rowGutter={16}
              row={2}
              col={2}
            />
            <FormSection fields={emailField} rowGutter={16} />
            <FormButtons
              type='header'
              onBackClick={() => {
                form.resetFields();
                // Clear all form field errors
                const currentFields = form.getFieldsValue();
                if (currentFields && typeof currentFields === 'object') {
                  form.setFields(
                    Object.keys(currentFields).map(fieldName => ({
                      name: fieldName,
                      errors: [],
                    }))
                  );
                }
                closeModal();
              }}
              cancelButtonCss='font-weight: 500; border-color: #BEC0C6 !important;'
              saveButtonCss='font-weight: 500;'
              saveBtnText='Save'
            />
          </Form>
        </Spin>
      </Box>
    ),
    gutter: 0,
    modalProps: {
      modalProps: {
        style: {
          // Custom styles can be added here if needed
        },
        footer: null,
        onCancel: () => {
          form.resetFields();
          // Clear all form field errors
          const currentFields = form.getFieldsValue();
          if (currentFields && typeof currentFields === 'object') {
            form.setFields(
              Object.keys(currentFields).map(fieldName => ({
                name: fieldName,
                errors: [],
              }))
            );
          }
          closeModal();
        },
      },
      // submitProps: {
      //   disabled: false,
      //   style: {
      //     background: '#3137FD',
      //     fontWeight: 500,
      //   },
      // },
      // cancelProps: {
      //   style: {
      //     color: '#686D78 !important',
      //     fontWeight: 500,
      //   },
      // },
      submitText: 'Save',
    },
  });

  return (
    <>
      {contextModal}
      <Button
        ghost
        icon={
          <Icon size={iconSize} $css='rotate: -90deg;'>
            <MaterialIcon iconClass='material-icons' name='add' />
          </Icon>
        }
        $css={`
          margin-top: 27px;
          margin-left: 15px;
          color: rgba(49, 55, 253, 1) !important;
          background-color: #FFFFFF !important;
          width: 40px !important;
          height: 40px !important;
          border-color: rgba(49, 55, 253, 1) !important;
          padding: 0 !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          min-width: 40px !important;
          box-sizing: border-box !important;

          ${$css}
        `}
        onClick={() => {
          form.resetFields();
          // Clear all form field errors
          const currentFields = form.getFieldsValue();
          if (currentFields && typeof currentFields === 'object') {
            form.setFields(
              Object.keys(currentFields).map(fieldName => ({
                name: fieldName,
                errors: [],
              }))
            );
          }
          setTimeout(() => {
            openModal();
          }, 50);
        }}
      />
    </>
  );
};

export default ContactQuickCreate;

export const ContactQuickCreateNew = ({
  handleSuccess,
  accountId,
  siteId,
  iconSize = '24px',
  $sx = {},
}: {
  handleSuccess?: (val) => void;
  accountId?: string;
  siteId?: string;
  iconSize?: string;
  $sx?: React.CSSProperties;
}) => {
  const [form] = AntdForm.useForm();
  const { snackbar } = useSnackbar();
  const { data: status } = useQuery<Array<WorkflowStatusModel>>({
    query: GET_WORKFLOW_STATUS,
    options: {
      variables: {
        code: 'contact',
      },
    },
  });
  const active = status && status?.filter(s => s.name === 'Active')?.[0];

  // Complete cleanup function
  const performCompleteCleanup = () => {
    // Reset form completely
    form.resetFields();

    // Clear all form field errors
    const currentFields = form.getFieldsValue();
    if (currentFields && typeof currentFields === 'object') {
      form.setFields(
        Object.keys(currentFields).map(fieldName => ({
          name: fieldName,
          errors: [],
        }))
      );
    }
  };

  const [createContactAccounts] = useMutation({
    query: CREATE_CONTACT_ACCOUNTS,
    disableAlert: true,
  });

  const [createContact, { loading: contactLoading }] = useMutation({
    query: CREATE_CONTACTS,
    successMessage: 'Contact successfully created.',
    disableAlert: true,
    onSuccess: async (value: ContactModel) => {
      try {
        if (accountId && value?.id) {
          await createContactAccounts({
            variables: {
              contactAccounts: [
                {
                  accountId: accountId,
                  contactId: value.id,
                },
              ],
            },
          });
        }

        snackbar({
          type: 'success',
          message: `${value.firstName} ${value.lastName} successfully created.`,
        });

        handleSuccess(value);
        performCompleteCleanup();
        closeModal();
      } catch (error) {
        console.error('Error creating contact account relationship:', error);
        // Still call handleSuccess since the contact was created successfully
        handleSuccess(value);
        performCompleteCleanup();
        closeModal();
      }
    },
    onError: err => {
      // Failed on BE validation
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      const field = graphQLError?.extensions.field;

      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        // Comprehensive field mapping for contact fields with case insensitive handling
        const fieldMapping = {
          // Contact details - handle various case variations
          firstName: 'firstName',
          first_name: 'firstName',
          firstname: 'firstName',
          lastName: 'lastName',
          last_name: 'lastName',
          lastname: 'lastName',
          fullName: 'fullName',
          full_name: 'fullName',
          fullname: 'fullName',
          email: 'email',
          emailAddress: 'email',
          email_address: 'email',
          phone: 'phone',
          phoneNumber: 'phone',
          phone_number: 'phone',
          mobile: 'mobile',
          mobileNumber: 'mobile',
          mobile_number: 'mobile',
        };

        const formFieldName = fieldMapping[field] || field || 'firstName';
        const fieldValue = form.getFieldValue(formFieldName) || 'This value';

        form.setFields([
          {
            name: formFieldName,
            errors: [
              `${fieldValue} already exists. This field must be unique.`,
            ],
          },
        ]);

        // Show standard error message used throughout the app
        snackbar({
          type: 'error',
          message: 'Error: Invalid data.',
        });
      } else {
        // Handle other types of errors - use standard error message
        const fieldName = field || 'firstName';
        const fieldValue = form.getFieldValue(fieldName) || 'This value';

        form.setFields([
          {
            name: fieldName,
            errors: [
              `${fieldValue} already exists. This field must be unique.`,
            ],
          },
        ]);

        // Use standard error message consistent with other modules
        snackbar({
          type: 'error',
          message: 'Error: Invalid data.',
        });
      }
      return;
    },
  });

  const onFinish = async values => {
    const cleanedValues = { ...values };

    // cleanedValues['fullName'] = `${cleanedValues?.firstName || ''} ${
    //   cleanedValues?.lastName || ''
    // }`.trim();

    // Handle phone field
    cleanedValues['phone'] = cleanedValues['phone']
      ? String(cleanedValues['phone']).trim()
      : null;

    // Handle mobile field - extract the actual number from phone component
    if (cleanedValues['mobile']) {
      const mobileStr = String(cleanedValues['mobile']);
      const mobileParts = mobileStr.split(' ');
      if (mobileParts.length > 1) {
        cleanedValues['mobile'] = mobileParts.slice(1).join('').trim() || null;
      } else {
        cleanedValues['mobile'] = mobileStr.trim() || null;
      }
    } else {
      cleanedValues['mobile'] = null;
    }

    // Set status
    cleanedValues['statusId'] = active.id;

    // Link contact to site if siteId is provided
    if (siteId) {
      cleanedValues['siteId'] = siteId;
    }
    const email = cleanedValues['email'];
    if (email) {
      const trimmedEmail = email.trim();
      if (trimmedEmail) {
        cleanedValues['email'] = trimmedEmail.toLowerCase();
      } else {
        cleanedValues['email'] = null;
      }
    }
    await createContact({
      variables: {
        contact: cleanedValues,
      },
    });
  };

  const onFinishFailed = errorInfo => {
    const isRequiredError =
      errorInfo?.errorFields?.findIndex(
        errorField =>
          errorField?.errors?.findIndex(error => error?.includes('required')) >
          -1
      ) > -1;

    if (isRequiredError) {
      return snackbar({
        type: 'error',
        message: 'Missing required field(s).',
      });
    }

    snackbar({
      type: 'error',
      message: 'Error: Invalid data.',
    });
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New contact',
    message: (
      <Box sx={{ button: { width: 120 } }}>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFinishFailed}>
          <FormSection fields={fields()} row={2} col={2} rowGutter={16} />
          <FormSection fields={emailField} />
          <FormButtons
            type='header'
            onBackClick={() => {
              performCompleteCleanup();
              closeModal();
            }}
            cancelButtonCss='font-weight: 500; border-color: #BEC0C6 !important;'
            saveButtonCss='font-weight: 500;'
            saveBtnText='Save'
            saveButtonProps={{
              loading: contactLoading,
            }}
          />
        </Form>
      </Box>
    ),
    gutter: 0,
    modalProps: {
      modalProps: {
        footer: null,
        style: {
          // Custom styles can be added here if needed
        },
        onCancel: () => {
          performCompleteCleanup();
          closeModal();
        },
      },
    },
  });

  return (
    <>
      {contextModal}
      <Box
        sx={{
          color: 'rgba(49, 55, 253, 1)',
          backgroundColor: '#FFFFFF',
          width: '40px',
          height: '40px',
          border: '1px solid rgba(49, 55, 253, 1)',
          padding: '8px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: '8px',
          marginTop: '12px',
          marginLeft: '15px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
            cursor: 'pointer',
          },
          ...$sx,
        }}
        onClick={() => {
          performCompleteCleanup();
          setTimeout(() => {
            openModal();
          }, 50);
        }}
      >
        <Icon size={iconSize} $css='rotate: -90deg;'>
          <MaterialIcon iconClass='material-icons' name='add' />
        </Icon>
      </Box>
    </>
  );
};
