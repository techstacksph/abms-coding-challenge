import { labelSpan, mobile, required } from '@/utils/inputProps.util';

export const fields = () => ({
  title: '',
  fields: [
    {
      type: 'text' as const,
      title: 'First name',
      field: 'firstName',
      required: true,
      props: {
        rules: [required],
        ...labelSpan,
      },
    },
    {
      type: 'text' as const,
      title: 'Phone',
      field: 'phone',
      placeholder: 'Phone',
      props: {
        ...labelSpan,
      },
    },
    {
      type: 'text' as const,
      title: 'Last name',
      field: 'lastName',
      required: true,
      props: {
        rules: [required],
        ...labelSpan,
      },
    },
    {
      type: 'phone' as const,
      title: 'Mobile',
      field: 'mobile',
      required: true,
      placeholder: '000 000 0000',
      props: {
        rules: [mobile()],
        ...labelSpan,
      },
      selectProps: {
        value: '+64',
      },
    },
  ].map(field => ({
    ...field,
    props: {
      ...field.props,
      $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
    },
  })),
});

export const emailField = {
  title: '',
  fields: [
    {
      type: 'text' as const,
      title: 'Email',
      field: 'email',
      required: true,
      props: {
        rules: [
          required,
          {
            type: 'email' as const,
            message: 'Please specify a valid email address',
          },
        ],
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
    },
  ],
};
