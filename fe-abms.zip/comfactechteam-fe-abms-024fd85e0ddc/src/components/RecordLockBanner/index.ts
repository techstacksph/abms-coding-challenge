export { RecordLockBanner } from './RecordLockBanner';
export type { RecordLockBannerProps } from './RecordLockBanner';
