import React, { useState, useEffect } from 'react';
import { InfoCircleOutlined } from '@ant-design/icons';
import styled from 'styled-components';
import { RecordLockInfo } from '@/hooks/useRecordLock';

const BannerWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 24px;
  background-color: #fffbea;
  border-bottom: 1px solid #fef3c7;
  font-size: 14px;
  color: #1f2226;
  line-height: 20px;
  width: 100%;
  box-sizing: border-box;

  .info-icon {
    font-size: 20px;
    color: #f59e0b;
    flex-shrink: 0;
  }

  .banner-text {
    flex: 1;
    line-height: 20px;
  }

  .countdown-timer {
    font-weight: 700;
    color: #1f2226;
  }
`;

export interface RecordLockBannerProps {
  /**
   * Lock information from useRecordLock hook
   */
  lockInfo: RecordLockInfo | null;
}

/**
 * Full-width banner component to display record lock status at the top of the page
 *
 * NOTE: Banner is permanently disabled as per ABMS-299.
 * Record locking still works in the background - only the visual banner is removed.
 * Other users attempting to edit a locked record will still see the modal popup.
 *
 * @example
 * ```tsx
 * const { lockInfo } = useRecordLock({
 *   recordType: 'account',
 *   recordId: '123',
 *   autoAcquire: true,
 * });
 *
 * <RecordLockBanner lockInfo={lockInfo} />
 * <FormContent>...</FormContent>
 * ```
 */
export const RecordLockBanner: React.FC<RecordLockBannerProps> = ({
  lockInfo,
}) => {
  // ABMS-299: Banner permanently removed for all environments
  // Record locking functionality continues to work in the background
  // Only the yellow banner UI is hidden
  return null;
};
