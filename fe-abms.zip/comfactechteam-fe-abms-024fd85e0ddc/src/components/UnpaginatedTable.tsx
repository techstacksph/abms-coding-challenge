import React, { useEffect, useMemo, useState } from 'react';

import {
  ModuleTable,
  Icon,
  Button,
  Form,
  Text,
  Delete,
} from '@/styled-components';

import { PlusOutlined } from '@ant-design/icons';
import { ModeEditOutlineOutlined } from '@mui/icons-material';
import { Box, Stack } from '@mui/material';

import { Form as AntdForm, Checkbox } from 'antd';

import useMutation from '../hooks/useMutation';
import useQuery from '../hooks/useQuery';
import ActionButton from '../views/settings/common/components/ActionButton';
import CellForm from '../views/settings/common/components/CellForm';
import ModuleAlert, { ModuleRowSelection } from './ModuleAlert';

export type SelectAllMenuTypes = 'all' | 'deselect';

const actionColumn = ({ editingId, onCancel, onEdit, onDelete }) => ({
  title: '',
  dataIndex: 'actions',
  key: 'actions',
  width: 110,
  render: (_, record) => (
    <ActionButton
      isEditing={editingId === record.id}
      disabled={Boolean(editingId)}
      onCancel={onCancel}
      actions={[
        {
          key: 'edit',
          label: (
            <a onClick={() => onEdit(record)}>
              <Stack direction='row' alignItems='center' spacing={1}>
                <Icon>
                  <ModeEditOutlineOutlined />
                </Icon>
                <Text>Edit</Text>
              </Stack>
            </a>
          ),
        },
        {
          key: 'delete',
          label: (
            <a onClick={() => onDelete(record)}>
              <Stack direction='row' alignItems='center' spacing={1}>
                <Icon>
                  <Delete />
                </Icon>
                <Text>Delete</Text>
              </Stack>
            </a>
          ),
        },
      ]}
    />
  ),
});

const UnpaginatedTable = ({
  columns,
  query,
  searchFields,
  fields,
  nameField,
  createField,
  updateField,
  idField,
  title,
}) => {
  const [form] = AntdForm.useForm();
  const [selected, setSelected] = useState<ModuleRowSelection<any>>({
    selected: [],
  });
  const [data, setData] = useState([]);
  const [addingId, setAddingId] = useState<string>('');
  const [editingId, setEditingId] = useState<string>('');

  const {
    data: allData,
    loading: allLoading,
    refetch: requery,
  } = useQuery<Array<any>>({
    query: query.all,
    options: {
      variables: {
        sortArg: [
          {
            field: 'createdAt',
            direction: 'asc',
          },
        ],
        searchArg: searchFields,
      },
    },
  });

  const [updateMutation, { loading: updateLoading }] = useMutation({
    query: query.update,
    successMessage: `${form.getFieldValue(nameField)} successfully updated.`,
  });

  const [createMutation, { loading: createLoading }] = useMutation({
    query: query.create,
    successMessage: `${form.getFieldValue(nameField)} successfully created.`,
  });

  const [deleteMutation, { loading: deleteLoading }] = useMutation({
    query: query.delete,
    successMessage: `
      ${
        selected.selected.length > 1
          ? `${selected.selected?.length} ${title.plural}`
          : selected.selected[0]
            ? selected.selected[0][nameField]
            : ''
      } successfully deleted.`,
  });

  useEffect(() => {
    setData(allData);
  }, [allData]);

  const onAdd = () => {
    const length = [...data].length;
    const newData = {
      id: `new-${length}`,
    };

    setData(prevState => [...prevState, newData]);
    form.resetFields();
    form.setFieldsValue(newData);
    setEditingId(`new-${length}`);
    setAddingId(`new-${length}`);
  };

  const submitDelete = async () => {
    await deleteMutation({
      variables: {
        ids: selected.selected?.map(d => d.id),
      },
    });

    setSelected({ selected: [] });
    requery();
  };

  const onCancel = () => {
    if (addingId === editingId) {
      setData(prevState => prevState.slice(0, -1));
      setAddingId(null);
    }
    setEditingId(null);
  };

  const tableColumns = useMemo(() => {
    const actionCol = actionColumn({
      editingId,
      onCancel,
      onEdit: record => {
        form.setFieldsValue(record);
        setEditingId(record.id);
      },
      onDelete: record => setSelected({ selected: [record], type: 'single' }),
    });
    const tableCol = [...columns];
    tableCol.push(actionCol);
    return tableCol.map(c => {
      if (!fields[c.dataIndex]) return c;

      return {
        ...c,
        onCell: record => ({
          key: record.id,
          formProps: fields[c.dataIndex],
          isEditing: editingId === record.id,
          style: {
            textAlign: fields[c.dataIndex].type === 'number' ? 'right' : 'left',
          },
        }),
      };
    });
  }, [editingId]);

  const onFinish = async () => {
    if (addingId) {
      await createMutation({
        variables: {
          [createField]: form.getFieldsValue(),
        },
      });
    } else {
      await updateMutation({
        variables: {
          [idField]: editingId,
          [updateField]: form.getFieldsValue(),
        },
      });
    }

    requery();
    setAddingId(null);
    setEditingId(null);
  };

  const loading = allLoading || updateLoading || createLoading || deleteLoading;

  return (
    <>
      <Form form={form} onFinish={onFinish}>
        <ModuleTable
          columns={tableColumns}
          data={data}
          loading={loading}
          rowSelection={{
            onChange: (_, selected) =>
              setSelected({ selected, type: 'multiple' }),
            renderCell: (checked, record, index, originNode) => {
              return (
                <Checkbox
                  {...originNode.props}
                  disabled={Boolean(addingId || editingId)}
                />
              );
            },
            selectedRowKeys: selected.selected.map(d => d.id),
            columnTitle: originNode => (
              <Checkbox
                {...originNode.props}
                onChange={e => {
                  setSelected({
                    selected: e.target.checked ? data : [],
                    type: 'multiple',
                  });
                }}
                indeterminate={
                  selected.selected.length > 0 &&
                  selected.selected.length != data.length
                }
                checked={
                  selected.selected.length > 0 &&
                  selected.selected.length === data.length
                }
                disabled={Boolean(addingId || editingId)}
              />
            ),
          }}
          tableProps={{
            components: {
              body: {
                cell: CellForm,
              },
            },
            summary: () => (
              <tr>
                <td colSpan={columns.length}>
                  <Box>
                    <Button
                      type='dashed'
                      icon={<PlusOutlined />}
                      onClick={onAdd}
                      $css='border-radius: 8px; padding: 8px 12px;'
                      disabled={Boolean(addingId)}
                    >
                      {title.singular}
                    </Button>
                  </Box>
                </td>
              </tr>
            ),
          }}
          hidePagination
        />
      </Form>
      <ModuleAlert
        loading={deleteLoading}
        selected={selected}
        message={
          selected.type === 'single' ? (
            `Are you sure you want to delete this ${title.singular}?`
          ) : (
            <>
              <Text>Are you sure you want to delete these {title.plural}?</Text>
              <br />
              <Text>All selected {title.plural} will be deleted.</Text>
            </>
          )
        }
        title={
          selected.type === 'single'
            ? title.singular
            : `${selected.selected.length} ${title.plural}`
        }
        onDelete={async () => await submitDelete()}
        onClose={() => setSelected({ selected: [], type: 'multiple' })}
        onExport={undefined}
      />
    </>
  );
};

export default UnpaginatedTable;
