import React from 'react';

import { AYRLogo } from '@/styled-components';

import { Routes } from '@/mfe-utilities';
import { Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Logo = () => {
  const navigate = useNavigate();

  return (
    <Box onClick={() => navigate((Routes.Default as any).home || '/dashboard')}>
      <Box position='relative'>
        <AYRLogo
          $css={`
          width: 190px;

          @media (max-width: 768px) {
            width: 120px;
          }

          @media (max-width: 480px) {
            width: 100px;
          }
        `}
        />
      </Box>
    </Box>
  );
};
export default Logo;
