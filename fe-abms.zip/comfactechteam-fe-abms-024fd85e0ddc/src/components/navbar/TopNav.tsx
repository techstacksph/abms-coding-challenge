import React from 'react';

import { Header } from '@/styled-components';

import { GET_DEFAULT_COMPANY_SETTINGS } from '@/graphql/companySettings';
import useQuery from '@/hooks/useQuery';
import { getRoute } from '@/mfe-utilities';
import { Box, Stack } from '@mui/material';

import { navigate } from '@/utils/navigation.utils';
import Logo from './Logo';
import Menu from './Menu';
import NavRightMenu from './NavRightMenu';
import useCompanySettings from '@/hooks/useCompanySettings';

const TopNav = () => {
  // Fetch company settings data at top level
  // eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars
  const { maximumFileSize } = useCompanySettings();

  const { data: companySettings } = useQuery<any>({
    query: GET_DEFAULT_COMPANY_SETTINGS,
    transformData: data => {
      return data[0];
    },
  });

  return (
    <Header
      $css={`
          position: sticky;
          top: 0;
          width: 100%;
          z-index: 10;
          display: flex;
          align-items: center;
          background: #090A0B;
          padding: 0px 16px;
          border-bottom: 1px solid #E1E9F0;
          height: 79px;

          @media (min-width: 768px) {
            padding: 0px 24px;
          }

          @media (min-width: 1024px) {
            padding: 0px 40px;
          }
        `}
    >
      <Stack
        direction='row'
        alignItems='center'
        spacing={{ xs: 1, sm: 2, md: 2.5 }}
        sx={{
          // Use flex-grow to fill available space without fixed width constraints
          flexGrow: 1,
          width: 'auto',
          minWidth: 0, // Allows flex items to shrink below their content size
          overflow: 'hidden', // Prevent horizontal overflow
        }}
      >
        <Box onClick={() => navigate(getRoute('Default', 'home'))}>
          <Logo />
        </Box>
        <Menu />
      </Stack>
      <NavRightMenu companySettings={companySettings} />
    </Header>
  );
};

export default TopNav;
