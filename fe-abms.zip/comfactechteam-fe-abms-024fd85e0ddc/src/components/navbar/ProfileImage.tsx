import React from 'react';

import { NoProfileImg } from '@/styled-components';

const ProfileImage = ({ profile, size = '40px' }) => {
  if (profile && profile?.profilePic) {
    return (
      <img
        width={size}
        height={size}
        style={{
          borderRadius: '50%',
          objectFit: 'cover',
          objectPosition: 'center',
          display: 'block',
          minWidth: size,
          minHeight: size,
        }}
        src={profile.profilePic}
        alt={`${profile.firstName || ''} ${profile.lastName || ''}`}
      />
    );
  }

  return <NoProfileImg size={size} />;
};

export default ProfileImage;
