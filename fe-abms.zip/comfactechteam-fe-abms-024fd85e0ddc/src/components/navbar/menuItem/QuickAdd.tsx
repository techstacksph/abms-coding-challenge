import React from 'react';

import { Button, Icon, MaterialIcon, Text } from '@/styled-components';

import { StyledMenu } from '@/components/DropdownMenuRender';
import Link from '@/components/Link';
import { Box, Stack } from '@mui/material';

import { Dropdown } from 'antd';

import { QuickAddList } from '../../../constants/QuickAddList';

const QuickAdd = () => {
  return (
    <Box>
      <Dropdown
        placement='bottomRight'
        menu={{
          items: QuickAddList.map(l => ({
            key: l.label,
            label: (
              <Link to={l.to} $css='&::after { content: unset !important;}'>
                <Stack
                  px={1.5}
                  py={1}
                  spacing={1}
                  direction='row'
                  alignItems='center'
                >
                  <Icon color='#878B97'>{l.icon}</Icon>
                  <Text $css='line-height: 20px;'>{l.label}</Text>
                </Stack>
              </Link>
            ),
          })),
        }}
        popupRender={menu => (
          <StyledMenu className='quick-add-menu'>{menu}</StyledMenu>
        )}
        trigger={['click']}
        overlayStyle={{
          width: 214,
          height: 168,
        }}
      >
        <Button
          type='primary'
          shape='circle'
          icon={
            <Icon size='reg'>
              <MaterialIcon name='add' />
            </Icon>
          }
          size='large'
          $css={`
            min-width: 48px !important;
            width: 48px !important;
            height: 48px;
            &:hover {
              background: #828FFF !important;
              border: 1px solid #3137FD;
            }
          `}
        />
      </Dropdown>
    </Box>
  );
};

export default QuickAdd;
