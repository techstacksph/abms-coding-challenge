import {
  ReactNode,
  useEffect,
  useState,
  useRef,
  useMemo,
  useCallback,
} from 'react';

import dayjs from 'dayjs';

import {
  Icon,
  Button,
  Text,
  Switch,
  IconAvatar,
  Badge,
  EmptyNotifications2,
  MaterialIcon,
  GoogleIcon,
} from '@/styled-components';

import environment from '@/config/environment';
import { useProfile, getListRoute } from '@/mfe-utilities';
import {
  ALL_NOTIFICATIONS,
  PAGINATED_NOTIFICATIONS,
  MARK_NOTIFICATION_READ,
  UNREAD_NOTIFICATION_COUNT,
  MARK_ALL_NOTIFICATIONS_AS_READ,
} from '@/graphql/notifications.gql';
import useMutation from '@/hooks/useMutation';
import useNavigate from '@/hooks/useNavigate';
import useNotificationPolling from '@/hooks/useNotificationPolling';
import useQuery from '@/hooks/useQuery';
import NotificationAndAlertModel from '@/models/NotificationAndAlertModel';
import { NotificationAndAlertIconsEnum } from '@/enums/NotificationAndAlertIconsEnum';
import { Box, Stack } from '@mui/material';

import { Button as AntdButton, Col, Dropdown, Row, Spin } from 'antd';

import DropdownPopup from '../DropdownPopup';

// Utility function to convert text to sentence case
const toSentenceCase = (text: string): string => {
  if (!text || typeof text !== 'string') return text || '';

  return text
    .toLowerCase()
    .split('. ')
    .map(sentence => sentence.charAt(0).toUpperCase() + sentence.slice(1))
    .join('. ');
};

interface NotificationItemProps {
  title?: ReactNode;
  description?: ReactNode;
  time?: Date | string;
  isRead?: boolean;
  onClick?: () => void;
  type?: 'task' | 'event' | 'default';
  icon?: NotificationAndAlertIconsEnum;
}

const NotificationItem = ({
  title,
  description,
  time,
  isRead,
  onClick,
  type = 'default',
  icon,
}: NotificationItemProps) => {
  return (
    <Stack
      direction='row'
      gap={'12px'}
      alignItems={'flex-start'}
      sx={{
        width: '100%',
        padding: '12px',
        cursor: 'pointer',
        '&:hover': {
          backgroundColor: '#F5F5F7',
        },
      }}
      onClick={onClick}
    >
      <IconAvatar
        icon={(() => {
          const iconData = getNotificationIcon(icon);
          return (
            <GoogleIcon
              name={iconData.name}
              $css={`font-size: 24px; color: #878B97`}
            />
          );
        })()}
        $css={
          'background-color: #E9EAEC; width: 40px; height: 40px; flex-shrink: 0;'
        }
      />
      <Stack
        gap={'8px'}
        sx={{
          flex: 1,
          overflow: 'hidden',
          minWidth: 0,
        }}
      >
        <Stack direction='row'>
          <Text
            $type='sm'
            $css={`font-weight: ${isRead ? '400' : '700'}; ${
              isRead ? 'color: #090A0B;' : ''
            } font-size: 14px; line-height: 20px; letter-spacing: 0%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width: 100%;`}
          >
            {title}
          </Text>
        </Stack>
        <Text
          $type='xs'
          $css={`white-space: pre-line; overflow: hidden; text-overflow: ellipsis; ${
            isRead ? 'color: #686D78;' : ''
          } font-weight: ${isRead ? '400' : '700'}; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; word-break: break-word;`}
        >
          {description}
        </Text>
      </Stack>

      <Stack
        sx={{
          flexShrink: 0,
          minWidth: '60px',
          '@media (max-width: 768px)': {
            minWidth: '50px',
          },
        }}
      >
        <Stack color='var(--color-text-secondary)'>
          <Text
            $type='xs'
            $css={
              isRead
                ? `color: var(--color-text-secondary); font-weight: 400; white-space: nowrap; font-size: 12px;`
                : `color: var(--color-text-primary); font-weight: 700; white-space: nowrap; font-size: 12px;`
            }
          >
            {time ? dayjs(time).format('MMM D') : ''}
          </Text>
        </Stack>
        <Stack>
          <Text
            $type='xs'
            $css={
              isRead
                ? `color: var(--color-text-secondary); font-weight: 400; white-space: nowrap; font-size: 12px;`
                : `color: var(--color-text-primary); font-weight: 700; white-space: nowrap; font-size: 12px;`
            }
          >
            {time ? dayjs(time).format('h:mm A') : ''}
          </Text>
        </Stack>
      </Stack>
    </Stack>
  );
};

// Helper function to determine notification icon based on backend icon field
const getNotificationIcon = (icon?: NotificationAndAlertIconsEnum) => {
  const defaultColor = '#31D48B';
  const fallbackColor = '#878B97';
  const primaryColor = 'var(--color-primary)';

  switch (icon) {
    case NotificationAndAlertIconsEnum.EVENT:
      return { name: 'event', color: defaultColor };
    case NotificationAndAlertIconsEnum.TASK_ALT:
      return { name: 'task_alt', color: defaultColor };
    case NotificationAndAlertIconsEnum.ALARM:
      return { name: 'alarm', color: primaryColor };
    case NotificationAndAlertIconsEnum.NOTIFICATIONS:
    default:
      return { name: 'notifications', color: fallbackColor };
  }
};

const Notification = () => {
  const [open, setOpen] = useState<boolean>(false);
  const [isReadOnly, setIsReadOnly] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<
    NotificationAndAlertModel[]
  >([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [popupNotifications, setPopupNotifications] = useState<
    NotificationAndAlertModel[]
  >([]);
  const [currentSkip, setCurrentSkip] = useState<number>(0);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [loadingMore, setLoadingMore] = useState<boolean>(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const { navigate } = useNavigate();
  const profile = useProfile();
  const TENANT_PREFIX = environment.TENANT_PREFIX;

  // LocalStorage key for tracking shown popup notifications
  const POPUP_STORAGE_KEY = 'shownNotificationPopups';

  // Helper functions for managing popup notification IDs in localStorage
  const getShownPopupIds = (): Set<string> => {
    try {
      const stored = localStorage.getItem(POPUP_STORAGE_KEY);
      const data = stored ? JSON.parse(stored) : [];

      // Filter out entries older than 24 hours
      const twentyFourHoursAgo = Date.now() - 24 * 60 * 60 * 1000;
      const recentIds = data.filter((entry: any) => {
        if (typeof entry === 'string') {
          // Old format - treat as expired
          return false;
        }
        const isRecent = entry.timestamp > twentyFourHoursAgo;
        return isRecent;
      });

      // Update localStorage with filtered data
      if (recentIds.length !== data.length) {
        localStorage.setItem(POPUP_STORAGE_KEY, JSON.stringify(recentIds));
      }

      const result = new Set<string>();
      recentIds.forEach((entry: any) => {
        if (entry.id) {
          result.add(entry.id);
        }
      });
      return result;
    } catch (error) {
      console.warn('Error reading popup IDs from localStorage:', error);
      return new Set();
    }
  };

  const addShownPopupId = (notificationId: string) => {
    try {
      const stored = localStorage.getItem(POPUP_STORAGE_KEY);
      const data = stored ? JSON.parse(stored) : [];

      // Add new entry with timestamp
      const newEntry = {
        id: notificationId,
        timestamp: Date.now(),
      };

      // Remove any existing entry for this ID
      const filteredData = data.filter(
        (entry: any) =>
          (typeof entry === 'string' ? entry : entry.id) !== notificationId
      );

      filteredData.push(newEntry);

      // Keep only the last 50 entries to prevent localStorage bloat
      const recentEntries = filteredData.slice(-50);

      localStorage.setItem(POPUP_STORAGE_KEY, JSON.stringify(recentEntries));
    } catch (error) {
      console.warn('Failed to store popup notification ID:', error);
    }
  };

  const clearOldPopupIds = () => {
    // Clear popup IDs when notifications are read
    // This helps prevent localStorage from growing indefinitely
    try {
      const stored = localStorage.getItem(POPUP_STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored);
        // Keep only recent entries (last 25 IDs)
        const recentEntries = data.slice(-25);
        localStorage.setItem(POPUP_STORAGE_KEY, JSON.stringify(recentEntries));
      }
    } catch {
      localStorage.removeItem(POPUP_STORAGE_KEY);
    }
  };

  // Memoize search args
  const searchArgs = useMemo(() => {
    const args = [];

    if (isReadOnly) {
      args.push({
        fieldName: 'read',
        searchValue: 'false',
        comparator: 'EQUAL',
      });
    }

    return args;
  }, [isReadOnly]);
  // Memoize query variables
  const queryVariables = useMemo(() => {
    const variables = {
      searchArg: searchArgs,
      pageArg: {
        take: 10,
        skip: currentSkip,
        sort: [{ field: 'createdAt', direction: 'desc' }],
      },
    };
    return variables;
  }, [searchArgs, currentSkip]);

  const {
    data: paginatedData,
    loading,
    refetch,
  } = useQuery<{
    pageInfo: { count: number; pageCount: number; take: number; skip: number };
    data: NotificationAndAlertModel[];
  }>({
    query: PAGINATED_NOTIFICATIONS,
    options: {
      variables: queryVariables,
      fetchPolicy: 'network-only',
    },
  });

  // Query for unread notification count
  const { data: unreadCountData, refetch: refetchUnreadCount } =
    useQuery<number>({
      query: UNREAD_NOTIFICATION_COUNT,
      options: {
        fetchPolicy: 'network-only',
      },
    });

  // Extract and memoize the actual notifications data from paginated response
  const data = useMemo(() => {
    return (
      paginatedData?.data?.map(notif => new NotificationAndAlertModel(notif)) ||
      []
    );
  }, [paginatedData?.data]);

  // Function to load more notifications
  const loadMoreNotifications = async () => {
    if (loadingMore || !hasMore) {
      return;
    }

    setLoadingMore(true);

    try {
      const newSkip = currentSkip + 10;
      setCurrentSkip(newSkip);

      // Don't set loadingMore to false here - let the useEffect handle it when data loads
    } catch (error) {
      console.error('Error loading more notifications:', error);
      setLoadingMore(false);
    }
  };

  // Scroll handler for infinite scrolling
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;

    // Load more when scrolled to within 100px of bottom
    if (scrollHeight - scrollTop <= clientHeight + 100) {
      loadMoreNotifications();
    }
  };

  // Reset pagination when filters change
  const resetPagination = () => {
    setCurrentSkip(0);
    setHasMore(true);
    setNotifications([]);
  };

  // Clear old popup IDs on component mount
  useEffect(() => {
    clearOldPopupIds();
  }, []);

  // Combined refetch function for both notifications and unread count
  const refetchAll = useCallback(async () => {
    await Promise.all([refetch(), refetchUnreadCount()]);
  }, [refetch, refetchUnreadCount]);

  // Use the custom notification polling hook
  const { forceRefresh } = useNotificationPolling({
    refetch: refetchAll,
    isOpen: open,
    interval: 30000, // 30 seconds
  });

  // Reset pagination and force refresh when modal opens
  // useEffect(() => {
  //   if (open) {
  //     resetPagination();
  //     // Force refresh to get latest notifications
  //     forceRefresh();
  //   }
  // }, [open, forceRefresh]);

  const [markAsReadMutation] = useMutation({
    query: MARK_NOTIFICATION_READ,
    disableAlert: true,
  });

  const [markAllAsReadMutation] = useMutation({
    query: MARK_ALL_NOTIFICATIONS_AS_READ,
    disableAlert: true,
  });

  const onChangeReadOnly = () => {
    const newValue = !isReadOnly;
    setIsReadOnly(newValue);
    resetPagination(); // Reset pagination when changing filter
  };

  const onMarkAsRead = async () => {
    if (unreadCount === 0) return;

    try {
      // Optimistically update UI
      setNotifications(prev =>
        prev.map(
          notif => new NotificationAndAlertModel({ ...notif, read: true })
        )
      );
      setUnreadCount(0);

      // Clear popup IDs when marking all as read
      clearOldPopupIds();

      // Call the backend mutation to mark all as read
      await markAllAsReadMutation();

      // Refetch to get the updated data
      await refetch();
      await refetchUnreadCount();
    } catch (error) {
      console.error('Failed to mark all as read:', error);
      // Refetch to restore accurate state on error
      await refetch();
      await refetchUnreadCount();
    }
  };

  const handleNotificationClick = async (
    notification: NotificationAndAlertModel
  ) => {
    if (!notification.read) {
      try {
        setNotifications(prev =>
          prev.map(n =>
            n.id === notification.id
              ? new NotificationAndAlertModel({ ...n, read: true })
              : n
          )
        );

        await markAsReadMutation({
          variables: {
            [`${TENANT_PREFIX}updateNotificationAndAlertId`]: notification.id,
          },
        });

        await refetch();
        await refetchUnreadCount();
      } catch {
        setNotifications(prev =>
          prev.map(n =>
            n.id === notification.id
              ? new NotificationAndAlertModel({ ...n, read: false })
              : n
          )
        );
        await refetchUnreadCount();
      }
    }

    // Navigation logic
    if (
      (notification.module === 'TASK' || notification.task?.id) &&
      notification.task?.id
    ) {
      navigate(`${getListRoute('Tasks')}/${notification.task.id}`);
      setOpen(false);
    } else if (
      (notification.module === 'EVENT' || notification.event?.id) &&
      notification.event?.id
    ) {
      navigate(`${getListRoute('Events')}/${notification.event.id}`);
      setOpen(false);
    }
  };

  // Update unread count from API
  useEffect(() => {
    if (unreadCountData !== undefined && unreadCountData !== null) {
      setUnreadCount(unreadCountData);
    }
  }, [unreadCountData]);

  useEffect(() => {
    if (data) {
      const unreadNotifications = data.filter(notif => !notif.read);

      // Handle notifications list based on pagination
      if (currentSkip === 0) {
        // First page - replace notifications
        if (isReadOnly) {
          setNotifications(unreadNotifications);
        } else {
          setNotifications(data);
        }
      } else {
        // Subsequent pages - append notifications
        setNotifications(prev => {
          const newNotifications = isReadOnly ? unreadNotifications : data;
          const existingIds = new Set(prev.map(n => n.id));
          const uniqueNewNotifications = newNotifications.filter(
            n => !existingIds.has(n.id)
          );
          return [...prev, ...uniqueNewNotifications];
        });
      }

      // Check if there are more notifications to load
      const pageInfo = paginatedData?.pageInfo;
      if (pageInfo) {
        const hasMoreData = currentSkip + 10 < pageInfo.count;
        setHasMore(hasMoreData && data.length === 10); // Only has more if we got a full page
      }

      // Set loadingMore to false when data is loaded (for subsequent pages)
      if (currentSkip > 0) {
        setLoadingMore(false);
      }

      // Handle popup notifications (only for first page)
      if (currentSkip === 0) {
        setPopupNotifications(prev => {
          const shownPopupIds = getShownPopupIds();
          const newNotifs = unreadNotifications.filter(
            notif =>
              !prev.some(existing => existing.id === notif.id) &&
              !shownPopupIds.has(notif.id || '')
          );

          const result = newNotifs.length > 0 ? [...prev, ...newNotifs] : prev;

          return result;
        });
      }
    }

    // Also set loadingMore to false if loading is complete (handles both first page and subsequent pages)
    if (!loading && loadingMore) {
      setLoadingMore(false);
    }
  }, [
    data,
    isReadOnly,
    currentSkip,
    paginatedData?.pageInfo,
    loading,
    loadingMore,
  ]);

  const popupTimers = useRef({});
  const [hoveredPopup, setHoveredPopup] = useState(null);

  // Separate useEffect to handle localStorage storage when popups are actually shown
  useEffect(() => {
    if (popupNotifications.length > 0) {
      // Add new popup notifications to localStorage
      popupNotifications.forEach(notif => {
        if (notif.id) {
          // Only add if not already in localStorage
          const shownIds = getShownPopupIds();
          if (!shownIds.has(notif.id)) {
            addShownPopupId(notif.id);
          }
        }
      });
    }
  }, [popupNotifications]); // Only runs when popupNotifications actually changes

  useEffect(() => {
    popupNotifications.forEach(notif => {
      if (!popupTimers.current[notif.id] && hoveredPopup !== notif.id) {
        popupTimers.current[notif.id] = setTimeout(() => {
          setPopupNotifications(prev => prev.filter(n => n.id !== notif.id));
          delete popupTimers.current[notif.id];
        }, 5000);
      }
    });
    Object.keys(popupTimers.current).forEach(id => {
      if (!popupNotifications.find(n => n.id === id)) {
        clearTimeout(popupTimers.current[id]);
        delete popupTimers.current[id];
      }
    });
    if (hoveredPopup) {
      if (popupTimers.current[hoveredPopup]) {
        clearTimeout(popupTimers.current[hoveredPopup]);
        delete popupTimers.current[hoveredPopup];
      }
    }
  }, [popupNotifications, hoveredPopup]);

  const NotificationPopup = ({
    notification,
    onClose,
    onViewDetails,
    visible,
  }) => {
    const popupRef = useRef(null);

    useEffect(() => {
      if (visible && popupRef.current) {
        void popupRef.current.offsetWidth;
      }
    }, [visible]);

    return (
      <Stack
        ref={popupRef}
        direction='row'
        alignItems='flex-start'
        gap={'8px'}
        sx={{
          position: 'relative',
          background: '#FFFFFF',
          borderRadius: '4px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
          padding: '16px',
          width: 328,
          maxWidth: '50vw',
          // '@media (max-width:400px)': {
          //   width: '90vw',
          //   minWidth: 0,
          //   maxWidth: 328,
          // },
          // '@media (max-width:340px)': {
          //   width: '95vw',
          //   minWidth: 0,
          //   maxWidth: 328,
          // },
          height: 'auto',
          borderLeft: `4px solid ${(notification as any).icon === NotificationAndAlertIconsEnum.ALARM ? 'var(--color-primary)' : '#31D48B'}`,
          marginBottom: 2,
          transform: visible ? 'translateX(0)' : 'translateX(120%)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 0.45s cubic-bezier(0.4,0,0.2,1), opacity 0.45s cubic-bezier(0.4,0,0.2,1)',
        }}
        onMouseEnter={() => setHoveredPopup(notification.id)}
        onMouseLeave={() => setHoveredPopup(null)}
      >
        <Stack
          alignItems='center'
          justifyContent='flex-start'
          sx={{
            width: '20%',
            minWidth: 0,
            paddingTop: '4px',
          }}
        >
          <Stack
            alignItems='center'
            justifyContent='center'
            sx={{
              width: 40,
              height: 40,
              borderRadius: '50%',
              background:
                (notification as any).icon ===
                NotificationAndAlertIconsEnum.ALARM
                  ? '#F0F3FF'
                  : '#F1FCF8',
            }}
          >
            {(() => {
              const iconData = getNotificationIcon((notification as any).icon);
              // Use special colors for popup icons only
              const popupIconColor =
                (notification as any).icon ===
                NotificationAndAlertIconsEnum.ALARM
                  ? 'var(--color-primary)'
                  : '#31D48B';
              return (
                <GoogleIcon
                  name={iconData.name}
                  $css={`font-size: 24px; color: ${popupIconColor};`}
                />
              );
            })()}
          </Stack>
        </Stack>
        <Stack gap={0.5} sx={{ width: '69%', minWidth: 0 }}>
          <Text
            $type='md'
            $css='font-weight: 600; font-size: 14px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;'
          >
            {notification.subject}
          </Text>
          <Text
            $type='xs'
            $css='color: #686D78; white-space: pre-line; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis; font-size: 14px; line-height: 20px;'
          >
            {notification.description}
          </Text>
          <Text
            $type='sm'
            $css='color: #3137FD; font-weight: 700; cursor: pointer;'
            onClick={onViewDetails}
          >
            View details
          </Text>
        </Stack>
        <Stack
          sx={{
            width: '10%',
            minWidth: 0,
            alignItems: 'flex-end',
            cursor: 'pointer',
          }}
          onClick={onClose}
        >
          <MaterialIcon name='close' $css='font-size: 20px; color: #878B97;' />
        </Stack>
      </Stack>
    );
  };

  return (
    <Box>
      <style>
        {`
          @media (max-width: 768px) {
            .notification-dropdown-overlay {
              left: 0 !important;
              right: 0 !important;
              max-width: 100vw !important;
              width: 100vw !important;
            }
            .notification-dropdown-overlay .ant-dropdown-menu {
              max-width: 100vw !important;
              width: 100vw !important;
            }
          }
        `}
      </style>
      {/* Popups for new notifications */}
      <Box sx={{ position: 'fixed', top: 24, right: 24, zIndex: 1400 }}>
        <Stack spacing={2}>
          {popupNotifications.map(notif => (
            <NotificationPopup
              key={notif.id}
              notification={notif}
              visible={true}
              onClose={() => {
                setPopupNotifications(prev =>
                  prev.filter(n => n.id !== notif.id)
                );
              }}
              onViewDetails={() => {
                handleNotificationClick(notif);
                setPopupNotifications(prev =>
                  prev.filter(n => n.id !== notif.id)
                );
              }}
            />
          ))}
        </Stack>
      </Box>
      <Dropdown
        popupRender={() => (
          <Box
            sx={{
              width: '100%',
              '@media (max-width: 768px)': {
                width: '100vw',
                maxWidth: '100vw',
              },
            }}
          >
            <DropdownPopup
              maxHeight={632}
              containerProps={{
                sx: {
                  '@media (max-width: 768px)': {
                    width: '100vw !important',
                    maxWidth: '100vw !important',
                    borderRadius: '0 !important',
                    marginTop: '0 !important',
                  },
                },
              }}
            >
              <Row justify='space-between' align='middle'>
                <Col>
                  <Text $type='md' weight='bold'>
                    Notifications
                  </Text>
                </Col>
                <Col>
                  <Stack direction='row' alignItems='center' gap={'16px'}>
                    <Stack direction='row' alignItems='center' gap={'8px'}>
                      <Text
                        $css={
                          'font-size: 12px;font-weight: 400; color: #090A0B'
                        }
                      >
                        Only show unread
                      </Text>
                      <Switch
                        checked={isReadOnly}
                        onChange={onChangeReadOnly}
                        $css={`
                          &.ant-switch.ant-switch-checked,
                          &.ant-switch.ant-switch-checked:where(.ant-switch) {
                            background: #3137FD !important;
                          }
                        `}
                        size='small'
                      />
                    </Stack>
                    <Stack>
                      <Button
                        type='link'
                        $css={
                          'font-size: 12px; font-weight: 600; height: 32px; padding: 4px 12px;'
                        }
                        onClick={onMarkAsRead}
                        disabled={unreadCount === 0}
                      >
                        Mark all as read
                      </Button>
                    </Stack>
                  </Stack>
                </Col>
              </Row>
              <Stack
                spacing={0.5}
                sx={{
                  maxHeight: '496px',
                  minHeight:
                    notifications.length === 0 && !loading ? 'auto' : '496px',
                  overflow: 'auto',
                  height: '100%',
                }}
                ref={scrollContainerRef}
                onScroll={handleScroll}
              >
                {loading && currentSkip === 0 ? (
                  <Stack
                    justifyContent='center'
                    alignItems='center'
                    sx={{
                      height: '100%',
                      minHeight: '496px',
                      width: '100%',
                    }}
                  >
                    <Spin size='large' />
                  </Stack>
                ) : notifications.length === 0 ? (
                  <Stack justifyContent='center' alignItems='center'>
                    <EmptyNotifications2 showingUnreadOnly={isReadOnly} />
                  </Stack>
                ) : (
                  <>
                    {notifications.map((notif, i) => {
                      // Debug log to see notification data
                      console.log('🔍 Notification data:', {
                        id: notif.id,
                        subject: notif.subject,
                        icon: (notif as any).icon,
                        module: notif.module,
                      });

                      return (
                        <NotificationItem
                          key={notif.id || i}
                          title={notif.subject}
                          description={notif.description}
                          time={notif.createdAt}
                          isRead={notif.read}
                          onClick={() => handleNotificationClick(notif)}
                          icon={(notif as any).icon}
                          type={
                            notif.module === 'TASK' || notif?.task?.id
                              ? 'task'
                              : notif.module === 'EVENT' || notif?.event?.id
                                ? 'event'
                                : 'default'
                          }
                        />
                      );
                    })}
                    {loadingMore && (
                      <Stack
                        justifyContent='center'
                        alignItems='center'
                        sx={{ padding: '16px' }}
                      >
                        <Spin />
                      </Stack>
                    )}
                    {/* Optionally show a message that there are no more notifications to load */}
                    {/* {!hasMore && notifications.length > 10 && (
                    <Stack
                      justifyContent='center'
                      alignItems='center'
                      sx={{ padding: '8px' }}
                    >
                      <Text $type='sm' $css='color: #686D78;'>
                        No more notifications to load
                      </Text>
                    </Stack>
                  )} */}
                  </>
                )}
              </Stack>
              {notifications.length > 0 && (
                <Box
                  sx={{
                    textAlign: 'center',
                    paddingTop: '12px',
                    paddingBottom: '12px',
                  }}
                >
                  <AntdButton
                    style={{
                      color: '#3137FD',
                      fontSize: '14px',
                      fontWeight: 500,
                      width: 200,
                      height: 36,
                      minWidth: '120px',
                      gap: '4px',
                      borderRadius: '8px',
                      paddingTop: '4px',
                      paddingRight: '12px',
                      paddingBottom: '4px',
                      paddingLeft: '12px',
                      borderWidth: '1px',
                      border: '1px solid #3137FD',
                    }}
                    onClick={() => {
                      navigate('/notifications');
                      setOpen(false);
                    }}
                  >
                    See all notifications & alerts
                  </AntdButton>
                </Box>
              )}
            </DropdownPopup>
          </Box>
        )}
        trigger={['click']}
        open={open}
        onOpenChange={setOpen}
        overlayClassName='notification-dropdown-overlay'
      >
        <Button
          type='text'
          shape='circle'
          icon={
            <Badge
              count={unreadCount}
              color='#F34C4C'
              $css={`
                .ant-badge-count {
                  background-color: #F34C4C;
                  font-weight: bold;
                  font-size: 12px;
                  height: 20px;
                  min-width: 20px;
                  line-height: 20px;
                  border-radius: 10px;
                  box-shadow: none;
                  padding: 0 6px;
                }
              `}
            >
              <Icon size='reg' color={open ? '#3137FD' : '#878B97'}>
                <MaterialIcon
                  name='notifications'
                  $css='font-weight: 400; font-size: 24px;'
                />
              </Icon>
            </Badge>
          }
          size='large'
          $css={`
            min-width: 40px !important;
            width: 40px !important;
            &:hover {
              background-color: #2F3137 !important;
            }

            &:hover span {
              color: #fff !important;
            }
            ${open ? 'background-color: #F0F3FF;' : undefined}
          `}
        />
      </Dropdown>
    </Box>
  );
};

export default Notification;
