import {
  Button,
  EmptySearch,
  GoogleIcon,
  Icon,
  Input,
  MaterialIcon,
  Text,
} from '@/styled-components';
import {
  UIEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { ALL_GLOBAL_SEARCH } from '@/graphql/globalSearch.gql';
import useQuery from '@/hooks/useQuery';
import GlobalSearch from '@/models/GlobalSearch';
import { navigate } from '@/utils/navigation.utils';
import { SearchOutlined } from '@ant-design/icons';
import { Box, Grid, Stack } from '@mui/material';
import { Dropdown, Spin } from 'antd';

import DropdownPopup from '../DropdownPopup';

const Search = () => {
  const [open, setOpen] = useState<boolean>(false);
  const [search, setSearch] = useState<string>();
  const [visibleCount, setVisibleCount] = useState<number>(10);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isScrollable, setIsScrollable] = useState<boolean>(false);
  const { data: dbSearch, loading: loadingSearch } = useQuery<
    Array<GlobalSearch>
  >({
    query: ALL_GLOBAL_SEARCH,
    options: {
      variables: {
        searchArg: search,
      },
    },
  });

  useEffect(() => {
    if (!open) setSearch(null);
  }, [open]);

  useEffect(() => {
    setVisibleCount(10);
  }, [search]);

  const results = useMemo(() => dbSearch || [], [dbSearch]);
  const slicedResults = useMemo(
    () => results.slice(0, visibleCount),
    [results, visibleCount]
  );

  const handleScroll = useCallback(
    (e: UIEvent<HTMLDivElement>) => {
      const target = e.currentTarget;
      const threshold = 24;
      const reachedBottom =
        target.scrollTop + target.clientHeight >=
        target.scrollHeight - threshold;
      if (reachedBottom && visibleCount < results.length) {
        setVisibleCount(prev => Math.min(prev + 10, results.length));
      }
    },
    [results.length, visibleCount]
  );

  useEffect(() => {
    if (!open) return;
    const el = scrollRef.current;
    if (!el) return;
    const onNativeScroll = () => {
      const threshold = 24;
      const reachedBottom =
        el.scrollTop + el.clientHeight >= el.scrollHeight - threshold;
      if (reachedBottom && visibleCount < results.length) {
        setVisibleCount(prev => Math.min(prev + 10, results.length));
      }
    };
    el.addEventListener('scroll', onNativeScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', onNativeScroll as EventListener);
    };
  }, [open, results.length, visibleCount]);

  useEffect(() => {
    // measure if the container has scroll
    const el = scrollRef.current;
    if (!el) {
      setIsScrollable(false);
      return;
    }
    // next tick to ensure layout is updated
    const id = window.requestAnimationFrame(() => {
      setIsScrollable(el.scrollHeight > el.clientHeight + 1);
    });
    return () => window.cancelAnimationFrame(id);
  }, [open, results.length, visibleCount]);

  return (
    <Box>
      <Dropdown
        placement='bottom'
        dropdownRender={() => (
          <DropdownPopup
            containerProps={{
              sx: { overflowY: 'auto' },
              onScroll: handleScroll,
              ref: scrollRef,
            }}
          >
            <Text type='md' weight='bold' $css={'font-size: 16px'}>
              Search
            </Text>
            <Input.Text
              value={search}
              placeholder='Search'
              prefix={
                <SearchOutlined
                  style={{ fontSize: '17px', color: 'var(--gray-300)' }}
                />
              }
              onChange={e => setSearch(e.target.value)}
              allowClear
              $css={`
                border-color: var(--gray-300) !important;
                outline-color: var(--gray-300) !important;
                `}
            />
            <Spin spinning={loadingSearch}>
              <Box>
                <Stack spacing={0.5}>
                  {dbSearch && dbSearch.length > 0 && (
                    <Text
                      $type='xs'
                      weight='bold'
                      color='var(--color-text-tertiary)'
                    >
                      RESULTS
                    </Text>
                  )}
                  {slicedResults && slicedResults.length > 0 ? (
                    slicedResults.map((item, key) => {
                      return (
                        <Grid
                          container
                          key={key}
                          alignItems='center'
                          sx={{
                            ':hover': {
                              borderRadius: '4px',
                              background: 'var(--gray-100)',
                            },
                            ':hover button > span': {
                              color: '#3137FD',
                            },
                          }}
                        >
                          <Grid item xs md>
                            <Stack padding='8px'>
                              <Text
                                weight='medium'
                                $css={'font-weight: 600'}
                                color='var(--color-text-primary)'
                              >
                                {item.name}
                              </Text>
                              <Text
                                $type='xs'
                                $css={'margin-top: 1px'}
                                color='var(--color-text-secondary)'
                              >
                                {item.module}
                              </Text>
                            </Stack>
                          </Grid>
                          <Grid item alignContent='center'>
                            <Button
                              ghost
                              $css='border: none; box-shadow: none !important; background: none !important;'
                              onClick={() => {
                                navigate(item.redirectTo);
                              }}
                            >
                              <Icon>
                                <GoogleIcon name='open_in_new' />
                              </Icon>
                            </Button>
                          </Grid>
                        </Grid>
                      );
                    })
                  ) : (
                    <EmptySearch
                      title='Type something to search from the site.'
                      $css={
                        'margin-top: 50px !important; margin-bottom: 50px !important; color: #A7AAB2'
                      }
                    />
                  )}
                </Stack>
                {results &&
                  results.length > 0 &&
                  (!isScrollable || visibleCount >= results.length) && (
                    <Stack textAlign='center'>
                      <Text $type='xs' color='var(--color-text-tertiary)'>
                        You&apos;ve reached the end.
                      </Text>
                    </Stack>
                  )}
              </Box>
            </Spin>
          </DropdownPopup>
        )}
        trigger={['click']}
        onOpenChange={val => setOpen(val)}
      >
        <Button
          type='text'
          shape='circle'
          icon={
            <Icon size='24px' color={open ? '#3137FD' : '#7B8B99'}>
              <MaterialIcon name='search' />
            </Icon>
          }
          size='large'
          onClick={() => setOpen(true)}
          $css={`
            min-width: 40px !important;
            width: 40px !important;
            &:hover {
              background-color: #2F3137 !important;
            }

            &:hover span {
              color: #fff !important;
            }
            ${open ? 'background-color: #F0F3FF;' : undefined}
          `}
        />
      </Dropdown>
    </Box>
  );
};

export default Search;
