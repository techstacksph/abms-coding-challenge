import React, { useState } from 'react';

import { Text, Space, Divider } from '@/styled-components';

import { useProfile } from '@/mfe-utilities';
import { ExpandMore } from '@mui/icons-material';
import { Box, Stack } from '@mui/material';

import { Col, Dropdown, Row } from 'antd';

import ProfileMenuList from '../../../constants/ProfileMenuList';
import DropdownPopup from '../DropdownPopup';
import ProfileFooter from '../ProfileFooter';
import ProfileImage from '../ProfileImage';
import ChangePasswordModal from '@/views/settings/manage-profile/common/components/ChangePasswordModal';
import { useNavigate } from 'react-router-dom';

interface ProfileProps {
  companySettings?: any;
}

const Profile = ({ companySettings }: ProfileProps) => {
  const profile = useProfile();
  const [open, setOpen] = useState<boolean>(false);
  const [changePasswordOpen, setChangePasswordOpen] = useState<boolean>(false);
  const navigate = useNavigate();
  // Get company name or fallback to "At Your Request"
  const displayCompanyName = companySettings?.companyName || 'At Your Request';

  return (
    <Box
      sx={{
        width: '192px',
        borderRadius: '50px',
        backgroundColor: open ? '#01033D' : 'transparent',
        padding: 1,
        border: open ? '1px solid #3137FD' : '1px solid #2F3137',
        cursor: 'pointer',
        transition: 'all 0.2s ease-in-out',
        '&:hover': {
          backgroundColor: open ? '#01033D' : '#1C1E21',
          border: open ? '1px solid #3137FD' : '1px solid #2F3137',
        },
      }}
    >
      <Dropdown
        placement='bottomRight'
        menu={{
          style: {
            boxShadow: 'none',
            padding: 0,
          },
          items: ProfileMenuList.map(l => ({
            key: l.label,
            label: (
              <Stack
                direction='row'
                onClick={() => {
                  if (l.key === 'changePassword') {
                    setChangePasswordOpen(true);
                  } else if (l.onClick) {
                    l.onClick(navigate);
                  }
                  setOpen(false);
                }}
              >
                {l.icon}
                <Text
                  $type='xs'
                  weight='medium'
                  $css='line-height: 22px !important; padding: 2px 0px 2px 12px !important;'
                >
                  {l.label}
                </Text>
              </Stack>
            ),
          })),
        }}
        popupRender={menu => (
          <DropdownPopup
            marginTop={1}
            width={294}
            padding={0}
            maxHeight={'max-content'}
            rowGap='0px'
          >
            <Box sx={{ padding: 2 }}>
              <Row justify='space-between' align='middle'>
                <Col>
                  <Text
                    $type='xs'
                    weight='medium'
                    $css={`
                      font-family: Hanken Grotesk;
                      font-weight: 500;
                      font-size: 12px;
                      line-height: 18px;
                      letter-spacing: 0%;
                      text-align: center;
                      vertical-align: middle;
                    `}
                  >
                    User Profile
                  </Text>
                </Col>
                <Col>
                  <Stack
                    sx={{
                      border: '1px solid #D3D5D9',
                      borderRadius: '8px',
                      padding: '4px 8px',
                    }}
                  >
                    <Text
                      $type='xs'
                      weight='semibold'
                      $css={`
                        font-family: Hanken Grotesk;
                        font-weight: 600;
                        font-size: 12px;
                        line-height: 18px;
                      `}
                    >
                      {profile?.userRole?.role}
                    </Text>
                  </Stack>
                </Col>
              </Row>
              <Stack
                justifyContent='center'
                alignItems='center'
                paddingTop={1.5}
                paddingBottom={0}
              >
                <ProfileImage profile={profile} size='60px' />
                <Space
                  size={4}
                  direction='vertical'
                  $css={
                    'text-align: center; width: 100%; overflow: auto; padding-top: 12px;'
                  }
                >
                  <Text
                    $type='sm'
                    weight='semibold'
                    ellipsis
                    $css={`
                      font-family: Hanken Grotesk;
                      font-weight: 600;
                      font-size: 14px;
                      line-height: 20px;
                      letter-spacing: 0%;
                      text-align: center;
                    `}
                  >
                    {profile?.firstName} {profile?.lastName}
                  </Text>
                  <Text
                    color='#686D78'
                    $type='xs'
                    weight='semibold'
                    ellipsis
                    $css={`
                      font-family: Hanken Grotesk;
                      font-weight: 500;
                      font-size: 12px;
                      line-height: 18px;
                      letter-spacing: 0%;
                      text-align: center;
                      vertical-align: middle;
                    `}
                  >
                    {profile?.email}
                  </Text>
                  <Text
                    color='#686D78'
                    $type='xs'
                    weight='semibold'
                    ellipsis
                    $css={`
                      font-family: Hanken Grotesk;
                      font-weight: 500;
                      font-size: 12px;
                      line-height: 18px;
                      letter-spacing: 0%;
                      text-align: center;
                      vertical-align: middle;
                    `}
                  >
                    {displayCompanyName}
                  </Text>
                </Space>
              </Stack>
            </Box>
            <Box>
              <Divider $css={'margin: 0px;'} />
              {menu}
              <Divider $css={'margin: 0px;'} />
            </Box>
            <ProfileFooter />
          </DropdownPopup>
        )}
        trigger={['click']}
        onOpenChange={flag => setOpen(flag)}
        open={open}
      >
        <Stack direction='row' alignItems='center' spacing={1}>
          <ProfileImage profile={profile} />
          <Stack overflow='auto'>
            <Text $type='xs' weight='medium' ellipsis color='#FFFFFF'>
              {profile?.firstName} {profile?.lastName}
            </Text>
            <Text $type='xs' color='#A7AAB2' ellipsis>
              {displayCompanyName}
            </Text>
          </Stack>
          <ExpandMore sx={{ color: '#878B97' }} />
        </Stack>
      </Dropdown>
      <ChangePasswordModal
        open={changePasswordOpen}
        onClose={() => setChangePasswordOpen(false)}
      />
    </Box>
  );
};

export default Profile;
