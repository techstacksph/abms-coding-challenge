import React from 'react';

import { Space, Text } from '@/styled-components';

import { copyright } from '../../utils/string.utils';

const ProfileFooter = () => {
  return (
    <Space
      size={7}
      $css={'padding: 16px 16px 16px; width: 100%;'}
      direction='vertical'
    >
      <Text
        $type='xs'
        color='#686D78'
        $css={`
          font-family: Hanken Grotesk;
          font-weight: 400;
          font-size: 12px;
          line-height: 18px;
          letter-spacing: 0%;
          text-align: center;
          vertical-align: middle;
        `}
      >
        {copyright()}
      </Text>
    </Space>
  );
};

export default ProfileFooter;
