import React from 'react';

import { styled } from 'styled-components';

import { Link as RouterLink } from 'react-router-dom';

const StyledLink = styled(RouterLink)<{ $active?: boolean }>`
  padding: 8px 16px;
  border-radius: 8px;
  font-weight: 500;
  font-size: 14px;
  color: ${({ $active }) => ($active ? '#fff' : 'var(--gray-300)')} !important;

  text-decoration: none !important;

  &:hover {
    background-color: #f4f4f6;
  }
`;

const NavLink = ({
  to,
  label,
  $active,
}: {
  to: string;
  label: string;
  $active?: boolean;
}) => {
  return (
    <StyledLink to={to} $active={$active}>
      {label}
    </StyledLink>
  );
};

export default NavLink;
