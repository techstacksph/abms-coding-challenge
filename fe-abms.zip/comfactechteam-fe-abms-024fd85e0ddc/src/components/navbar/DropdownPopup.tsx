import React, { ReactNode } from 'react';

import { Space } from '@/styled-components';

import { Box, BoxProps, Paper } from '@mui/material';

const DropdownPopup = ({
  children,
  width = 458,
  padding = 2,
  maxHeight = 498,
  marginTop = 2,
  height,
  containerProps = {},
  rowGap,
}: {
  children?: ReactNode;
  width?: number;
  padding?: number;
  maxHeight?: number | any;
  marginTop?: number;
  height?: number;
  containerProps?: BoxProps;
  rowGap?: string;
}) => {
  let max = maxHeight;

  if (max) max = typeof max == 'string' ? max : `${max}px`;
  return (
    <Box
      component={Paper}
      {...containerProps}
      sx={{
        ...(height && { height: `${height}px` }),
        padding: padding,
        width: `${width}px`,
        maxHeight: max,
        marginTop: marginTop,
        boxShadow: `
          0 6px 16px 0 rgba(0, 0, 0, 0.08),
          0 3px 6px -4px rgba(0, 0, 0, 0.12), 
          0 9px 28px 8px rgba(0, 0, 0, 0.05)
        `,
        borderRadius: '8px',
        ...containerProps?.sx,
        gap: 0,
      }}
    >
      <Space
        direction='vertical'
        $css={`width: 100%; ${rowGap ? `row-gap: ${rowGap}` : ''}`}
      >
        {children}
      </Space>
    </Box>
  );
};

export default DropdownPopup;
