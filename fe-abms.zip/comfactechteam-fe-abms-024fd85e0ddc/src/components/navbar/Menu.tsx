import React, { useEffect, useState } from 'react';

import { MaterialIcon } from '@/styled-components';
import { styled } from 'styled-components';

import { Menu as AntMenu } from 'antd';

import { NavMenuList } from '../../constants/NavMenuList';
import NavLink from './NavLink';

const StyledMenu = styled(AntMenu)`
  height: 80px;
  border-bottom: none;
  width: 100%;
  max-width: 814px;
  background: none;

  & li {
    display: flex !important;
    justify-content: center;
    align-items: center;
    padding-inline: 8px !important;
  }

  @media (max-width: 768px) {
    max-width: none;
    height: 60px;

    & li {
      padding-inline: 2px !important;
      font-size: 12px;
    }
  }

  @media (max-width: 480px) {
    height: 50px;

    & li {
      padding-inline: 1px !important;
      font-size: 11px;
    }
  }

  & li.ant-menu-overflow-item.ant-menu-overflow-item-rest {
    color: #878b97 !important;
    width: 56px !important;
  }

  & li.theme-provider-menu-overflow-item-rest {
    width: 56px !important;
  }

  & li:hover span > a {
    color: #fff !important;
    background: #2f3137;
  }

  & li:hover::after {
    border-bottom-width: 4px !important;
    border-bottom-color: #3137fd !important;
  }

  & .ant-menu-item.ant-menu-item-active::after {
    border-bottom-width: 4px !important;
    border-bottom-color: #3137fd !important;
  }

  & li.ant-menu-overflow-item.ant-menu-overflow-item-rest {
    color: #878b97 !important;
    width: 56px !important;
  }

  & li.theme-provider-menu-overflow-item-rest {
    width: 56px !important;
  }

  & li.ant-menu-submenu-active::after {
    border: none !important;
  }
`;

const Menu = () => {
  const [selected, setSelected] = useState<string>(
    location.pathname.split('/')[1]
  );

  useEffect(() => {
    if (location.pathname.split('/')[1] != selected) {
      setSelected(location.pathname.split('/')[1]);
    }
  }, [location.pathname]);

  const menuItems = NavMenuList.map(item => ({
    key: item.key,
    label: (
      <NavLink
        to={item.path}
        label={item.label}
        $active={selected === item.key}
      />
    ),
  }));

  return (
    <StyledMenu
      theme='light'
      mode='horizontal'
      items={menuItems}
      overflowedIndicator={
        <MaterialIcon name='more_horiz' $css='color: var(--gray-300);' />
      }
      selectedKeys={[selected]}
      onSelect={({ key }) => setSelected(key)}
    />
  );
};

export default Menu;
