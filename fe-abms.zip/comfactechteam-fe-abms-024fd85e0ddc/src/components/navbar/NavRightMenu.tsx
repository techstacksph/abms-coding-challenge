import React from 'react';

import { Button, Icon, MaterialIcon } from '@/styled-components';

// import { getListRoute } from '@/mfe-utilities';
import { Stack } from '@mui/material';
import { useNavigate } from 'react-router-dom';

import Notification from './menuItem/Notification';
import Profile from './menuItem/Profile';
import QuickAdd from './menuItem/QuickAdd';
import Search from './menuItem/Search';

interface NavRightMenuProps {
  companySettings?: any;
}

const NavRightMenu = ({ companySettings }: NavRightMenuProps) => {
  const navigate = useNavigate();
  const isSettings = location.pathname.split('/')[1] == 'settings';

  return (
    <Stack
      direction='row'
      spacing={1.5}
      alignItems='center'
      justifyContent='flex-end'
    >
      <Search />
      <Notification />
      <Button
        type='text'
        shape='circle'
        icon={
          <Icon size='reg' color={isSettings ? '#3137FD' : '#7B8B99'}>
            <MaterialIcon name='settings' />
          </Icon>
        }
        size='large'
        $css={`
          min-width: 40px !important;
          width: 40px !important;
          &:hover {
            background-color: #2F3137 !important;
          }
          ${isSettings ? 'background-color: #F0F3FF;' : undefined}
          &:hover span {
            color: #fff !important;
          }
        `}
        onClick={() => navigate('/settings/users')}
      />
      <QuickAdd />
      <Profile companySettings={companySettings} />
    </Stack>
  );
};

export default NavRightMenu;
