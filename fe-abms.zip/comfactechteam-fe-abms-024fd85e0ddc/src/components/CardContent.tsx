import React from 'react';

import { Text } from '@/styled-components';
import styled from 'styled-components';

import { Space, Card, Col, Row } from 'antd';

interface IconContainerProps {
  bgColor?: string;
  color?: string;
}

const IconContainer = styled.div<IconContainerProps>`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: ${props => props.bgColor || '#f0f0f0'};
  color: ${props => props.color || '#000'};
  display: flex;
  align-items: center;
  justify-content: center;
`;

const CardStyled = styled(Card)`
  border: 1px solid #d3d5d9;

  .ant-card-body {
    padding: 12px 20px;
  }
  :where(.css-dev-only-do-not-override-i0102m).ant-space-gap-row-small {
    row-gap: 4px;
  }
`;

const CardContent = ({ gutter, span, contents }) => {
  return (
    <>
      <Row gutter={gutter}>
        {contents &&
          contents.map((content, i) => (
            <Col span={span} key={i}>
              <CardStyled size='small'>
                <Row align='middle'>
                  <Col flex='auto'>
                    <Space direction='vertical'>
                      <Text style={{ fontSize: 12 }}>{content.title}</Text>
                      <Text style={{ fontSize: 24, fontWeight: 500 }}>
                        {content.value}
                      </Text>
                    </Space>
                  </Col>
                  <Col>
                    <Space direction='vertical' align='end'>
                      <IconContainer
                        bgColor={content.icon.background}
                        color={content.icon.color}
                      >
                        {content.icon.icon}
                      </IconContainer>
                    </Space>
                  </Col>
                </Row>
              </CardStyled>
            </Col>
          ))}
      </Row>
    </>
  );
};

export default CardContent;
