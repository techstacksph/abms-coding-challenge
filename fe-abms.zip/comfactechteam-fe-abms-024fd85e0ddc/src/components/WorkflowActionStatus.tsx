import React from 'react';

import { Badge, Text } from '@/styled-components';

import { Stack } from '@mui/material';

const WorkflowActionsStatus = ({ color, text }) => {
  return (
    <Stack direction='row' spacing={1}>
      <Badge dot color={color} />
      <Text>{text}</Text>
    </Stack>
  );
};

export default WorkflowActionsStatus;
