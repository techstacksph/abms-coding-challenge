import React, { ComponentProps } from 'react';

import { Icon, NoProfileImg } from '@/styled-components';
import { styled } from 'styled-components';

import { Box } from '@mui/material';

const StyledBox = styled(Box)<{ size?: string; $css?: string }>`
  background: var(--gray-0);

  width: 80px;
  height: 80px;
  margin: 10px;
  border-radius: 50%;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  ${({ size }) =>
    size &&
    `
    width: ${typeof size == 'string' ? size : `${size}px`} !important;
    height: ${typeof size == 'string' ? size : `${size}px`} !important;
  `}

  ${({ $css }) => $css}
`;

const ProfileIcon = (
  props: ComponentProps<typeof Box> & { size?: string; $css?: string }
) => {
  const size = props?.size || '48';

  return (
    <StyledBox {...props}>
      <Icon size={size} color='#A7AAB2'>
        <NoProfileImg size={80} />
      </Icon>
    </StyledBox>
  );
};

export default ProfileIcon;
