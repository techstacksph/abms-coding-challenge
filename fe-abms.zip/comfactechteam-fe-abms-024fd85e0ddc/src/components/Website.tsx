import React from 'react';

import { Text, MaterialIcon } from '@/styled-components';
import styled from 'styled-components';

import { Tag } from 'antd';

const StyledTag = styled(Tag)<{ $css?: string }>`
  & {
    padding: 4px 8px;
    border-radius: 8px;
    width: max-content;
    background: #fff;
  }

  &:hover {
    cursor: pointer;
    background: #f4f4f6;
  }

  ${({ $css }) => $css}
`;

const Website = ({ data }) => {
  return (
    <StyledTag
      icon={
        <MaterialIcon
          name='link'
          $css={`
            color: #878B97;
            margin-right: 4px; 
            font-size: 16px
          `}
        />
      }
    >
      <Text $type='xs' weight='semibold' color='#090A0B'>
        {data}
      </Text>
    </StyledTag>
  );
};

export default Website;
