import React from 'react';

import { Form, FormInput, Text } from '@/styled-components';

import { Stack } from '@mui/material';

import { FormInstance } from 'antd';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const ChangePasswordForm = ({
  form,
  onFinish,
}: {
  form?: FormInstance;
  onFinish?: any;
}) => {
  return (
    <Form form={form} onFinish={onFinish}>
      <FormInput
        field={{
          title: 'Old Password',
          field: 'oldPassword',
          type: 'password',
          required: true,
          props: {
            labelCol: {
              span: 24,
            },
          },
          inputProps: {
            placeholder: 'Enter your old password',
          },
          rules: [
            {
              required: true,
              message: 'Please enter your old password',
            },
          ],
        }}
      />
      <FormInput
        field={{
          title: 'New Password',
          field: 'newPassword',
          type: 'password',
          required: true,
          props: {
            labelCol: {
              span: 24,
            },
          },
          inputProps: {
            placeholder: 'Enter your new password',
          },
          rules: [
            {
              required: true,
              message: 'Please enter your new password',
            },
            {
              pattern: new RegExp(/^(?=.*[A-Z])(?=.*\d)/g),
              message: 'Wrong format',
            },
            {
              min: 8,
              message: 'Password must be minimum 8 characters.',
            },
          ],
        }}
      />
      <FormInput
        field={{
          title: 'Confirm new Password',
          field: 'confirmPassword',
          type: 'password',
          required: true,
          props: {
            labelCol: {
              span: 24,
            },
          },
          inputProps: {
            placeholder: 'Confirm your new password',
          },
          dependencies: ['newPassword'],
          rules: [
            {
              required: true,
              message: 'Please confirm your new password',
            },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue('newPassword') === value) {
                  return Promise.resolve();
                }
                return Promise.reject(
                  new Error('The new password that you entered do not match')
                );
              },
            }),
          ],
        }}
      />
      {/* <Stack
        p={1.5}
        sx={{ border: '1px solid #F0F4F8', borderRadius: 2 }}
        spacing={1.25}
      >
        <Text>Your new password must contain:</Text>
        <Text color={'#969FAE'}>
          <Icon size={15}>
            <CheckOutlined />
          </Icon>{' '}
          At least 8 characters
        </Text>
        <Text color="#969FAE">
          <Icon size={15}>
            <CheckOutlined />
          </Icon>{' '}
          At least 1 uppercase letter
        </Text>
        <Text color="#969FAE">
          <Icon size={15}>
            <CheckOutlined />
          </Icon>{' '}
          At least 1 number
        </Text>
      </Stack> */}
      <Stack spacing={1.25} border='1px solid #F0F4F8' p={1.5}>
        <Text>Your new password must contain:</Text>
      </Stack>
    </Form>
  );
};

export default ChangePasswordForm;
