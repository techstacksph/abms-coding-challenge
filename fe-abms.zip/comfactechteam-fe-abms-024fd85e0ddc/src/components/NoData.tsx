import React from 'react';

import { Text } from '@/styled-components';

const truncateText = (text, maxLength = 125) => {
  if (text.length > maxLength) {
    return text.substring(0, maxLength) + '...';
  }
  return text;
};

const NoData = () => {
  return <Text color='var(--table-no-data)'>No data</Text>;
};

export default NoData;

export const NoDataRenderer = ({ content, alter = <NoData /> }) => {
  return ['', null, undefined].includes(content) ||
    (typeof content === 'string' && content?.trim() === '')
    ? alter
    : content;
};

export const NoDataOrElipsis = ({ content, maxLength = 125 }) => {
  return ['', null, undefined].includes(content) ||
    (typeof content === 'string' && content?.trim() === '') ? (
    <NoData />
  ) : (
    truncateText(content, maxLength)
  );
};
