import React, { memo } from 'react';

import { Button } from '@/styled-components';

import useNavigate from '@/hooks/useNavigate';
import { Stack } from '@mui/material';
import { ModulePageFormType } from '@/typings/module.types';
import { useRecordLockContextSafe } from '@/contexts/RecordLockContext';

const FormButtons = ({
  formType,
  saveButtonProps,
  saveAsDraftButtonProps,
  type,
  displaySaveBtn = true,
  displaySaveAsDraftBtn = false,
  saveBtnText = 'Save',
  backBtnText = 'Cancel',
  onBackClick,
  cancelButtonCss = '',
  saveButtonCss = '',
  cancelButtonProps,
}: {
  formType?: ModulePageFormType;
  saveButtonProps?: React.ComponentProps<typeof Button>;
  saveAsDraftButtonProps?: React.ComponentProps<typeof Button>;
  type: 'header' | 'footer';
  displaySaveBtn?: boolean;
  displaySaveAsDraftBtn?: boolean;
  saveBtnText?: string;
  backBtnText?: string;
  onBackClick?: any;
  cancelButtonCss?: string;
  saveButtonCss?: string;
  cancelButtonProps?: React.ComponentProps<typeof Button>;
}) => {
  const { back } = useNavigate(formType);

  // Safely get lock info from context if available
  // Will be null if not wrapped in RecordLockProvider (some forms don't use record locking)
  const lockContext = useRecordLockContextSafe();
  const canEdit = lockContext?.canEdit ?? true; // Default to true if no lock context

  return (
    <Stack
      direction='row'
      spacing={2.5}
      justifyContent='flex-end'
      pb={type == 'footer' ? 2.5 : 0}
    >
      <Button
        ghost
        $css={`
          width: 120px;
          color: #686D78 !important;
          border-color: #A7AAB2 !important;
          font-weight: 600;
          background: #FFFFFF !important;
          line-height: 20px;
          ${cancelButtonCss}
        `}
        onClick={onBackClick ? onBackClick : back}
        {...cancelButtonProps}
        data-cy={`${type}-form-cancel`}
        data-testid={`${type}-form-cancel-button`}
      >
        {backBtnText}
      </Button>
      {displaySaveAsDraftBtn && (
        <Button
          ghost
          htmlType='submit'
          $css={`
            width: 120px;
            color: #686D78 !important;
            border-color: #A7AAB2 !important;
            font-weight: 600;
            background: #FFFFFF !important;
            line-height: 20px;
          `}
          {...saveAsDraftButtonProps}
          data-cy={`${type}-form-submit-draft`}
          data-testid={`${type}-form-save-draft-button`}
        >
          Save as draft
        </Button>
      )}
      {displaySaveBtn && (
        <Button
          type='primary'
          htmlType='submit'
          disabled={!canEdit}
          $css={`
            width: 120px;
            border: 1px solid #3137FD !important;
            font-weight: 600;
            line-height: 20px;
            ${saveButtonCss}
          `}
          {...saveButtonProps}
          data-cy={`${type}-form-submit`}
          data-testid={`${type}-form-save-button`}
        >
          {saveBtnText}
        </Button>
      )}
    </Stack>
  );
};

export default memo(FormButtons);
