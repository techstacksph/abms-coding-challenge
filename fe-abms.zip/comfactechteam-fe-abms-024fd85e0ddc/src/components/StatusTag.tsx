import React, { ReactNode } from 'react';

import {
  StatusTag as BaseStatusTag,
  Text,
  GoogleIcon,
} from '@/styled-components';

import { Status } from '@/constants/Status';
import { Stack } from '@mui/material';
import { toSentenceCase } from '@/utils/helper.utils';

const StatusTag = ({
  status = Status.ACTIVE,
  customBadge,
  $css,
  hasLabel,
  labelName = 'Status',
  isDeal,
  customColor,
  isPoItems = false,
  isTraining = false,
  variant = 'filled',
  isBusinessForSale = false,
}: {
  status: Status | string;
  customBadge?: ReactNode;
  $css?: string;
  hasLabel?: boolean;
  labelName?: string;
  isDeal?: boolean;
  customColor?: string;
  isPoItems?: boolean;
  isTraining?: boolean;
  variant?: 'outlined' | 'filled';
  isBusinessForSale?: boolean;
}) => {
  let color;
  let icon = customBadge;
  const normalizedStatus = status.replace(/\s+/g, '').toUpperCase();
  let label = toSentenceCase(status);

  if (normalizedStatus === Status.REVIEW_IN_PROGRESS) {
    label = 'Review in-progress';
  } else if (status === Status.IN_PROGRESS) {
    label = 'In progress';
  } else if (status === Status.ON_HOLD) {
    label = 'On hold';
  } else if (status === Status.FOR_SALE) {
    label = 'For sale';
  } else {
    label = label
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  switch (normalizedStatus) {
    case Status.COMPLETED:
    case Status.COMPLETE:
    case Status.ACTIVE:
    case Status.AMEND:
    case Status.RIGHT:
    case Status.ACTIVE_AND_SIGNED:
    case Status.PASSED:
      color = '#31D48B';
      break;
    case Status.REVIEW_IN_PROGRESS:
      color = '#D576F0';
      break;
    case Status.CREATED:
      color = '#f9b61d';
      break;
    case Status.SENT_AND_APPROVED:
      icon = (
        <GoogleIcon
          name='check'
          $css={'color:#31D48B; font-size:16px;'}
          fill={true}
        />
      );
      color = '#3137FD';
      label = 'Sent & Approved';
      break;
    case Status.SENT:
      icon = (
        <GoogleIcon
          name='check'
          $css={'color:#31D48B; font-size:16px;'}
          fill={true}
        />
      );
      color = '#3137FD';
      break;
    case Status.INACTIVE:
      color = 'var(--gray-400)';
      break;
    case Status.OPEN:
      color = '#A7AAB2';
      break;
    case Status.CANCELLED:
    case Status.CANCEL:
      color = '#EA3927';
      break;
    case Status.REVIEWED:
      color = '#D576F0';
      break;
    case Status.ALLOCATED:
      color = '#7793FF';
      break;
    case Status.ALLOCATE:
      color = '#7793FF';
      break;
    case Status.PENDING:
      color = isDeal ? '#3137FD' : '#f9b61d';
      break;
    case Status.APPROVED:
      color = isPoItems ? '#3137FD  ' : '#31D48B';
      break;
    case Status.DISAPPROVED:
      color = '#EA3927';
      break;
    case Status.WRONG:
      color = '#EA3927';
      break;
    case Status.CLOSED_LOST:
      color = '#EA3927';
      break;
    case Status.CLOSED_WON:
      color = '#31D48B';
      break;
    case Status.IN_PROGRESS:
      color = isTraining ? '#F79009' : '#00F5F5';
      break;
    case Status.IN_PROGRESS2:
      color = '#52D2FC';
      break;
    case Status.EXPIRED:
      color = '#EA3927';
      break;
    case Status.NEW:
      color = '#FDB61C';
      break;
    case Status.FOR_SALE:
      color = '#FDB61C';
      break;
    case Status.QUALIFIED:
      color = '#7793FF';
      break;
    case Status.UNQUALIFIED:
      color = '#E76B36';
      break;
    case Status.OVERDUE:
      color = '#EA3927';
      break;
    case Status.AWAITING_PAYMENT:
      color = '#FDB61C';
      break;
    case Status.PAYMENT_IN_PROGRESS:
      color = '#7793FF';
      break;
    case Status.DELETED:
    case Status.SENT_AND_REJECTED:
      icon = (
        <GoogleIcon
          name='close'
          $css={'color:#EA3927; font-size:16px;'}
          fill={true}
        />
      );
      label = 'Sent & Rejected';
      color = '#EA3927';
      break;
    case Status.DRAFT:
      color = '#A7AAB2';
      break;
    case Status.VOID:
      color = '#D576F0';
      break;
    case Status.VOIDED:
      color = '#D576F0';
      break;
    case Status.PAID:
      color = '#31D48B';
      break;
    case Status.EXPORTED:
      color = '#7793FF';
      label = 'Exported to Xero';
      break;
    case Status.EXPORTED_TO_XERO:
      color = '#7793FF';
      label = 'Exported to Xero';
      break;
    case Status.REJECTED:
    case 'REJECTED':
      color = '#EA3927';
      label = 'Rejected';
      break;
    case Status.SENT_TO_SUPPLIER:
    case 'SENTTOSUPPLIER':
    case 'SENT TO SUPPLIER':
      color = isPoItems ? '#7793FF' : '#3137FD';
      variant = 'outlined';
      label = 'Sent to supplier';
      break;
    case 'START':
      color = '#31D48B';
      break;
    case 'END':
      color = '#3137FD';
      break;
    case 'PAUSE':
      color = '#f9b61d';
      break;
    case 'RESUME':
      color = '#D576F0';
      break;
    case 'SUBMITTED':
      color = '#7793FF';
      break;
    case 'SOLD':
      color = '#31D48B';
      break;
    case Status.ONGOING:
      color = '#FDB61C';
      break;
    case 'READYFORPICK-UP':
    case 'READY_FOR_PICK-UP':
    case 'READY FOR PICK-UP':
      color = '#D576F0';
      label = 'Ready for pick-up';
      break;
    case 'DELIVERYIN-PROGRESS':
    case 'DELIVERY_IN-PROGRESS':
    case 'DELIVERY IN-PROGRESS':
      color = '#3137FD';
      label = 'Delivery in-progress';
      break;
    case 'WITHDR':
      color = '#bd0074ff';
      label = 'With DR';
      break;
    case Status.DELIVERED:
    case 'DELIVERED':
      color = '#00c84dff';
      label = 'Delivered';
      break;
    case Status.PARTIALLY_DELIVERED:
    case 'PARTIALLYDELIVERED':
      color = '#c8c800ff';
      label = 'Partially delivered';
      break;
    case Status.RETURNED:
    case 'RETURNED':
      color = '#31D48B';
      variant = 'outlined';
      label = 'Returned';
      break;
    case Status.ON_QUEUE:
    case 'ON_QUEUE':
    case 'ONQUEUE':
      color = '#F79009';
      label = 'On queue';
      break;
    case Status.FAILED:
    case 'FAILED':
      color = '#EA3927';
      label = 'Failed';
      break;
    default:
      color = '#586C7F';
      break;
    case 'DECLINED':
      if (isBusinessForSale) {
        color = '#E76B36';
        label = 'Declined';
      }
      break;
    case 'ACCEPTED':
      if (isBusinessForSale) {
        color = '#31D48B';
        label = 'Accepted';
      }
      break;
  }

  const renderStatusTag = () => (
    <BaseStatusTag
      $css={$css}
      color={customColor || color}
      label={label}
      customBadge={icon ? icon : customBadge}
      variant={variant}
    />
  );

  return (
    <>
      {hasLabel ? (
        <Stack direction={'row'} spacing={1} alignItems='center'>
          <Text
            $type='sm'
            weight='bold'
            $css={
              'font-weight: 400; font-size: 14px !important; color: var(--color-text-secondary)'
            }
          >
            {labelName}
          </Text>
          {renderStatusTag()}
        </Stack>
      ) : (
        renderStatusTag()
      )}
    </>
  );
};

export default StatusTag;
