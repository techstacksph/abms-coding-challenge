import React, { memo } from 'react';

import { Icon, Text, GoogleIcon } from '@/styled-components';

import Link from '@/components/Link';
import { getListRoute } from '@/mfe-utilities';
import { Box, Stack } from '@mui/material';

const ListEventItems = ({
  data,
  dataKey,
}: {
  data: Array<any>;
  dataKey: string | Array<string>;
}) => {
  return (
    <Stack justifyContent='space-between' marginTop={'16px'} maxWidth='500px'>
      <Text $type='sm' color='var(--color-text-secondary)'>
        Events
      </Text>
      <Box
        maxHeight='200px'
        overflow='auto'
        sx={{
          overflowX: 'hidden',
          '&::-webkit-scrollbar': {
            width: '16px',
            backgroundColor: 'transparent',
          },

          '&::-webkit-scrollbar-track': {
            backgroundColor: 'transparent',
            borderLeft: '1px solid #D3D5D9',
            borderRight: '1px solid #D3D5D9',
          },

          '&::-webkit-scrollbar-thumb': {
            background: 'rgba(167, 170, 178, 0.5)',
            borderRadius: '24px',
            border: '4px solid transparent',
            width: '4px',
            backgroundClip: 'padding-box',
          },

          scrollbarWidth: 'medium',
          scrollbarColor: 'rgba(167, 170, 178, 0.5) transparent',
        }}
      >
        {data &&
          data?.map((event: any & { id: string }) => (
            <Stack
              key={event.id}
              direction='row'
              spacing={1}
              alignItems='center'
              borderRadius={2}
              px={0.5}
              py={1}
            >
              <Box
                sx={{
                  width: 24,
                  height: 24,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  backgroundColor: '#F4F4F6',
                  borderRadius: 1,
                }}
              >
                <Icon size='sm' color='var(--gray-400)'>
                  <GoogleIcon
                    name='event'
                    $css={`
                       vertical-align: middle;
                       font-size: 18px;
                       color: rgba(135, 139, 151, 1);
                     `}
                  />
                </Icon>
              </Box>
              <Text
                $type='sm'
                color='#3137FD'
                $css={`
                  cursor: pointer;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  display: block;
                  min-width: 0;
                  font-weight: 500 !important;
                `}
              >
                <Link
                  $css={{ fontWeight: 500 }}
                  to={`${getListRoute('Events')}/${event?.id}`}
                >
                  {Array.isArray(dataKey)
                    ? dataKey.map(k => event[k]).join(' ')
                    : event[dataKey]}
                </Link>
              </Text>
            </Stack>
          ))}
      </Box>
    </Stack>
  );
};

export default memo(ListEventItems);
