export { default, VariantTypeQuickCreate } from './VariantTypeQuickCreate';
