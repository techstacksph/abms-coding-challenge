import React from 'react';

import {
  FormSection,
  Icon,
  MaterialIcon,
  Form,
  useModal,
  FormButtons,
} from '@/styled-components';

import { CREATE_VARIANTS } from '@/graphql/variants.gql';
import useMutation from '@/hooks/useMutation';
import VariantsModel from '@/models/VariantsModel';
import { Box } from '@mui/material';
import { labelSpan, required } from '@/utils/inputProps.util';
import { errorMessages } from '@/utils/messages.utils';

import { Form as AntdForm } from 'antd';

// Variant type fields for the quick create form
const variantTypeFields = {
  title: '',
  showDivider: false,
  fields: [
    {
      title: 'Variant',
      type: 'text',
      field: 'name',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      maxLength: 100,
    },
    {
      title: 'Code',
      type: 'text',
      field: 'code',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      maxLength: 100,
    },
    {
      title: 'Description',
      type: 'textarea',
      field: 'description',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      inputProps: {
        autoSize: {
          minRows: 3,
        },
      },
    },
  ],
};

export const VariantTypeQuickCreate = ({
  handleSuccess,
}: {
  handleSuccess?: (val: VariantsModel) => void;
}) => {
  const [form] = AntdForm.useForm();

  const [createVariantType] = useMutation({
    query: CREATE_VARIANTS,
    successMessage: 'Variant type created successfully.',
    onSuccess: (value: VariantsModel) => {
      if (handleSuccess) {
        handleSuccess(value);
      }
      closeModal();
      form.resetFields();
    },
    onError: err => {
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      const field = graphQLError?.extensions.field;

      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        form.setFields([
          {
            name: field,
            errors: [errorMessages.UNIQUE_FIELD],
          },
        ]);
      }
      return;
    },
  });

  const onFinish = async values => {
    await createVariantType({
      variables: {
        variant: {
          ...values,
        },
      },
    });
  };

  // Complete cleanup function
  const performCompleteCleanup = () => {
    // Reset form completely
    form.resetFields();

    // Clear all form field errors
    const currentFields = form.getFieldsValue();
    if (currentFields && typeof currentFields === 'object') {
      form.setFields(
        Object.keys(currentFields).map(fieldName => ({
          name: fieldName,
          errors: [],
        }))
      );
    }
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New variant type',
    message: (
      <Box sx={{ button: { width: 120 } }}>
        <Form form={form} onFinish={onFinish}>
          <FormSection fields={variantTypeFields} />
          <FormButtons
            saveAsDraft={false}
            onCancel={() => {
              performCompleteCleanup();
              closeModal();
            }}
            submitText='Save'
          />
        </Form>
      </Box>
    ),
    modalProps: {
      modalProps: {
        footer: null,
        onCancel: () => {
          performCompleteCleanup();
          closeModal();
        },
      },
    },
  });

  const handleOpenModal = () => {
    // Perform complete cleanup
    performCompleteCleanup();

    // Open modal
    setTimeout(() => {
      openModal();
    }, 50);
  };

  return (
    <>
      {contextModal}
      <Box
        sx={{
          color: 'rgba(49, 55, 253, 1)',
          backgroundColor: '#FFFFFF',
          width: '40px',
          height: '40px',
          border: '1px solid rgba(49, 55, 253, 1)',
          padding: '8px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: '8px',
          marginTop: '28px',
          marginLeft: '15px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
            cursor: 'pointer',
          },
        }}
        onClick={handleOpenModal}
      >
        <Icon $css='rotate: -90deg;'>
          <MaterialIcon iconClass='material-icons' name='add' />
        </Icon>
      </Box>
    </>
  );
};

export default VariantTypeQuickCreate;
