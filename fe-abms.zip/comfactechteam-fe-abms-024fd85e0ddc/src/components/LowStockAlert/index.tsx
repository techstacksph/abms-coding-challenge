import React, { useMemo, useState, useRef, useEffect } from 'react';
import { gql } from '@apollo/client';
import { Checkbox } from 'antd';
import styled from 'styled-components';
import {
  CloseOutlined,
  PlusOutlined,
  MinusOutlined,
  LeftOutlined,
  RightOutlined,
} from '@ant-design/icons';
import {
  useModal,
  Button,
  Text,
  MaterialIcon,
  GoogleIcon,
  useSnackbar,
} from '@/styled-components';
import useQuery from '@/hooks/useQuery';
import environment from '@/config/environment';
import { Stack, Box, Avatar } from '@mui/material';
import { formatCurrency } from '@/utils/helper.utils';

const TENANT_PREFIX = environment.TENANT_PREFIX;

// Custom query to fetch items with pricing and stock levels
const LOW_STOCK_QUERY = gql`
  query ${TENANT_PREFIX}lowStockItems {
    ${TENANT_PREFIX}warehouseItems {
      id
      warehouseId
      itemId
      stockOnHand
      minimumLevel
      warehouse {
        id
        name
      }
      item {
        id
        name
        pricing
        itemCode
        productImage
      }
    }
  }
`;

const renderProductImage = (images?: string | string[]) => {
  if (!images) return '';
  if (typeof images === 'string') return images;
  if (Array.isArray(images) && images.length > 0) {
    if (images[0].includes('base64') && images.length > 1) {
      return `${images[0]},${images[1].trim()}`;
    }
    return images[0];
  }
  return '';
};

const AlertButton = styled.div`
  display: flex;
  align-items: center;
  padding: 12px;
  background: #ffffff;
  border: 2px solid #f6a194;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  gap: 12px;
  height: 74px;
  min-width: 216px;

  &:hover {
    border-color: #ea3927;
  }
`;

const ImageGrid = styled.div<{ count: number }>`
  display: grid;
  width: 40px;
  height: 40px;
  gap: 2px;
  overflow: hidden;
  background: #fff;
  flex-shrink: 0;
  border-radius: 4px;

  ${({ count }) => {
    if (count <= 1)
      return 'grid-template-columns: 1fr; grid-template-rows: 1fr;';
    if (count === 2)
      return 'grid-template-columns: 1fr 1fr; grid-template-rows: 1fr;';
    if (count === 3)
      return 'grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr;';
    return 'grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr;';
  }}

  & > *:first-child {
    ${({ count }) => count === 3 && 'grid-row: span 2;'}
  }
`;

const GridImageContainer = styled.div`
  width: 100%;
  height: 100%;
  background-color: #f5f5f5;
  border-radius: 2px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const GridIconContainer = styled.div`
  width: 100%;
  height: 100%;
  background-color: #e9eaec;
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const GridImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 2px;
  overflow: hidden;
  display: block;
`;

const TextContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2px;
`;

const IconWrapper = styled.div`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: #fdf3f1;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: auto;
  flex-shrink: 0;

  svg {
    font-size: 18px;
  }
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  padding-right: 0px;
`;

const ModalTitle = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

const CloseButton = styled.div`
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
  color: #595959;

  &:hover {
    background: #f5f5f5;
    color: #1f1f1f;
  }
`;

const ItemsContainer = styled.div`
  max-height: 550px;
  overflow-y: auto;

  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: #e8e8e8;
    border-radius: 10px;
  }
`;

const WarehouseTitle = styled.div`
  background: #e9eaec;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  height: 44px;
`;

const ItemRow = styled.div<{ selected?: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: ${props => (props.selected ? '#eff6ff' : '#ffffff')};
  border-radius: 8px;
  transition: all 0.2s;
  cursor: pointer;

  &:hover {
    background: ${props => (props.selected ? '#eff6ff' : '#fafafa')};
  }
`;

const ItemLeftContent = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
  flex: 1;
`;

const ItemText = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const CounterWrapper = styled.div`
  display: flex;
  align-items: center;
  background: #ffffff;
  border: 1px solid #bec0c6;
  border-radius: 6px;
  overflow: hidden;
  height: 40px;
`;

const CounterButton = styled.div`
  width: 40px;
  height: 40px !important;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
  background: #fff;

  &:hover {
    background: #f5f5f5;
    color: #1f1f1f;
  }

  &.disabled {
    color: #bfbfbf;
    cursor: not-allowed;
    &:hover {
      background: #fff;
    }
  }
`;

const CounterInput = styled.input`
  width: 48px;
  height: 40px !important;
  height: 100%;
  border: none;
  border-left: 1px solid #bec0c6;
  border-right: 1px solid #bec0c6;
  text-align: center;
  font-size: 14px;
  font-weight: 400;
  outline: none;
  font-style: Hanken Grotesk;
  color: #131933;

  &::-webkit-inner-spin-button,
  &::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;

const ModalFooter = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 24px;
  border-top: 1px solid #f0f0f0;
`;

const PaginationContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
`;

const PaginationControls = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
`;

const PaginationButton = styled.button`
  border: none;
  background: transparent;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #7b8b99;
  padding: 8px;
  border-radius: 6px;
  transition: all 0.2s;

  &:hover:not(:disabled) {
    background: #f5f5f5;
    color: #7b8b99;
  }

  &:disabled {
    color: #bfbfbf;
    cursor: not-allowed;
  }
`;

interface LowStockItem {
  id: string;
  warehouseId: string;
  itemId: string;
  stockOnHand: number;
  minimumLevel: number;
  warehouse: {
    id: string;
    name: string;
  };
  item: {
    id: string;
    name: string;
    pricing: number;
    itemCode: string;
    productImage?: string[];
  };
  reorderQuantity: number;
}

const GridImageWithFallback: React.FC<{ src: string }> = ({ src }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  return (
    <GridImageContainer>
      {src && !imageError ? (
        <GridImage
          src={src}
          alt=''
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageError(true)}
          style={{ display: imageLoaded ? 'block' : 'none' }}
        />
      ) : null}
      {(!src || imageError) && (
        <GoogleIcon name='hide_image' $css='color: #B8BCC6; font-size: 8px;' />
      )}
    </GridImageContainer>
  );
};

const QuantityCounter: React.FC<{
  value: number;
  onChange: (val: number) => void;
}> = ({ value, onChange }) => {
  return (
    <CounterWrapper onClick={e => e.stopPropagation()}>
      <CounterButton
        className={value <= 1 ? 'disabled' : ''}
        onClick={() => value > 1 && onChange(value - 1)}
      >
        <MinusOutlined style={{ fontSize: 12, color: '#4C4F57' }} />
      </CounterButton>
      <CounterInput
        type='number'
        value={value}
        onChange={e => {
          const val = parseInt(e.target.value);
          if (!isNaN(val) && val >= 0) onChange(val);
        }}
        onClick={e => e.stopPropagation()}
      />
      <CounterButton onClick={() => onChange(value + 1)}>
        <PlusOutlined style={{ fontSize: 12, color: '#4C4F57' }} />
      </CounterButton>
    </CounterWrapper>
  );
};

// Helper component to format stock text like "1 left in stock"
// The number and "left" are red, "in stock" is gray.
const FormattedStockText: React.FC<{ count: number }> = ({ count }) => {
  return (
    <Text $css='font-size: 12px; font-weight: 400; line-height: 18px;'>
      <Text $css='color: #EA3927'>{count} left</Text>{' '}
      <Text $css='color: #090A0B'>in stock</Text>
    </Text>
  );
};

const LowStockAlert: React.FC = () => {
  const [selectedItems, setSelectedItems] = useState<
    Record<string, LowStockItem>
  >({});
  const [reorderQuantities, setReorderQuantities] = useState<
    Record<string, number>
  >({});
  const [page, setPage] = useState(1);
  const [modalOpen, setModalOpen] = useState(false);
  const pageSize = 10;
  const itemsContainerRef = useRef<HTMLDivElement>(null);

  const { snackbar } = useSnackbar();

  const handleAddToPORef = useRef<() => void>(null);

  const { data: rawData, refetch } = useQuery({
    query: LOW_STOCK_QUERY,
    options: {
      fetchPolicy: 'network-only',
    },
  });

  // Refetch data when modal opens to ensure fresh data
  useEffect(() => {
    if (modalOpen) {
      refetch();
    }
  }, [modalOpen, refetch]);

  const allLowStockItems: LowStockItem[] = useMemo(() => {
    const items = (rawData as any[]) || [];
    return items
      .filter((wi: any) => {
        return wi.minimumLevel != null && wi.stockOnHand <= wi.minimumLevel;
      })
      .map((wi: any) => ({
        ...wi,
        reorderQuantity: Math.max(wi.minimumLevel - wi.stockOnHand + 1, 1),
      }));
  }, [rawData]);

  const filteredItems = useMemo(() => {
    // Search functionality removed as requested, so just return sorted list
    const list = [...allLowStockItems];
    return list.sort((a, b) => {
      if (a.warehouse?.name < b.warehouse?.name) return -1;
      if (a.warehouse?.name > b.warehouse?.name) return 1;
      return a.item?.name.localeCompare(b.item?.name);
    });
  }, [allLowStockItems]);

  const totalItems = filteredItems.length;
  const totalPages = Math.ceil(totalItems / pageSize);

  // Reset page if out of bounds
  useEffect(() => {
    if (totalPages > 0 && page > totalPages) {
      setPage(totalPages);
    } else if (totalPages === 0 && page !== 1) {
      setPage(1);
    }
  }, [totalPages, page]);

  // Scroll to top on page change
  useEffect(() => {
    if (itemsContainerRef.current) {
      itemsContainerRef.current.scrollTop = 0;
    }
  }, [page]);

  const paginatedItems = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredItems.slice(start, start + pageSize);
  }, [filteredItems, page]);

  const groupedItems = useMemo(() => {
    const groups: Record<string, { name: string; items: LowStockItem[] }> = {};
    paginatedItems.forEach(item => {
      if (!groups[item.warehouseId]) {
        groups[item.warehouseId] = {
          name: item.warehouse?.name || 'Unknown Warehouse',
          items: [],
        };
      }
      groups[item.warehouseId].items.push(item);
    });
    return groups;
  }, [paginatedItems]);

  const toggleItemSelection = (item: LowStockItem) => {
    // Removed active restriction warning. Now allows mixed selection.
    setSelectedItems(prev => {
      const newSelected = { ...prev };
      if (newSelected[item.id]) {
        delete newSelected[item.id];
      } else {
        newSelected[item.id] = item;
      }
      return newSelected;
    });
  };

  const handleReorderQtyChange = (id: string, value: number) => {
    setReorderQuantities(prev => ({
      ...prev,
      [id]: value,
    }));
  };

  const handleModalCancel = () => {
    setSelectedItems({});
    setReorderQuantities({});
    setPage(1);
  };

  const [_openModal, _closeModal, contextModal] = useModal({
    title: null,
    message: (
      <Box sx={{ width: '100%' }}>
        <ModalHeader>
          <ModalTitle>
            <Text $css='font-size: 16px; font-weight: 600; color: #131933; line-height: 28px;'>
              Low stock alert
            </Text>
            <Text $css='font-size: 14px; font-weight: 400; color: #090A0B; line-height: 20px;'>
              Not enough stock on these items.
            </Text>
          </ModalTitle>
          <CloseButton onClick={() => closeModal()}>
            <CloseOutlined style={{ fontSize: 14, color: '#1C1B1F' }} />
          </CloseButton>
        </ModalHeader>

        <ItemsContainer ref={itemsContainerRef}>
          {Object.entries(groupedItems).map(([warehouseId, group]) => (
            <Box key={warehouseId}>
              <WarehouseTitle>
                <Text $css='font-size: 14px; font-weight: 500; color: #090A0B; line-height: 20px;'>
                  {group.name}
                </Text>
              </WarehouseTitle>
              {group.items.map(item => {
                const isSelected = !!selectedItems[item.id];
                const qty = reorderQuantities[item.id] || item.reorderQuantity;

                return (
                  <ItemRow
                    key={item.id}
                    selected={isSelected}
                    onClick={() => toggleItemSelection(item)}
                  >
                    <ItemLeftContent>
                      <Checkbox
                        checked={isSelected}
                        onClick={e => e.stopPropagation()}
                        onChange={() => toggleItemSelection(item)}
                        style={{ width: 20, height: 20, borderRadius: '2px' }}
                      />
                      <Avatar
                        src={renderProductImage(item.item.productImage)}
                        variant='rounded'
                        sx={{
                          width: 80,
                          height: 80,
                          bgcolor: '#E9EAEC',
                          borderRadius: '8px',
                        }}
                      >
                        <GoogleIcon
                          name='hide_image'
                          $css='color: #B8BCC6; font-size: 20px;'
                        />
                      </Avatar>
                      <ItemText>
                        <Text $css='font-size: 14px; font-weight: 700; color: #090A0B; line-height: 20px;'>
                          {item.item.name}
                        </Text>
                        <FormattedStockText count={item.stockOnHand} />
                        <Text $css='font-size: 14px; font-weight: 700; color: #090A0B; line-height: 20px;'>
                          {formatCurrency(item.item.pricing || 0)}
                        </Text>
                      </ItemText>
                    </ItemLeftContent>

                    {isSelected && (
                      <QuantityCounter
                        value={qty}
                        onChange={val => handleReorderQtyChange(item.id, val)}
                      />
                    )}
                  </ItemRow>
                );
              })}
            </Box>
          ))}
          {filteredItems.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Text color='secondary'>No low stock items found.</Text>
            </Box>
          )}
        </ItemsContainer>

        <ModalFooter>
          <PaginationContainer>
            <Text $css='font-size: 12px; font-weight: 400; color: #494F59; line-height: 18px;'>
              {totalItems > 0 ? (page - 1) * pageSize + 1 : 0}-
              {Math.min(page * pageSize, totalItems)} of {totalItems}
            </Text>
            <PaginationControls>
              <PaginationButton
                disabled={page <= 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
              >
                <LeftOutlined style={{ fontSize: 16 }} />
              </PaginationButton>
              <PaginationButton
                disabled={page >= totalPages}
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              >
                <RightOutlined style={{ fontSize: 16 }} />
              </PaginationButton>
            </PaginationControls>
          </PaginationContainer>

          <Stack direction='row' spacing={2}>
            <Button
              type='default'
              $css='border: 1px solid #BEC0C6; background: #ffffff; color: #717A89; font-weight: 500; border-radius: 8px; padding: 8px 12px; height: 40px; width: 120px;'
              onClick={() => closeModal()}
            >
              Cancel
            </Button>
            <Button
              type='primary'
              disabled={Object.keys(selectedItems).length === 0}
              onClick={() => handleAddToPORef.current?.()}
              $css='padding: 8px 12px; border-radius: 8px; font-weight: 500; display: flex; align-items: center; gap: 6px; background: #3137fd; height: 40px; width: 150px;'
            >
              <PlusOutlined style={{ fontSize: 14 }} />
              Purchase order
            </Button>
          </Stack>
        </ModalFooter>
      </Box>
    ),
    onCancel: handleModalCancel,
    modalProps: {
      modalProps: {
        width: 650,
        footer: null,
        destroyOnClose: true,
        closeIcon: null, // We implemented a custom close button
        centered: true,
        $css: '.theme-provider-modal-content { padding: 20px !important; }',
      },
    },
  });

  // Wrapped modal functions to handle state management
  const openModal = () => {
    setModalOpen(true);
    _openModal();
  };

  const closeModal = () => {
    setModalOpen(false);
    _closeModal();
  };

  const handleAddToPO = () => {
    const selectedList = Object.values(selectedItems);

    // Check for multiple warehouses
    const uniqueWarehouses = new Set(
      selectedList.map(item => item.warehouseId)
    );
    if (uniqueWarehouses.size > 1) {
      snackbar({
        type: 'error',
        message:
          'You can only create a purchase order for one warehouse at a time. To proceed, please deselect items from other warehouses or start a separate PO.',
      });
      return;
    }

    const itemsToOrder = selectedList.map(item => {
      return {
        itemId: item.item?.id,
        name: item.item?.name,
        quantity: reorderQuantities[item.id] || item.reorderQuantity,
        unitPrice: item.item?.pricing || 0,
      };
    });

    const params = new URLSearchParams();
    if (uniqueWarehouses.size === 1) {
      params.append('warehouseId', Array.from(uniqueWarehouses)[0]);
    }
    params.append('items', JSON.stringify(itemsToOrder));

    const url = `/purchasing&inventory/purchase-order/new?${params.toString()}`;
    window.open(url, '_blank');
    closeModal();
    handleModalCancel();
  };

  (handleAddToPORef as any).current = handleAddToPO;

  if (allLowStockItems.length === 0) {
    return null;
  }

  return (
    <>
      <AlertButton onClick={openModal}>
        <ImageGrid count={Math.min(allLowStockItems.length, 4)}>
          {allLowStockItems.slice(0, 4).map((item, index) => {
            const src = renderProductImage(item.item.productImage);
            return src ? (
              <GridImageWithFallback key={`${item.id}-${index}`} src={src} />
            ) : (
              <GridIconContainer key={`${item.id}-${index}`}>
                <GoogleIcon
                  name='hide_image'
                  $css='color: #B8BCC6; font-size: 8px;'
                />
              </GridIconContainer>
            );
          })}
        </ImageGrid>

        <TextContent>
          <Text $css='font-size: 14px; font-weight: 700; color: #090A0B; line-height: 20px;'>
            {allLowStockItems.length} items
          </Text>
          <Text $css='font-size: 14px; font-weight: 400; color: #EA3927; line-height: 20px;'>
            Low in stock
          </Text>
        </TextContent>

        <IconWrapper>
          <MaterialIcon
            name='trending_down'
            $css='font-size: 24px; color: #EA3927;'
          />
        </IconWrapper>
      </AlertButton>
      {contextModal}
    </>
  );
};

export default LowStockAlert;
