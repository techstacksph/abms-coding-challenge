import React from 'react';

import { Text } from '@/styled-components';
import Link from '@/components/Link';
import { ACTIVITIES_BY_MODULE } from '@/graphql/activities.gql';
import useQuery from '@/hooks/useQuery';
import ActivityModel from '@/models/ActivityModel';
import { formatToNZTime, dateFormat, formatDate2 } from '@/utils/date.utils';
import {
  relatedModuleFieldMap,
  ActivitySiteNotes,
} from '@/constants/Activities';
import { Box, Stack } from '@mui/material';
import { getViewRoute } from '@/mfe-utilities';
import dayjs from 'dayjs';
import { haveData, isValueValid } from '@/utils/helper.utils';
export const LAST_ACTIVITY = {
  EVENT_CREATED: 'event created',
  EVENT_COMPLETED: 'event completed',
  EVENT_CANCELLED: 'event cancelled',
  CALL_LOG_CREATED: 'call log created',
  TASK_CREATED: 'task created',
  QUALIFIED: 'qualified',
  UNQUALIFIED: 'unqualified',
};

interface LastActivityProps {
  siteId?: string;
  loading?: boolean;
  staticData?: {
    lastActivity?: string;
    activityDate?: string;
  };
}

interface LastActivityTextProps {
  accountId?: string;
  siteId?: string;
  staticData?: {
    lastActivity?: string;
    activityDate?: string | Date;
  };
}

const LastActivity: React.FC<LastActivityProps> = ({
  siteId,
  loading: externalLoading,
  staticData,
}) => {
  const { data: activities, loading: activitiesLoading } = useQuery<
    Array<ActivityModel>
  >({
    query: ACTIVITIES_BY_MODULE,
    options: {
      variables: {
        abmsrelatedRecordId: siteId,
        abmsrelatedRecordFieldName: relatedModuleFieldMap.site,
        abmssearchKeyword: '',
      },
      skip: !siteId || !!staticData,
    },
  });

  const loading = externalLoading || activitiesLoading;

  // Get the most recent activity
  const mostRecentActivity =
    activities && activities.length > 0 ? activities[0] : null;

  // Determine activity type and date
  const getActivityType = (activity: ActivityModel) => {
    if (!activity) return null;

    // Handle communication types
    if (activity.commType === 'Calls') return 'Call log created';
    if (activity.commType === 'Email') return 'Email sent';
    if (activity.commType === 'SMS') return 'SMS sent';
    if (activity.commType === 'Note' || !activity.commType) return 'Note added';

    return activity.commType;
  };

  // Map static activity types to display names
  const getActivityDisplayName = (activityType: string) => {
    if (!activityType) return null;

    // Map backend activity types to display names
    const activityTypeMap = {
      [ActivitySiteNotes.CLOSED_WON_QUOTE]: 'Closed won quote',
      [ActivitySiteNotes.JOB_ALLOCATED]: 'Job allocated',
      [ActivitySiteNotes.JOB_COMPLETED]: 'Job completed',
      [ActivitySiteNotes.JOB_CANCELLED]: 'Job cancelled',
      [ActivitySiteNotes.LEAD_CREATED]: 'Lead created',
      [ActivitySiteNotes.LEAD_QUALIFIED]: 'Lead qualified',
      [ActivitySiteNotes.LEAD_UNQUALIFIED]: 'Lead unqualified',
      'Call log created': 'Call log created',
      'Email sent': 'Email sent',
      'SMS sent': 'SMS sent',
      'Note added': 'Note added',
    };

    return activityTypeMap[activityType] || activityType;
  };

  const activityType = staticData?.lastActivity
    ? getActivityDisplayName(staticData.lastActivity)
    : getActivityType(mostRecentActivity);

  const activityDate =
    staticData?.activityDate ||
    (mostRecentActivity?.createdAt
      ? formatToNZTime(mostRecentActivity.createdAt, dateFormat)
      : null);

  return (
    <Stack
      sx={{
        border: '2px solid #F6A194',
        borderRadius: '8px',
        background: '#fff',
        maxWidth: 260,
        width: '198px',
        height: '76px',
        padding: '4px 12px',
      }}
      direction='column'
      justifyContent='center'
    >
      <Text
        weight='bold'
        color='var(--color-text-primary)'
        $css='font-size: 12px; line-height: 18px;'
      >
        Last activity
      </Text>
      <Text weight='medium' $css='font-size: 14px; line-height: 20px;'>
        {loading ? 'Loading...' : activityType || 'No activity'}
      </Text>
      <Text
        color='var(--color-text-secondary)'
        $css='font-size: 14px; line-height: 20px;'
      >
        {loading ? '' : activityDate || ''}
      </Text>
    </Stack>
  );
};

export default LastActivity;

export const LastActivityText = ({
  accountId,
  siteId,
  staticData,
}: LastActivityTextProps) => {
  return (
    <>
      <Text color='#686D78'>
        Last activity:{' '}
        <Text color='#3137FD'>
          {staticData?.lastActivity ? (
            <Link
              to={`${getViewRoute('Account')}/${accountId}/sites/${siteId}`}
              $css='color: #3137FD;'
            >
              {`${staticData?.lastActivity} ${dayjs(
                staticData?.activityDate
              ).format(dateFormat)}`}
            </Link>
          ) : (
            haveData(staticData?.lastActivity)
          )}
        </Text>
      </Text>
    </>
  );
};

export const LastActivityNew = ({
  lastActivity = 'No recent activity',
  lastActivityDate,
  showPlaceHolder = true,
  separate = false,
}) => {
  let bgColor = '#F4F4F6';
  let borderColor = '#D3D5D9';
  const lowerLastActivity = lastActivity?.toLowerCase();

  switch (lowerLastActivity) {
    // Event created - grey
    case LAST_ACTIVITY.EVENT_CREATED:
      bgColor = '#F4F4F6';
      borderColor = '#D3D5D9';
      break;
    // Event completed - green
    case LAST_ACTIVITY.EVENT_COMPLETED:
      bgColor = '#F1FCF8';
      borderColor = '#97ECCA';
      break;
    // Event cancelled - red
    case LAST_ACTIVITY.EVENT_CANCELLED:
      bgColor = '#FDF3F1';
      borderColor = '#F6A194';
      break;
    // Call log created - grey
    case LAST_ACTIVITY.CALL_LOG_CREATED:
      bgColor = '#F4F4F6';
      borderColor = '#D3D5D9';
      break;
    // Task created - grey
    case LAST_ACTIVITY.TASK_CREATED:
      bgColor = '#F4F4F6';
      borderColor = '#D3D5D9';
      break;
    // Qualified - green
    case LAST_ACTIVITY.QUALIFIED:
      bgColor = '#F1FCF8';
      borderColor = '#97ECCA';
      break;
    // Unqualified - red
    case LAST_ACTIVITY.UNQUALIFIED:
      bgColor = '#FDF3F1';
      borderColor = '#F6A194';
      break;
    default:
      bgColor = '#F4F4F6';
      borderColor = '#D3D5D9';
  }

  return (
    <Box
      sx={{
        border: `1px solid ${borderColor}`,
        borderRadius: '8px',
        backgroundColor: bgColor,
        padding: '8px',
        maxWidth: '200px',
      }}
    >
      <Text color='#686D78'>
        {showPlaceHolder && `Last activity: `}
        <Text weight={'semibold'} color={'#090A0B'}>
          {isValueValid(lastActivity) ? lastActivity : 'No recent activity'}
        </Text>
        <Text color='#090A0B'>
          {isValueValid(lastActivityDate) ? (
            <>
              {`,`}
              {separate ? <br /> : ' '}
              {`${formatDate2(lastActivityDate)}`}
            </>
          ) : (
            ''
          )}
        </Text>
      </Text>
    </Box>
  );
};
