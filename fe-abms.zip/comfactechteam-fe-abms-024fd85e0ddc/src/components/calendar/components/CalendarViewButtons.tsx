import React, { Dispatch, SetStateAction, useEffect, useState } from 'react';

import dayjs from 'dayjs';

import { MaterialIcon, Button } from '@/styled-components';

import { useMediaQuery } from '@mui/material';

import { Dropdown, Space } from 'antd';

import { ViewBtn } from '../CalendarHeader';
import { calendarViews } from '../constants';

interface ICalendarViewButtonProps {
  calendar: any;
  setTitle: Dispatch<SetStateAction<string>>;
}

const CalendarViewButton = (props: ICalendarViewButtonProps) => {
  const isSmallScreen = useMediaQuery('(max-width:1280px)');

  const { calendar } = props;

  const [activeView, setActiveView] = useState<string>('dayGridMonth');

  const onChangeView = view => {
    calendar?.calendar.changeView(view);
    if (view === 'timeGridFourDay') {
      const calendarDate = calendar?.calendar.getDate();
      const startDate = dayjs(calendarDate).startOf('week').add(1, 'day');
      calendar?.calendar.gotoDate(new Date(startDate.format()));
    } else if (view === 'timeGridDay') {
      calendar?.calendar.today();
    }
    props.setTitle(calendar?.calendar.view.title);
  };

  useEffect(() => {
    setActiveView(calendar?.calendar.view.type);
  }, [calendar?.calendar.view.type]);

  if (isSmallScreen) {
    return (
      <Dropdown
        menu={{
          items: calendarViews.map(v => ({
            key: v.view,
            label: v.label,
          })),
          onClick: ({ key }) => onChangeView(key),
          activeKey: activeView,
        }}
      >
        <Button ghost $css='width: 40px; height: 40px;'>
          <MaterialIcon name='more_horiz' />
        </Button>
      </Dropdown>
    );
  }

  return (
    <Space.Compact>
      {calendarViews.map(v => (
        <ViewBtn
          key={v.view}
          isActive={activeView === v.view}
          onClick={() => onChangeView(v.view)}
        >
          {v.label}
        </ViewBtn>
      ))}
    </Space.Compact>
  );
};

export default CalendarViewButton;
