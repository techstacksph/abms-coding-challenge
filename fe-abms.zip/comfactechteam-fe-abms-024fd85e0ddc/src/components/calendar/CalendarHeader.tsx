import React, { useEffect, useState } from 'react';

import { Text, Button, MaterialIcon } from '@/styled-components';
import { MicosotftIcon } from '@/styled-components/assets/svg/icons';
import styled from 'styled-components';

import { Loop, NavigateBefore, NavigateNext } from '@mui/icons-material';
import { Stack, Box } from '@mui/material';
import PrintCalendar from '@/views/calendar/calendar/common/components/print/PrintCalendar';

import { Space, Button as AntdButton } from 'antd';

import CalendarViewButton from './components/CalendarViewButtons';
import { useOutlookCalendarSync } from '@/hooks/useOutlookCalendarSync';

interface ViewBtnProps {
  isActive?: boolean;
  $css?: string;
}

export const ViewBtn = styled(AntdButton)<ViewBtnProps>`
  border-color: rgba(190, 192, 198, 1);
  color: rgba(104, 109, 120, 1);
  font-weight: 600;

  &:hover {
    background: rgba(0, 0, 0, 0.05);
    color: #090a0b !important;
    font-weight: 600;
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
    border-color: rgba(190, 192, 198, 1) !important;
  }

  ${props =>
    props.isActive &&
    `
      background: rgba(0, 0, 0, 0.05);
      color: #090A0B;
      font-weight: 600;
      box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
    `}

  ${({ $css }) => $css}
`;

const CalendarHeader = ({
  calendar,
  setOpenFilter,
  reLoadCalendar,
  isFilteredUsers,
  onAccountConnected,
}: {
  calendar?: any;
  views?: {
    list?: boolean;
    daily?: boolean;
    weekly?: boolean;
    monthly?: boolean;
  };
  setOpenFilter?: () => void;
  reLoadCalendar?: () => void;
  isFilteredUsers?: boolean;
  onAccountConnected?: () => void;
}) => {
  const [openLocalFilter, setLocalOpenFilter] = useState<boolean>(true);
  const [title, setTitle] = useState<string>();

  const { openOutlookAuth, hasMicrosoftAccount, isOutlookEmailEnabled } =
    useOutlookCalendarSync({
      onAccountConnected,
    });

  const onNext = () => {
    calendar?.calendar.next();
    setTitle(calendar?.calendar.view.title);
  };

  const onBack = () => {
    calendar?.calendar.prev();
    setTitle(calendar?.calendar.view.title);
  };

  const onToday = () => {
    calendar?.calendar.today();
    calendar?.calendar.changeView('timeGridDay');
    setTitle(calendar?.calendar.view.title);
  };

  const onClickRightFilter = () => {
    setOpenFilter();
    setLocalOpenFilter(!openLocalFilter);
  };

  useEffect(() => {
    if (!title) {
      setTitle(calendar?.calendar.view.title);
    }
  }, [calendar?.calendar]);

  return (
    <Stack
      direction='row'
      alignItems='center'
      justifyContent={'space-between'}
      sx={{ flexWrap: 'wrap' }}
      rowGap={1.5}
    >
      <Stack direction='row' spacing={1}>
        <Space.Compact>
          <ViewBtn
            icon={<NavigateBefore sx={{ color: '#878B97' }} />}
            onClick={onBack}
          />
          <ViewBtn
            icon={<NavigateNext sx={{ color: '#878B97' }} />}
            onClick={onNext}
          />
        </Space.Compact>
        <Button
          ghost
          onClick={onToday}
          $css={'border-color: #BEC0C6 !important;'}
        >
          Today
        </Button>
        <Button
          ghost
          icon={<Loop sx={{ color: '#878B97' }} />}
          onClick={reLoadCalendar}
          $css={'border-color: #BEC0C6 !important;'}
        />
        <PrintCalendar
          calendarData={calendar?.calendar?.currentData}
          isFilteredUsers={isFilteredUsers}
        />
        {/* Only show Outlook button when using Microsoft Outlook for email (not SMTP) */}
        {isOutlookEmailEnabled && !hasMicrosoftAccount && (
          <Button
            ghost
            onClick={openOutlookAuth}
            icon={<MicosotftIcon />}
            $css={'border-color: #BEC0C6 !important;'}
            title='Outlook Calendar Sync'
          />
        )}
      </Stack>
      <Box sx={{ alignItems: 'center', flex: 1 }} textAlign='center'>
        <Text $type='xl' weight='medium'>
          {title}
        </Text>
      </Box>
      <Stack direction='row' spacing={1.5}>
        <CalendarViewButton calendar={calendar} setTitle={setTitle} />
        <Button
          type='primary'
          ghost
          icon={
            <MaterialIcon
              name={`${
                openLocalFilter ? 'left_panel_open' : 'right_panel_open'
              }`}
            />
          }
          onClick={onClickRightFilter}
          $css={`
            &:hover {
              background: rgba(0, 0, 0, 0.05) !important;
            }

            color: ${
              openLocalFilter
                ? 'rgba(49, 55, 253, 1)'
                : 'rgba(104, 109, 120, 1) !important'
            };
            ${
              !openLocalFilter &&
              'border-color: rgba(190, 192, 198, 1) !important;'
            }
          `}
        />
      </Stack>
    </Stack>
  );
};

export default CalendarHeader;
