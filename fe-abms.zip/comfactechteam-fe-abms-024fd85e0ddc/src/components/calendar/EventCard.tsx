import React from 'react';

import dayjs from 'dayjs';

import { Box, Stack } from '@mui/material';

import TruncatedText from './TruncatedText';

interface EventCardProps {
  event: {
    id: string;
    start: Date | string;
    end: Date | string;
    title: string;
    extendedProps: any;
  };
  onOpenEvent: (event: any) => void;
  isDraggable?: boolean;
  onDragStart?: () => void;
}

const EventCard = (props: EventCardProps) => {
  const { start, end, title, extendedProps, id } = props.event;
  const isDraggable = props.isDraggable || false;

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    if (!isDraggable) return;

    // Set drag data
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', id);

    // Create FullCalendar compatible event data
    const fcEvent = {
      id: id,
      title: title,
      start: start,
      end: end,
      extendedProps: extendedProps,
    };
    e.dataTransfer.setData('application/json', JSON.stringify(fcEvent));

    // Notify parent if callback exists
    if (props.onDragStart) {
      props.onDragStart();
    }
  };

  const handleClick = () => {
    props.onOpenEvent({
      id: id,
      title: title,
      start: start,
      end: end,
      extendedProps: extendedProps,
    });
  };

  return (
    <Stack
      direction='row'
      className='calendar_view montly_view'
      borderColor={extendedProps.color}
      data-event-id={id}
      draggable={isDraggable}
      onDragStart={handleDragStart}
      sx={{
        padding: '8px',
        cursor: isDraggable ? 'grab' : 'pointer',
        ':hover button': {
          display: 'block',
        },
        ':active': isDraggable
          ? {
              cursor: 'grabbing',
            }
          : {},
        borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
        backgroundColor: '#F4F4F6',
        borderRadius: 1,
      }}
      onClick={handleClick}
    >
      <Box width='100%'>
        <Stack spacing={0.5}>
          <Stack direction='row' alignItems='center' overflow='hidden'>
            <TruncatedText
              $type='xs'
              weight='sm'
              color='var(--color-text-secondary)'
              style={{ fontWeight: '400', fontSize: '12px', width: '100%' }}
              text={`${dayjs(start).format('hh:mm a')} - ${dayjs(end).format(
                'hh:mm a'
              )}`}
            />
          </Stack>
          <Stack direction='row' alignItems='center' overflow='hidden'>
            <TruncatedText
              $type='sm'
              weight='medium'
              color='var(--color-text-primary)'
              style={{ fontSize: '12px', lineHeight: '1.2', width: '100%' }}
              text={title}
            />
          </Stack>
          <Stack direction='row' alignItems='center' overflow='hidden'>
            <TruncatedText
              $type='sm'
              weight='medium'
              color='var(--color-text-primary)'
              style={{ fontSize: '12px', lineHeight: '1.2', width: '100%' }}
              text={extendedProps?.location}
            />
          </Stack>
        </Stack>
      </Box>
    </Stack>
  );
};

export default EventCard;
