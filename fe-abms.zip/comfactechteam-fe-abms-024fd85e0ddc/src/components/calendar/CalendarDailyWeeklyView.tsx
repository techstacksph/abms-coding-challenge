import React, { useEffect, useRef, useState } from 'react';

import dayjs from 'dayjs';

import { Box, Stack, Tooltip } from '@mui/material';

import CalendarOverflow from './CalendarOverflow';
import MoreLink from './MoreLink';
import TruncatedText from './TruncatedText';

const CalendarWeeklyView = props => {
  const { start, end, title, extendedProps, allDay } = props.event;

  const ref = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number>();

  useEffect(() => {
    if (ref.current?.clientHeight) {
      setHeight(ref.current?.clientHeight);
    }
  }, [ref.current]);

  const overflow = height && height < 54;

  const time = `${dayjs(start).format('hh:mm a')} - ${dayjs(end).format(
    'hh:mm a'
  )}`;

  if (allDay) {
    return (
      <MoreLink
        start={start}
        onOpenEvent={props.onOpenEvent}
        events={extendedProps?.events ?? []}
        title={`View all (${extendedProps?.events.length})`}
      />
    );
  }

  return (
    <Tooltip
      title={
        overflow ? (
          <CalendarOverflow
            title={title}
            location={extendedProps?.location}
            time={time}
          />
        ) : null
      }
    >
      <Stack
        spacing={0.5}
        direction='row'
        justifyContent='space-between'
        className='calendar_view weekly_view'
        sx={{
          padding: overflow ? '3px 8px' : '8px',
          ':hover button': {
            display: 'block',
          },
          borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
          height: '100%',
          overflow: 'hidden',
        }}
        ref={ref}
      >
        <Box width='100%' display={height <= 20 ? 'none' : 'block'}>
          <Stack spacing={0.5}>
            <Stack direction='row' alignItems='center' overflow='hidden'>
              <TruncatedText
                $type='sm'
                weight='bold'
                color='var(--color-text-primary)'
                style={{ fontSize: '12px', fontWeight: 'bold' }}
                text={title}
              />
            </Stack>
            <Stack direction='row' alignItems='center' overflow='hidden'>
              <TruncatedText
                $type='xs'
                weight='medium'
                color='var(--color-text-secondary)'
                style={{ fontWeight: 400 }}
                text={extendedProps?.location}
              />
            </Stack>
            <Stack direction='row' alignItems='center' overflow='hidden'>
              <TruncatedText
                $type='xs'
                weight='medium'
                color='var(--color-text-secondary)'
                style={{ fontWeight: 400, whiteSpace: 'nowrap' }}
                text={`${dayjs(start).format('hh:mm a')} - ${dayjs(end).format(
                  'hh:mm a'
                )}`}
              />
            </Stack>
          </Stack>
        </Box>
      </Stack>
    </Tooltip>
  );
};

export default CalendarWeeklyView;
