import React from 'react';

import { Tooltip, TooltipProps } from '@mui/material';
import { styled } from '@mui/material/styles';

// Custom styled tooltip with exact specifications
// Background: #FFFFFF, Text: #131933, Font: 12px/400/18px line-height
export const StyledTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} arrow />
))(() => ({
  '& .MuiTooltip-tooltip': {
    backgroundColor: '#FFFFFF',
    color: '#131933',
    fontSize: '12px',
    fontWeight: 400,
    lineHeight: '18px',
    padding: '8px 12px',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    maxWidth: '300px',
    wordWrap: 'break-word',
  },
  '& .MuiTooltip-arrow': {
    color: '#FFFFFF',
  },
}));

interface DescriptionTooltipProps {
  description?: string;
  children: React.ReactElement;
  placement?: TooltipProps['placement'];
}

const DescriptionTooltip: React.FC<DescriptionTooltipProps> = ({
  description,
  children,
  placement = 'top',
}) => {
  // Only show tooltip if description exists and is not empty
  if (!description || description.trim() === '') {
    return children;
  }

  return (
    <StyledTooltip title={description} placement={placement}>
      {children}
    </StyledTooltip>
  );
};

export default DescriptionTooltip;
