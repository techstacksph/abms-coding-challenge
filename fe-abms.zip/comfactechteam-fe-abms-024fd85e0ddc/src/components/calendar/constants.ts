/* eslint-disable no-unused-vars */

export enum VIEWS {
  DAY = 'timeGridDay',
  WEEKLY = 'timeGridWeek',
  WKEELY2 = 'timeGridFourDay',
  LIST = 'listWeek',
  MONTHLY = 'dayGridMonth',
}

export const calendarViews = [
  {
    label: 'Schedule',
    view: VIEWS.LIST,
  },
  {
    label: 'Daily',
    view: VIEWS.DAY,
  },
  {
    label: 'Weekly',
    view: VIEWS.WKEELY2,
  },
  {
    label: 'Monthly',
    view: VIEWS.MONTHLY,
  },
];
