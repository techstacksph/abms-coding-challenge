import React from 'react';

import { Avatar, Box, Stack, Tooltip } from '@mui/material';
import { AccountCircle } from '@mui/icons-material';

export interface AssigneeProfile {
  id: string;
  name: string;
  profilePic?: string | null;
  firstName?: string;
  lastName?: string;
}

interface AssigneeAvatarsProps {
  assignees: AssigneeProfile[];
  maxDisplay?: number;
  size?: number;
}

/**
 * Component to display assignee avatars with profile pictures or AccountCircle icon
 * Shows max N avatars overlapping
 * Displays tooltip with all usernames on hover
 */
const AssigneeAvatars: React.FC<AssigneeAvatarsProps> = ({
  assignees,
  maxDisplay = 3,
  size = 18,
}) => {
  if (!assignees || assignees.length === 0) {
    return null;
  }

  const displayedAssignees = assignees.slice(0, maxDisplay);

  // Create tooltip content with names in column format
  const tooltipContent = (
    <Stack direction='column' spacing={0.5}>
      {assignees.map((a, index) => (
        <span key={a.id || index}>{a.name}</span>
      ))}
    </Stack>
  );

  return (
    <Tooltip
      title={tooltipContent}
      placement='top'
      arrow
      componentsProps={{
        tooltip: {
          sx: {
            bgcolor: 'white',
            color: '#131933',
            fontWeight: 500,
            fontSize: '12px',
            fontFamily: "Hanken Grotesk",
            boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.15)',
            '& .MuiTooltip-arrow': {
              color: 'white',
            },
          },
        },
      }}
    >
      <Stack
        direction='row'
        sx={{ cursor: 'pointer' }}
        alignItems='center'
      >
        {displayedAssignees.map((assignee, index) => (
          <Box
            key={assignee.id || index}
            sx={{
              zIndex: displayedAssignees.length - index,
              marginLeft: index > 0 ? '-8px' : 0,
            }}
          >
            {assignee.profilePic ? (
              <Avatar
                src={assignee.profilePic}
                alt={assignee.name}
                sx={{
                  width: size,
                  height: size,
                  border: '2px solid white',
                }}
              />
            ) : (
              <AccountCircle
                sx={{
                  fontSize: size + 2,
                  color: '#878B97',
                }}
              />
            )}
          </Box>
        ))}
      </Stack>
    </Tooltip>
  );
};

export default AssigneeAvatars;
