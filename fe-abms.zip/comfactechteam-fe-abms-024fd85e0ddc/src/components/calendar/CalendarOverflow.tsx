import React, { memo } from 'react';

import { Stack } from '@mui/material';

import TruncatedText from './TruncatedText';

const Overflow = ({ title, location, time }) => {
  return (
    <Stack spacing={0.5}>
      <TruncatedText
        $type='sm'
        weight='medium'
        color='#131933'
        style={{ fontSize: '12px' }}
        ellipsis={false}
        text={title}
        disabled={true}
      />
      <TruncatedText
        $type='sm'
        weight='medium'
        color='#131933'
        style={{ fontSize: '12px' }}
        ellipsis={false}
        text={location}
        disabled={true}
      />
      <TruncatedText
        $type='sm'
        weight='medium'
        color='#131933'
        style={{ fontSize: '12px' }}
        ellipsis={false}
        text={time}
        disabled={true}
      />
    </Stack>
  );
};

export default memo(Overflow);
