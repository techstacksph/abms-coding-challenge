import React, { useEffect, useRef, useState } from 'react';

import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { Box, Stack } from '@mui/material';

import AssigneeAvatars from './AssigneeAvatars';
import CalendarOverflow from './CalendarOverflow';
import TruncatedText from './TruncatedText';
import { StyledTooltip } from './DescriptionTooltip';

const CalendarDailyTaskView = props => {
  const { start, end, title, extendedProps } = props.event;
  const ref = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number>();

  useEffect(() => {
    if (ref.current?.clientHeight) {
      setHeight(ref.current?.clientHeight);
    }
  }, [ref.current]);

  // Ensure start and end are valid dates
  const startDate = start
    ? start instanceof Date
      ? start
      : new Date(start)
    : null;
  const endDate = end ? (end instanceof Date ? end : new Date(end)) : null;

  const time =
    startDate &&
    endDate &&
    !isNaN(startDate.getTime()) &&
    !isNaN(endDate.getTime())
      ? `${dayjs(startDate).format('hh:mm a')} - ${dayjs(endDate).format('hh:mm a')}`
      : '';

  // Get assignee profiles for avatar display
  const assigneeProfiles = extendedProps?.assigneeProfiles || [];

  return (
    <StyledTooltip
      title={
        <CalendarOverflow
          title={title}
          location={extendedProps?.location}
          time={time}
        />
      }
      placement='top'
    >
      <Stack
        spacing={0.5}
        direction='row'
        justifyContent='space-between'
        className='calendar_view daily_view'
        sx={{
          padding: '3px 8px',
          ':hover button': {
            display: 'block',
          },
          borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
          height: '100%',
          overflow: 'hidden',
        }}
        ref={ref}
      >
        <Box display={height <= 20 ? 'none' : 'block'} flex={1}>
          <Stack spacing={0.5}>
            <Stack
              direction='row'
              alignItems='center'
              justifyContent='space-between'
            >
              <TruncatedText
                $type='sm'
                weight='medium'
                color='var(--color-text-primary)'
                style={{ fontSize: '12px' }}
                text={title}
                disabled={true}
              />
              {assigneeProfiles.length > 0 && (
                <AssigneeAvatars
                  assignees={assigneeProfiles}
                  maxDisplay={3}
                  size={18}
                />
              )}
            </Stack>
            {extendedProps?.location && (
              <Stack direction='row' alignItems='center'>
                <TruncatedText
                  $type='sm'
                  weight='medium'
                  color='var(--color-text-secondary)'
                  style={{ fontSize: '12px' }}
                  text={extendedProps.location}
                  disabled={true}
                />
              </Stack>
            )}
            {time && (
              <Stack direction='row' alignItems='center'>
                <Text
                  $type='xs'
                  weight='400'
                  color='var(--color-text-secondary)'
                >
                  {time}
                </Text>
              </Stack>
            )}
          </Stack>
        </Box>
      </Stack>
    </StyledTooltip>
  );
};

export default CalendarDailyTaskView;
