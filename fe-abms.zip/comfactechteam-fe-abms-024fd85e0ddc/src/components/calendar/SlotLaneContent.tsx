import React, { memo, useState, useEffect } from 'react';

import dayjs, { Dayjs } from 'dayjs';

import { Text } from '@/styled-components';
import styled from 'styled-components';

import { Stack } from '@mui/material';
import { timeFormat } from '@/utils/date.utils';

export const StyledSlot = styled.span<{ $isSelected?: boolean }>`
  height: 100%;
  display: block;
  opacity: 0;
  padding-left: 8px;
  cursor: pointer;

  ${({ $isSelected }) =>
    $isSelected &&
    `
    background-color: var(--green-300);
    opacity: 1;
  `}

  &:hover {
    background-color: var(--green-300);
    opacity: 1;
  }
`;

export const EventLane = styled.span<{ width?: number }>`
  display: flex;
  flex-direction: row;
  height: 100%;

  .event-slot {
    width: ${({ width }) => (width && width > 0 ? `${width}px` : 'auto')};
    min-width: ${({ width }) => (width && width > 0 ? `${width}px` : '0')};
    display: flex;
    flex-direction: row;
    padding: 6px 8px;
    gap: 12px;
    height: 100%;
    align-items: center;
    opacity: 0;
    margin-left: 0.5px;
    cursor: pointer;

    &.selected {
      opacity: 1;
      background-color: var(--green-300);
    }

    &:hover {
      opacity: 1;
      background-color: var(--green-300);
    }

    p {
      margin: 0;
      white-space: nowrap;

      &.time {
        font-size: 14px;
        font-weight: 600;
      }

      &.evailability {
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
  }
`;

export const TimeSlot = ({
  startTime,
  endTime,
  onClick,
  isSelected,
}: {
  startTime: string;
  endTime: string;
  onClick?: () => void;
  isSelected?: boolean;
}) => {
  return (
    <StyledSlot
      className='event-slot'
      $isSelected={isSelected}
      onClick={e => {
        e.stopPropagation();
        if (onClick) {
          onClick();
        }
      }}
    >
      <Stack
        direction='row'
        spacing={1.5}
        alignItems='center'
        height='100%'
        width='100%'
      >
        <Text $type='sm' weight='semibold' ellipsis>
          {startTime} - {endTime}
        </Text>
        <Text $type='xs' ellipsis>
          Everyone is available
        </Text>
      </Stack>
    </StyledSlot>
  );
};

const SlotLaneContent = ({
  event,
  modal,
  onClick,
  weekStart,
}: {
  event: any;
  modal?: boolean;
  onClick?: (dayIndex: number) => void;
  selectedTimeRange?: { start: Date | null; end: Date | null }; // kept for backward compatibility
  weekStart?: Dayjs | null;
}) => {
  // Calculate width after render to ensure DOM is ready
  // Use state to store width and update it when available
  const [width, setWidth] = useState<number | undefined>(undefined);

  useEffect(() => {
    // Calculate width after component mounts and DOM is ready
    const calculateWidth = () => {
      const header = document.querySelector(
        `${
          modal ? '#modal-calendar' : '#non-modal-calendar'
        } .fc-timeGridWeek-view th[role="columnheader"]`
      );

      if (header) {
        const headerWidth = header.clientWidth;
        if (headerWidth > 0) {
          setWidth(headerWidth);
        }
      }
    };

    // Calculate immediately
    calculateWidth();

    // Also calculate after a short delay to catch late-rendering calendars
    const timeoutId = setTimeout(calculateWidth, 100);

    // Recalculate on window resize
    window.addEventListener('resize', calculateWidth);

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', calculateWidth);
    };
  }, [modal]); // Re-run if modal prop changes

  const slotTime = dayjs(event.date);
  const hour = slotTime.hour();
  const minute = slotTime.minute();
  const startTime = slotTime.format(timeFormat);
  const endTime = slotTime.add(30, 'minutes').format(timeFormat);

  // Create a stable key for this EventLane based on time slot only
  // Don't include selection in key to prevent unnecessary remounts
  // The selection state is handled internally and doesn't require remounting
  const eventLaneKey = `event-lane-${dayjs(event.date).format('YYYY-MM-DD-HH-mm')}`;

  return (
    <EventLane key={eventLaneKey} width={width}>
      {new Array(7).fill(0).map((_, i) => {
        // Selection highlighting is now handled by ghost events
        // Slots only show hover effect for clickability
        // Click handler passes dayIndex to parent for date calculation
        return (
          <div
            className='event-slot'
            key={i}
            onClick={e => {
              e.stopPropagation();
              if (onClick) {
                onClick(i);
              }
            }}
          >
            <p className='time'>
              {startTime} - {endTime}
            </p>
            <p className='evailability' style={{ fontSize: '12px' }}>
              Everyone is available
            </p>
          </div>
        );
      })}
    </EventLane>
  );
};

// Memoize - re-render when weekStart or event date changes
// Selection highlighting is now handled by ghost events, not slot-based
export default memo(SlotLaneContent, (prevProps, nextProps) => {
  // Re-render if weekStart changes
  const prevWeekStart = prevProps.weekStart?.valueOf();
  const nextWeekStart = nextProps.weekStart?.valueOf();
  if (prevWeekStart !== nextWeekStart) {
    return false; // Re-render
  }

  // Re-render if event date changes
  const prevEventDate = prevProps.event?.date?.getTime();
  const nextEventDate = nextProps.event?.date?.getTime();
  if (prevEventDate !== nextEventDate) {
    return false; // Re-render
  }

  // Otherwise, skip re-render
  return true;
});
