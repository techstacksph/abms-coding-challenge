import React, { useEffect, useRef, useState } from 'react';

import dayjs from 'dayjs';

import { Box, Stack } from '@mui/material';

import AssigneeAvatars from './AssigneeAvatars';
import CalendarOverflow from './CalendarOverflow';
import MoreLink from './MoreLink';
import TruncatedText from './TruncatedText';
import { StyledTooltip } from './DescriptionTooltip';

const CalendarWeeklyTaskView = props => {
  const { start, end, title, extendedProps, allDay } = props.event;

  const ref = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number>();

  useEffect(() => {
    if (ref.current?.clientHeight) {
      setHeight(ref.current?.clientHeight);
    }
  }, [ref.current]);

  // Ensure start and end are valid dates
  const startDate = start
    ? start instanceof Date
      ? start
      : new Date(start)
    : null;
  const endDate = end ? (end instanceof Date ? end : new Date(end)) : null;

  const time =
    startDate &&
    endDate &&
    !isNaN(startDate.getTime()) &&
    !isNaN(endDate.getTime())
      ? `${dayjs(startDate).format('hh:mm a')} - ${dayjs(endDate).format('hh:mm a')}`
      : '';

  // Get assignee profiles for avatar display
  const assigneeProfiles = extendedProps?.assigneeProfiles || [];

  if (allDay) {
    return (
      <MoreLink
        start={start}
        onOpenEvent={props.onOpenEvent}
        events={extendedProps?.events ?? []}
        title={`View all (${extendedProps?.events.length})`}
      />
    );
  }

  return (
    <StyledTooltip
      title={
        <CalendarOverflow
          title={title}
          location={extendedProps?.location}
          time={time}
        />
      }
      placement='top'
    >
      <Stack
        spacing={0.5}
        direction='row'
        justifyContent='space-between'
        className='calendar_view weekly_view'
        sx={{
          padding: '3px 8px',
          ':hover button': {
            display: 'block',
          },
          borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
          height: '100%',
          overflow: 'hidden',
        }}
        ref={ref}
      >
        <Box width='100%' display={height <= 20 ? 'none' : 'block'}>
          <Stack spacing={0.5}>
            <Stack
              direction='row'
              alignItems='center'
              overflow='hidden'
              justifyContent='space-between'
            >
              <TruncatedText
                $type='sm'
                weight='medium'
                color='var(--color-text-primary)'
                style={{ fontSize: '12px' }}
                text={title}
                disabled={true}
              />
              {assigneeProfiles.length > 0 && (
                <AssigneeAvatars
                  assignees={assigneeProfiles}
                  maxDisplay={3}
                  size={16}
                />
              )}
            </Stack>
            {extendedProps?.location && (
              <Stack direction='row' alignItems='center' overflow='hidden'>
                <TruncatedText
                  $type='xs'
                  weight='medium'
                  color='var(--color-text-secondary)'
                  style={{ fontWeight: 400 }}
                  text={extendedProps.location}
                  disabled={true}
                />
              </Stack>
            )}
            {time && (
              <Stack direction='row' alignItems='center' overflow='hidden'>
                <TruncatedText
                  $type='xs'
                  weight='medium'
                  color='var(--color-text-secondary)'
                  style={{ fontWeight: 400, whiteSpace: 'nowrap' }}
                  text={time}
                  disabled={true}
                />
              </Stack>
            )}
          </Stack>
        </Box>
      </Stack>
    </StyledTooltip>
  );
};

export default CalendarWeeklyTaskView;
