import React, { useEffect, useRef, useState } from 'react';

import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { Box, Stack, Tooltip } from '@mui/material';

import CalendarOverflow from './CalendarOverflow';
import TruncatedText from './TruncatedText';

const CalendarDailyView = props => {
  const { start, end, title, extendedProps } = props.event;
  const ref = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number>();

  useEffect(() => {
    if (ref.current?.clientHeight) {
      setHeight(ref.current?.clientHeight);
    }
  }, [ref.current]);

  const overflow = height && height < 54;

  const time = `${dayjs(start).format('hh:mm a')} - ${dayjs(end).format(
    'hh:mm a'
  )}`;

  return (
    <Tooltip
      title={
        overflow ? (
          <CalendarOverflow
            title={title}
            location={extendedProps?.location}
            time={time}
          />
        ) : null
      }
    >
      <Stack
        spacing={0.5}
        direction='row'
        justifyContent='space-between'
        className='calendar_view daily_view'
        sx={{
          padding: overflow ? '3px 8px' : '8px',
          ':hover button': {
            display: 'block',
          },
          borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
          height: '100%',
          overflow: 'hidden',
        }}
        ref={ref}
      >
        <Box display={height <= 20 ? 'none' : 'block'}>
          <Stack spacing={0.5}>
            <Stack direction='row' alignItems='center'>
              <TruncatedText
                $type='sm'
                weight='bold'
                color='var(--color-text-primary)'
                style={{ fontSize: '12px', fontWeight: 'bold' }}
                text={title}
                disabled={overflow}
              />
            </Stack>
            <Stack direction='row' alignItems='center'>
              <TruncatedText
                $type='sm'
                weight='medium'
                color='var(--color-text-secondary)'
                style={{ fontSize: '12px' }}
                text={extendedProps?.location}
              />
            </Stack>
            <Stack direction='row' alignItems='center'>
              <Text $type='xs' weight='400' color='var(--color-text-secondary)'>
                {time}
              </Text>
            </Stack>
          </Stack>
        </Box>
      </Stack>
    </Tooltip>
  );
};

export default CalendarDailyView;
