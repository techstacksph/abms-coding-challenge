import React, { useState } from 'react';

import dayjs from 'dayjs';

import { Text, Icon, Button } from '@/styled-components';

import { CloseOutlined } from '@ant-design/icons';
import { EventApi } from '@fullcalendar/core';
import { Stack } from '@mui/material';
import { calendarFormatComma } from '@/utils/date.utils';

import { Tooltip } from 'antd';

import EventCard from './EventCard';

interface IMoreLinkProps {
  start: string;
  events?: Array<{ [key: string]: string }> | EventApi[];
  title: string;
  onOpenEvent: (event) => void;
  height?: string | number;
}

const MoreLink = (props: IMoreLinkProps) => {
  const { title, events, start, height } = props;
  const [open, setOpen] = useState<boolean>(false);

  return (
    <Tooltip
      trigger={['click']}
      color='#FFF'
      overlayInnerStyle={{
        width: 340,
      }}
      title={
        <Stack p={1} spacing={1} maxHeight='474px'>
          <Stack
            direction='row'
            justifyContent='space-between'
            alignItems='center'
          >
            <Text>{dayjs(start).format(calendarFormatComma)}</Text>
            <Button
              type='text'
              ghost
              $css={`
                height: 24px;
                min-width: 24px;
                padding: 0;
              `}
              onClick={() => setOpen(false)}
            >
              <Icon size='14px' color='#7B8B99'>
                <CloseOutlined />
              </Icon>
            </Button>
          </Stack>
          <Stack spacing={1} height={height} overflow='auto' pr={1}>
            {events?.map((e, i) => {
              // Check if this is a job schedule event (should not be draggable)
              const isJobSchedule = e.id?.includes('job-schedule-');

              return (
                <EventCard
                  key={i}
                  event={e}
                  isDraggable={!isJobSchedule}
                  onOpenEvent={event => {
                    setOpen(false);
                    props.onOpenEvent(event);
                  }}
                  onDragStart={() => {
                    // Close tooltip when drag starts
                    setTimeout(() => setOpen(false), 50);
                  }}
                />
              );
            })}
          </Stack>
        </Stack>
      }
      onOpenChange={open => setOpen(open)}
      open={open}
    >
      <Stack
        className='calendar_view'
        sx={{
          padding: '8px',
          ':hover button': {
            display: 'block',
          },
        }}
      >
        <Text $type='xs' weight='medium'>
          {title}
        </Text>
      </Stack>
    </Tooltip>
  );
};

export default MoreLink;
