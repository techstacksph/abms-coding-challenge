import React, { useRef, useState } from 'react';

import FullCalendar from '@fullcalendar/react';
import { Box } from '@mui/material';
import { CalendarEvent } from '@/typings/calendar.types';

import { VIEWS } from '../constants';
import Calendar from './Calendar';
import ModalCalendar from './ModalCalendar';

interface UserOption {
  label: string;
  value: string;
}

const AssigneeCalendar = ({
  events,
  onDateClick,
  selectedTimeRange,
  disableAutoScroll,
  onDatesSet,
  users,
  filterAssignees,
  onFilterAssigneesChange,
  onModalClose,
}: {
  events: Array<CalendarEvent>;
  onDateClick?: (arg: any) => void;
  selectedTimeRange?: { start: Date | null; end: Date | null };
  disableAutoScroll?: boolean;
  onDatesSet?: (arg: {
    start: Date;
    end: Date;
    startStr: string;
    endStr: string;
    timeZone: string;
    view: any;
  }) => void;
  users?: UserOption[];
  filterAssignees?: string[];
  onFilterAssigneesChange?: (assignees: string[]) => void;
  onModalClose?: (filterAssignees: string[]) => void;
}) => {
  const calendarRef = useRef<FullCalendar>(null);
  const modalCalendarRef = useRef<FullCalendar>(null);

  const [open, setOpen] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<VIEWS>(VIEWS.DAY);

  const handleViewChange = (view: VIEWS) => {
    setCurrentView(view);
    calendarRef?.current?.getApi()?.changeView(view);
    modalCalendarRef?.current?.getApi()?.changeView(view);
  };

  // Handler for main calendar clicks (no modal logic)
  const handleMainCalendarDateClick = (arg: any) => {
    if (onDateClick) {
      onDateClick(arg);
    }
  };

  // Handler for modal calendar clicks (includes modal closing and navigation)
  const handleModalDateClick = (arg: any) => {
    // First call the onDateClick callback to update form values
    // This must happen before closing the modal and navigating
    if (onDateClick) {
      onDateClick(arg);
    }

    // Close the modal after a short delay to allow form update
    setTimeout(() => {
      setOpen(false);

      // Navigate calendar to the selected date/time
      // This works for both day and week views - day view shows the specific day,
      // week view shows the week containing the selected date
      if (arg?.date && calendarRef.current && !disableAutoScroll) {
        const calendarApi = calendarRef.current.getApi();
        if (calendarApi) {
          // Navigate to the selected date
          calendarApi.gotoDate(arg.date);

          // Scroll to the selected time to make it visible
          const selectedDate = new Date(arg.date);
          const hours = selectedDate.getHours();
          const minutes = selectedDate.getMinutes();
          calendarApi.scrollToTime({
            hours: hours,
            minutes: minutes,
          });
        }
      }
    }, 100);
  };


  return (
    <Box height='100%'>
      <Calendar
        setOpen={setOpen}
        events={events}
        calendar={calendarRef}
        currentView={currentView}
        onViewChange={handleViewChange}
        onDateClick={handleMainCalendarDateClick}
        selectedTimeRange={selectedTimeRange}
        onDatesSet={onDatesSet}
      />
      <ModalCalendar
        setOpen={setOpen}
        open={open}
        events={events}
        calendar={modalCalendarRef}
        currentView={currentView}
        onViewChange={handleViewChange}
        onDateClick={handleModalDateClick}
        selectedTimeRange={selectedTimeRange}
        onDatesSet={onDatesSet}
        users={users}
        filterAssignees={filterAssignees}
        onFilterAssigneesChange={onFilterAssigneesChange}
        onModalClose={onModalClose}
      />
    </Box>
  );
};

export default AssigneeCalendar;
