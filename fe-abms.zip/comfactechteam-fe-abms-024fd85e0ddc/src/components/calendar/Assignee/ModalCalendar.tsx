/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useState, useMemo, useEffect, MutableRefObject } from 'react';

import dayjs from 'dayjs';
import styled from 'styled-components';

import { Text } from '@/styled-components';

import FullCalendar from '@fullcalendar/react';
import { MinimizeOutlined } from '@mui/icons-material';
import { Stack } from '@mui/material';

import { Modal, Select } from 'antd';

import { ViewBtn } from '../CalendarHeader';
import SlotLaneContent, { TimeSlot } from '../SlotLaneContent';
import { VIEWS } from '../constants';
import { timeFormat } from '@/utils/date.utils';
import { StyledCalendar } from './Calendar';
import Toolbar from './Toolbar';
import { createCommonProps } from './common';
import CalendarWeeklyTaskView from '../CalendarDailyWeeklyTaskView';
import CalendarDailyTaskView from '../CalendarDailyTaskView';
import EventTooltip from './EventTooltip';

interface UserOption {
  label: string;
  value: string;
}

// Styled component for the selected time range highlight
const SelectedTimeHighlight = styled.div`
  background-color: var(--green-300);
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 12px;
  padding: 6px 8px;
  height: 100%;
  box-sizing: border-box;
  color: #000;

  .time {
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    margin: 0;
  }

  .availability {
    font-size: 12px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    margin: 0;
  }
`;

const ModalCalendar = ({
  events,
  calendar,
  setOpen,
  open,
  currentView,
  onViewChange,
  onDateClick,
  selectedTimeRange,
  onDatesSet,
  users,
  filterAssignees,
  onFilterAssigneesChange,
  onModalClose,
}: {
  events: Array<any>;
  calendar: MutableRefObject<FullCalendar | null>;
  setOpen: (open: boolean) => void;
  open: boolean;
  currentView: string;
  onViewChange: (view: any) => void;
  onDateClick?: (arg: any) => void;
  selectedTimeRange?: { start: Date | null; end: Date | null };
  onDatesSet?: (arg: {
    start: Date;
    end: Date;
    startStr: string;
    endStr: string;
    timeZone: string;
    view: any;
  }) => void;
  users?: UserOption[];
  filterAssignees?: string[];
  onFilterAssigneesChange?: (assignees: string[]) => void;
  onModalClose?: (filterAssignees: string[]) => void;
}) => {
  const [load, setLoad] = useState<boolean>(false);

  // Track the current week start date for week view
  const [currentWeekStart, setCurrentWeekStart] = useState<dayjs.Dayjs | null>(
    null
  );

  // Update week start when calendar date changes
  // Note: Calendar uses firstDay: 1 (Monday), so we need to align with that
  useEffect(() => {
    if (calendar.current) {
      const calendarApi = calendar.current.getApi();
      if (calendarApi) {
        const calendarDate = calendarApi.getDate();
        // Use startOf('isoWeek') to get Monday as the start (ISO week starts on Monday)
        const weekStart = dayjs(calendarDate).startOf('isoWeek');
        setCurrentWeekStart(weekStart);
      }
    }
  }, [calendar, events]); // Re-run when calendar or events change

  // Memoize the views object so it updates when selectedTimeRange changes
  // This ensures FullCalendar re-renders without remounting
  const viewsConfig = useMemo(
    () => ({
      [VIEWS.DAY]: {
        dayHeaders: false,
        slotLaneContent: (event: any) => {
          const startTime = dayjs(event.date).format(timeFormat);
          const endTime = dayjs(event.date)
            .add(30, 'minutes')
            .format(timeFormat);

          // Get the current calendar date (the day being viewed)
          const calendarDate = calendar.current?.getApi()?.getDate();

          // Get the time from the event slot
          const slotTime = dayjs(event.date);
          const hour = slotTime.hour();
          const minute = slotTime.minute();

          // Use the calendar's current date with the slot's time
          // Fallback to event.date if calendarDate is not available
          const slotStartDateTime = calendarDate
            ? dayjs(calendarDate)
                .hour(hour)
                .minute(minute)
                .second(0)
                .millisecond(0)
                .toDate()
            : dayjs(event.date).second(0).millisecond(0).toDate();

          const slotEndDateTime = dayjs(slotStartDateTime)
            .add(30, 'minutes')
            .toDate();

          // Check if this slot falls within the selected time range
          let isSelected = false;
          if (selectedTimeRange?.start && selectedTimeRange?.end) {
            const slotDate = dayjs(slotStartDateTime);
            const selectedDate = dayjs(selectedTimeRange.start);

            // First check: dates must be on the same day
            const isSameDay = slotDate.isSame(selectedDate, 'day');

            // Second check: time ranges must overlap
            const timeOverlaps =
              slotDate.isBefore(dayjs(selectedTimeRange.end), 'minute') &&
              dayjs(slotEndDateTime).isAfter(
                dayjs(selectedTimeRange.start),
                'minute'
              );

            isSelected = isSameDay && timeOverlaps;
          }

          return (
            <TimeSlot
              startTime={startTime}
              endTime={endTime}
              isSelected={isSelected}
              onClick={() => {
                if (onDateClick) {
                  onDateClick({ date: slotStartDateTime });
                }
              }}
            />
          );
        },
      },
      [VIEWS.WEEKLY]: {
        slotLaneContent: (event: any) => {
          // Use the tracked weekStart state, or calculate from calendar if available
          // Use startOf('isoWeek') to match calendar's firstDay: 1 (Monday)
          let weekStart = currentWeekStart;
          if (!weekStart) {
            if (calendar.current) {
              const calendarDate = calendar.current.getApi()?.getDate();
              weekStart = calendarDate
                ? dayjs(calendarDate).startOf('isoWeek')
                : null;
            }
            // Fallback to event date if calendar is not available
            if (!weekStart) {
              weekStart = dayjs(event.date).startOf('isoWeek');
            }
          }

          return (
            <SlotLaneContent
              event={event}
              modal
              selectedTimeRange={selectedTimeRange}
              weekStart={weekStart}
              onClick={dayIndex => {
                if (onDateClick) {
                  // Get the time from the event slot
                  const slotTime = dayjs(event.date);
                  const hour = slotTime.hour();
                  const minute = slotTime.minute();

                  // Use the weekStart from closure, or calculate it
                  let clickedWeekStart = weekStart;
                  if (!clickedWeekStart) {
                    if (calendar.current) {
                      const calendarDate = calendar.current.getApi()?.getDate();
                      clickedWeekStart = calendarDate
                        ? dayjs(calendarDate).startOf('isoWeek')
                        : null;
                    }
                    // Fallback to event date
                    if (!clickedWeekStart) {
                      clickedWeekStart = dayjs(event.date).startOf('isoWeek');
                    }
                  }

                  const clickedDate = clickedWeekStart
                    .add(dayIndex, 'day')
                    .hour(hour)
                    .minute(minute)
                    .second(0)
                    .millisecond(0);

                  onDateClick({ date: clickedDate.toDate() });
                }
              }}
            />
          );
        },
      },
    }),
    [selectedTimeRange, onDateClick, calendar, currentWeekStart]
  );

  // Create events array with the selected time range as a ghost event
  const eventsWithSelection = useMemo(() => {
    const baseEvents = Array.isArray(events) ? events : [];

    // Add ghost event for selected time range
    // Only show if both start and end are valid and end is after start
    if (selectedTimeRange?.start && selectedTimeRange?.end) {
      const startTime = dayjs(selectedTimeRange.start);
      const endTime = dayjs(selectedTimeRange.end);

      // Validate: end time must be after start time
      if (startTime.isValid() && endTime.isValid() && endTime.isAfter(startTime)) {
        const selectionEvent = {
          id: 'selected-time-range',
          title: 'Selected Time',
          start: selectedTimeRange.start,
          end: selectedTimeRange.end,
          extendedProps: {
            isSelectionHighlight: true,
          },
          display: 'auto',
          backgroundColor: 'transparent',
          borderColor: 'transparent',
        };
        return [selectionEvent, ...baseEvents];
      }
    }

    return baseEvents;
  }, [events, selectedTimeRange]);

  // Force FullCalendar to update when selection changes
  // FullCalendar doesn't always detect events prop changes, so we manually refresh
  useEffect(() => {
    const updateSelection = () => {
      if (calendar.current) {
        const calendarApi = calendar.current.getApi();
        if (calendarApi) {
          // Remove existing selection event if any
          const existingEvent = calendarApi.getEventById('selected-time-range');
          if (existingEvent) {
            existingEvent.remove();
          }

          // Add the new selection event if valid
          if (selectedTimeRange?.start && selectedTimeRange?.end) {
            const startTime = dayjs(selectedTimeRange.start);
            const endTime = dayjs(selectedTimeRange.end);

            if (startTime.isValid() && endTime.isValid() && endTime.isAfter(startTime)) {
              calendarApi.addEvent({
                id: 'selected-time-range',
                title: 'Selected Time',
                start: selectedTimeRange.start,
                end: selectedTimeRange.end,
                extendedProps: {
                  isSelectionHighlight: true,
                },
                display: 'auto',
                backgroundColor: 'transparent',
                borderColor: 'transparent',
              });
            }
          }
        }
      }
    };

    // Use requestAnimationFrame to ensure DOM is ready
    const rafId = requestAnimationFrame(() => {
      updateSelection();
    });

    return () => cancelAnimationFrame(rafId);
  }, [selectedTimeRange, calendar, currentView, open]);

  return (
    <Modal
      closable={false}
      open={open}
      width='1840px'
      styles={{ body: { padding: 0 } }}
      footer={null}
      destroyOnClose
      destroyOnHidden
      style={{
        marginTop: -75,
      }}
      afterOpenChange={open => setLoad(open)}
    >
      <Stack spacing={2.5} height={window.innerHeight - 100} width='100%'>
        <Stack
          direction='row'
          alignItems='center'
          justifyContent='space-between'
        >
          <Text $type='md' weight='semibold'>
            Week
          </Text>
          <Stack direction='row' alignItems='center' spacing={1.5}>
            {users && users.length > 0 && (
              <Select
                mode='multiple'
                placeholder='Filter by assignee'
                value={filterAssignees}
                onChange={onFilterAssigneesChange}
                options={users}
                style={{ minWidth: 406, maxWidth: 406 }}
                maxTagCount='responsive'
                showSearch
                filterOption={(input, option) =>
                  ((option?.label as string) ?? '')
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
              />
            )}
            <ViewBtn
              onClick={() => {
                if (onModalClose && filterAssignees) {
                  onModalClose(filterAssignees);
                }
                setOpen(false);
              }}
              icon={<MinimizeOutlined />}
            />
          </Stack>
        </Stack>
        <Toolbar
          isModal
          setOpen={setOpen}
          calendar={calendar}
          currentView={currentView}
          onViewChange={onViewChange}
        />
        <StyledCalendar id='modal-calendar' modal>
          <FullCalendar
            initialView={VIEWS.WEEKLY}
            ref={calendar}
            events={eventsWithSelection}
            eventContent={eventInfo => {
              // Check if this is the selection highlight event
              if (eventInfo.event.extendedProps?.isSelectionHighlight) {
                const startTime = dayjs(eventInfo.event.start).format(timeFormat);
                const endTime = dayjs(eventInfo.event.end).format(timeFormat);
                return (
                  <SelectedTimeHighlight>
                    <p className='time'>
                      {startTime} - {endTime}
                    </p>
                    <p className='availability'>Everyone is available</p>
                  </SelectedTimeHighlight>
                );
              }

              const { type } = eventInfo.view;
              if (type === 'timeGridDay')
                return <CalendarDailyTaskView {...eventInfo} />;
              if (type === 'timeGridWeek')
                return (
                  <CalendarWeeklyTaskView
                    {...eventInfo}
                    onOpenEvent={() => {}}
                  />
                );
              // Fallback to tooltip for any other view types
              return <EventTooltip event={eventInfo} />;
            }}
            eventDisplay='list-item'
            views={viewsConfig}
            datesSet={arg => {
              // Update week start when dates change (for week view)
              // Use startOf('isoWeek') to match calendar's firstDay: 1 (Monday)
              if (arg.view.type === 'timeGridWeek') {
                const weekStart = dayjs(arg.start).startOf('isoWeek');
                setCurrentWeekStart(weekStart);
              }
              // Call the original onDatesSet if provided
              if (onDatesSet) {
                onDatesSet(arg);
              }
            }}
            {...createCommonProps()}
          />
        </StyledCalendar>
      </Stack>
    </Modal>
  );
};

export default ModalCalendar;
