import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { EventContentArg } from '@fullcalendar/core';
import { Box, Stack } from '@mui/material';
import { timeFormat } from '@/utils/date.utils';

import { Tooltip } from 'antd';

const TooltipContent = ({ content }: { content: Array<string> }) => {
  return (
    <Stack>
      {content.map((c, i) => (
        <Text key={i}>{c}</Text>
      ))}
    </Stack>
  );
};

const EventTooltip = ({ event }: { event: EventContentArg }) => {
  const { assignee } = event.event.extendedProps as { assignee?: string[] };
  const assigneeList = Array.isArray(assignee) ? assignee : [];
  const uniqueAssignees: string[] = Array.from(new Set<string>(assigneeList));

  const start = dayjs(event.event.start).format(timeFormat);

  let end;
  if (event.event.end) {
    end = dayjs(event.event.end).format(timeFormat);
  } else {
    end = dayjs(event.event.start).add(1, 'hour').format(timeFormat);
  }

  return (
    <Tooltip
      title={<TooltipContent content={uniqueAssignees} />}
      placement='top'
      color='#FFF'
      overlayInnerStyle={{
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <Box
        height='100%'
        className='event-content'
        sx={{
          opacity: 0,
          ':hover': {
            opacity: 1,
          },
          paddingLeft: 1,
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Stack direction='row' spacing={1.5} width='100%'>
          <Text $type='sm' weight='semibold' ellipsis>
            {start} - {end}
          </Text>
          <Text $type='xs' ellipsis>
            {uniqueAssignees.length}{' '}
            {uniqueAssignees.length > 1 ? "people aren't " : "person isn't "}
            available
          </Text>
        </Stack>
      </Box>
    </Tooltip>
  );
};

export default EventTooltip;
