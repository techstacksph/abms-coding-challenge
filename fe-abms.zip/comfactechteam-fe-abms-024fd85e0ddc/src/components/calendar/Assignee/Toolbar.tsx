import React, {
  Dispatch,
  memo,
  MutableRefObject,
  SetStateAction,
  useState,
} from 'react';

import dayjs, { Dayjs } from 'dayjs';

import { DatePicker, Button } from '@/styled-components';

import FullCalendar from '@fullcalendar/react';
import { ExpandMore, NavigateBefore, NavigateNext } from '@mui/icons-material';
import { Box, Stack } from '@mui/material';

import { Dropdown, Space } from 'antd';

import { ViewBtn } from '../CalendarHeader';
import { VIEWS } from '../constants';

const Toolbar = ({
  calendar,
  isModal,
  setOpen,
  currentView,
  onViewChange,
}: {
  calendar: MutableRefObject<FullCalendar>;
  isModal?: boolean;
  setOpen: Dispatch<SetStateAction<boolean>>;
  currentView: string;
  onViewChange: (view: VIEWS) => void;
}) => {
  const [date, setDate] = useState<Dayjs>(dayjs());

  const onButtonPress = func => {
    calendar?.current?.getApi()?.[func]();
    const newDate = dayjs(new Date(calendar?.current?.getApi().getDate()));
    setDate(newDate);
  };

  const formatDate = value => {
    if (currentView === VIEWS.DAY) return dayjs(value).format('MMM DD, YYYY');

    return `${dayjs(value)
      .startOf('week')
      .add(1, 'day')
      .format('MMM DD')} - ${dayjs(value)
      .endOf('week')
      .add(1, 'day')
      .format('MMM DD, YYYY')}`;
  };

  return (
    <Stack direction={isModal ? 'row' : 'column'} spacing={2.5}>
      <Stack flex={1} direction='row' justifyContent='space-between'>
        <Space.Compact>
          <ViewBtn
            icon={<NavigateBefore sx={{ color: '#878B97' }} />}
            onClick={() => onButtonPress('prev')}
          />
          <ViewBtn
            onClick={() => onButtonPress('today')}
            $css={'font-weight: 400; color: #1F2226;'}
          >
            Today
          </ViewBtn>
          <ViewBtn
            icon={<NavigateNext sx={{ color: '#878B97' }} />}
            onClick={() => onButtonPress('next')}
          />
        </Space.Compact>
        <Stack direction='row' spacing={'3px'}>
          <DatePicker
            variant='borderless'
            suffixIcon={null}
            defaultValue={dayjs()}
            value={date}
            allowClear={false}
            placeholder=''
            inputReadOnly
            format={formatDate}
            size='small'
            $css={
              'input { color: var(--text-primary) !important; font-size: 16px !important; font-weight: 500 !important; text-align: right; }'
            }
            onChange={(value: Dayjs) => setDate(value)}
            picker={currentView === VIEWS.WEEKLY ? 'week' : 'date'}
          />
          <Dropdown
            menu={{
              items: [
                {
                  key: 'day',
                  label: 'Day',
                  onClick: () => {
                    onViewChange(VIEWS.DAY);
                    if (isModal) {
                      setOpen(false);
                    }
                  },
                },
                {
                  key: 'week',
                  label: 'Week',
                  onClick: () => {
                    onViewChange(VIEWS.WEEKLY);
                    if (!isModal) {
                      setOpen(true);
                    }
                  },
                },
              ],
            }}
            trigger={['click']}
            placement='bottomRight'
          >
            <Button
              icon={<ExpandMore sx={{ color: '#878B97' }} />}
              type='text'
            />
          </Dropdown>
        </Stack>
      </Stack>
      {(currentView === VIEWS.WEEKLY || isModal) && (
        <Box
          justifyContent={isModal ? 'flex-end' : 'center'}
          alignItems='center'
          display='flex'
          flex={1}
        >
          <Button
            type='link'
            $css='color: var(--color-primary); height: fit-content;'
            size='small'
            onClick={() => {
              if (isModal) {
                setOpen(false);
              } else {
                setOpen(true);
              }
            }}
          >
            {isModal ? 'Minimise' : 'View'} assignee calendar
          </Button>
        </Box>
      )}
    </Stack>
  );
};

export default memo(Toolbar);
