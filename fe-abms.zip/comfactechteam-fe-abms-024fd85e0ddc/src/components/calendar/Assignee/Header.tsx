import { memo } from 'react';

import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { DayHeaderContentArg } from '@fullcalendar/core';

const Header = (props: DayHeaderContentArg) => {
  const { date } = props;
  const formattedDate = dayjs(date).format('ddd DD/MM');
  return <Text>{formattedDate}</Text>;
};

export default memo(Header);
