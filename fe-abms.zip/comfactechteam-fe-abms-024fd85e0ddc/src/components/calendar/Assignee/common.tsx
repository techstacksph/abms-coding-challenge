import { CalendarOptions, FormatterInput } from '@fullcalendar/core';
import rrulePlugin from '@fullcalendar/rrule';
import timeGridPlugin from '@fullcalendar/timegrid';

import Header from './Header';

export const createCommonProps = (): CalendarOptions => ({
  plugins: [timeGridPlugin, rrulePlugin],
  themeSystem: 'standard',
  height: '100%',
  headerToolbar: false as const,
  slotLabelFormat: {
    hour: 'numeric',
    meridiem: 'lowercase',
  } as FormatterInput,
  allDaySlot: false,
  dayHeaderContent: props => <Header {...props} />,
  firstDay: 1,
  expandRows: true,
  scrollTime: '00:00',
  scrollTimeReset: false,
});

export const commonProps: CalendarOptions = createCommonProps();
