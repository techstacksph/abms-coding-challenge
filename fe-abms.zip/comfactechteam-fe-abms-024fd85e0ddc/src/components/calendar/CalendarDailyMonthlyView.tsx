import React from 'react';

import { Text } from '@/styled-components';
import { formatTimeRange } from '@/utils/date.utils';

import { Box, Stack } from '@mui/material';

import TruncatedText from './TruncatedText';

const CalendarMonthlyView = props => {
  const { start, end, title, extendedProps } = props.event;

  return (
    <Stack
      direction='row'
      className='calendar_view montly_view'
      borderColor={extendedProps.color}
      sx={{
        padding: '8px',
        cursor: 'pointer',
        ':hover button': {
          display: 'block',
        },
        borderLeft: `4px solid ${extendedProps.color || '#fff'}`,
      }}
    >
      <Box width='100%'>
        <Stack spacing={0.5}>
          <Stack direction='row' alignItems='center'>
            <Text
              $type='xs'
              weight='sm'
              color='var(--color-text-secondary)'
              style={{ fontWeight: '400', fontSize: '12px' }}
            >
              {formatTimeRange(start, end)}
            </Text>
          </Stack>
          <Stack direction='row' alignItems='center'>
            <TruncatedText
              $type='sm'
              weight='bold'
              color='var(--color-text-primary)'
              style={{
                fontSize: '12px',
                lineHeight: '1.2',
                textWrap: 'unset',
                fontWeight: 'bold',
              }}
              text={title}
            />
          </Stack>
          <Stack direction='row' alignItems='center'>
            <TruncatedText
              $type='xs'
              weight='sm'
              color='var(--color-text-secondary)'
              style={{
                fontSize: '12px',
                fontWeight: '400',
                textWrap: 'unset',
              }}
              text={extendedProps?.location}
            />
          </Stack>
        </Stack>
      </Box>
    </Stack>
  );
};

export default CalendarMonthlyView;
