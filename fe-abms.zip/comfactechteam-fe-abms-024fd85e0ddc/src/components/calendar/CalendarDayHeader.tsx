import React from 'react';

import dayjs from 'dayjs';

import { Text } from '@/styled-components';

import { Stack } from '@mui/material';

const CalendarDayHeader = ({ date, view, selectedUsers }) => {
  const { type } = view;
  let calendarFormat = 'ddd';
  switch (type) {
    case 'dayGridMonth': {
      calendarFormat = 'ddd';
      break;
    }
    case 'timeGridFourDay': {
      calendarFormat = 'ddd M/D';
      break;
    }
    case 'listWeek': {
      calendarFormat = 'dddd';
      break;
    }
    default:
      calendarFormat = 'DD MMM YYYY';
      break;
  }

  return (
    <Stack justifyContent='space-between' direction='row'>
      {type === 'timeGridDay' && (
        <Text $css='font-weight: 500 !important; color: #1F2226; font-size: 14px !important;'>
          {selectedUsers?.length
            ? selectedUsers?.map(e => e)?.join(', ')
            : 'All users'}
        </Text>
      )}
      {(type === 'dayGridMonth' || type === 'timeGridFourDay') && (
        <Text $type='sm' weight='semibold'>
          {dayjs(date).format(calendarFormat)}
        </Text>
      )}
      {type === 'listWeek' && (
        <>
          <Text $type='sm' weight='semibold'>
            {dayjs(date).format(calendarFormat)}
          </Text>
          <Text $type='sm' weight='semibold'>
            {dayjs(date).format('DD MMM YYYY')}
          </Text>
        </>
      )}
    </Stack>
  );
};

export default CalendarDayHeader;
