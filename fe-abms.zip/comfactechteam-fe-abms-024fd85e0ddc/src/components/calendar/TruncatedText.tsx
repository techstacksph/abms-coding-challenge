import React from 'react';

import { Text } from '@/styled-components';

import { Tooltip } from '@mui/material';

const TruncatedText = ({
  text,
  disabled = false,
  numberOfLines = 1,
  ellipsis = true,
  ...props
}) => {
  if (!text) return null;

  const cssStyles = `
    overflow: hidden;
    ${
      ellipsis
        ? `
      text-overflow: ellipsis;
      display: -webkit-box !important;
      white-space: normal;
      -webkit-line-clamp: ${numberOfLines};
      -webkit-box-orient: vertical;
    `
        : `
      text-overflow: clip;
      white-space: normal;
      word-wrap: break-word;
      overflow-wrap: break-word;
    `
    }
  `;

  return (
    <Tooltip title={disabled ? '' : text}>
      <span style={{ width: '100%', overflow: 'hidden' }}>
        <Text $css={cssStyles} {...props}>
          {text}
        </Text>
      </span>
    </Tooltip>
  );
};

export default TruncatedText;
