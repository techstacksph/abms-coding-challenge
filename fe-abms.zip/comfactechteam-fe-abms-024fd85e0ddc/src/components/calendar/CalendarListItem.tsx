import React from 'react';

import { Text, MaterialIcon, Button, Icon, Delete } from '@/styled-components';
import { formatTimeRange } from '@/utils/date.utils';

import {
  MoreVert,
  InfoOutlined,
  ModeEditOutlineOutlined,
} from '@mui/icons-material';
import { Box, Stack } from '@mui/material';
import { haveData } from '@/utils/helper.utils';

import { Dropdown } from 'antd';

import TruncatedText from './TruncatedText';

const CalendarListItem = props => {
  const { start, end, title, extendedProps } = props.event;

  const statusColor =
    extendedProps.status === 'cancelled' ||
    extendedProps.status === 'completed';
  let textStatus = '';
  if (extendedProps.status === 'cancelled') textStatus = 'Cancelled: ';
  if (extendedProps.status === 'completed') textStatus = 'Completed: ';

  return (
    <Stack
      spacing={0.5}
      direction='row'
      justifyContent='space-between'
      sx={{
        ':hover button': {
          visibility: 'visible',
        },
      }}
    >
      <Box>
        <Box>
          <Text
            $type='xs'
            weight='semibold'
            color={`var(--color-text-${statusColor ? 'tertiary' : 'primary'})`}
          >
            {formatTimeRange(start, end)}
          </Text>
        </Box>
        <Stack spacing={0.5} pl={0.5}>
          <Stack direction='row' alignItems='center' spacing={1}>
            <MaterialIcon
              name='event'
              $css={`color: ${
                statusColor ? '#A7AAB2' : '#878B97'
              }; font-size: 18px;`}
            />
            <TruncatedText
              $type='sm'
              weight='bold'
              color={`var(--color-text-${
                statusColor ? 'tertiary' : 'primary'
              })`}
              style={{
                fontWeight: 'bold',
                textDecoration:
                  extendedProps.status === 'cancelled' ? 'line-through' : '',
              }}
              numberOfLines={1}
              ellipsis
              text={`${textStatus} ${title}`}
            />
          </Stack>
          <Stack direction='row' alignItems='center' spacing={1}>
            <MaterialIcon
              name='location_on'
              $css={`color: ${
                statusColor ? '#A7AAB2' : '#878B97'
              }; font-size: 18px;`}
            />
            <TruncatedText
              $type='xs'
              color={`var(--color-text-${
                statusColor ? 'tertiary' : 'secondary'
              })`}
              numberOfLines={1}
              ellipsis
              text={extendedProps.location || haveData('')}
            />
          </Stack>
          <Stack direction='row' alignItems='center' spacing={1}>
            <MaterialIcon
              name='person'
              $css={`color: ${
                statusColor ? '#A7AAB2' : '#878B97'
              }; font-size: 18px;`}
            />
            <Text
              $type='xs'
              color={`var(--color-text-${
                statusColor ? 'tertiary' : 'secondary'
              })`}
            >
              {extendedProps.assignee?.length
                ? extendedProps.assignee?.join(', ')
                : haveData('')}
            </Text>
          </Stack>
        </Stack>
      </Box>
      <Dropdown
        menu={{
          items: [
            {
              key: 'view',
              label: (
                <Stack direction='row' spacing={1} alignItems='center'>
                  <Icon color='#878B97'>
                    <InfoOutlined />
                  </Icon>
                  <Text>More Details</Text>
                </Stack>
              ),
            },
            {
              key: 'edit',
              label: (
                <Stack direction='row' spacing={1} alignItems='center'>
                  <Icon color='#878B97'>
                    <ModeEditOutlineOutlined />
                  </Icon>
                  <Text>Edit</Text>
                </Stack>
              ),
              expandIcon: <></>,
              children: [
                {
                  key: 'this-event',
                  label: 'This event',
                },
                {
                  key: 'this-and-all-event',
                  label: 'This and all following events',
                },
                {
                  key: 'all-event',
                  label: 'All events in the series',
                },
              ],
            },
            {
              key: 'delete',
              label: (
                <Stack direction='row' spacing={1} alignItems='center'>
                  <Icon color='#878B97'>
                    <Delete />
                  </Icon>
                  <Text>Delete</Text>
                </Stack>
              ),
            },
          ],
        }}
        trigger={['click']}
      >
        <Button
          type='text'
          icon={
            <Icon color='var(--gray-500)'>
              <MoreVert />
            </Icon>
          }
          $css='visibility: hidden;'
        />
      </Dropdown>
    </Stack>
  );
};

export default CalendarListItem;
