import { Dayjs } from 'dayjs';

import { FrequencyEnum } from '@/constants/Frequency';
import {
  IFrequencyValues,
  IFrequencyWeeklyValues,
} from '@/typings/frequency.types';

import { FormInstance } from 'antd';

export const setDefaultValues = (
  frequency: FrequencyEnum,
  form: FormInstance
) => {
  let startDate: Dayjs = form.getFieldValue('startDate');
  const startTime: Dayjs = form.getFieldValue('startTime');
  const endTime: Dayjs = form.getFieldValue('endTime');

  let endDate = startDate?.add(2, 'months');

  if (startDate) {
    startDate = startDate.set('hour', startTime.hour());
    startDate = startDate.set('minutes', startTime.minute());

    endDate = startDate.set('hour', endTime.hour());
    endDate = startDate.set('minutes', endTime.minute());
  }

  if (frequency === FrequencyEnum.DAILY || frequency === FrequencyEnum.WEEKLY) {
    form.setFieldsValue({
      frequencyValues: {
        startDate: startDate,
        date: 1,
        endDate: endDate.add(2, 'months'),
        order: null,
        dayWeek: null,
        onTheDay: null,
        onTheMonth: null,
        onEveryMonth: null,
        radio: null,
      },
    });
    return;
  }

  if (frequency === FrequencyEnum.MONTHLY) {
    form.setFieldsValue({
      frequencyValues: {
        startDate: startDate,
        date: 1,
        order: 'FIRST',
        dayWeek: 'MONDAY',
        onTheDay: startDate.format('D'),
        endDate: startDate.add(6, 'months'),
        radio: null,
      },
    });
    return;
  }

  if (frequency === FrequencyEnum.YEARLY) {
    form.setFieldsValue({
      frequencyValues: {
        startDate: startDate,
        date: 1,
        order: 'FIRST',
        dayWeek: 'MONDAY',
        onTheDay: startDate.format('D'),
        endDate: startDate.add(2, 'years'),
        onTheMonth: startDate.format('MMMM').toUpperCase(),
        onEveryMonth: startDate.format('MMMM').toUpperCase(),
        radio: null,
      },
    });
    return;
  }
};

export const validateFrequency = (
  frequencyValues: IFrequencyValues,
  form: FormInstance
): boolean => {
  const errors = [];

  if (!frequencyValues?.startDate) {
    errors.push(['frequencyValues', 'startDate']);
  }

  const frequency = form.getFieldValue('frequency');
  if (frequency === FrequencyEnum.WEEKLY) {
    const weeklyDays = (frequencyValues as IFrequencyWeeklyValues).days;
    if (!weeklyDays || weeklyDays.length === 0) {
      errors.push(['frequencyValues', 'days']);
    }
  }

  if (errors.length > 0) {
    const formError = errors.map(e => ({
      name: e,
      errors: ['This field is required.'],
    }));
    form.setFields(formError);
    return false;
  }

  form.setFields([]);
  return true;
};
