import React, { useMemo } from 'react';

import { FormSection, Text } from '@/styled-components';

import { FrequencyEnum } from '@/constants/Frequency';
import { Box } from '@mui/material';
import { TFrequencyRadioValues } from '@/typings/frequency.types';
import { FrequencyFormProp, InputSection } from '@/typings/inputField.types';
import {
  disableFrequencyField,
  frequencyFields,
} from '@/utils/frequency.utils';

import { Space, Row, Col, Form } from 'antd';

const Monthly = ({ form, frequency: propsFrequency }: FrequencyFormProp) => {
  const frequency = Form.useWatch<TFrequencyRadioValues>('frequencyValues', {
    form,
  });

  const isMonthly = propsFrequency === FrequencyEnum.MONTHLY;

  const { onDayField, onTheOrderField, onTheDayOfWeekField } = useMemo(() => {
    const onThe = frequency?.radio;

    let onDayField = frequencyFields.on.day.field as InputSection;
    let onTheOrderField = frequencyFields.on.the.order as InputSection;
    let onTheDayOfWeekField = frequencyFields.on.the.dayOfWeek as InputSection;

    if (onThe && isMonthly) {
      onDayField = disableFrequencyField(onDayField, onThe !== 'day', form);
      onTheOrderField = disableFrequencyField(
        onTheOrderField,
        onThe !== 'the',
        form
      );
      onTheDayOfWeekField = disableFrequencyField(
        onTheDayOfWeekField,
        onThe !== 'the',
        form
      );
    }

    return {
      onDayField,
      onTheOrderField,
      onTheDayOfWeekField,
    };
  }, [frequency?.radio]);

  return (
    <Box display={isMonthly ? 'block' : 'none'}>
      <FormSection fields={frequencyFields.startDate} />
      <Box pt={2} pb={2}>
        <Text
          $type='md'
          weight='semibold'
          style={{ fontSize: '14px', fontWeight: 500 }}
        >
          Repeat every
        </Text>
      </Box>
      <Space wrap size='middle'>
        <FormSection fields={frequencyFields.day} $css='width: 53px' />
        <FormSection fields={frequencyFields.frequency} />
      </Space>
      <Row>
        <Col span={24} style={{ marginTop: '16px' }}>
          <Space size='middle'>
            <FormSection fields={frequencyFields.on.day.radio} />
            <FormSection fields={onDayField} $css='width: 53px' />
          </Space>
        </Col>
      </Row>
      <Row>
        <Col span={24} style={{ marginTop: '16px' }}>
          <Space size='middle'>
            <FormSection fields={frequencyFields.on.the.radio} />
            <FormSection fields={onTheOrderField} />
            <FormSection fields={onTheDayOfWeekField} />
          </Space>
        </Col>
      </Row>
    </Box>
  );
};

export default Monthly;
