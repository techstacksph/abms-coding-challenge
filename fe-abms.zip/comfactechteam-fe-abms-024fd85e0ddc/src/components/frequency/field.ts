import { FrequencyEnum } from '@/constants/Frequency';
import { labelSpan } from '@/utils/inputProps.util';

export const frequencyField = (
  required = false,
  openModal: (value) => void
) => ({
  fields: [
    {
      title: 'Frequency',
      field: 'frequency',
      type: 'select',
      required: required,
      props: {
        ...labelSpan,
        wrapperCol: {
          span: 5,
        },
      },
      isSort: false,
      inputProps: {
        options: [
          { value: FrequencyEnum.DOES_NOT_REPEAT, label: 'Does not repeat' },
          { value: FrequencyEnum.DAILY, label: 'Daily' },
          { value: FrequencyEnum.WEEKLY, label: 'Weekly' },
          { value: FrequencyEnum.MONTHLY, label: 'Monthly' },
          { value: FrequencyEnum.YEARLY, label: 'Yearly' },
          { value: FrequencyEnum.CUSTOM, label: 'Custom' },
        ],
        defaultValue: FrequencyEnum.DOES_NOT_REPEAT,
        onChange: openModal,
      },
    },
  ],
});
