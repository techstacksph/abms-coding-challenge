import React, { useMemo } from 'react';

import { FormSection, Text } from '@/styled-components';

import { Stack } from '@mui/material';
import { TFrequencyRadioValues } from '@/typings/frequency.types';
import { FrequencyFormProp, InputSection } from '@/typings/inputField.types';
import {
  disableFrequencyField,
  frequencyFields,
} from '@/utils/frequency.utils';

import { Form } from 'antd';

const Custom = ({ form }: FrequencyFormProp) => {
  const frequency = Form.useWatch<TFrequencyRadioValues>('frequencyValues', {
    form,
  });

  const {
    onEveryMonthField,
    onEveryDayField,
    onTheOrderField,
    onTheDayOfWeekField,
    onTheMonthField,
  } = useMemo(() => {
    const onThe = frequency?.radio;

    let onEveryMonthField = frequencyFields.on.every.month as InputSection;
    let onEveryDayField = frequencyFields.on.day.field as InputSection;
    let onTheOrderField = frequencyFields.on.the.order as InputSection;
    let onTheDayOfWeekField = frequencyFields.on.the.dayOfWeek as InputSection;
    let onTheMonthField = frequencyFields.on.the.month as InputSection;

    if (onThe) {
      onEveryMonthField = disableFrequencyField(
        onEveryMonthField,
        onThe !== 'every',
        form
      );

      onEveryDayField = disableFrequencyField(
        onEveryDayField,
        onThe !== 'every',
        form
      );

      onTheOrderField = disableFrequencyField(
        onTheOrderField,
        onThe !== 'the',
        form
      );
      onTheDayOfWeekField = disableFrequencyField(
        onTheDayOfWeekField,
        onThe !== 'the',
        form
      );
      onTheMonthField = disableFrequencyField(
        onTheMonthField,
        onThe !== 'the',
        form
      );
    }

    return {
      onEveryMonthField,
      onEveryDayField,
      onTheOrderField,
      onTheDayOfWeekField,
      onTheMonthField,
    };
  }, [frequency]);

  return (
    <Stack direction='column' spacing={1.5}>
      <Stack direction='row' alignItems='center' sx={{ width: '100%' }}>
        <FormSection fields={frequencyFields.startDate} />
      </Stack>
      <Text
        $type='md'
        weight='semibold'
        style={{ fontSize: '14px', fontWeight: 500 }}
      >
        Repeat every
      </Text>
      <Stack direction='row' spacing={1.5} sx={{ width: '100%' }}>
        <FormSection fields={frequencyFields.day} $css='width: 53px' />
        <FormSection fields={frequencyFields.frequency} />
      </Stack>
      <Stack direction='row' spacing={1.5} sx={{ width: '100%' }}>
        <FormSection fields={frequencyFields.on.day.radio} />
        <FormSection
          fields={onEveryMonthField}
          $css='width: 108px; [class*="col-md-24"] {padding-left: 0px !important;}'
        />
        <FormSection
          fields={onEveryDayField}
          $css='width: 53px; [class*="col-md-24"] {padding-left: 0px !important;}'
        />
      </Stack>
      <Stack
        direction='row'
        alignItems='center'
        spacing={1.5}
        sx={{ width: '100%' }}
      >
        <FormSection fields={frequencyFields.on.the.radio} />
        <FormSection fields={onTheOrderField} />
        <FormSection fields={onTheDayOfWeekField} />
        <Text>of</Text>
        <FormSection fields={onTheMonthField} />
      </Stack>
      <FormSection fields={frequencyFields.endDate} />
    </Stack>
  );
};

export default Custom;
