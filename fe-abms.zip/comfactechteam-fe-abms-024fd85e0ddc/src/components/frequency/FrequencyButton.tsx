import React, { useEffect, useMemo, useState } from 'react';

import { FormSection, useModal, Text, Button } from '@/styled-components';

import { CaretDownOutlined } from '@ant-design/icons';
import { FrequencyEnum } from '@/constants/Frequency';
import { Box, Stack } from '@mui/material';
import { formatFrequency, frequencyFields } from '@/utils/frequency.utils';

import { FormInstance, Form as AntdForm } from 'antd';

import Daily from './Daily';
import Monthly from './Monthly';
import Weekly from './Weekly';
import Yearly from './Yearly';
import { frequencyField } from './field';
import { setDefaultValues, validateFrequency } from './service';

const FrequencyButton = ({
  form,
  required,
  formType,
  localStorageKey,
}: {
  form: FormInstance;
  required?: boolean;
  formType?: 'Edit' | 'New';
  localStorageKey?: {
    key: string;
    transformer: (data: string) => any;
  };
}) => {
  const [saved, setSaved] = useState<any>();

  const selectedFrequency = AntdForm.useWatch('frequency', {
    form,
    preserve: true,
  });
  const frequency = AntdForm.useWatch(['frequencyValues'], {
    form,
    preserve: true,
  });

  const startDate = AntdForm.useWatch(['frequencyValues', 'startDate'], {
    form,
    preserve: true,
  });

  useEffect(() => {
    if (!saved || saved?.frequency !== selectedFrequency) {
      setDefaultValues(selectedFrequency, form);
    } else {
      form.setFieldValue('frequencyValues', saved);
    }
  }, [selectedFrequency, saved]);

  useEffect(() => {
    if (startDate) {
      form.setFields([
        { name: ['frequencyValues', 'startDate'], errors: null },
      ]);
    }
  }, [startDate]);

  const occurString = useMemo(() => {
    return formatFrequency(frequency, selectedFrequency);
  }, [frequency, selectedFrequency]);

  const onClose = () => {
    if (!saved) {
      form.setFieldValue('frequency', FrequencyEnum.DOES_NOT_REPEAT);
    } else {
      form.setFieldValue('frequencyValues', saved);
    }
    closeModal();
  };

  const onSave = () => {
    const savedValues = form.getFieldValue('frequencyValues');

    const valid = validateFrequency(savedValues, form);

    if (valid) {
      setSaved({ ...savedValues, frequency: selectedFrequency });
      closeModal();
    }
  };

  useEffect(() => {
    const savedLocal = localStorage.getItem(localStorageKey.key);
    if (savedLocal) {
      const transformData = localStorageKey.transformer(savedLocal);

      if (transformData?.frequencyValues) {
        setSaved(transformData?.frequencyValues);
        return;
      }
    }

    if (formType === 'Edit' && !saved) {
      setSaved(frequency);
    }
  }, [frequency]);

  const endDateField = useMemo(() => {
    if (frequency?.startDate) {
      const field = frequencyFields.endDate.fields[0];
      field.inputProps = {
        ...field.inputProps,
        defaultValue: null,
        minDate: frequency.startDate,
      };

      frequencyFields.endDate.fields[0] = field;
      return frequencyFields.endDate;
    }

    return frequencyFields.endDate;
  }, [frequency?.startDate]);

  const [openModal, closeModal, contextModal] = useModal({
    title: 'Set recurrence',
    message: (
      <Stack spacing={1}>
        <Stack>
          {selectedFrequency === FrequencyEnum.DAILY && <Daily />}
          {selectedFrequency === FrequencyEnum.WEEKLY && <Weekly />}
          <Monthly form={form} frequency={selectedFrequency} />
          <Yearly form={form} frequency={selectedFrequency} />
          <FormSection fields={endDateField} />
          <Text>{occurString}</Text>
        </Stack>
        <Stack direction='row' justifyContent='flex-end' spacing={1.5}>
          <Button $css='width: 120px' onClick={onClose}>
            Cancel
          </Button>
          <Button $css='width: 120px' type='primary' onClick={onSave}>
            Save
          </Button>
        </Stack>
      </Stack>
    ),
    modalProps: {
      modalProps: {
        width: 600,
        $css: `
          color: #eee;
          & [class*="modal-body"] > [class*="row-no-wrap"] { 
            width: 100%;
            display: inline-block;
          }

          & [class*="modal-body"] [class*="row-no-wrap"] [class*="col"] > [class*="col"] {
            padding-right: 0px !important;
          }

          & [class$="modal-footer"] {
            display: none;
          }
        `,
      },
      cancelProps: {
        style: {
          display: 'none',
        },
      },
      submitProps: {
        style: {
          display: 'none',
        },
      },
    },
  });

  const onOpen = value => {
    if (value === FrequencyEnum.CUSTOM) {
      form.setFieldValue('frequency', FrequencyEnum.DAILY);
    }
    openModal();
  };

  return (
    <Box>
      {contextModal}
      {saved ? (
        <Stack spacing={1}>
          <Text weight='medium' $css='line-height: 20px;'>
            Frequency
          </Text>
          <Stack
            direction='row'
            spacing={1}
            onClick={onOpen}
            sx={{
              borderRadius: '8px',
              py: 1,
              border: '1px solid #d9d9d9',
              width: 'fit-content',
              px: '11px',
              '&:hover': {
                backgroundColor: 'transparent',
                borderColor: '#596168',
                cursor: 'pointer',
              },
            }}
          >
            <span>{formatFrequency(saved, (saved as any)?.frequency)}</span>
            <CaretDownOutlined style={{ fontSize: 12, color: '#878B97' }} />
          </Stack>
        </Stack>
      ) : (
        <FormSection fields={frequencyField(required, onOpen)} />
      )}
    </Box>
  );
};

export default FrequencyButton;
