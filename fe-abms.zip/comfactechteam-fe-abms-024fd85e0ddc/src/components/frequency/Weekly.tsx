import React from 'react';

import { FormSection, Text } from '@/styled-components';

import { Box } from '@mui/material';
import { frequencyFields } from '@/utils/frequency.utils';

import { Space, Row, Col } from 'antd';

const Weekly = () => {
  return (
    <Box>
      <FormSection fields={frequencyFields.startDate} />
      <Box pt={2} pb={2}>
        <Text
          $type='md'
          weight='semibold'
          style={{ fontSize: '14px', fontWeight: 500 }}
        >
          Repeat every
        </Text>
      </Box>
      <Space wrap size='middle'>
        <FormSection fields={frequencyFields.day} $css='width: 53px' />
        <FormSection fields={frequencyFields.frequency} />
      </Space>

      <Row>
        <Col span={24} style={{ marginTop: '16px' }}>
          <FormSection fields={frequencyFields.repeatDays} />
        </Col>
      </Row>
    </Box>
  );
};

export default Weekly;
