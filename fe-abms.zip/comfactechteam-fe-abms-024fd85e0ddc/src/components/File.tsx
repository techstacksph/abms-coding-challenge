import React from 'react';

import { GoogleIcon, Text } from '@/styled-components';

import { Stack } from '@mui/material';

const File = ({
  file,
  sx,
  stackProps,
  textProps,
  size = '20px',
}: {
  file: string;
  sx?: any;
  stackProps?: any;
  textProps?: any;
  size?: any;
}) => {
  const icons = {
    doc: {
      icon: 'description',
      color: '#3137FD',
    },
    docs: {
      icon: 'description',
      color: '#3137FD',
    },
    docx: {
      icon: 'description',
      color: '#3137FD',
    },
    txt: {
      icon: 'description',
      color: '#3137FD',
    },
    xml: {
      icon: 'description',
      color: '#3137FD',
    },
    xls: {
      icon: 'table',
      color: '#31D48B',
    },
    ods: {
      icon: 'table',
      color: '#31D48B',
    },
    xlsx: {
      icon: 'table',
      color: '#31D48B',
    },
    csv: {
      icon: 'table',
      color: '#31D48B',
    },
    tsv: {
      icon: 'table',
      color: '#31D48B',
    },
    pdf: {
      icon: 'picture_as_pdf',
      color: '#EA3927',
    },
    jpg: {
      icon: 'photo',
      color: '#E76B36',
    },
    jpeg: {
      icon: 'photo',
      color: '#E76B36',
    },
    png: {
      icon: 'photo',
      color: '#E76B36',
    },
    svg: {
      icon: 'photo',
      color: '#E76B36',
    },
    ppt: {
      icon: 'tile_large',
      color: '#FDB61C',
    },
    pptx: {
      icon: 'tile_large',
      color: '#FDB61C',
    },
    odp: {
      icon: 'tile_large',
      color: '#FDB61C',
    },
  };

  const fileName = String(file).split('.');
  const ext = fileName[fileName.length - 1];

  const icon = icons[ext] ? icons[ext].icon : 'draft';
  const color = icons[ext] ? icons[ext].color : '#A7AAB2';

  return (
    <Stack
      gap={0.5}
      direction='row'
      width='fit-content'
      maxWidth='100%'
      sx={sx}
      {...stackProps}
    >
      <GoogleIcon
        name={icon}
        fill={true}
        $css={`
          color: ${color};
          font-size: ${size};
        `}
      />
      <Text ellipsis {...textProps}>
        {file}
      </Text>
    </Stack>
  );
};

export default File;
