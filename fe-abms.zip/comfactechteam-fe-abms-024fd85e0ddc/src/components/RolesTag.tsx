import React, { useMemo } from 'react';

import { StatusTag, GoogleIcon, Icon } from '@/styled-components';

import { Roles } from '../constants/roles';

const RolesTag = ({ role }: { role?: Roles }) => {
  const label = useMemo(() => {
    switch (role) {
      case Roles.SUPER_ADMIN:
        return (
          <>
            {role}{' '}
            <Icon size='16px' color='#FDB61C'>
              <GoogleIcon name='award_star' />
            </Icon>
          </>
        );
      default:
        return role;
    }
  }, [role]);
  return (
    <StatusTag
      $css={`
        text-transform: capitalize; 
        overflow: hidden;
        text-overflow: ellipsis;
        width: fit-content;
        
        /* lg */
        @media (min-width: 992px) {
          max-width: 120px;
        }
        /* xl */
        @media (min-width: 1200px) {
          max-width: 333px;
        }
      `}
      label={label}
    />
  );
};

export default RolesTag;
