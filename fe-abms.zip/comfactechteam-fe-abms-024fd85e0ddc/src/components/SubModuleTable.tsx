import React from 'react';

import {
  ModuleTable as Table,
  Text,
  Select,
  GoogleIcon,
  EmptyState,
} from '@/styled-components';

import { Stack } from '@mui/material';

const RowsPerPage = ({ total, range, setPageSize, pageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        defaultValue={pageSize || 10}
        options={[
          {
            label: '10',
            value: 10,
          },
          {
            label: '20 ',
            value: 20,
          },
          {
            label: '50',
            value: 50,
          },
          {
            label: '100',
            value: 100,
          },
        ]}
        onChange={val => setPageSize(val)}
        suffixIcon={
          <GoogleIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
            &[class*="-select-focused"] [class*="-select-selector"] {
              box-shadow: none;
            }

            [class$="select-selection-item"] {
              color: var(--color-text-primary) !important;
              font-size: 12px;
              padding-inline-end: 24px !important;
            }
            [class$="select-selector"] {
              gap: 4px;
              padding: 0 4px;
              border-width: 0 !important;
            }
          `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};

const SubModuleTable = ({ columns, data, pageSize, setPageSize, tableProps = {}, ...props }) => {
  return (
    <Table
      columns={columns}
      data={data}
      paginationText={'Rows per page'}
      showPaginationItems={false}
      hidePagination
      tableProps={{
        ...(pageSize
          ? {
              pagination: {
                total: data?.length,
                showSizeChanger: false,
                position: ['bottom', 'left'],
                pageSize: pageSize,
                showTotal: (total, range) => (
                  <RowsPerPage
                    total={total}
                    range={range}
                    setPageSize={setPageSize}
                    pageSize={pageSize}
                  />
                ),
                itemRender: (_, type, originalElement) =>
                  type === 'page' ? null : originalElement,
              },
            }
          : {}),
        ...(tableProps || {}),
      }}
      emptyState={<EmptyState iconW='200px' title='No data to display.' />}
      {...props}
    />
  );
};

export default SubModuleTable;
