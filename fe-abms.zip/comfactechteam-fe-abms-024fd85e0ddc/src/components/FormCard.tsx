import React from 'react';

import { Text, Content } from '@/styled-components';

import { Stack, Box, StackProps, BoxProps } from '@mui/material';

import { Spin } from 'antd';

const FormCard = ({
  title,
  loading = false,
  containerProps,
  childContainerProps,
  children,
  showBorder = true,
  $css = '',
}: {
  title?: string;
  loading?: boolean;
  containerProps?: StackProps;
  childContainerProps?: BoxProps;
  children: React.ReactNode;
  showBorder?: boolean;
  $css?: string;
}) => {
  return (
    <Content padding={{ px: 40, py: 40 }} $css={$css}>
      <Spin spinning={loading}>
        <Stack spacing={4.5} {...containerProps}>
          {title && (
            <Box
              borderBottom={showBorder ? '1px solid var(--gray-200)' : 'none'}
              pb={1.5}
            >
              <Text $type='lg' weight='semibold' $css='line-height: 28px;'>
                {title}
              </Text>
            </Box>
          )}
          <Box {...childContainerProps}>{children}</Box>
        </Stack>
      </Spin>
    </Content>
  );
};

export default FormCard;
