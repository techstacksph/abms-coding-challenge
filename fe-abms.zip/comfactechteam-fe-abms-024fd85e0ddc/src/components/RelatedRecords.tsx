import React, { memo } from 'react';

import { Text, MaterialIcon } from '@/styled-components';

import { Stack, Box } from '@mui/material';

import Link from './Link';

interface RelatedModule {
  module: string;
  relatesTo: string;
  relatedUrl: string;
  icon?: any;
  direction?: 'row' | 'column';
  isUnderRelatedTo?: boolean;
  isHidden?: boolean;
  moduleColor?: string;
  multipleRelated?: Array<{
    relatesTo: string;
    relatedUrl: string;
  }>;
  moduleCss?: string;
}

const RelatedItem = memo((props: RelatedModule) => {
  const {
    direction = 'row',
    multipleRelated = [
      {
        relatesTo: props.relatesTo,
        relatedUrl: props.relatedUrl,
      },
    ],
  } = props;
  const alignment = direction === 'row' ? 'center' : 'left';

  return (
    <Stack
      direction={direction}
      alignItems={alignment}
      spacing={1}
      width='100%'
    >
      <Box
        width={
          props?.isUnderRelatedTo || props?.isUnderRelatedTo == undefined
            ? '100px'
            : '100%'
        }
      >
        {props?.icon && props?.icon}{' '}
        {props?.module ? (
          <Text
            $type='sm'
            color={props?.moduleColor || '#090A0B'}
            $css={props?.moduleCss}
          >
            {props?.module}
          </Text>
        ) : (
          <Text color='var(--table-no-data)'>No data</Text>
        )}
      </Box>

      {direction === 'row' && props?.module != 'Other' && (
        <MaterialIcon
          name='arrow_right'
          $css={`
            color: rgba(135, 139, 151, 1);
          `}
        />
      )}
      {props?.module !== 'Other' &&
        (multipleRelated.length > 0 ? (
          multipleRelated.map((item, index) => (
            <Box key={index} sx={{ flex: 1 }}>
              {item.relatesTo ? (
                <Link $css='font-weight: 500' to={item.relatedUrl}>
                  {item.relatesTo}
                </Link>
              ) : (
                <Text color='var(--table-no-data)'>No data</Text>
              )}
            </Box>
          ))
        ) : (
          <Text color='var(--table-no-data)'>No data</Text>
        ))}
    </Stack>
  );
});
RelatedItem.displayName = 'RelatedItem';

const RelatedRecords = ({
  relatedItems,
  relatedToDisplayed = true,
  moduleColor,
  hideRelatedTo = false,
  gap = 16,
  moduleCss,
}: {
  relatedItems: Array<RelatedModule>;
  relatedToDisplayed?: boolean;
  moduleColor?: string;
  hideRelatedTo?: boolean;
  gap?: number;
  moduleCss?: string;
}) => {
  return (
    <Stack spacing={1}>
      {!hideRelatedTo && (
        <Text
          $type='sm'
          color='var(--color-text-secondary)'
          $css={`display: ${relatedToDisplayed ? 'block' : 'none'}`}
        >
          Related to
        </Text>
      )}
      <Stack spacing={`${gap}px`} marginTop={'-8px'}>
        {relatedItems
          .filter(a => !a.isHidden)
          .map((r, i) => (
            <RelatedItem
              key={i}
              {...r}
              moduleColor={moduleColor}
              moduleCss={moduleCss}
            />
          ))}
      </Stack>
    </Stack>
  );
};

export default memo(RelatedRecords);
