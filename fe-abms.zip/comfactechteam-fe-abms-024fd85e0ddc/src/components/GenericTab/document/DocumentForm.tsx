import React from 'react';
import { Box } from '@mui/material';

import FormHeader from '@/views/documents/common/components/FormHeader';
import DocumentProvider from '@/views/documents/common/components/FormProvider';
import DocumentInformation from '@/views/documents/common/components/form/DocumentInformation';
import { CREATE_DOCUMENT } from '@/graphql/document.gql';

interface DocumentFormProps {
  mode: 'new' | 'edit';
  breadCrumbs: string[];
  tabMode?: boolean; // New prop to hide related record section
  [key: string]: any;
}

const DocumentForm: React.FC<DocumentFormProps> = ({
  mode,
  breadCrumbs,
  tabMode = false, // Default to false
  ...props
}) => {
  const renderFormProvider = () => {
    if (mode === 'new') {
      return (
        <DocumentProvider.New
          query={CREATE_DOCUMENT}
          nameField='documentName'
          tabMode={tabMode}
          {...props}
        >
          <FormHeader
            view='New'
            breadCrumbs={breadCrumbs}
            titleDisplaySize={15}
            endDisplaySize={9}
          />
          <DocumentInformation tabMode={tabMode} {...props} />
        </DocumentProvider.New>
      );
    }

    return (
      <DocumentProvider.Edit {...props}>
        <FormHeader
          view='Edit'
          breadCrumbs={breadCrumbs}
          titleDisplaySize={15}
          endDisplaySize={9}
        />
        <DocumentInformation tabMode={tabMode} {...props} />
      </DocumentProvider.Edit>
    );
  };

  return <Box>{renderFormProvider()}</Box>;
};

export default DocumentForm;
