import React, { useEffect, useMemo, useState } from 'react';
import { ModuleActions, Text, useSnackbar } from '@/styled-components';
import DataTable from '@/components/DataTable';
import ModuleAlert, { ModuleRowSelection } from '@/components/ModuleAlert';
import environment from '@/config/environment';
import { MIN_SEARCH_LENGTH } from '@/constants/ui';
import {
  ALL_DOCUMENTS,
  DELETE_DOCUMENTS,
  PAGINATED_DOCUMENTS,
} from '@/graphql/document.gql';
import useMutation from '@/hooks/useMutation';
import useNavigate from '@/hooks/useNavigate';
import Document from '@/models/Document';
import { Box, Stack } from '@mui/material';
import { mapArrToCSVFields, convertToCSVBase64 } from '@/utils/array.utils';
import { saveCSVFile } from '@/services/export.services';
import { getSearchParams } from '@/utils/string.utils';
import { listColumns } from '@/views/documents/common/columns';
import {
  MODULE_NAME,
  MODULE_NAME_SINGULAR,
  relatedModuleFieldMap,
} from '@/views/documents/common/constants';
import { exportFields, searchFields } from '@/views/documents/common/fields';
import { filters } from '@/views/documents/common/filters';
import useGlobalOptions from '@/hooks/useGlobalOptions';
import { SortArg, SortDirection } from '@/typings/module.types';
import {
  getDeleteSuccessMessage,
  getDeleteErrorMessage,
  getDeleteConfirmationMessageJSX,
} from '@/utils/message.helper.utils';
import dayjs from 'dayjs';

const TENANT_PREFIX = environment.TENANT_PREFIX;

interface DocumentsDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  onNewDocument?: () => void;
  onEditDocument?: (document: Document) => void;
  onViewDocument?: (document: Document) => void;
  searchArg?: Array<{
    fieldName: string;
    comparator: string;
    searchValue: string;
    inOr?: boolean;
  }>;
}

const DocumentsDataTable: React.FC<DocumentsDataTableProps> = ({
  id,
  module,
  tab,
  setTab,
  onNewDocument,
  onEditDocument,
  onViewDocument,
  searchArg,
}) => {
  const { snackbar } = useSnackbar();
  const { navigate } = useNavigate('List');

  // Get the related record field name based on the module
  const relatedRecordFieldName = relatedModuleFieldMap[module] || 'accountId';

  const [selected, setSelected] = useState<ModuleRowSelection<Document>>({
    selected: [],
  });
  const [search, setSearch] = useState([]);
  const [refetch, setRefetch] = useState<boolean>(false);
  const [allQueryData, setAllQueryData] = useState<Array<Document>>([]);
  const [page, setPage] = useState<number>(1);
  const [sortArg, setSortArg] = useState<Array<SortArg>>([
    {
      field: 'documentName',
      direction: 'asc' as SortDirection,
    },
  ]);
  const [listFilters, setListFilters] = useState([]);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [forceLoadAllData, setForceLoadAllData] = useState<boolean>(false);
  const [isDataLoading, setIsDataLoading] = useState<boolean>(false);

  // Get global options for filters
  const {
    users: dbUsers,
    documentTypes: dbDocumentTypes,
    usersLoading: isUsersLoading,
    documentTypesLoading: isDocumentTypesLoading,
  } = useGlobalOptions({
    users: true,
    documentTypes: true,
  });

  // Fetch document types separately
  // const { data: dbDocumentTypes } = useQuery({
  //   query: ALL_DOCUMENT_TYPES,
  // });

  const [deleteDocuments, { loading: deleteDocumentLoading }] = useMutation({
    query: DELETE_DOCUMENTS,
    disableAlert: true,
  });

  const submitDelete = async () => {
    const isPlural = selected.type === 'multiple';
    try {
      await deleteDocuments({
        variables: {
          ids: selected.selected.map(d => d.id),
        },
      });
      snackbar({
        type: 'success',
        message: getDeleteSuccessMessage({
          isPlural: isPlural,
          ...(isPlural
            ? { recordType: MODULE_NAME_SINGULAR }
            : { recordName: selected?.selected?.[0]?.documentName }),
        }),
      });
    } catch (error) {
      console.log({ error });
      snackbar({
        type: 'error',
        message: getDeleteErrorMessage({
          isPlural: isPlural,
          ...(isPlural
            ? { recordType: MODULE_NAME_SINGULAR }
            : { recordName: selected?.selected?.[0]?.documentName }),
        }),
      });
    }

    setSelected({ selected: [] });
    setRefetch(true);
  };

  const handleNewDocument = () => {
    if (onNewDocument) {
      onNewDocument();
    } else {
      const searchParams = getSearchParams(window.location.pathname);
      navigate(`${window.location.pathname}/documents/new${searchParams}`);
    }
  };

  const handleEditDocument = (document: Document) => {
    if (onEditDocument) {
      onEditDocument(document);
    } else {
      const searchParams = getSearchParams(window.location.pathname);
      navigate(
        `${window.location.pathname}/documents/${document.id}/edit${searchParams}`
      );
    }
  };

  const handleViewDocument = (document: Document) => {
    if (onViewDocument) {
      onViewDocument(document);
    } else {
      const searchParams = getSearchParams(window.location.pathname);
      navigate(
        `${window.location.pathname}/documents/${document.id}${searchParams}`
      );
    }
  };

  // Handle search
  const onSearch = e => {
    const str_search = e.target.value;
    if (str_search?.length >= MIN_SEARCH_LENGTH) {
      const searchFilters = searchFields(str_search);
      setSearch(searchFilters);
    }
    if (str_search === '') {
      setSearch([]);
    }
  };

  // Handle filter changes
  const onChangeFilter = dt => {
    const args = [];
    if (dt) {
      Object.entries(dt).forEach(([key, value]: [string, any]) => {
        if (key === 'updatedAt') {
          // Skip if value is null/undefined/empty
          if (
            value === null ||
            value === undefined ||
            (Array.isArray(value) && value.length === 0) ||
            (Array.isArray(value) &&
              value.every(v => v === null || v === undefined))
          ) {
            return;
          }

          let start;
          let end;

          if (Array.isArray(value)) {
            // Handle date range
            start = dayjs(value[0]).startOf('day');
            end = dayjs(value[1]).endOf('day');
          } else {
            // Handle single date - make it a full day range
            const selectedDate = dayjs(value);
            start = selectedDate.startOf('day');
            end = selectedDate.endOf('day');
          }

          args.push({
            fieldName: key,
            comparator: 'BETWEEN',
            dataType: 'DATETIME',
            searchValue: start.toISOString(),
            searchValue1: end.toISOString(),
          });
          return;
        } else if (value instanceof Array && value.length > 0) {
          args.push({
            fieldName: key,
            comparator: 'IN',
            searchValue: value.join(','),
          });
        } else if (value && value !== 'All') {
          args.push({
            fieldName: key,
            comparator: 'EQUAL',
            searchValue: value,
          });
        }
      });
    }
    setListFilters(args);
  };

  // Handle table changes (sorting, pagination)
  const onTableChange = (pagination, filters, sorter, extra) => {
    if (extra?.action === 'paginate') {
      setPage(pagination?.current);
    }

    // Handle sorting
    if (extra?.action === 'sort' && sorter) {
      let newSortArg = [];

      // Handle both single sorter and array of sorters
      if (Array.isArray(sorter)) {
        newSortArg = sorter
          .filter(s => s && s.field && s.order) // Filter out invalid sorters
          .map(s => {
            // Map field names to match backend expectations
            let fieldName = s.field;

            // Handle nested field mappings for backend compatibility
            const fieldMapping = {
              'documentType.name': 'documentType.name', // Keep nested field name
              updatedByName: 'updatedByName',
              documentName: 'documentName',
              updatedAt: 'updatedAt',
            };

            fieldName = fieldMapping[fieldName] || fieldName;

            return {
              field: fieldName,
              direction: s.order === 'ascend' ? 'asc' : 'desc',
            };
          });
      } else if (sorter && sorter.field && sorter.order) {
        // Handle single sorter object
        let fieldName = sorter.field;

        // Handle nested field mappings for backend compatibility
        const fieldMapping = {
          'documentType.name': 'documentType.name', // Keep nested field name
          updatedByName: 'updatedByName',
          documentName: 'documentName',
          updatedAt: 'updatedAt',
        };

        fieldName = fieldMapping[fieldName] || fieldName;

        newSortArg = [
          {
            field: fieldName,
            direction: sorter.order === 'ascend' ? 'asc' : 'desc',
          },
        ];
      }

      if (newSortArg.length > 0) {
        setSortArg(newSortArg);
      }
    }
  };

  // Get document filters
  // const documentFilters = filters({
  //   users: dbUsers,
  //   documentTypes: dbDocumentTypes,
  // });

  const documentFilters = useMemo(() => {
    return filters({
      users: dbUsers ?? [],
      documentTypes: dbDocumentTypes ?? [],
    });
    // return [];
  }, [dbUsers, dbDocumentTypes]);
  // Combine searchArg with user search input
  const combinedSearchFields = useMemo(() => {
    const allSearchFields = [];

    // Add searchArg if provided
    if (searchArg && searchArg.length > 0) {
      allSearchFields.push(...searchArg);
    }

    // Add user search input
    if (search && search.length > 0) {
      allSearchFields.push(...search);
    }

    // Add filter arguments
    if (listFilters && listFilters.length > 0) {
      allSearchFields.push(...listFilters);
    }

    return allSearchFields;
  }, [searchArg, search, listFilters]);

  // Handle export processing
  useEffect(() => {
    if (
      forceLoadAllData &&
      !isDataLoading &&
      allQueryData &&
      allQueryData.length > 0
    ) {
      try {
        setIsExporting(true);
        const csvData = mapArrToCSVFields(allQueryData, exportFields);
        const base64CSV = convertToCSVBase64(csvData);
        saveCSVFile(base64CSV, MODULE_NAME);
        snackbar({
          type: 'success',
          message: `${MODULE_NAME} exported successfully!`,
        });
      } catch (error) {
        console.error('Export error:', error);
        snackbar({
          type: 'error',
          message: `Failed to export ${MODULE_NAME.toLowerCase()}.`,
        });
      } finally {
        setIsExporting(false);
        setForceLoadAllData(false);
        setAllQueryData(undefined);
      }
    }
  }, [forceLoadAllData, allQueryData, isDataLoading, snackbar]);

  useEffect(() => {
    if (tab == '' && setTab) {
      setTab('documents');
    }
  }, [tab]);

  const isLoading = [isUsersLoading, isDocumentTypesLoading].includes(true);

  return (
    <Box>
      <Stack spacing={2}>
        {/* <Content> */}
        <ModuleActions
          hasCustom={false}
          onSearch={onSearch}
          filters={documentFilters}
          onChangeFilter={onChangeFilter}
          onCreateNew={handleNewDocument}
          title='Document'
          isExporting={isExporting}
          onCustomExport={async () => {
            try {
              snackbar({
                type: 'info',
                message: `Loading ${MODULE_NAME.toLowerCase()} data for export...`,
              });
              setForceLoadAllData(true);
              return [];
            } catch (error) {
              console.error('Export error:', error);
              snackbar({
                type: 'error',
                message: `Failed to export ${MODULE_NAME.toLowerCase()}.`,
              });
              return [];
            }
          }}
        />
        <DataTable
          columns={listColumns}
          onChangeSelected={selected => {
            setSelected({ selected, type: 'multiple' });
          }}
          actions={[
            {
              type: 'group',
              title: 'Actions',
            },
            {
              type: 'view',
              title: 'View details',
              onClick: handleViewDocument,
            },
            {
              type: 'edit',
              title: 'Edit',
              onClick: handleEditDocument,
            },
            {
              type: 'delete',
              title: 'Delete',
              onClick: (record: Document) =>
                setSelected({ selected: [record], type: 'single' }),
            },
          ]}
          paginationText={''}
          showTotal={false}
          paginatedQuery={PAGINATED_DOCUMENTS}
          allQuery={ALL_DOCUMENTS}
          setAllQueryData={setAllQueryData}
          refetch={{ refetch, setRefetch }}
          searchFields={combinedSearchFields}
          loader={isLoading}
          sortArg={sortArg}
          page={page}
          setPage={setPage}
          pageSize={20}
          onTableChange={onTableChange}
          customArgs={{
            [`${TENANT_PREFIX}relatedRecordFieldName`]: relatedRecordFieldName,
            [`${TENANT_PREFIX}relatedRecordId`]: id,
          }}
          isDataLoading={isDataLoading}
          setIsDataLoading={setIsDataLoading}
          forceLoadAllData={forceLoadAllData}
          setForceLoadAllData={setForceLoadAllData}
        />
        <ModuleAlert
          message={
            selected?.type === 'single' ? (
              <Text>
                {getDeleteConfirmationMessageJSX(
                  selected.selected[0].documentName,
                  false,
                  MODULE_NAME_SINGULAR
                )}
              </Text>
            ) : (
              <Text>
                {getDeleteConfirmationMessageJSX(
                  undefined,
                  true,
                  MODULE_NAME_SINGULAR
                )}
              </Text>
            )
          }
          title={selected.type === 'single' ? 'document' : 'documents'}
          loading={deleteDocumentLoading}
          selected={selected}
          onDelete={async () => {
            await submitDelete();
          }}
          // onExport={() => { }}
        />
        {/* </Content> */}
      </Stack>
    </Box>
  );
};

export default DocumentsDataTable;
