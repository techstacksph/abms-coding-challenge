import React from 'react';

import environment from '@/config/environment';
import { FIND_DOCUMENT_BY_ID } from '@/graphql/document.gql';
import useQuery from '@/hooks/useQuery';
import Document from '@/models/Document';
import ViewDocumentProvider from '@/views/documents/common/components/ViewDocumentProvider';
import ViewDocument from '@/views/documents/view';
import { dateFormat } from '@/utils/date.utils';
import dayjs from 'dayjs';

import { Spin } from 'antd';
// import { toSentenceCase } from '@/utils/helper.utils';

interface DocumentViewProps {
  documentId: string;
  moduleNameSingular: string; // e.g., 'Account', 'Deal', 'Job'
  parentModuleId: string;
  breadCrumbs: string[];
  relatedRecordField?: string; // e.g., 'account', 'deal', 'job'
  parentViewPageUrl?: string;
  viewPageUrl?: string;
}

const TENANT_PREFIX = environment.TENANT_PREFIX;

// Map module types to their display name field and ID field for search
// Labels are verified against ViewModuleHeader titles in each module's view page
const moduleDisplayMap = {
  account: { label: 'name', field: 'accountId' },
  agreement: { label: 'agreementNo', field: 'agreementId' },
  agreementsAndContracts: {
    label: 'agreementsContractNo',
    field: 'agreementsAndContractsId',
  },
  bill: { label: 'billNo', field: 'billId' },
  businessForSale: { label: 'businessNo', field: 'businessForSaleId' },
  case: { label: 'caseNo', field: 'caseId' },
  creditDebitNote: { label: 'creditDebitNo', field: 'creditDebitNoteId' },
  deal: { label: 'dealNo', field: 'dealId' },
  deliveryReturn: { label: 'deliveryReturnNo', field: 'deliveryReturnId' },
  employee: { label: 'fullName', field: 'employeeId' },
  evaluation: { label: 'evaluationDate', field: 'evaluationId' },
  event: { label: 'subject', field: 'eventId' },
  franchiseeAgreement: { label: 'agreementNo', field: 'franchiseeAgreementId' },
  invoice: { label: 'autoNumber', field: 'invoiceId' },
  job: { label: 'jobNo', field: 'jobId' },
  jobPurchaseApplication: {
    label: 'jobPurchaseNo',
    field: 'jobPurchaseApplicationId',
  },
  lead: { label: 'lead', field: 'leadId' },
  other: { label: 'name', field: 'otherId' },
  performanceReview: { label: 'perfReviewNo', field: 'performanceReviewId' },
  purchaseOrder: { label: 'poNo', field: 'purchaseOrderId' },
  qualityAudit: { label: 'qaNo', field: 'qualityAuditId' },
  recruitment: { label: 'recruitmentNo', field: 'recruitmentId' },
  salesOrder: { label: 'soNo', field: 'salesOrderId' },
  site: { label: 'siteName', field: 'siteId' },
  task: { label: 'taskSubject', field: 'taskId' },
  training: { label: 'trainingDate', field: 'trainingId' },
};

// Helper function to generate searchArg for filtering documents by module
export const generateDocumentSearchArg = (
  moduleType: string,
  moduleId: string
): Array<{ fieldName: string; searchValue: string; comparator: string }> => {
  const displayConfig = moduleDisplayMap[moduleType];
  if (!displayConfig) {
    return [];
  }

  return [
    {
      fieldName: displayConfig.field,
      searchValue: moduleId,
      comparator: 'EQUAL',
    },
  ];
};

const DocumentView: React.FC<DocumentViewProps> = ({
  documentId,
  moduleNameSingular,
  parentModuleId,
  breadCrumbs,
  relatedRecordField = 'account', // Default to 'account' for backward compatibility
  parentViewPageUrl = '',
  viewPageUrl = '',
}) => {
  const { data, loading } = useQuery<Document>({
    query: FIND_DOCUMENT_BY_ID,
    isViewRecordQuery: true,
    options: {
      variables: {
        [`${TENANT_PREFIX}findDocumentByIdId`]: documentId,
      },
    },
  });

  let relatedRecordName: string;
  let relatedRecordUrl: string;

  if (relatedRecordField === 'other') {
    relatedRecordName = 'Other';
    relatedRecordUrl = parentViewPageUrl;
  } else {
    const relatedRecord = data?.[relatedRecordField];
    const displayConfig = moduleDisplayMap[relatedRecordField] || {
      label: 'name',
      field: 'id',
    };
    const displayNameField = displayConfig.label;

    relatedRecordName = relatedRecord?.[displayNameField];

    if (!relatedRecordName && relatedRecordField === 'agreementsAndContracts') {
      relatedRecordName =
        relatedRecord?.type ||
        (relatedRecord?.documentBody
          ? relatedRecord.documentBody.substring(0, 50) + '...'
          : null) ||
        'Unnamed Agreement/Contract';
    }

    if (relatedRecordField === 'evaluation' && relatedRecord?.evaluationDate) {
      relatedRecordName = dayjs(relatedRecord.evaluationDate).format(
        dateFormat
      );
    }
    if (relatedRecordField === 'training' && relatedRecord?.trainingDate) {
      relatedRecordName = dayjs(relatedRecord.trainingDate).format(dateFormat);
    }
    if (!relatedRecordName) {
      relatedRecordName = relatedRecord?.id;
    }

    relatedRecordUrl = relatedRecord?.id ? viewPageUrl : parentViewPageUrl;
  }

  return (
    <ViewDocumentProvider
      parentModuleId={parentModuleId}
      breadCrumbs={breadCrumbs}
      parentViewPageUrl={parentViewPageUrl}
      moduleName={moduleNameSingular}
      relatedRecordName={relatedRecordName}
      relatedRecordUrl={relatedRecordUrl}
      moduleType={relatedRecordField}
    >
      <Spin spinning={loading}>
        <ViewDocument data={data} />
      </Spin>
    </ViewDocumentProvider>
  );
};

export default DocumentView;
