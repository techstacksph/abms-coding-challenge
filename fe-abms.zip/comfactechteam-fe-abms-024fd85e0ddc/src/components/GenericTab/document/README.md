# Generic Document Components

This folder contains reusable document components that can be used across different modules in the application.

## Components

### 1. DocumentsDataTable

A generic data table component for displaying documents with filtering, pagination, and actions.

**Features:**

- **Search**: Document name and file name search (minimum 3 characters)
- **Filters**: Record owner, Updated at, Document type
- **Sorting**: Document name, Document type
- **Pagination**: Default 20 rows per page
- **Actions**: View, Edit, Delete documents
- **Export**: CSV export functionality

**Props:**

- `id`: The ID of the parent record (e.g., account ID, deal ID)
- `module`: The module name (e.g., 'accounts', 'deals', 'jobs')
- `tab`: Current tab name
- `setTab`: Function to change tabs
- `breadCrumbs`: Array of breadcrumb strings
- `onNewDocument`: Optional callback for new document action
- `onEditDocument`: Optional callback for edit document action
- `onViewDocument`: Optional callback for view document action
- `searchArg`: Optional array of search arguments for list components (e.g., pre-filtered results)

**Usage:**

```tsx
import { DocumentsDataTable } from '@/components/GenericTab/document';

<DocumentsDataTable
  id='account-123'
  module='accounts'
  tab='documents'
  setTab={tab => setTab(tab)}
/>;
```

**Search Functionality:**
The search feature allows users to search across:

- Document name
- File names (file1, file2, file3, file4, file5)

Search is triggered after typing 3 or more characters and uses ILIKE comparison for flexible matching.

**Search Arguments (searchArg):**
The `searchArg` prop allows list components to provide pre-defined search criteria:

- **Always applied**: When provided, these search arguments are always active
- **Combined with user search**: User search input is combined with searchArg for comprehensive filtering
- **Combined with filters**: Filter selections (Record Owner, Updated At, Document Type) are also added to the search payload
- **List component use case**: Perfect for scenarios where you want to show pre-filtered results (e.g., "Recent Documents", "Pending Approval", etc.)

**Search Payload Composition:**
The final search payload sent to the GraphQL query combines three sources:

1. **searchArg**: Pre-defined search criteria (always applied when provided)
2. **User Search**: Text input search (document name, file names)
3. **Filter Selections**: User-selected filters (Record Owner, Updated At, Document Type)

This ensures that all search criteria work together seamlessly.

**Example searchArg usage:**

```tsx
// Show only documents from the last 30 days
<DocumentsDataTable
  id="account-123"
  module="accounts"
  searchArg={[
    {
      fieldName: 'createdAt',
      comparator: 'GTE',
      searchValue: dayjs().subtract(30, 'days').toISOString(),
    }
  ]}
/>

// Show only documents of a specific type
<DocumentsDataTable
  id="deal-456"
  module="deals"
  searchArg={[
    {
      fieldName: 'documentType.name',
      comparator: 'EQUAL',
      searchValue: 'Invoice',
    }
  ]}
/>
```

**Filter Options:**

- **Record Owner**: Filter by user who created the document
- **Updated At**: Date-based filtering for document updates
- **Document Type**: Filter by document type (e.g., Invoice, Contract, etc.)

**Sorting:**

- **Document Name**: Alphabetical sorting (ascending/descending)
- **Document Type**: Sort by document type name
- Default sort: Document name ascending

**Pagination:**

- Default page size: 20 rows per page
- Configurable page navigation
- Efficient data loading with GraphQL pagination

### 2. DocumentForm

A generic form component for creating and editing documents.

**Props:**

- `mode`: 'new' or 'edit'
- `breadCrumbs`: Array of breadcrumb strings
- `accountId`: Account ID (for account-related documents)
- `dealId`: Deal ID (for deal-related documents)
- `jobId`: Job ID (for job-related documents)
- `documentId`: Document ID (for edit mode)
- `module`: Module name for field mapping
- `tabMode`: Boolean flag to hide related record section (default: false)

**Usage:**

```tsx
import { DocumentForm } from '@/components/GenericTab/document';

// New document
<DocumentForm
  mode="new"
  breadCrumbs={['Accounts', 'View Account', 'New Document']}
  accountId="account-123"
  module="accounts"
/>

// Edit document
<DocumentForm
  mode="edit"
  breadCrumbs={['Accounts', 'View Account', 'Edit Document']}
  accountId="account-123"
  documentId="doc-456"
  module="accounts"
/>

// New document with tabMode (hides related record section)
<DocumentForm
  mode="new"
  breadCrumbs={['Accounts', 'View Account', 'New Document']}
  accountId="account-123"
  module="accounts"
  tabMode={true}
/>
```

## Tab Mode

The `tabMode` prop is a boolean flag that controls the visibility of the related record section in document forms.

### What tabMode Does

- **`tabMode={false}` (default)**: Shows the full document form with related record section on the right side
- **`tabMode={true}`**: Hides the related record section and upload files section, showing only the document information fields

### When to Use tabMode

- **Use `tabMode={true}`** when implementing document tabs within existing modules (e.g., Accounts, Tasks, Leads, Deals, Jobs)
- **Use `tabMode={false}`** when implementing standalone document forms or when you need the related record selection functionality

### Implementation in Module Tabs

For module-specific document tabs, set `tabMode={true}` to hide the related record section since the relationship is already established through the parent module:

```tsx
// Example: Task document within Tasks module
<DocumentForm
  mode='new'
  breadCrumbs={['Calendar', 'Tasks', 'View Task', 'New Document']}
  taskId={id}
  module='task'
  tabMode={true} // Hide related record section for tasks
/>
```

### 3. DocumentView

A generic component for viewing document details.

**Props:**

- `documentId`: The ID of the document to view
- `moduleNameSingular`: Singular module name (e.g., 'Account', 'Deal', 'Job')
- `parentModuleId`: ID of the parent module record
- `breadCrumbs`: Array of breadcrumb strings
- `relatedRecordField`: Field name for the related record (e.g., 'account', 'deal', 'job')
- `parentViewPageUrl`: URL to return to parent module documents tab
- `viewPageUrl`: URL to view the related record

**Usage:**

```tsx
import { DocumentView } from '@/components/GenericTab/document';

<DocumentView
  documentId='doc-123'
  moduleNameSingular='Account'
  parentModuleId='account-456'
  breadCrumbs={['Accounts', 'View Account', 'View Document']}
  relatedRecordField='account'
  parentViewPageUrl='/accounts/account-456?tab=documents'
  viewPageUrl='/accounts/account-456'
/>;
```

## Module Verification

**IMPORTANT**: Before implementing document tabs for any module, you must verify that the module is available in `getViewRoute` from `@/mfe-utilities`. This prevents routing errors and ensures proper navigation.

### Check Module Availability

1. **Import and verify the module exists:**

```tsx
import { getViewRoute } from '@/mfe-utilities';

// Check if module is available
const moduleRoute = getViewRoute('YourModule');
if (!moduleRoute) {
  console.error('Module "YourModule" is not available in getViewRoute');
  // Handle gracefully or show appropriate error message
}
```

**⚠️ CRITICAL WARNING**: Always verify that the module name exists in `RoutesInternal` before using `getViewRoute`. Common mistakes include:

- Using singular names when plural is defined (e.g., `'Lead'` instead of `'Leads'`)
- Using incorrect casing or spacing
- Using module names that don't exist in the system

**Common Module Name Corrections:**

- ✅ `getViewRoute('Leads')` - NOT `getViewRoute('Lead')`
- ✅ `getViewRoute('Deals')` - NOT `getViewRoute('Deal')`
- ✅ `getViewRoute('Jobs')` - NOT `getViewRoute('Job')`
- ✅ `getViewRoute('Locations')` - NOT `getViewRoute('Location')`

2. **Common available modules in getViewRoute:**

```tsx
// These modules are typically available:
getViewRoute('Account'); // Returns route for accounts
getViewRoute('Leads'); // Returns route for leads
getViewRoute('Deals'); // Returns route for deals
getViewRoute('Jobs'); // Returns route for jobs
getViewRoute('Task'); // Returns route for tasks
getViewRoute('Event'); // Returns route for events
getViewRoute('Case'); // Returns route for cases
getViewRoute('Invoice'); // Returns route for invoices
getViewRoute('Bill'); // Returns route for bills
getViewRoute('PurchaseOrder'); // Returns route for purchase orders
getViewRoute('SalesOrder'); // Returns route for sales orders
```

3. **Safe implementation pattern:**

```tsx
import { getViewRoute } from '@/mfe-utilities';

const ViewYourModuleDocument = () => {
  const { id, documentId } = useParams();
  const breadCrumbs = ['Your Module', 'View Your Module', 'View Document'];

  // Verify module is available before using getViewRoute
  const moduleRoute = getViewRoute('YourModule');
  if (!moduleRoute) {
    return (
      <div>
        <p>Module not available. Please check module configuration.</p>
      </div>
    );
  }

  return (
    <DocumentView
      documentId={documentId}
      moduleNameSingular='Your Module'
      parentModuleId={id}
      breadCrumbs={breadCrumbs}
      relatedRecordField='yourModule'
      parentViewPageUrl={`${moduleRoute}/${id}?tab=documents`}
      viewPageUrl={`${moduleRoute}/${id}`}
    />
  );
};
```

### Why This Matters

- **Prevents Routing Errors**: Modules not in `getViewRoute` will cause navigation failures
- **Ensures Consistency**: All modules follow the same routing pattern
- **Better Error Handling**: Graceful fallbacks when modules aren't available
- **Maintains Navigation**: Proper breadcrumb and return navigation functionality

## Module Setup

To use these components in a new module:

1. **Create a module-specific list component:**

```tsx
// src/views/your-module/view/tabs/Documents/list/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { DocumentsDataTable } from '@/components/GenericTab/document';

const YourModuleDocumentsList = props => {
  const { id: paramId } = useParams();
  const id = props?.id || paramId;

  return (
    <DocumentsDataTable
      id={id}
      module='your-module'
      tab={props?.tab}
      setTab={props?.setTab}
    />
  );
};

export default YourModuleDocumentsList;
```

2. **Create module-specific form components:**

```tsx
// src/views/your-module/view/tabs/Documents/new/index.tsx
import React from 'react';
import { DocumentForm } from '@/components/GenericTab/document';

const NewYourModuleDocument = props => {
  const { id } = useParams();
  const breadCrumbs = ['Your Module', 'View Your Module', 'New Document'];

  return (
    <DocumentForm
      mode='new'
      breadCrumbs={breadCrumbs}
      yourModuleId={id}
      module='your-module'
      {...props}
    />
  );
};

export default NewYourModuleDocument;
```

### 3. DocumentView

A generic component for viewing document details.

**Props:**

- `documentId`: The ID of the document to view
- `moduleNameSingular`: Singular module name (e.g., 'Account', 'Deal', 'Job')
- `parentModuleId`: ID of the parent module record
- `breadCrumbs`: Array of breadcrumb strings
- `relatedRecordField`: Field name for the related record (e.g., 'account', 'deal', 'job')
- `parentViewPageUrl`: URL to return to parent module documents tab
- `viewPageUrl`: URL to view the related record

**Usage:**

```tsx
import { DocumentView } from '@/components/GenericTab/document';
import { useParams } from '@/utils/navigation.utils';
import { getViewRoute } from '@/mfe-utilities';

const ViewYourModuleDocument = () => {
  const { id, documentId } = useParams();
  const breadCrumbs = ['Your Module', 'View Your Module', 'View Document'];

  return (
    <DocumentView
      documentId={documentId}
      moduleNameSingular='Your Module'
      parentModuleId={id}
      breadCrumbs={breadCrumbs}
      relatedRecordField='yourModule'
      parentViewPageUrl={`${getViewRoute('YourModule')}/${id}?tab=documents`}
      viewPageUrl={`${getViewRoute('YourModule')}/${id}`}
    />
  );
};

export default ViewYourModuleDocument;
```

## Field Mapping

The components automatically handle field mapping based on the module name. The `relatedModuleFieldMap` in `src/views/documents/common/constants.ts` maps module names to their corresponding foreign key fields:

```tsx
export const relatedModuleFieldMap = {
  account: 'accountId',
  accounts: 'accountId',
  lead: 'leadId',
  deal: 'dealId',
  site: 'siteId',
  job: 'jobId',
  case: 'caseId',
  // ... other mappings
};
```

## Benefits

1. **Reusability**: Components can be used across different modules
2. **Consistency**: Uniform UI and behavior across the application
3. **Maintainability**: Single source of truth for document functionality
4. **Flexibility**: Easy to customize for specific module requirements

## Troubleshooting

### Common Issues

1. **GraphQL Error: "Property 'name' was not found in 'DocumentModel'"**
   - This error occurs when the GraphQL query requests a non-existent field
   - The `relatedTo.name` field has been removed from the GraphQL fragment
   - Ensure all field references use the correct property names

2. **Field Mapping Issues**
   - Verify that the module name is correctly mapped in `relatedModuleFieldMap`
   - Check that the `relatedRecordField` prop matches the expected field name

3. **TypeScript Errors**
   - Ensure all required props are provided
   - Check that the component interfaces match the expected types

4. **Search Arguments (searchArg) Issues**
   - Ensure `searchArg` array contains valid search objects with `fieldName`, `comparator`, and `searchValue`
   - Check that field names in `searchArg` match the actual GraphQL schema fields
   - Verify that comparator values are supported by your backend (e.g., 'EQUAL', 'IN', 'GTE', 'ILIKE')
   - Remember that `searchArg` is always applied and combined with user search input

5. **Filter Issues**
   - **Filters not appearing in search payload**: Ensure `onChangeFilter` is properly connected and updating the `listFilters` state
   - **Filter values not being sent**: Check that filter field names match the GraphQL schema (e.g., 'createdBy', 'updatedAt', 'documentType.name')
   - **Filter comparators**: Verify that the backend supports the comparator types being used ('EQUAL', 'IN', 'BETWEEN', etc.)
   - **Filter state persistence**: Filters are maintained in component state and combined with search arguments

### Debugging

1. **Check Browser Console**: Look for GraphQL errors or JavaScript errors
2. **Verify GraphQL Queries**: Ensure the queries are requesting valid fields
3. **Check Field Mapping**: Verify that module names are correctly mapped
4. **Inspect Network Tab**: Check which GraphQL queries are being executed
5. **Debug Search Payload**:
   - Check `combinedSearchFields` in component state
   - Verify `searchArg`, `search`, and `listFilters` are properly populated
   - Use browser dev tools to inspect the component state
   - Add console.log to see the final search payload being sent

## Recent Fixes

- **Fixed GraphQL Error**: Removed `relatedTo.name` field from GraphQL fragment to prevent "Property 'name' was not found in 'DocumentModel'" error
- **Improved Field Mapping**: Added proper field mapping for different module types in DocumentView component
- **Updated Props Interface**: Removed deprecated `moduleRouteName` prop and added `parentViewPageUrl` and `viewPageUrl` props
- **Added searchArg Prop**: New prop for list components to provide pre-defined search criteria
- **Fixed Filter Integration**: Filters are now properly combined with search arguments in the GraphQL payload
- **Added Module Verification**: New section explaining how to verify module availability in `getViewRoute` before implementation
- **Added tabMode Prop**: New boolean prop to hide related record section when implementing document tabs within existing modules
