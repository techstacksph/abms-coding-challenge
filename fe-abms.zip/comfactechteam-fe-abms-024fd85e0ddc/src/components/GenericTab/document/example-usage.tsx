import React from 'react';

import { DocumentForm, DocumentsDataTable, DocumentView } from './index';

// Example usage for DocumentsDataTable
export const ExampleDocumentsDataTable = () => {
  return (
    <div>
      {/* For Accounts module */}
      <DocumentsDataTable
        id='account-123'
        module='accounts'
        tab='documents'
        setTab={tab => console.log('Tab changed to:', tab)}
      />

      {/* For Deals module */}
      <DocumentsDataTable
        id='deal-456'
        module='deals'
        tab='documents'
        setTab={tab => console.log('Tab changed to:', tab)}
      />

      {/* For Jobs module */}
      <DocumentsDataTable
        id='job-789'
        module='jobs'
        tab='documents'
        setTab={tab => console.log('Tab changed to:', tab)}
      />

      {/* For List components with searchArg */}
      <DocumentsDataTable
        id='account-123'
        module='accounts'
        searchArg={[
          {
            fieldName: 'documentType.name',
            comparator: 'EQUAL',
            searchValue: 'Invoice',
          },
        ]}
      />
    </div>
  );
};

// Example usage with searchArg for list components
export const ExampleDocumentsDataTableWithSearchArg = () => {
  return (
    <div>
      {/* Show only recent documents (last 7 days) */}
      <DocumentsDataTable
        id='account-123'
        module='accounts'
        searchArg={[
          {
            fieldName: 'createdAt',
            comparator: 'GTE',
            searchValue: new Date(
              Date.now() - 7 * 24 * 60 * 60 * 1000
            ).toISOString(),
          },
        ]}
      />

      {/* Show only pending approval documents */}
      <DocumentsDataTable
        id='deal-456'
        module='deals'
        searchArg={[
          {
            fieldName: 'status',
            comparator: 'EQUAL',
            searchValue: 'Pending Approval',
          },
        ]}
      />

      {/* Show only specific document types */}
      <DocumentsDataTable
        id='job-789'
        module='jobs'
        searchArg={[
          {
            fieldName: 'documentType.name',
            comparator: 'IN',
            searchValue: 'Invoice,Contract,Proposal',
          },
        ]}
      />

      {/* Show documents by specific user */}
      <DocumentsDataTable
        id='site-101'
        module='sites'
        searchArg={[
          {
            fieldName: 'createdBy',
            comparator: 'EQUAL',
            searchValue: 'John Doe',
          },
        ]}
      />
    </div>
  );
};

// Example usage for DocumentForm
export const ExampleDocumentForm = () => {
  return (
    <div>
      {/* New document form for Accounts */}
      <DocumentForm
        mode='new'
        breadCrumbs={['Accounts', 'View Account', 'New Document']}
        accountId='account-123'
        module='accounts'
      />

      {/* Edit document form for Deals */}
      <DocumentForm
        mode='edit'
        breadCrumbs={['Deals', 'View Deal', 'Edit Document']}
        dealId='deal-456'
        documentId='doc-789'
        module='deals'
      />
    </div>
  );
};

// Example usage for DocumentView
export const ExampleDocumentView = () => {
  return (
    <div>
      {/* View document for Accounts */}
      <DocumentView
        documentId='doc-123'
        moduleNameSingular='Account'
        parentModuleId='account-456'
        breadCrumbs={['Accounts', 'View Account', 'View Document']}
        relatedRecordField='account'
        parentViewPageUrl='/accounts/account-456?tab=documents'
        viewPageUrl='/accounts/account-456'
      />

      {/* View document for Deals */}
      <DocumentView
        documentId='doc-456'
        moduleNameSingular='Deal'
        parentModuleId='deal-789'
        breadCrumbs={['Deals', 'View Deal', 'View Document']}
        relatedRecordField='deal'
        parentViewPageUrl='/deals/deal-789?tab=documents'
        viewPageUrl='/deals/deal-789'
      />

      {/* View document for Jobs */}
      <DocumentView
        documentId='doc-789'
        moduleNameSingular='Job'
        parentModuleId='job-123'
        breadCrumbs={['Jobs', 'View Job', 'View Document']}
        relatedRecordField='job'
        parentViewPageUrl='/jobs/job-123?tab=documents'
        viewPageUrl='/jobs/job-123'
      />
    </div>
  );
};

// Example of DocumentsDataTable with all features enabled
export const ExampleDocumentsDataTableWithFeatures = () => {
  return (
    <div>
      <h3>Documents DataTable with Full Features</h3>
      <p>
        This example shows the DocumentsDataTable with all features enabled:
      </p>
      <ul>
        <li>
          <strong>Search:</strong> Users can search by document name or file
          names (min 3 characters)
        </li>
        <li>
          <strong>Filters:</strong> Record owner, Updated at, Document type
        </li>
        <li>
          <strong>Sorting:</strong> Document name and Document type columns are
          sortable
        </li>
        <li>
          <strong>Pagination:</strong> Default 20 rows per page with navigation
        </li>
        <li>
          <strong>Actions:</strong> View, Edit, Delete for each document
        </li>
        <li>
          <strong>Export:</strong> CSV export functionality
        </li>
      </ul>

      <DocumentsDataTable
        id='account-123'
        module='accounts'
        tab='documents'
        setTab={tab => console.log('Tab changed to:', tab)}
      />
    </div>
  );
};

export default ExampleDocumentsDataTable;
