export { default as QualityAuditsDataTable } from './QualityAuditsDataTable';
