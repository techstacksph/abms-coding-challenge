import React from 'react';
import QualityAuditList from '@/views/customer-service/quality-audit/list';
import QualityAuditModel from '@/models/QualityAuditModel';

interface QualityAuditsDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  onNewQualityAudit?: () => void;
  onEditQualityAudit?: (record: QualityAuditModel) => void;
  onViewQualityAudit?: (
    record: QualityAuditModel,
    event?: React.MouseEvent
  ) => void;
  searchArg?: Array<any>;
  customWorkflowRoutes?: {
    [key: string]: (record: QualityAuditModel) => string;
  };
}

/**
 * QualityAuditsDataTable - A wrapper component that reuses QualityAuditList
 * This component provides a way to embed the full quality audit list functionality
 * in other contexts (like tabs in Job/Account views) with custom action handlers.
 */
const QualityAuditsDataTable: React.FC<QualityAuditsDataTableProps> = ({
  onNewQualityAudit,
  onEditQualityAudit,
  onViewQualityAudit,
  searchArg,
  customWorkflowRoutes,
  ...props
}) => {
  return (
    <QualityAuditList
      externalData={true}
      externalSearchArgs={searchArg}
      onCustomNew={onNewQualityAudit}
      onCustomEdit={onEditQualityAudit}
      onCustomView={onViewQualityAudit}
      customWorkflowRoutes={customWorkflowRoutes}
      {...props}
    />
  );
};

export default QualityAuditsDataTable;
