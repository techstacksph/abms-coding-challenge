import React from 'react';
import { EventForm, EventsDataTable } from './index';
import EventModel from '@/models/EventModel';

// Example usage of EventsDataTable with custom callbacks
const ExampleEventsDataTable = () => {
  const handleNewEvent = () => {
    console.log('New event clicked');
    // Custom navigation or modal logic
  };

  const handleEditEvent = (event: EventModel) => {
    console.log('Edit event:', event);
    // Custom edit logic
  };

  const handleViewEvent = (event: EventModel) => {
    console.log('View event:', event);
    // Custom view logic
  };

  return (
    <EventsDataTable
      id='account-123'
      module='accounts'
      onNewEvent={handleNewEvent}
      onEditEvent={handleEditEvent}
      onViewEvent={handleViewEvent}
    />
  );
};

// Example usage of EventForm
const ExampleEventForm = () => {
  const breadCrumbs = ['Accounts', 'Accounts', 'View Account', 'New Event'];

  return (
    <EventForm
      mode='new'
      breadCrumbs={breadCrumbs}
      accountId='account-123'
      // Additional props as needed
    />
  );
};

export { ExampleEventsDataTable, ExampleEventForm };
