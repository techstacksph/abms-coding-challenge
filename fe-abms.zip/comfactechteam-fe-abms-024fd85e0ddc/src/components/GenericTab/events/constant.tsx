export const relatedToModuleMap = {
  account: 'accountId',
  contact: 'contactId',
  site: 'siteId',
  employee: 'employeeId',
  user: 'userId',
  task: 'taskId',
  lead: 'leadId',
  // Sales modules
  deal: 'dealId',
  // Jobs modules
  job: 'jobId',
  // Customer Service modules
  case: 'caseId',
  qualityAudit: 'qualityAuditId',
  // Finance modules
  invoice: 'invoiceId',
  bill: 'billId',
  // Purchasing & Inventory modules
  deliveryandreturn: 'deliveryAndReturnId',
  stockcontrol: 'stockControlId',
  stock_control: 'stockControlId',
  purchaseOrder: 'purchaseOrderId',
  salesOrder: 'salesOrderId',
  // Other modules
  recruitment: 'recruitmentId',
  evaluation: 'evaluationId',
  training: 'trainingId',
  businessforsale: 'businessForSaleId',
  jobpurchase: 'jobPurchaseId',
};
