import React from 'react';
import EventList from '@/views/calendar/events/list';
import EventModel from '@/models/EventModel';

interface EventsDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  onNewEvent?: () => void;
  onEditEvent?: (event: EventModel) => void;
  onViewEvent?: (event: EventModel, e?: React.MouseEvent) => void;
  viewRoute?: string;
  searchArg?: Array<any>;
  customWorkflowRoutes?: {
    addNote?: (event: EventModel) => string;
    addEmail?: (event: EventModel) => string;
    addSms?: (event: EventModel) => string;
    addCall?: (event: EventModel) => string;
    addTask?: (event: EventModel) => string;
    addDocument?: (event: EventModel) => string;
  };
  [key: string]: any;
}

const EventsDataTable: React.FC<EventsDataTableProps> = ({
  onNewEvent,
  onEditEvent,
  onViewEvent,
  searchArg,
  customWorkflowRoutes,
  ...props
}) => {
  return (
    <EventList
      externalData={true}
      searchArg={searchArg}
      onNewEvent={onNewEvent}
      onEditEvent={onEditEvent}
      onViewEvent={onViewEvent}
      customWorkflowRoutes={customWorkflowRoutes}
      {...props}
    />
  );
};

export default EventsDataTable;
