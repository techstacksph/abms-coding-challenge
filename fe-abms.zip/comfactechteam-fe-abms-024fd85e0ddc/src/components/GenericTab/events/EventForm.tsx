import React, { useEffect, useMemo, useState } from 'react';
import { Box, Stack } from '@mui/material';
import { Container } from '@/styled-components';
import FormCard from '@/components/FormCard';

import EventProvider from '@/views/calendar/events/common/components/EventProvider';
import EventsFormHeader from '@/views/calendar/events/common/components/EventsFormHeader';
import EventDetailsForm from '@/views/calendar/events/common/components/forms/EventDetailsForm';
import RelatedRecordForm from '@/views/calendar/events/common/components/forms/RelatedRecordForm';
import AssigneeCalendar from '@/views/calendar/events/common/components/AssgineeCalendar';
import useGlobalOptions from '@/hooks/useGlobalOptions';
import { relatedToModuleMap } from './constant';
import { isValueValid } from '@/utils/helper.utils';

interface EventFormProps {
  mode: 'new' | 'edit';
  breadCrumbs: string[];
  relatedTo?: {
    module: string;
    moduleId?: string;
  };
  redirect?: string | ((eventId: string) => void);
  [key: string]: any;
}

const EventForm: React.FC<EventFormProps> = ({
  mode,
  breadCrumbs,
  relatedTo,
  redirect,
  ...props
}) => {
  const { modules, modulesLoading } = useGlobalOptions({
    modules: true,
  });
  const [moduleIdToUse, setModuleIdToUse] = useState<string | null>(null);

  const moduleEvent = useMemo(() => {
    return modules.filter(m => m.isIncludedInEvent);
  }, [modules, modulesLoading]);

  // Update URL with relatedTo information for EventProvider to read
  useEffect(() => {
    if (relatedTo && mode === 'new' && isValueValid(moduleIdToUse)) {
      const currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('module', relatedTo.module);
      currentUrl.searchParams.set('moduleId', moduleIdToUse);

      // Update URL without triggering navigation
      window.history.replaceState({}, '', currentUrl.toString());
    }
  }, [relatedTo, mode, modules, moduleEvent, moduleIdToUse]);

  useEffect(() => {
    if (moduleEvent) {
      const currentModuleEvent = moduleEvent.find(
        m => m.code?.toLowerCase() === relatedTo.module.toLowerCase()
      );
      if (currentModuleEvent?.id ?? relatedTo.moduleId) {
        setModuleIdToUse(currentModuleEvent?.id ?? relatedTo.moduleId);
      }
    }
  }, [moduleEvent]);

  useEffect(() => {
    const relatedToModule = relatedToModuleMap[relatedTo?.module];
    if (isValueValid(relatedToModule)) {
      const currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('relatedToId', props[relatedToModule]);
      currentUrl.searchParams.set('leadStatusId', props?.leadStatusId);
      window.history.replaceState({}, '', currentUrl.toString());
    }
  }, [props]);

  // // Also check URL parameters directly for moduleId
  // useEffect(() => {
  //   if (mode === 'new') {
  //     const urlParams = new URLSearchParams(window.location.search);
  //     const moduleParam = urlParams.get('module');
  //     const moduleIdParam = urlParams.get('moduleId');

  //     if (moduleParam && moduleIdParam) {
  //       const currentUrl = new URL(window.location.href);
  //       currentUrl.searchParams.set('module', moduleParam);
  //       currentUrl.searchParams.set('moduleId', moduleIdParam);

  //       // Update URL without triggering navigation
  //       window.history.replaceState({}, '', currentUrl.toString());
  //     }
  //   }
  // }, [mode]);

  const renderFormProvider = () => {
    if (mode === 'new') {
      return (
        <EventProvider.New
          {...props}
          redirect={redirect}
          relatedTo={{ ...relatedTo, moduleId: moduleIdToUse }}
        >
          <EventsFormHeader
            view='New'
            breadCrumbs={breadCrumbs}
            titleDisplaySize={props?.titleDisplaySize}
            endDisplaySize={props?.endDisplaySize}
          />
          <Container>
            <Stack direction='row' spacing={2.5}>
              <FormCard
                title='Event information'
                containerProps={{ spacing: 2 }}
              >
                <Stack direction='row' spacing={5}>
                  <EventDetailsForm />
                  <RelatedRecordForm />
                </Stack>
              </FormCard>
              <AssigneeCalendar />
            </Stack>
          </Container>
        </EventProvider.New>
      );
    }

    return (
      <EventProvider.Edit {...props} redirect={redirect}>
        <EventsFormHeader
          view='Edit'
          breadCrumbs={breadCrumbs}
          titleDisplaySize={props?.titleDisplaySize}
          endDisplaySize={props?.endDisplaySize}
        />
        <Container>
          <Stack direction='row' spacing={2.5}>
            <FormCard title='Event information' containerProps={{ spacing: 2 }}>
              <Stack direction='row' spacing={5}>
                <EventDetailsForm />
                <RelatedRecordForm />
              </Stack>
            </FormCard>
            <AssigneeCalendar />
          </Stack>
        </Container>
      </EventProvider.Edit>
    );
  };

  return <Box>{renderFormProvider()}</Box>;
};

export default EventForm;
