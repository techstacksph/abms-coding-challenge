import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import {
  TasksDataTable,
  TaskView,
  TaskForm,
} from '@/components/GenericTab/task';
import useNavigate from '@/hooks/useNavigate';
import Task from '@/models/Task';
import { SearchComparator } from '@/typings/module.types';

// Example: Using TasksDataTable in Accounts context (REAL IMPLEMENTATION!)
// Features: Filtering by assignees, status, and due date (uses globalOptions for performance)
const AccountTasksTabExample = (props: {
  tab?: string;
  setTab?: (val: string) => void;
}) => {
  const { id } = useParams();
  const { navigate } = useNavigate('List');

  // Custom navigation handlers to stay within accounts context
  const handleNewTask = () => {
    navigate(`/accounts/${id}/tasks/new`);
  };

  const handleEditTask = (task: Task) => {
    navigate(`/accounts/${id}/tasks/${task.id}/edit`);
  };

  const handleViewTask = (task: Task) => {
    navigate(`/accounts/${id}/tasks/${task.id}`);
  };

  // Search arguments for filtering tasks by account
  const searchArg = [
    {
      fieldName: 'account.id',
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <TasksDataTable
      id={id}
      module='accounts'
      tab={props.tab}
      setTab={props.setTab}
      breadCrumbs={['Accounts', 'View Account', 'Tasks']}
      onNewTask={handleNewTask}
      onEditTask={handleEditTask}
      onViewTask={handleViewTask}
      searchArg={searchArg}
    />
  );
};

// Example: Using TaskForm with callbacks (NEW IMPROVED PATTERN!)
// Shows how to preselect "Account" in Related To field
const AccountTaskFormExample = () => {
  const { id } = useParams();
  const { navigate } = useNavigate();

  const handleTaskCreated = (task: Task) => {
    // Navigate to task view within accounts context
    navigate(`/accounts/${id}/tasks/${task.id}`);
  };

  const handleTaskUpdated = (task: Task) => {
    // Navigate to task view or back to list
    navigate(`/accounts/${id}/tasks/${task.id}`);
  };

  return (
    <TaskForm
      mode='new'
      breadCrumbs={[
        { title: 'Accounts' },
        { title: 'View Account' },
        { title: 'New Task' },
      ]}
      onTaskCreated={handleTaskCreated}
      onTaskUpdated={handleTaskUpdated}
      // These props preselect "Account" in Related To dropdown
      relatedTo={{
        module: 'account', // Module type (account, deal, job, etc.)
        moduleId: id, // Specific record ID within that module
      }}
      accountId={id} // For URL params
      relatedToId={id} // For form field preselection
    />
  );
};

// Example: Using TaskView in a modal or embedded context
const EmbeddedTaskViewExample = ({ taskId }: { taskId: string }) => {
  return (
    <TaskView
      breadCrumbs={[
        { title: 'Accounts' },
        { title: 'View Account' },
        { title: 'Task Details' },
      ]}
      parentViewPageUrl='/accounts/123?tab=tasks'
      taskId={taskId}
      hideHeader={true}
      hideNavigation={true}
    />
  );
};

export {
  AccountTasksTabExample,
  AccountTaskFormExample,
  EmbeddedTaskViewExample,
};
