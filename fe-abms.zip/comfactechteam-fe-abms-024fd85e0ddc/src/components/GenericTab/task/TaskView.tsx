import React from 'react';
import TasksView from '@/views/calendar/tasks/view';

interface TaskViewProps {
  breadCrumbs: { title: string }[];
  parentViewPageUrl: string;
  taskId?: string;
  [key: string]: any;
}

const TaskView: React.FC<TaskViewProps> = ({
  breadCrumbs,
  parentViewPageUrl,
  taskId,
  ...props
}) => {
  return (
    <TasksView
      breadCrumbs={breadCrumbs}
      parentUrl={parentViewPageUrl}
      taskId={taskId}
      {...props}
    />
  );
};

export default TaskView;
