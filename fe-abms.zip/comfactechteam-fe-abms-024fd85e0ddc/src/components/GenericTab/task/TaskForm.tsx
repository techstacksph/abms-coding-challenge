import React, { useEffect } from 'react';
import { Box } from '@mui/material';

import TaskFormProvider from '@/views/calendar/tasks/common/components/TaskFormProvider';
import TaskFormHeader from '@/views/calendar/tasks/common/components/TaskFormHeader';
import MainTaskForm from '@/views/calendar/tasks/common/components/MainTaskForm';
import Task from '@/models/Task';

interface TaskFormProps {
  mode: 'new' | 'edit';
  breadCrumbs: { title: string }[];
  onTaskCreated?: (task: Task) => void;
  onTaskUpdated?: (task: Task) => void;
  [key: string]: any;
}

const TaskForm: React.FC<TaskFormProps> = ({
  mode,
  breadCrumbs,
  onTaskCreated,
  onTaskUpdated,
  ...props
}) => {
  useEffect(() => {
    if (props?.leadStatusId) {
      const currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('leadStatusId', props?.leadStatusId);
      window.history.replaceState({}, '', currentUrl.toString());
    }
  }, [props]);

  const renderFormProvider = () => {
    if (mode === 'new') {
      return (
        <TaskFormProvider.New onTaskCreated={onTaskCreated} {...props}>
          <TaskFormHeader view='New' breadCrumbs={breadCrumbs} />
          <MainTaskForm />
        </TaskFormProvider.New>
      );
    }

    return (
      <TaskFormProvider.Edit onTaskUpdated={onTaskUpdated} {...props}>
        <TaskFormHeader view='Edit' breadCrumbs={breadCrumbs} />
        <MainTaskForm />
      </TaskFormProvider.Edit>
    );
  };

  return <Box>{renderFormProvider()}</Box>;
};

export default TaskForm;
