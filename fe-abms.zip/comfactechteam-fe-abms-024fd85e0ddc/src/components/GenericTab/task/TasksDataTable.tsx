import React from 'react';
import TasksList from '@/views/calendar/tasks/list';
import Task from '@/models/Task';

interface TasksDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  onNewTask?: () => void;
  onEditTask?: (task: Task, recurringEditOption?: string) => void;
  onViewTask?: (task: Task, event?: React.MouseEvent) => void;
  searchArg?: Array<any>;
  customWorkflowRoutes?: {
    addNote?: (task: Task) => string;
    addEmail?: (task: Task) => string;
    addSms?: (task: Task) => string;
    addCall?: (task: Task) => string;
    addEvent?: (task: Task) => string;
    addDocument?: (task: Task) => string;
  };
}

/**
 * TasksDataTable - A wrapper component that reuses TasksList
 * This component provides a way to embed the full tasks list functionality
 * in other contexts (like tabs in Deal/Account views) with custom action handlers.
 *
 * Pattern follows: /views/sales/deals/view/tabs/tasks.tsx
 */
const TasksDataTable: React.FC<TasksDataTableProps> = ({
  onNewTask,
  onEditTask,
  onViewTask,
  searchArg,
  customWorkflowRoutes,
  ...props
}) => {
  return (
    <TasksList
      externalData={true}
      externalSearchArgs={searchArg}
      onCustomNew={onNewTask}
      onCustomEdit={onEditTask}
      onCustomView={onViewTask}
      customWorkflowRoutes={customWorkflowRoutes}
      {...props}
    />
  );
};

export default TasksDataTable;
