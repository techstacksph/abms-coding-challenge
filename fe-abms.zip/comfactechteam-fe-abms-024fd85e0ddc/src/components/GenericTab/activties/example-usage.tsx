import React, { useState } from 'react';
import { ActivityFormWrapper, ActivitiesDataTable } from './index';

// Example component showing how to use the reusable activity components with callbacks
const ExampleActivityUsage = () => {
  const [currentView, setCurrentView] = useState<'list' | 'form'>('list');
  const [selectedActivityType, setSelectedActivityType] = useState<string>('');
  const [selectedActivity, setSelectedActivity] = useState<any>(null);

  const handleNewActivity = (activityType: string) => {
    setSelectedActivityType(activityType);
    setCurrentView('form');
  };

  const handleEditActivity = (activity: any) => {
    setSelectedActivity(activity);
    setCurrentView('form');
  };

  const handleViewActivity = (activity: any) => {
    console.log('View activity:', activity);
    // Navigate to view page or show modal
  };

  const handleFormSuccess = (activityType: string, data: any) => {
    console.log('Activity created/updated:', activityType, data);
    // Handle success - maybe refresh data, show notification, etc.
    setCurrentView('list');
  };

  const handleFormCancel = () => {
    console.log('Activity form cancelled');
    setCurrentView('list');
  };

  if (currentView === 'form') {
    return (
      <ActivityFormWrapper
        mode={selectedActivity ? 'edit' : 'new'}
        activityType={selectedActivityType as any}
        module='accounts'
        breadCrumbs={[
          'Accounts',
          'View Account',
          selectedActivity ? 'Edit Activity' : 'New Activity',
        ]}
        recipients={[]} // Add your recipients here
        initialRecipientData={null} // Add your initial data here
        accountId='123' // Add your account ID here
        id={selectedActivity?.id} // For edit mode
        redirectUrl='/accounts/accounts/123/activities' // Base URL for navigation
        onNewActivity={handleFormSuccess}
        onEditActivity={(activityId, data) => {
          console.log('Activity updated:', activityId, data);
          setCurrentView('list');
        }}
        onCancel={handleFormCancel}
      />
    );
  }

  return (
    <ActivitiesDataTable
      id='123' // Add your account ID here
      module='accounts'
      onNewActivity={handleNewActivity}
      onEditActivity={handleEditActivity}
      onViewActivity={handleViewActivity}
    />
  );
};

export default ExampleActivityUsage;
