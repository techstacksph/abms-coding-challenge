import React, { useEffect, useState } from 'react';

import {
  Content,
  ModuleActions,
  Text,
  Button,
  MaterialIcon,
  useSnackbar,
} from '@/styled-components';

import DataTable from '@/components/DataTable';
import { dropdownLinkRender } from '@/components/DropdownMenuRender';
import ModuleAlert, { ModuleRowSelection } from '@/components/ModuleAlert';
import environment from '@/config/environment';
import { CommTypesEnum, relatedModuleFieldMap } from '@/constants/Activities';
import {
  ACTIVITIES_BY_MODULE,
  PAGINATED_ACTIVITIES_BY_MODULE,
} from '@/graphql/activities.gql';
import { DELETE_COMM_LOGs } from '@/graphql/communicationLogs.gql';
import { DELETE_NOTES } from '@/graphql/notes.gql';
import useMutation from '@/hooks/useMutation';
import useNavigate from '@/hooks/useNavigate';
import ActivityModel from '@/models/ActivityModel';
import { Box, Stack } from '@mui/material';
import { mapArrToCSVFields, convertToCSVBase64 } from '@/utils/array.utils';
import { saveCSVFile } from '@/services/export.services';
import { mergeSearchParams } from '@/utils/string.utils';

import { Dropdown } from 'antd';

import { activitiesListColumns } from '../../../views/activities/common/columns';
import {
  MODAL_TITLE,
  MODULE_NAME,
  MODULE_NAME_SINGULAR,
} from '../../../views/activities/common/constants';
import { exportFields } from '../../../views/activities/common/fields';
const TENANT_PREFIX = environment.TENANT_PREFIX;

interface ActivitiesDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  recipients?: any[];
  onNewActivity?: (activityType: string) => void;
  onEditActivity?: (activity: ActivityModel) => void;
  onViewActivity?: (activity: ActivityModel) => void;
}

const ActivitiesDataTable: React.FC<ActivitiesDataTableProps> = ({
  id,
  module,
  tab,
  setTab,
  onNewActivity,
  onEditActivity,
  onViewActivity,
}) => {
  const { snackbar } = useSnackbar();
  const { navigate } = useNavigate('List');
  const [selected, setSelected] = useState<ModuleRowSelection<ActivityModel>>({
    selected: [],
  });
  const [searchKeyword, setSearchKeyword] = useState<string>('');
  const [refetch, setRefetch] = useState<boolean>(false);
  const [allQueryData, setAllQueryData] = useState<Array<ActivityModel>>([]);
  const [page, setPage] = useState<number>(1);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [forceLoadAllData, setForceLoadAllData] = useState<boolean>(false);
  const [isDataLoading, setIsDataLoading] = useState<boolean>(false);

  const [deleteCommLogs, { loading: deleteCommLogLoading }] = useMutation({
    query: DELETE_COMM_LOGs,
    disableAlert: true,
  });

  const [deleteNotes, { loading: deleteNoteLoading }] = useMutation({
    query: DELETE_NOTES,
    disableAlert: true,
  });

  const submitDelete = async () => {
    const selectedCommLogs = selected.selected.filter(
        activity => activity.commType != CommTypesEnum.NOTE
      ),
      selectedNotes = selected.selected.filter(
        activity => activity.commType == CommTypesEnum.NOTE
      ),
      totalDeleted = selectedCommLogs.length + selectedNotes.length;
    try {
      if (selectedCommLogs.length > 0) {
        await deleteCommLogs({
          variables: {
            ids: selectedCommLogs.map(d => d.id),
          },
        });
      }

      if (selectedNotes.length > 0) {
        await deleteNotes({
          variables: {
            ids: selectedNotes.map(d => d.id),
          },
        });
      }

      snackbar({
        type: 'success',
        message: `
        ${
          totalDeleted > 1 ? MODULE_NAME : MODULE_NAME_SINGULAR
        } deleted successfully.`,
      });
    } catch (error) {
      console.log({ error });
      snackbar({
        type: 'error',
        message: `There was an error deleting the ${
          totalDeleted > 1
            ? MODULE_NAME.toLowerCase()
            : MODULE_NAME_SINGULAR.toLowerCase()
        }`,
      });
    }

    setSelected({ selected: [] });
    setRefetch(true);
  };

  const onSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const str_search = e.target.value;
    setSearchKeyword(str_search);
  };

  const handleNewActivity = (activityType: string) => {
    if (onNewActivity) {
      onNewActivity(activityType);
    } else {
      // Default navigation behavior
      const searchParams = mergeSearchParams(location.pathname, {
        activityType,
      });
      const basePath = `${location.pathname}/activities/new${searchParams}`;

      navigate(basePath, {
        state:
          module == 'site'
            ? { siteId: id, module: module }
            : { module: module },
      });
    }
  };

  const handleEditActivity = (activity: ActivityModel) => {
    console.log('activity', activity);
    if (onEditActivity) {
      onEditActivity(activity);
    } else {
      // Default navigation behavior
      const activityType = CommTypesEnum[activity?.commType?.toUpperCase()];
      const searchParams = mergeSearchParams(location.pathname, {
        activityType,
      });
      const editPath =
        module == 'site'
          ? `${location.pathname}/site/activities/${activity?.id}/edit${searchParams}`
          : `${location.pathname}/activities/${activity?.id}/edit${searchParams}`;
      navigate(editPath);
    }
  };

  const handleSearchKeyword = (searchKeyword: string) => {
    if (searchKeyword == 'call log' || searchKeyword == 'call logs') {
      return searchKeyword;
    } else {
      return /(call|log|call\s*log|^l\s*l|^l\s*lo)/i.test(searchKeyword)
        ? 'call'
        : searchKeyword;
    }
  };

  const handleViewActivity = (activity: ActivityModel) => {
    if (onViewActivity) {
      onViewActivity(activity);
    } else {
      // Default navigation behavior
      const viewPageUrlExt =
        activity?.commType == CommTypesEnum.NOTE ? '/note' : '';
      navigate(
        `${location.pathname}/activities/${activity?.id}${viewPageUrlExt}`
      );
    }
  };

  useEffect(() => {
    if (tab == '' && setTab) {
      setTab('activities');
    }
  }, [tab]);

  useEffect(() => {
    if (
      forceLoadAllData &&
      !isDataLoading &&
      allQueryData &&
      allQueryData.length > 0
    ) {
      try {
        setIsExporting(true);
        const csvData = mapArrToCSVFields(allQueryData, exportFields);
        const base64CSV = convertToCSVBase64(csvData);
        saveCSVFile(base64CSV, MODULE_NAME);
        snackbar({
          type: 'success',
          message: 'Activities exported successfully!',
        });
      } catch (error) {
        console.error('Export error:', error);
        snackbar({
          type: 'error',
          message: 'Failed to export activities.',
        });
      } finally {
        setIsExporting(false);
        setForceLoadAllData(false);
      }
    }
  }, [forceLoadAllData, allQueryData, isDataLoading, snackbar]);

  return (
    <Box>
      <Stack spacing={2.5}>
        <Content $css={'border: 0px; padding: 0px !important'}>
          <ModuleActions
            onSearch={e => setTimeout(() => onSearch(e), 1000)}
            isExporting={isExporting}
            onCustomExport={async () => {
              try {
                // if (allQueryData && allQueryData.length > 0) {
                //   // Data is already available, export immediately
                //   setForceLoadAllData(true);
                //   const csvData = mapArrToCSVFields(allQueryData, exportFields);
                //   const base64CSV = convertToCSVBase64(csvData);
                //   saveCSVFile(base64CSV, MODULE_NAME);
                //   snackbar({
                //     type: 'success',
                //     message: 'Activities exported successfully!',
                //   });
                //   return csvData;
                // } else {
                // Force load all data for export
                snackbar({
                  type: 'info',
                  message: 'Loading activities data for export...',
                });
                setForceLoadAllData(true);
                return [];
                // }
              } catch (error) {
                console.error('Export error:', error);
                snackbar({
                  type: 'error',
                  message: 'Failed to export activities.',
                });
                return [];
              }
            }}
            ComponentCustom={
              <Dropdown
                dropdownRender={dropdownLinkRender}
                menu={{
                  items: [
                    {
                      key: 'email',
                      title: 'New Email',
                      label: (
                        <Button
                          type='text'
                          $css='&::after { content: unset !important;}'
                          onClick={() => handleNewActivity('email')}
                        >
                          <Stack
                            direction='row'
                            alignItems='center'
                            spacing={1}
                          >
                            <MaterialIcon
                              name='mail'
                              $css='color: var(--icon-3)'
                            />
                            <Text>New email</Text>
                          </Stack>
                        </Button>
                      ),
                    },
                    {
                      key: 'sms',
                      title: 'New SMS',
                      label: (
                        <Button
                          type='text'
                          $css='&::after { content: unset !important;}'
                          onClick={() => handleNewActivity('sms')}
                        >
                          <Stack
                            direction='row'
                            alignItems='center'
                            spacing={1}
                          >
                            <MaterialIcon
                              name='sms'
                              $css='color: var(--icon-3)'
                            />
                            <Text>New SMS</Text>
                          </Stack>
                        </Button>
                      ),
                    },
                    {
                      key: 'calls',
                      title: 'New call log',
                      label: (
                        <Button
                          type='text'
                          $css='&::after { content: unset !important;}'
                          onClick={() => handleNewActivity('calls')}
                        >
                          <Stack
                            direction='row'
                            alignItems='center'
                            spacing={1}
                          >
                            <MaterialIcon
                              name='call_log'
                              $css='color: var(--icon-3)'
                            />
                            <Text>New call log</Text>
                          </Stack>
                        </Button>
                      ),
                    },
                    {
                      key: 'note',
                      title: 'New note',
                      label: (
                        <Button
                          type='text'
                          $css='&::after { content: unset !important;}'
                          onClick={() => handleNewActivity('note')}
                        >
                          <Stack
                            direction='row'
                            alignItems='center'
                            spacing={1}
                          >
                            <MaterialIcon
                              name='note_stack'
                              $css='color: var(--icon-3)'
                            />
                            <Text>New note</Text>
                          </Stack>
                        </Button>
                      ),
                    },
                  ],
                }}
                trigger={['click']}
              >
                <Button
                  type='primary'
                  icon={<MaterialIcon name='add' />}
                  $css='font-size: 14px; padding: 8px 12px;'
                  data-cy='list-button-new'
                >
                  <Stack direction='row' alignItems='center' spacing={0.5}>
                    <Text color='#fff' weight='medium'>
                      Activity
                    </Text>
                    <MaterialIcon name='arrow_drop_down' />
                  </Stack>
                </Button>
              </Dropdown>
            }
            title='Activities'
          />
          <DataTable
            columns={activitiesListColumns()}
            onChangeSelected={selected => {
              setSelected({ selected, type: 'multiple' });
            }}
            actions={[
              {
                type: 'group',
                title: 'Actions',
              },
              {
                type: 'view',
                title: 'View details',
                onClick: handleViewActivity,
              },
              {
                type: 'edit',
                title: 'Edit',
                show: (record: ActivityModel) =>
                  record?.commType == CommTypesEnum.NOTE ||
                  record?.commType == CommTypesEnum.CALLS,
                onClick: handleEditActivity,
              },
              {
                type: 'delete',
                title: 'Delete',
                onClick: (record: ActivityModel) =>
                  setSelected({ selected: [record], type: 'single' }),
              },
            ]}
            paginationText={''}
            showTotal={false}
            paginatedQuery={PAGINATED_ACTIVITIES_BY_MODULE}
            allQuery={ACTIVITIES_BY_MODULE}
            setAllQueryData={setAllQueryData}
            refetch={{ refetch, setRefetch }}
            searchFields={[]}
            sortArg={[]}
            page={page}
            setPage={setPage}
            onTableChange={(pagination, filters, sorter, extra) => {
              if (extra?.action === 'paginate') {
                setPage(pagination?.current);
              }
            }}
            customArgs={{
              [`${TENANT_PREFIX}relatedRecordFieldName`]:
                relatedModuleFieldMap[module],
              [`${TENANT_PREFIX}relatedRecordId`]: id,
              [`${TENANT_PREFIX}searchKeyword`]:
                handleSearchKeyword(searchKeyword),
            }}
            isDataLoading={isDataLoading}
            setIsDataLoading={setIsDataLoading}
            forceLoadAllData={forceLoadAllData}
            setForceLoadAllData={setForceLoadAllData}
          />
          <ModuleAlert
            message={
              selected.type === 'single' ? (
                <Text>
                  Are you sure you want to move this activity to the Recycle
                  Bin?
                </Text>
              ) : (
                <>
                  <Text>
                    Are you sure you want to move all selected activities to the
                    recycle bin?
                  </Text>
                </>
              )
            }
            title={MODAL_TITLE}
            loading={deleteCommLogLoading || deleteNoteLoading}
            selected={selected}
            onDelete={async () => {
              await submitDelete();
            }}
            onExport={() => {}}
          />
        </Content>
      </Stack>
    </Box>
  );
};

export default ActivitiesDataTable;
