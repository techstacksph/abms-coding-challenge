import React, { useEffect } from 'react';
import { useParams } from '@/utils/navigation.utils';

import environment from '@/config/environment';
import { CommTypes } from '@/constants/Activities';
import {
  DELETE_COMM_LOG,
  FIND_COMM_LOG_BY_ID,
  // ALL_COMM_LOGS_IDS,
} from '@/graphql/communicationLogs.gql';
import {
  // ALL_NOTES,
  CHECK_NOTE,
} from '@/graphql/notes.gql';
import useQuery from '@/hooks/useQuery';
// import useRecordNavigation from '@/hooks/useRecordNavigation';
import CommunicationLogModel from '@/models/CommunicationLogs';
import NoteModel from '@/models/NoteModel';
import ViewCallLog from '@/views/activities/view/callLog';
import ViewEmail from '@/views/activities/view/email';
import ViewSMS from '@/views/activities/view/sms';

import { Spin } from 'antd';
import { Box } from '@mui/material';

const TENANT_PREFIX = environment.TENANT_PREFIX;

interface ActivityViewProps {
  breadCrumbs: string[];
  parentViewPageUrl: string;
  activityId?: string;
  findDocumentsFunction?: (
    allDocumentsIdsData: any[],
    targetId: string
  ) => any[];
  titleDisplaySize?: number;
  endDisplaySize?: number;
}

const ActivityView: React.FC<ActivityViewProps> = ({
  breadCrumbs,
  parentViewPageUrl,
  titleDisplaySize,
  endDisplaySize,
  // activityId,
  // findDocumentsFunction,
}) => {
  const { id, activityId } = useParams();
  // const propsId = id || activityId;
  // Fetch note data to check if the activity is a note
  const { data: noteData, loading: noteLoading } = useQuery<NoteModel>({
    query: CHECK_NOTE,
    options: {
      variables: {
        [`${TENANT_PREFIX}findNoteByIdId`]: activityId ?? id,
      },
      skip: !activityId,
    },
  });

  const isNote = !!noteData;

  // Fetch communication log data
  const { data, loading: commLoading } = useQuery<CommunicationLogModel>({
    query: FIND_COMM_LOG_BY_ID,
    isViewRecordQuery: true,
    options: {
      variables: {
        [`${TENANT_PREFIX}findCommunicationLogByIdId`]: activityId ?? id,
      },
      skip: isNote || noteLoading,
    },
  });

  // const { data: allCommData } = useQuery<Array<{ id: string }>>({
  //   query: ALL_COMM_LOGS_IDS,
  //   options: {
  //     variables: {
  //       tenantPrefix: TENANT_PREFIX,
  //       sortArg: [
  //         {
  //           field: 'createdAt',
  //           direction: 'desc',
  //         },
  //       ],
  //     },
  //     skip: isNote || noteLoading,
  //   },
  // });

  // const { data: allNotesData } = useQuery<Array<{ id: string }>>({
  //   query: ALL_NOTES,
  //   options: {
  //     variables: {
  //       tenantPrefix: TENANT_PREFIX,
  //       sortArg: [
  //         {
  //           field: 'createdAt',
  //           direction: 'desc',
  //         },
  //       ],
  //     },
  //     skip: isNote || noteLoading,
  //   },
  // });

  useEffect(() => {
    if (!noteLoading && isNote) {
      const currentURL = window.location.href;
      const parts = currentURL.split('/activities/');
      if (parts.length > 1) {
        const baseUrl = parts[0];
        const newURL = `${baseUrl}/activities/${activityId}/note`;
        window.location.replace(newURL);
      }
    }
  }, [noteLoading, isNote, activityId]);

  // const allCommsIdData = findDocumentsFunction(allCommData || [], propsId);
  // const allNotesIdData = findDocumentsFunction(allNotesData || [], propsId);
  // const combinedIdData = [...allCommsIdData, ...allNotesIdData];

  // const { currentIndex, previousRecord, nextRecord } = useRecordNavigation({
  //   propsId: activityId,
  //   idList: combinedIdData,
  // });

  // const navigateLoad = {
  //   previousRecord,
  //   nextRecord,
  //   idList: combinedIdData,
  //   currentIndex,
  // };

  const isLoading = [commLoading, noteLoading].includes(true);

  const activityTypeComponents = {
    email: (
      <Spin spinning={isLoading}>
        <ViewEmail
          data={data}
          queryLoading={isLoading}
          breadCrumbs={breadCrumbs}
          deleteQuery={DELETE_COMM_LOG}
          deleteVar={`${TENANT_PREFIX}deleteCommunicationLogId`}
          deleteTitle='Email'
          parentViewPageUrl={parentViewPageUrl}
          titleDisplaySize={titleDisplaySize}
          endDisplaySize={endDisplaySize}
          // navigateLoad={navigateLoad}
        />
      </Spin>
    ),
    sms: (
      <Spin spinning={isLoading}>
        <ViewSMS
          data={data}
          queryLoading={isLoading}
          breadCrumbs={breadCrumbs}
          deleteQuery={DELETE_COMM_LOG}
          deleteVar={`${TENANT_PREFIX}deleteCommunicationLogId`}
          deleteTitle='SMS'
          parentViewPageUrl={parentViewPageUrl}
          titleDisplaySize={titleDisplaySize}
          endDisplaySize={endDisplaySize}
          // navigateLoad={navigateLoad}
        />
      </Spin>
    ),
    calls: (
      <Spin spinning={isLoading}>
        <ViewCallLog
          data={data}
          queryLoading={isLoading}
          breadCrumbs={breadCrumbs}
          deleteQuery={DELETE_COMM_LOG}
          deleteVar={`${TENANT_PREFIX}deleteCommunicationLogId`}
          deleteTitle='Call Log'
          parentViewPageUrl={parentViewPageUrl}
          titleDisplaySize={titleDisplaySize}
          endDisplaySize={endDisplaySize}
          // navigateLoad={navigateLoad}
        />
      </Spin>
    ),
  };

  return (
    <>
      {isLoading ? (
        <Spin spinning={isLoading}>
          <Box sx={{ height: '100vh', width: '100vw' }} />
        </Spin>
      ) : (
        activityTypeComponents[CommTypes[data?.commType]]
      )}
    </>
  );
};

export default ActivityView;
