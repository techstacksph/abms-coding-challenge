import React, { useEffect } from 'react';

import environment from '@/config/environment';
import { CHECK_COMM } from '@/graphql/communicationLogs.gql';
import { DELETE_NOTE, FIND_NOTE_BY_ID } from '@/graphql/notes.gql';
import useQuery from '@/hooks/useQuery';
import CommunicationLogModel from '@/models/CommunicationLogs';
import NoteModel from '@/models/NoteModel';
import ViewNote from '@/views/activities/view/note';

const TENANT_PREFIX = environment.TENANT_PREFIX;

interface ActivityViewNoteProps {
  breadCrumbs: string[];
  parentViewPageUrl: string;
  activityId: string;
  titleDisplaySize?: number;
  endDisplaySize?: number;
}

const ActivityViewNote: React.FC<ActivityViewNoteProps> = ({
  breadCrumbs,
  parentViewPageUrl,
  activityId,
  titleDisplaySize,
  endDisplaySize,
}) => {
  // Fetch note data to check if the activity is a note
  const { data: commData, loading: commLoading } =
    useQuery<CommunicationLogModel>({
      query: CHECK_COMM,
      options: {
        variables: {
          [`${TENANT_PREFIX}findCommunicationLogByIdId`]: activityId,
        },
        skip: !activityId,
      },
    });

  const isComm = !!commData;

  const { data, loading } = useQuery<NoteModel>({
    query: FIND_NOTE_BY_ID,
    isViewRecordQuery: true,
    options: {
      variables: {
        [`${TENANT_PREFIX}findNoteByIdId`]: activityId,
      },
      skip: isComm || commLoading,
    },
  });

  useEffect(() => {
    if (!commLoading && isComm) {
      const currentURL = window.location.href;
      const parts = currentURL.split('/activities/');
      if (parts.length > 1) {
        const baseUrl = parts[0];
        const newURL = `${baseUrl}/activities/${activityId}`;
        window.location.replace(newURL);
      }
    }
  }, [commLoading, isComm, activityId]);

  const isLoading = commLoading || loading;

  const noteProps = {
    data: data,
    queryLoading: isLoading,
    breadCrumbs: breadCrumbs,
    deleteQuery: DELETE_NOTE,
    deleteVar: `${TENANT_PREFIX}deleteNoteId`,
    deleteTitle: 'Note',
    parentViewPageUrl: parentViewPageUrl,
    titleDisplaySize: titleDisplaySize,
    endDisplaySize: endDisplaySize,
  };

  return <ViewNote {...noteProps} />;
};

export default ActivityViewNote;
