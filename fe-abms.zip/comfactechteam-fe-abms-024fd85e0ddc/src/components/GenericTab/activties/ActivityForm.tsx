import React, { useState } from 'react';
import ReactQuill from 'react-quill';

import { Box, Stack } from '@mui/material';
import ActivityFormHeader from '@/views/activities/common/components/ActivityFormHeader';
import ActivityFormProvider from '@/views/activities/common/components/ActivityFormProvider';
import NoteFormProvider from '@/views/activities/common/components/NoteFormProvider';
import EmailActivityInformation from '@/views/activities/common/components/forms/email/ActivityInformation';
import SMSActivityInformation from '@/views/activities/common/components/forms/sms/ActivityInformation';
import CallsActivityInformation from '@/views/activities/common/components/forms/callLog/ActivityInformation';
import { Container, FormSection } from '@/styled-components';
import FormCard from '@/components/FormCard';
import { noteFields } from '@/views/activities/common/fields';
import { Spin } from 'antd';

interface ActivityFormProps {
  mode: 'new' | 'edit';
  activityType: string;
  module: string;
  breadCrumbs: string[];
  recipients?: any[];
  initialRecipientData?: any;
  initialWatcherData?: any;
  redirectUrl?: string;
  recipientsMode?: 'user' | 'contact' | 'employee';
  loading?: boolean;
  [key: string]: any;
}

const ActivityForm: React.FC<ActivityFormProps> = ({
  mode,
  activityType,
  module,
  breadCrumbs,
  recipients = [],
  initialRecipientData,
  initialWatcherData,
  redirectUrl,
  recipientsMode,
  loading = false,
  ...props
}) => {
  const [quill, setQuill] = useState<ReactQuill>(null);
  const normalizedActivityType = activityType?.toLowerCase();
  const renderActivityInformation = () => {
    switch (normalizedActivityType) {
      case 'email':
        return (
          <EmailActivityInformation
            initialRecipientData={initialRecipientData}
            initialWatcherData={initialWatcherData}
            recipients={recipients}
            recipientsMode={recipientsMode}
            loading={loading}
          />
        );
      case 'sms':
        return (
          <SMSActivityInformation
            initialRecipientData={initialRecipientData}
            recipients={recipients}
            setQuill={setQuill}
            recipientsMode={recipientsMode}
            loading={loading}
          />
        );
      case 'calls':
        return (
          <CallsActivityInformation
            initialRecipientData={initialRecipientData}
            loading={loading}
          />
        );
      case 'note':
        return (
          <Spin spinning={loading}>
            <Container>
              <Stack>
                <FormCard
                  title='Activity information'
                  containerProps={{ spacing: 2 }}
                >
                  <Stack width='100%'>
                    <FormSection fields={noteFields} />
                  </Stack>
                </FormCard>
              </Stack>
            </Container>
          </Spin>
        );
      default:
        return null;
    }
  };

  const renderFormProvider = () => {
    if (normalizedActivityType === 'note') {
      const NoteProvider =
        mode === 'new' ? NoteFormProvider.New : NoteFormProvider.Edit;
      return (
        <NoteProvider
          activityType='note'
          module={module}
          redirectUrl={redirectUrl}
          {...props}
        >
          <ActivityFormHeader
            view={mode === 'new' ? 'New' : 'Edit'}
            breadCrumbs={breadCrumbs ?? []}
            titleDisplaySize={props?.titleDisplaySize}
            endDisplaySize={props?.endDisplaySize}
          />
          {renderActivityInformation()}
        </NoteProvider>
      );
    }

    if (mode === 'new') {
      return (
        <ActivityFormProvider.New
          quillInstance={normalizedActivityType === 'sms' ? quill : undefined}
          activityType={normalizedActivityType}
          module={module}
          redirectUrl={redirectUrl}
          {...props}
        >
          <ActivityFormHeader
            view='New'
            breadCrumbs={breadCrumbs ?? []}
            displaySaveBtn={!['email', 'sms'].includes(normalizedActivityType)}
            titleDisplaySize={props?.titleDisplaySize}
            endDisplaySize={props?.endDisplaySize}
          />
          {renderActivityInformation()}
        </ActivityFormProvider.New>
      );
    }

    return (
      <ActivityFormProvider.Edit
        activityType={normalizedActivityType}
        activityId={props.activityId}
        redirectUrl={redirectUrl}
        {...props}
      >
        <ActivityFormHeader
          view='Edit'
          breadCrumbs={breadCrumbs ?? []}
          titleDisplaySize={props?.titleDisplaySize}
          endDisplaySize={props?.endDisplaySize}
        />
        {renderActivityInformation()}
      </ActivityFormProvider.Edit>
    );
  };

  return <Box>{renderFormProvider()}</Box>;
};

export default ActivityForm;
