import React, { useState } from 'react';
import ReactQuill from 'react-quill';

import ContactModel from '@/models/ContactModel';
import User from '@/models/User';
import { Box, Stack } from '@mui/material';
import ActivityFormHeader from '@/views/activities/common/components/ActivityFormHeader';
import ActivityFormProvider from '@/views/activities/common/components/ActivityFormProvider';
import NoteFormProvider from '@/views/activities/common/components/NoteFormProvider';
import EmailActivityInformation from '@/views/activities/common/components/forms/email/ActivityInformation';
import SMSActivityInformation from '@/views/activities/common/components/forms/sms/ActivityInformation';
import CallsActivityInformation from '@/views/activities/common/components/forms/callLog/ActivityInformation';
import { Container, FormSection } from '@/styled-components';
import FormCard from '@/components/FormCard';
import { noteFields } from '@/views/activities/common/fields';

interface ActivityFormWrapperProps {
  mode: 'new' | 'edit';
  activityType: 'email' | 'sms' | 'calls' | 'note';
  module: string;
  breadCrumbs: string[];
  recipients?: Array<ContactModel | User>;
  initialRecipientData?: any;
  initialWatcherData?: any;
  onNewActivity?: (activityType: string, data: any) => void;
  onEditActivity?: (activityId: string, data: any) => void;
  onCancel?: () => void;
  [key: string]: any;
}

const ActivityFormWrapper: React.FC<ActivityFormWrapperProps> = ({
  mode,
  activityType,
  module,
  breadCrumbs,
  recipients = [],
  initialRecipientData,
  initialWatcherData,
  ...props
}) => {
  const [quill, setQuill] = useState<ReactQuill>(null);

  const renderActivityInformation = () => {
    switch (activityType) {
      case 'email':
        return (
          <EmailActivityInformation
            initialRecipientData={initialRecipientData}
            initialWatcherData={initialWatcherData}
            recipients={recipients}
          />
        );
      case 'sms':
        return (
          <SMSActivityInformation
            initialRecipientData={initialRecipientData}
            recipients={recipients}
            setQuill={setQuill}
          />
        );
      case 'calls':
        return (
          <CallsActivityInformation
            initialRecipientData={initialRecipientData}
          />
        );
      case 'note':
        return (
          <Container>
            <Stack>
              <FormCard
                title='Activity information'
                containerProps={{ spacing: 2 }}
              >
                <Stack width='100%'>
                  <FormSection fields={noteFields} />
                </Stack>
              </FormCard>
            </Stack>
          </Container>
        );
      default:
        return null;
    }
  };

  const renderFormProvider = () => {
    if (activityType === 'note') {
      const NoteProvider =
        mode === 'new' ? NoteFormProvider.New : NoteFormProvider.Edit;
      return (
        <NoteProvider activityType='note' module={module} {...props}>
          <ActivityFormHeader
            view={mode === 'new' ? 'New' : 'Edit'}
            breadCrumbs={breadCrumbs ?? []}
          />
          {renderActivityInformation()}
        </NoteProvider>
      );
    }

    if (mode === 'new') {
      return (
        <ActivityFormProvider.New
          quillInstance={activityType === 'sms' ? quill : undefined}
          activityType={activityType}
          module={module}
          {...props}
        >
          <ActivityFormHeader view='New' breadCrumbs={breadCrumbs ?? []} />
          {renderActivityInformation()}
        </ActivityFormProvider.New>
      );
    }

    return (
      <ActivityFormProvider.Edit
        activityType={activityType}
        activityId={props.id}
        {...props}
      >
        <ActivityFormHeader view='Edit' breadCrumbs={breadCrumbs ?? []} />
        {renderActivityInformation()}
      </ActivityFormProvider.Edit>
    );
  };

  return <Box>{renderFormProvider()}</Box>;
};

export default ActivityFormWrapper;
