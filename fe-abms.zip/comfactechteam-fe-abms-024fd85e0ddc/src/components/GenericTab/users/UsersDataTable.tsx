import React from 'react';
import UsersList from '@/views/settings/users/list';
import EventModel from '@/models/EventModel'; // Although it's users data table, using similar import pattern if needed, but UsersList handles logic.
import UserModel from '@/models/User';

interface UsersDataTableProps {
    id?: string;
    module?: string;
    tab?: string;
    setTab?: (val: string) => void;
    breadCrumbs?: string[];
    onNewUser?: () => void;
    onEditUser?: (user: UserModel) => void;
    onViewUser?: (user: UserModel, e?: React.MouseEvent) => void;
    viewRoute?: string;
    searchArg?: Array<any>;
    [key: string]: any;
}

const UsersDataTable: React.FC<UsersDataTableProps> = ({
    onNewUser,
    onEditUser,
    onViewUser,
    searchArg,
    ...props
}) => {
    return (
        <UsersList
            externalData={true}
            searchArg={searchArg}
            onNewUser={onNewUser}
            onEditUser={onEditUser}
            onViewUser={onViewUser}
            {...props}
        />
    );
};

export default UsersDataTable;
