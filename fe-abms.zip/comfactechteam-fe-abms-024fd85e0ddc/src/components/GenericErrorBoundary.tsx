import React from 'react';
import { useNavigate } from 'react-router-dom';

import { Container, Text } from '@/styled-components';
import { Box, Button, Stack } from '@mui/material';
import { convertCase } from '@/styled-components/utils/stringHelper';

interface GenericErrorBoundaryProps {
  error?: Error;
  errorInfo?: React.ErrorInfo;
  onReset?: () => void;
  moduleName?: string;
  modulePath?: string;
  showGoToModule?: boolean;
  customMessage?: string;
}

const GenericErrorBoundary: React.FC<GenericErrorBoundaryProps> = ({
  error,
  errorInfo,
  onReset,
  moduleName = 'Module',
  modulePath,
  showGoToModule = true,
  customMessage,
}) => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1);
  };

  const handleGoToModule = () => {
    if (modulePath) {
      navigate(modulePath);
    }
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  const getDefaultMessage = () => {
    if (customMessage) return customMessage;
    return `We encountered an issue while loading the ${moduleName.toLowerCase()} data. 
    This might be due to a temporary network issue or a problem with the data.`;
  };

  return (
    <Container>
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Stack spacing={3}>
          <Text size={24} weight='bold' color='var(--color-error)'>
            {convertCase(moduleName)} Error
          </Text>
          <Text size={16} color='var(--color-text-secondary)'>
            {getDefaultMessage()}
          </Text>

          {error && process.env.NODE_ENV === 'development' && (
            <Box sx={{ textAlign: 'left', maxWidth: '600px', mx: 'auto' }}>
              <Text size={14} weight='bold' color='var(--color-error)'>
                Error Details (Development):
              </Text>
              <Text
                size={12}
                color='var(--color-text-secondary)'
                $css='font-family: monospace; white-space: pre-wrap;'
              >
                {error.toString()}
                {errorInfo?.componentStack}
              </Text>
            </Box>
          )}

          <Stack direction='row' spacing={2} justifyContent='center'>
            <Button
              variant='contained'
              onClick={handleRefresh}
              sx={{ alignSelf: 'center' }}
            >
              Refresh Page
            </Button>
            {showGoToModule && modulePath && (
              <Button
                variant='outlined'
                onClick={handleGoToModule}
                sx={{ alignSelf: 'center' }}
              >
                Go to {convertCase(moduleName)}
              </Button>
            )}
            <Button
              variant='outlined'
              onClick={handleGoBack}
              sx={{ alignSelf: 'center' }}
            >
              Go Back
            </Button>
            {onReset && (
              <Button
                variant='outlined'
                onClick={onReset}
                sx={{ alignSelf: 'center' }}
              >
                Try Again
              </Button>
            )}
          </Stack>

          <Box sx={{ mt: 2 }}>
            <Text size={14} color='var(--color-text-secondary)'>
              If this problem persists, please contact support.
            </Text>
          </Box>
        </Stack>
      </Box>
    </Container>
  );
};

export default GenericErrorBoundary;
