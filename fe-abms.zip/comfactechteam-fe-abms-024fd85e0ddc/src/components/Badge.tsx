import React from 'react';

import styled from 'styled-components';

import { Badge as AntdBadge, BadgeProps } from 'antd';

const StyledBadge = styled(AntdBadge)`
  & [class*='badge-dot'] {
    width: 4px;
    min-width: 4px;
    height: 4px;
  }
`;

export const Badge = (props: BadgeProps) => {
  return <StyledBadge {...props}>{props.children}</StyledBadge>;
};
