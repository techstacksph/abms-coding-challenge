import React from 'react';

import { Text } from '@/styled-components';

import {
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from '@mui/material';

export type BareColumn = {
  key: string;
  label: string;
  align?: 'left' | 'right' | 'center';
  render?: (value: any, row: Record<string, any>) => React.JSX.Element | string;
};

type Props = {
  columns: BareColumn[];
  data: Record<string, any>[];
};
const BareTable = ({ columns, data }: Props) => {
  return (
    <TableContainer component='div'>
      <Table
        sx={{
          minWidth: 650,
          width: '100%',
          tableLayout: 'fixed',
          borderCollapse: 'collapse',
        }}
        aria-label='custom table'
      >
        <TableHead>
          <TableRow>
            {columns.map(col => (
              <TableCell
                key={col.key}
                align={col.align || 'left'}
                sx={{
                  border: 'none',
                  width: `${100 / columns.length}%`,
                  padding: '10px 16px',
                  fontWeight: 'bolder',
                }}
              >
                <Text $css={'font-weight:700;'}>{col.label}</Text>
              </TableCell>
            ))}
          </TableRow>
        </TableHead>

        <TableBody>
          {data.map((row, index) => (
            <TableRow key={index}>
              {columns.map(col => (
                <TableCell
                  key={col.key}
                  align={col.align || 'left'}
                  sx={{
                    border: 'none',
                    width: `${100 / columns.length}%`,
                    padding: '5px 16px',
                  }}
                >
                  {col.render ? col.render(row[col.key], row) : row[col.key]}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default BareTable;
