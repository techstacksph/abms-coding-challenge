import React, { memo } from 'react';

import { Icon, Text } from '@/styled-components';

import Link from '@/components/Link';
import SettingsRoutes from '@/constants/SettingsRoutes';
import useNavigate from '@/hooks/useNavigate';
import { AccountCircle } from '@mui/icons-material';
import { Box, Stack } from '@mui/material';

const ListUserItems = ({
  data,
  dataKey,
  disableHover = false,
}: {
  data: Array<any>;
  dataKey: string | Array<string>;
  disableHover?: boolean;
}) => {
  const { navigate } = useNavigate();

  return (
    <Stack justifyContent='space-between'>
      <Box maxHeight='200px' overflow='auto'>
        {data &&
          data?.map((user: any & { id: string }) => (
            <Stack
              key={user.id}
              direction='row'
              spacing={1}
              alignItems='center'
              sx={
                disableHover
                  ? {}
                  : {
                      ':hover': {
                        backgroundColor: '#F4F4F6',
                        cursor: 'pointer',
                        '& .list-button': {
                          visibility: 'visible',
                        },
                      },
                    }
              }
              borderRadius={2}
              px={0.5}
              py={1}
            >
              <Icon size='24px' color='var(--gray-400)'>
                <AccountCircle />
              </Icon>
              <Text
                $type='sm'
                color='#3137FD'
                $css='cursor: pointer'
                onClick={() =>
                  navigate(`${SettingsRoutes.Users.view}/${user?.id}`)
                }
              >
                <Link to={`${SettingsRoutes.Users.view}/${user?.id}`}>
                  {Array.isArray(dataKey)
                    ? dataKey.map(k => user[k]).join(' ')
                    : user[dataKey]}
                </Link>
              </Text>
            </Stack>
          ))}
      </Box>
    </Stack>
  );
};

export default memo(ListUserItems);
