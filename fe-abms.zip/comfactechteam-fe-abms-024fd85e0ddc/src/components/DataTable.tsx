/* eslint-disable @typescript-eslint/no-unused-vars */
import { useEffect, useRef, useState } from 'react';

import {
  Checkbox,
  EmptyState,
  GoogleIcon,
  Icon,
  MaterialIcon,
  Select,
  ModuleTable as Table,
  Text,
} from '@/styled-components';

import usePaginatedQuery from '@/hooks/usePaginatedQuery';
import useQuery from '@/hooks/useQuery';
import { safeWarn } from '@/utils/error.utils';
import { Box, Stack } from '@mui/material';

import { Dropdown, Spin } from 'antd';

export type SelectAllMenuTypes = 'this' | 'all' | 'deselect';

export const RowsPerPage = ({ total, range, setPageSize, defaultPageSize }) => {
  return (
    <Stack direction='row' alignItems='center' spacing={1}>
      <Text $type='xs'>Rows per page </Text>
      <Select
        size='small'
        value={defaultPageSize}
        options={[
          {
            label: '10',
            value: 10,
          },
          {
            label: '20 ',
            value: 20,
          },
          {
            label: '50',
            value: 50,
          },
          {
            label: '100',
            value: 100,
          },
        ]}
        onChange={val => setPageSize(val)}
        allowClear={false}
        suffixIcon={
          <GoogleIcon
            name='arrow_drop_down'
            $css={'color: var(--color-text-primary)'}
          />
        }
        $css={`
          &[class*="-select-focused"] [class*="-select-selector"] {
            box-shadow: none;
          }

          [class$="select-selection-item"] {
            color: var(--color-text-primary) !important;
            font-size: 12px;
            padding-inline-end: 24px !important;
          }
          [class$="select-selector"] {
            gap: 4px;
            padding: 0 4px;
            border-width: 0 !important;
          }
        `}
      />
      <Text $type='xs'>
        {range[0]}-{range[1]} of {total}
      </Text>
    </Stack>
  );
};

const DataTable = ({
  columns,
  allQuery = null,
  onChangeSelected,
  searchFields,
  filterFields = [],
  refetch,
  nameField = 'name',
  onTableChange = undefined,
  sortArg,
  paginatedQuery,
  customArgs = {},
  page = 1,
  setPage,
  hasRowSelections = true,
  defaultPageSize = 20,
  onChangePageSize = undefined,
  hideSelectionColumnHeader = false,
  expandable = {},
  transformData = undefined,
  otherTableProps = {},
  loader = false,
  staticData = [],
  skipQueries = false,
  filterLoading = false,
  forceLoadAllData = false,
  setAllQueryData = undefined,
  setIsDataLoading = undefined,
  waitForFilters = false,
  staticPageInfo = undefined,
  calledFrom = '',
  hidePagination = false,
  shouldShowSpinner = false,
  hideFooter = true,
  ...props
}) => {
  const { rowSelection } = props as any;
  const [selectType, setSelectType] = useState<SelectAllMenuTypes>();
  const [selected, setSelected] = useState([]);
  const [selectedRowMap, setSelectedRowMap] = useState<Record<string, any>>({});
  const [pageSize, setPageSize] = useState<number>(defaultPageSize);
  const [filtersInitialized, setFiltersInitialized] = useState(false);
  const currentPageData = useRef([]);

  // Update internal pageSize when defaultPageSize changes from parent
  useEffect(() => {
    setPageSize(defaultPageSize);
  }, [defaultPageSize]);

  let searchArg = [];
  if (searchFields && searchFields != '' && searchFields != null)
    searchArg = searchFields;

  for (const filterArr of filterFields) {
    if (filterArr && filterArr != null) {
      searchArg.push(filterArr);
    }
  }

  // Track when filters have been initialized (either with filters or explicitly empty)
  useEffect(() => {
    if (waitForFilters && !filtersInitialized) {
      // Mark filters as initialized when we have searchFields (even if empty)
      // or when we're not waiting for filters anymore
      if (searchFields !== undefined) {
        setFiltersInitialized(true);
      }
    }
  }, [searchFields, waitForFilters, filtersInitialized]);

  // Skip paginatedQuery if filterLoading is true, skipQueries is true, or waiting for filters
  const shouldSkipPaginatedQuery =
    (skipQueries && !refetch?.refetch) ||
    filterLoading ||
    (waitForFilters && !filtersInitialized);

  // Skip allQuery unless selectType is 'all' or forceLoadAllData is true
  const shouldSkipAllQuery =
    (skipQueries && !refetch?.refetch) ||
    (!forceLoadAllData && selectType !== 'all');

  const {
    data,
    loading,
    refetch: requery,
  } = usePaginatedQuery({
    query: paginatedQuery,
    options: {
      skip: shouldSkipPaginatedQuery,
      variables: {
        pageArg: {
          skip: (page - 1) * pageSize,
          take: pageSize,
          sort: (() => {
            if (!sortArg) {
              return [{ field: nameField, direction: 'desc' }];
            }

            if (Array.isArray(sortArg)) {
              const validSorts = sortArg.filter(
                sort =>
                  sort &&
                  typeof sort === 'object' &&
                  sort.field &&
                  sort.direction &&
                  ['asc', 'desc'].includes(sort.direction)
              );

              if (validSorts.length !== sortArg.length) {
                safeWarn(
                  'Invalid sortArg detected, falling back to default sort',
                  sortArg,
                  'DataTable'
                );
              }

              return validSorts.length > 0
                ? validSorts
                : [{ field: nameField, direction: 'desc' }];
            }

            if (typeof sortArg === 'object' && sortArg !== null) {
              if (
                sortArg.field &&
                sortArg.direction &&
                ['asc', 'desc'].includes(sortArg.direction)
              ) {
                return [sortArg];
              } else {
                safeWarn(
                  'Invalid sortArg object, falling back to default sort',
                  sortArg,
                  'DataTable'
                );
              }
            }

            safeWarn(
              'Invalid sortArg type, falling back to default sort',
              sortArg,
              'DataTable'
            );
            return [{ field: nameField, direction: 'desc' }];
          })(),
        },
        searchArg,
        sortArg,
        ...customArgs,
      },
    },
    transformData: data => (transformData ? transformData(data) : data),
  });

  const {
    data: allData,
    loading: allLoading,
    refetch: allRequery,
  } = useQuery<Array<any>>({
    skip: shouldSkipAllQuery,
    query: allQuery,
    options: {
      fetchPolicy: 'no-cache',
      variables: {
        sortArg: [
          ...(sortArg || {
            field: 'updatedAt',
            direction: 'desc',
          }),
        ],
        searchArg,
        ...customArgs,
      },
    },
    transformData: data => (transformData ? transformData(data) : data),
  });

  useEffect(() => {
    if (setAllQueryData) {
      setAllQueryData(allData);
    }
  }, [allData]);

  useEffect(() => {
    if (allLoading && setAllQueryData) {
      setAllQueryData(undefined);
    }
    if (setIsDataLoading) {
      if (allLoading) {
        setIsDataLoading(true);
      } else if (!allLoading && allData?.length > 0) {
        setTimeout(() => {
          setIsDataLoading(false);
        }, 1000);
      } else {
        setIsDataLoading(loading);
      }
    }
  }, [allLoading, setIsDataLoading, loading]);

  // Refetch allData if it's empty and we need it
  useEffect(() => {
    if (selectType === 'all') {
      allRequery();
    }
  }, [selectType]);

  // Refetch allData when forceLoadAllData becomes true
  useEffect(() => {
    if (forceLoadAllData) {
      allRequery();
    }
  }, [forceLoadAllData]);

  useEffect(() => {
    if (selectType === 'all' && allData && allData.length > 0) {
      const selectId = allData ? allData.map(v => v?.id) : [];
      onChangeSelected(allData ?? [], selectType);
      setSelected(selectId);
    }
  }, [selectType, allData]);

  useEffect(() => {
    if (data?.data.length === 0) {
      const { count } = data.pageInfo;
      const updatedPageNumber = Math.ceil(count / pageSize);

      // SETTING CORRECT PAGE NUMBER (IMPORTANT IN DELETE)
      if (updatedPageNumber > 0) setPage(updatedPageNumber);
    }
  }, [data]);

  // Refetch effect
  useEffect(() => {
    if (refetch?.refetch) {
      // Only reset selection if we're actually refetching data
      // Don't reset if user just selected "all" (selectType will be 'all')
      const shouldResetSelection = selectType !== 'all';

      if (!shouldSkipPaginatedQuery) {
        requery();
      }
      if (!shouldSkipAllQuery) {
        allRequery();
      }

      if (shouldResetSelection) {
        onSelectType('deselect');
        onChangeSelected([], selectType);
        setSelected([]);
      }

      refetch?.setRefetch(false);
    }
  }, [refetch?.refetch, shouldSkipPaginatedQuery, shouldSkipAllQuery]);

  // Handle page size changes
  const handlePageSizeChange = newSize => {
    setPageSize(newSize);
    if (onChangePageSize) {
      onChangePageSize(newSize);
    }
    setPage(1); // Reset to page 1 when changing page size
  };

  const onSelectType = async (type: SelectAllMenuTypes) => {
    setSelectType(type);

    let selectId = [...selected]; // Start with current selections

    if (type === 'this') {
      // Use staticData if available, otherwise fallback to data?.data
      const currentData =
        staticData?.length > 0 ? staticData : data?.data || [];
      const currentPageIds = currentData.map((d: any) => d.id);

      // Add current page IDs to existing selections without duplicates
      for (const id of currentPageIds) {
        if (!selectId.includes(id)) {
          selectId.push(id);
        }
      }

      // Merge currently available rows into the persisted map
      const dataSource =
        staticData?.length > 0
          ? staticData
          : allData && allData.length > 0
            ? allData
            : data?.data || [];
      const nextMap: Record<string, any> = { ...selectedRowMap };
      for (const row of dataSource) {
        if (selectId.includes(row.id)) {
          nextMap[row.id] = row;
        }
      }
      setSelectedRowMap(nextMap);
      onChangeSelected(Object.values(nextMap), type);
    } else if (type === 'all') {
      if (allData && allData.length > 0) {
        selectId = allData.map((d: any) => d.id);
        const nextMap: Record<string, any> = {};
        for (const row of allData) nextMap[row.id] = row;
        setSelectedRowMap(nextMap);
        onChangeSelected(Object.values(nextMap), type);
      }
    } else if (type === 'deselect') {
      selectId = [];
      onChangeSelected([], type);
      setSelectedRowMap({});
    }

    setSelected(selectId);
  };

  const customRowSelection = {
    preserveSelectedRowKeys: true,
    columnWidth: 68,
    columnTitle: () => {
      if (rowSelection?.type === 'radio' || hideSelectionColumnHeader) return;

      return (
        <Dropdown
          menu={{
            items: [
              {
                key: 'thisPage',
                label: 'Select this page',
                onClick: () => onSelectType('this'),
              },
              {
                key: 'allPage',
                label: 'Select all page',
                onClick: () => onSelectType('all'),
              },
              {
                key: 'deselectAll',
                label: 'Deselect all',
                onClick: () => onSelectType('deselect'),
              },
            ],
          }}
          trigger={['click']}
        >
          <a role='button'>
            <Stack direction='row' alignItems='center' spacing={0.5}>
              <Checkbox
                checked={
                  (Boolean(selectType) && selectType != 'deselect') ||
                  (selected.length == data?.pageInfo?.count &&
                    data?.pageInfo?.count > 0)
                }
                indeterminate={
                  (selectType === 'this' &&
                    selected.length !== data?.pageInfo?.count) ||
                  (selected.length > 0 &&
                    selected.length !== data?.pageInfo?.count &&
                    selectType != 'all')
                }
                $css={`
                  min-width: 24px !important;
                  height: 24px;
                  justify-content: center;  
                `}
              />
              <Icon color='var(--gray-600)'>
                <MaterialIcon name='arrow_drop_down' />
              </Icon>
            </Stack>
          </a>
        </Dropdown>
      );
    },
    selectedRowKeys: selected,
    onChange: keys => {
      const prev = selected;
      const added = keys.filter(k => !prev.includes(k));
      const removed = prev.filter(k => !keys.includes(k));

      const findRowById = (id: string) => {
        const sources = [
          ...(currentPageData.current || []),
          ...(staticData || []),
          ...(allData || []),
          ...((data?.data as any[]) || []),
        ];
        return sources.find(r => r?.id === id) || selectedRowMap[id] || { id };
      };

      const nextMap: Record<string, any> = { ...selectedRowMap };
      for (const id of added) nextMap[id] = findRowById(id);
      for (const id of removed) delete nextMap[id];

      setSelected(keys);
      setSelectedRowMap(nextMap);
      if (onChangeSelected) {
        onChangeSelected(Object.values(nextMap), selectType);
      }
    },
    renderCell: (_, __, ___, originNode) => {
      if (rowSelection?.type === 'radio') return originNode;

      return (
        <Box
          display='flex'
          sx={{
            width: 24,
            height: 24,
            justifyContent: 'center',
          }}
        >
          {originNode}
        </Box>
      );
    },
  };

  // SET CUSTOM SORT ICON
  columns = columns?.map(column => {
    return column?.sorter
      ? {
          ...column,
          sortIcon: () => (
            <GoogleIcon name='unfold_more' $css={'font-size: inherit;'} />
          ),
        }
      : column;
  });

  return (
    <Spin
      spinning={
        [loading, allLoading, loader, filterLoading].includes(true) &&
        shouldShowSpinner
      }
    >
      <Table
        columns={columns}
        data={
          staticData?.length > 0
            ? transformData
              ? transformData(staticData)
              : staticData
            : transformData
              ? transformData(data?.data ?? [])
              : (data?.data ?? [])
        }
        paginationText={'Rows per page'}
        showTotal={false}
        paginationProps={{
          onPageChange: (page, pageSize) => {
            setPage(data?.pageInfo?.pageCount >= page ? page : 1);
            setPageSize(pageSize);
            if (onChangePageSize) {
              onChangePageSize(pageSize);
            }
          },
          showSizeChanger: false,
        }}
        onChange={onTableChange}
        pageInfo={staticPageInfo || data?.pageInfo}
        onSelectAllMenu={type => onSelectType(type)}
        loading={[loading, allLoading, loader, filterLoading].includes(true)}
        rowSelection={hasRowSelections ? customRowSelection : undefined}
        hidePagination
        onChangePageSize={handlePageSizeChange}
        hideFooter={hideFooter}
        tableProps={
          hidePagination
            ? undefined
            : {
                footer: currentPage => {
                  currentPageData.current = currentPage;
                  return;
                },
                pagination: {
                  total: (staticPageInfo || data?.pageInfo)?.count,
                  showSizeChanger: false,
                  position: ['bottom', 'left'],
                  pageSize: pageSize,
                  current: page,
                  showTotal: (total, range) => (
                    <RowsPerPage
                      total={total}
                      range={range}
                      setPageSize={handlePageSizeChange}
                      defaultPageSize={pageSize}
                    />
                  ),
                  itemRender: (_, type, originalElement) =>
                    ['page', 'jump-prev', 'jump-next'].includes(type)
                      ? null
                      : originalElement,
                },
                tableLayout: 'fixed',
                expandable,
                ...otherTableProps,
              }
        }
        emptyState={<EmptyState iconW='200px' title='No data to display.' />}
        {...props}
      />
    </Spin>
  );
};

export default DataTable;
