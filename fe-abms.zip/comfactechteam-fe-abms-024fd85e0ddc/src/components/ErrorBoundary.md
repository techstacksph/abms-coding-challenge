# ErrorBoundary Component

A React error boundary component that catches JavaScript errors anywhere in the child component tree and displays a fallback UI instead of crashing the entire application.

## Features

- **Error Catching**: Catches JavaScript errors in child components
- **Fallback UI**: Displays a user-friendly error message with action buttons
- **Development Mode**: Shows detailed error information in development
- **Custom Fallback**: Supports custom fallback components
- **Error Reporting**: Provides callback for error logging
- **Reset Functionality**: Can be reset using a resetKey prop
- **Navigation**: Includes "Go Back" and "Refresh Page" buttons

## Usage

### Basic Usage

```tsx
import ErrorBoundary from '@/components/ErrorBoundary';

const MyComponent = () => {
  return (
    <ErrorBoundary>
      <ComponentThatMightThrow />
    </ErrorBoundary>
  );
};
```

### With Error Callback

```tsx
<ErrorBoundary
  onError={(error, errorInfo) => {
    // Log error to your error reporting service
    console.error('Error caught:', error);
    console.error('Error info:', errorInfo);
  }}
>
  <ComponentThatMightThrow />
</ErrorBoundary>
```

### With Custom Fallback

```tsx
const CustomErrorUI = () => (
  <div>
    <h3>Custom Error Message</h3>
    <button onClick={() => window.location.reload()}>Reload</button>
  </div>
);

<ErrorBoundary fallback={<CustomErrorUI />}>
  <ComponentThatMightThrow />
</ErrorBoundary>;
```

### With Reset Functionality

```tsx
const MyComponent = () => {
  const [resetKey, setResetKey] = useState(0);

  const handleReset = () => {
    setResetKey(prev => prev + 1);
  };

  return (
    <div>
      <button onClick={handleReset}>Reset Error Boundary</button>
      <ErrorBoundary resetKey={resetKey}>
        <ComponentThatMightThrow />
      </ErrorBoundary>
    </div>
  );
};
```

## Props

| Prop       | Type                                                 | Description                                      |
| ---------- | ---------------------------------------------------- | ------------------------------------------------ |
| `children` | `ReactNode`                                          | The components to wrap with error boundary       |
| `fallback` | `ReactNode`                                          | Custom fallback UI component                     |
| `onError`  | `(error: Error, errorInfo: React.ErrorInfo) => void` | Callback function called when an error is caught |
| `resetKey` | `string \| number`                                   | Key to reset the error boundary state            |

## Default Fallback UI

The default fallback UI includes:

- Error message: "Something went wrong"
- Description: "An unexpected error occurred. Please try refreshing the page or go back to the previous page."
- Action buttons:
  - **Refresh Page**: Reloads the current page
  - **Go Back**: Navigates to the previous page
  - **Try Again**: Resets the error boundary (if resetKey is provided)

## Development Mode

In development mode, the error boundary also displays:

- Detailed error message
- Component stack trace
- Error information for debugging

## Best Practices

1. **Wrap Critical Components**: Wrap components that are critical to your application
2. **Use Multiple Boundaries**: Use different error boundaries for different parts of your app
3. **Log Errors**: Use the `onError` callback to log errors to your error reporting service
4. **Provide Reset**: Use `resetKey` to allow users to retry after an error
5. **Custom Fallbacks**: Create custom fallback UIs for specific use cases

## Example Implementation

```tsx
// Wrap your main app component
const App = () => {
  return (
    <ErrorBoundary
      onError={(error, errorInfo) => {
        // Log to your error reporting service
        logErrorToService(error, errorInfo);
      }}
    >
      <YourAppContent />
    </ErrorBoundary>
  );
};

// Or wrap specific sections
const Dashboard = () => {
  return (
    <div>
      <ErrorBoundary>
        <UserProfile />
      </ErrorBoundary>
      <ErrorBoundary>
        <RecentActivity />
      </ErrorBoundary>
      <ErrorBoundary>
        <Analytics />
      </ErrorBoundary>
    </div>
  );
};
```

## Notes

- Error boundaries only catch errors in the component tree below them
- They don't catch errors in event handlers, async code, or server-side rendering
- Use try-catch for those cases
- Error boundaries must be class components (React requirement)
