export { RecordLockIndicator } from './RecordLockIndicator';
export type { RecordLockIndicatorProps } from './RecordLockIndicator';
