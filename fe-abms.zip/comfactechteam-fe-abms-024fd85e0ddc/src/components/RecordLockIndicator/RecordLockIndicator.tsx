import React, { useState, useEffect } from 'react';
import { Tooltip } from 'antd';
import {
  LockOutlined,
  UnlockOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
import styled from 'styled-components';
import { RecordLockInfo } from '@/hooks/useRecordLock';

const LockIconWrapper = styled.span<{ $isOwnedByCurrentUser: boolean }>`
  display: inline-flex;
  align-items: center;
  margin-left: 8px;
  cursor: help;
  font-size: 16px;
  color: ${props => (props.$isOwnedByCurrentUser ? '#1890ff' : '#faad14')};
  vertical-align: middle;

  &:hover {
    opacity: 0.8;
  }
`;

const TooltipContent = styled.div`
  max-width: 300px;

  .tooltip-title {
    font-weight: 600;
    margin-bottom: 4px;
    font-size: 13px;
  }

  .tooltip-details {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.85);
    margin-top: 4px;
  }
`;

const LockBanner = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  background-color: #ffffff;
  border: 1px solid #e5e7eb;
  border-left: 4px solid #facc15;
  border-radius: 4px;
  margin-left: 16px;
  font-size: 14px;
  color: #374151;
  line-height: 20px;
  max-width: fit-content;

  .info-icon {
    font-size: 20px;
    color: #facc15;
    flex-shrink: 0;
  }

  .banner-text {
    line-height: 20px;
    white-space: nowrap;
  }

  .countdown-timer {
    font-weight: 700;
    color: #374151;
  }
`;

export interface RecordLockIndicatorProps {
  /**
   * Lock information from useRecordLock hook
   */
  lockInfo: RecordLockInfo | null;

  /**
   * Whether to show the indicator when record is unlocked
   * Default: false
   */
  showWhenUnlocked?: boolean;
}

/**
 * Component to display record lock status as an icon
 * Shows a lock icon beside the header text with a hover tooltip
 *
 * @example
 * ```tsx
 * const { lockInfo } = useRecordLock({
 *   recordType: 'job',
 *   recordId: '123',
 *   autoAcquire: true,
 * });
 *
 * <h2>
 *   Job Details
 *   <RecordLockIndicator lockInfo={lockInfo} />
 * </h2>
 * ```
 */
export const RecordLockIndicator: React.FC<RecordLockIndicatorProps> = ({
  lockInfo,
  showWhenUnlocked = false,
}) => {
  const [timeRemaining, setTimeRemaining] = useState<number>(0);

  // Extract lock info properties
  const isCurrentUser = lockInfo?.isOwnedByCurrentUser || false;
  const expiresAt = lockInfo?.expiresAt;

  // Countdown timer for current user's lock (must be before any early returns)
  useEffect(() => {
    if (!isCurrentUser || !expiresAt) {
      return;
    }

    const calculateTimeRemaining = () => {
      const now = Date.now();
      const expiryTime = new Date(expiresAt).getTime();
      const remaining = Math.max(0, Math.floor((expiryTime - now) / 1000));
      return remaining;
    };

    setTimeRemaining(calculateTimeRemaining());

    const interval = setInterval(() => {
      const remaining = calculateTimeRemaining();
      setTimeRemaining(remaining);

      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isCurrentUser, expiresAt]);

  // Don't show anything if no lock info
  if (!lockInfo) {
    return null;
  }

  // Don't show anything if unlocked and showWhenUnlocked is false
  if (!lockInfo.isLocked && !showWhenUnlocked) {
    return null;
  }

  // Show unlocked state if enabled
  if (!lockInfo.isLocked && showWhenUnlocked) {
    return (
      <Tooltip title='Available for editing'>
        <LockIconWrapper $isOwnedByCurrentUser={false}>
          <UnlockOutlined />
        </LockIconWrapper>
      </Tooltip>
    );
  }

  // Record is locked - determine by whom
  const lockedByName = lockInfo.lockedBy || 'Unknown User';

  // Format expiration time
  const formatExpirationTime = (isoString: string): string => {
    try {
      const expiryDate = new Date(isoString);
      const now = new Date();
      const diffMs = expiryDate.getTime() - now.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);

      if (diffMins < 1) {
        return 'less than a minute';
      } else if (diffMins < 60) {
        return `${diffMins} minute${diffMins > 1 ? 's' : ''}`;
      } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours > 1 ? 's' : ''}`;
      } else {
        return expiryDate.toLocaleString();
      }
    } catch {
      return 'unknown time';
    }
  };

  // Format countdown timer
  const formatCountdown = (seconds: number): string => {
    if (seconds < 60) {
      return `${seconds} second${seconds !== 1 ? 's' : ''}`;
    }

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    if (hours > 0) {
      if (minutes > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ${minutes} minute${minutes > 1 ? 's' : ''}`;
      }
      return `${hours} hour${hours > 1 ? 's' : ''}`;
    }

    return `${minutes} minute${minutes > 1 ? 's' : ''}`;
  };

  // Show banner for current user's lock
  if (isCurrentUser) {
    return (
      <LockBanner>
        <InfoCircleOutlined className='info-icon' />
        <div className='banner-text'>
          You are currently editing this record. This page is locked for others
          and will expire in{' '}
          <span className='countdown-timer'>
            {formatCountdown(timeRemaining)}
          </span>
          .
        </div>
      </LockBanner>
    );
  }

  // Show icon tooltip for other user's lock
  const tooltipContent = (
    <TooltipContent>
      <div className='tooltip-title'>{lockedByName} is editing this record</div>
      <div className='tooltip-details'>
        You cannot save changes while the record is locked
      </div>
      {expiresAt && (
        <div className='tooltip-details'>
          Lock expires in {formatExpirationTime(expiresAt)}
        </div>
      )}
    </TooltipContent>
  );

  return (
    <Tooltip title={tooltipContent}>
      <LockIconWrapper $isOwnedByCurrentUser={isCurrentUser}>
        <LockOutlined />
      </LockIconWrapper>
    </Tooltip>
  );
};
