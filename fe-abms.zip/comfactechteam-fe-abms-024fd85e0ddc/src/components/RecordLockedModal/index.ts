export { RecordLockedModal } from './RecordLockedModal';
export type { RecordLockedModalProps } from './RecordLockedModal';
