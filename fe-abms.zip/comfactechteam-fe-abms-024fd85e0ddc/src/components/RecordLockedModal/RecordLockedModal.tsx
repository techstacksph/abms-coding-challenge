import React, { useState, useEffect } from 'react';
import { Modal, Progress } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import styled from 'styled-components';
import { MaterialIcon } from '@/styled-components';

export interface RecordLockedModalProps {
  /**
   * Whether the modal is visible
   */
  visible: boolean;

  /**
   * Name of the user who has the lock
   */
  lockedBy?: string;

  /**
   * When the lock expires (ISO timestamp)
   */
  expiresAt?: string;

  /**
   * Callback when modal is closed
   */
  onClose: () => void;
}

const StyledModal = styled(Modal)`
  .ant-modal-content {
    border-radius: 20px;
    padding: 48px 64px;
  }

  .ant-modal-header {
    border-bottom: none;
    padding: 0;
    margin-bottom: 40px;

    .ant-modal-title {
      font-family:
        'Inter',
        -apple-system,
        BlinkMacSystemFont,
        'Segoe UI',
        sans-serif;
      font-size: 24px;
      font-weight: 600;
      color: #1f2937;
    }
  }

  .ant-modal-body {
    padding: 0;
  }

  .ant-modal-footer {
    display: none;
  }

  .ant-modal-close {
    top: 24px;
    right: 24px;
    width: 40px;
    height: 40px;
    border-radius: 8px;
    border: 1px solid #e8e8e8;
    background: #ffffff;

    &:hover {
      background: #f5f5f5;
    }

    .ant-modal-close-x {
      width: 40px;
      height: 40px;
      line-height: 40px;
      font-size: 20px;
      color: #1f2937;
    }
  }
`;

const ContentWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
`;

const IconWrapper = styled.div`
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const MessageText = styled.div`
  font-family:
    'Inter',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  color: #1f2937;
`;

const TimerWrapper = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 120px;
  height: 120px;
  flex-shrink: 0;
`;

const TimerText = styled.div`
  position: absolute;
  font-family:
    'Inter',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    sans-serif;
  font-size: 32px;
  font-weight: 600;
  color: #1f2937;
`;

/**
 * Record Locked Modal
 *
 * Shows a modal when a user tries to access a record that's currently locked by another user.
 * Matches UI/UX design specifications from ABMS-299.
 *
 * Design features:
 * - Title: "Page locked for editing"
 * - Icon: Material Icon "edit_off" (pencil with diagonal slash)
 * - Message: Explains record is being edited and editing is temporarily disabled
 * - Close button: X in top right corner
 * - Clean, minimal design matching session timeout modal
 *
 * @example
 * ```tsx
 * <RecordLockedModal
 *   visible={!canEdit && lockInfo?.isLocked}
 *   lockedBy={lockInfo?.lockedBy}
 *   onClose={handleClose}
 * />
 * ```
 */
export const RecordLockedModal: React.FC<RecordLockedModalProps> = ({
  visible,
  lockedBy,
  expiresAt,
  onClose,
}) => {
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [totalTime, setTotalTime] = useState<number>(0);

  // Reset totalTime when modal closes so it recalculates on next open
  useEffect(() => {
    if (!visible) {
      setTotalTime(0);
    }
  }, [visible]);

  useEffect(() => {
    if (!visible || !expiresAt) {
      return;
    }

    const calculateTimeRemaining = () => {
      const now = Date.now();
      const expiryTime = new Date(expiresAt).getTime();
      const remaining = Math.max(0, Math.floor((expiryTime - now) / 1000));
      return remaining;
    };

    // Initialize time remaining
    const initial = calculateTimeRemaining();
    setTimeRemaining(initial);

    // Set total time to initial value (this represents the full duration from when modal opened)
    // This allows progress bar to fill from current position to 100%
    if (totalTime === 0) {
      setTotalTime(initial);
    }

    // Update countdown every second
    const interval = setInterval(() => {
      const remaining = calculateTimeRemaining();
      setTimeRemaining(remaining);

      if (remaining <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [visible, expiresAt, totalTime]);

  const formatTime = (seconds: number): string => {
    if (seconds < 60) {
      return `${seconds}s`;
    }

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    if (hours > 0) {
      return minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
    }

    return `${minutes}m`;
  };

  // Progress fills from 0% to 100% as time counts down (100% when timeRemaining = 0)
  const progressPercent =
    totalTime > 0 ? ((totalTime - timeRemaining) / totalTime) * 100 : 0;

  return (
    <StyledModal
      open={visible}
      title='Page locked for editing'
      closable={true}
      closeIcon={<CloseOutlined />}
      onCancel={onClose}
      maskClosable={true}
      keyboard={true}
      footer={null}
      width={580}
      centered
    >
      <ContentWrapper>
        {timeRemaining <= 60 ? (
          // Show circular progress timer when 60 seconds or less
          <TimerWrapper>
            <Progress
              type='circle'
              percent={progressPercent}
              strokeColor='#3b82f6'
              trailColor='#e5e7eb'
              strokeWidth={6}
              width={120}
              showInfo={false}
            />
            <TimerText>{formatTime(timeRemaining)}</TimerText>
          </TimerWrapper>
        ) : (
          // Show lock icon when more than 60 seconds
          <IconWrapper>
            <MaterialIcon
              name='edit_off'
              $css={`
                font-size: 48px !important;
                width: 48px !important;
                height: 48px !important;
                font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 48 !important;
                color: #6b7280 !important;
              `}
            />
          </IconWrapper>
        )}

        <MessageText>
          This page is currently being edited by another user. Editing is
          temporarily disabled until their session ends.
        </MessageText>
      </ContentWrapper>
    </StyledModal>
  );
};

export default RecordLockedModal;
