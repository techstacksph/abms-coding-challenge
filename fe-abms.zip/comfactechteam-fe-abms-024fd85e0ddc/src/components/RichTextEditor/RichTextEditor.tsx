import React, { ReactNode, useMemo, useRef } from 'react';
import { renderToString } from 'react-dom/server';
import ReactQuill, { Quill, ReactQuillProps } from 'react-quill';
import 'react-quill/dist/quill.snow.css';

import { GoogleIcon, Button, MaterialIcon, Divider } from '@/styled-components';
import { styled } from 'styled-components';

import { Box, Stack } from '@mui/material';

import './RichTextEditor.css';

// Remove global quillObj variable
// let quillObj: ReactQuill;

// Add this before your component definition
// Register formats with Quill
const Font = ReactQuill.Quill.import('formats/font');
Font.whitelist = [
  'arial',
  'helvetica',
  'times-new-roman',
  'courier-new',
  'georgia',
  'trebuchet-ms',
  'verdana',
  'montserrat',
  'antonio',
  'manrope',
];
ReactQuill.Quill.register(Font, true);

// Set default font to Manrope
const DefaultFontClass = Quill.import('attributors/class/font');
DefaultFontClass.whitelist = Font.whitelist;
Quill.register(DefaultFontClass, true);

// Set Manrope as the default font

// Make imageHandler accept quillRef as parameter
const createImageHandler =
  (quillRef: React.MutableRefObject<ReactQuill>) => () => {
    const input = document.createElement('input');

    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'image/*');
    input.click();

    input.onchange = async () => {
      const file: File = input.files[0];
      //const size = file.size;

      // IMAGE ATTACHMENT VALIDATION (SHOULD BE LESS THAN 512KB)
      // UNCOMMENT IF STATEMENT FOR FUTURE FEA
      //if((size/1000) <= 512) {
      const reader = new FileReader();
      reader.onload = function (e) {
        const range = quillRef.current?.getEditorSelection();
        quillRef.current
          ?.getEditor()
          ?.insertEmbed(range.index, 'image', e.target.result);
      };
      reader.readAsDataURL(file);
      //}
    };
  };

/*
 * Quill modules to attach to editor
 * See http://quilljs.com/docs/modules/ for complete options
 */
const createModules = (
  toolbarId: string,
  quillRef: React.MutableRefObject<ReactQuill>
) => ({
  toolbar: {
    container: `#${toolbarId}`,
    handlers: {
      image: createImageHandler(quillRef),
    },
    clipboard: {
      matchVisual: false,
    },
  },
});

const CustomToolbar = ({
  displaytoolbar = true,
  isview = false,
  customFontSize,
  toolbarId,
}: {
  displaytoolbar?: boolean;
  isview?: boolean;
  customFontSize?: string;
  toolbarId: string;
}) => {
  return (
    <StyledCustomToolbarContainer
      id={toolbarId}
      direction='row'
      alignItems='center'
      spacing={0.5}
      displaytoolbar={displaytoolbar}
      isview={isview}
      customFontSize={customFontSize}
    >
      <select
        className='ql-font'
        defaultValue={'manrope'}
        onChange={e => e.persist()}
      >
        <option value='arial'>Arial</option>
        <option value='helvetica'>Helvetica</option>
        <option value='times-new-roman'>Times New Roman</option>
        <option value='courier-new'>Courier New</option>
        <option value='georgia'>Georgia</option>
        <option value='trebuchet-ms'>Trebuchet MS</option>
        <option value='verdana'>Verdana</option>
        <option value='montserrat'>Montserrat</option>
        <option value='antonio'>Antonio</option>
        <option value='manrope'>Manrope</option>
      </select>
      <select
        className='ql-header'
        defaultValue={''}
        onChange={e => e.persist()}
      >
        <option value='1' />
        <option value='2' />
        <option selected />
      </select>

      <Stack direction='row' spacing={0.5}>
        <button className='ql-bold custom-toolbar-button'>
          <MaterialIcon name='format_bold' $css='color: var(--icon-3)' />
        </button>
        <button className='ql-italic custom-toolbar-button'>
          <MaterialIcon name='format_italic' $css='color: var(--icon-3)' />
        </button>
        <button className='ql-underline custom-toolbar-button'>
          <MaterialIcon name='format_underlined' $css='color: var(--icon-3)' />
        </button>
      </Stack>
      <Divider type='vertical' $css='height: 24px;' />
      <Stack direction='row' spacing={0.5}>
        <select
          className='ql-color custom-toolbar-select'
          defaultValue=''
          onChange={e => e.persist()}
        >
          <option value='red'>Red</option>
          <option value='green'>Green</option>
          <option value='blue'>Blue</option>
          <option value='black'>Black</option>
        </select>
        <select
          className='ql-background custom-toolbar-select'
          defaultValue=''
          onChange={e => e.persist()}
        >
          <option value='yellow'>Yellow</option>
          <option value='lightblue'>Light Blue</option>
          <option value='lightgreen'>Light Green</option>
          <option value='pink'>Pink</option>
          <option value='white'>White</option>
        </select>
      </Stack>
      <Divider type='vertical' $css='height: 24px;' />
      <Stack direction='row' spacing={0.5}>
        <button className='ql-list custom-toolbar-button' value='bullet'>
          <MaterialIcon
            name='format_list_bulleted'
            $css='color: var(--icon-3)'
          />
        </button>
        <button className='ql-list custom-toolbar-button' value='ordered'>
          <MaterialIcon
            name='format_list_numbered'
            $css='color: var(--icon-3)'
          />
        </button>
      </Stack>

      <Divider type='vertical' $css='height: 24px;' />
      <Stack direction='row' spacing={0.5}>
        <button className='ql-image custom-toolbar-button'>
          <MaterialIcon name='photo' $css='color: var(--icon-3)' />
        </button>
        <button className='ql-link custom-toolbar-button'>
          <MaterialIcon name='link' $css='color: var(--icon-3)' />
        </button>
      </Stack>
      <Divider type='vertical' $css='height: 24px;' />
      <Stack direction='row'>
        <button className='ql-clean custom-toolbar-button'>
          <MaterialIcon name='format_clear' $css='color: var(--icon-3)' />
        </button>
      </Stack>
    </StyledCustomToolbarContainer>
  );
};

const StyledRichText = styled(ReactQuill)<{
  displaytoolbar?: boolean;
  height?: number | string;
  isview?: boolean;
  $css?: string;
  customFontSize?: string;
}>`
  .ql-editor {
    height: ${({ height }) =>
      height ? (typeof height == 'string' ? height : `${height}px;`) : '400px'};
    word-break: break-all;
    ${({ isview }) =>
      isview
        ? `
          padding: 0;
          max-height: 600px !important;
        `
        : ''}
  }

  ${({ customFontSize }) =>
    customFontSize
      ? `
    .ql-editor p {
      font-size: ${customFontSize} !important;
    }
       .ql-editor ul {
      font-size: ${customFontSize} !important;
    }
  `
      : ''}

  .ql-container {
    font-family: inherit;
    border-bottom: 0px;

    ${({ displaytoolbar }) =>
      !displaytoolbar
        ? `
          border-top-right-radius: 8px;
          border-top-left-radius: 8px;
        `
        : ''}

    ${({ isview }) =>
      isview
        ? `
          border: transparent;
        `
        : ''}
  }

  .ql-container a {
    color: #3137fd;
  }

  .ql-tooltip.ql-editing {
    z-index: 1;
  }

  ${({ $css }) => $css}
`;

const StyledCustomToolbarContainer = styled(Stack)<{
  displaytoolbar?: boolean;
  isview?: boolean;
  customFontSize?: string;
}>`
  ${({ displaytoolbar, isview }) =>
    !displaytoolbar || isview ? 'display: none !important;' : ''}

  & {
    display: flex;
    padding: 4px !important;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    border-bottom: 0px !important;
    flex-wrap: wrap;
    gap: 4px;
    row-gap: 6px;
  }

  .ql-header span.ql-picker-label,
  .ql-font span.ql-picker-label {
    border: 0;
    font-size: 14px;
    font-weight: 400;
    font-family: 'Hanken Grotesk';
    color: var(--rich-text-stroke-color);
  }

  .ql- .custom-toolbar-button {
    width: 40px !important;
    height: 40px !important;
    padding: 8px !important;
  }

  .custom-toolbar-select {
    width: 40px !important;
    height: 40px !important;
    color: #fff;
    padding: 5px 3px 0px 3px !important;
    margin-top: 5px;
  }

  .custom-toolbar-button > span:hover,
  .custom-toolbar-button.ql-active > span,
  .ql-header span.ql-picker-label:hover,
  .ql-header span.ql-picker-label.ql-active,
  .ql-header.ql-expanded > .ql-picker-options > .ql-picker-item.ql-selected,
  .ql-header.ql-expanded > .ql-picker-options > .ql-picker-item:hover,
  .ql-font span.ql-picker-label:hover,
  .ql-font span.ql-picker-label.ql-active,
  .ql-font.ql-expanded > .ql-picker-options > .ql-picker-item.ql-selected,
  .ql-font.ql-expanded > .ql-picker-options > .ql-picker-item:hover,
  /* Add color and background picker label hover styles */
  .ql-color-picker span.ql-picker-label:hover span,
  .ql-color-picker span.ql-picker-label.ql-active span,
  .ql-background-picker span.ql-picker-label:hover span,
  .ql-background-picker span.ql-picker-label.ql-active span {
    color: var(--rich-text-hover-color);
  }

  .ql-header span.ql-picker-label .ql-stroke,
  .ql-font span.ql-picker-label .ql-stroke {
    stroke: var(--rich-text-stroke-color);
  }

  .ql-header span.ql-picker-label:hover .ql-stroke,
  .ql-header span.ql-picker-label.ql-active .ql-stroke,
  .ql-font span.ql-picker-label:hover .ql-stroke,
  .ql-font span.ql-picker-label.ql-active .ql-stroke {
    stroke: var(--icon-3);
    font-size: 22px;
    margin: 0;
  }

  /* Add specific styles for color and background picker icons */
  .ql-color-picker span.ql-picker-label span,
  .ql-background-picker span.ql-picker-label span {
    color: var(--icon-3);
    font-size: 22px;
    margin: 0;
  }

  .ql-color-picker span.ql-picker-label:hover span,
  .ql-color-picker span.ql-picker-label.ql-active span,
  .ql-background-picker span.ql-picker-label:hover span,
  .ql-background-picker span.ql-picker-label.ql-active span {
    color: var(--rich-text-hover-color);
  }

  /* Style the picker items for color and background */
  .ql-color-picker .ql-picker-options .ql-picker-item:hover,
  .ql-color-picker .ql-picker-options .ql-picker-item.ql-selected,
  .ql-background-picker .ql-picker-options .ql-picker-item:hover,
  .ql-background-picker .ql-picker-options .ql-picker-item.ql-selected {
    border: 1px solid var(--rich-text-hover-color);
  }
`;

const RichText = (
  props: ReactQuillProps & {
    footerBtns?: ReactNode;
    enableClear?: boolean;
    hasFooterBorder?: boolean;
    quillInstance?: (quill: ReactQuill) => any;
    displaytoolbar?: boolean;
    height?: number | string;
    $css?: string;
    isview?: boolean;
    customFontSize?: string;
    displayfooter?: boolean;
    $clearCSS?: string;
    showFooter?: boolean;
  }
) => {
  // Create unique toolbar ID for each instance
  const toolbarId = useMemo(
    () => `custom-toolbar-${Math.random().toString(36).substr(2, 9)}`,
    []
  );

  // Create ref for this specific instance
  const quillRef = useRef<ReactQuill>(null);

  // Create modules with unique toolbar ID
  const modules = useMemo(
    () => createModules(toolbarId, quillRef),
    [toolbarId]
  );

  const icons = Quill.import('ui/icons');
  icons['bold'] = renderToString(
    <MaterialIcon name='format_bold' $css='color: var(--icon-3)' />
  );
  icons['italic'] = renderToString(
    <MaterialIcon name='format_italic' $css='color: var(--icon-3)' />
  );
  icons['underline'] = renderToString(
    <MaterialIcon name='format_underlined' $css='color: var(--icon-3)' />
  );
  icons['list'].bullet = renderToString(
    <MaterialIcon name='format_list_bulleted' $css='color: var(--icon-3)' />
  );
  icons['list'].ordered = renderToString(
    <MaterialIcon name='format_list_numbered' $css='color: var(--icon-3)' />
  );
  icons['image'] = renderToString(
    <MaterialIcon name='photo' $css='color: var(--icon-3)' />
  );
  icons['link'] = renderToString(
    <MaterialIcon name='link' $css='color: var(--icon-3)' />
  );
  icons['clean'] = renderToString(
    <MaterialIcon name='format_clear' $css='color: var(--icon-3)' />
  );
  icons['background'] = renderToString(
    <GoogleIcon name='format_ink_highlighter' $css='color: var(--icon-3)' />
  );
  icons['color'] = renderToString(
    <GoogleIcon name='format_color_text' $css='color: var(--icon-3)' />
  );

  const {
    footerBtns,
    enableClear,
    hasFooterBorder,
    quillInstance,
    displaytoolbar,
    height,
    isview,
    displayfooter = true,
    $clearCSS,
    showFooter = true,
  } = props;

  const onClearClick = () => {
    quillRef.current
      ?.getEditor()
      .deleteText(0, quillRef.current?.getEditor().getLength());
  };

  const footerContainerSxProps = {
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderTop: !hasFooterBorder ? 0 : '1px solid #D3D5D9',
  };

  if (isview || !displayfooter) {
    Object.assign(footerContainerSxProps, {
      border: 'transparent',
    });
  }

  return (
    <Box width={'100%'}>
      <CustomToolbar
        displaytoolbar={displaytoolbar}
        isview={isview}
        customFontSize={props.customFontSize}
        toolbarId={toolbarId}
      />
      <StyledRichText
        theme='snow'
        modules={modules}
        displaytoolbar={displaytoolbar ?? true}
        height={height}
        customFontSize={props.customFontSize}
        ref={el => {
          quillRef.current = el;
          if (quillInstance) {
            quillInstance(el);
          }
        }}
        readOnly={isview ?? false}
        defaultValue={'<p class="ql-font-manrope"></p>'}
        {...props}
      />
      {showFooter && (
        <Stack
          className='richtext-footer-container'
          flexDirection='row'
          alignItems='center'
          padding={1}
          border='1px solid #D3D5D9'
          justifyContent={enableClear ? 'space-between' : 'flex-end'}
          sx={footerContainerSxProps}
        >
          {enableClear && (
            <Button
              ghost
              $css={`width: 120px; ${$clearCSS}`}
              onClick={onClearClick}
            >
              Clear
            </Button>
          )}
          {footerBtns}
        </Stack>
      )}
    </Box>
  );
};

export default RichText;
