import React from 'react';

import { Space } from '@/styled-components';
import { styled } from 'styled-components';

import { Tabs as AntTabs, TabsProps, Col } from 'antd';

const StyledTabs = styled(AntTabs)<{ $css?: string }>`
  & [class$='-tabs-nav']::before {
    border-bottom: none !important;
  }

  & [class$='-tabs-nav-list'] {
    background: #f4f4f6;
    border-radius: 8px;
  }

  & [class$='-tabs-nav-list'] div[class$='-tabs-tab'] {
    border-radius: 4px !important;
    padding: 8px;
    margin: 8px;
    border: 1px solid #f4f4f6 !important;
  }

  & [class$='-tabs-nav-list'] div[class$='-tabs-tab-active'] {
    border-radius: 4px !important;
    padding: 8px;
    margin: 8px;
    border: 1px solid white !important;
    background: white;
  }

  & [class$='-tabs-content-holder'] {
    padding-top: 0px;
  }

  ${({ $css }) => $css}
`;

const Tabs = (
  props: TabsProps & { $css?: string; tabBarWidth?: string | number }
) => {
  return (
    <Col span={24}>
      <StyledTabs
        type={'card'}
        tabBarStyle={{
          fontWeight: 600,
          fontSize: 14,
          width: props?.tabBarWidth ? props?.tabBarWidth : '100%',
          zIndex: 1,
          lineHeight: '20px',
        }}
        {...props}
        items={
          props.items &&
          props.items
            .filter(a => String(a?.className).indexOf('hidden-tab') == -1)
            .map(i => {
              return {
                ...i,
                children: (
                  <Space
                    size={20}
                    direction='vertical'
                    $css={`
                      background-color: var(--background-1); 
                      width: -webkit-fill-available;
                      width: -moz-available;
                    `}
                  >
                    {i.children}
                  </Space>
                ),
              };
            })
        }
        $css={props.$css}
      />
    </Col>
  );
};

export default Tabs;
