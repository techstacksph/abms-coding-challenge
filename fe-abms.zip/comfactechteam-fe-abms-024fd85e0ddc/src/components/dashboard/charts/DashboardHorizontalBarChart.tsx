import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency, formatCurrencyK } from '@/utils/helper.utils';
import {
  chartTypography,
  chartColors,
  chartCard,
  chartTitleCss,
  chartAxisLine,
  chartSplitLine,
  chartNameGap,
} from './chartTheme';

export interface DashboardHorizontalBarChartData {
  name: string;
  value: number;
}

export interface DashboardHorizontalBarChartProps {
  title?: string;
  data: DashboardHorizontalBarChartData[];
  height?: number;
  width?: string;
  color?: string;
  xAxisLabel?: string;
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  barWidth?: number;
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const DashboardHorizontalBarChart: React.FC<
  DashboardHorizontalBarChartProps
> = ({
  title,
  data,
  height = 300,
  width = '100%',
  color = chartColors.secondary,
  xAxisLabel = '',
  cardPadding = chartCard.padding,
  cardStyle = {},
  barWidth = 20,
  option: optionOverride = {},
}) => {
  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
      },
      formatter: (params: any) => {
        const { name, value } = params[0];
        return `${name}: ${formatCurrency(value)}`;
      },
    },
    grid: {
      left: 10,
      right: 30,
      bottom: 40,
      top: 20,
      containLabel: true,
    },
    xAxis: {
      type: 'value',
      name: xAxisLabel,
      nameLocation: 'middle',
      nameGap: chartNameGap.xAxis,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      inverse: false,
      axisLine: {
        show: false,
      },
      axisLabel: {
        ...chartTypography.axisLabel,
        formatter: (value: number) => formatCurrencyK(value),
      },
      splitLine: {
        lineStyle: {
          ...chartSplitLine.lineStyle,
          type: 'dashed',
        },
      },
    },
    yAxis: {
      type: 'category',
      data: data.map(item => item.name),
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
      },
      axisTick: {
        show: false,
      },
    },
    series: [
      {
        type: 'bar',
        data: data.map(item => item.value),
        barWidth,
        itemStyle: {
          color,
          borderRadius: [4, 4, 4, 4],
        },
        label: {
          show: true,
          position: 'insideRight',
          formatter: (params: any) => formatCurrency(params.value),
          ...chartTypography.seriesLabel,
          color: '#fff',
        },
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    grid: { ...defaultOption.grid, ...optionOverride.grid },
    xAxis: {
      ...defaultOption.xAxis,
      ...optionOverride.xAxis,
      axisLabel: {
        ...defaultOption.xAxis.axisLabel,
        ...optionOverride.xAxis?.axisLabel,
      },
    },
    yAxis: {
      ...defaultOption.yAxis,
      ...optionOverride.yAxis,
      axisLabel: {
        ...defaultOption.yAxis.axisLabel,
        ...optionOverride.yAxis?.axisLabel,
      },
    },
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardHorizontalBarChart;
