import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import {
  chartTypography,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
} from './chartTheme';

export interface DashboardColumnStackSeries {
  /** Series name displayed in legend and tooltip */
  name: string;
  /** Data values for this series */
  data: number[];
  /** Bar color */
  color?: string;
}

export interface DashboardColumnStackProps {
  /** Chart title */
  title?: string;
  /** Categories for X-axis */
  categories: string[];
  /** Array of series to stack */
  series: DashboardColumnStackSeries[];
  /** Chart height in pixels */
  height?: number;
  /** Chart width */
  width?: string;
  /** Y-axis label */
  yAxisLabel?: string;
  /** X-axis label */
  xAxisLabel?: string;
  /** Bar width in pixels */
  barWidth?: number;
  /** Rotate X-axis labels (degrees) */
  xAxisLabelRotate?: number;
  /** Custom tooltip value formatter */
  tooltipFormatter?: (value: number) => string;
  /** Custom tooltip suffix (e.g., "invoices", "items") */
  tooltipSuffix?: string;
  /** Show legend */
  showLegend?: boolean;
  /** Legend position */
  legendPosition?: 'top' | 'bottom';
  /** Default colors for series (if not specified per series) */
  colors?: string[];
  /** Card padding */
  cardPadding?: string;
  /** Custom card styles */
  cardStyle?: React.CSSProperties;
  /** ECharts option override for advanced customization */
  option?: Record<string, any>;
}

const defaultColors = [
  '#4285F4', // Blue
  '#EA4335', // Red
  '#FBBC04', // Yellow
  '#34A853', // Green
  '#9334E6', // Purple
  '#FF6D01', // Orange
];

const DashboardColumnStack: React.FC<DashboardColumnStackProps> = ({
  title,
  categories,
  series,
  height = 300,
  width = '100%',
  yAxisLabel = '',
  xAxisLabel = '',
  barWidth = 40,
  xAxisLabelRotate = 0,
  tooltipFormatter,
  tooltipSuffix = '',
  showLegend = true,
  legendPosition = 'bottom',
  colors = defaultColors,
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  // Build series configuration
  const seriesConfig = series.map((s, index) => ({
    name: s.name,
    type: 'bar',
    stack: 'total',
    data: s.data,
    barWidth,
    itemStyle: {
      color: s.color || colors[index % colors.length],
      // Add border radius to the top series (last in array)
      ...(index === series.length - 1 ? { borderRadius: [4, 4, 0, 0] } : {}),
    },
  }));

  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
      },
      formatter: (params: any) => {
        let result = `<strong>${params[0].name}</strong><br/>`;
        let total = 0;
        params.forEach((param: any) => {
          const value = tooltipFormatter
            ? tooltipFormatter(param.value)
            : param.value;
          const suffix = tooltipSuffix ? ` ${tooltipSuffix}` : '';
          result += `${param.marker} ${param.seriesName}: ${value}${suffix}<br/>`;
          total += param.value;
        });
        if (params.length > 1) {
          const totalValue = tooltipFormatter ? tooltipFormatter(total) : total;
          const suffix = tooltipSuffix ? ` ${tooltipSuffix}` : '';
          result += `<strong>Total: ${totalValue}${suffix}</strong>`;
        }
        return result;
      },
    },
    legend: showLegend
      ? {
          data: series.map(s => s.name),
          [legendPosition === 'top' ? 'top' : 'bottom']: 0,
          left: 'center',
          textStyle: {
            ...chartTypography.axisLabel,
          },
        }
      : undefined,
    grid: {
      ...chartGrid,
      bottom: showLegend && legendPosition === 'bottom' ? 60 : 30,
      top: showLegend && legendPosition === 'top' ? 60 : '10%',
    },
    xAxis: {
      type: 'category',
      data: categories,
      name: xAxisLabel,
      nameLocation: 'middle',
      nameGap: 35,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
        rotate: xAxisLabelRotate,
      },
      axisTick: {
        show: false,
      },
    },
    yAxis: {
      type: 'value',
      name: yAxisLabel,
      nameLocation: 'middle',
      nameGap: 50,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      axisLine: {
        show: false,
      },
      axisLabel: {
        ...chartTypography.axisLabel,
      },
      splitLine: chartSplitLine,
    },
    series: seriesConfig,
  };

  // Merge with option override (deep merge for nested objects)
  const option = {
    ...defaultOption,
    ...optionOverride,
    legend: showLegend
      ? {
          ...defaultOption.legend,
          ...optionOverride.legend,
        }
      : undefined,
    grid: {
      ...defaultOption.grid,
      ...optionOverride.grid,
    },
    xAxis: {
      ...defaultOption.xAxis,
      ...optionOverride.xAxis,
    },
    yAxis: {
      ...defaultOption.yAxis,
      ...optionOverride.yAxis,
    },
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
            autoResize={true}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardColumnStack;
