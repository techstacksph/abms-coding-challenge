import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency, formatCurrencyK } from '@/utils/helper.utils';
import {
  chartTypography,
  chartColors,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
  chartNameGap,
} from './chartTheme';

export interface DashboardLineChartData {
  name: string;
  value: number;
}

export interface DashboardLineChartProps {
  title?: string;
  data: DashboardLineChartData[];
  height?: number;
  width?: string;
  color?: string;
  showArea?: boolean;
  smooth?: boolean;
  yAxisLabel?: string;
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const DashboardLineChart: React.FC<DashboardLineChartProps> = ({
  title,
  data,
  height = 300,
  width = '100%',
  color = chartColors.primary,
  showArea = false,
  smooth = false,
  yAxisLabel = '',
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const { name, value } = params[0];
        return `${name}: ${formatCurrency(value)}`;
      },
    },
    grid: {
      ...chartGrid,
    },
    xAxis: {
      type: 'category',
      data: data.map(item => item.name),
      boundaryGap: false,
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: true,
        ...chartSplitLine,
      },
    },
    yAxis: {
      type: 'value',
      name: yAxisLabel,
      nameLocation: 'middle',
      nameGap: chartNameGap.yAxis,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      axisLine: {
        show: false,
      },
      axisLabel: {
        ...chartTypography.axisLabel,
        formatter: (value: number) => formatCurrencyK(value),
      },
      splitLine: chartSplitLine,
    },
    series: [
      {
        type: 'line',
        data: data.map(item => item.value),
        smooth,
        symbol: 'circle',
        symbolSize: 8,
        lineStyle: {
          color,
          width: 2,
        },
        itemStyle: {
          color,
          borderColor: color,
          borderWidth: 0,
        },
        areaStyle: showArea
          ? {
              color: {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  { offset: 0, color: `${color}33` },
                  { offset: 1, color: `${color}00` },
                ],
              },
            }
          : undefined,
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    grid: { ...defaultOption.grid, ...optionOverride.grid },
    xAxis: { ...defaultOption.xAxis, ...optionOverride.xAxis },
    yAxis: { ...defaultOption.yAxis, ...optionOverride.yAxis },
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
            autoResize={true}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardLineChart;
