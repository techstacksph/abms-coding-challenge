/**
 * Shared chart theme configuration
 * All chart components should use these defaults for consistent styling
 */

// Typography styles
export const chartTypography = {
  // Used for axis names/labels (e.g., "Costing Amount ($)")
  axisName: {
    color: '#686D78',
    fontFamily: 'Hanken Grotesk',
    fontSize: 14,
    fontWeight: 400,
    lineHeight: 20,
  },
  // Used for axis tick labels (e.g., "$80,000")
  axisLabel: {
    color: '#717A89',
    fontFamily: 'Manrope',
    fontSize: 12,
    fontWeight: 400,
    lineHeight: 18,
  },
  // Used for chart card title
  title: {
    color: '#090A0B',
    fontFamily: 'Hanken Grotesk',
    fontSize: 16,
    fontWeight: 600,
    lineHeight: 24,
  },
  // Used for gauge percentage display
  gaugeValue: {
    color: '#090A0B',
    fontFamily: 'Hanken Grotesk',
    fontSize: 24,
    fontWeight: 700,
  },
  // Used for gauge detail text
  gaugeDetail: {
    color: '#686D78',
    fontFamily: 'Manrope',
    fontSize: 14,
  },
  // Used for bar/series labels
  seriesLabel: {
    color: '#717A89',
    fontFamily: 'Manrope',
    fontSize: 11,
  },
};

// Color palette
export const chartColors = {
  primary: '#3137FD',
  secondary: '#4285F4',
  background: '#E9EAEC',
  line: '#E9EAEC',
  text: {
    primary: '#090A0B',
    secondary: '#686D78',
    muted: '#717A89',
  },
};

// Grid defaults
export const chartGrid = {
  left: 80,
  right: 10,
  bottom: 0,
  top: '10%',
  containLabel: true,
};

// Axis line styles
export const chartAxisLine = {
  lineStyle: {
    color: chartColors.line,
  },
};

// Split line styles
export const chartSplitLine = {
  lineStyle: {
    color: chartColors.line,
    type: 'solid' as const,
  },
};

// Card styles
export const chartCard = {
  padding: '12px 20px',
  background: 'white',
  border: `1px solid ${chartColors.line}`,
  borderRadius: '12px',
  boxShadow: '0 1px 3px 0 rgb(0 0 0 / 0.1)',
};

// Title CSS for card headers
export const chartTitleCss = `
color: var(--Colors-text-primary, ${chartTypography.title.color});
font-family: "${chartTypography.title.fontFamily}";
font-size: ${chartTypography.title.fontSize}px;
font-style: normal;
font-weight: ${chartTypography.title.fontWeight};
line-height: ${chartTypography.title.lineHeight}px;
`;

// Default tooltip config
export const chartTooltip = {
  trigger: 'axis' as const,
  axisPointer: {
    type: 'shadow' as const,
  },
};

// Name gap defaults for axis labels
export const chartNameGap = {
  yAxis: 130,
  xAxis: 50,
};

// Types for customization
export interface ChartAxisLabelStyle {
  color?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: number;
  lineHeight?: number;
}

export interface ChartGridConfig {
  left?: number | string;
  right?: number | string;
  bottom?: number | string;
  top?: number | string;
  containLabel?: boolean;
}

export interface ChartTooltipConfig {
  trigger?: 'axis' | 'item' | 'none';
  formatter?: (params: any) => string;
}
