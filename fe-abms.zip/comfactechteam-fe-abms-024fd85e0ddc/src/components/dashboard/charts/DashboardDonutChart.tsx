import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';

const titleCss = `
color: var(--Colors-text-primary, #090A0B);
font-family: "Hanken Grotesk";
font-size: 16px;
font-style: normal;
font-weight: 600;
line-height: 24px;
`;

export interface DashboardDonutChartData {
  name: string;
  value: number;
  color?: string;
}

export interface DashboardDonutChartProps {
  title?: string;
  data: DashboardDonutChartData[];
  height?: number;
  width?: string;
  colors?: string[];
  innerRadius?: string;
  outerRadius?: string;
  showLegend?: boolean;
  legendPosition?: 'top' | 'bottom' | 'left' | 'right';
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
}

const defaultColors = ['#FDB61C', '#A78BFA', '#7793FF', '#E76B36'];

const DashboardDonutChart: React.FC<DashboardDonutChartProps> = ({
  title,
  data,
  height = 300,
  width = '100%',
  colors = defaultColors,
  innerRadius = '60%',
  outerRadius = '80%',
  showLegend = true,
  legendPosition = 'top',
  cardPadding = '12px 20px',
  cardStyle = {},
}) => {
  const legendOrient =
    legendPosition === 'top' || legendPosition === 'bottom'
      ? 'horizontal'
      : 'vertical';

  const option = {
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        const { name, value, percent } = params;
        return `${name}: ${value} (${percent}%)`;
      },
    },
    legend: showLegend
      ? {
          orient: legendOrient,
          [legendPosition]:
            legendPosition === 'top'
              ? 0
              : legendPosition === 'bottom'
                ? 0
                : 'center',
          ...(legendPosition === 'left' || legendPosition === 'right'
            ? { top: 'center' }
            : {}),
          itemWidth: 32,
          itemHeight: 8,
          itemGap: 20,
          textStyle: {
            color: '#686D78',
            fontSize: 12,
          },
          icon: 'rect',
        }
      : false,
    color: colors,
    series: [
      {
        type: 'pie',
        radius: [innerRadius, outerRadius],
        center: ['50%', '55%'],
        avoidLabelOverlap: false,
        label: {
          show: false,
        },
        labelLine: {
          show: false,
        },
        data: data.map((item, index) => ({
          name: item.name,
          value: item.value,
          itemStyle: {
            color: item.color || colors[index % colors.length],
          },
        })),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.2)',
          },
        },
      },
    ],
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: white;
        border: 1px solid #E5E7EB;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={titleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardDonutChart;
