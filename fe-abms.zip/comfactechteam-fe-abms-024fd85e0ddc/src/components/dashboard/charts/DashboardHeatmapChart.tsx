import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { chartTypography, chartCard, chartTitleCss } from './chartTheme';

export interface DashboardHeatmapLegendItem {
  /** Legend item label */
  label: string;
  /** Legend item color */
  color: string;
}

export interface DashboardHeatmapChartProps {
  /** Chart title */
  title?: string;
  /** X-axis categories */
  xCategories: string[];
  /** Y-axis categories */
  yCategories: string[];
  /** Heatmap data as [xIndex, yIndex, value][] */
  data: number[][];
  /** Chart height in pixels */
  height?: number;
  /** Chart width */
  width?: string;
  /** Min value for color scale */
  minValue?: number;
  /** Max value for color scale */
  maxValue?: number;
  /** Colors for visual map gradient [low, mid, high] or custom array */
  colors?: string[];
  /** Show value labels inside cells */
  showLabels?: boolean;
  /** Custom tooltip formatter */
  tooltipFormatter?: (params: {
    xCategory: string;
    yCategory: string;
    value: number;
  }) => string;
  /** Custom legend items (displayed above chart) */
  legendItems?: DashboardHeatmapLegendItem[];
  /** Card padding */
  cardPadding?: string;
  /** Custom card styles */
  cardStyle?: React.CSSProperties;
  /** ECharts option override for advanced customization */
  option?: Record<string, any>;
}

const defaultColors = ['#FEE2E2', '#FEF3C7', '#D1FAE5']; // Light red, light yellow, light green

const DashboardHeatmapChart: React.FC<DashboardHeatmapChartProps> = ({
  title,
  xCategories,
  yCategories,
  data,
  height = 300,
  width = '100%',
  minValue = 0,
  maxValue = 100,
  colors = defaultColors,
  showLabels = true,
  tooltipFormatter,
  legendItems,
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  const defaultOption = {
    tooltip: {
      position: 'top',
      formatter: (params: any) => {
        const xCategory = xCategories[params.data[0]];
        const yCategory = yCategories[params.data[1]];
        const value = params.data[2];

        if (tooltipFormatter) {
          return tooltipFormatter({ xCategory, yCategory, value });
        }

        return `${xCategory}<br/>${yCategory}: ${value}`;
      },
    },
    grid: {
      left: 10,
      right: 20,
      top: 30,
      bottom: 60,
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: xCategories,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        ...chartTypography.axisLabel,
        interval: 0,
      },
      splitLine: { show: false },
    },
    yAxis: {
      type: 'category',
      data: yCategories,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        ...chartTypography.axisLabel,
      },
      splitLine: { show: false },
    },
    visualMap: {
      show: false,
      min: minValue,
      max: maxValue,
      inRange: {
        color: colors,
      },
    },
    series: [
      {
        name: 'Heatmap',
        type: 'heatmap',
        data,
        label: {
          show: showLabels,
          fontSize: 12,
          color: '#090A0B',
        },
        itemStyle: {
          borderWidth: 2,
          borderColor: '#fff',
          borderRadius: 4,
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: 'rgba(0, 0, 0, 0.3)',
          },
        },
      },
    ],
  };

  // Merge with option override
  const option = {
    ...defaultOption,
    ...optionOverride,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 16px -20px' }} />
          </>
        )}
        {legendItems && legendItems.length > 0 && (
          <Stack
            direction='row'
            spacing={3}
            justifyContent='center'
            sx={{ marginBottom: '16px' }}
          >
            {legendItems.map((item, index) => (
              <Stack
                key={index}
                direction='row'
                alignItems='center'
                spacing={1}
              >
                <div
                  style={{
                    width: 16,
                    height: 16,
                    backgroundColor: item.color,
                    borderRadius: 4,
                  }}
                />
                <Text $css='font-size: 12px; color: #686D78;'>
                  {item.label}
                </Text>
              </Stack>
            ))}
          </Stack>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardHeatmapChart;
