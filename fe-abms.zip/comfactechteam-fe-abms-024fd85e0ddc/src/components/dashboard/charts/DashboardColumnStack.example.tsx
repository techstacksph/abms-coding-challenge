/**
 * DashboardColumnStack - Usage Examples
 *
 * A reusable stacked column/bar chart component for comparing multiple
 * data series stacked on top of each other.
 */

import React from 'react';
import { Grid } from '@mui/material';
import DashboardColumnStack from './DashboardColumnStack';

// =============================================================================
// EXAMPLE 1: Basic Two-Series Stack
// =============================================================================
// Simple stacked bar with two categories

export const BasicStackExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Monthly Sales by Region'
      categories={['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']}
      series={[
        {
          name: 'North',
          data: [120, 132, 101, 134, 90, 230],
          color: '#4285F4',
        },
        {
          name: 'South',
          data: [220, 182, 191, 234, 290, 330],
          color: '#34A853',
        },
      ]}
      yAxisLabel='Sales ($)'
      height={300}
    />
  );
};

// =============================================================================
// EXAMPLE 2: A/R Ageing Analysis (Finance Use Case)
// =============================================================================
// Track invoice aging buckets

export const AgeingAnalysisExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='A/R Ageing Analysis'
      categories={['0-30', '31-60', '61-90', '91 and above']}
      series={[
        {
          name: 'Current',
          data: [45, 30, 15, 8],
          color: '#4285F4',
        },
        {
          name: 'Overdue',
          data: [12, 18, 25, 35],
          color: '#EA4335',
        },
      ]}
      yAxisLabel='Count of invoices'
      tooltipSuffix='invoices'
      height={300}
      barWidth={40}
    />
  );
};

// =============================================================================
// EXAMPLE 3: Multi-Series Stack (More than 2 series)
// =============================================================================
// Multiple categories stacked together

export const MultiSeriesExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Quarterly Revenue by Product Line'
      categories={['Q1', 'Q2', 'Q3', 'Q4']}
      series={[
        {
          name: 'Product A',
          data: [320, 302, 341, 374],
          color: '#4285F4',
        },
        {
          name: 'Product B',
          data: [120, 132, 101, 134],
          color: '#34A853',
        },
        {
          name: 'Product C',
          data: [220, 182, 191, 234],
          color: '#FBBC04',
        },
        {
          name: 'Product D',
          data: [150, 212, 201, 154],
          color: '#EA4335',
        },
      ]}
      yAxisLabel='Revenue ($K)'
      tooltipFormatter={value => `$${value}K`}
      height={350}
    />
  );
};

// =============================================================================
// EXAMPLE 4: With Rotated Labels
// =============================================================================
// For long category names

export const RotatedLabelsExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Sales by Department'
      categories={[
        'Marketing',
        'Engineering',
        'Sales',
        'Customer Support',
        'Human Resources',
      ]}
      series={[
        {
          name: 'Budget',
          data: [150, 230, 180, 90, 120],
          color: '#4285F4',
        },
        {
          name: 'Actual',
          data: [140, 250, 160, 85, 130],
          color: '#34A853',
        },
      ]}
      yAxisLabel='Amount ($K)'
      xAxisLabelRotate={30}
      height={300}
    />
  );
};

// =============================================================================
// EXAMPLE 5: Legend at Top
// =============================================================================
// Position legend at top of chart

export const LegendTopExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Weekly Performance'
      categories={['Mon', 'Tue', 'Wed', 'Thu', 'Fri']}
      series={[
        {
          name: 'Completed',
          data: [25, 30, 28, 35, 22],
          color: '#34A853',
        },
        {
          name: 'Pending',
          data: [10, 8, 12, 5, 15],
          color: '#FBBC04',
        },
        {
          name: 'Overdue',
          data: [5, 2, 3, 0, 8],
          color: '#EA4335',
        },
      ]}
      yAxisLabel='Tasks'
      tooltipSuffix='tasks'
      legendPosition='top'
      height={300}
    />
  );
};

// =============================================================================
// EXAMPLE 6: Without Legend
// =============================================================================
// Hide legend for compact display

export const NoLegendExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Simple Comparison'
      categories={['A', 'B', 'C', 'D']}
      series={[
        {
          name: 'Value 1',
          data: [100, 150, 120, 180],
          color: '#4285F4',
        },
        {
          name: 'Value 2',
          data: [80, 100, 90, 120],
          color: '#EA4335',
        },
      ]}
      showLegend={false}
      height={250}
    />
  );
};

// =============================================================================
// EXAMPLE 7: Custom Colors
// =============================================================================
// Using custom color palette

export const CustomColorsExample: React.FC = () => {
  return (
    <DashboardColumnStack
      title='Status Distribution'
      categories={['Project A', 'Project B', 'Project C']}
      series={[
        { name: 'Done', data: [40, 55, 30] },
        { name: 'In Progress', data: [25, 20, 35] },
        { name: 'To Do', data: [15, 10, 20] },
      ]}
      colors={['#10B981', '#F59E0B', '#6B7280']}
      yAxisLabel='Tasks'
      height={300}
    />
  );
};

// =============================================================================
// FULL DEMO COMPONENT
// =============================================================================
// Displays all examples in a grid layout

const DashboardColumnStackDemo: React.FC = () => {
  return (
    <Grid container spacing={3} sx={{ p: 3 }}>
      <Grid item xs={12} md={6}>
        <BasicStackExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <AgeingAnalysisExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <MultiSeriesExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <RotatedLabelsExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <LegendTopExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <NoLegendExample />
      </Grid>
      <Grid item xs={12}>
        <CustomColorsExample />
      </Grid>
    </Grid>
  );
};

export default DashboardColumnStackDemo;

/**
 * PROPS REFERENCE
 * ================
 *
 * title?: string
 *   - Chart title displayed at the top
 *
 * categories: string[]
 *   - Array of category labels for X-axis
 *   - Example: ['Q1', 'Q2', 'Q3', 'Q4']
 *
 * series: DashboardColumnStackSeries[]
 *   - Array of series objects to stack
 *   - Each series has:
 *     - name: string - Display name in legend/tooltip
 *     - data: number[] - Values (must match categories length)
 *     - color?: string - Bar color (optional, uses default palette)
 *
 * height?: number (default: 300)
 *   - Chart height in pixels
 *
 * width?: string (default: '100%')
 *   - Chart width
 *
 * yAxisLabel?: string
 *   - Label for Y-axis
 *
 * xAxisLabel?: string
 *   - Label for X-axis
 *
 * barWidth?: number (default: 40)
 *   - Width of bars in pixels
 *
 * xAxisLabelRotate?: number (default: 0)
 *   - Rotation angle for X-axis labels
 *
 * tooltipFormatter?: (value: number) => string
 *   - Custom formatter for tooltip values
 *   - Example: (v) => `$${v}K`
 *
 * tooltipSuffix?: string
 *   - Suffix added to tooltip values
 *   - Example: 'invoices', 'tasks', 'items'
 *
 * showLegend?: boolean (default: true)
 *   - Show or hide legend
 *
 * legendPosition?: 'top' | 'bottom' (default: 'bottom')
 *   - Position of legend
 *
 * colors?: string[]
 *   - Default color palette for series without explicit colors
 *   - Default: ['#4285F4', '#EA4335', '#FBBC04', '#34A853', '#9334E6', '#FF6D01']
 *
 * cardPadding?: string
 *   - Custom card padding
 *
 * cardStyle?: React.CSSProperties
 *   - Custom card styles
 *
 * option?: Record<string, any>
 *   - ECharts option override for advanced customization
 */
