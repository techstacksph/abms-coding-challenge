import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { chartTypography, chartCard, chartTitleCss } from './chartTheme';

export interface DashboardPieChartData {
  name: string;
  value: number;
  color?: string;
}

export interface DashboardPieChartProps {
  /** Chart title displayed in the card header */
  title?: string;
  /** Data array with name, value, and optional color */
  data: DashboardPieChartData[];
  /** Chart height in pixels */
  height?: number;
  /** Card width */
  width?: string;
  /** Default colors if not specified in data */
  colors?: string[];
  /** Outer radius of pie (use '0%' for inner to make solid pie) */
  outerRadius?: string;
  /** Inner radius of pie (use '0%' for solid pie, higher for donut) */
  innerRadius?: string;
  /** Show legend */
  showLegend?: boolean;
  /** Legend position */
  legendPosition?: 'top' | 'top-right' | 'right' | 'bottom';
  /** Show labels with lines pointing to slices */
  showLabels?: boolean;
  /** Label formatter - 'value' shows number, 'percent' shows %, 'name' shows name, or custom function */
  labelFormatter?:
    | 'value'
    | 'percent'
    | 'name'
    | 'name-value'
    | ((params: any) => string);
  /** Card padding */
  cardPadding?: string;
  /** Additional card styles */
  cardStyle?: React.CSSProperties;
  /** Pie chart center position [x, y] */
  center?: [string, string];
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const defaultColors = [
  '#31D48B',
  '#FDB61C',
  '#7793FF',
  '#E76B36',
  '#A78BFA',
  '#EA3927',
];

const DashboardPieChart: React.FC<DashboardPieChartProps> = ({
  title,
  data,
  height = 300,
  width = '100%',
  colors = defaultColors,
  outerRadius = '70%',
  innerRadius = '0%',
  showLegend = true,
  legendPosition = 'top-right',
  showLabels = true,
  labelFormatter = 'value',
  cardPadding = chartCard.padding,
  cardStyle = {},
  center = ['50%', '55%'],
  option: optionOverride = {},
}) => {
  // Determine legend configuration based on position
  const getLegendConfig = () => {
    if (!showLegend) return { show: false };

    const baseConfig = {
      show: true,
      itemWidth: 12,
      itemHeight: 12,
      itemGap: 12,
      textStyle: {
        ...chartTypography.axisLabel,
        color: chartTypography.axisLabel.color,
      },
    };

    switch (legendPosition) {
      case 'top':
        return {
          ...baseConfig,
          orient: 'horizontal' as const,
          top: 0,
          left: 'center',
        };
      case 'top-right':
        return {
          ...baseConfig,
          orient: 'vertical' as const,
          top: 0,
          right: 0,
        };
      case 'right':
        return {
          ...baseConfig,
          orient: 'vertical' as const,
          top: 'center',
          right: 0,
        };
      case 'bottom':
        return {
          ...baseConfig,
          orient: 'horizontal' as const,
          bottom: 0,
          left: 'center',
        };
      default:
        return baseConfig;
    }
  };

  // Get label formatter function
  const getLabelFormatter = () => {
    if (typeof labelFormatter === 'function') {
      return labelFormatter;
    }

    switch (labelFormatter) {
      case 'value':
        return '{c}';
      case 'percent':
        return '{d}%';
      case 'name':
        return '{b}';
      case 'name-value':
        return '{b}: {c}';
      default:
        return '{c}';
    }
  };

  // Adjust center based on legend position
  const getCenter = (): [string, string] => {
    if (legendPosition === 'top-right' || legendPosition === 'right') {
      return ['40%', '55%'];
    }
    return center;
  };

  const defaultOption = {
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        const { name, value, percent } = params;
        return `${name}: ${value} (${percent.toFixed(1)}%)`;
      },
    },
    legend: getLegendConfig(),
    series: [
      {
        type: 'pie',
        radius: [innerRadius, outerRadius],
        center: getCenter(),
        avoidLabelOverlap: true,
        label: showLabels
          ? {
              show: true,
              position: 'outside',
              formatter: getLabelFormatter(),
              ...chartTypography.axisLabel,
              alignTo: 'labelLine',
              edgeDistance: 10,
            }
          : { show: false },
        labelLine: showLabels
          ? {
              show: true,
              length: 15,
              length2: 10,
              smooth: true,
              lineStyle: {
                color: '#C4C4C4',
              },
            }
          : { show: false },
        data: data.map((item, index) => ({
          name: item.name,
          value: item.value,
          itemStyle: {
            color: item.color || colors[index % colors.length],
          },
        })),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.2)',
          },
        },
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    legend: { ...defaultOption.legend, ...optionOverride.legend },
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardPieChart;
