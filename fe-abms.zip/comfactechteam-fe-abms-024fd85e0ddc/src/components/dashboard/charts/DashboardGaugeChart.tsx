import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency } from '@/utils/helper.utils';
import { chartTypography, chartCard, chartTitleCss } from './chartTheme';

export interface DashboardGaugeChartProps {
  title?: string;
  totalBudget: number;
  costingAmount: number;
  height?: number | string;
  width?: number | string;
  color?: string;
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const DashboardGaugeChart: React.FC<DashboardGaugeChartProps> = ({
  title,
  totalBudget,
  costingAmount,
  height = 300,
  width = '100%',
  color = '#7CB342',
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  // const percentage =
  //   totalBudget > 0 ? Math.round((costingAmount / totalBudget) * 100) : 0;

  const defaultOption = {
    tooltip: {
      trigger: 'item',
      formatter: () => {
        return `Value: ${formatCurrency(costingAmount)}<br/>Target: ${formatCurrency(totalBudget)}`;
      },
    },
    series: [
      {
        type: 'gauge',
        startAngle: 180,
        endAngle: 0,
        center: ['50%', '75%'],
        radius: '100%',
        min: 0,
        max: totalBudget,
        splitNumber: 10,
        axisLine: {
          roundCap: true,
          lineStyle: {
            width: 18,
            color: [[1, color]],
          },
        },
        pointer: {
          show: true,
          length: '60%',
          width: 6,
          itemStyle: {
            color: color,
          },
        },
        anchor: {
          show: true,
          showAbove: true,
          size: 12,
          itemStyle: {
            borderWidth: 0,
            color: color,
          },
        },
        axisTick: {
          show: true,
          distance: -22,
          length: 8,
          lineStyle: {
            color: '#999',
            width: 1,
          },
        },
        splitLine: {
          show: true,
          distance: -26,
          length: 14,
          lineStyle: {
            color: '#999',
            width: 2,
          },
        },
        axisLabel: {
          show: true,
          distance: -45,
          ...chartTypography.axisLabel,
          formatter: (value: number) => {
            if (value === 0) return '0';
            const k = value / 1000;
            return `$${k}K`;
          },
        },
        title: {
          show: false,
        },
        detail: {
          show: true,
          offsetCenter: [0, '40%'],
          ...chartTypography.gaugeValue,
          formatter: () => formatCurrency(costingAmount),
        },
        data: [
          {
            value: costingAmount,
          },
        ],
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div
          style={{ width: width, height: `${height}px`, overflow: 'hidden' }}
        >
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
            notMerge={true}
            autoResize={true}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardGaugeChart;
