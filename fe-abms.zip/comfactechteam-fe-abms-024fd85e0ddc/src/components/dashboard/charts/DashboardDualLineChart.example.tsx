/**
 * DashboardDualLineChart - Usage Examples
 *
 * A reusable dual line chart component for comparing two data series.
 * Supports single Y-axis (same scale) or dual Y-axis (different scales).
 */

import React from 'react';
import { Grid } from '@mui/material';
import DashboardDualLineChart from './DashboardDualLineChart';

// =============================================================================
// EXAMPLE 1: Basic Usage - Single Y-Axis (Same Scale)
// =============================================================================
// Use this when both series have the same unit/scale (e.g., both are dollar amounts)

export const BasicDualLineExample: React.FC = () => {
  const data = [
    { name: 'Jan', revenue: 45000, expenses: 32000 },
    { name: 'Feb', revenue: 52000, expenses: 35000 },
    { name: 'Mar', revenue: 48000, expenses: 38000 },
    { name: 'Apr', revenue: 61000, expenses: 42000 },
    { name: 'May', revenue: 55000, expenses: 40000 },
    { name: 'Jun', revenue: 67000, expenses: 45000 },
  ];

  return (
    <DashboardDualLineChart
      title='Revenue vs Expenses'
      data={data}
      primarySeries={{
        dataKey: 'revenue',
        label: 'Revenue',
        color: '#4285F4',
        lineStyle: 'solid',
      }}
      secondarySeries={{
        dataKey: 'expenses',
        label: 'Expenses',
        color: '#EA4335',
        lineStyle: 'dashed',
      }}
      primaryYAxisLabel='Amount ($)'
      height={300}
    />
  );
};

// =============================================================================
// EXAMPLE 2: Dual Y-Axis (Different Scales)
// =============================================================================
// Use this when series have different units (e.g., dollars vs percentage)

export const DualYAxisExample: React.FC = () => {
  const data = [
    { name: 'Product A', sales: 150000, margin: 35 },
    { name: 'Product B', sales: 120000, margin: 28 },
    { name: 'Product C', sales: 95000, margin: 42 },
    { name: 'Product D', sales: 180000, margin: 31 },
    { name: 'Product E', sales: 75000, margin: 45 },
  ];

  return (
    <DashboardDualLineChart
      title='Sales vs Profit Margin by Product'
      data={data}
      primarySeries={{
        dataKey: 'sales',
        label: 'Sales Amount',
        color: '#34A853',
        lineStyle: 'solid',
        yAxisIndex: 0,
      }}
      secondarySeries={{
        dataKey: 'margin',
        label: 'Profit Margin %',
        color: '#FBBC04',
        lineStyle: 'dashed',
        yAxisIndex: 1,
        valueFormatter: (value: number) => `${value}%`,
      }}
      primaryYAxisLabel='Sales ($)'
      secondaryYAxisLabel='Margin %'
      height={350}
    />
  );
};

// =============================================================================
// EXAMPLE 3: Budget vs Actual Comparison
// =============================================================================
// Common use case for financial dashboards

export const BudgetVsActualExample: React.FC = () => {
  const data = [
    { name: 'Cleaning', budget: 150000, actual: 142000 },
    { name: 'Maintenance', budget: 120000, actual: 135000 },
    { name: 'Security', budget: 80000, actual: 75000 },
    { name: 'Landscaping', budget: 60000, actual: 58000 },
    { name: 'Pest Control', budget: 40000, actual: 45000 },
  ];

  return (
    <DashboardDualLineChart
      title='Budget vs Actual by Department'
      data={data}
      primarySeries={{
        dataKey: 'budget',
        label: 'Budget',
        color: '#4285F4',
        lineStyle: 'solid',
      }}
      secondarySeries={{
        dataKey: 'actual',
        label: 'Actual',
        color: '#34A853',
        lineStyle: 'dashed',
      }}
      primaryYAxisLabel='Amount ($)'
      xAxisLabelRotate={30}
      smooth={true}
      showMarkers={true}
      markerSize={10}
      height={300}
    />
  );
};

// =============================================================================
// EXAMPLE 4: Trend Analysis with Custom Styling
// =============================================================================
// Shows how to customize appearance

export const CustomStyledExample: React.FC = () => {
  const data = [
    { name: 'Week 1', thisYear: 25000, lastYear: 22000 },
    { name: 'Week 2', thisYear: 32000, lastYear: 28000 },
    { name: 'Week 3', thisYear: 28000, lastYear: 30000 },
    { name: 'Week 4', thisYear: 45000, lastYear: 38000 },
    { name: 'Week 5', thisYear: 38000, lastYear: 35000 },
    { name: 'Week 6', thisYear: 52000, lastYear: 42000 },
  ];

  return (
    <DashboardDualLineChart
      title='Year over Year Comparison'
      data={data}
      primarySeries={{
        dataKey: 'thisYear',
        label: 'This Year',
        color: '#9334E6',
        lineStyle: 'solid',
      }}
      secondarySeries={{
        dataKey: 'lastYear',
        label: 'Last Year',
        color: '#A7AAB2',
        lineStyle: 'dashed',
      }}
      primaryYAxisLabel='Sales ($)'
      smooth={false}
      showMarkers={true}
      markerSize={6}
      height={280}
      cardStyle={{ background: '#FAFAFA' }}
    />
  );
};

// =============================================================================
// EXAMPLE 5: Without Markers (Clean Lines)
// =============================================================================
// For a cleaner look with many data points

export const NoMarkersExample: React.FC = () => {
  const data = Array.from({ length: 12 }, (_, i) => ({
    name: `Month ${i + 1}`,
    target: 50000 + Math.random() * 20000,
    achieved: 45000 + Math.random() * 25000,
  }));

  return (
    <DashboardDualLineChart
      title='Monthly Target vs Achievement'
      data={data}
      primarySeries={{
        dataKey: 'target',
        label: 'Target',
        color: '#EA4335',
        lineStyle: 'solid',
      }}
      secondarySeries={{
        dataKey: 'achieved',
        label: 'Achieved',
        color: '#34A853',
        lineStyle: 'dashed',
      }}
      primaryYAxisLabel='Amount ($)'
      smooth={true}
      showMarkers={false}
      height={300}
    />
  );
};

// =============================================================================
// FULL DEMO COMPONENT
// =============================================================================
// Displays all examples in a grid layout

const DashboardDualLineChartDemo: React.FC = () => {
  return (
    <Grid container spacing={3} sx={{ p: 3 }}>
      <Grid item xs={12} md={6}>
        <BasicDualLineExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <DualYAxisExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <BudgetVsActualExample />
      </Grid>
      <Grid item xs={12} md={6}>
        <CustomStyledExample />
      </Grid>
      <Grid item xs={12}>
        <NoMarkersExample />
      </Grid>
    </Grid>
  );
};

export default DashboardDualLineChartDemo;

/**
 * PROPS REFERENCE
 * ================
 *
 * title?: string
 *   - Chart title displayed at the top
 *
 * data: DashboardDualLineChartDataPoint[]
 *   - Array of objects with 'name' field and value fields
 *   - Example: [{ name: 'Jan', value1: 100, value2: 80 }]
 *
 * primarySeries: DashboardDualLineChartSeries
 *   - dataKey: string - Key in data object for primary values
 *   - label: string - Display name in legend/tooltip
 *   - color?: string - Line color (default: #4285F4)
 *   - lineStyle?: 'solid' | 'dashed' - Line style (default: solid)
 *   - yAxisIndex?: number - Y-axis index for dual Y-axis mode (0 = left)
 *   - valueFormatter?: (value: number) => string - Custom tooltip formatter
 *
 * secondarySeries: DashboardDualLineChartSeries
 *   - Same properties as primarySeries
 *   - lineStyle defaults to 'dashed'
 *   - yAxisIndex defaults to 1 in dual Y-axis mode
 *
 * primaryYAxisLabel?: string
 *   - Label for the left Y-axis
 *
 * secondaryYAxisLabel?: string
 *   - Label for the right Y-axis
 *   - Setting this enables dual Y-axis mode
 *
 * height?: number (default: 300)
 *   - Chart height in pixels
 *
 * width?: string (default: '100%')
 *   - Chart width
 *
 * smooth?: boolean (default: true)
 *   - Enable smooth curves
 *
 * showMarkers?: boolean (default: true)
 *   - Show data point markers
 *
 * markerSize?: number (default: 8)
 *   - Size of data point markers
 *
 * xAxisLabelRotate?: number (default: 0)
 *   - Rotation angle for X-axis labels
 *
 * cardPadding?: string
 *   - Custom card padding
 *
 * cardStyle?: React.CSSProperties
 *   - Custom card styles
 *
 * option?: Record<string, any>
 *   - ECharts option override for advanced customization
 */
