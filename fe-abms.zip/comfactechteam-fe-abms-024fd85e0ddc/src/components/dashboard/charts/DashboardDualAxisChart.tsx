import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency, formatCurrencyK } from '@/utils/helper.utils';
import {
  chartTypography,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
} from './chartTheme';

export interface DashboardDualAxisChartDataPoint {
  name: string;
  [key: string]: string | number;
}

export interface DashboardDualAxisChartSeries {
  /** Data field key in dataPoints */
  dataKey: string;
  /** Display name in legend and tooltip */
  label: string;
  /** Chart type: line or bar */
  type: 'line' | 'bar';
  /** Series color */
  color?: string;
  /** Line style (only for type: 'line') */
  lineStyle?: 'solid' | 'dashed';
  /** Y-axis index (0 = left, 1 = right) */
  yAxisIndex?: number;
  /** Custom value formatter for tooltip */
  valueFormatter?: (value: number) => string;
  /** Bar width (only for type: 'bar') */
  barWidth?: number;
}

export interface DashboardDualAxisChartProps {
  /** Chart title */
  title?: string;
  /** Array of data points with name and value fields */
  data: DashboardDualAxisChartDataPoint[];
  /** Primary series configuration */
  primarySeries: DashboardDualAxisChartSeries;
  /** Secondary series configuration */
  secondarySeries: DashboardDualAxisChartSeries;
  /** Chart height in pixels */
  height?: number;
  /** Chart width */
  width?: string;
  /** Primary Y-axis label (left side) */
  primaryYAxisLabel?: string;
  /** Primary Y-axis formatter */
  primaryYAxisFormatter?: (value: number) => string;
  /** Secondary Y-axis label (right side) */
  secondaryYAxisLabel?: string;
  /** Secondary Y-axis formatter */
  secondaryYAxisFormatter?: (value: number) => string;
  /** Enable smooth curves for line series */
  smooth?: boolean;
  /** Show data point markers for line series */
  showMarkers?: boolean;
  /** Marker size */
  markerSize?: number;
  /** Rotate X-axis labels (degrees) */
  xAxisLabelRotate?: number;
  /** Show legend */
  showLegend?: boolean;
  /** Legend position */
  legendPosition?: 'top' | 'bottom';
  /** Card padding */
  cardPadding?: string;
  /** Custom card styles */
  cardStyle?: React.CSSProperties;
  /** ECharts option override for advanced customization */
  option?: Record<string, any>;
}

const DashboardDualAxisChart: React.FC<DashboardDualAxisChartProps> = ({
  title,
  data,
  primarySeries,
  secondarySeries,
  height = 300,
  width = '100%',
  primaryYAxisLabel = '',
  primaryYAxisFormatter = (v: number) => formatCurrencyK(v),
  secondaryYAxisLabel = '',
  secondaryYAxisFormatter = (v: number) => `${v}%`,
  smooth = true,
  showMarkers = true,
  markerSize = 8,
  xAxisLabelRotate = 0,
  showLegend = true,
  legendPosition = 'top',
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  // Default colors
  const primaryColor = primarySeries.color || '#4285F4';
  const secondaryColor = secondarySeries.color || '#34A853';

  // Default formatters
  const primaryFormatter =
    primarySeries.valueFormatter || ((v: number) => formatCurrency(v));
  const secondaryFormatter =
    secondarySeries.valueFormatter || ((v: number) => `${v}%`);

  // Build series configuration
  const buildSeriesConfig = (
    series: DashboardDualAxisChartSeries,
    color: string
  ) => {
    const baseConfig = {
      name: series.label,
      yAxisIndex: series.yAxisIndex ?? 0,
      data: data.map(item => item[series.dataKey]),
    };

    if (series.type === 'line') {
      return {
        ...baseConfig,
        type: 'line',
        smooth,
        symbol: showMarkers ? 'circle' : 'none',
        symbolSize: markerSize,
        lineStyle: {
          color,
          width: 2,
          type: series.lineStyle || 'solid',
        },
        itemStyle: {
          color,
        },
      };
    } else {
      return {
        ...baseConfig,
        type: 'bar',
        barWidth: series.barWidth || 30,
        itemStyle: {
          color,
          borderRadius: [4, 4, 0, 0],
        },
      };
    }
  };

  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
      },
      formatter: (params: any) => {
        let result = `<strong>${params[0].name}</strong><br/>`;
        params.forEach((param: any) => {
          const formatter =
            param.seriesName === primarySeries.label
              ? primaryFormatter
              : secondaryFormatter;
          result += `${param.marker} ${param.seriesName}: ${formatter(param.value)}<br/>`;
        });
        return result;
      },
    },
    legend: showLegend
      ? {
          data: [primarySeries.label, secondarySeries.label],
          [legendPosition === 'top' ? 'top' : 'bottom']: 0,
          left: 'center',
          textStyle: {
            ...chartTypography.axisLabel,
          },
        }
      : undefined,
    grid: {
      ...chartGrid,
      top: showLegend && legendPosition === 'top' ? 60 : '10%',
      bottom: showLegend && legendPosition === 'bottom' ? 60 : 30,
    },
    xAxis: {
      type: 'category',
      data: data.map(item => item.name),
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
        rotate: xAxisLabelRotate,
      },
      axisTick: {
        show: false,
      },
    },
    yAxis: [
      {
        type: 'value',
        name: primaryYAxisLabel,
        nameLocation: 'middle',
        nameGap: 50,
        nameTextStyle: {
          ...chartTypography.axisName,
        },
        axisLine: {
          show: false,
        },
        axisLabel: {
          ...chartTypography.axisLabel,
          formatter: primaryYAxisFormatter,
        },
        splitLine: chartSplitLine,
      },
      {
        type: 'value',
        name: secondaryYAxisLabel,
        nameLocation: 'middle',
        nameGap: 40,
        nameTextStyle: {
          ...chartTypography.axisName,
        },
        axisLine: {
          show: false,
        },
        axisLabel: {
          ...chartTypography.axisLabel,
          formatter: secondaryYAxisFormatter,
        },
        splitLine: {
          show: false,
        },
      },
    ],
    series: [
      buildSeriesConfig(primarySeries, primaryColor),
      buildSeriesConfig(secondarySeries, secondaryColor),
    ],
  };

  // Deep merge with option override
  const option = {
    ...defaultOption,
    ...optionOverride,
    legend: optionOverride.legend
      ? { ...defaultOption.legend, ...optionOverride.legend }
      : defaultOption.legend,
    grid: { ...defaultOption.grid, ...optionOverride.grid },
    xAxis: {
      ...defaultOption.xAxis,
      ...optionOverride.xAxis,
      axisLabel: {
        ...defaultOption.xAxis.axisLabel,
        ...optionOverride.xAxis?.axisLabel,
      },
    },
    yAxis: optionOverride.yAxis
      ? defaultOption.yAxis.map((axis: any, i: number) => ({
          ...axis,
          ...(optionOverride.yAxis?.[i] || {}),
        }))
      : defaultOption.yAxis,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
            autoResize={true}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardDualAxisChart;
