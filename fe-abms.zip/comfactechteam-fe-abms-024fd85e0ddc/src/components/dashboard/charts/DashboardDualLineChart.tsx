import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency, formatCurrencyK } from '@/utils/helper.utils';
import {
  chartTypography,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
} from './chartTheme';

export interface DashboardDualLineChartDataPoint {
  name: string;
  [key: string]: string | number;
}

export interface DashboardDualLineChartSeries {
  /** Data field key in dataPoints */
  dataKey: string;
  /** Display name in legend and tooltip */
  label: string;
  /** Line color */
  color?: string;
  /** Line style: solid or dashed */
  lineStyle?: 'solid' | 'dashed';
  /** Y-axis index (0 = left, 1 = right) - used for dual Y-axis */
  yAxisIndex?: number;
  /** Custom value formatter for tooltip */
  valueFormatter?: (value: number) => string;
}

export interface DashboardDualLineChartProps {
  /** Chart title */
  title?: string;
  /** Array of data points with name and value fields */
  data: DashboardDualLineChartDataPoint[];
  /** Primary series configuration */
  primarySeries: DashboardDualLineChartSeries;
  /** Secondary series configuration */
  secondarySeries: DashboardDualLineChartSeries;
  /** Chart height in pixels */
  height?: number;
  /** Chart width */
  width?: string;
  /** Primary Y-axis label (left side) */
  primaryYAxisLabel?: string;
  /** Secondary Y-axis label (right side) - enables dual Y-axis mode */
  secondaryYAxisLabel?: string;
  /** Enable smooth curves */
  smooth?: boolean;
  /** Show data point markers */
  showMarkers?: boolean;
  /** Marker size */
  markerSize?: number;
  /** Rotate X-axis labels (degrees) */
  xAxisLabelRotate?: number;
  /** Card padding */
  cardPadding?: string;
  /** Custom card styles */
  cardStyle?: React.CSSProperties;
  /** ECharts option override for advanced customization */
  option?: Record<string, any>;
}

const DashboardDualLineChart: React.FC<DashboardDualLineChartProps> = ({
  title,
  data,
  primarySeries,
  secondarySeries,
  height = 300,
  width = '100%',
  primaryYAxisLabel = '',
  secondaryYAxisLabel,
  smooth = true,
  showMarkers = true,
  markerSize = 8,
  xAxisLabelRotate = 0,
  cardPadding = chartCard.padding,
  cardStyle = {},
  option: optionOverride = {},
}) => {
  // Determine if dual Y-axis mode is enabled
  const isDualYAxis = !!secondaryYAxisLabel;

  // Default colors
  const primaryColor = primarySeries.color || '#4285F4';
  const secondaryColor = secondarySeries.color || '#34A853';

  // Default formatters
  const primaryFormatter =
    primarySeries.valueFormatter || ((v: number) => formatCurrency(v));
  const secondaryFormatter =
    secondarySeries.valueFormatter || ((v: number) => formatCurrency(v));

  // Build Y-axis configuration
  const yAxisConfig = isDualYAxis
    ? [
        {
          type: 'value',
          name: primaryYAxisLabel,
          nameLocation: 'middle',
          nameGap: 50,
          nameTextStyle: {
            ...chartTypography.axisName,
          },
          axisLine: {
            show: false,
          },
          axisLabel: {
            ...chartTypography.axisLabel,
            formatter: (value: number) => formatCurrencyK(value),
          },
          splitLine: chartSplitLine,
        },
        {
          type: 'value',
          name: secondaryYAxisLabel,
          nameLocation: 'middle',
          nameGap: 40,
          nameTextStyle: {
            ...chartTypography.axisName,
          },
          axisLine: {
            show: false,
          },
          axisLabel: {
            ...chartTypography.axisLabel,
            formatter:
              secondarySeries.valueFormatter ||
              ((value: number) => `${value}%`),
          },
          splitLine: {
            show: false,
          },
        },
      ]
    : {
        type: 'value',
        name: primaryYAxisLabel,
        nameLocation: 'middle',
        nameGap: 50,
        nameTextStyle: {
          ...chartTypography.axisName,
        },
        axisLine: {
          show: false,
        },
        axisLabel: {
          ...chartTypography.axisLabel,
          formatter: (value: number) => formatCurrencyK(value),
        },
        splitLine: chartSplitLine,
      };

  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        let result = `<strong>${params[0].name}</strong><br/>`;
        params.forEach((param: any) => {
          const formatter =
            param.seriesName === primarySeries.label
              ? primaryFormatter
              : secondaryFormatter;
          result += `${param.marker} ${param.seriesName}: ${formatter(param.value)}<br/>`;
        });
        return result;
      },
    },
    legend: {
      data: [primarySeries.label, secondarySeries.label],
      bottom: 0,
      left: 'center',
      textStyle: {
        ...chartTypography.axisLabel,
      },
    },
    grid: {
      ...chartGrid,
      bottom: 60,
    },
    xAxis: {
      type: 'category',
      data: data.map(item => item.name),
      boundaryGap: false,
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
        rotate: xAxisLabelRotate,
      },
      axisTick: {
        show: false,
      },
    },
    yAxis: yAxisConfig,
    series: [
      {
        name: primarySeries.label,
        type: 'line',
        yAxisIndex: isDualYAxis ? (primarySeries.yAxisIndex ?? 0) : undefined,
        data: data.map(item => item[primarySeries.dataKey]),
        smooth,
        symbol: showMarkers ? 'circle' : 'none',
        symbolSize: markerSize,
        lineStyle: {
          color: primaryColor,
          width: 2,
          type: primarySeries.lineStyle || 'solid',
        },
        itemStyle: {
          color: primaryColor,
        },
      },
      {
        name: secondarySeries.label,
        type: 'line',
        yAxisIndex: isDualYAxis ? (secondarySeries.yAxisIndex ?? 1) : undefined,
        data: data.map(item => item[secondarySeries.dataKey]),
        smooth,
        symbol: showMarkers ? 'circle' : 'none',
        symbolSize: markerSize,
        lineStyle: {
          color: secondaryColor,
          width: 2,
          type: secondarySeries.lineStyle || 'dashed',
        },
        itemStyle: {
          color: secondaryColor,
        },
      },
    ],
  };

  // Merge with option override
  const option = {
    ...defaultOption,
    ...optionOverride,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
            autoResize={true}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardDualLineChart;
