import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency } from '@/utils/helper.utils';
import {
  chartTypography,
  chartColors,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
  chartNameGap,
} from './chartTheme';

export interface DashboardAreaChartData {
  name: string;
  value: number;
}

export interface DashboardAreaChartProps {
  title?: string;
  data: DashboardAreaChartData[];
  height?: number;
  width?: string;
  color?: string;
  yAxisLabel?: string;
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  showMarkers?: boolean;
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const DashboardAreaChart: React.FC<DashboardAreaChartProps> = ({
  title,
  data,
  height = 300,
  width = '100%',
  color = chartColors.primary,
  yAxisLabel = '',
  cardPadding = chartCard.padding,
  cardStyle = {},
  showMarkers = true,
  option: optionOverride = {},
}) => {
  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const { name, value } = params[0];
        return `${name}: ${formatCurrency(value)}`;
      },
    },
    grid: {
      ...chartGrid,
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.map(item => item.name),
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: true,
        ...chartSplitLine,
      },
    },
    yAxis: {
      type: 'value',
      name: yAxisLabel,
      nameLocation: 'middle',
      nameGap: chartNameGap.yAxis,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      axisLine: {
        show: false,
      },
      axisLabel: {
        ...chartTypography.axisLabel,
        formatter: (value: number) => formatCurrency(value),
      },
      splitLine: {
        show: false,
      },
    },
    series: [
      {
        type: 'line',
        data: data.map(item => item.value),
        smooth: true,
        symbol: showMarkers ? 'circle' : 'none',
        symbolSize: 8,
        itemStyle: {
          color,
          borderColor: color,
          borderWidth: 0,
        },
        lineStyle: {
          color,
          width: 2,
        },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: `${color}40`,
              },
              {
                offset: 1,
                color: `${color}05`,
              },
            ],
          },
        },
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    grid: { ...defaultOption.grid, ...optionOverride.grid },
    xAxis: { ...defaultOption.xAxis, ...optionOverride.xAxis },
    yAxis: { ...defaultOption.yAxis, ...optionOverride.yAxis },
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardAreaChart;
