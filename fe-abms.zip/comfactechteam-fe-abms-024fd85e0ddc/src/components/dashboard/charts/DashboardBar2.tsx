import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency } from '@/utils/helper.utils';
import {
  chartTypography,
  chartColors,
  chartCard,
  chartTitleCss,
  chartGrid,
  chartAxisLine,
  chartSplitLine,
  chartNameGap,
} from './chartTheme';

export interface DashboardBar2Data {
  name: string;
  value: number;
}

export interface DashboardBar2Props {
  title?: string;
  data: DashboardBar2Data[];
  height?: number;
  width?: string;
  color?: string;
  yAxisLabel?: string;
  legendLabel?: string;
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  barWidth?: number;
  /** Inverse the y-axis (show values from high to low) */
  inverse?: boolean;
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const DashboardBar2: React.FC<DashboardBar2Props> = ({
  title,
  data,
  height = 300,
  width = '100%',
  color = chartColors.primary,
  yAxisLabel = '',
  legendLabel = '',
  cardPadding = chartCard.padding,
  cardStyle = {},
  barWidth = 40,
  inverse = false,
  option: optionOverride = {},
}) => {
  const defaultOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow',
      },
      formatter: (params: any) => {
        const { name, value } = params[0];
        return `${name}: ${formatCurrency(value)}`;
      },
    },
    legend: legendLabel
      ? {
          data: [legendLabel],
          top: 0,
          right: 'center',
          itemWidth: 12,
          itemHeight: 12,
          textStyle: {
            ...chartTypography.axisLabel,
            color: chartColors.text.secondary,
          },
        }
      : undefined,
    grid: {
      ...chartGrid,
      top: legendLabel ? '15%' : '10%',
    },
    xAxis: {
      type: 'category',
      data: data.map(item => item.name),
      axisLine: chartAxisLine,
      axisLabel: {
        ...chartTypography.axisLabel,
        interval: 0,
        formatter: (value: string) => {
          // Wrap long labels
          if (value.length > 12) {
            const words = value.split(' ');
            const lines: string[] = [];
            let currentLine = '';
            words.forEach(word => {
              if ((currentLine + ' ' + word).trim().length <= 12) {
                currentLine = (currentLine + ' ' + word).trim();
              } else {
                if (currentLine) lines.push(currentLine);
                currentLine = word;
              }
            });
            if (currentLine) lines.push(currentLine);
            return lines.join('\n');
          }
          return value;
        },
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: true,
        ...chartSplitLine,
      },
    },
    yAxis: {
      type: 'value',
      name: yAxisLabel,
      nameLocation: 'middle',
      nameGap: chartNameGap.yAxis,
      nameTextStyle: {
        ...chartTypography.axisName,
      },
      inverse,
      axisLine: {
        show: false,
      },
      axisLabel: {
        ...chartTypography.axisLabel,
        formatter: (value: number) => formatCurrency(value),
      },
      splitLine: chartSplitLine,
    },
    series: [
      {
        name: legendLabel || '',
        type: 'bar',
        data: data.map(item => item.value),
        barWidth,
        itemStyle: {
          color,
          borderRadius: [4, 4, 0, 0],
        },
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    grid: { ...defaultOption.grid, ...optionOverride.grid },
    xAxis: { ...defaultOption.xAxis, ...optionOverride.xAxis },
    yAxis: { ...defaultOption.yAxis, ...optionOverride.yAxis },
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardBar2;
