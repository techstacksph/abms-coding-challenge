import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { formatCurrency } from '@/utils/helper.utils';
import { chartTypography, chartCard, chartTitleCss } from './chartTheme';

export interface DashboardFunnelChartData {
  name: string;
  value: number;
  color?: string;
}

export interface DashboardFunnelChartProps {
  title?: string;
  data: DashboardFunnelChartData[];
  height?: number;
  width?: string;
  colors?: string[];
  showLegend?: boolean;
  legendPosition?: 'top' | 'bottom' | 'left' | 'right';
  cardPadding?: string;
  cardStyle?: React.CSSProperties;
  sort?: 'ascending' | 'descending' | 'none';
  funnelAlign?: 'left' | 'center' | 'right';
  /** Override ECharts option - merged with defaults */
  option?: Record<string, any>;
}

const defaultColors = ['#31D48B', '#E76B36'];

const DashboardFunnelChart: React.FC<DashboardFunnelChartProps> = ({
  title,
  data,
  height = 300,
  width = '100%',
  colors = defaultColors,
  showLegend = true,
  legendPosition = 'top',
  cardPadding = chartCard.padding,
  cardStyle = {},
  sort = 'descending',
  funnelAlign = 'center',
  option: optionOverride = {},
}) => {
  const legendOrient =
    legendPosition === 'top' || legendPosition === 'bottom'
      ? 'horizontal'
      : 'vertical';

  const defaultOption = {
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        const { name, value } = params;
        return `${name}: ${formatCurrency(value)}`;
      },
    },
    legend: showLegend
      ? {
          orient: legendOrient,
          [legendPosition]:
            legendPosition === 'top'
              ? 0
              : legendPosition === 'bottom'
                ? 0
                : 'center',
          ...(legendPosition === 'left' || legendPosition === 'right'
            ? { top: 'center' }
            : {}),
          itemWidth: 32,
          itemHeight: 8,
          itemGap: 20,
          textStyle: {
            ...chartTypography.axisLabel,
          },
          icon: 'rect',
        }
      : false,
    series: [
      {
        name: 'Funnel',
        type: 'funnel',
        left: '10%',
        top: showLegend ? 60 : 20,
        bottom: 20,
        width: '80%',
        min: 0,
        minSize: '0%',
        maxSize: '100%',
        sort,
        gap: 2,
        funnelAlign,
        label: {
          show: true,
          position: 'right',
          formatter: (params: any) => formatCurrency(params.value),
          ...chartTypography.axisLabel,
          color: '#374151',
          fontWeight: 600,
        },
        labelLine: {
          show: true,
          length: 20,
          lineStyle: {
            color: '#E9EAEC',
          },
        },
        itemStyle: {
          borderColor: '#fff',
          borderWidth: 1,
        },
        emphasis: {
          label: {
            show: true,
          },
        },
        data: data.map((item, index) => ({
          name: item.name,
          value: item.value,
          itemStyle: {
            color: item.color || colors[index % colors.length],
          },
        })),
      },
    ],
  };

  // Deep merge option override with defaults
  const option = {
    ...defaultOption,
    ...optionOverride,
    series: optionOverride.series
      ? defaultOption.series.map((s, i) => ({
          ...s,
          ...optionOverride.series?.[i],
        }))
      : defaultOption.series,
  };

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: ${chartCard.background};
        border: ${chartCard.border};
        border-radius: ${chartCard.borderRadius};
        box-shadow: ${chartCard.boxShadow};
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={chartTitleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}
        <div style={{ width: '100%', height: `${height}px` }}>
          <ReactECharts
            option={option}
            style={{ height: '100%', width: '100%' }}
            opts={{ renderer: 'svg' }}
          />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardFunnelChart;
