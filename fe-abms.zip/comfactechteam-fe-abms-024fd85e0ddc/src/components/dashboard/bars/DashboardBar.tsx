import React from 'react';
import { Bar, BarConfig } from '@ant-design/charts';
import { axisConfig, themeConfig } from '@/config/chartConfig';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';

const titleCss = `
color: var(--Colors-text-primary, #090A0B);
font-family: "Hanken Grotesk";
font-size: 16px;
font-style: normal;
font-weight: 600;
line-height: 24px;
`;

export interface DashboardBarData {
  [key: string]: any;
}

export interface DashboardBarProps {
  title?: string;
  data: DashboardBarData[];
  xField: string;
  yField: string;
  seriesField?: string;
  colorField?: string;
  height?: number;
  width?: string;

  // Chart customization options
  stack?: boolean | object;
  group?: boolean | object;
  percent?: boolean;

  // Styling options
  color?: string | string[];
  barStyle?: object;

  // Axis configuration options
  axis?: object;
  xAxis?: object;
  yAxis?: object;

  // Interaction configuration
  interaction?: object;

  // Legend configuration
  legend?: object;

  // Advanced chart configuration override (non-styling properties)
  chartConfig?: Partial<BarConfig & { [key: string]: any }>;

  // Card styling
  cardPadding?: string;
  cardStyle?: React.CSSProperties;

  // Scale configuration
  scaleStyle?: object;

  // Event handlers
  onReady?: (chart: any) => void;
  onBarClick?: (data: any) => void;
}

const DashboardBar: React.FC<DashboardBarProps> = ({
  title,
  data,
  xField,
  yField,
  seriesField,
  colorField,
  height = 300,
  width = '100%',
  stack = false,
  group = false,
  percent = false,
  color,
  barStyle,
  axis,
  xAxis,
  yAxis,
  interaction,
  legend,
  chartConfig = {},
  cardPadding = '12px 20px',
  cardStyle = {},
  onReady,
  onBarClick,
  scaleStyle = {},
}) => {
  // Default chart configuration
  const defaultConfig: any = {
    data,
    xField,
    yField,
    colorField: seriesField || colorField,
    height,
    stack,
    group,
    percent,
    scale: {
      color: color
        ? {
            palette: Array.isArray(color) ? color : [color],
          }
        : undefined,
      ...scaleStyle,
    },
    // Default styling
    style: {
      maxWidth: 48,
      radiusTopRight: 4,
      radiusBottomRight: 4,
      radiusTopLeft: 4,
      radiusBottomLeft: 4,
      ...barStyle,
    },

    // Color configuration
    // color: color || '#4CAF50',
    axis: {
      x: {
        ...axisConfig.x,
        ...xAxis,
      },
      y: {
        ...axisConfig.y,
        // labelFormatter: (text: string) => {
        //   return isValueValid(text) && typeof text === 'string'
        //     ? convertCase(text, CaseType.SENTENCE_CASE)
        //     : text;
        // },
        ...yAxis,
      },
      ...axis,
    },

    // Default interaction
    interaction: {
      tooltip: {
        shared: true,
        crosshairs: false,
      },
      ...interaction,
    },

    // Default legend configuration
    legend: {
      color: {
        // color: [],
        position: 'top',
        layout: {
          justifyContent: 'center',
        },
      },
      ...legend,
    },

    // Default theme
    theme: 'light',

    // Event handlers
    onReady: onReady,

    // Override with custom config
    ...chartConfig,
  };

  // Handle bar click if provided
  if (onBarClick) {
    defaultConfig.onReady = (chart: any) => {
      chart.on('element:click', onBarClick);
      if (onReady) onReady(chart);
    };
  }

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: white;
        border: 1px solid #E5E7EB;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {/* Header Section */}
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={titleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}

        {/* Chart Section */}
        <div style={{ width: '100%', height: `${height}px` }}>
          <Bar {...defaultConfig} theme={themeConfig} />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardBar;
