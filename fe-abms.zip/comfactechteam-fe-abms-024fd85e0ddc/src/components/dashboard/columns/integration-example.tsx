import React from 'react';
import { Stack, Grid, Typography } from '@mui/material';
import { GoogleIcon } from '@/styled-components';

// Import both KPI and Column components
import { DashboardKpi, DashboardKpiGrid } from '../kpi';
import { DashboardColumn } from './index';

/**
 * Example showing how to integrate Column charts with existing KPI components
 * This demonstrates a complete dashboard layout mixing both component types
 */
const DashboardIntegrationExample: React.FC = () => {
  // Sample KPI data
  const kpiData = [
    {
      icon: <GoogleIcon name='trending_up' />,
      topCaption: 'Total Revenue',
      value: '$847K',
      badgeValue: '+12%',
      badgeIconType: 'up' as const,
      bottomCaption: 'vs last month',
    },
    {
      icon: <GoogleIcon name='groups' />,
      topCaption: 'Active Clients',
      value: '156',
      badgeValue: '+8',
      badgeIconType: 'up' as const,
      bottomCaption: 'new this month',
    },
    {
      icon: <GoogleIcon name='task_alt' />,
      topCaption: 'Completed Jobs',
      value: '1,247',
      badgeValue: '98%',
      badgeIconType: 'up' as const,
      bottomCaption: 'completion rate',
    },
    {
      icon: <GoogleIcon name='schedule' />,
      topCaption: 'Avg Response Time',
      value: '2.4h',
      badgeValue: '-15min',
      badgeIconType: 'up' as const,
      bottomCaption: 'improvement',
    },
  ];

  // Sample chart data
  const serviceRevenueData = [
    { service: 'General Office Cleaning', amount: 195000 },
    { service: 'Deep Cleaning', amount: 140000 },
    { service: 'Carpet Cleaning', amount: 25000 },
    { service: 'Floor Care', amount: 70000 },
    { service: 'Window Cleaning', amount: 75000 },
    { service: 'Sanitization', amount: 165000 },
  ];

  const monthlyTrendData = [
    { month: 'Jan', revenue: 120000, jobs: 180 },
    { month: 'Feb', revenue: 135000, jobs: 195 },
    { month: 'Mar', revenue: 98000, jobs: 145 },
    { month: 'Apr', revenue: 145000, jobs: 210 },
    { month: 'May', revenue: 162000, jobs: 235 },
    { month: 'Jun', revenue: 178000, jobs: 250 },
  ];

  const teamPerformanceData = [
    { team: 'Team A', completed: 45, pending: 12, overdue: 3 },
    { team: 'Team B', completed: 38, pending: 8, overdue: 5 },
    { team: 'Team C', completed: 52, pending: 15, overdue: 2 },
    { team: 'Team D', completed: 41, pending: 10, overdue: 4 },
  ].flatMap(item => [
    { team: item.team, count: item.completed, status: 'Completed' },
    { team: item.team, count: item.pending, status: 'Pending' },
    { team: item.team, count: item.overdue, status: 'Overdue' },
  ]);

  return (
    <Stack spacing={4} sx={{ padding: 3 }}>
      {/* Dashboard Header */}
      <Typography variant='h4' component='h1' gutterBottom>
        Complete Dashboard Example
      </Typography>
      <Typography variant='subtitle1' color='text.secondary' gutterBottom>
        Combining KPI cards with interactive column charts
      </Typography>

      {/* KPI Section */}
      <div>
        <Typography variant='h5' gutterBottom sx={{ mb: 2 }}>
          Key Performance Indicators
        </Typography>
        <DashboardKpiGrid data={kpiData} columnCount={4} spacing='20px' />
      </div>

      {/* Main Charts Section */}
      <div>
        <Typography variant='h5' gutterBottom sx={{ mb: 2 }}>
          Revenue Analysis
        </Typography>
        <Grid container spacing={3}>
          {/* Service Revenue Chart - Full Width */}
          <Grid item xs={12}>
            <DashboardColumn
              title='Service Type Revenue'
              data={serviceRevenueData}
              xField='service'
              yField='amount'
              height={350}
              color='#4F46E5'
              chartConfig={{
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) =>
                        `$${(value / 1000).toFixed(0)}K`,
                    },
                  },
                },
                tooltip: {
                  formatter: (datum: any) => ({
                    name: 'Revenue',
                    value: `$${datum.amount.toLocaleString()}`,
                  }),
                },
              }}
            />
          </Grid>

          {/* Monthly Trends - Two Charts Side by Side */}
          <Grid item xs={12} md={6}>
            <DashboardColumn
              title='Monthly Revenue Trend'
              data={monthlyTrendData}
              xField='month'
              yField='revenue'
              height={300}
              color='#10B981'
              chartConfig={{
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) =>
                        `$${(value / 1000).toFixed(0)}K`,
                    },
                  },
                },
              }}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <DashboardColumn
              title='Monthly Jobs Completed'
              data={monthlyTrendData}
              xField='month'
              yField='jobs'
              height={300}
              color='#F59E0B'
              chartConfig={{
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) => `${value}`,
                    },
                  },
                },
              }}
            />
          </Grid>

          {/* Team Performance - Stacked Chart */}
          <Grid item xs={12}>
            <DashboardColumn
              title='Team Performance Overview'
              data={teamPerformanceData}
              xField='team'
              yField='count'
              seriesField='status'
              stack={true}
              height={300}
              color={['#10B981', '#F59E0B', '#EF4444']}
              chartConfig={{
                legend: {
                  position: 'top',
                },
              }}
            />
          </Grid>
        </Grid>
      </div>

      {/* Mixed Layout Example */}
      <div>
        <Typography variant='h5' gutterBottom sx={{ mb: 2 }}>
          Mixed Layout Example
        </Typography>
        <Grid container spacing={3}>
          {/* Left side - KPIs */}
          <Grid item xs={12} md={4}>
            <Stack spacing={2}>
              <DashboardKpi
                icon={<GoogleIcon name='analytics' />}
                topCaption='Revenue Growth'
                value='+23.5%'
                badgeValue='vs Q1'
                badgeIconType='up'
                bottomCaption='quarterly increase'
              />
              <DashboardKpi
                icon={<GoogleIcon name='star' />}
                topCaption='Customer Rating'
                value='4.8/5'
                badgeValue='+0.2'
                badgeIconType='up'
                bottomCaption='improvement'
              />
            </Stack>
          </Grid>

          {/* Right side - Chart */}
          <Grid item xs={12} md={8}>
            <DashboardColumn
              title='Top Performing Services'
              data={serviceRevenueData.slice(0, 4)}
              xField='service'
              yField='amount'
              height={280}
              color='#8B5CF6'
              chartConfig={{
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) =>
                        `$${(value / 1000).toFixed(0)}K`,
                    },
                  },
                },
              }}
            />
          </Grid>
        </Grid>
      </div>

      {/* Usage Note */}
      <div
        style={{
          backgroundColor: '#f8f9fa',
          padding: '16px',
          borderRadius: '8px',
          border: '1px solid #e9ecef',
        }}
      >
        <Typography variant='h6' gutterBottom>
          💡 Integration Tips
        </Typography>
        <Typography variant='body2' component='div'>
          <ul>
            <li>
              Use <strong>DashboardKpiGrid</strong> for key metrics at the top
            </li>
            <li>
              Use <strong>DashboardColumn</strong> for detailed data
              visualization
            </li>
            <li>
              Use <strong>DashboardColumnGrid</strong> for multiple related
              charts
            </li>
            <li>Mix components in Material-UI Grid for flexible layouts</li>
            <li>Both component families share the same design system</li>
          </ul>
        </Typography>
      </div>
    </Stack>
  );
};

export default DashboardIntegrationExample;
