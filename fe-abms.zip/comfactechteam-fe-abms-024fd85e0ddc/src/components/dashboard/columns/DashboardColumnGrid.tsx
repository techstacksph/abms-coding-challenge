import React from 'react';
import { Grid } from '@mui/material';
import DashboardColumn, { DashboardColumnProps } from './DashboardColumn';

export interface DashboardColumnGridProps {
  data: DashboardColumnProps[]; // Required: Array of column chart data
  columnCount?: number; // Optional: Max 4 columns (default: 2 for charts)
  spacing?: number | string; // Optional: Grid spacing (default: '20px')

  // Grid-level styling
  containerStyle?: React.CSSProperties;
}

const DashboardColumnGrid: React.FC<DashboardColumnGridProps> = ({
  data,
  columnCount = 2,
  spacing = '20px',
  containerStyle = {},
}) => {
  // Ensure columnCount is between 1 and 4
  const validColumnCount = Math.min(Math.max(columnCount, 1), 4);

  // Calculate grid column size based on column count
  const getGridSize = () => {
    switch (validColumnCount) {
      case 1:
        return 12;
      case 2:
        return 6;
      case 3:
        return 4;
      case 4:
      default:
        return 3;
    }
  };

  const gridSize = getGridSize();

  return (
    <div style={containerStyle}>
      <Grid container spacing={spacing}>
        {data.map((columnData, index) => (
          <Grid item xs={12} sm={gridSize} key={index}>
            <DashboardColumn {...columnData} />
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default DashboardColumnGrid;
