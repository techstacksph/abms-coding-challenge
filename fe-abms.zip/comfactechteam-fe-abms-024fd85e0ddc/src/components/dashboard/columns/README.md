# Dashboard Column Chart Components

A set of reusable, customizable column chart components built with Ant Design Charts, following the same pattern as the Dashboard KPI components.

## Components

### `DashboardColumn`

A single column chart component with extensive customization options.

### `DashboardColumnGrid`

A grid layout component for displaying multiple column charts in a responsive layout.

## Installation & Dependencies

These components use the following dependencies (already included in the project):

- `@ant-design/charts` - For chart rendering
- `@mui/material` - For layout components
- `styled-components` - For custom styling

## Basic Usage

### Single Column Chart

```tsx
import { DashboardColumn } from '@/components/dashboard/columns';

const data = [
  { service: 'General Office Cleaning', amount: 195000 },
  { service: 'Deep Cleaning', amount: 140000 },
  { service: 'Carpet Cleaning', amount: 25000 },
  { service: 'Floor Care', amount: 70000 },
];

function MyComponent() {
  return (
    <DashboardColumn
      title='Service Revenue'
      subtitle='Revenue by service type'
      data={data}
      xField='service'
      yField='amount'
      height={300}
      color='#4F46E5'
    />
  );
}
```

### Multiple Charts in Grid

```tsx
import { DashboardColumnGrid } from '@/components/dashboard/columns';

const chartData = [
  {
    title: 'Service Revenue',
    data: serviceData,
    xField: 'service',
    yField: 'amount',
    height: 250,
    color: '#8B5CF6',
  },
  {
    title: 'Monthly Trend',
    data: monthlyData,
    xField: 'month',
    yField: 'revenue',
    height: 250,
    color: '#06B6D4',
  },
];

function Dashboard() {
  return (
    <DashboardColumnGrid data={chartData} columnCount={2} spacing='24px' />
  );
}
```

## Props Reference

### DashboardColumn Props

| Prop            | Type                    | Default      | Description                       |
| --------------- | ----------------------- | ------------ | --------------------------------- |
| `title`         | `string`                | -            | Chart title                       |
| `subtitle`      | `string`                | -            | Chart subtitle/description        |
| `data`          | `DashboardColumnData[]` | **Required** | Chart data array                  |
| `xField`        | `string`                | **Required** | X-axis field name                 |
| `yField`        | `string`                | **Required** | Y-axis field name                 |
| `seriesField`   | `string`                | -            | Field for grouping/series         |
| `colorField`    | `string`                | -            | Field for color mapping           |
| `height`        | `number`                | `300`        | Chart height in pixels            |
| `width`         | `string`                | `'100%'`     | Chart width                       |
| `stack`         | `boolean \| object`     | `false`      | Enable stacked columns            |
| `group`         | `boolean \| object`     | `false`      | Enable grouped columns            |
| `percent`       | `boolean`               | `false`      | Show as percentage (for stacked)  |
| `color`         | `string \| string[]`    | `'#4F46E5'`  | Column colors                     |
| `columnStyle`   | `object`                | -            | Column styling options            |
| `chartConfig`   | `Partial<ColumnConfig>` | -            | Ant Design Charts config override |
| `cardPadding`   | `string`                | `'24px'`     | Card padding                      |
| `cardStyle`     | `React.CSSProperties`   | -            | Card styling                      |
| `onReady`       | `(chart: any) => void`  | -            | Chart ready callback              |
| `onColumnClick` | `(data: any) => void`   | -            | Column click handler              |

### DashboardColumnGrid Props

| Prop             | Type                     | Default      | Description                   |
| ---------------- | ------------------------ | ------------ | ----------------------------- |
| `data`           | `DashboardColumnProps[]` | **Required** | Array of chart configurations |
| `columnCount`    | `number`                 | `2`          | Number of columns (1-4)       |
| `spacing`        | `number \| string`       | `'20px'`     | Grid spacing                  |
| `containerStyle` | `React.CSSProperties`    | -            | Container styling             |

## Chart Types & Examples

### 1. Basic Column Chart

Simple single-series column chart.

```tsx
<DashboardColumn
  title='Service Revenue'
  data={[
    { service: 'Cleaning', amount: 195000 },
    { service: 'Maintenance', amount: 140000 },
  ]}
  xField='service'
  yField='amount'
  color='#4F46E5'
/>
```

### 2. Grouped Column Chart

Compare multiple series side by side.

```tsx
<DashboardColumn
  title='Revenue vs Target'
  data={[
    { month: 'Jan', type: 'Revenue', value: 120000 },
    { month: 'Jan', type: 'Target', value: 100000 },
    { month: 'Feb', type: 'Revenue', value: 135000 },
    { month: 'Feb', type: 'Target', value: 110000 },
  ]}
  xField='month'
  yField='value'
  seriesField='type'
  group={true}
  color={['#4F46E5', '#10B981']}
/>
```

### 3. Stacked Column Chart

Stack multiple series on top of each other.

```tsx
<DashboardColumn
  title='Task Status by Team'
  data={[
    { team: 'Team A', count: 45, status: 'Completed' },
    { team: 'Team A', count: 12, status: 'Pending' },
    { team: 'Team A', count: 3, status: 'Overdue' },
  ]}
  xField='team'
  yField='count'
  seriesField='status'
  stack={true}
  color={['#10B981', '#F59E0B', '#EF4444']}
/>
```

### 4. Percentage Stacked Chart

Show proportional distribution.

```tsx
<DashboardColumn
  title='Performance Distribution'
  data={stackedData}
  xField='team'
  yField='count'
  seriesField='status'
  stack={true}
  percent={true}
  chartConfig={{
    axis: {
      y: {
        label: {
          formatter: (value: number) => `${(value * 100).toFixed(0)}%`,
        },
      },
    },
  }}
/>
```

## Advanced Customization

### Custom Formatting

```tsx
<DashboardColumn
  data={data}
  xField='service'
  yField='amount'
  chartConfig={{
    axis: {
      y: {
        label: {
          formatter: (value: number) => `$${(value / 1000).toFixed(0)}K`,
        },
      },
    },
    tooltip: {
      formatter: (datum: any) => ({
        name: 'Revenue',
        value: `$${(datum.amount / 1000).toFixed(0)}K`,
      }),
    },
  }}
/>
```

### Custom Styling

```tsx
<DashboardColumn
  data={data}
  xField='service'
  yField='amount'
  cardStyle={{
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
  }}
  columnStyle={{
    stroke: '#ffffff',
    strokeWidth: 2,
  }}
  color='#ffffff'
/>
```

### Event Handling

```tsx
<DashboardColumn
  data={data}
  xField='service'
  yField='amount'
  onColumnClick={data => {
    console.log('Clicked column:', data);
    // Handle click event
  }}
  onReady={chart => {
    console.log('Chart ready:', chart);
    // Chart instance available for further customization
  }}
/>
```

## Data Format

The `data` prop expects an array of objects where each object represents a data point:

```typescript
interface DashboardColumnData {
  [key: string]: string | number;
}

// Example data formats:

// Basic data
const basicData = [
  { category: 'A', value: 100 },
  { category: 'B', value: 200 },
];

// Grouped/Stacked data
const groupedData = [
  { category: 'A', value: 100, series: 'Series 1' },
  { category: 'A', value: 150, series: 'Series 2' },
  { category: 'B', value: 200, series: 'Series 1' },
  { category: 'B', value: 180, series: 'Series 2' },
];
```

## Responsive Design

The components are fully responsive:

- **DashboardColumn**: Automatically adjusts to container width
- **DashboardColumnGrid**: Uses Material-UI Grid system with breakpoints
  - `xs={12}`: Full width on extra small screens
  - `sm={gridSize}`: Responsive columns on small screens and up

## Integration with Existing Dashboard

These components follow the same patterns as the existing `DashboardKpi` components:

1. **Similar API**: Consistent prop naming and structure
2. **Same Styling**: Uses the same design tokens and card styling
3. **Grid Layout**: Compatible grid system for mixed layouts
4. **TypeScript**: Full type safety and IntelliSense support

## Performance Considerations

- **Data Memoization**: Consider memoizing large datasets
- **Chart Instances**: Use `onReady` callback for chart instance management
- **Lazy Loading**: For large dashboards, consider lazy loading charts

## Troubleshooting

### Common Issues

1. **Chart not rendering**: Ensure `@ant-design/charts` is installed
2. **Data not showing**: Verify `xField` and `yField` match your data structure
3. **Styling conflicts**: Check for CSS conflicts with existing styles

### Debug Mode

Enable debug mode by adding to chartConfig:

```tsx
chartConfig={{
  // ... other config
  debug: true,
}}
```

## Examples

See `examples.tsx` for comprehensive usage examples covering all chart types and customization options.

For a complete interactive demo, visit `/dashboard-columns` in your application.
