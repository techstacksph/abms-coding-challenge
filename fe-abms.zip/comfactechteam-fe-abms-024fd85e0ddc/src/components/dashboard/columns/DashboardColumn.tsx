import React from 'react';
// import { Column, ColumnConfig } from '@ant-design/plots';
import { Column, ColumnConfig } from '@ant-design/charts';
import { Stack, Divider } from '@mui/material';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { axisConfig } from '@/config/chartConfig';

const titleCss = `
color: var(--Colors-text-primary, #090A0B);
font-family: "Hanken Grotesk";
font-size: 16px;
font-style: normal;
font-weight: 600;
line-height: 24px;
`;

export interface DashboardColumnData {
  [key: string]: string | number | React.ReactNode;
}

export interface DashboardColumnProps {
  title?: string;
  data: DashboardColumnData[];
  xField: string;
  yField: string;
  seriesField?: string;
  colorField?: string;
  height?: number;
  width?: string;

  // Chart customization options
  stack?: boolean | object;
  group?: boolean | object;
  percent?: boolean;

  // Styling options
  color?: string | string[];
  columnStyle?: object;

  // Axis configuration options
  axis?: object;
  xAxis?: object;
  yAxis?: object;

  // Interaction configuration
  interaction?: object;

  // Advanced chart configuration override (non-styling properties)
  chartConfig?: Partial<ColumnConfig & { [key: string]: any }>;

  // Card styling
  cardPadding?: string;
  cardStyle?: React.CSSProperties;

  // Event handlers
  onReady?: (chart: any) => void;
  onColumnClick?: (data: any) => void;
}

const DashboardColumn: React.FC<DashboardColumnProps> = ({
  title,
  data,
  xField,
  yField,
  seriesField,
  colorField,
  height = 300,
  width = '100%',
  stack = false,
  group = false,
  percent = false,
  color,
  columnStyle,
  axis,
  xAxis,
  yAxis,
  interaction,
  chartConfig = {},
  cardPadding = '12px 20px',
  cardStyle = {},
  onReady,
  onColumnClick,
}) => {
  //   // const { chart } = chartRef.current;
  //   // const { document } = chart.getContext().canvas;
  //   // const group = document?.createElement('g', {});
  //   if (!isValueValid(text)) {
  //     return text;
  //   }
  //   // const label = document.createElement('text', {
  //   //   style: {
  //   //     text: convertCase(text, CaseType.SENTENCE_CASE),
  //   //     color: 'red',
  //   //     textAlign: 'center',
  //   //     fontFamily: 'Manrope',
  //   //     fontSize: '12px',
  //   //     fontStyle: 'normal',
  //   //     fontWeight: 400,
  //   //     lineHeight: '18px',
  //   //     textWrap: 'auto',
  //   //     // fill: 'gray',
  //   //     // textAlign: 'center',
  //   //     // transform: `translate(0, 25)`,
  //   //   },
  //   // });
  //   // group.appendChild(label);
  //   // return group;
  //   return convertCase(text, CaseType.SENTENCE_CASE);
  // };

  // Default chart configuration
  const defaultConfig: ColumnConfig = {
    data,
    xField,
    yField,
    seriesField,
    colorField,
    height,
    stack,
    group,
    percent,
    // color: 'red',
    // Default styling
    style: {
      fill: color || '#3137FD',
      maxWidth: 48,
      radiusTopLeft: 4,
      radiusTopRight: 4,
      ...columnStyle,
    },
    axis: {
      x: {
        ...axisConfig.x,
        ...xAxis,
      },
      y: {
        ...axisConfig.y,
        // labelFormatter: (text: string) => {
        //   return isValueValid(text) && typeof text === 'string'
        //     ? convertCase(text, CaseType.SENTENCE_CASE)
        //     : text;
        // },
        ...yAxis,
      },
      ...axis,
    },

    // Default interaction
    interaction: {
      tooltip: {
        shared: true,
        crosshairs: false,
      },
      ...interaction,
    },

    // Default theme
    theme: 'light',

    // Event handlers
    onReady: onReady,

    // Override with custom config
    ...chartConfig,
  };

  // Handle column click if provided
  if (onColumnClick) {
    defaultConfig.interaction = {
      ...defaultConfig.interaction,
      elementClick: onColumnClick,
    };
  }

  return (
    <Card
      padding={cardPadding}
      $css={`
        background: white;
        border: 1px solid #E5E7EB;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
        height: auto;
        width: ${width};
        ${Object.entries(cardStyle)
          .map(([key, value]) => `${key}: ${value};`)
          .join(' ')}
      `}
    >
      <Stack spacing={0}>
        {/* Header Section */}
        {title && (
          <>
            <div style={{ padding: '0 0 16px 0' }}>
              <Text $css={titleCss}>{title}</Text>
            </div>
            <Divider sx={{ margin: '0 -20px 24px -20px' }} />
          </>
        )}

        {/* Chart Section */}
        <div style={{ width: '100%', height: `${height}px` }}>
          <Column {...defaultConfig} />
        </div>
      </Stack>
    </Card>
  );
};

export default DashboardColumn;
