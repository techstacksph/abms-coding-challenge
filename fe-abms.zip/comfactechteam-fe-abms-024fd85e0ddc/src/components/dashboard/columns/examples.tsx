import React from 'react';
import { Stack } from '@mui/material';
import { DashboardColumn, DashboardColumnGrid } from './index';

// Sample data matching the screenshot
const serviceTypeData = [
  { service: 'General Office\nCleaning', amount: 195000, category: 'Cleaning' },
  { service: 'Deep Cleaning', amount: 140000, category: 'Cleaning' },
  { service: 'Carpet\nCleaning', amount: 25000, category: 'Cleaning' },
  { service: 'Floor Care', amount: 70000, category: 'Cleaning' },
  { service: 'Window\nCleaning', amount: 75000, category: 'Cleaning' },
  { service: 'Waste\nManagement', amount: 95000, category: 'Management' },
  { service: 'Sanitization', amount: 165000, category: 'Cleaning' },
];

// Monthly revenue data
const monthlyRevenueData = [
  { month: 'Jan', revenue: 120000, target: 100000 },
  { month: 'Feb', revenue: 135000, target: 110000 },
  { month: 'Mar', revenue: 98000, target: 105000 },
  { month: 'Apr', revenue: 145000, target: 115000 },
  { month: 'May', revenue: 162000, target: 120000 },
  { month: 'Jun', revenue: 178000, target: 125000 },
];

// Team performance data
const teamPerformanceData = [
  { team: 'Team A', completed: 45, pending: 12, overdue: 3 },
  { team: 'Team B', completed: 38, pending: 8, overdue: 5 },
  { team: 'Team C', completed: 52, pending: 15, overdue: 2 },
  { team: 'Team D', completed: 41, pending: 10, overdue: 4 },
];

// Stacked data for team performance
const stackedTeamData = teamPerformanceData.flatMap(item => [
  { team: item.team, count: item.completed, status: 'Completed' },
  { team: item.team, count: item.pending, status: 'Pending' },
  { team: item.team, count: item.overdue, status: 'Overdue' },
]);

export const DashboardColumnExamples: React.FC = () => {
  return (
    <Stack spacing={4} sx={{ padding: 3 }}>
      {/* Example 1: Basic Column Chart */}
      <div>
        <h2>Example 1: Basic Service Type Revenue (Single Column)</h2>
        <DashboardColumn
          title='Service Type Revenue'
          data={serviceTypeData}
          xField='service'
          yField='amount'
          height={400}
          color='#3137FD'
          chartConfig={{
            axis: {
              y: {
                label: {
                  formatter: (value: number) =>
                    `$${(value / 1000).toFixed(0)}K`,
                },
              },
            },
            tooltip: {
              formatter: (datum: any) => ({
                name: 'Revenue',
                value: `$${(datum.amount / 1000).toFixed(0)}K`,
              }),
            },
          }}
        />
      </div>

      {/* Example 2: Grouped Column Chart */}
      <div>
        <h2>Example 2: Monthly Revenue vs Target (Grouped)</h2>
        <DashboardColumn
          title='Monthly Performance'
          data={[
            ...monthlyRevenueData.map(item => ({
              ...item,
              type: 'Revenue',
              value: item.revenue,
            })),
            ...monthlyRevenueData.map(item => ({
              ...item,
              type: 'Target',
              value: item.target,
            })),
          ]}
          xField='month'
          yField='value'
          seriesField='type'
          group={true}
          height={350}
          color={['#4F46E5', '#10B981']}
          chartConfig={{
            axis: {
              y: {
                label: {
                  formatter: (value: number) =>
                    `$${(value / 1000).toFixed(0)}K`,
                },
              },
            },
          }}
        />
      </div>

      {/* Example 3: Stacked Column Chart */}
      <div>
        <h2>Example 3: Team Performance (Stacked)</h2>
        <DashboardColumn
          title='Team Task Status'
          data={stackedTeamData}
          xField='team'
          yField='count'
          seriesField='status'
          stack={true}
          height={300}
          color={['#10B981', '#F59E0B', '#EF4444']}
          chartConfig={{
            legend: {
              position: 'top',
            },
          }}
        />
      </div>

      {/* Example 4: Column Grid Layout */}
      <div>
        <h2>Example 4: Multiple Charts in Grid Layout</h2>
        <DashboardColumnGrid
          columnCount={2}
          spacing='24px'
          data={[
            {
              title: 'Service Revenue',
              data: serviceTypeData.slice(0, 4),
              xField: 'service',
              yField: 'amount',
              height: 250,
              color: '#8B5CF6',
              chartConfig: {
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) =>
                        `$${(value / 1000).toFixed(0)}K`,
                    },
                  },
                },
              },
            },
            {
              title: 'Monthly Trend',
              data: monthlyRevenueData,
              xField: 'month',
              yField: 'revenue',
              height: 250,
              color: '#06B6D4',
              chartConfig: {
                axis: {
                  y: {
                    label: {
                      formatter: (value: number) =>
                        `$${(value / 1000).toFixed(0)}K`,
                    },
                  },
                },
              },
            },
          ]}
        />
      </div>

      {/* Example 5: Custom Styling and Events */}
      <div>
        <h2>Example 5: Custom Styling with Click Events</h2>
        <DashboardColumn
          title='Interactive Service Chart'
          data={serviceTypeData}
          xField='service'
          yField='amount'
          height={350}
          cardPadding='32px'
          cardStyle={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
          }}
          columnStyle={{
            stroke: '#ffffff',
            strokeWidth: 2,
          }}
          color='#ffffff'
          onColumnClick={(data: any) => {
            alert(
              `Clicked on ${data.data.service}: $${(data.data.amount / 1000).toFixed(0)}K`
            );
          }}
          chartConfig={{
            axis: {
              x: {
                label: {
                  style: { fill: '#ffffff' },
                },
                line: { stroke: '#ffffff' },
                tick: { stroke: '#ffffff' },
              },
              y: {
                label: {
                  style: { fill: '#ffffff' },
                  formatter: (value: number) =>
                    `$${(value / 1000).toFixed(0)}K`,
                },
                line: { stroke: '#ffffff' },
                tick: { stroke: '#ffffff' },
                grid: { stroke: 'rgba(255,255,255,0.2)' },
              },
            },
            tooltip: {
              domStyles: {
                'g2-tooltip': {
                  background: 'rgba(0,0,0,0.8)',
                  color: '#ffffff',
                },
              },
            },
          }}
        />
      </div>

      {/* Example 6: Percentage Stacked Chart */}
      <div>
        <h2>Example 6: Percentage Stacked Chart</h2>
        <DashboardColumn
          title='Team Performance Distribution'
          data={stackedTeamData}
          xField='team'
          yField='count'
          seriesField='status'
          stack={true}
          percent={true}
          height={300}
          color={['#10B981', '#F59E0B', '#EF4444']}
          chartConfig={{
            axis: {
              y: {
                label: {
                  formatter: (value: number) => `${(value * 100).toFixed(0)}%`,
                },
              },
            },
            legend: {
              position: 'bottom',
            },
          }}
        />
      </div>
    </Stack>
  );
};

export default DashboardColumnExamples;
