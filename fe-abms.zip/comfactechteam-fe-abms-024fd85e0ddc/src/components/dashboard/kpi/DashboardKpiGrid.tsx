import React from 'react';
import { Grid } from '@mui/material';
import DashboardKpi, { DashboardKpiProps } from './DashboardKpi';

export interface DashboardKpiGridProps {
  data: DashboardKpiProps[]; // Required: Array of KPI data
  columnCount?: number; // Optional: Max 4 columns (default: 4)
  spacing?: number | string; // Optional: Grid spacing (default: 3)
  iconPosition?: 'start' | 'end'; // Optional: icon position
  isForceColumn?: boolean;
  minHeight?: number | string; // Optional: min height (default: 120px)
  parentPadding?: string; // Optional: min height (default: 24px)
}

const DashboardKpiGrid: React.FC<DashboardKpiGridProps> = ({
  data,
  columnCount = 4,
  spacing = '20px',
  iconPosition = 'start',
  isForceColumn = false,
  minHeight,
  parentPadding = '24px',
}) => {
  // Ensure columnCount is between 1 and 4
  const validColumnCount = Math.min(Math.max(columnCount, 1), 4);

  // Calculate grid column size based on column count
  const getGridSize = () => {
    switch (validColumnCount) {
      case 1:
        return 12;
      case 2:
        return 6;
      case 3:
        return 4;
      case 4:
      default:
        return 3;
    }
  };

  const gridSize = getGridSize();
  return (
    <Grid container spacing={spacing}>
      {data.map((kpiData, index) => (
        <Grid
          item
          xs={12}
          sm={isForceColumn ? columnCount : gridSize}
          key={index}
        >
          <DashboardKpi
            {...kpiData}
            iconPosition={iconPosition}
            minHeight={minHeight}
            parentPadding={parentPadding}
          />
        </Grid>
      ))}
    </Grid>
  );
};

export default DashboardKpiGrid;
