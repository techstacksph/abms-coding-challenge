import React from 'react';
import { Stack } from '@mui/material';
import { Tooltip } from 'antd';
import { Card } from '@/styled-components/components/layouts';
import { Text } from '@/styled-components/components/typography';
import { GoogleIcon } from '@/styled-components';

const captionCss = `
color: var(--Colors-text-secondary, #686D78);
font-size: 12px;
font-style: normal;
font-weight: 400;
line-height: 18px;
`;
export interface DashboardKpiProps {
  icon: React.ReactNode;
  topCaption?: string;
  bottomCaption?: string;
  value: string | number;
  badgeValue?: string | number;
  badgeIconType?: 'up' | 'down' | 'idle';
  badgeColor?: string;
  badgeBgColor?: string;
  customBadgeIcon?: React.ReactNode;
  tooltip?: string;
  iconPosition?: 'start' | 'end';
  minHeight?: string | number;
  parentPadding?: string;
  // Secondary badge (optional) - displayed between value and primary badge
  secondaryBadgeValue?: string | number;
  secondaryBadgeColor?: string;
  secondaryBadgeBgColor?: string;
}

const DashboardKpi: React.FC<DashboardKpiProps> = ({
  icon,
  topCaption,
  bottomCaption,
  value,
  badgeValue,
  badgeIconType = 'idle',
  badgeColor,
  badgeBgColor,
  customBadgeIcon,
  tooltip,
  iconPosition = 'start',
  secondaryBadgeValue,
  secondaryBadgeColor,
  secondaryBadgeBgColor,
  minHeight = '120px',
  parentPadding = '24px',
}) => {
  const getBadgeIcon = () => {
    if (customBadgeIcon) return customBadgeIcon;

    switch (badgeIconType) {
      case 'up':
        return (
          <GoogleIcon
            name='arrow_upward'
            $css='font-size: 16px; color: #31D48B;'
          />
        );
      case 'down':
        return (
          <GoogleIcon
            name='arrow_downward'
            $css='font-size: 16px; color: #EA3927;'
          />
        );
      case 'idle':
        return (
          <GoogleIcon
            name='arrows_outward'
            $css='font-size: 16px; color: #A7AAB2;'
          />
        );
      default:
        return null;
    }
  };

  const getBadgeColor = () => {
    if (badgeColor) return badgeColor;

    switch (badgeIconType) {
      case 'up':
        return '#31D48B'; // Green
      case 'down':
        return '#EF4444'; // Red
      case 'idle':
        return '#6B7280'; // Gray
      default:
        return '#6B7280';
    }
  };

  const getBadgeBgColor = () => {
    if (badgeBgColor) return badgeBgColor;

    switch (badgeIconType) {
      case 'up':
        return '#F1FCF8'; // Green
      case 'down':
        return '#FDF3F1'; // Red
      case 'idle':
        return '#F4F4F6'; // Gray
      default:
        return '#F4F4F6';
    }
  };

  const cardContent = (
    <Card
      padding={parentPadding}
      $css={`
        background: white;
        border: 1px solid #E5E7EB;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
        height: auto;
        min-height: ${minHeight};
      `}
    >
      <Stack direction='row' spacing={1} alignItems='center'>
        {/* Icon */}
        {iconPosition == 'start' && (
          <Stack
            sx={{
              fontSize: '24px',
              color: '#6B7280',
              alignItems: 'center',
              backgroundColor: '#F4F4F6 !important',
              borderRadius: '50%',
              padding: '8px !important',
            }}
          >
            {icon}
          </Stack>
        )}
        {/* Content Column */}
        <Stack spacing={0.5} sx={{ flex: 1 }}>
          {/* Top Caption */}
          {topCaption && <Text $css={captionCss}>{topCaption}</Text>}

          {/* Value and Badge Row */}
          <Stack
            direction='row'
            alignItems='center'
            // justifyContent='space-between'
            spacing={'4px'}
          >
            <Text
              $css={`
                color: var(--Colors-text-primary, #090A0B);
                text-align: center;
                font-family: "Hanken Grotesk";
                font-size: 24px;
                font-style: normal;
                font-weight: 500;
                line-height: 32px; /* 133.333% */
              `}
            >
              {value}
            </Text>

            {/* Secondary Badge (optional) */}
            {secondaryBadgeValue && (
              <Stack
                direction='row'
                alignItems='center'
                sx={{
                  padding: '4px 8px',
                  fontSize: '14px',
                  fontWeight: 500,
                  borderRadius: '20px',
                  backgroundColor: secondaryBadgeBgColor || '#F4F4F6',
                  color: secondaryBadgeColor || '#686D78',
                  marginRight: '4px',
                }}
              >
                <Text
                  $css={`
                  color: ${secondaryBadgeColor || '#686D78'};
                  font-family: "Hanken Grotesk";
                  font-size: 12px;
                  font-style: normal;
                  font-weight: 400;
                  line-height: 18px;
                `}
                >
                  {secondaryBadgeValue}
                </Text>
              </Stack>
            )}

            {/* Badge */}
            {badgeValue && (
              <Stack
                direction='row'
                alignItems='center'
                sx={{
                  padding: '4px 8px',
                  color: getBadgeColor(),
                  fontSize: '14px',
                  fontWeight: 500,
                  borderRadius: '20px',
                  backgroundColor: getBadgeBgColor(),
                  marginRight: '4px',
                }}
              >
                {getBadgeIcon()}
                <Text
                  $css={`
                  color: var(--Colors-text-primary, #090A0B);
                  font-family: "Hanken Grotesk";
                  font-size: 12px;
                  font-style: normal;
                  font-weight: 400;
                  line-height: 18px; /* 150% */
                `}
                >
                  {badgeValue}
                </Text>
              </Stack>
            )}
          </Stack>

          {/* Bottom Caption */}
          {bottomCaption && <Text $css={captionCss}>{bottomCaption}</Text>}
        </Stack>

        {/* Icon */}
        {iconPosition == 'end' && (
          <Stack
            sx={{
              fontSize: '24px',
              color: '#6B7280',
              alignItems: 'center',
              backgroundColor: '#F4F4F6 !important',
              borderRadius: '50%',
              padding: '8px !important',
            }}
          >
            {icon}
          </Stack>
        )}
      </Stack>
    </Card>
  );

  return tooltip ? (
    <Tooltip title={tooltip} placement='top'>
      {cardContent}
    </Tooltip>
  ) : (
    cardContent
  );
};

export default DashboardKpi;
