import React from 'react';

import { Text } from '@/styled-components';

const CellClamp = ({ text, lines = 4 }: { text?: string; lines?: number }) => {
  if (!text) return null;

  return (
    <Text
      $css={`
        overflow: hidden;
        display: -webkit-box;
        line-clamp: ${lines}; 
        -webkit-line-clamp: ${lines};
        -webkit-box-orient: vertical;
      `}
    >
      {text}
    </Text>
  );
};

export default CellClamp;
