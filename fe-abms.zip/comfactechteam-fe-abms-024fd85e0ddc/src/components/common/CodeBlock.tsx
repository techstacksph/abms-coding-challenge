import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

export interface CodeBlockProps {
  children: string;
  title: string;
  backgroundColor?: string;
  titleColor?: string;
  fontSize?: string;
  padding?: number;
}

const CodeBlock: React.FC<CodeBlockProps> = ({
  children,
  title,
  backgroundColor = '#f5f5f5',
  titleColor = '#1976d2',
  fontSize = '14px',
  padding = 2,
}) => (
  <Box sx={{ marginY: 2 }}>
    <Typography variant='h6' sx={{ marginBottom: 1, color: titleColor }}>
      {title}
    </Typography>
    <Paper
      sx={{
        padding,
        backgroundColor,
        fontFamily: 'monospace',
        fontSize,
        overflow: 'auto',
      }}
    >
      <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{children}</pre>
    </Paper>
  </Box>
);

export default CodeBlock;
