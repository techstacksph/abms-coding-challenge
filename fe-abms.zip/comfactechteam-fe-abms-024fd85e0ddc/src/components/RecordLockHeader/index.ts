export { RecordLockHeader } from './RecordLockHeader';
export type { RecordLockHeaderProps } from './RecordLockHeader';
