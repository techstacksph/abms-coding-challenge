import React from 'react';
import { Typography } from 'antd';
import styled from 'styled-components';
import { RecordLockIndicator } from '../RecordLockIndicator/RecordLockIndicator';
import { useRecordLockContext } from '@/contexts/RecordLockContext';

const { Title } = Typography;

const HeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
`;

export interface RecordLockHeaderProps {
  /**
   * Header text to display (e.g., "Edit Account", "Edit Job")
   */
  children: React.ReactNode;

  /**
   * Ant Design Title level (1-5)
   * Default: 4
   */
  level?: 1 | 2 | 3 | 4 | 5;

  /**
   * Additional CSS class name
   */
  className?: string;

  /**
   * Additional inline styles
   */
  style?: React.CSSProperties;
}

/**
 * Header component that automatically shows lock icon when used within RecordLockProvider
 *
 * @example
 * ```tsx
 * <RecordLockProvider recordType="account" recordId="123">
 *   <RecordLockHeader level={3}>Edit Account</RecordLockHeader>
 *   <Form>...</Form>
 * </RecordLockProvider>
 * ```
 */
export const RecordLockHeader: React.FC<RecordLockHeaderProps> = ({
  children,
  level = 4,
  className,
  style,
}) => {
  const { lockInfo } = useRecordLockContext();

  return (
    <HeaderWrapper className={className} style={style}>
      <Title level={level} style={{ margin: 0 }}>
        {children}
      </Title>
      <RecordLockIndicator lockInfo={lockInfo} />
    </HeaderWrapper>
  );
};
