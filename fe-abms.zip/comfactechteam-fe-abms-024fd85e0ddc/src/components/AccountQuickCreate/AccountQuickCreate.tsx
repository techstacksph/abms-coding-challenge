import React, { useRef, useEffect, useState } from 'react';

import {
  FormSection,
  Icon,
  MaterialIcon,
  Form,
  useModal,
  FormButtons,
  FormTitle,
  useSnackbar,
} from '@/styled-components';

// import environment from '@/config/environment';
import { useProfile } from '@/mfe-utilities';
import { CREATE_ACCOUNT } from '@/graphql/accounts.gql';
import { ALL_AREAS } from '@/graphql/area.gql';
import { ALL_COUNTRIES } from '@/graphql/country.gql';
import { ALL_LOCATIONS } from '@/graphql/location.gql';
import { GET_WORKFLOW_STATUS } from '@/graphql/module.gql';
import useMutation from '@/hooks/useMutation';
import useQuery from '@/hooks/useQuery';
import AccountModel, { AccountTypeEnum } from '@/models/AccountModel';
import AreaModel from '@/models/AreaModel';
import CountryModel from '@/models/CountryModel';
import LocationModel from '@/models/LocationModel';
import WorkflowStatusModel from '@/models/WorkflowStatusModel';
import { Box, Stack } from '@mui/material';
import { setFieldValues } from '@/services/findaddress.service';
import { FindAddressFields } from '@/typings/find.address.types';
import { labelSpan, required } from '@/utils/inputProps.util';
import { errorMessages } from '@/utils/messages.utils';

import { Form as AntdForm } from 'antd';

import BillingAddress from './common/components/BillingAddress';
import PhysicalAddress from './common/components/PhysicalAddress';

// const { TENANT_PREFIX } = environment;

// Account fields for the quick create form
const fields1 = () => ({
  title: 'Account details',
  showDivider: false,
  fields: [
    {
      title: 'Account name',
      type: 'text' as const,
      field: 'name',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      inputProps: {},
    },
  ],
});

const fields2 = ({ locations }) => ({
  title: 'Related to',
  showDivider: false,
  fields: [
    {
      title: 'Location',
      type: 'select' as const,
      field: 'locationId',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
      inputProps: {
        placeholder: 'Select',
        options:
          locations?.map(location => ({
            label: location.name,
            value: location.id,
          })) || [],
      },
    },
  ],
});

export const AccountQuickCreateNew = ({
  handleSuccess,
  defaultLocationId,
  $sx = {},
}: {
  handleSuccess?: (val) => void;
  defaultLocationId?: string;
  $sx?: React.CSSProperties;
}) => {
  const [form] = AntdForm.useForm();
  const { snackbar } = useSnackbar();

  // Set initial form values with proper types
  useEffect(() => {
    form.setFieldsValue({
      isSameAsPhysicalAddress: false,
    });
  }, []);

  const profile = useProfile();
  const { data: status } = useQuery<Array<WorkflowStatusModel>>({
    query: GET_WORKFLOW_STATUS,
    options: {
      variables: {
        code: 'account',
      },
    },
  });

  const { data: dbCountries } = useQuery<Array<CountryModel>>({
    query: ALL_COUNTRIES,
    options: {
      variables: {
        sortArg: [
          {
            field: 'name',
            direction: 'asc',
          },
        ],
      },
    },
  });

  const { data: dbAreas } = useQuery<Array<AreaModel>>({
    query: ALL_AREAS,
    options: {
      variables: {
        sortArg: [
          {
            field: 'area',
            direction: 'asc',
          },
        ],
      },
    },
    transformData: (data: AreaModel[]) => {
      return data?.filter(item => item.area);
    },
  });

  const active = status && status?.filter(s => s.name === 'Active')?.[0];
  const [createAccount] = useMutation({
    query: CREATE_ACCOUNT,
    disableAlert: true,
    onSuccess: (value: AccountModel) => {
      handleSuccess(value);
      closeModal();
      form.resetFields();

      snackbar({
        type: 'success',
        message: `${value.name} created successfully.`,
      });
    },
    onError: err => {
      const graphQLError = err.graphQLErrors?.[0];
      const errorCode = graphQLError?.code;
      const field = graphQLError?.extensions.field;

      if (errorCode === 'UNIQUE_KEY_CONSTRAINT_VIOLATION') {
        // Comprehensive field mapping for all account fields
        const fieldMapping = {
          // Account details
          name: 'name',
          accountName: 'name',
          account_name: 'name',
          legalName: 'legalName',
          legal_name: 'legalName',
          website: 'website',
          bankAccountNo: 'bankAccountNo',
          bank_account_no: 'bankAccountNo',
          gst: 'gst',
          nzbn: 'nzbn',

          // Physical address fields
          pFindAddress: 'pFindAddress',
          pStreetAddress: 'pStreetAddress',
          pSuburb: 'pSuburb',
          pAreaId: 'pAreaId',
          pCity: 'pCity',
          pRegion: 'pRegion',
          pPostalCode: 'pPostalCode',
          pCountryId: 'pCountryId',

          // Billing address fields
          bFindAddress: 'bFindAddress',
          bStreetAddress: 'bStreetAddress',
          bSuburb: 'bSuburb',
          bAreaId: 'bAreaId',
          bCity: 'bCity',
          bRegion: 'bRegion',
          bPostalCode: 'bPostalCode',
          bCountryId: 'bCountryId',

          // Common variations
          email: 'email',
          phone: 'phone',
          mobile: 'mobile',
        };

        const formFieldName = fieldMapping[field] || field || 'name';
        const fieldValue = form.getFieldValue(formFieldName) || 'This value';

        form.setFields([
          {
            name: formFieldName,
            errors: [
              `${fieldValue} already exists. This field must be unique.`,
            ],
          },
        ]);

        snackbar({
          type: 'error',
          message: 'Error: Invalid data.',
        });
      } else {
        const fieldName = field || 'name';
        const fieldValue = form.getFieldValue(fieldName) || 'This value';

        form.setFields([
          {
            name: fieldName,
            errors: [
              `${fieldValue} already exists. This field must be unique.`,
            ],
          },
        ]);

        snackbar({
          type: 'error',
          message: 'Error: Invalid data.',
        });
      }
      return;
    },
  });

  // Google Places API Configuration (same as MainForm)
  const autocompleteOptions = {
    fields: ['geometry', 'address_components', 'place_id'],
    componentRestrictions: { country: 'nz' },
  };

  // Refs for address input fields
  const pFindAddressRef = useRef(null);
  const bFindAddressRef = useRef(null);

  // Google Places autocomplete instances
  const [placeAutocompletePhysical, setPlaceAutocompletePhysical] =
    useState<google.maps.places.Autocomplete | null>(null);

  const [placeAutocompleteBilling, setPlaceAutocompleteBilling] =
    useState<google.maps.places.Autocomplete | null>(null);

  // Address field mappings (same as MainForm)
  const pAddressFields: FindAddressFields = {
    findAddress: 'pFindAddress', // field name of respective find address field
    street: 'pStreetAddress', // field name of respective street address field
    city: 'pCity', // ...and so on
    region: 'pRegion',
    postal: 'pPostalCode',
    suburb: 'pSuburb',
    country: 'pCountryId',
    longitude: 'pLongitude',
    latitude: 'pLatitude',
    placeId: 'pPlaceId',
  };

  const bAddressFields: FindAddressFields = {
    findAddress: 'bFindAddress',
    street: 'bStreetAddress',
    city: 'bCity',
    region: 'bRegion',
    postal: 'bPostalCode',
    suburb: 'bSuburb',
    country: 'bCountryId',
    longitude: 'bLongitude',
    latitude: 'bLatitude',
    placeId: 'bPlaceId',
  };

  // Same as physical address field
  const isSameAsPhysicalAddressWatch = AntdForm.useWatch(
    'isSameAsPhysicalAddress',
    {
      form,
      preserve: true,
    }
  );

  // Convert to boolean if it's an array
  const isSameAsPhysicalAddress = Array.isArray(isSameAsPhysicalAddressWatch)
    ? isSameAsPhysicalAddressWatch.length > 0
    : Boolean(isSameAsPhysicalAddressWatch);

  // set value of pFindAddress to bFindAddress (same as MainForm)
  const setBFindAddressValue = () => {
    if (pFindAddressRef.current && bFindAddressRef.current) {
      bFindAddressRef.current.value = pFindAddressRef.current.value;

      // reinitialize bFindAddress autocomplete field so that
      // value from pFindAddress will be set to bFindAddress
      setPlaceAutocompleteBilling(
        new google.maps.places.Autocomplete(
          bFindAddressRef.current,
          autocompleteOptions
        )
      );
    }
  };

  // ON PLACE SELECT - Physical Address (same as MainForm)
  const onPlaceSelectPFindAddress = (place: google.maps.places.PlaceResult) => {
    // IF isSameAsPhysicalAddress IS CHECKED
    const isSameAsPhysical = form.getFieldValue('isSameAsPhysicalAddress');
    setFieldValues(
      place,
      pAddressFields,
      form,
      pFindAddressRef,
      undefined,
      dbCountries
    );

    if (place) {
      clearPhysicalAddressFieldErrors();
    }

    if (isSameAsPhysical?.length > 0) {
      setBFindAddressValue();
      onPlaceSelectBFindAddress(place);
    }
  };

  // ON PLACE SELECT - Billing Address (same as MainForm)
  const onPlaceSelectBFindAddress = (place: google.maps.places.PlaceResult) => {
    setFieldValues(
      place,
      bAddressFields,
      form,
      bFindAddressRef,
      undefined,
      dbCountries
    );

    if (place) {
      clearBillingAddressFieldErrors();
    }
  };

  const clearPhysicalAddressFieldErrors = () => {
    const allFields = [
      pAddressFields.suburb,
      pAddressFields.street,
      pAddressFields.city,
      pAddressFields.region,
      pAddressFields.postal,
      pAddressFields.country,
    ];

    const fieldUpdates = allFields.map(field => {
      const fieldValue = form.getFieldValue(field);
      return {
        name: field,
        errors: fieldValue ? [] : [],
      };
    });

    form.setFields(fieldUpdates);
  };

  const clearBillingAddressFieldErrors = () => {
    const allFields = [
      bAddressFields.suburb,
      bAddressFields.street,
      bAddressFields.city,
      bAddressFields.region,
      bAddressFields.postal,
      bAddressFields.country,
    ];

    const fieldUpdates = allFields.map(field => {
      const fieldValue = form.getFieldValue(field);
      return {
        name: field,
        errors: fieldValue ? [] : [],
      };
    });

    form.setFields(fieldUpdates);
  };

  // Add useEffect to synchronize addresses when "Same as physical address" is checked
  useEffect(() => {
    // IF isSameAsPhysicalAddress IS CHECKED
    if (isSameAsPhysicalAddress === true) {
      setBFindAddressValue();
    }
  }, [isSameAsPhysicalAddress]);

  // Ensure autocomplete instances are reinitialized when refs become available after modal reopen
  useEffect(() => {
    // Small delay to ensure refs are properly set after modal opens
    const timer = setTimeout(() => {
      if (
        pFindAddressRef.current &&
        !placeAutocompletePhysical &&
        window.google?.maps?.places
      ) {
        setPlaceAutocompletePhysical(
          new google.maps.places.Autocomplete(
            pFindAddressRef.current,
            autocompleteOptions
          )
        );
      }
      if (
        bFindAddressRef.current &&
        !placeAutocompleteBilling &&
        window.google?.maps?.places
      ) {
        setPlaceAutocompleteBilling(
          new google.maps.places.Autocomplete(
            bFindAddressRef.current,
            autocompleteOptions
          )
        );
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [
    pFindAddressRef.current,
    bFindAddressRef.current,
    placeAutocompletePhysical,
    placeAutocompleteBilling,
  ]);

  const pFindAddress = AntdForm.useWatch('pFindAddress', form);
  const pStreetAddress = AntdForm.useWatch('pStreetAddress', form);
  const pSuburb = AntdForm.useWatch('pSuburb', form);
  const pAreaId = AntdForm.useWatch('pAreaId', form);
  const pCity = AntdForm.useWatch('pCity', form);
  const pRegion = AntdForm.useWatch('pRegion', form);
  const pPostalCode = AntdForm.useWatch('pPostalCode', form);
  const pCountryId = AntdForm.useWatch('pCountryId', form);

  // Sync billing fields when any physical address field changes
  useEffect(() => {
    if (isSameAsPhysicalAddress === true) {
      // Properly sync fields with correct UUIDs for country IDs
      form.setFieldsValue({
        bFindAddress: pFindAddress,
        bStreetAddress: pStreetAddress,
        bSuburb: pSuburb,
        bAreaId: pAreaId,
        bCity: pCity,
        bRegion: pRegion,
        bPostalCode: pPostalCode,
        bCountryId: pCountryId, // Will be UUID from custom country field
      });

      // Also update the bFindAddressRef to match pFindAddressRef
      if (pFindAddressRef.current && bFindAddressRef.current) {
        bFindAddressRef.current.value = pFindAddressRef.current.value;
      }
    }
  }, [
    isSameAsPhysicalAddress,
    pFindAddress,
    pStreetAddress,
    pSuburb,
    pAreaId,
    pCity,
    pRegion,
    pPostalCode,
    pCountryId,
  ]);

  // Create custom country fields that use country ID instead of code
  const getCustomCountryFields = () => {
    // Create custom field configurations for physical and billing addresses
    const customPCountry = {
      fields: [
        {
          title: 'Country',
          type: 'select',
          field: 'pCountryId',
          required: true,
          props: {
            ...labelSpan,
            rules: [required],
          },
          inputProps: {
            placeholder: 'Select',
            options:
              dbCountries?.map(country => ({
                value: country.id, // Use ID instead of code
                label: country.name,
              })) || [],
          },
        },
      ],
    };

    const customBCountry = {
      fields: [
        {
          title: 'Country',
          type: 'select',
          field: 'bCountryId',
          required: true,
          props: {
            ...labelSpan,
            rules: [required],
          },
          inputProps: {
            placeholder: 'Select',
            options:
              dbCountries?.map(country => ({
                value: country.id, // Use ID instead of code
                label: country.name,
              })) || [],
          },
        },
      ],
    };

    return { customPCountry, customBCountry };
  };

  const { customPCountry, customBCountry } = getCustomCountryFields();

  // Complete cleanup function
  const performCompleteCleanup = () => {
    // Reset form completely
    form.resetFields();

    // Clear all form field errors
    const currentFields = form.getFieldsValue();
    if (currentFields && typeof currentFields === 'object') {
      form.setFields(
        Object.keys(currentFields).map(fieldName => ({
          name: fieldName,
          errors: [],
        }))
      );
    }

    // Clean up Google Places autocomplete instances and their event listeners
    if (placeAutocompletePhysical) {
      google.maps.event.clearInstanceListeners(placeAutocompletePhysical);
    }
    if (placeAutocompleteBilling) {
      google.maps.event.clearInstanceListeners(placeAutocompleteBilling);
    }

    // Clear Google Places autocomplete instances
    setPlaceAutocompletePhysical(null);
    setPlaceAutocompleteBilling(null);

    // Clear refs
    if (pFindAddressRef.current) {
      pFindAddressRef.current.value = '';
    }
    if (bFindAddressRef.current) {
      bFindAddressRef.current.value = '';
    }
  };

  const onFinish = async values => {
    values['statusId'] = active.id;
    values['locationId'] = profile?.location?.id;

    // Set default accountType to CUSTOMER
    values['accountType'] = AccountTypeEnum.CUSTOMER;

    // Convert isSameAsPhysicalAddress from array to boolean
    if (values.isSameAsPhysicalAddress !== undefined) {
      // Handle both array and direct boolean cases
      values.isSameAsPhysicalAddress = Array.isArray(
        values.isSameAsPhysicalAddress
      )
        ? values.isSameAsPhysicalAddress.length > 0
        : Boolean(values.isSameAsPhysicalAddress);
    }

    await createAccount({
      variables: {
        account: {
          ...values,
        },
      },
    });
  };

  const { data: dbLocations } = useQuery<Array<LocationModel>>({
    query: ALL_LOCATIONS,
  });

  const onFinishFailed = errorInfo => {
    const isRequiredError =
      errorInfo?.errorFields?.findIndex(
        errorField =>
          errorField?.errors?.findIndex(error => error?.includes('required')) >
          -1
      ) > -1;

    if (isRequiredError) {
      return snackbar({
        type: 'error',
        message: 'Missing required field(s).',
      });
    }

    snackbar({
      type: 'error',
      message: 'Error: Invalid data.',
    });
  };

  const [openModal, closeModal, contextModal] = useModal({
    title: 'New account',
    message: (
      <Box sx={{ button: { width: 120 }, width: '100%' }}>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFinishFailed}>
          <Stack direction='column' spacing={2}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
              <FormSection fields={fields1()} $css={'width: 100%;'} />
              <FormSection
                fields={fields2({ locations: dbLocations })}
                $css={'width: 100%;'}
              />
            </Stack>
            <FormTitle
              $css={
                'font-size: 18px; font-weight: 600; margin-bottom: -16px !important;'
              }
            >
              Address information
            </FormTitle>
            <Stack direction={{ xs: 'column', lg: 'row' }} spacing={3}>
              <PhysicalAddress
                countries={dbCountries}
                areas={dbAreas}
                customCountryField={customPCountry}
                placeAutocomplete={placeAutocompletePhysical}
                setPlaceAutocomplete={setPlaceAutocompletePhysical}
                pFindAddressRef={pFindAddressRef}
                bFindAddressRef={bFindAddressRef}
                isSameAsPhysicalAddress={isSameAsPhysicalAddress}
                autocompleteOptions={autocompleteOptions}
                onPlaceSelect={onPlaceSelectPFindAddress}
                form={form}
                data={{}}
              />
              <BillingAddress
                form={form}
                countries={dbCountries}
                areas={dbAreas}
                customCountryField={customBCountry}
                placeAutocomplete={placeAutocompleteBilling}
                setPlaceAutocomplete={setPlaceAutocompleteBilling}
                bFindAddressRef={bFindAddressRef}
                autocompleteOptions={autocompleteOptions}
                onPlaceSelect={onPlaceSelectBFindAddress}
                data={{}}
              />
            </Stack>
            <FormButtons
              saveAsDraft={false}
              onCancel={() => {
                performCompleteCleanup();
                closeModal();
              }}
              submitText='Save'
            />
          </Stack>
        </Form>
      </Box>
    ),
    modalProps: {
      modalProps: {
        $css: `[class*="modal-content"] {
          width: 1000px !important;
          height: auto !important;
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          padding: 20px;
        }`,
        style: {
          // Custom styles moved to style object
        },
        footer: null,
        onCancel: () => {
          performCompleteCleanup();
          closeModal();
        },
      },
    },
  });

  const handleOpenModal = () => {
    // Perform complete cleanup
    performCompleteCleanup();

    // Reset form values
    form.setFieldsValue({
      isSameAsPhysicalAddress: false,
      locationId: defaultLocationId,
    });

    // Small delay to ensure proper cleanup and reinitialization
    setTimeout(() => {
      // Set placeholders after cleanup
      if (pFindAddressRef.current) {
        pFindAddressRef.current.placeholder = 'Search for address';
        pFindAddressRef.current.value = '';
      }
      if (bFindAddressRef.current) {
        bFindAddressRef.current.placeholder = 'Search for address';
        bFindAddressRef.current.value = '';
      }

      openModal();
    }, 100);
  };

  return (
    <>
      {contextModal}
      <Box
        sx={{
          color: 'rgba(49, 55, 253, 1)',
          backgroundColor: '#FFFFFF',
          width: '40px',
          height: '40px',
          border: '1px solid rgba(49, 55, 253, 1)',
          padding: '8px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: '8px',
          marginTop: '12px',
          marginLeft: '15px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
            cursor: 'pointer',
          },
          ...$sx,
        }}
        onClick={handleOpenModal}
      >
        <Icon $css='rotate: -90deg;'>
          <MaterialIcon iconClass='material-icons' name='add' />
        </Icon>
      </Box>
    </>
  );
};

export default AccountQuickCreateNew;
