import React, { useEffect, useState } from 'react';

import { FormSection, Text } from '@/styled-components';

import GoogleApiLoader from '@/components/GoogleApiLoader';
// import environment from '@/config/environment';
import { Stack } from '@mui/material';
import { googleApiErrorMessages } from '@/utils/messages.utils';

// import { LoadScript } from '@react-google-maps/api';
import { Form as AntdForm } from 'antd';

import {
  bSuburbArea,
  bCityRegion,
  bPostalCode,
  bCountry,
  billAddress,
  sameAsPhysicalAddress,
} from '../fields';

// const GOOGLE_API_KEY = environment.GOOGLE_API_KEY;

const BillingAddress = ({
  countries,
  areas,
  form,
  customCountryField,
  placeAutocomplete,
  setPlaceAutocomplete,
  bFindAddressRef,
  autocompleteOptions,
  onPlaceSelect,
  data,
}) => {
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // Watch the isSameAsPhysicalAddress field to disable inputs when checked
  const isSameAsPhysicalAddress = AntdForm.useWatch('isSameAsPhysicalAddress', {
    form,
    preserve: true,
  });

  useEffect(() => {
    if (
      window.google &&
      isLoaded &&
      bFindAddressRef.current &&
      !placeAutocomplete
    ) {
      // INITIALIZE GOOGLE AUTOCOMPLETE
      const autocomplete = new google.maps.places.Autocomplete(
        bFindAddressRef.current,
        autocompleteOptions
      );
      setPlaceAutocomplete(autocomplete);

      // Set placeholder after autocomplete is initialized
      setTimeout(() => {
        if (bFindAddressRef.current) {
          bFindAddressRef.current.placeholder = 'Enter a location';
        }
      }, 100);
    }
  }, [window.google, isLoaded, placeAutocomplete, bFindAddressRef.current]);

  useEffect(() => {
    if (!placeAutocomplete) return;

    const listener = placeAutocomplete.addListener('place_changed', () => {
      const place = placeAutocomplete.getPlace();

      onPlaceSelect(place);
    });

    // Ensure placeholder is maintained after autocomplete is fully loaded
    setTimeout(() => {
      if (bFindAddressRef.current) {
        bFindAddressRef.current.placeholder = 'Enter a location';
      }
    }, 100);

    // Cleanup function to remove event listener
    return () => {
      if (listener && google?.maps?.event) {
        google.maps.event.removeListener(listener);
      }
    };
  }, [placeAutocomplete, onPlaceSelect]);

  useEffect(() => {
    // INTERCEPT CONSOLE ERRORS FOR GOOGLE ERRORS
    const console = window.console;
    if (!console) return;

    const intercept = (method: string) => {
      const original = console[method];
      console[method] = function (...args) {
        // do sneaky stuff
        if (original.apply) {
          if (args[0]) {
            Object.keys(googleApiErrorMessages).forEach(error => {
              if (args[0].indexOf(error) > -1) {
                form.setFields([
                  {
                    name: 'bFindAddress',
                    errors: [googleApiErrorMessages[error]],
                  },
                ]);

                return;
              }
            });
          }
          // Do this for normal browsers
          original.apply(console, args);
        } else {
          // Do this for IE
          const message = Array.prototype.slice.apply(args).join(' ');
          original(message);
        }
      };
    };
    const methods = ['error'];
    for (let i = 0; i < methods.length; i++) intercept(methods[i]);
  }, []);

  return (
    <>
      <Stack spacing={2} direction='column' sx={{ width: '100%' }}>
        <Stack
          direction='row'
          justifyContent='space-between'
          sx={{ width: '100%' }}
        >
          <Text
            $type='sm'
            weight='bold'
            $css={'font-size: 16px !important; font-weight: 600;'}
          >
            Billing address
          </Text>
          <FormSection
            fields={sameAsPhysicalAddress}
            $css={'[class*="item-control-input"] {min-height: 24px;}'}
          />
        </Stack>

        <div
          style={{
            opacity: isSameAsPhysicalAddress === true ? 0.6 : 1,
            pointerEvents: isSameAsPhysicalAddress === true ? 'none' : 'auto',
            width: '100%',
          }}
        >
          <FormSection
            fields={billAddress(
              // <LoadScript
              //   id="google-maps-api-script-loader"
              //   googleMapsApiKey={GOOGLE_API_KEY}
              //   libraries={libraries}
              //   onLoad={() => setIsLoaded(true)}
              // >
              <GoogleApiLoader onLoad={() => setIsLoaded(true)}>
                <input
                  name={'bFindAddress'}
                  className='find-address-input'
                  ref={bFindAddressRef}
                  placeholder='Enter a location'
                  defaultValue={data?.bFindAddress}
                  onChange={() => {
                    form.setFieldValue('bPlaceId', null);
                    form.setFieldValue('bFindAddress', null);
                  }}
                />
              </GoogleApiLoader>
              // </LoadScript>
            )}
            $css={
              'width: 100% !important; [class*="form-item"] { width: 100% !important; } [class*="form-item-control"] { width: 100% !important; } input, textarea { width: 100% !important; }'
            }
          />
          <Stack direction='row' spacing={2} sx={{ mt: 2, width: '100%' }}>
            <FormSection
              fields={bSuburbArea(areas)}
              $css={
                'flex: 1; width: calc(50% - 8px) !important; [class*="form-item"] { width: 100% !important; } [class*="form-item-control"] { width: 100% !important; } input, .ant-select { width: 100% !important; }'
              }
            />
            <FormSection
              fields={bCityRegion}
              $css={
                'flex: 1; width: calc(50% - 8px) !important; [class*="form-item"] { width: 100% !important; } [class*="form-item-control"] { width: 100% !important; } input { width: 100% !important; }'
              }
            />
          </Stack>
          <Stack direction='row' spacing={2} sx={{ mt: 2, width: '100%' }}>
            <FormSection
              fields={bPostalCode}
              $css={
                'flex: 0 0 calc(30% - 8px); width: calc(30% - 8px) !important; [class*="form-item"] { width: 100% !important; } [class*="form-item-control"] { width: 100% !important; } input { width: 100% !important; }'
              }
            />
            <FormSection
              fields={customCountryField || bCountry(countries)}
              $css={
                'flex: 0 0 calc(70% - 8px); width: calc(70% - 8px) !important; [class*="form-item"] { width: 100% !important; } [class*="form-item-control"] { width: 100% !important; } .ant-select { width: 100% !important; }'
              }
            />
          </Stack>
        </div>
      </Stack>
    </>
  );
};

export default BillingAddress;
