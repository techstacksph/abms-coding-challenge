import React from 'react';

import { InputFieldType } from '@/styled-components/types/input.types';
import AccountCodeModel from '@/models/AccountCodeModal';
import AccountModel, {
  AccountTypeEnum,
  FranchiseeTypeEnum,
} from '@/models/AccountModel';
import AreaModel from '@/models/AreaModel';
import ContactModel from '@/models/ContactModel';
import CountryModel from '@/models/CountryModel';
import Location from '@/models/Location';
import PriceListModel from '@/models/PriceListModel';
import Source from '@/models/Source';
import SupplierType from '@/models/SupplierType';
import User from '@/models/User';
import WorkflowStatusModel from '@/models/WorkflowStatusModel';
import { SearchComparator } from '@/typings/module.types';
import { formatDate } from '@/utils/date.utils';
import { toSentenceCase } from '@/utils/helper.utils';
import { labelSpan, required } from '@/utils/inputProps.util';

export const accountFields = {
  name: 'Account Name',
  accountType: 'Account Type',
};

export const accountDetails = (
  isFranchisee,
  isSupplier,
  isSubcontractor,
  formType
) => {
  const result = {
    title: 'Account details',
    showDivider: false,
    fields: [
      {
        title: 'Account type',
        type: 'select' as InputFieldType,
        field: 'accountType',
        required: true,
        disabled: formType === 'Edit',
        props: {
          ...labelSpan,
          rules: [required],
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
        inputProps: {
          placeholder: 'Select',
          options: [
            { label: 'Customer', value: AccountTypeEnum.CUSTOMER },
            { label: 'Franchisee', value: AccountTypeEnum.FRANCHISEE },
            { label: 'Supplier', value: AccountTypeEnum.SUPPLIER },
            { label: 'Subcontractor', value: AccountTypeEnum.SUBCONTRACTOR },
          ],
        },
      },
      {
        title: 'Account name',
        type: 'text' as InputFieldType,
        field: 'name',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
      {
        title: 'Legal name',
        type: 'text' as InputFieldType,
        field: 'legalName',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
      {
        title: 'Notes',
        type: 'textarea' as InputFieldType,
        field: 'notes',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
        inputProps: {
          autoSize: {
            minRows: 3,
          },
        },
      },
      {
        title: '',
        field: 'requiresPO',
        type: 'checkbox',
        props: {
          labelCol: {
            span: 0,
          },
        },
        inputProps: {
          options: [
            {
              label: 'Requires PO',
              value: true,
            },
          ],
        },
      },
    ],
  };

  if (isFranchisee || isSupplier || isSubcontractor) {
    const index = result.fields.findIndex(a => a.field == 'requiresPO');
    if (index > -1) {
      result.fields.splice(index, 1);
    }
  } else {
    const index = result.fields.findIndex(a => a.field == 'legalName');

    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const accountDetails2 = (isSupplier, isSubcontractor) => {
  const result = {
    title: 'Account details',
    showDivider: false,
    showSectionTitle: false,
    fields: [
      {
        title: 'Website',
        type: 'text' as InputFieldType,
        field: 'website',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
      {
        title: 'Bank account no.',
        type: 'text' as InputFieldType,
        field: 'bankAccountNo',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
      {
        title: 'GST',
        type: 'text' as InputFieldType,
        field: 'gst',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
      {
        title: 'NZBN',
        type: 'text' as InputFieldType,
        field: 'nzbn',
        props: {
          ...labelSpan,
          $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
        },
      },
    ],
  };

  if (isSupplier || isSubcontractor) {
    const index = result.fields.findIndex(a => a.field == 'bankAccountNo');

    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const contactDetails = (
  contacts: Array<ContactModel> = [],
  notFoundContent
) => ({
  title: 'Site contact details',
  showDivider: false,
  //showSectionTitle: false,
  $titleCss: 'display:none; ',
  fields: [
    {
      type: 'select' as InputFieldType,
      title: 'Primary contact',
      field: 'primaryContactId',
      notFoundContent,
      props: {
        ...labelSpan,
        style: {
          margin: undefined,
        },
      },
      inputProps: {
        showSearch: true,
        options: contacts?.map(d => ({
          value: d.id,
          label: `${d.firstName} ${d.lastName}`,
        })),
        optionFilterProp: 'label',
        tagRender: () => null,
        $css: `
          [class$="select-selection-overflow"]::after {
            content: 'Search and select';
            color: rgb(0 0 0 / 25%);
          }
        `,
      },
    },
  ],
});

export const physicalAddress = (findAddressElement: React.ReactNode) => ({
  showDivider: false,
  fields: [
    {
      title: 'Find address',
      type: 'custom',
      field: 'pFindAddress',
      element: findAddressElement,
      props: {
        ...labelSpan,
      },
      inputProps: {
        autoSize: {
          minRows: 2,
        },
      },
    },
    {
      title: 'Street address',
      type: 'textarea' as InputFieldType,
      field: 'pStreetAddress',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        autoSize: {
          minRows: 3,
        },
      },
    },
    {
      title: 'Longitude',
      type: 'text' as InputFieldType,
      field: 'pLongitude',
      ishidden: true,
    },
    {
      title: 'Latitude',
      type: 'text' as InputFieldType,
      field: 'pLatitude',
      ishidden: true,
    },
    {
      title: 'Place Id',
      type: 'text' as InputFieldType,
      field: 'pPlaceId',
      ishidden: true,
    },
  ],
});

export const pSuburbArea = (areas: Array<AreaModel>) => ({
  fields: [
    {
      title: 'Suburb',
      type: 'text' as InputFieldType,
      field: 'pSuburb',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
    },
    {
      title: 'Area',
      type: 'select' as InputFieldType,
      field: 'pAreaId',
      props: {
        ...labelSpan,
      },
      inputProps: {
        placeholder: 'Select',
        options: areas?.map(d => ({
          value: d.id,
          label: d.area,
        })),
      },
    },
  ],
});

export const pCityRegion = {
  fields: [
    {
      title: 'City',
      type: 'text' as InputFieldType,
      field: 'pCity',
      required: true,
      props: {
        rules: [required],
        ...labelSpan,
      },
    },
    {
      title: 'Region',
      type: 'text' as InputFieldType,
      field: 'pRegion',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
    },
  ],
};

export const pPostalCode = {
  fields: [
    {
      title: 'Postal code',
      type: 'text' as InputFieldType,
      field: 'pPostalCode',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
    },
  ],
};

export const pCountry = (countries: Array<CountryModel> = []) => ({
  fields: [
    {
      title: 'Country',
      type: 'select' as InputFieldType,
      field: 'pCountryId',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        placeholder: 'Select',
        options: countries?.map(d => ({
          value: d.code,
          label: d.name,
        })),
      },
    },
  ],
});

export const sameAsPhysicalAddress = {
  fields: [
    {
      title: 'Same as physical address',
      field: 'isSameAsPhysicalAddress',
      type: 'checkbox',
      props: {
        labelCol: {
          span: 24,
        },
        $css: `
          [class*="form-item-label"] {display: none !important;}
        `,
      },
      inputProps: {
        options: [
          {
            value: true,
            label: 'Same as physical address',
          },
        ],
      },
    },
  ],
};

export const billAddress = (findAddressElement: React.ReactNode) => ({
  showDivider: false,
  fields: [
    {
      title: 'Find address',
      type: 'custom',
      field: 'bFindAddress',
      element: findAddressElement,
      props: {
        ...labelSpan,
      },
      inputProps: {
        readOnly: false,
        autoSize: {
          minRows: 2,
        },
      },
    },
    {
      title: 'Street address',
      type: 'textarea' as InputFieldType,
      field: 'bStreetAddress',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        readOnly: false,
        autoSize: {
          minRows: 3,
        },
      },
    },
    {
      title: 'Longitude',
      type: 'text' as InputFieldType,
      field: 'bLongitude',
      ishidden: true,
    },
    {
      title: 'Latitude',
      type: 'text' as InputFieldType,
      field: 'bLatitude',
      ishidden: true,
    },
    {
      title: 'Place Id',
      type: 'text' as InputFieldType,
      field: 'bPlaceId',
      ishidden: true,
    },
  ],
});

export const bSuburbArea = (areas: Array<AreaModel>) => ({
  fields: [
    {
      title: 'Suburb',
      type: 'text' as InputFieldType,
      field: 'bSuburb',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        readOnly: false,
      },
    },
    {
      title: 'Area',
      type: 'select' as InputFieldType,
      field: 'bAreaId',
      props: {
        ...labelSpan,
      },
      inputProps: {
        placeholder: 'Select',
        options: areas?.map(d => ({
          value: d.id,
          label: d.area,
        })),
      },
    },
  ],
});

export const bCityRegion = {
  fields: [
    {
      title: 'City',
      type: 'text' as InputFieldType,
      field: 'bCity',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        readOnly: false,
      },
    },
    {
      title: 'Region',
      type: 'text' as InputFieldType,
      field: 'bRegion',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        readOnly: false,
      },
    },
  ],
};

export const bPostalCode = {
  fields: [
    {
      title: 'Postal code',
      type: 'text' as InputFieldType,
      field: 'bPostalCode',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        readOnly: false,
      },
    },
  ],
};

export const bCountry = (countries: Array<CountryModel> = []) => ({
  fields: [
    {
      title: 'Country',
      type: 'select' as InputFieldType,
      field: 'bCountryId',
      required: true,
      props: {
        ...labelSpan,
        rules: [required],
      },
      inputProps: {
        placeholder: 'Select',
        options: countries?.map(d => ({
          value: d.code,
          label: d.name,
        })),
      },
    },
  ],
});

export const franchiseeDetails = (
  accounts: Array<AccountModel> = [],
  isFranchisee,
  franchiseeType
) => {
  const result = {
    showDivider: false,
    fields: [
      {
        title: 'Franchisee Type',
        field: 'franchiseeType',
        type: 'radio' as InputFieldType,
        required: isFranchisee,
        props: {
          ...labelSpan,
          rules: [required],
        },
        options: [
          { label: 'Local', value: FranchiseeTypeEnum.LOCAL },
          { label: 'Regional', value: FranchiseeTypeEnum.REGIONAL },
        ],
      },
      {
        title: 'Regional Franchisor',
        type: 'select' as InputFieldType,
        field: 'regionalFranchisorId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Search and select',
          options: accounts?.map(d => ({
            value: d.id,
            label: d.name,
          })),
        },
      },
    ],
  };

  if (franchiseeType == FranchiseeTypeEnum.REGIONAL) {
    const index = result.fields.findIndex(
      a => a.field == 'regionalFranchisorId'
    );

    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const franchiseeStartDate = {
  fields: [
    {
      title: 'Start date',
      type: 'date',
      field: 'startDate',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
    },
  ],
};

export const franchiseeDetails2 = {
  showDivider: false,
  fields: [
    {
      title: 'AYR mobile',
      type: 'text' as InputFieldType,
      field: 'ayrMobile',
      props: {
        ...labelSpan,
      },
    },
    {
      title: 'AYR email',
      type: 'text' as InputFieldType,
      field: 'ayrEmail',
      props: {
        ...labelSpan,
      },
    },
    {
      title: 'IRD no.',
      type: 'number' as InputFieldType,
      field: 'irdNo',
      controls: false,
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 16px;}',
      },
    },
  ],
};

export const relatedRecord = (
  locations: Array<Location> = [],
  users: Array<User> = [],
  isFranchisee: boolean,
  isSupplier: boolean,
  isSubcontractor: boolean
) => {
  const result = {
    showDivider: false,
    fields: [
      {
        title: 'Record owner',
        type: 'select' as InputFieldType,
        field: 'recordOwnerId',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
        inputProps: {
          placeholder: 'Select',
          options: users?.map(d => ({
            value: d.id,
            label: `${d.firstName} ${d.lastName}`,
          })),
        },
      },
      {
        title: 'Location',
        type: 'select' as InputFieldType,
        field: 'locationId',
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
        inputProps: {
          placeholder: 'Select',
          options: locations?.map(d => ({
            value: d.id,
            label: d.name,
          })),
        },
      },
    ],
  };

  if (!isSupplier && !isSubcontractor) {
    const index = result.fields.findIndex(a => a.field == 'recordOwnerId');
    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  if (!isFranchisee) {
    const index = result.fields.findIndex(a => a.field == 'recruitmentId');
    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const otherDetails = (
  sources: Array<Source> = [],
  priceLists: Array<PriceListModel> = [],
  isSupplier: boolean,
  isSubcontractor: boolean
) => {
  const result = {
    showDivider: false,
    fields: [
      {
        title: 'Source',
        type: 'select' as InputFieldType,
        field: 'sourceId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Select',
          options: sources?.map(d => ({
            value: d.id,
            label: d.name,
          })),
        },
      },
      {
        title: 'Interested services',
        type: 'select' as InputFieldType,
        field: 'interestedServiceId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Select',
          options: [],
        },
      },

      {
        title: 'Price list',
        type: 'select' as InputFieldType,
        field: 'priceListId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Select',
          options: priceLists?.map(d => ({
            value: d.id,
            label: d.name,
          })),
        },
      },
    ],
  };

  if (isSupplier || isSubcontractor) {
    const interestedServicesIdx = result.fields.findIndex(
      a => a.field == 'interestedServices'
    );
    if (interestedServicesIdx > -1) {
      result.fields.splice(interestedServicesIdx, 1);
    }
    const priceListIdx = result.fields.findIndex(a => a.field == 'priceListId');
    if (priceListIdx > -1) {
      result.fields.splice(priceListIdx, 1);
    }
  }

  return result;
};

export const supplierAccountNo = (isSupplier: boolean) => {
  const result = {
    fields: [
      {
        title: 'Supplier account no.',
        type: 'text' as InputFieldType,
        field: 'supplierAccountNo',
        required: isSupplier,
        props: {
          ...labelSpan,
          rules: isSupplier ? [required] : [],
        },
      },
    ],
  };

  if (isSupplier) {
    const index = result.fields.findIndex(a => a.field == 'subconAccountNo');

    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const accountCode = (accountCode: Array<AccountCodeModel>) => ({
  showDivider: false,
  fields: [
    {
      title: 'Account code',
      type: 'select' as InputFieldType,
      field: 'accountCodeId',
      props: {
        ...labelSpan,
      },
      inputProps: {
        placeholder: 'Select',
        options: accountCode.map(a => ({
          label: a.accountCode,
          value: a.id,
        })),
      },
    },
  ],
});

export const paymentTerms = paymentTerm => ({
  showDivider: false,
  fields: [
    {
      title: 'Payment term',
      type: 'select' as InputFieldType,
      field: 'paymentTermId',
      props: {
        ...labelSpan,
      },
      inputProps: {
        placeholder: 'Select',
        options: paymentTerm?.map(d => ({
          value: d.id,
          label: d.paymentTerm,
        })),
      },
    },
  ],
});

export const supplierTypeField = (
  isSupplier: boolean,
  supplierType: Array<SupplierType>
  // isSubcontractor: boolean
) => {
  const result = {
    showDivider: false,
    fields: [
      {
        title: 'Supplier type',
        type: 'select' as InputFieldType,
        field: 'supplierTypeId',
        props: {
          ...labelSpan,
        },
        inputProps: {
          placeholder: 'Select',
          options: supplierType?.map(d => ({
            value: d.id,
            label: d.name,
          })),
        },
      },
    ],
  };

  if (isSupplier) {
    const index = result.fields.findIndex(a => a.field == 'subconType');

    if (index > -1) {
      result.fields.splice(index, 1);
    }
  }

  return result;
};

export const minLeadTime = {
  showDivider: false,
  fields: [
    {
      title: 'Minimum lead time (days)',
      type: 'number' as InputFieldType,
      field: 'minimumLeadTime',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 8px;}',
      },
    },
  ],
};

export const maxLeadTime = {
  showDivider: false,
  fields: [
    {
      title: 'Maximum lead time (days)',
      type: 'number' as InputFieldType,
      field: 'maximumLeadTime',
      props: {
        ...labelSpan,
        $css: '[class*="form-item-label"] {padding-bottom: 8px;}',
      },
    },
  ],
};

export const bankDetails = isSupplier => ({
  fields: [
    {
      title: 'Bank account name',
      type: 'text' as InputFieldType,
      field: 'bankAccountName',
      required: isSupplier,
      props: {
        ...labelSpan,
        rules: isSupplier ? [required] : [],
      },
    },
    {
      title: 'Bank name',
      type: 'text' as InputFieldType,
      field: 'bankName',
      required: isSupplier,
      props: {
        ...labelSpan,
        rules: isSupplier ? [required] : [],
      },
    },
  ],
});

export const bankDetails2 = (isSupplier, isSubcontractor) => ({
  fields: [
    {
      title: 'Bank account no.',
      type: 'text' as InputFieldType,
      field: 'bankAccountNo',
      required: isSupplier || isSubcontractor,
      props: {
        ...labelSpan,
        rules: isSupplier || isSubcontractor ? [required] : [],
      },
    },
    {
      title: 'Bank address',
      type: 'text' as InputFieldType,
      field: 'bankAddress',
      required: isSupplier,
      props: {
        ...labelSpan,
        rules: isSupplier ? [required] : [],
      },
    },
  ],
});

export const searchFields = value => [
  {
    fieldName: 'name',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'accountType',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'primaryContact.firstName',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'primaryContact.lastName',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'location.name',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
];

export const searchFieldsAccountContacts = value => [
  {
    fieldName: 'account.name',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'account.accountType',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'account.location.name',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  {
    fieldName: 'account.primaryContact.firstName',
    comparator: SearchComparator.ILIKE,
    searchValue: value,
    inOr: true,
  },
  // {
  //   fieldName: 'account.primaryContact.lastName',
  //   comparator: SearchComparator.ILIKE,
  //   searchValue: value,
  //   inOr: true,
  // },
  // {
  //   fieldName: 'account.primaryContact.jobTitle',
  //   comparator: SearchComparator.ILIKE,
  //   searchValue: value,
  //   inOr: true,
  // },
  // {
  //   fieldName: 'account.primaryContact.phone',
  //   comparator: SearchComparator.ILIKE,
  //   searchValue: value,
  //   inOr: true,
  // },
  // {
  //   fieldName: 'account.primaryContact.email',
  //   comparator: SearchComparator.ILIKE,
  //   searchValue: value,
  //   inOr: true,
  // },
];

export const exportFields = [
  {
    title: 'Account',
    field: 'name',
  },
  {
    title: 'Account type',
    field: 'accountType',
    transform: data => (data ? toSentenceCase(data) : null),
  },
  {
    title: 'Primary contact',
    field: 'primaryContact',
    transform: (data: ContactModel) =>
      data && data != null ? `${data?.firstName} ${data?.lastName}` : null,
  },
  {
    title: 'Location',
    field: 'location',
    transform: (data: Location) => data?.name,
  },
  {
    title: 'Status',
    field: 'status',
    transform: (data: WorkflowStatusModel) => data?.name,
  },
];

export const exportFieldsBills = [
  {
    title: 'Bill No.',
    field: 'reference',
  },
  {
    title: 'Bill Date',
    field: 'billDate',
    transform: text => (text ? formatDate(text) : '-'),
  },
  {
    title: 'Account',
    field: 'account',
    transform: data => data?.name || null,
  },
  {
    title: 'Bill Type',
    field: 'billType',
  },
  {
    title: 'Bill Total',
    field: 'totalAmount',
    transform: text => (text ? `$${text.toFixed(2)}` : '$0.00'),
  },
  {
    title: 'Outstanding Balance',
    field: 'outstandingBalance',
    transform: text => (text ? `$${text.toFixed(2)}` : '$0.00'),
  },
  {
    title: 'Location',
    field: 'location',
    transform: data => data?.name || null,
  },
  {
    title: 'Bill Template',
    field: 'billTemplate',
  },
  {
    title: 'Xero Status',
    field: 'xeroStatus',
  },
  {
    title: 'BMS Status',
    field: 'status',
  },
];

export const exportContactAccountFields = [
  {
    title: 'Account',
    field: 'account',
    transform: data => {
      return data?.name;
    },
  },
  {
    title: 'Account type',
    field: 'account',
    transform: data =>
      data?.accountType ? toSentenceCase(data?.accountType) : null,
  },
  {
    title: 'Primary contact',
    field: 'account',
    transform: data =>
      data?.primaryContact?.firstName
        ? `${data?.primaryContact?.firstName} ${data?.primaryContact?.lastName}`
        : null,
  },
  {
    title: 'Location',
    field: 'account',
    transform: data => data?.location?.name || null,
  },
  {
    title: 'Status',
    field: 'account',
    transform: data => data?.status?.name || null,
  },
];

export const exportFieldsInvoices = [
  {
    title: 'Invoice No.',
    field: 'reference',
  },
  {
    title: 'Invoice Date',
    field: 'invoiceDate',
    transform: text => (text ? formatDate(text) : '-'),
  },
  {
    title: 'Account',
    field: 'account',
    transform: data => data?.name || null,
  },
  {
    title: 'Invoice Type',
    field: 'invoiceType',
  },
  {
    title: 'Total',
    field: 'totalAmount',
    transform: text => (text ? `$${text.toFixed(2)}` : '$0.00'),
  },
  {
    title: 'Outstanding Balance',
    field: 'outstandingBalance',
    transform: text => (text ? `$${text.toFixed(2)}` : '$0.00'),
  },
  {
    title: 'Location',
    field: 'location',
    transform: data => data?.name || null,
  },
  {
    title: 'Invoice Template',
    field: 'invoiceTemplate',
  },
  {
    title: 'Xero Status',
    field: 'xeroStatus',
  },
  {
    title: 'Status',
    field: 'status',
  },
];
