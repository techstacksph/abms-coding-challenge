import React from 'react';

import { SelectAddIcon, Text } from '@/styled-components';

import { Stack } from '@mui/material';

const NotFoundContent = ({ name }) => {
  return (
    <Stack padding={1} gap={1}>
      <Text style={{ color: '#090A0B', textAlign: 'center' }}>
        {' '}
        No results found
      </Text>
      <Stack
        direction={'row'}
        width={'max-content'}
        alignItems={'center'}
        alignSelf={'center'}
      >
        <Text style={{ color: '#686D78' }}>Click </Text>
        <Stack pl={1} pr={1}>
          <SelectAddIcon />
        </Stack>
        <Text style={{ color: '#686D78' }}> to add new {name}.</Text>
      </Stack>
    </Stack>
  );
};

export default NotFoundContent;
