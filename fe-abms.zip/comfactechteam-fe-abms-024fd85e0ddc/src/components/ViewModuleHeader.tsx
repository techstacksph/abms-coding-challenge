import React from 'react';

import {
  Delete,
  ModuleHeader as BaseModuleHeader,
  Button,
  MaterialIcon,
  Text,
  Icon,
} from '@/styled-components';
import styled from 'styled-components';

import {
  ModeEditOutlineOutlined,
  NavigateBefore,
  NavigateNext,
} from '@mui/icons-material';
import { Stack } from '@mui/material';

import { Space, Button as AntdButton } from 'antd';

const StyledCompactButton = styled(AntdButton)`
  display: flex;
  align-items: center;
  height: 40px;
  padding: 7px 8px;
`;

const ModuleHeader = (
  props: React.ComponentProps<typeof BaseModuleHeader> & {
    subtitleText?: string;
  }
) => {
  return (
    <BaseModuleHeader
      containerProps={{
        $css: `
          padding-block: 20px;
          align-items: center;
            
          & [class*="-col"] > [class*="-space"],
          & [class*="-col"] > [class*="-space-item"] {
            display: flex !important
          } 
        `,
      }}
      subtitle={
        <Stack alignItems='center' direction='row' spacing={1.25}>
          <Button
            type='text'
            icon={<MaterialIcon name='arrow_back' $css={'color: #878B97;'} />}
            onClick={props?.onBackClick}
            $css={`
              &:hover{
                background-color: transparent !important;
              }
            `}
          />
          <Text weight='bold' size={24}>
            {props?.subtitleText}
          </Text>
        </Stack>
      }
      endDisplay={
        <Stack alignItems='center' direction='row' spacing={2.5}>
          <Stack spacing={1} direction='row'>
            <Button type='primary' $css='padding: 0px; width: 40px;'>
              <ModeEditOutlineOutlined />
            </Button>
            <Button
              ghost
              type='text'
              $css='padding: 0px; width: 40px; color: #7B8B99;'
            >
              <Delete />
            </Button>
          </Stack>
          <Space>
            <Space.Compact direction='vertical'>
              <StyledCompactButton>
                <Icon color='#878B97'>
                  <NavigateNext />
                </Icon>
              </StyledCompactButton>
              <StyledCompactButton>
                <Icon color='#878B97'>
                  <NavigateBefore />
                </Icon>
              </StyledCompactButton>
            </Space.Compact>
          </Space>
        </Stack>
      }
      {...props}
    />
  );
};

export default ModuleHeader;
