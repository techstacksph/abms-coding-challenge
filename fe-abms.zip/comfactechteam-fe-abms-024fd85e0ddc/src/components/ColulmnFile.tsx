import React from 'react';

import FileChip from '@/components/files/FileChip';
import MoreFileTooltip from '@/components/files/MoreFileTooltip';
import { Stack } from '@mui/material';
import { FileUpload } from '@/typings/inputField.types';

const ColumnFile = ({ files }: { files: Array<string> }) => {
  const sliceFile = files.splice(0, 2);
  const excessFiles: Array<FileUpload> = files.map(f => JSON.parse(f));

  return (
    <Stack direction='row' spacing={1} flexWrap='wrap' useFlexGap>
      {sliceFile.map((f, i) => {
        try {
          const file: FileUpload = JSON.parse(f);

          return <FileChip key={i} {...file} />;
        } catch {
          console.error(`[file${i}] Invalid file`);
          return null;
        }
      })}
      <MoreFileTooltip files={excessFiles} />
    </Stack>
  );
};

export default ColumnFile;
