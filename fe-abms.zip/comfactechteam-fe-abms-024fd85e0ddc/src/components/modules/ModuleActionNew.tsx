import React, { memo } from 'react';

import { Text } from '@/styled-components';

import { PlusOutlined } from '@ant-design/icons';
import Link from '@/components/Link';
import { Stack, SxProps } from '@mui/material';
import { convertCase } from '@/utils/string.utils';

const sx: SxProps = {
  backgroundColor: 'var(--color-primary)',
  color: '#FFF',
  padding: '8px 12px',
  minWidth: '32px',
  borderRadius: 2,
  height: '40px',
  '&:active': {
    background: 'var(--button-primary-bg-hover)',
  },
  '&:hover': {
    background: 'var(--button-primary-bg-hover)',
  },
};

const ModuleActionNew = ({
  module,
  to,
  onClick,
  states,
  width = 'max-content',
}: {
  module: string;
  to?: string;
  onClick?: () => void;
  states?: any;
  width?: string;
}) => {
  const content = (
    <Stack
      direction='row'
      sx={{
        ...sx,
        width,
        '@media (max-width: 1300px)': {
          width: '40px',
          padding: '8px',
          minWidth: '40px',
        },
      }}
      spacing={1}
      alignItems='center'
      justifyContent='center'
    >
      <PlusOutlined color='#FFF' />
      <Text
        color='#FFF'
        $css={`
          @media (max-width: 1300px) {
            display: none;
          }
        `}
      >
        {convertCase(module)}
      </Text>
    </Stack>
  );

  // If onClick is provided, render as clickable div instead of Link
  if (onClick) {
    return (
      <div onClick={onClick} style={{ cursor: 'pointer' }}>
        {content}
      </div>
    );
  }

  // Otherwise render as Link with to prop
  return (
    <Link to={to || ''} states={states}>
      {content}
    </Link>
  );
};

export default memo(ModuleActionNew);
