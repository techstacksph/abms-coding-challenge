import React, { memo, ReactNode } from 'react';

import { Text, Divider } from '@/styled-components';

import { Stack, Box, StackProps } from '@mui/material';

const ViewModuleSections = ({
  title,
  children,
  containerProps,
  css = '',
  showTitle = true,
  titleTextType = 'md',
  titleTextWeight = 'medium',
  titleTextCss = '',
}: {
  title: string | ReactNode;
  children: ReactNode;
  containerProps?: StackProps;
  css?: string;
  showTitle?: boolean;
  titleTextType?: string;
  titleTextWeight?: string;
  titleTextCss?: string;
}) => {
  return (
    <Stack {...containerProps}>
      {showTitle && (
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <Text
            $type={titleTextCss ? undefined : titleTextType}
            weight={titleTextCss ? undefined : titleTextWeight}
            $css={titleTextCss}
          >
            {title}
          </Text>
          <Divider $css={css + 'margin-block: 20px;'} />
        </Box>
      )}
      {children}
    </Stack>
  );
};

export default memo(ViewModuleSections);
