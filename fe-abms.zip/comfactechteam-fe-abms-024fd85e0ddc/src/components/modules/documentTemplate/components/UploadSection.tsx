import React, { useEffect, useState, useRef } from 'react';

import {
  UploadFile,
  Button,
  MaterialIcon,
  Text,
  GoogleIcon,
  FormSection,
} from '@/styled-components';

import { Badge } from '@/components/Badge';
import { Box, Stack } from '@mui/material';

import { Form, FormInstance, Tooltip } from 'antd';

import { fileField } from '../fields';
import useCompanySettings from '@/hooks/useCompanySettings';

const MAX_FILE_COUNT = 5;

export interface DocumentTemplateFile {
  name: string;
  type: string;
  uid: string;
  size: number;
  file?: File; // The actual File object for S3 upload
  // For existing files loaded from backend
  url?: string;
  s3Key?: string;
  isExisting?: boolean;
}

const UploadSection = ({
  form,
  name = 'Document template',
}: {
  form: FormInstance;
  name?: string;
}) => {
  const { maximumFileSizeValue, maximumFileSize } = useCompanySettings();
  const [fileList, setFileList] = useState<DocumentTemplateFile[]>([]);
  // Keep a map of uid -> File to preserve File objects across re-renders
  const fileObjectsRef = useRef<Map<string, File>>(new Map());

  const files = Form.useWatch('files', { form });

  const onHandleCallback = (info: any[]) => {
    // Map files and include the actual File object for S3 upload
    const newFiles: DocumentTemplateFile[] = info.map(i => {
      const { name, type, uid, size, originFileObj } = i;

      // Store the File object in our ref map if it exists
      if (originFileObj instanceof File) {
        fileObjectsRef.current.set(uid, originFileObj);
      }

      // Get the File from our map (in case originFileObj is undefined on re-render)
      const fileObject = fileObjectsRef.current.get(uid);

      return {
        name,
        type,
        uid,
        size,
        file: fileObject, // Use the preserved File object
        isExisting: false,
      };
    });

    // Clean up removed files from the map
    const currentUids = new Set(info.map(i => i.uid));
    fileObjectsRef.current.forEach((_, uid) => {
      if (!currentUids.has(uid)) {
        fileObjectsRef.current.delete(uid);
      }
    });

    form.setFieldValue('files', newFiles);
  };

  useEffect(() => {
    if (files) {
      setFileList(files);
    }
  }, [files]);

  const isMaxFile = fileList.length === MAX_FILE_COUNT;

  return (
    <Stack spacing='15px' maxWidth={400}>
      <Text $type='md' weight='semibold'>
        Upload files
      </Text>
      <Stack direction='row' spacing={1} alignItems='center'>
        <Badge dot offset={[5, 3]} color='var(--red-300)'>
          <Text $type='sm' weight='medium' $css='line-height: 20px;'>
            {name} file
          </Text>
        </Badge>
        <Tooltip
          color='#FFF'
          title={
            <Text>
              <Text color='var(--color-text-secondary)'>File format: </Text>
              .JPEG, .PNG, .GIF, .TXT, .PDF, .XLS, .XLSX, .PPT, .PPTX, .DOC,
              .DOCX, .key, .numbers.
              <br />
              <br />
              <Text color='var(--color-text-secondary)'>
                Maximum file size:{' '}
              </Text>
              {maximumFileSize}
            </Text>
          }
          overlayInnerStyle={{
            padding: 12,
          }}
        >
          <Box>
            <MaterialIcon
              name='info'
              $css={`
                display: flex;
                font-size: 16px;
                color: rgba(135, 139, 151, 1);
                cursor: pointer;
              `}
            />
          </Box>
        </Tooltip>
      </Stack>
      <UploadFile
        name='documents'
        multiple
        files={fileList}
        maxCount={MAX_FILE_COUNT}
        maxFileSize={maximumFileSizeValue}
        progress={{
          strokeColor: {
            '0%': '#108ee9',
            '100%': '#87d068',
          },
          strokeWidth: 3,
          format: percent => percent && `${parseFloat(percent.toFixed(2))}%`,
        }}
        onHandleCallback={onHandleCallback}
      >
        <Button
          type='text'
          icon={
            <GoogleIcon
              name='upload_file'
              fill={false}
              $css='padding-inline: 4px; font-size: 24px; cursor: pointer; color:#0000ff'
            />
          }
          disabled={isMaxFile}
          $css={`
            width:max-content;
            justify-content: flex-start;
            padding: 8px 8px;
            border: 1px solid #0000ff;
            color:#0000ff;
            font-size:14px;

            &:disabled {
              border: 1px solid #E9EAEC;
              box-shadow: 0px 1px 2px 0px #0000000D;

            }
            &:disabled span {
              color: #A7AAB2;
            }
          `}
        >
          <Text $css='margin-left: -4px; color: #3137FD;' weight='semibold'>
            Upload files (up to 5)
          </Text>
        </Button>
      </UploadFile>
      <FormSection fields={fileField(fileList.length !== 0)} />
    </Stack>
  );
};

export default UploadSection;
