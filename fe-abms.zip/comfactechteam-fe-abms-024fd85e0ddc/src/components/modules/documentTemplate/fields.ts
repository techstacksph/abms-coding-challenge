import { labelSpan, required } from '@/utils/inputProps.util';
import { convertCase } from '@/utils/string.utils';
import {
  DocumentTemplateAccessEnum,
  DocumentTemplateTypeEnum,
} from '@/views/settings/documentTemplates/common/constants';

const labelCol = {
  ...labelSpan.labelCol,
  style: {
    paddingBottom: 16,
  },
};
export const fields = ({ access }: { access: string }) => ({
  fields: [
    {
      title: 'Document template name',
      type: 'text',
      field: 'name',
      required: true,
      props: {
        labelCol,
        rules: [required],
      },
    },
    {
      title: 'Access',
      field: 'access',
      type: 'select',
      required: true,
      props: {
        labelCol,
        rules: [required],
      },
      inputProps: {
        placeholder: 'Select',
        options: Object.values(DocumentTemplateAccessEnum).map(value => ({
          value,
          label: convertCase(value as string, undefined, true),
        })),
      },
    },
    {
      title: 'Type',
      field: 'type',
      type: 'select',
      required: access == DocumentTemplateAccessEnum.FRANCHISEE ? true : false,
      props: {
        labelCol,
        rules:
          access == DocumentTemplateAccessEnum.FRANCHISEE ? [required] : [],
      },
      inputProps: {
        placeholder: 'Select',
        options: Object.values(DocumentTemplateTypeEnum).map(value => ({
          value,
          label: convertCase(value as string, undefined, true).replace(
            /\band\b/g,
            ' & '
          ),
        })),
      },
    },
    {
      title: 'Description',
      type: 'textarea',
      field: 'description',
      props: {
        labelCol,
      },
    },
  ],
});

export const fileField = hidden => ({
  fields: [
    {
      required: true,
      title: 'Document template file',
      field: 'files',
      type: 'custom',
      props: {
        rules: [required],
        $css: `
          [class*="form-item-label"] {
            display: none;
            padding-bottom: 0px !important;
          }

          [class*="form-item-control"] > [class*="form-item-control-input"] {
            min-height: 0;
          }

          [class*="form-item-control"] [class*="form-item-explain-error"] {
            padding-top: 0;
          }

          #files_help {
            display: ${hidden ? 'none' : 'block'}
          }
        `,
      },
    },
  ],
});
