import React from 'react';

import { Container, Text, FormSection } from '@/styled-components';

import FormCard from '@/components/FormCard';
import { Box, CircularProgress, Stack } from '@mui/material';
import { ISubModuleFormProps } from '@/typings/module.types';
import { MODULE_FORM_TITLE } from '@/views/settings/documentTemplates/common/constants';

import { FormInstance, Form as AntdForm } from 'antd';

import FormModuleHeader from '../FormModuleHeader';
import UploadSection from './components/UploadSection';
import { fields } from './fields';

const DocumentTemplateForm = (
  props: ISubModuleFormProps & { form: FormInstance; loading?: boolean }
) => {
  const access = AntdForm.useWatch('access', props.form);

  return (
    <>
      <FormModuleHeader
        title={`${props.type} ${MODULE_FORM_TITLE}`}
        breadCrumbs={[
          ...(props?.breadCrumbs ?? []),
          { title: `${props.type} ${MODULE_FORM_TITLE}` },
        ]}
      />
      <Container>
        <Box position='relative'>
          {props.loading && (
            <Box
              position='absolute'
              top={0}
              left={0}
              right={0}
              bottom={0}
              display='flex'
              alignItems='center'
              justifyContent='center'
              bgcolor='rgba(255, 255, 255, 0.8)'
              zIndex={10}
              borderRadius={2}
            >
              <CircularProgress size={40} />
            </Box>
          )}
          <FormCard
            title='Document template information'
            containerProps={{ spacing: 2 }}
          >
            <Stack direction='row' spacing={2}>
              <Stack spacing={2} flex={1}>
                <Text $type='md' weight='semibold'>
                  Document template details
                </Text>
                <FormSection fields={fields({ access })} />
              </Stack>
              <UploadSection form={props.form} />
            </Stack>
          </FormCard>
        </Box>
      </Container>
    </>
  );
};

export default DocumentTemplateForm;
