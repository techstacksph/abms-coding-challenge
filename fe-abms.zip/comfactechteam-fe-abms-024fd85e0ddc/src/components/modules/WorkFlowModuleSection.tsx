import React, { memo, ReactNode } from 'react';

import { Text, Button, Icon, Badge, MaterialIcon } from '@/styled-components';

import Link from '@/components/Link';
import { Box, Stack, StackProps } from '@mui/material';

const centerIconStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
};

const WprkFlowModuleSection = ({
  workflows,
  jobs,
  statuses,
  others,
  showBorder = true,
  containerStyle = {
    marginTop: '-21px',
    marginBottom: '-21px',
    minWidth: '220px',
  },
  isCenterIconStyle = false,
}: {
  workflows?: Array<{
    icon: ReactNode;
    label?: ReactNode | string;
    onClick?: () => void;
    to?: string;
    css?: string;
    isVisible?: boolean;
  }>;
  jobs?: Array<{
    icon: ReactNode;
    label?: string;
    onClick?: () => void;
    to?: string;
  }>;
  others?: Array<{
    icon: ReactNode;
    label?: ReactNode | string;
    onClick?: () => void;
    to?: string;
    css?: string;
    isVisible?: boolean;
  }>;
  showBorder?: boolean;
  containerStyle?: StackProps;
  statuses?: Array<{
    color: string;
    label: string;
    onClick: (e: React.MouseEvent<HTMLButtonElement>, value?: string) => void;
    isVisible: boolean;
    variant?: 'filled' | 'outlined';
  }>;
  isCenterIconStyle?: boolean;
}) => {
  statuses = statuses ? statuses.filter(a => a.isVisible) : [];
  others = others ? others.filter(a => a.isVisible) : [];
  return (
    <Box
      borderLeft={showBorder && '1px solid #D3D5D9'}
      marginY={showBorder && '-20px'}
      paddingY={showBorder && '20px'}
    >
      <Stack p={2.5} width='80%' spacing={2.5} {...containerStyle}>
        <Stack spacing={2.5} sx={{ marginTop: '8px !important' }}>
          <Text $type='md' weight='medium'>
            More actions
          </Text>
          {workflows && workflows.length > 0 && (
            <>
              <Text $type='xs' weight='medium' color='#A7AAB2'>
                Workflow
              </Text>
              <Box>
                {workflows?.map((w, index) => {
                  if (w?.to) {
                    return (
                      <Link to={w.to} key={index}>
                        <Stack
                          direction='row'
                          spacing={1}
                          alignItems='center'
                          px='15px'
                          py='8px'
                          mb={2}
                          sx={{
                            '&:hover': {
                              backgroundColor: '#0000000f',
                              color: '#212529',
                            },
                            borderRadius: '8px',
                          }}
                        >
                          <Icon>{w.icon}</Icon>
                          <Text color='inherit'>{w.label}</Text>
                        </Stack>
                      </Link>
                    );
                  }

                  return (
                    <Button
                      key={index}
                      type='text'
                      $css={`color: var(--color-primary); justify-content: left !important; align-items: center !important; width: 100% !important; margin-bottom: 16px !important; ${w.css}`}
                      data-cy={`workflow-${w.label}`}
                      onClick={w.onClick}
                    >
                      <Stack
                        direction='row'
                        spacing={1}
                        alignItems='center'
                        style={isCenterIconStyle ? centerIconStyle : {}}
                      >
                        <Icon>{w.icon}</Icon>
                        {typeof w.label === 'string' ? (
                          <Text color='inherit'>{w.label}</Text>
                        ) : (
                          w.label
                        )}
                      </Stack>
                    </Button>
                  );
                })}
              </Box>
            </>
          )}
          {jobs && jobs.length > 0 && (
            <>
              <Text $type='xs' weight='medium' color='#A7AAB2'>
                Jobs
              </Text>
              <Box>
                {jobs?.map(j => {
                  if (j?.to) {
                    return (
                      <Link to={j.to} key={j.label}>
                        <Stack
                          direction='row'
                          spacing={1}
                          alignItems='center'
                          px='15px'
                          py='8px'
                          mb={2}
                          sx={{
                            '&:hover': {
                              backgroundColor: '#0000000f',
                              color: '#212529',
                            },
                            borderRadius: '8px',
                          }}
                        >
                          <Icon>{j.icon}</Icon>
                          <Text color='inherit'>{j.label}</Text>
                        </Stack>
                      </Link>
                    );
                  }

                  return (
                    <Button
                      key={j.label}
                      type='text'
                      $css='color: var(--color-primary); justify-content: left !important; width: 100% !important; margin-bottom: 16px !important;'
                      data-cy={`workflow-${j.label}`}
                      onClick={j.onClick}
                    >
                      <Stack
                        direction='row'
                        spacing={1}
                        alignItems='center'
                        style={isCenterIconStyle ? centerIconStyle : {}}
                      >
                        <Icon>{j.icon}</Icon>
                        <Text color='inherit'>{j.label}</Text>
                      </Stack>
                    </Button>
                  );
                })}
              </Box>
            </>
          )}
          {others && others.length > 0 && (
            <>
              <Text $type='xs' weight='medium' color='#A7AAB2'>
                Others
              </Text>
              <Box>
                {others?.map((o, index) => {
                  if (o?.to) {
                    return (
                      <Link to={o.to} key={index}>
                        <Stack
                          direction='row'
                          spacing={1}
                          alignItems='center'
                          px='15px'
                          py='8px'
                          mb={2}
                          sx={{
                            '&:hover': {
                              backgroundColor: '#0000000f',
                              color: '#212529',
                            },
                            borderRadius: '8px',
                          }}
                        >
                          <Icon>{o.icon}</Icon>
                          <Text color='inherit'>{o.label}</Text>
                        </Stack>
                      </Link>
                    );
                  }

                  return (
                    <Button
                      key={index}
                      type='text'
                      $css={`color: var(--color-primary); justify-content: left !important; align-items: center !important; margin-bottom: 16px !important; ${o.css}`}
                      data-cy={`workflow-${o.label}`}
                      onClick={o.onClick}
                    >
                      <Stack
                        direction='row'
                        spacing={1}
                        alignItems='center'
                        style={isCenterIconStyle ? centerIconStyle : {}}
                      >
                        <Icon>{o.icon}</Icon>
                        {typeof o.label === 'string' ? (
                          <Text color='inherit'>{o.label}</Text>
                        ) : (
                          o.label
                        )}
                      </Stack>
                    </Button>
                  );
                })}
              </Box>
            </>
          )}
        </Stack>
        <Stack>
          {statuses && statuses.length > 0 && (
            <>
              <Text $type='xs' weight='medium' color='#A7AAB2'>
                Set status
              </Text>
              <Box>
                {statuses?.map(
                  s =>
                    s.isVisible && (
                      <Button
                        key={s.label}
                        type='text'
                        $css='color: var(--color-primary); width: 100%; justify-content: left !important;'
                        data-cy={`workflow-${s.label}`}
                        onClick={(e: React.MouseEvent<HTMLButtonElement>) =>
                          s.onClick(e, s.label)
                        }
                      >
                        <Stack direction='row' spacing={1} alignItems='center'>
                          <Badge color={s.color}>
                            {s.variant == 'outlined' ? (
                              <MaterialIcon
                                name='circle'
                                $css={`color: ${s.color}; font-size: 8px;`}
                              />
                            ) : null}
                          </Badge>
                          <Text color='inherit'>{s.label}</Text>
                        </Stack>
                      </Button>
                    )
                )}
              </Box>
            </>
          )}
          {jobs && jobs.length > 0 && (
            <>
              <Text $type='xs' weight='medium' color='#A7AAB2'>
                Jobs
              </Text>
              <Box>
                {jobs?.map(j => {
                  if (j?.to) {
                    return (
                      <Link to={j.to} key={j.label}>
                        <Stack
                          direction='row'
                          spacing={1}
                          alignItems='center'
                          px='15px'
                          py='8px'
                          mb={2}
                          sx={{
                            '&:hover': {
                              backgroundColor: '#0000000f',
                              color: '#212529',
                            },
                            borderRadius: '8px',
                          }}
                        >
                          <Icon>{j.icon}</Icon>
                          <Text color='inherit'>{j.label}</Text>
                        </Stack>
                      </Link>
                    );
                  }

                  return (
                    <Button
                      key={j.label}
                      type='text'
                      $css='color: var(--color-primary); justify-content: left !important; width: 100% !important; margin-bottom: 16px !important;'
                      data-cy={`workflow-${j.label}`}
                      onClick={j.onClick}
                    >
                      <Stack
                        direction='row'
                        spacing={1}
                        alignItems='center'
                        style={isCenterIconStyle ? centerIconStyle : {}}
                      >
                        <Icon>{j.icon}</Icon>
                        <Text color='inherit'>{j.label}</Text>
                      </Stack>
                    </Button>
                  );
                })}
              </Box>
            </>
          )}
        </Stack>
      </Stack>
    </Box>
  );
};

export default memo(WprkFlowModuleSection);
