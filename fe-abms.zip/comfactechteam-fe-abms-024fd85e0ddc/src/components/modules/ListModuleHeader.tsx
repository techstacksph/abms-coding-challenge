import React, { memo, ReactNode } from 'react';

import { Text, ModuleHeader as BaseModuleHeader } from '@/styled-components';

import { Stack } from '@mui/material';
import { convertCase } from '@/utils/string.utils';

const ListModuleHeader = (
  props: React.ComponentProps<typeof BaseModuleHeader> & {
    listTitle: ReactNode;
    listSubtitle?: ReactNode;
    listTitleCss?: string;
    setTItleCase?: boolean;
    extraEndDisplay?: ReactNode;
  }
) => {
  const setTitleCase = props.setTitleCase ?? false;
  return (
    <>
      <BaseModuleHeader
        setTitleCase={setTitleCase}
        subtitle={
          <Stack direction='column'>
            <Text weight='bold' size={24} $css={props?.listTitleCss}>
              {setTitleCase ? props?.listTitle : convertCase(props?.listTitle)}
            </Text>
            <Text
              $type='sm'
              color='#686d78'
              $css={
                'height: 28px; display: inline-flex; align-items: center; padding-top: 4px;'
              }
            >
              {props?.listSubtitle}
            </Text>
          </Stack>
        }
        endDisplay={props?.extraEndDisplay}
        containerProps={{
          $css: `
          padding-block: 24px;
          align-items: center;

          & [class*="-col"] > [class*="-space"],
          & [class*="-col"] > [class*="-space-item"] {
            display: flex !important
          }
        `,
        }}
        {...props}
      />
    </>
  );
};

export default memo(ListModuleHeader);
