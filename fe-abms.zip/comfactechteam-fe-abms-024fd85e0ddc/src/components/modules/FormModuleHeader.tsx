import React, { memo, ReactNode } from 'react';

import { ModuleHeader, Button, Text, MaterialIcon } from '@/styled-components';

import FormButtons from '@/components/FormButtons';
import useNavigate from '@/hooks/useNavigate';
import { Box, Stack } from '@mui/material';
import { ModulePageFormType } from '@/typings/module.types';
import { convertCase } from '@/utils/string.utils';

const FormModuleHeader = (
  props: React.ComponentProps<typeof ModuleHeader> & {
    formType: ModulePageFormType;
    saveButtonProps?: React.ComponentProps<typeof Button>;
    saveAsDraftButtonProps?: React.ComponentProps<typeof Button>;
    displaySaveBtn?: boolean;
    redirectTo?: string;
    titleDisplaySize?: number;
    endDisplaySize?: number;
    extraEndDisplay?: ReactNode;
  }
) => {
  const { back, navigate } = useNavigate(props?.formType);

  return (
    <Box>
      <ModuleHeader
        endDisplay={
          <Stack direction='row' alignItems='center' spacing={2}>
            {props?.extraEndDisplay}
            <FormButtons {...props} type='header' />
          </Stack>
        }
        subtitle={
          <>
            <Stack direction='row' spacing={1} alignItems='center'>
              <Button
                type='text'
                icon={
                  <MaterialIcon name='arrow_back' $css={'color: #878B97;'} />
                }
                onClick={() => {
                  if (props?.onClickBack) {
                    props.onClickBack();
                    return;
                  }
                  if (props?.redirectTo) {
                    navigate(props.redirectTo);
                  } else {
                    back();
                  }
                }}
                $css={`
                &:hover {
                  background-color: transparent !important;
                }
              `}
                data-cy='form-back'
              />
              <Text weight='bold' size={24} $css='line-height: 32px;'>
                {convertCase(props?.title)}
              </Text>
            </Stack>
            {props?.subTitle && (
              <Box marginLeft={6.2}>
                <Text $css='color: #686D78;'>{props.subTitle}</Text>
              </Box>
            )}
          </>
        }
        containerProps={{
          $css: `
            padding-block: 20px;
            align-items: center;
            & [class*="-col"] > [class*="-space"],
            & [class*="-col"] > [class*="-space-item"] {
              display: flex !important;
              line-height: 20px !important;
            }
          `,
        }}
        title={undefined}
        titleDisplaySize={props?.titleDisplaySize}
        endDisplaySize={props?.endDisplaySize}
        {...props}
      />
    </Box>
  );
};

export default memo(FormModuleHeader);
