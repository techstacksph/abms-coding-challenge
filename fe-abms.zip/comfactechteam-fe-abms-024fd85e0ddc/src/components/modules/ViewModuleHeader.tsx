// import React, { memo, ReactNode, useState, useEffect, useRef } from 'react';
import React, { memo, ReactNode, useState } from 'react';

import { DocumentNode } from 'graphql';

import {
  ModuleHeader as BaseModuleHeader,
  Button,
  Delete,
  Icon,
  MaterialIcon,
  Text,
} from '@/styled-components';
import { styled } from 'styled-components';

import ViewDeleteModal from '@/components/ViewDeleteModal';
import useNavigate from '@/hooks/useNavigate';
import { useSafeNavigation } from '@/hooks/useSafeNavigation';
import { ViewPageType } from '@/typings/module.types';
import {
  ModeEditOutlineOutlined,
  NavigateBefore,
  NavigateNext,
} from '@mui/icons-material';
import { Box, Stack, StackProps } from '@mui/material';
import { getDeleteConfirmationMessageJSX } from '@/utils/message.helper.utils';

import { Button as AntdButton, Space } from 'antd';
// import { ScrollToTop } from '../ScrollToTop';

const StyledCompactButton = styled(AntdButton)`
  display: flex;
  align-items: center;
  height: 40px;
  padding: 6px 8px;
`;

const ViewModuleHeader = (
  props: React.ComponentProps<typeof BaseModuleHeader> & {
    onNext?: () => void;
    onPrevious?: () => void;
    onDelete?: () => void;
    onEdit?: () => void;
    deleteRecordName?: string;
    deleteRecordNameWeight?: string;
    deleteQuery: DocumentNode;
    deleteId?: string;
    hideEdit?: boolean;
    hideDelete?: boolean;
    hideNextBackPrev?: boolean;
    disableNextPrev?: boolean;
    disablePrevious?: boolean;
    disableNext?: boolean;
    subtitleProps?: StackProps;
    extraEndDisplay?: ReactNode;
    deleteVar?: string;
    titleIcon?: string;
    redirection?: string;
    toPrev?: boolean;
    redirectBack?: string;
    deleteTitle?: string;
    editUrlSearchParams?: string;
    customSuccessDeleteMessage?: string;
    sourcePageType?: string;
    errorMessage?: string;
    shouldDelete?: boolean;
    customEditPageRoute?: string;
    type?: ViewPageType; // SET type AS 'ViewSubModule' IF VIEW PAGE IS FROM A TAB
    btnParentStyle?: React.CSSProperties;
    titleDisplaySize?: number;
    endDisplaySize?: number;
    recurringDeleteOption?: string;
    additionalDeleteVariables?: Record<string, any>;
    titleColor?: string;
  }
) => {
  const { navigateToEdit } = useSafeNavigation();
  const [open, setOpen] = useState<boolean>(false);
  const [deleteLoading, setDeleteLoading] = useState<boolean>(false);
  const { location, toBack, navigate, back: prevBack } = useNavigate('View');

  // const sourceStateEditOrNew =
  //   location?.state?.source?.includes('edit') ||
  //   location?.state?.source?.includes('new');
  // console.log({ sourceStateEditOrNew });
  const back = props.redirectBack || location?.state?.toBack || toBack;

  // Determine the appropriate fallback link target
  const redirectHasTab =
    props.redirectBack?.includes('?tab=') ||
    props.redirection?.includes('?tab=') ||
    props.redirectBack?.includes('?contact-tab=') ||
    props.redirection?.includes('?contact-tab=');

  // When coming from edit page, prioritize redirectBack/redirection props if they exist
  // Otherwise, use the back navigation to return to the list page
  const linkTarget = redirectHasTab
    ? props.redirectBack || props.redirection
    : props.redirectBack || props.redirection || back || '/';

  return (
    <>
      {/* <ScrollToTop /> */}
      {props?.deleteQuery && (
        <ViewDeleteModal
          recordName={props?.deleteRecordName || props?.title}
          deleteTitle={props?.deleteTitle || props?.title}
          open={open}
          deleteQuery={props?.deleteQuery}
          id={props?.deleteId ?? props?.id}
          setOpen={setOpen}
          deleteVar={props?.deleteVar}
          redirection={props?.redirection}
          customSuccessDeleteMessage={props?.customSuccessDeleteMessage}
          message={getDeleteConfirmationMessageJSX(
            props?.deleteRecordName,
            false,
            props?.deleteTitle || props?.title
          )}
          shouldDelete={props?.shouldDelete}
          errorMessage={props?.errorMessage}
          onDelete={props?.onDelete}
          onLoadingChange={setDeleteLoading}
          recurringDeleteOption={props?.recurringDeleteOption}
          additionalDeleteVariables={props?.additionalDeleteVariables}
        />
      )}
      <BaseModuleHeader
        subtitle={
          <Stack
            direction='row'
            spacing={1}
            alignItems='center'
            {...props?.subtitleProps}
          >
            {
              <Button
                type='text'
                onClick={() =>
                  props?.toPrev ? prevBack() : navigate(linkTarget)
                }
                data-testid='view-back-button'
                $css={`
                  display: flex;
                  align-items: center;
                  width: 40px;
                  height: 40px;
                  padding: 8px;
                  &:hover {
                    background-color: transparent !important;
                  }
                `}
              >
                <Icon
                  $css={`
                    display: flex;
                    align-items: center;
                    width: 40px;
                    height: 40px;
                    padding: 8px;
                  `}
                >
                  <MaterialIcon name='arrow_back' $css={'color: #878B97;'} />
                </Icon>
              </Button>
            }
            {props?.titleIcon ? (
              <Text weight='bold' size={24} color={props?.titleColor}>
                {props?.titleIcon}
              </Text>
            ) : (
              <Text weight='bold' size={24} color={props?.titleColor}>
                {props?.title}
              </Text>
            )}
          </Stack>
        }
        endDisplay={
          <Stack alignItems='center' direction='row' spacing={2.5}>
            {props?.extraEndDisplay}
            <Stack spacing={1} direction='row'>
              {!props?.hideEdit && (
                <Button
                  type='primary'
                  onClick={() => {
                    if (props?.onEdit) {
                      // Use custom edit handler if provided (e.g., for recurring tasks)
                      props.onEdit();
                    } else if (props?.customEditPageRoute) {
                      navigate(props.customEditPageRoute);
                    } else {
                      navigateToEdit(undefined, props?.editUrlSearchParams);
                    }
                  }}
                  data-testid='view-edit-button'
                  $css='background-color: var(--color-primary) !important; border-radius: 12px; width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;'
                >
                  <ModeEditOutlineOutlined sx={{ color: '#FFF' }} />
                </Button>
              )}
              {!props?.hideDelete && (
                <Button
                  type='text'
                  $css='padding: 0px; width: 40px; color: #7B8B99;'
                  data-cy='view-delete'
                  data-testid='view-delete-button'
                  onClick={() => {
                    if (props?.onDelete) {
                      // Use custom delete handler if provided (e.g., for recurring tasks)
                      props.onDelete();
                    } else {
                      setOpen(true);
                    }
                  }}
                  disabled={deleteLoading}
                  loading={deleteLoading}
                >
                  <Delete />
                </Button>
              )}
            </Stack>
            {!props?.hideNextBackPrev && (
              <Box sx={{ float: 'right', ...props?.btnParentStyle }}>
                <Space.Compact direction='vertical'>
                  <StyledCompactButton
                    data-cy='view-next'
                    data-testid='view-next-button'
                    onClick={props?.onNext}
                    disabled={
                      !props.onNext ||
                      props.disableNext ||
                      props?.disableNextPrev
                    }
                  >
                    <Icon color='#878B97'>
                      <NavigateNext />
                    </Icon>
                  </StyledCompactButton>
                  <StyledCompactButton
                    data-cy='view-previous'
                    data-testid='view-previous-button'
                    onClick={props?.onPrevious}
                    disabled={
                      !props.onPrevious ||
                      props.disablePrevious ||
                      props?.disableNextPrev
                    }
                  >
                    <Icon color='#878B97'>
                      <NavigateBefore />
                    </Icon>
                  </StyledCompactButton>
                </Space.Compact>
              </Box>
            )}
          </Stack>
        }
        containerProps={{
          $css: `
          padding-block: 20px;
          align-items: center;

          & [class*="-col"] > [class*="-space"],
          & [class*="-col"] > [class*="-space-item"] {
            display: flex !important
          }
        `,
        }}
        {...props}
      />
    </>
  );
};

export default memo(ViewModuleHeader);
