import CssBaseline from '@mui/material/CssBaseline';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import { ConfigProvider } from 'antd';
import { ConfigProvider as ChartsConfigProvider } from '@ant-design/charts';
import React, { useEffect } from 'react';
import { useInactivityTimeout } from '@/hooks/useInactivityTimeout';
import { SessionTimeoutWarning } from '@/components/SessionTimeoutWarning';
import { initDevConsole } from '@/utils/devConsole';

// Apollo Client
import {
  apolloClient,
  ApolloProvider,
  ProfileProvider,
  SystemSettingsProvider,
  useSystemSettings,
} from '@/mfe-utilities';

// Router
import { RouterProvider } from 'react-router-dom';

// Routes
import { config, snackbarConfig } from '@/config/snackbarConfig';
import { chartConfig } from '@/config/chartConfig';
import {
  antThemeConfig,
  GlobalStyles,
  MuiTheme,
  SnackbarProvider,
  ThemeProvider,
} from '@/styled-components';
import { router } from './router';

// Days Setup
import { extend } from 'dayjs';
import advancedFormat from 'dayjs/plugin/advancedFormat';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import isBetween from 'dayjs/plugin/isBetween';
import localeData from 'dayjs/plugin/localeData';
import weekOfYear from 'dayjs/plugin/weekOfYear';
import weekYear from 'dayjs/plugin/weekYear';
import weekday from 'dayjs/plugin/weekday';

extend(customParseFormat);
extend(advancedFormat);
extend(weekday);
extend(localeData);
extend(weekOfYear);
extend(weekYear);
extend(isBetween);

/**
 * Inner component that has access to SystemSettingsProvider context
 * This must be a separate component because hooks can only access context
 * from providers that are ancestors in the component tree
 */
const AppContent: React.FC = () => {
  // Initialize dev console utilities (DEV/SANDBOX only)
  useEffect(() => {
    initDevConsole();
  }, []);

  // Get security level configuration from system settings
  const systemSettings = useSystemSettings();

  // Extract inactivity timeout from security level configuration
  // Fallback to 30 minutes if security level is not yet loaded
  const inactivityTimeoutMinutes =
    systemSettings?.securityLevel?.configuration?.authentication?.session
      ?.inactivityInMin || 30;

  // Session timeout management with dynamic timeout based on security level
  const { showWarning, remainingTime, resetTimer, triggerLogout } =
    useInactivityTimeout({
      timeoutMs: inactivityTimeoutMinutes * 60 * 1000, // Convert minutes to milliseconds
      warningMs: 2 * 60 * 1000, // 2 minutes warning
    });

  return (
    <>
      <RouterProvider router={router} />
      <SessionTimeoutWarning
        visible={showWarning}
        remainingTime={remainingTime}
        onExtendSession={resetTimer}
        onLogout={triggerLogout}
      />
    </>
  );
};

// Main App Component
const App: React.FC = () => {
  return (
    <ApolloProvider client={apolloClient}>
      <ThemeProvider appName='fe-abms'>
        <ConfigProvider {...antThemeConfig}>
          <MuiThemeProvider theme={MuiTheme}>
            <CssBaseline />
            <GlobalStyles />
            <SnackbarProvider config={config} snackbarConfig={snackbarConfig}>
              <SystemSettingsProvider>
                <ProfileProvider>
                  <ChartsConfigProvider
                    column={chartConfig.column}
                    dualAxes={chartConfig.dualAxes}
                  >
                    <AppContent />
                  </ChartsConfigProvider>
                </ProfileProvider>
              </SystemSettingsProvider>
            </SnackbarProvider>
          </MuiThemeProvider>
        </ConfigProvider>
      </ThemeProvider>
    </ApolloProvider>
  );
};

export default App;
