import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Leave`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const LEAVE_FRAGMENT = gql`
  fragment LeaveFragment on ${MODEL_NAME} {
    id
    leaveNo
    dateFrom
    dateTo
    hours
    reason
    approver
    employee {
        id
        fullName
        primaryManager {
            id
            name
            fullName
        }
    }
    departments {
        id
        name
    }
    location {
        id
        name
    }
    leaveType {
        id
        name
    }
    status {
        id
        name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_LEAVES = gql`
  ${LEAVE_FRAGMENT}
  query paginatedLeaves($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedLeaves(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...LeaveFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_LEAVES = gql`
  ${LEAVE_FRAGMENT}
  query ${TENANT_PREFIX}leaves($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leaves(sortArg: $sortArg, searchArg: $searchArg) {
      ...LeaveFragment
      ...BaseFragment
    }
  }
`;

export const GET_LEAVE_DASHBOARD = gql`
  query ${TENANT_PREFIX}leaveDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}leaveDashboard(dashboardArg: $dashboardArg) {
      all
      pending
      approved
      disapproved   
    }
  }
`;

export const FIND_LEAVE_BY_ID = gql`
  ${LEAVE_FRAGMENT}
  query findLeaveById($${TENANT_PREFIX}findLeaveByIdId: String!) {
    ${TENANT_PREFIX}findLeaveById(id: $${TENANT_PREFIX}findLeaveByIdId) {
      ...LeaveFragment
      ...BaseFragment
      documentFile
    }
  }
`;

export const UPDATE_LEAVE_BY_ID = gql`
  ${LEAVE_FRAGMENT}
  mutation updateLeave($leave: ${TENANT_PREFIX}LeaveInput!, $${TENANT_PREFIX}updateLeaveById: String!) {
    ${TENANT_PREFIX}updateLeave(leave: $leave, id: $${TENANT_PREFIX}updateLeaveById) {
      ...LeaveFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LEAVE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateLeaveStatus($${TENANT_PREFIX}updateLeaveStatusId: String!, $status: ${TENANT_PREFIX}LeaveStatusInput!) {
    ${TENANT_PREFIX}updateLeaveStatus(id: $${TENANT_PREFIX}updateLeaveStatusId, status: $status) {
      id
    }
  }
`;

export const CREATE_LEAVE = gql`
  ${LEAVE_FRAGMENT}
  mutation createLeave($leave: ${TENANT_PREFIX}LeaveInput!) {
    ${TENANT_PREFIX}createLeave(leave: $leave) {
      ...LeaveFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_LEAVE = gql`
  mutation deleteLeave($${TENANT_PREFIX}deleteLeaveById: String!) {
    ${TENANT_PREFIX}deleteLeave(id: $${TENANT_PREFIX}deleteLeaveById)
  }
`;

export const DELETE_LEAVES = gql`
  mutation deleteLeaves($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLeaves(ids: $ids)
  }
`;

export const GET_LEAVES_CSV = gql`
  query ${TENANT_PREFIX}leaveTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}leaveTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
