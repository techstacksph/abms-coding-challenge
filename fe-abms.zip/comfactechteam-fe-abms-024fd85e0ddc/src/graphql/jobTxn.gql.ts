import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}JobTransaction`;

export const JOB_TRANSACTION_FRAGMENT = gql`
  fragment JobTransactionFragment on ${MODEL_NAME} {
    id
    process
    timestamp
    transactionDetails
    job {
      id
    }
    user {
      id
      firstName
      lastName
    }
  }
`;

export const FIND_JOB_TRANSACTION_BY_ID = gql`
  ${JOB_TRANSACTION_FRAGMENT}
  query ${TENANT_PREFIX}findJobTransactionById($id: String!) {
    ${TENANT_PREFIX}findJobTransactionById(id: $id) {
      ...JobTransactionFragment
    }
  }
`;

export const ALL_JOB_TRANSACTIONS = gql`
  ${JOB_TRANSACTION_FRAGMENT}
  query ${TENANT_PREFIX}jobTransactions($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobTransactions(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobTransactionFragment
    }
  }
`;

export const PAGINATED_JOB_TRANSACTIONS = gql`
  ${JOB_TRANSACTION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedJobTransactions($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedJobTransactions(pageArg: $pageArg, searchArg: $searchArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...JobTransactionFragment
      }
    }
  }
`;

export const CREATE_JOB_TRANSACTION = gql`
  ${JOB_TRANSACTION_FRAGMENT}
  mutation ${TENANT_PREFIX}createJobTransaction($jobTransaction: ${TENANT_PREFIX}JobTransactionInput!) {
    ${TENANT_PREFIX}createJobTransaction(jobTransaction: $jobTransaction) {
      ...JobTransactionFragment
    }
  }
`;

export const UPDATE_JOB_TRANSACTION = gql`
  ${JOB_TRANSACTION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateJobTransaction($id: String!, $jobTransaction: ${TENANT_PREFIX}JobTransactionInput!) {
    ${TENANT_PREFIX}updateJobTransaction(id: $id, jobTransaction: $jobTransaction) {
      ...JobTransactionFragment
    }
  }
`;

export const DELETE_JOB_TRANSACTION = gql`
  mutation ${TENANT_PREFIX}deleteJobTransaction($id: String!) {
    ${TENANT_PREFIX}deleteJobTransaction(id: $id)
  }
`;

export const DELETE_JOB_TRANSACTIONS = gql`
  mutation ${TENANT_PREFIX}deleteJobTransactions($ids: [String!]!) {
    ${TENANT_PREFIX}deleteJobTransactions(ids: $ids)
  }
`;

export const JOB_TRANSACTION_CSV = gql`
  query ${TENANT_PREFIX}JobTransactionCSV($searchArg: [${TENANT_PREFIX}SearchArg!], $columnArg: [${TENANT_PREFIX}ColumnArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}JobTransactionCSV(searchArg: $searchArg, columnArg: $columnArg, sortArg: $sortArg)
  }
`;
