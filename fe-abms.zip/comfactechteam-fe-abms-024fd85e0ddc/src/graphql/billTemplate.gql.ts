import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'BillTemplate';
const TITLE_SMALL = 'billTemplate';
const TITLE_FRAGMENT = 'BillTemplateFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_BILL_TEMPLATES_TITLE = 'paginatedBillTemplates';

export const BILL_TEMPLATE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    reference
    billTemplateNo
    invoiceTemplateDetailId
    date
    billDate
    due
    repeat
    thisTransactionEvery
    endDate
    nextGenerationDate
    subtotal
    gstAmount
    gstType
    totalAmount
    type
    billType
    subType
    status {
      id
      name
    }
    notes
    account {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      ayrMobile
      gst
      bankAccountNo
      accountType
      location {
        id
        name
        address
        financeEmail
      }
    }
    billingAccount {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      ayrMobile
      gst
      bankAccountNo
      accountType
      location {
        id
        name
        address
        financeEmail
      }
    }
    billTemplateContacts {
      id
      contact {
        id
        fullName
      }
    }
    billTemplateDetails {
      id
      invoiceTemplateDetailId
      description
      qty
      unitPrice
      lineAmount
      job {
        id
        jobNo
      }
      item {
        id
        name
      }
      accountCode {
        id
        accountCode
      }
    }
    location {
      id
      name
    }
    bills {
      id
    }
    xeroAccount {
      id
      xeroAccount
    }
    jobs {
      id
      jobNo
    }
    orgId
    recordLocked
    lockedBy
    timeLocked
    invoiceTemplateDetailId
  }
  ${BASE_FRAGMENT}
`;

export const ALL_BILL_TEMPLATES = gql`
  ${BILL_TEMPLATE_FRAGMENT}
  query ${TENANT_PREFIX}billTemplates($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}billTemplates(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const PAGINATED_BILL_TEMPLATES = gql`
  ${BILL_TEMPLATE_FRAGMENT}
  query ${PAGINATED_BILL_TEMPLATES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_BILL_TEMPLATES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_BILL_TEMPLATES_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_BILL_TEMPLATE_BY_ID = gql`
  ${BILL_TEMPLATE_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ById: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ById) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_BILL_TEMPLATE = gql`
  ${BILL_TEMPLATE_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_BILL_TEMPLATE = gql`
  ${BILL_TEMPLATE_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_BILL_TEMPLATE = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_BILL_TEMPLATES = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const UPDATE_BILL_TEMPLATE_STATUS = gql`
  mutation ${TENANT_PREFIX}update${TITLE}Status($status: String!, $id: String!) {
    ${TENANT_PREFIX}update${TITLE}Status(status: $status, id: $id) {
      id
    }
  }
`;

export const GET_BILL_TEMPLATE_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}sDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}sDashboard(dashboardArg: $dashboardArg) {
      all
      active
      inactive
    }
  }
`;

export const BILL_TEMPLATES_FOR_RECOMMENDATIONS = gql`
  query ${TENANT_PREFIX}billTemplatesForRecommendations($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}billTemplates(sortArg: $sortArg, searchArg: $searchArg) {
      id
      totalAmount
      billType
      account {
        id
        name
      }
      location {
        id
        name
      }
    }
  }
`;

export const GET_BILL_TEMPLATE_CSV = gql`
  query ${TENANT_PREFIX}BillTemplateCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}BillTemplateCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const FORCE_GENERATE_BILL = gql`
  mutation ${TENANT_PREFIX}forceGenerateBill($billTemplateId: String!) {
    ${TENANT_PREFIX}forceGenerateBill(billTemplateId: $billTemplateId) {
      id
      billNo
    }
  }
`;
