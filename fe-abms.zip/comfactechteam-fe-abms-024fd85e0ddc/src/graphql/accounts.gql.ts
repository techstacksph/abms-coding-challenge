import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Account`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ACCOUNT_FRAGMENT = gql`
  fragment AccountsFragment on ${MODEL_NAME} {
    id
    name
    accountNumber
    accountType
    notes
    website
    bankAccountNo
    gst
    nzbn
    paymentTermId
    primaryContact{
      id
      firstName
      lastName
      fullName
      phone
      mobile
      email
      jobTitle
    }
    pFindAddress
    pStreetAddress
    pSuburb
    pCity
    pRegion
    pPostalCode
    pPlaceId
    pCountry{
      id
      name
      code
    }
    pLongitude
    pLatitude
    bFindAddress
    bStreetAddress
    bSuburb
    bCity
    bRegion
    bPostalCode
    bLongitude
    bLatitude
    bPlaceId
    bCountry{
      id
      name
      code
    }
    location{
      id
      name
    }
    locations{
      id
      name
    }
    source{
      id
      name
    }
    priceList{
      id
      name
    }
    requiresPO
    isSameAsPhysicalAddress
    franchiseeType
    regionalFranchisor{
      id
      name
    }
    ayrEmail
    ayrMobile
    irdNo
    equipmentTopUpFee
    recruitmentId
    startDate
    legalName
    status{
      id
      name
    }
    physicalAddress
    billingAddress
    supplierAccountNo
    supplierType{
      id
      name
    }
    minimumLeadTime
    maximumLeadTime
    lead{
      id
      location{
        id
      }
      recordOwner{
        id
      }
      site{
        id
      }
      status{
        id
      }
      company
    }
    bankName
    bankAccountName
    bankAddress
    recordOwner{
      id
      firstName
      lastName
    }
    statusNotes
    pArea{
      id
      area
    }
    bArea{
      id
      area
    }
    hasDeals
    subconAccountNo
    subconType
    accountCode{
      id
      accountCode
    }
    interestedService {
      id
      servicetype
    }

    paymentTerm {
      id
      paymentTerm
    }
    
    relatedUsers {
      id
      fullName
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_ACCOUNTS_REVISED = gql`
  query paginatedAccounts($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedAccounts(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        id
        name
        accountNumber
        accountType
        primaryContact{
          id
          firstName
          lastName
          fullName
          phone
          mobile
          email
          jobTitle
        }
        location{
          id
          name
        }
        status{
          id
          name
        }
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const PAGINATED_ACCOUNTS = gql`
  ${ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}paginatedAccounts($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedAccounts(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...AccountsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_ACCOUNTS = gql`
  ${ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      ...AccountsFragment
      ...BaseFragment
    }
  }
`;

export const ALL_ACCOUNTS_IDS = gql`
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_ACCOUNTS = gql`
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      locationId
      location {
        id
        name
      }
      accountType
      franchiseeType
      primaryContact {
        phone
        email
      }
    }
  }
`;

export const SELECT_ACCOUNT_CONTACT = gql`
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      id
      primaryContact{
        id
      }
    }
  }
`;

export const SELECT_SERVICE_PROVIDERS = gql`
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      accountType
    }
  }
`;

export const SELECT_FILTER_ACCOUNTS = gql`
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      locationId
      accountType
      relatedUsers {
        id
      }
      status{
        name
      }
    }
  }
`;

export const SELECT_ACCOUNTS_WITH_QUERIES = gql`
  query ${TENANT_PREFIX}accounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      locationId
      accountType
      status{
        id
        name
      }
      location {
        id
        name
      }
      relatedUsers {
        id
        locationId
        location {
          id
          name
        }
      }
      primaryContact {
        phone
        email
      }
    }
  }
`;

export const FIND_ACCOUNT_BY_ID = gql`
  ${ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      ...AccountsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ACCOUNT_BY_ID = gql`
  ${ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}updateAccount($account: ${TENANT_PREFIX}AccountInput!, $${TENANT_PREFIX}updateAccountId: String!) {
    ${TENANT_PREFIX}updateAccount(account: $account, id: $${TENANT_PREFIX}updateAccountId) {
      ...AccountsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ACCOUNT = gql`
  ${ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}createAccount($account: ${TENANT_PREFIX}AccountInput!) {
    ${TENANT_PREFIX}createAccount(account: $account) {
      ...AccountsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ACCOUNT = gql`
  mutation ${TENANT_PREFIX}deleteAccount($${TENANT_PREFIX}deleteAccountId: String!) {
    ${TENANT_PREFIX}deleteAccount(id: $${TENANT_PREFIX}deleteAccountId)
  }
`;

export const DELETE_ACCOUNTS = gql`
  mutation ${TENANT_PREFIX}deleteAccounts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAccounts(ids: $ids)
  }
`;

export const GET_ACCOUNT_CSV = gql`
  query ${TENANT_PREFIX}AccountCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}AccountCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const ACCOUNT_DASHBOARD = gql`
  query ${TENANT_PREFIX}accountsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}accountsDashboard(dashboardArg: $dashboardArg) {
      active
      all
      inactive
    }
  }
`;

export const UPDATE_ACCOUNT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateAccountStatus($${TENANT_PREFIX}updateAccountStatusId: String!, $status: ${TENANT_PREFIX}AccountStatusInput!) {
    ${TENANT_PREFIX}updateAccountStatus(id: $${TENANT_PREFIX}updateAccountStatusId, status: $status) {
      id
    }
  }
`;

export const GET_ACCOUNT_TYPE_BY_ID = gql`
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      accountType
    }
  }
`;

export const GET_PRIMARY_CONTACT = gql`
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      primaryContact{
        id
        fullName
        mobile
        email
      }
    }
  }
`;

// export const FIND_ALL_ACCOUNT_IDS = gql`
//   query ${TENANT_PREFIX}findAllAccountIds {
//     ${TENANT_PREFIX}accounts {
//       id
//     }
//   }
// `;

export const FIND_ALL_ACCOUNT_IDS = gql`
  query ${TENANT_PREFIX}accounts {
    ${TENANT_PREFIX}accounts {
      id
      name
      locationId
    }
  }
`;
