import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Document`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DOCUMENT_FRAGMENT = gql`
  fragment DocumentFragment on ${MODEL_NAME} {
    id
    documentName
    description
    documentType {
      id
      name
      description
    }
    event {
      id
      subject
    }
    account {
      id
      name
    }
    lead {
      id
      lead
    }
    deal {
      id
      dealNo
      dealname
    }
    site {
      id
      siteName
      lastActivity
    }
    job {
      id
      jobNo
    }
    case {
      id
      caseNo
    }
    training {
      id
      trainingDate
    }
    agreement {
      id
      agreementNo
    }
    qualityAudit {
      id
      qaNo
    }
    file1
    file2
    file3
    file4
    file5
  }
  ${BASE_FRAGMENT}
`;

export const ALL_DOCUMENT_TYPES = gql`
  query ${TENANT_PREFIX}documentTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}documentTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      description
      updatedAt
      updatedBy
    }
  }
`;

export const CREATE_TASKS = gql`
  mutation ${TENANT_PREFIX}createTask($task: abmsTaskInput!) {
    ${TENANT_PREFIX}createTask(task: $task) {
      id
      description,
      subject,
      dueDate
    }
  }
`;

export const CREATE_DOCUMENT = gql`
  mutation ${TENANT_PREFIX}createDocument($document: ${TENANT_PREFIX}DocumentInput!) {
    ${TENANT_PREFIX}createDocument(document: $document) {
      id
      documentName
    }
  }
`;

export const FIND_DOCUMENT_BY_ID = gql`
  ${DOCUMENT_FRAGMENT}
  query ${TENANT_PREFIX}findDocumentById($${TENANT_PREFIX}findDocumentByIdId: String!) {
    ${TENANT_PREFIX}findDocumentById(id: $${TENANT_PREFIX}findDocumentByIdId) {
      ...DocumentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DOCUMENT_BY_ID = gql`
  mutation ${TENANT_PREFIX}updateDocument($document: ${TENANT_PREFIX}DocumentInput!, $${TENANT_PREFIX}updateDocumentId: String!) {
    ${TENANT_PREFIX}updateDocument(document: $document, id: $${TENANT_PREFIX}updateDocumentId) {
      id
      documentName
    }
  }
`;
