import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CreditDebitNote`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_CREDIT_DEBIT_NOTES_TITLE = 'paginatedCreditDebitNotes';
//temporary removed xero fragment to avoid error in credit debit note gql
export const CREDIT_DEBIT_NOTE_FRAGMENT = gql`
  fragment CreditDebitNoteFragment on ${MODEL_NAME} {
    id
    creditDebitNo
    type
    jobId
    salesOrderId
    reasonForCredit
    otherReason
    creditDate
    notes
    startDate
    endDate
    creditAmountGST
    debitAmountGST
    serviceProvider
    schedule
    cleaningTime
    cleaningDays
    creditAmount
    commissions
    debitAmount
    totalCleaningDays
    totalCreditAmount
    totalDebitAmount
    statusId
    xeroCreditStatus
    xeroDebitStatus
    creditNotePDF
    debitNotePDF
    locationId
    xeroId
    creditFileName
    debitFileName
    job {
      id
      jobNo
      account {
        id
        name
        billingAddress
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
        bCountry {
          name
        }
      }
      contact {
        id
        firstName
        lastName
        fullName
        email
        mobile
        phone
      }
    }
    salesOrder {
      id
      soNo
      orderType
      customer {
        id
        name
        billingAddress
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
        bCountry {
          name
        }
      }
      franchisee {
        id
        name
        billingAddress
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
        bCountry {
          name
        }
      }
      contact {
        id
        firstName
        lastName
        fullName
        email
        mobile
        phone
      }
    }
    status {
      id
      name
    }
    location {
      id
      name
      financeEmail
      billingAccount {
        id
        legalName
        billingAddress
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
        gst
        primaryContact {
          id
          phone
          email
        }
      }
      billingAccountId
    }
    # xero {
    #   id
    #   xeroAccount
    # }
    createdByName
    creditDebitNoteToFranchisees {
      id
      franchiseeId
      franchisees {
        id
        name
      }
    }
    creditDebitNoteDetails {
      id
      accountId
      schedule
      cleaningTime
      cleaningDays
      creditAmount
      commissionType
      commission
      debitAmount
      debitNo
      franchisee {
        id
        name
      }
      xeroDebitStatus {
        id
        name
      }
    }
  }

  ${BASE_FRAGMENT}
`;

export const FIND_CREDIT_DEBIT_NOTE_BY_ID = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${TENANT_PREFIX}findCreditDebitNoteById($${TENANT_PREFIX}findCreditDebitNoteByIdId: String!) {
    ${TENANT_PREFIX}findCreditDebitNoteById(id: $${TENANT_PREFIX}findCreditDebitNoteByIdId) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CREDIT_DEBIT_NOTES = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${TENANT_PREFIX}creditDebitNotes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}creditDebitNotes(sortArg: $sortArg, searchArg: $searchArg) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_CREDIT_DEBIT_NOTES = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${PAGINATED_CREDIT_DEBIT_NOTES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_CREDIT_DEBIT_NOTES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CreditDebitNoteFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const CREATE_CREDIT_DEBIT_NOTE = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}createCreditDebitNote($creditDebitNote: ${TENANT_PREFIX}CreditDebitNoteInputSchema!) {
    ${TENANT_PREFIX}createCreditDebitNote(creditDebitNote: $creditDebitNote) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CREDIT_DEBIT_NOTE = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCreditDebitNote($creditDebitNote: ${TENANT_PREFIX}CreditDebitNoteInputSchema!, $${TENANT_PREFIX}updateCreditDebitNoteId: String!) {
    ${TENANT_PREFIX}updateCreditDebitNote(creditDebitNote: $creditDebitNote, id: $${TENANT_PREFIX}updateCreditDebitNoteId) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CREDIT_DEBIT_NOTE = gql`
  mutation ${TENANT_PREFIX}deleteCreditDebitNote($${TENANT_PREFIX}deleteCreditDebitNoteId: String!) {
    ${TENANT_PREFIX}deleteCreditDebitNote(id: $${TENANT_PREFIX}deleteCreditDebitNoteId)
  }
`;

export const DELETE_CREDIT_DEBIT_NOTES = gql`
  mutation ${TENANT_PREFIX}deleteCreditDebitNotes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCreditDebitNotes(ids: $ids)
  }
`;

export const ALL_CREDIT_DEBIT_NOTES_FOR_DASHBOARD = gql`
  query ${TENANT_PREFIX}creditDebitNotes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}creditDebitNotes(sortArg: $sortArg, searchArg: $searchArg) {
      id
      statusId
    }
  }
`;

// Note: For status updates, use the UPDATE_CREDIT_DEBIT_NOTE mutation and pass the statusId within the creditDebitNote input.

// Query to calculate credit/debit amounts for a job
export const CALCULATE_CREDIT_DEBIT = gql`
  query ${TENANT_PREFIX}calculateCreditDebit($input: ${TENANT_PREFIX}CreditDebitCalculationInput!) {
    ${TENANT_PREFIX}calculateCreditDebit(input: $input) {
      details {
        serviceProviderId
        serviceProviderName
        schedule
        cleaningTime
        days
        frequency
        cleaningDays
        totalMonthCleaningDays
        dailyCreditAmount
        creditAmount
        commissionType
        commission
        dailyDebitAmount
        debitAmount
        invoiceUnitPrice
        billUnitPrice
      }
      totalCleaningDays
      totalCreditAmount
      totalDebitAmount
    }
  }
`;
