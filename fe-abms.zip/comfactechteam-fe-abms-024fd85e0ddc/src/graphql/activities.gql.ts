import { gql } from '@apollo/client';

import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Activity`;

export const ACTIVITY_FRAGMENT = gql`
  fragment ActivitiesFragment on ${MODEL_NAME} {
    id
    createdAt
    updatedAt
    createdByName
    createdBy
    notes
    commType
    subjectEmail
    bodyEmail
    bodyEmailPreview
    messageSMS
    subjectCall
    callOutcome
    callType
    accountId
    dealId
    siteId
    caseId
    jobId
    qualityAuditId
    invoiceId
    updatedByName
  }
`;

export const ACTIVITIES_BY_MODULE = gql`
  ${ACTIVITY_FRAGMENT}
  query ${TENANT_PREFIX}activities($${TENANT_PREFIX}relatedRecordId: String!, $${TENANT_PREFIX}relatedRecordFieldName: String!, $${TENANT_PREFIX}searchKeyword: String!) {
    ${TENANT_PREFIX}activities(relatedRecordId: $${TENANT_PREFIX}relatedRecordId, relatedRecordFieldName: $${TENANT_PREFIX}relatedRecordFieldName, searchKeyword: $${TENANT_PREFIX}searchKeyword) {
      ...ActivitiesFragment
    }
  }
`;

export const ACTIVITIES_BY_MODULE_IDS = gql`
  query ${TENANT_PREFIX}activities($${TENANT_PREFIX}relatedRecordId: String!, $${TENANT_PREFIX}relatedRecordFieldName: String!, $${TENANT_PREFIX}searchKeyword: String!) {
    ${TENANT_PREFIX}activities(relatedRecordId: $${TENANT_PREFIX}relatedRecordId, relatedRecordFieldName: $${TENANT_PREFIX}relatedRecordFieldName, searchKeyword: $${TENANT_PREFIX}searchKeyword) {
      id 
      accountId
    }
  }
`;

export const ACTIVITIES_BY_MODULE_ID = gql`
  query ${TENANT_PREFIX}activities($${TENANT_PREFIX}relatedRecordId: String!, $${TENANT_PREFIX}relatedRecordFieldName: String!, $${TENANT_PREFIX}searchKeyword: String!) {
    ${TENANT_PREFIX}activities(relatedRecordId: $${TENANT_PREFIX}relatedRecordId, relatedRecordFieldName: $${TENANT_PREFIX}relatedRecordFieldName, searchKeyword: $${TENANT_PREFIX}searchKeyword) {
      id
      accountId
    }
  }
`;

export const PAGINATED_ACTIVITIES_BY_MODULE = gql`
  ${ACTIVITY_FRAGMENT}
  query paginatedActivities($${TENANT_PREFIX}relatedRecordId: String!, $${TENANT_PREFIX}relatedRecordFieldName: String!, $pageArg: ${TENANT_PREFIX}PageArg, $${TENANT_PREFIX}searchKeyword: String!) {
    ${TENANT_PREFIX}paginatedActivities(relatedRecordId: $${TENANT_PREFIX}relatedRecordId, relatedRecordFieldName: $${TENANT_PREFIX}relatedRecordFieldName, pageArg: $pageArg, searchKeyword: $${TENANT_PREFIX}searchKeyword) {
      data {
        ...ActivitiesFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;
