import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Rating`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const RATING_FRAGMENT = gql`
 fragment RatingFragment on ${MODEL_NAME} {
    id
    ratingDescription
    ratingName
    scale
    ratingScales {
      id
    }
  }
  ${BASE_FRAGMENT}
`;

export const CREATE_UPDATE_RATINGS = gql`
${RATING_FRAGMENT}
mutation ${TENANT_PREFIX}upsertRatings($updateRatings: [${TENANT_PREFIX}RatingInput!]!) {
  ${TENANT_PREFIX}upsertRatings(updateRatings: $updateRatings) {
    ...RatingFragment
    ...BaseFragment    
  }
}
`;

export const DELETE_RATING = gql`
mutation ${TENANT_PREFIX}deleteRating($${TENANT_PREFIX}deleteRatingId: String!) {
  ${TENANT_PREFIX}deleteRating(id: $${TENANT_PREFIX}deleteRatingId)
}
`;
