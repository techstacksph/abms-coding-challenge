import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const TOP_BEST_SELLING_PRODUCTS = gql`
  query ${TENANT_PREFIX}topBestSellingProducts($filter: ${TENANT_PREFIX}BestSellingProductFilterInput) {
    ${TENANT_PREFIX}topBestSellingProducts(filter: $filter) {
      products {
        itemId
        itemName
        itemCode
        totalQuantitySold
        price
        totalRevenue
        rank
      }
      totalCount
      periodStart
      periodEnd
    }
  }
`;
