import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Area`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const AREA_FRAGMENT = gql`
  fragment AreaFragment on ${MODEL_NAME} {
    id
    area
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_AREAS = gql`
  ${AREA_FRAGMENT}
  query paginatedAreas($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedAreas(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...AreaFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_AREAS = gql`
  ${AREA_FRAGMENT}
  query ${TENANT_PREFIX}areas($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}areas(sortArg: $sortArg, searchArg: $searchArg) {
      ...AreaFragment
      ...BaseFragment
    }
  }
`;

export const ALL_AREAS_IDS = gql`
  query ${TENANT_PREFIX}areas($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}areas(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_AREAS = gql`
  query ${TENANT_PREFIX}areas($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}areas(sortArg: $sortArg, searchArg: $searchArg) {
      id
      area
    }
  }
`;

export const FIND_AREA_BY_ID = gql`
  ${AREA_FRAGMENT}
  query findAreaById($${TENANT_PREFIX}findAreaByIdId: String!) {
    ${TENANT_PREFIX}findAreaById(id: $${TENANT_PREFIX}findAreaByIdId) {
      ...AreaFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_AREA_BY_ID = gql`
  ${AREA_FRAGMENT}
  mutation updateArea($area: ${TENANT_PREFIX}AreaInput!, $${TENANT_PREFIX}updateAreaId: String!) {
    ${TENANT_PREFIX}updateArea(area: $area, id: $${TENANT_PREFIX}updateAreaId) {
      ...AreaFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_AREA = gql`
  ${AREA_FRAGMENT}
  mutation createArea($area: ${TENANT_PREFIX}AreaInput!) {
    ${TENANT_PREFIX}createArea(area: $area) {
      ...AreaFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_AREA = gql`
  mutation deleteArea($${TENANT_PREFIX}deleteAreaById: String!) {
    ${TENANT_PREFIX}deleteArea(id: $${TENANT_PREFIX}deleteAreaById)
  }
`;

export const DELETE_AREAS = gql`
  mutation deleteAreas($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAreas(ids: $ids)
  }
`;

export const GET_AREA_CSV = gql`
  query ${TENANT_PREFIX}AreaCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}AreaCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
