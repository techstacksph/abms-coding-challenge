import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CommunicationLog`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const COMM_LOG_FRAGMENT = gql`
  fragment CommLogFragment on ${MODEL_NAME} {
    id
    createdBy
    createdByName
    commType
    recipient
    subjectEmail
    bodyEmail
    messageSMS
    toSMS
    subjectCall
    callType
    callOutcome
    from
    fromEmail
    toEmail
    ccEmail
    ccEmailText
    bccEmail
    module {
      id
      name
      code
    }
    account {
      id
      name
    }
    franchiseeNotification{
      id
      subject
    }
    task {
      id
      taskSubject
    }
    event {
      id
      subject
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_COMM_LOGS = gql`
  ${COMM_LOG_FRAGMENT}
  query ${TENANT_PREFIX}communicationLogs(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}communicationLogs(sortArg: $sortArg, searchArg: $searchArg) {
      ...CommLogFragment
      ...BaseFragment
    }
  }
`;

export const ALL_COMM_LOGS_IDS = gql`
  query ${TENANT_PREFIX}communicationLogs(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}communicationLogs(sortArg: $sortArg, searchArg: $searchArg) {
      id
      account {
        id
      }
      event {
        id
      }
      commType
    }
  }
`;

export const ALL_COMM_LOGS_BY_TYPE = gql`
  query ${TENANT_PREFIX}communicationLogs(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}communicationLogs(sortArg: $sortArg, searchArg: $searchArg) {
      commType
    }
  }
`;
export const ALL_COMM_LOGS_IDS_BY_MODULE = gql`
  query ${TENANT_PREFIX}communicationLogs(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}communicationLogs(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_COMM_LOG_BY_ID = gql`
  ${COMM_LOG_FRAGMENT}
  query ${TENANT_PREFIX}findCommunicationLogById($${TENANT_PREFIX}findCommunicationLogByIdId: String!) {
    ${TENANT_PREFIX}findCommunicationLogById(id: $${TENANT_PREFIX}findCommunicationLogByIdId) {
      ...CommLogFragment
      ...BaseFragment
    }
  }
`;

export const CHECK_COMM = gql`
  query ${TENANT_PREFIX}findCommunicationLogById($${TENANT_PREFIX}findCommunicationLogByIdId: String!) {
    ${TENANT_PREFIX}findCommunicationLogById(id: $${TENANT_PREFIX}findCommunicationLogByIdId) {
      id
    }
  }
`;

export const CREATE_COMM_LOG = gql`
  ${COMM_LOG_FRAGMENT}
  mutation ${TENANT_PREFIX}createCommunicationLog(
    $communicationLog: ${TENANT_PREFIX}CommunicationLogInput!
    $isVirtual: Boolean
    $parentId: String
    $parentType: ParentType
    $startDate: String
  ) {
    ${TENANT_PREFIX}createCommunicationLog(
      communicationLog: $communicationLog
      isVirtual: $isVirtual
      parentId: $parentId
      parentType: $parentType
      startDate: $startDate
    ) {
      ...CommLogFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_COMM_LOGS = gql`
  mutation ${TENANT_PREFIX}createCommunicationLogs($communicationLogs: [${TENANT_PREFIX}CommunicationLogInput!]!) {
    ${TENANT_PREFIX}createCommunicationLogs(communicationLogs: $communicationLogs) {
      id
    }
  }
`;

export const UPDATE_COMM_LOG_BY_ID = gql`
  ${COMM_LOG_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCommunicationLog($communicationLog: ${TENANT_PREFIX}CommunicationLogInput!, $${TENANT_PREFIX}updateCommunicationLogId: String!) {
    ${TENANT_PREFIX}updateCommunicationLog(communicationLog: $communicationLog, id: $${TENANT_PREFIX}updateCommunicationLogId) {
      ...CommLogFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_COMM_LOG = gql`
  mutation ${TENANT_PREFIX}deleteCommunicationLog($${TENANT_PREFIX}deleteCommunicationLogId: String!) {
    ${TENANT_PREFIX}deleteCommunicationLog(id: $${TENANT_PREFIX}deleteCommunicationLogId)
  }
`;

export const UPDATE_COMM_LOG = gql`
  ${COMM_LOG_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCommunicationLog($communicationLog: ${TENANT_PREFIX}CommunicationLogInput!, $${TENANT_PREFIX}updateCommunicationLogId: String!) {
  ${TENANT_PREFIX}updateCommunicationLog(communicationLog: $communicationLog, id: $${TENANT_PREFIX}updateCommunicationLogId) {
    ...CommLogFragment
    ...BaseFragment
  }
}
`;

export const DELETE_COMM_LOGs = gql`
  mutation ${TENANT_PREFIX}deleteCommunicationLogs($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCommunicationLogs(ids: $ids)
  }
`;

export const GET_COMM_LOG_CSV = gql`
  query Query($sortArg: [${TENANT_PREFIX}SortArg!], $columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
  ${TENANT_PREFIX}communicationLogsCSV(sortArg: $sortArg, columnArg: $columnArg, searchArg: $searchArg)
}
`;

export const GET_COMM_LOG_DASHBOARD = gql`
  query ${TENANT_PREFIX}communicationLogsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}communicationLogsDashboard(dashboardArg: $dashboardArg) {
      all
      calls
      email
      sms
    }
  }
`;

export const PAGINATED_COMM_LOG = gql`
  ${COMM_LOG_FRAGMENT}
  query ${TENANT_PREFIX}paginatedCommunicationLogs(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $pageArg: ${TENANT_PREFIX}PageArg
  ) {
    ${TENANT_PREFIX}paginatedCommunicationLogs(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CommLogFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const COMM_LOGS_BY_FRANCHISEE_NOTIFICATION = gql`
  ${COMM_LOG_FRAGMENT}
  query ${TENANT_PREFIX}communicationLogs(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}communicationLogs(sortArg: $sortArg, searchArg: $searchArg) {
      ...CommLogFragment
      ...BaseFragment
    }
  }
`;
