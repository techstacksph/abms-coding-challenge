import { gql } from '@apollo/client';
import environment from '@/config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
// Note: Backend uses "Employement" (misspelled) instead of "Employment"
const MODEL_NAME = `${TENANT_PREFIX}EmployementHistory`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const EMPLOYMENT_HISTORY_FRAGMENT = gql`
  fragment EmploymentHistoryFragment on ${MODEL_NAME} {
    id
    startDate
    endDate
    employmentType
    jobTitle { id name }
    status { id name }
    employee { id fullName }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_EMPLOYMENT_HISTORIES = gql`
  ${EMPLOYMENT_HISTORY_FRAGMENT}
  query ${TENANT_PREFIX}paginatedEmployementHistory($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedEmployementHistory(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...EmploymentHistoryFragment
        ...BaseFragment
      }
      pageInfo { count skip take pageSize pageCount }
    }
  }
`;

export const PAGINATED_EMPLOYMENT_HISTORIES = gql`
  ${EMPLOYMENT_HISTORY_FRAGMENT}
  query ${TENANT_PREFIX}paginatedEmployementHistories($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedEmployementHistories(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...EmploymentHistoryFragment
        ...BaseFragment
      }
      pageInfo { count skip take pageSize pageCount }
    }
  }
`;

export const FIND_EMPLOYMENT_HISTORY_BY_ID = gql`
  ${EMPLOYMENT_HISTORY_FRAGMENT}
  query ${TENANT_PREFIX}findEmployementHistoryById($${TENANT_PREFIX}findEmployementHistoryByIdId: String!) {
    ${TENANT_PREFIX}findEmployementHistoryById(id: $${TENANT_PREFIX}findEmployementHistoryByIdId) {
      ...EmploymentHistoryFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_EMPLOYMENT_HISTORY = gql`
  mutation ${TENANT_PREFIX}createEmployementHistory($employementHistory: ${TENANT_PREFIX}EmployementHistoryInput!) {
    ${TENANT_PREFIX}createEmployementHistory(employementHistory: $employementHistory) { id }
  }
`;

export const UPDATE_EMPLOYMENT_HISTORY = gql`
  mutation ${TENANT_PREFIX}updateEmployementHistory($employementHistory: ${TENANT_PREFIX}EmployementHistoryInput!, $${TENANT_PREFIX}updateEmployementHistoryId: String!) {
    ${TENANT_PREFIX}updateEmployementHistory(employementHistory: $employementHistory, id: $${TENANT_PREFIX}updateEmployementHistoryId) { id }
  }
`;

export const DELETE_EMPLOYMENT_HISTORY = gql`
  mutation ${TENANT_PREFIX}deleteEmployementHistory($${TENANT_PREFIX}deleteEmployementHistoryId: String!) {
    ${TENANT_PREFIX}deleteEmployementHistory(id: $${TENANT_PREFIX}deleteEmployementHistoryId)
  }
`;

export const DELETE_EMPLOYMENT_HISTORIES = gql`
  mutation ${TENANT_PREFIX}deleteEmployementHistorys($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEmployementHistorys(ids: $ids)
  }
`;

export const UPDATE_EMPLOYMENT_HISTORY_STATUS = gql`
  mutation ${TENANT_PREFIX}updateEmployementHistoryStatus($${TENANT_PREFIX}updateEmployementHistoryStatusId: String!, $status: ${TENANT_PREFIX}EmployementHistoryStatusInput!) {
    ${TENANT_PREFIX}updateEmployementHistoryStatus(id: $${TENANT_PREFIX}updateEmployementHistoryStatusId, status: $status) { id }
  }
`;
