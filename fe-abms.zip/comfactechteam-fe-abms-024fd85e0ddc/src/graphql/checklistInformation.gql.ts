import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ChecklistDetails`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CHECKLIST_INFO_FRAGMENT = gql`
 fragment ChecklistFragment on ${MODEL_NAME} {
    id
    description
    checklist
    checkListInformation {
      id
    }
  }
  ${BASE_FRAGMENT}
`;

export const CREATE_UPDATE_CHECKLIST = gql`
  ${CHECKLIST_INFO_FRAGMENT}
  mutation AbmsupsertCheckListDetails(
    $updateCheckLists: [abmsChecklistDetailsInput!]!
  ) {
    abmsupsertCheckListDetails(updateCheckLists: $updateCheckLists) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CHECKLISTS = gql`
  mutation AbmsdeleteCheckListDetails($ids: [String!]!) {
    abmsdeleteCheckListDetails(ids: $ids)
  }
`;

export const GET_CHECKLIST_DETAILS = gql`
  ${CHECKLIST_INFO_FRAGMENT}
  query AbmscheckListDetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    abmscheckListDetails(sortArg: $sortArg, searchArg: $searchArg) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;
