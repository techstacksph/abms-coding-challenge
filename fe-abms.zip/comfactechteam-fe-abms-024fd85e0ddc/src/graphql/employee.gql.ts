import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Employee`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_EMPLOYEES_TITLE = 'paginatedEmployees';

export const EMPLOYEE_FRAGMENT = gql`
  fragment EmployeeFragment on ${MODEL_NAME} {
    id
    code
    firstName
    middleName
    lastName
    title
    email
    phoneNo
    mobileNo
    profilePicture
    preferredName
    gender
    nationalityId
    dateOfBirth
    martialStatus
    citizenship
    medicalCondition
    streetAddress
    findAddress
    suburb
    city
    region
    postalCode
    countryId
    userId
    employmentType
    startDate
    terminationDate
    probationLength
    primaryManagerId
    secondaryManagerId
    workPhoneNo
    workMobileNo
    workEmail
    notes
    profilePicture
    jobTitle {
      id
      name
    }
    location {
      id
      name
    }
    departments {
      id 
      name
    }
    status {
      id 
      name
    }
    industryStandardJobTitle { 
      id 
      name
    }
    taxCodeDeclarationDetails {
      id
      irdNo
      taxCode
      sourceOfIncome
      # dateSigned
      taxDeclaration
      signature
      disclaimer
    }
    primaryManager{
      id
      fullName
      firstName
      lastName
      email
      mobile
    }
    secondaryManager{
      id
      fullName
      firstName
      lastName
      email
      mobile
    }
    country {
      id 
      name
    }
    area {
      id
      area
    }
    fullName
  }
  ${BASE_FRAGMENT}
`;

export const ALL_EMPLOYEES = gql`
  ${EMPLOYEE_FRAGMENT}
  query ${TENANT_PREFIX}Employees($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}Employees(searchArg: $searchArg, sortArg: $sortArg) {
      ...EmployeeFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_EMPLOYEES = gql`
  ${EMPLOYEE_FRAGMENT}
  query ${PAGINATED_EMPLOYEES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_EMPLOYEES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...EmployeeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const SELECT_EMPLOYEES = gql`
  query ${TENANT_PREFIX}Employees{
    ${TENANT_PREFIX}Employees{
      id
      firstName
      lastName
      fullName
      email
      mobileNo
      relatedUserId
      location {
        id
        name
      }
      departments {
        id
        name
      }
      primaryManager {
        id
        firstName
        lastName
        name
      }
    }
  }
`;

export const CREATE_EMPLOYEE = gql`
  mutation ${TENANT_PREFIX}createEmployee($employee: ${TENANT_PREFIX}EmployeeInput!) {
    ${TENANT_PREFIX}createEmployee(employee: $employee) {
      id
      fullName
    }
  }
`;

export const DELETE_EMPLOYEE = gql`
  mutation ${TENANT_PREFIX}deleteEmployees($${TENANT_PREFIX}deleteEmployeeId: String!) {
    ${TENANT_PREFIX}deleteEmployee(id: $${TENANT_PREFIX}deleteEmployeeId)
  }
`;

export const DELETE_EMPLOYEES = gql`
  mutation ${TENANT_PREFIX}deleteEmployees($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEmployees(ids: $ids)
  }
`;

export const FIND_EMPLOYEE_BY_ID = gql`
  ${EMPLOYEE_FRAGMENT}
  query ${TENANT_PREFIX}findEmployeeById($${TENANT_PREFIX}findEmployeeByIdId: String!) {
    ${TENANT_PREFIX}findEmployeeById(id: $${TENANT_PREFIX}findEmployeeByIdId) {
      ...EmployeeFragment
      ...BaseFragment
      nationality {
        id 
        name
      }
    }
  }
`;

export const UPDATE_EMPLOYEE_BY_ID = gql`
  mutation ${TENANT_PREFIX}updateEmployee($employee: ${TENANT_PREFIX}EmployeeInput!, $${TENANT_PREFIX}updateEmployeeId: String!) {
    ${TENANT_PREFIX}updateEmployee(employee: $employee, id: $${TENANT_PREFIX}updateEmployeeId) {
      id
      fullName
      taxCodeDeclarationDetails {
        id
      }
    }
  }
`;

export const GET_EMPLOYEE_DASHBOARD = gql`
  query ${TENANT_PREFIX}employeeDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}employeeDashboard(dashboardArg: $dashboardArg) {
      all
      active
      inactive
    }
  }
`;

export const UPDATE_EMPLOYEE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateEmployeeStatus($${TENANT_PREFIX}updateEmployeeStatusId: String!, $status: ${TENANT_PREFIX}EmployeeStatusInput!) {
    ${TENANT_PREFIX}updateEmployeeStatus(id: $${TENANT_PREFIX}updateEmployeeStatusId, status: $status) {
      id
    }
  }
`;
