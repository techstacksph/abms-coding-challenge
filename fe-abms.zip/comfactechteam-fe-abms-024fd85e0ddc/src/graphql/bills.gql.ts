import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Bill`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const BILL_FRAGMENT = gql`
  fragment BillFragment on ${MODEL_NAME} {
    id
    reference
    billNo
    billTemplate {
      id
      billTemplateNo
      nextGenerationDate
    }
    invoice {
      id
      invoiceNo
      invoiceDate
    }
    account {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      ayrMobile
      gst
      bankAccountNo
      bStreetAddress
      bSuburb
      bPostalCode
      primaryContact {
        id
        fullName
        phone
      }
    }
    outstandingBalance
    nextGenerationDate
    billingAccount {
      id
      name
      legalName
      billingAddress
      ayrMobile
      gst
      bankAccountNo
    }
    billContacts {
      id
      contact {
        id
        fullName
        email
      }
    }
    billDate
    dueDate
    notes
    location {
      id
      name
      financeEmail
      billingAccount {
        id
        name
        legalName
        billingAddress
        ayrMobile
        gst
        bankAccountNo
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
      }
    }
    xeroAccount {
      id
      xeroAccount
    }
    jobs {
      id
      jobNo
    }
    purchaseOrder {
      id
      poNo
    }
    subType
    status {
      id
      name
    }
    xeroStatus
    type
    gstType
    subtotal
    gstAmount
    totalAmount
    paidAmount
    invoiceDetailId
    exportedId
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_BILLS = gql`
  ${BILL_FRAGMENT}
  query ${TENANT_PREFIX}paginatedBills($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedBills(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...BillFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_BILLS = gql`
  ${BILL_FRAGMENT}
  query ${TENANT_PREFIX}bills($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}bills(sortArg: $sortArg, searchArg: $searchArg) {
      ...BillFragment
      ...BaseFragment
    }
  }
`;

export const ALL_BILLS_IDS = gql`
  query ${TENANT_PREFIX}bills($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}bills(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_BILL_BY_ID = gql`
  ${BILL_FRAGMENT}
  query ${TENANT_PREFIX}findBillById($${TENANT_PREFIX}findBillByIdId: String!) {
    ${TENANT_PREFIX}findBillById(id: $${TENANT_PREFIX}findBillByIdId) {
      ...BillFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_BILL_BY_ID = gql`
  ${BILL_FRAGMENT}
  mutation ${TENANT_PREFIX}updateBill($bill: ${TENANT_PREFIX}BillInput!, $${TENANT_PREFIX}updateBillId: String!) {
    ${TENANT_PREFIX}updateBill(bill: $bill, id: $${TENANT_PREFIX}updateBillId) {
      ...BillFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_BILL = gql`
  ${BILL_FRAGMENT}
  mutation ${TENANT_PREFIX}createBill($bill: ${TENANT_PREFIX}BillInput!) {
    ${TENANT_PREFIX}createBill(bill: $bill) {
      ...BillFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_BILL = gql`
  mutation ${TENANT_PREFIX}deleteBill($${TENANT_PREFIX}deleteBillId: String!) {
    ${TENANT_PREFIX}deleteBill(id: $${TENANT_PREFIX}deleteBillId)
  }
`;

export const DELETE_BILLS = gql`
  mutation ${TENANT_PREFIX}deleteBills($ids: [String!]!) {
    ${TENANT_PREFIX}deleteBills(ids: $ids)
  }
`;

export const UPDATE_BILL_STATUS = gql`
  mutation ${TENANT_PREFIX}updateBillStatus($${TENANT_PREFIX}updateBillStatusId: String!, $status: String!) {
    ${TENANT_PREFIX}updateBillStatus(id: $${TENANT_PREFIX}updateBillStatusId, status: $status) {
      id
    }
  }
`;

export const GET_BILLS_CSV = gql`
  query ${TENANT_PREFIX}BillCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}BillCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const BILLS_DASHBOARD = gql`
  query ${TENANT_PREFIX}billsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}billsDashboard(dashboardArg: $dashboardArg) {
      all
      created
      reviewed
      exported
      data
    }
  }
`;

export const GET_ACCOUNT_PRIMARY_CONTACT_PHONE = gql`
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      id
    primaryContact{
      id
      firstName
      lastName
      fullName
      phone
      mobile
      email
      jobTitle
    }
    }
  }
`;
