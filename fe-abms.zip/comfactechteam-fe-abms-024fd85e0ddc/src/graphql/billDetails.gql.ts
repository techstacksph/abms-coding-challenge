import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}BillDetail`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const BillDetailFragment = gql`
  fragment BillDetailFragment on ${MODEL_NAME} {
    ...BaseFragment
    description
    unitPrice
    qty
    id
    lineAmount
    bill {
      id
      gstType
      gstAmount
      totalAmount
    }
    job {
      id
      jobNo
    }
    item {
      id
      name
    }
    accountCode {
      id
      accountCode
    }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_BILL_DETAILS = gql`
  query ${TENANT_PREFIX}billDetails($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}billDetails(searchArg: $searchArg, sortArg: $sortArg) {
      ...BillDetailFragment
      ...BaseFragment
    }
  }
  ${BillDetailFragment}
`;

export const GET_BILL_DETAIL = gql`
  query ${TENANT_PREFIX}billDetail($id: String!) {
    ${TENANT_PREFIX}billDetail(id: $id) {
      ...BillDetailFragment
      ...BaseFragment
    }
  }
  ${BillDetailFragment}
`;

export const CREATE_BILL_DETAIL = gql`
  mutation ${TENANT_PREFIX}createBillDetail($billDetail: ${TENANT_PREFIX}BillDetailInput!) {
    ${TENANT_PREFIX}createBillDetail(billDetail: $billDetail) {
      ...BillDetailFragment
      ...BaseFragment
    }
  }
  ${BillDetailFragment}
`;

export const UPDATE_BILL_DETAIL = gql`
  ${BillDetailFragment}
  mutation ${TENANT_PREFIX}updateBillDetail($billDetail: ${TENANT_PREFIX}BillDetailInput!, $${TENANT_PREFIX}updateBillDetailId: String!) {
    ${TENANT_PREFIX}updateBillDetail(billDetail: $billDetail, id: $${TENANT_PREFIX}updateBillDetailId) {
      ...BillDetailFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_BILL_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteBillDetail($id: String!) {
    ${TENANT_PREFIX}deleteBillDetail(id: $id)
  }
`;
