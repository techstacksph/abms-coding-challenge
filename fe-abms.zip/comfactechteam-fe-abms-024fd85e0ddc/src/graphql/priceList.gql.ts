import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PriceList`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PRICE_LIST_FRAGMENT = gql`
  fragment PriceListFragment on ${MODEL_NAME} {
    id
    name
    description
    startDate
    endDate
    isActive
    isDefault
    locationName
    effectivityDate
    location{
      id
      name
    }
    status {
      id
      name
    }
    supplier {
      id
      name
    }
    paymentTerm {
      id
      paymentTerm
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_PRICE_LISTS = gql`
  ${PRICE_LIST_FRAGMENT}
  query paginatedPriceLists($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPriceLists(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PriceListFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_PRICE_LISTS = gql`
  ${PRICE_LIST_FRAGMENT}
  query ${TENANT_PREFIX}priceLists($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceLists(sortArg: $sortArg, searchArg: $searchArg) {
      ...PriceListFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DEFAULT_PRICE_LISTS_BY_LOCATION = gql`
  query ${TENANT_PREFIX}priceLists($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceLists(sortArg: $sortArg, searchArg: $searchArg) {
      id
      isDefault
    }
  }
`;

export const ALL_PRICE_LISTS_IDS = gql`
  query ${TENANT_PREFIX}priceLists($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceLists(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_PRICE_LIST_BY_ID = gql`
  ${PRICE_LIST_FRAGMENT}
  query findPriceListById($${TENANT_PREFIX}findPriceListByIdId: String!) {
    ${TENANT_PREFIX}findPriceListById(id: $${TENANT_PREFIX}findPriceListByIdId) {
      ...PriceListFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_PRICE_LIST_BY_ID = gql`
  ${PRICE_LIST_FRAGMENT}
  mutation updatePriceList($priceList: ${TENANT_PREFIX}PriceListInput!, $${TENANT_PREFIX}updatePriceListId: String!) {
    ${TENANT_PREFIX}updatePriceList(priceList: $priceList, id: $${TENANT_PREFIX}updatePriceListId) {
      ...PriceListFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_PRICE_LIST = gql`
  ${PRICE_LIST_FRAGMENT}
  mutation createPriceList($priceList: ${TENANT_PREFIX}PriceListInput!) {
    ${TENANT_PREFIX}createPriceList(priceList: $priceList) {
      ...PriceListFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_PRICE_LIST = gql`
  mutation deletePriceList($${TENANT_PREFIX}deletePriceListById: String!) {
    ${TENANT_PREFIX}deletePriceList(id: $${TENANT_PREFIX}deletePriceListById)
  }
`;

export const DELETE_PRICE_LISTS = gql`
  mutation deletePriceLists($ids: [String!]!) {
    ${TENANT_PREFIX}deletePriceLists(ids: $ids)
  }
`;

export const GET_PRICE_LIST_CSV = gql`
  query ${TENANT_PREFIX}PriceListCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}PriceListCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const UPDATE_PRICE_LIST_STATUS = gql`
  mutation ${TENANT_PREFIX}updatePriceListStatus($${TENANT_PREFIX}updatePriceListStatusId: String!, $status: Boolean!) {
    ${TENANT_PREFIX}updatePriceListStatus(id: $${TENANT_PREFIX}updatePriceListStatusId, status: $status) {
      id
    }
  }
`;

export const PRICE_LIST_DASHBOARD = gql`
  query ${TENANT_PREFIX}priceListDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}priceListDashboard(dashboardArg: $dashboardArg) {
      active
      all
      inactive
    }
  }
`;

export const SELECT_PRICE_LIST = gql`
  query ${TENANT_PREFIX}priceLists($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceLists(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      isActive
      location {
        id
        name
      }
      isDefault
    }
  }
`;

export const SELECT_PRICE_LIST_WITHOUT_LOCATION = gql`
  query ${TENANT_PREFIX}priceLists($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceLists(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      isActive
    }
  }
`;

// Price List Item operations
export const PRICE_LIST_ITEM_FRAGMENT = gql`
  fragment PriceListItemFragment on ${TENANT_PREFIX}PriceListItem {
    id
    amount
    minimumCharge
    profitMargin
    item {
      id
      name
      itemCode
      description
      productImage
    }
    priceList {
      id
      name
    }
    uom {
      id
      name
    }
  }
`;

export const CREATE_PRICE_LIST_ITEM = gql`
  ${PRICE_LIST_ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}createPriceListItem($priceListItem: ${TENANT_PREFIX}PriceListItemInput!) {
    ${TENANT_PREFIX}createPriceListItem(priceListItem: $priceListItem) {
      ...PriceListItemFragment
    }
  }
`;

export const FIND_PRICE_LIST_ITEM_BY_ID = gql`
  ${PRICE_LIST_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}findPriceListItemById($${TENANT_PREFIX}findPriceListItemByIdId: String!) {
    ${TENANT_PREFIX}findPriceListItemById(id: $${TENANT_PREFIX}findPriceListItemByIdId) {
      ...PriceListItemFragment
    }
  }
`;

export const UPDATE_PRICE_LIST_ITEMS = gql`
  ${PRICE_LIST_ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}updatePriceListItems($priceListItems: [${TENANT_PREFIX}PriceListItemInput!]!, $ids: [String!]!) {
    ${TENANT_PREFIX}updatePriceListItems(priceListItems: $priceListItems, ids: $ids) {
      ...PriceListItemFragment
    }
  }
`;

export const DELETE_PRICE_LIST_ITEM = gql`
  mutation ${TENANT_PREFIX}deletePriceListItem($${TENANT_PREFIX}deletePriceListItemId: String!) {
    ${TENANT_PREFIX}deletePriceListItem(id: $${TENANT_PREFIX}deletePriceListItemId)
  }
`;

export const ALL_PRICE_LIST_ITEMS = gql`
  ${PRICE_LIST_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}priceListItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}priceListItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...PriceListItemFragment
    }
  }
`;

export const PRICE_LIST_ITEMS_BY_PRICE_LIST_ID = gql`
  ${PRICE_LIST_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}priceListItems($priceListId: String!) {
    ${TENANT_PREFIX}priceListItems(priceListId: $priceListId) {
      ...PriceListItemFragment
    }
  }
`;
