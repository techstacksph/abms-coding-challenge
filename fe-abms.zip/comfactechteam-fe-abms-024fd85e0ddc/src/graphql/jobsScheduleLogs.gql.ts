import { gql } from '@apollo/client';

import environment from '../config/environment';

const TITLE = 'JobScheduleLog';
const TITLE_SMALL = 'jobScheduleLog';
// const TITLE_FRAGMENT = 'JobScheduleLogFragment';
// const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
// const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_JOBS_TITLE = 'paginatedJobScheduleLogs';

export const JOB_SCHEDULE_LOG_FRAGMENT = gql`
  fragment JobScheduleLogFragment on ${TENANT_PREFIX}JobScheduleLog {
    id
    dateTime
    location
    latitude
    longitude
    logType
    status {
      id
      name
    }
    job {
      id
      jobNo
      site {
        id
        siteName
      }
      account {
        id
        name
      }
      location {
        id
        name
      }
    }
    jobSchedule {
      id
      title
      description
      date
      startTime
      endTime
      duration
      startDate
      actualStart
      actualEnd
      location
      startImage
      endImage
      healthSafety
      acknowledge
      time
      status {
        id
        name
      }
      assignees {
        id
        assignee {
          id
          name
          fullName
          firstName
          lastName
        }
      }
      assignedStaff {
        id
        staff {
          id
          fullName
          firstName
          lastName
        }
      }
      job {
        id
        jobNo
        site {
          id
          siteName
        }
        account {
          id
          name
        }
        location {
          id
          name
        }
      }
      jobAreas {
        id
        area
        completed
        notes
      }
    }
  }

  fragment BaseFragment on ${TENANT_PREFIX}JobScheduleLog {
    createdAt
    updatedAt
    createdBy
    updatedBy
    updatedByName
    createdByName
  }
`;

// Optimized fragment for paginated list view - only includes fields used in the UI
export const PAGINATED_JOB_SCHEDULE_LOG_FRAGMENT = gql`
  fragment PaginatedJobScheduleLogFragment on ${TENANT_PREFIX}JobScheduleLog {
    id
    dateTime
    logType
    jobSchedule {
      id
      title
      date
      startTime
      time
      location
      assignees {
        id
        assignee {
          id
          name
          fullName
        }
      }
      assignedStaff {
        id
        staff {
          id
          fullName
        }
      }
    }
  }

  fragment PaginatedBaseFragment on ${TENANT_PREFIX}JobScheduleLog {
    createdAt
    createdBy
  }
`;

export const PAGINATED_JOB_SCHEDULE_LOGS = gql`
  ${JOB_SCHEDULE_LOG_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobScheduleLogFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

// Optimized paginated query for list view - uses minimal fields for better performance
export const PAGINATED_JOB_SCHEDULE_LOGS_OPTIMIZED = gql`
  ${PAGINATED_JOB_SCHEDULE_LOG_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}Optimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PaginatedJobScheduleLogFragment
        ...PaginatedBaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_JOB_SCHEDULE_LOGS = gql`
  ${JOB_SCHEDULE_LOG_FRAGMENT}
  query ${TENANT_PREFIX}jobScheduleLogs($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobScheduleLogs(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobScheduleLogFragment
      ...BaseFragment
    }
  }
`;

export const ALL_JOB_SCHEDULE_LOG_IDS = gql`
  query ${TENANT_PREFIX}jobScheduleLogs($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobScheduleLogs(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_JOB_SCHEDULE_LOG_BY_ID = gql`
  ${JOB_SCHEDULE_LOG_FRAGMENT}
  query ${TENANT_PREFIX}findJobScheduleLogById($${TENANT_PREFIX}findJobScheduleLogById: String!) {
    ${TENANT_PREFIX}findJobScheduleLogById(id: $${TENANT_PREFIX}findJobScheduleLogById) {
      ...JobScheduleLogFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_JOB_SCHEDULE_LOG_BY_ID = gql`
  ${JOB_SCHEDULE_LOG_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...JobScheduleLogFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_JOB_SCHEDULE_LOG = gql`
  ${JOB_SCHEDULE_LOG_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...JobScheduleLogFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_JOB_SCHEDULE_LOG = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_JOB_SCHEDULE_LOGS = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const GET_JOB_SCHEDULE_LOG_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const JOB_SCHEDULE_LOG_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}sDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}sDashboard(dashboardArg: $dashboardArg) {
      all
      created
      allocated
      complete
      completed
      cancelled
      cancel
      on_hold
    }
  }
`;
export const ALL_JOB_SCHEDULES = gql`
  query ${TENANT_PREFIX}jobSchedules($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}jobSchedules(searchArg: $searchArg, sortArg: $sortArg) {
      id
      title
      date
      time
      location
      status {
        id
        name
      }
      assignees {
        id
        assignee {
          id
          fullName
          firstName
          lastName
        }
      }
      watchers {
        id
        watcher {
          id
          fullName
        }
      }
      assignedStaff {
        id
        staff {
          id
          fullName
        }
      }
    }
  }
`;

export const JOB_SCHEDULES_BY_DATE_RANGE = gql`
  query ${TENANT_PREFIX}jobSchedulesByDateRange($startDate: DateTimeISO!, $endDate: DateTimeISO!, $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}jobSchedulesByDateRange(startDate: $startDate, endDate: $endDate, searchArg: $searchArg, sortArg: $sortArg) {
      id
      title
      description
      date
      time
      location
      status {
        id
        name
      }
      assignees {
        id
        assignee {
          id
          fullName
        }
      }
      watchers {
        id
        watcher {
          id
          fullName
        }
      }
      assignedStaff {
        id
        staff {
          id
          fullName
        }
      }
    }
  }
`;

export const PAGINATED_JOB_SCHEDULES_BY_DATE_RANGE = gql`
  query ${TENANT_PREFIX}paginatedJobSchedulesByDateRange($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!], $startDate: DateTimeISO, $endDate: DateTimeISO) {
    ${TENANT_PREFIX}paginatedJobSchedulesByDateRange(pageArg: $pageArg, searchArg: $searchArg, sortArg: $sortArg, startDate: $startDate, endDate: $endDate) {
      data {
        id
        title
        date
        description
        time
        location
        status {
          id
          name
        }
        assignees {
          id
          assignee {
            id
            fullName
          }
        }
        watchers {
          id
          watcher {
            id
            fullName
          }
        }
        assignedStaff {
          id
          staff {
            id
            fullName
          }
        }
      }
      pageInfo {
        count
        pageSize
        pageCount
        skip
        take
      }
      sort {
        field
        direction
      }
    }
  }
`;
