import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'CancellationType';
const TITLE_SMALL = 'cancellationType';
const TITLE_FRAGMENT = 'CancellationTypeFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_CANCELLATIONTYPE_TITLE = 'paginatedCancellationTypes';
export const CANCELLATIONTYPE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    cancellationType
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CANCELLATIONTYPE = gql`
  ${CANCELLATIONTYPE_FRAGMENT}
  query ${PAGINATED_CANCELLATIONTYPE_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_CANCELLATIONTYPE_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_CANCELLATION_TYPE = gql`
  ${CANCELLATIONTYPE_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_CANCELLATION_TYPE_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CANCELLATIONTYPE_BY_ID = gql`
  ${CANCELLATIONTYPE_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ByIdId: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ByIdId) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_CANCELLATIONTYPE_BY_ID = gql`
  ${CANCELLATIONTYPE_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_CANCELLATIONTYPE = gql`
  ${CANCELLATIONTYPE_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_CANCELLATION_TYPE = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_CANCELLATION_TYPES = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const GET_CANCELLATIONTYPE_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
