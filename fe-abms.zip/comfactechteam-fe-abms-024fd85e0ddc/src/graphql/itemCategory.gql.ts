import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ItemCategory`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ITEM_CATEGORY_FRAGMENT = gql`
  fragment ItemCategoryFragment on ${MODEL_NAME} {
    id
    name
    description
    code
    active
    clientPortal
    franchiseeportal
    icno
    categorySubCategories {
      id
      subCategory {
        id
      }
    }
  }
  ${BASE_FRAGMENT}
`;
export const PAGINATED_ITEM_CATEGORIES = gql`
  ${ITEM_CATEGORY_FRAGMENT}
  query paginatedItemCategories($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedItemCategories(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ItemCategoryFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;
export const ALL_ITEM_CATEGORIES = gql`
  ${ITEM_CATEGORY_FRAGMENT}
  query ${TENANT_PREFIX}itemCategories($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemCategories(sortArg: $sortArg, searchArg: $searchArg) {
      ...ItemCategoryFragment
      ...BaseFragment

    }
  }
`;

export const ALL_ITEM_CATEGORIES_IDS = gql`
  query ${TENANT_PREFIX}itemCategories($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemCategories(sortArg: $sortArg, searchArg: $searchArg) {
      id

    }
  }
`;

export const FIND_ITEM_CATEGORY_BY_ID = gql`
  ${ITEM_CATEGORY_FRAGMENT}
  query findItemCategoryById($${TENANT_PREFIX}findItemCategoryByIdId: String!) {
    ${TENANT_PREFIX}findItemCategoryById(id: $${TENANT_PREFIX}findItemCategoryByIdId) {
      ...ItemCategoryFragment
      ...BaseFragment
    }
  }
`;
export const UPDATE_ITEM_CATEGORY_BY_ID = gql`
  ${ITEM_CATEGORY_FRAGMENT}
  mutation updateItemCategory($itemCategory: ${TENANT_PREFIX}ItemCategoryInput!, $${TENANT_PREFIX}updateItemCategoryId: String!) {
    ${TENANT_PREFIX}updateItemCategory(itemCategory: $itemCategory, id: $${TENANT_PREFIX}updateItemCategoryId) {
      ...ItemCategoryFragment
      ...BaseFragment
    }
  }
`;
export const CREATE_ITEM_CATEGORY = gql`
  ${ITEM_CATEGORY_FRAGMENT}
  mutation createItemCategory($itemCategory: ${TENANT_PREFIX}ItemCategoryInput!) {
    ${TENANT_PREFIX}createItemCategory(itemCategory: $itemCategory) {
      ...ItemCategoryFragment
      ...BaseFragment
    }
  }
`;
export const DELETE_ITEM_CATEGORY = gql`
  mutation deleteItemCategory($${TENANT_PREFIX}deleteItemCategoryById: String!) {
    ${TENANT_PREFIX}deleteItemCategory(id: $${TENANT_PREFIX}deleteItemCategoryById)
  }
`;
export const DELETE_ITEM_CATEGORIES = gql`
  mutation deleteItemCategories($ids: [String!]!) {
    ${TENANT_PREFIX}deleteItemCategories(ids: $ids)
  }
`;
export const GET_ITEM_CATEGORIES_CSV = gql`
  query ${TENANT_PREFIX}itemCategoryCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}itemCategoryCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_ITEM_CATEGORIES = gql`
  query ${TENANT_PREFIX}itemCategories {
    ${TENANT_PREFIX}itemCategories {
      id
      name
    }
  }
`;

export const UPDATE_ITEM_STATUS = gql`
  mutation ${TENANT_PREFIX}updateItemStatus($${TENANT_PREFIX}updateItemStatusId: String!, $status: ${TENANT_PREFIX}ItemInput!) {
    ${TENANT_PREFIX}updateItemStatus(id: $${TENANT_PREFIX}updateItemStatusId, status: $status) {
      id
    }
  }
`;

export const CREATE_CATEGORY_SUBCATEGORIES = gql`
  mutation ${TENANT_PREFIX}createCategorySubCategories($itemCategorySubCategories: [${TENANT_PREFIX}CategorySubCategoryInput!]!) {
    ${TENANT_PREFIX}createCategorySubCategories(itemCategorySubCategories: $itemCategorySubCategories) {
      id
      category {
        id
      }
    }
  }
`;

export const DELETE_CATEGORY_SUBCATEGORIES = gql`
  mutation ${TENANT_PREFIX}deleteCategorySubCategories($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCategorySubCategories(ids: $ids)
  }
`;
