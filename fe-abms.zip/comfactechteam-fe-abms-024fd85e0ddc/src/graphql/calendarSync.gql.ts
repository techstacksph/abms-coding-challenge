import { gql } from '@apollo/client';
import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

/**
 * ABMS-202: Calendar Sync GraphQL Mutations and Queries
 */

export const INITIALIZE_OUTLOOK_CALENDAR_SYNC = gql`
  mutation ${TENANT_PREFIX}InitializeOutlookCalendarSync($microsoftAccountId: String!) {
    ${TENANT_PREFIX}initializeOutlookCalendarSync(microsoftAccountId: $microsoftAccountId) {
      success
      message
      eventsCreated
      eventsUpdated
      totalEventsSynced
    }
  }
`;

export const GET_CALENDAR_SYNC_STATUS = gql`
  query ${TENANT_PREFIX}GetCalendarSyncStatus($microsoftAccountId: String!) {
    ${TENANT_PREFIX}getCalendarSyncStatus(microsoftAccountId: $microsoftAccountId) {
      totalEvents
      syncedEvents
      pendingEvents
      errorEvents
      conflictEvents
      notSyncedEvents
      lastSyncedAt
    }
  }
`;

export const FORCE_EVENT_SYNC = gql`
  mutation ${TENANT_PREFIX}ForceEventSync($eventId: String!) {
    ${TENANT_PREFIX}forceEventSync(eventId: $eventId)
  }
`;

/**
 * ABMS-202: Fetch virtual Outlook events (read-only, not stored in database)
 * Backend automatically looks up user's Microsoft account
 */
export const FETCH_OUTLOOK_VIRTUAL_EVENTS = gql`
  query ${TENANT_PREFIX}FetchOutlookVirtualEvents(
    $startDate: DateTimeISO
    $endDate: DateTimeISO
  ) {
    ${TENANT_PREFIX}fetchOutlookVirtualEvents(
      startDate: $startDate
      endDate: $endDate
    ) {
      id
      subject
      description
      startTime
      endTime
      location
      isAllDay
      showAs
      webLink
      isVirtual
      isReadOnly
      
    }
  }
`;
