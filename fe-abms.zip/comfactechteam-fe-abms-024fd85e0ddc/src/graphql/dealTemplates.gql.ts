import environment from '@/config/environment';
import { gql } from '@apollo/client';

const { TENANT_PREFIX } = environment;

export const ALL_DEAL_TEMPLATES = gql`
  query ${TENANT_PREFIX}dealTemplates($searchArg: [abmsSearchArg!], $sortArg: [abmsSortArg!]) {
    ${TENANT_PREFIX}dealTemplates(searchArg: $searchArg, sortArg: $sortArg) {
      id
      dealTemplate
      description
      serviceType {
        id
        servicetype
      }
      dealTemplateDetails {
        id
        area
        sortOrder
        item {
          id
        }
        frequency
      }
      dealTemplateSpecifications {
        id
        specifications
        days
        sortOrder
        variant {
          id
        }
      }
    }
  }
`;

export const ALL_DEAL_TEMPLATES_LIST = gql`
  query ${TENANT_PREFIX}dealTemplates($searchArg: [abmsSearchArg!], $sortArg: [abmsSortArg!]) {
    ${TENANT_PREFIX}dealTemplates(searchArg: $searchArg, sortArg: $sortArg) {
      id
      dealTemplate
      description
    }
  }
`;

export const PAGINATED_DEAL_TEMPLATES = gql`
  query ${TENANT_PREFIX}paginatedDealTemplates($searchArg: [abmsSearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDealTemplates(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        id
        dealTemplate
        description
        serviceType {
          id
          servicetype
        }
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const CREATE_DEAL_TEMPLATE = gql`
  mutation ${TENANT_PREFIX}createDealTemplate($dealTemplate: ${TENANT_PREFIX}DealTemplateInput!) {
    ${TENANT_PREFIX}createDealTemplate(dealTemplate: $dealTemplate) {
      id
      dealTemplate
      description
    }
  }
`;

export const CREATE_DEAL_TEMPLATE_DETAIL = gql`
  mutation ${TENANT_PREFIX}createDealTemplateDetail($dealTemplateDetail: ${TENANT_PREFIX}DealTemplateDetailInput!) {
    ${TENANT_PREFIX}createDealTemplateDetail(dealTemplateDetail: $dealTemplateDetail) {
      id
      area
    }
  }
`;

export const CREATE_DEAL_TEMPLATE_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}createDealTemplateSpecification($dealTemplateSpecification: ${TENANT_PREFIX}DealTemplateSpecificationInput!) {
    ${TENANT_PREFIX}createDealTemplateSpecification(dealTemplateSpecification: $dealTemplateSpecification) {
      id
      specifications
    }
  }
`;

export const UPDATE_DEAL_TEMPLATE = gql`
  mutation ${TENANT_PREFIX}updateDealTemplate($id: String!, $dealTemplate: ${TENANT_PREFIX}DealTemplateInput!) {
    ${TENANT_PREFIX}updateDealTemplate(id: $id, dealTemplate: $dealTemplate) {
      id
      dealTemplate
      description
    }
  }
`;

export const UPDATE_DEAL_TEMPLATE_DETAIL = gql`
  mutation ${TENANT_PREFIX}updateDealTemplateDetail($id: String!, $dealTemplateDetail: ${TENANT_PREFIX}DealTemplateDetailInput!) {
    ${TENANT_PREFIX}updateDealTemplateDetail(id: $id, dealTemplateDetail: $dealTemplateDetail) {
      id
      area
    }
  }
`;

export const UPDATE_DEAL_TEMPLATE_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}updateDealTemplateSpecification($id: String!, $dealTemplateSpecification: ${TENANT_PREFIX}DealTemplateSpecificationInput!) {
    ${TENANT_PREFIX}updateDealTemplateSpecification(id: $id, dealTemplateSpecification: $dealTemplateSpecification) {
      id
      specifications
    }
  }
`;

export const DELETE_DEAL_TEMPLATE_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteDealTemplateDetail($id: String!) {
    ${TENANT_PREFIX}deleteDealTemplateDetail(id: $id)
  }
`;

export const DELETE_DEAL_TEMPLATE_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}deleteDealTemplateSpecification($id: String!) {
    ${TENANT_PREFIX}deleteDealTemplateSpecification(id: $id)
  }
`;

export const DELETE_DEAL_TEMPLATES = gql`
  mutation ${TENANT_PREFIX}deleteDealTemplates($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDealTemplates(ids: $ids)
  }
`;

export const DELETE_DEAL_TEMPLATE = gql`
  mutation ${TENANT_PREFIX}deleteDealTemplate($${TENANT_PREFIX}deleteDealTemplateId: String!) {
    ${TENANT_PREFIX}deleteDealTemplate(id: $${TENANT_PREFIX}deleteDealTemplateId)
  }
`;

export const FIND_DEAL_TEMPLATE_BY_ID = gql`
  query ${TENANT_PREFIX}findDealTemplateById($id: String!) {
    ${TENANT_PREFIX}findDealTemplateById(id: $id) {
      id
      dealTemplate
      description
      serviceType {
        id
        servicetype
      }
      dealTemplateDetails {
        id
        area
        sortOrder
        item {
          id
        }
        frequency
      }
      dealTemplateSpecifications {
        id
        dealTemplateDetail {
          id
        }
        specifications
        days
        sortOrder
        variant {
          id
          name
        }
      }
    }
  }
`;

export const GET_DEAL_TEMPLATES_CSV = gql`
  query ${TENANT_PREFIX}DealTemplateCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}DealTemplateCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
