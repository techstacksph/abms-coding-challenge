import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Location`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const LOCATION_FRAGMENT = gql`
  fragment LocationFragment on ${MODEL_NAME} {
    areaId
    area {
      area
      id
      code
    }
    billingAccountId
    billingAccount {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      bStreetAddress
      bSuburb
      bCity
      bRegion
      bPostalCode
      ayrMobile
      gst
      bankAccountNo
    }
    brandFee
    brandFeePaymarkAccountId
    xeroAccount {
      id
      xeroAccount
    }
    brandFeePaymarkPassword
    brandFeePaymarkUrl
    brandFeePaymarkUsername
    brandFeeLimit
    city
    franchiseeFee
    collectionFee
    commissionRate
    costToBuyRate
    countryCode
    description
    enablePayNow
    franchiseeGroupEmail
    orderGroupEmail
    financeEmail
    poAmountAsBulk
    leadsTarget
    id
    name
    parentLocationId
    postalCode
    portalPaymarkAccountId
    portalPaymarkPassword
    portalPaymarkUrl
    portalPaymarkUsername
    region
    royaltyFee
    salesTarget
    address
    streetAddress
    areaId
    suburb
    longitude
    latitude
    placeId
    address
    technologyFee
    fullAddress
    updatedByName
    monthlyIncome
    parentLocation {
      id
      name
    } 
    childLocations {
      id
      name
    }
    users {
      id
      firstName
      lastName
      userName
      email
    }
    country {
      name
      code
    }
    commissionType
    commission
    repeat
    thisTransactionEvery
    due
    date
    dayOfTheMonth
    equipmentTopUpFee
    directorId
    director {
      id
      firstName
      lastName
    }

    operationsUsers {
      id
      firstName
      lastName
    }
    financeUserId
    financeUser {
      id
      firstName
      lastName
    }
    orderPurchasingUserId
    orderPurchasingUser {
      id
      firstName
      lastName
    }
    securityChecksUserId
    securityChecksUser {
      id
      firstName
      lastName
    }
    insurancesUserId
    insurancesUser {
      id
      firstName
      lastName
    }
    jobPurchasesUserId
    jobPurchasesUser {
      id
      firstName
      lastName
    }
    sellingYourBusinessUserId
    sellingYourBusinessUser {
      id
      firstName
      lastName
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_LOCATIONS = gql`
  ${LOCATION_FRAGMENT}
  query paginatedLocations($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedLocations(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...LocationFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_LOCATIONS = gql`
  ${LOCATION_FRAGMENT}
  query ${TENANT_PREFIX}locations($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}locations(searchArg: $searchArg, sortArg: $sortArg) {
      ...LocationFragment
      ...BaseFragment
    }
  }
`;

export const ALL_LOCATIONS_ID = gql`
  query ${TENANT_PREFIX}locations($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}locations(searchArg: $searchArg, sortArg: $sortArg) {
      id
      name
    }
  }
`;

export const SELECT_LOCATIONS = gql`
  query ${TENANT_PREFIX}locations($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}locations(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      commissionType
      commission
      poAmountAsBulk
      dayOfTheMonth
      repeat
      thisTransactionEvery
      due
      date
      xeroAccount{
        id
        xeroAccount
      }
    }
  }
`;

export const PARENT_LOCATIONS = gql`
  query locations {
    ${TENANT_PREFIX}locations {
      id
      name
    }
  }
`;

export const FIND_LOCATION_BY_ID = gql`
  ${LOCATION_FRAGMENT}
  query findLocationById($${TENANT_PREFIX}findLocationByIdId: String!) {
    ${TENANT_PREFIX}findLocationById(id: $${TENANT_PREFIX}findLocationByIdId) {
      ...LocationFragment
      ...BaseFragment
    }
  }
`;

export const FIND_LOCATION_BY_NAME = gql`
  ${LOCATION_FRAGMENT}
  query findLocationByName($${TENANT_PREFIX}findLocationByName: String!) {
    ${TENANT_PREFIX}findLocationByName(name: $${TENANT_PREFIX}findLocationByName) {
      ...LocationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LOCATION_BY_ID = gql`
  ${LOCATION_FRAGMENT}
  mutation updateLocation($location: ${TENANT_PREFIX}LocationInput!, $${TENANT_PREFIX}updateLocationId: String!) {
    ${TENANT_PREFIX}updateLocation(location: $location, id: $${TENANT_PREFIX}updateLocationId) {
      ...LocationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LOCATION_XERO_ACCOUNT = gql`
  mutation ${TENANT_PREFIX}updateLocationXeroAccount($id: String!, $xeroAccountId: String) {
    ${TENANT_PREFIX}updateLocationXeroAccount(id: $id, xeroAccountId: $xeroAccountId) {
      id
    }
  }
`;

export const CREATE_LOCATION = gql`
  ${LOCATION_FRAGMENT}
  mutation createLocation($location: ${TENANT_PREFIX}LocationInput!) {
    ${TENANT_PREFIX}createLocation(location: $location) {
      ...LocationFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_LOCATION = gql`
  mutation deleteLocation($id: String!) {
    ${TENANT_PREFIX}deleteLocation(id: $id)
  }
`;

export const DELETE_LOCATIONS = gql`
  mutation deleteLocation($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLocations(ids: $ids)
  }
`;
