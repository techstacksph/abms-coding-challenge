import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CompanySetting`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

const COMPANY_SETTINGS_FRAGMENT = gql`
  fragment CompanySettingsFragment on ${MODEL_NAME} {
    id
    orgId
    companyName
    tradingName
    website
    phone
    companyLogo
    streetAddress
    suburb
    city
    area {
      id
      code
      area
    }
    findAddress
    region
    postalcode
    country {
      code
      id
      name
    }
    timezone {
      id
      name
      
    }
    securityLevel {
      id 
      name
    }
    findAddress
    docLogo
    targetClose
    autoFollowup
    salesTax
    purchaseTax
    smsKey
    smsSecret
    xeroApp
    xeroID
    xeroSecret
    xeroWebhookKey
    mapAPI
    tinyKey
    outlookID
    outlookSecret
    outlookTenantID
    emailSettings
    email
    mailerAccount
    tenantId
    clientId
    placeId, 
    longitude, 
    latitude,
    clientSecret
    mailHost
    mailPort
    appPassword
    autoReply
    mailSender
    customDisplayName
    sharePointSiteName
    sharePointUploadFolderName
    accessKeyId
    secretKey
    awsRegion
    bucketName
    maximumFileSize
    }

  ${BASE_FRAGMENT}
`;

export const FIND_COMPANY_SETTINGS_BY_ID = gql`
  ${COMPANY_SETTINGS_FRAGMENT}
  query ${TENANT_PREFIX}findCompanySettingById($${TENANT_PREFIX}findCompanySettingByIdId2: String!) {
    ${TENANT_PREFIX}findCompanySettingById(id: $${TENANT_PREFIX}findCompanySettingByIdId2) {
      ...CompanySettingsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_COMPANY_SETTINGS_BY_ID = gql`
  ${COMPANY_SETTINGS_FRAGMENT}
  mutation updateCompanySettings($companySetting: ${TENANT_PREFIX}CompanySettingInput!, $${TENANT_PREFIX}updateCompanySettingId: String!) {
    ${TENANT_PREFIX}updateCompanySetting(companySetting: $companySetting, id: $${TENANT_PREFIX}updateCompanySettingId) {
      ...CompanySettingsFragment
      ...BaseFragment
    }
  }
`;

export const GET_DEFAULT_COMPANY_SETTINGS = gql`
  ${COMPANY_SETTINGS_FRAGMENT}
  query ${TENANT_PREFIX}companySettings {
    ${TENANT_PREFIX}companySettings {
      ...CompanySettingsFragment
      ...BaseFragment
    }
  }
`;

export const GET_COMPANY_CLOSE_DATE = gql`
  query ${TENANT_PREFIX}companySettings {
    ${TENANT_PREFIX}companySettings {
      targetClose
    }
  }
`;

/* QUERIES FOR SYSTEM PREFERENCE SETTINGS */
export const CREATE_SYSTEM_PREFERENCE_SETTINGS = gql`
  ${COMPANY_SETTINGS_FRAGMENT}
    mutation ${TENANT_PREFIX}createSystemPreferenceSetting($systemPreferenceSetting: ${TENANT_PREFIX}CompanySettingInput!) {
    ${TENANT_PREFIX}createSystemPreferenceSetting(systemPreferenceSetting: $systemPreferenceSetting) {
        ...CompanySettingsFragment
        ...BaseFragment
    }
    }
`;

export const UPDATE_SYSTEM_PREFERENCE_SETTINGS_BY_ID = gql`
  ${COMPANY_SETTINGS_FRAGMENT}
  mutation updateSystemPreferenceSetting($systemPreferenceSetting: ${TENANT_PREFIX}CompanySettingInput!, $${TENANT_PREFIX}updateSystemPreferenceSettingId: String!) {
    ${TENANT_PREFIX}updateSystemPreferenceSetting(systemPreferenceSetting: $systemPreferenceSetting, id: $${TENANT_PREFIX}updateSystemPreferenceSettingId) {
      ...CompanySettingsFragment
      ...BaseFragment
    }
  }
`;

/* QUERIES FOR EMAIL SERVER SETTINGS */

export const TEST_MAILER_SETTINGS = gql`
  mutation ${TENANT_PREFIX}testMailerCompanySettings($companySettings: ${TENANT_PREFIX}CompanySettingsMailerInput!, $testSettingsRecipient: String!) {
    ${TENANT_PREFIX}testMailerCompanySettings(companySettings: $companySettings, testSettingsRecipient: $testSettingsRecipient)
  }
`;

export const VALIDATE_SMTP_CREDENTIALS = gql`
  mutation ${TENANT_PREFIX}validateSmtpCredentials(
    $mailHost: String!
    $mailPort: String!
    $mailerAccount: String!
    $appPassword: String!
    $emailSettings: String!
  ) {
    ${TENANT_PREFIX}validateSmtpCredentials(
      mailHost: $mailHost
      mailPort: $mailPort
      mailerAccount: $mailerAccount
      appPassword: $appPassword
      emailSettings: $emailSettings
    ) {
      valid
      error
      message
    }
  }
`;

/* PUBLIC COMPANY SETTINGS QUERY - For unauthorized access */
export const GET_PUBLIC_COMPANY_SETTINGS = gql`
  query ${TENANT_PREFIX}publicCompanySettings($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}publicCompanySettings(sortArg: $sortArg, searchArg: $searchArg) {
      ...CompanySettingsFragment
      ...BaseFragment
    }
  }
`;
