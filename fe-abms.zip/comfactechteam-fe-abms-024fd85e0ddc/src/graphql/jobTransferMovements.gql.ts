import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragmentWithUniqueName } from './base.gql';

const TITLE = 'JobTransferMovement';
const TITLE_SMALL = 'jobTransferMovement';
const TITLE_FRAGMENT = 'JobTransferMovementFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragmentWithUniqueName(MODEL_NAME);
const BASE_FRAGMENT_NAME = `BaseFragment_${MODEL_NAME}`;

export const JOB_TRANSFER_MOVEMENT_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    serviceProviderId
    from
    to
    tookoverDate
    lastCleaningDate
    jobStartDate
    days
    income
    weekdays
    weekends
    serviceProviderIncome
    dailyAmountRC
    receivables
    dailyAmountPY
    payables
    numberOfDays
    notes
    timestamp
    continuesToNextPeriod
    serviceProvider {
      id
      name
    }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_JOB_TRANSFER_MOVEMENTS = gql`
  ${JOB_TRANSFER_MOVEMENT_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const PAGINATED_JOB_TRANSFER_MOVEMENTS = gql`
  ${JOB_TRANSFER_MOVEMENT_FRAGMENT}
  query ${TENANT_PREFIX}paginated${TITLE}s($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginated${TITLE}s(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const FIND_JOB_TRANSFER_MOVEMENT_BY_ID = gql`
  ${JOB_TRANSFER_MOVEMENT_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ById: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ById) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;
