import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ContactType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CONTACTS_TYPES_FRAGMENT = gql`
  fragment ContactTypesFragment on ${MODEL_NAME} {
    id
    code
    description
    name
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_CONTACTS_TYPES = gql`
  ${CONTACTS_TYPES_FRAGMENT}
  query paginatedContactTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedContactTypes(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...ContactTypesFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_CONTACT_TYPES = gql`
  ${CONTACTS_TYPES_FRAGMENT}
  query ${TENANT_PREFIX}contactTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contactTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...ContactTypesFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CONTACT_TYPES_IDS = gql`
  query ${TENANT_PREFIX}contactTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contactTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CONTACT_TYPE_BY_ID = gql`
  ${CONTACTS_TYPES_FRAGMENT}
  query ${TENANT_PREFIX}findContactTypeById($${TENANT_PREFIX}findContactTypeByIdId: String!) {
    ${TENANT_PREFIX}findContactTypeById(id: $${TENANT_PREFIX}findContactTypeByIdId) {
      ...ContactTypesFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CONTACT_TYPE_BY_ID = gql`
  ${CONTACTS_TYPES_FRAGMENT}
  mutation ${TENANT_PREFIX}updateContactType($contacttype: ${TENANT_PREFIX}ContactTypeInput!, $${TENANT_PREFIX}updateContactTypeId: String!) {
    ${TENANT_PREFIX}updateContactType(contacttype: $contacttype, id: $${TENANT_PREFIX}updateContactTypeId) {
      ...ContactTypesFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CONTACT_TYPE = gql`
  ${CONTACTS_TYPES_FRAGMENT}
  mutation ${TENANT_PREFIX}createContactType($contacttype: abmsContactTypeInput!) {
    ${TENANT_PREFIX}createContactType(contacttype: $contacttype) {
      ...ContactTypesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CONTACT_TYPES = gql`
  mutation ${TENANT_PREFIX}deleteContactTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteContactTypes(ids: $ids)
  }
`;

export const DELETE_CONTACT_TYPE = gql`
  mutation ${TENANT_PREFIX}deleteContactType($${TENANT_PREFIX}deleteContactTypeId: String!) {
    ${TENANT_PREFIX}deleteContactType(id: $${TENANT_PREFIX}deleteContactTypeId)
  }
`;

export const GET_CONTACT_TYPES_CSV = gql`
  query ${TENANT_PREFIX}contactTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}contactTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
