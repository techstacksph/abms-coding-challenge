import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Position`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const POSITION_FRAGMENT = gql`
  fragment PositionFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_POSITIONS = gql`
  ${POSITION_FRAGMENT}
  query paginatedPositions($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPositions(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PositionFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_POSITIONS = gql`
  ${POSITION_FRAGMENT}
  query ${TENANT_PREFIX}positions($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}positions(sortArg: $sortArg, searchArg: $searchArg) {
      ...PositionFragment
      ...BaseFragment
    }
  }
`;

export const ALL_POSITIONS_IDS = gql`
  query ${TENANT_PREFIX}positions($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}positions(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_POSITIONS = gql`
  query positions {
      ${TENANT_PREFIX}positions {
        id
        name
      }
    }
`;

export const FIND_POSITION_BY_ID = gql`
  ${POSITION_FRAGMENT}
  query findPositionById($${TENANT_PREFIX}findPositionByIdId: String!) {
    ${TENANT_PREFIX}findPositionById(id: $${TENANT_PREFIX}findPositionByIdId) {
      ...PositionFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_POSITION_BY_ID = gql`
  ${POSITION_FRAGMENT}
  mutation updatePosition($position: ${TENANT_PREFIX}PositionInput!, $${TENANT_PREFIX}updatePositionId: String!) {
    ${TENANT_PREFIX}updatePosition(position: $position, id: $${TENANT_PREFIX}updatePositionId) {
      ...PositionFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_POSITION = gql`
  ${POSITION_FRAGMENT}
  mutation createPosition($position: ${TENANT_PREFIX}PositionInput!) {
    ${TENANT_PREFIX}createPosition(position: $position) {
      ...PositionFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_POSITION = gql`
  mutation deletePosition($${TENANT_PREFIX}deletePositionById: String!) {
    ${TENANT_PREFIX}deletePosition(id: $${TENANT_PREFIX}deletePositionById)
  }
`;

export const DELETE_POSITIONS = gql`
  mutation deletePositions($ids: [String!]!) {
    ${TENANT_PREFIX}deletePositions(ids: $ids)
  }
`;

export const GET_POSITIONS_CSV = gql`
  query ${TENANT_PREFIX}PositionCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}PositionCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
