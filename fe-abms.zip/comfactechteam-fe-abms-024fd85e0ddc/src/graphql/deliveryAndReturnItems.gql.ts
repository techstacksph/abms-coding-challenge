import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}DeliveryAndReturnItem`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DELIVERY_RETURN_ITEM_FRAGMENT = gql`
  fragment DeliveryReturnItemFragment on ${MODEL_NAME} {
    id
    lineItemNo
    lineNo
    item {
      id
      itemCode
      name
      productImage
      description
    }
    drQuantity
    referencedQuantity
    unitPrice
    amount
    uom {
      id
      name
    }
    uomId
    salesOrderItem {
      id
      salesorderId
    }
    salesOrderItemId
    purchaseOrderItem {
      id
      purchaseOrderId
    }
    purchaseOrderItemId
  }

  ${BASE_FRAGMENT}
`;

export const ALL_DELIVERY_RETURN_ITEMS = gql`
  ${DELIVERY_RETURN_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}deliveryAndReturnItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deliveryAndReturnItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...DeliveryReturnItemFragment
      ...BaseFragment
    }
  }
`;

export const FIND_DELIVERY_RETURN_ITEMS_BY_DELIVERY_RETURN_ID = gql`
  ${DELIVERY_RETURN_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}deliveryAndReturnItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deliveryAndReturnItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...DeliveryReturnItemFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DELIVERY_RETURN_ITEM = gql`
  ${DELIVERY_RETURN_ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}createDeliveryAndReturnItem($deliveryAndReturnItem: ${TENANT_PREFIX}DeliveryAndReturnItemInput!) {
    ${TENANT_PREFIX}createDeliveryAndReturnItem(deliveryAndReturnItem: $deliveryAndReturnItem) {
      ...DeliveryReturnItemFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DELIVERY_RETURN_ITEM = gql`
  ${DELIVERY_RETURN_ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}updateDeliveryAndReturnItem($id: String!, $input: ${TENANT_PREFIX}DeliveryAndReturnItemInput!) {
    ${TENANT_PREFIX}updateDeliveryAndReturnItem(id: $id, input: $input) {
      ...DeliveryReturnItemFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_DELIVERY_RETURN_ITEM_BY_IDS = gql`
  mutation ${TENANT_PREFIX}deleteDeliveryAndReturnItems($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDeliveryAndReturnItems(ids: $ids)
  }
`;

export const PAGINATED_DELIVERY_RETURN_ITEMS = gql`
  ${DELIVERY_RETURN_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}paginatedDeliveryReturnItems($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDeliveryReturnItems(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DeliveryReturnItemFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }

    }
  }
`;
