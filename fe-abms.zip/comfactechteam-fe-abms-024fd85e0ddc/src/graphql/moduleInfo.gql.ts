/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ModuleInfo`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const MODULE_INFO_FRAGMENT = gql`
  fragment ModuleInfoFragment on ${MODEL_NAME} {
    id
    moduleTitle
    course {
      id
      course
    }
    description
    createdByName
    updatedByName
  }
  ${BASE_FRAGMENT}
`;

// Get Paginated ModuleInfos Query
export const PAGINATED_MODULE_INFOS = gql`
  ${MODULE_INFO_FRAGMENT}
  query PaginatedModuleInfos($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedModuleInfos(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ModuleInfoFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Get All ModuleInfos Query
export const ALL_MODULE_INFOS = gql`
  ${MODULE_INFO_FRAGMENT}
  query ${TENANT_PREFIX}moduleInfos($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}moduleInfos(searchArg: $searchArg, sortArg: $sortArg) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;

export const ALL_MODULE_INFO_IDS = gql`
  query ${TENANT_PREFIX}moduleInfos($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}moduleInfos(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const ALL_MODULE_INFOS_ID = gql`
  query ${TENANT_PREFIX}moduleInfosIds($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}moduleInfos(searchArg: $searchArg, sortArg: $sortArg) {
      id
      moduleTitle
    }
  }
`;

export const SELECT_MODULE_INFOS = gql`
  query moduleInfos {
      ${TENANT_PREFIX}moduleInfos {
        id
        moduleTitle
      }
    }
`;

// Find ModuleInfo By ID Query
export const FIND_MODULE_INFO_BY_ID = gql`
  ${MODULE_INFO_FRAGMENT}
  query findModuleInfoById($id: String!) {
    ${TENANT_PREFIX}findModuleInfoById(id: $id) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;

// Create ModuleInfo Mutation
export const CREATE_MODULE_INFO = gql`
  ${MODULE_INFO_FRAGMENT}
  mutation createModuleInfo($input: ${TENANT_PREFIX}ModuleInfoInput!) {
    ${TENANT_PREFIX}createModuleInfo(moduleInfo: $input) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;

// Update ModuleInfo Mutation
export const UPDATE_MODULE_INFO_BY_ID = gql`
  ${MODULE_INFO_FRAGMENT}
  mutation updateModuleInfo($input: ${TENANT_PREFIX}ModuleInfoInput!, $id: String!) {
    ${TENANT_PREFIX}updateModuleInfo(moduleInfo: $input, id: $id) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_MODULE_INFO = gql`
  mutation deleteModuleInfo($id: String!) {
    ${TENANT_PREFIX}deleteModuleInfo(id: $id)
  }
`;

export const DELETE_MODULE_INFOS = gql`
  mutation deleteModuleInfos($ids: [String!]!) {
    ${TENANT_PREFIX}deleteModuleInfos(ids: $ids)
  }
`;

export const MODULE_INFOS_CSV = gql`
  query ${TENANT_PREFIX}ModuleInfoCSV(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}ModuleInfoCSV(
      searchArg: $searchArg
      columnArg: $columnArg
      sortArg: $sortArg
    )
  }
`;

// Create ModuleInfo With Test Questions Mutation
export const CREATE_MODULE_INFO_WITH_QUESTIONS = gql`
  ${MODULE_INFO_FRAGMENT}
  mutation createModuleInfoWithQuestions($data: ${TENANT_PREFIX}ModuleInfoWithQuestionsInput!) {
    ${TENANT_PREFIX}createModuleInfoWithQuestions(data: $data) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;

// Update ModuleInfo With Test Questions Mutation
export const UPDATE_MODULE_INFO_WITH_QUESTIONS = gql`
  ${MODULE_INFO_FRAGMENT}
  mutation editModuleInfoWithQuestions($id: String!, $data: ${TENANT_PREFIX}ModuleInfoWithQuestionsInput!) {
    ${TENANT_PREFIX}editModuleInfoWithQuestions(id: $id, data: $data) {
      ...ModuleInfoFragment
      ...BaseFragment
    }
  }
`;
