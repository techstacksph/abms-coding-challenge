import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}JobSchedule`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const JOB_SCHEDULE_FRAGMENT = gql`
  fragment JobScheduleFragment on ${MODEL_NAME} {
    id
    location
    title
    description
    actualEnd
    actualStart
    time
    endImage
    startImage
    status {
      id
      name
    }
    assignedStaff {
      id
      staff {
        id
        fullName
      }
    }
    assignees {
      id
      assigneeId
      assignee {
        id
        name
        fullName
      }
    }
    job {
      id
      jobNo
      location {
        id
        name
      }
      site {
        id
        siteName
      }
      account {
        id
        name
      }
    }
    jobAreas {
      area
      completed
      notes
    }
    jobScheduleLogs {
      id
      dateTime
      job {
        id
        jobNo
        location {
          id
          name
        }
      }
      location
      logType
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_JOB_SCHEDULES = gql`
  ${JOB_SCHEDULE_FRAGMENT}
  query paginatedJobSchedules($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedJobSchedules(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobScheduleFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_JOB_SCHEDULES = gql`
  ${JOB_SCHEDULE_FRAGMENT}
  query ${TENANT_PREFIX}jobSchedules($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobSchedules(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobScheduleFragment
      ...BaseFragment
    }
  }
`;

export const FIND_JOB_SCHEDULE_BY_ID = gql`
  ${JOB_SCHEDULE_FRAGMENT}
  query findJobScheduleById($${TENANT_PREFIX}findJobScheduleByIdId: String!) {
    ${TENANT_PREFIX}findJobScheduleById(id: $${TENANT_PREFIX}findJobScheduleByIdId) {
      ...JobScheduleFragment
      ...BaseFragment
    }
  }
`;

export const GET_JOB_SCHEDULE_CSV = gql`
  query ${TENANT_PREFIX}JobScheduleCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}JobScheduleCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_JOB_SCHEDULES = gql`
  query ${TENANT_PREFIX}jobSchedules($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobSchedules(sortArg: $sortArg, searchArg: $searchArg) {
      id
      title
      location
      job {
        id
        jobNo
      }
    }
  }
`;

export const CALENDAR_JOB_SCHEDULES = gql`
  query ${TENANT_PREFIX}jobSchedules($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}jobSchedules(searchArg: $searchArg, sortArg: $sortArg) {
    id
    title
    location
    time
    assignees {
      assignee {
        id
        name
        fullName
      }
    }
    job {
      id
      jobNo
    }
  }
  }
`;

export const PAGINATED_JOB_SCHEDULES_CALENDAR = gql`
  query paginatedJobSchedules($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedJobSchedules(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        id
        title
        location
        time
        assignees {
          assignee {
            id
            name
            fullName
          }
        }
        job {
          id
          jobNo
        }
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;
