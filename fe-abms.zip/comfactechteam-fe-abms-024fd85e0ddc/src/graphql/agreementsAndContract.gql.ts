import { gql } from '@apollo/client';

import environment from '@/config/environment';
import { getBaseFragment } from '@/graphql/base.gql';

const TITLE = 'AgreementAndContract';
const TITLE_SMALL = 'agreementAndContract';
const TITLE_FRAGMENT = 'AgreementAndContractFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}AgreementsAndContracts`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_AGREEMENT_AND_CONTRACT_TITLE =
  'paginatedAgreementsAndContracts';
export const AGREEMENT_AND_CONTRACT_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    agreementPDF
    agreementsContractNo
    autoNumber
    documentBody
    effectiveDate
    expirationDate
    employee {
      id
      firstName
      lastName
      fullName
      email
    }
    status {
      id
      name
    }
    signedAgreement
    type
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_AGREEMENT_AND_CONTRACT = gql`
  ${AGREEMENT_AND_CONTRACT_FRAGMENT}
  query ${PAGINATED_AGREEMENT_AND_CONTRACT_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_AGREEMENT_AND_CONTRACT_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;
const TEST_NAME = 'agreementsAndContracts';
export const ALL_AGREEMENT_AND_CONTRACT = gql`
  ${AGREEMENT_AND_CONTRACT_FRAGMENT}
  query ${TENANT_PREFIX}${TEST_NAME}($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TEST_NAME}(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;
export const ALL_AGREEMENT_AND_CONTRACT_IDS = gql`
  query ${TENANT_PREFIX}${TEST_NAME}($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TEST_NAME}(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_AGREEMENT_AND_CONTRACT_BY_ID = gql`
  ${AGREEMENT_AND_CONTRACT_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ByIdId: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ByIdId) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_AGREEMENT_AND_CONTRACT_BY_ID = gql`
  ${AGREEMENT_AND_CONTRACT_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}Input: ${TENANT_PREFIX}AgreementsAndContractsInput!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}Input: $${TITLE_SMALL}Input, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_AGREEMENT_AND_CONTRACT = gql`
  ${AGREEMENT_AND_CONTRACT_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}Input: ${TENANT_PREFIX}AgreementsAndContractsInput!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}Input: $${TITLE_SMALL}Input) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_AGREEMENT_AND_CONTRACT = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_AGREEMENT_AND_CONTRACTS = gql`
  mutation deleteAgreementsAndContracts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAgreementsAndContracts(ids: $ids)
  }
`;

export const GET_AGREEMENT_AND_CONTRACT_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const AGREEMENT_AND_CONTRACT_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}Dashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}Dashboard(dashboardArg: $dashboardArg) {
     all
     created
     active
     inactive
    }
  }
`;

export const UPDATE_AGREEMENT_AND_CONTRACT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateAgreementsAndContractsStatus($${TENANT_PREFIX}updateAgreementsAndContractsStatusId: String!, $status: ${TENANT_PREFIX}AgreementsAndContractsStatusInput!) {
    ${TENANT_PREFIX}updateAgreementsAndContractsStatus(id: $${TENANT_PREFIX}updateAgreementsAndContractsStatusId, status: $status) {
      id
    }
  }
`;

export const AGREEMENTS_AND_CONTRACT_STATUS = gql`
  query ${TENANT_PREFIX}getModuleWorkflowStatus{
    ${TENANT_PREFIX}getModuleWorkflowStatus(code: "agreementandcontract") {
      id
      name
    }
}`;

export const AGREEMENT_AND_CONTRACT_STATUS_COUNTS = gql`
  query ${TENANT_PREFIX}agreementsAndContracts($searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}agreementsAndContracts(searchArg: $searchArg) {
      status {
        name
      }
    }
  }
`;
