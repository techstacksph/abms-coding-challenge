import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'Marketplace';
const TITLE_SMALL = TITLE.toLowerCase();
const TITLE_FRAGMENT = 'MarketplaceFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_MARKETPLACES_TITLE = 'paginatedMarketplaces';

export const MARKETPLACE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    marketplaceNo
    platformId
    suburb
    addinfo
    cleaningDays
    forNewFranchisee
    dateAvailability
    monthlyIncome
    outrightFee
    installmentFranchiseeFee
    cleaningSchedule
    statusId
    account {
      id
      accountType
      name
      status {
        id
        name
      }
    }
    accountId
    location {
      id
      name
      fullAddress
      suburb
      area {
        id
        area
      }
    }
    locationId
    area {
      id
      area
      code
    }
    areaId
    job {
      id
      jobNo
      jobAmount
      forSale
      site {
        id
        siteName
        fullAddress
        lastActivity
      }
    }
    jobId
    jobPurchases {
      id
    }
    marketplaceJobPurchases {
      id
    }
    status {
      id
      name
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_MARKETPLACES = gql`
  ${MARKETPLACE_FRAGMENT}
  query ${PAGINATED_MARKETPLACES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_MARKETPLACES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_MARKETPLACES = gql`
  ${MARKETPLACE_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
    ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_MARKETPLACES_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_MARKETPLACES = gql`
  query ${TENANT_PREFIX}marketplaces{
    ${TENANT_PREFIX}marketplaces{
      id
      marketplaceNo
    }
  }
`;

export const FIND_MARKETPLACE_BY_ID = gql`
  ${MARKETPLACE_FRAGMENT}
  query ${TENANT_PREFIX}findMarketplaceById($${TENANT_PREFIX}findMarketplaceByIdId: String!) {
    ${TENANT_PREFIX}findMarketplaceById(id: $${TENANT_PREFIX}findMarketplaceByIdId) {
      ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_MARKETPLACE_BY_ID = gql`
  ${MARKETPLACE_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_MARKETPLACE = gql`
  ${MARKETPLACE_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_MARKETPLACE = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_MARKETPLACES = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const GET_MARKETPLACE_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const MARKETPLACE_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}sDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}sDashboard(dashboardArg: $dashboardArg) {
      all
      created
      available
      sold
      inactive
      pending
    }
  }
`;
