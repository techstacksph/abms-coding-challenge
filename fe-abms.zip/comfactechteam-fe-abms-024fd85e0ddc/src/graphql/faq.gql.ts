/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Faq`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FAQ_FRAGMENT = gql`
  fragment FaqFragment on ${MODEL_NAME} {
    id
    question
    answer
    createdByName
    updatedByName
  }
  ${BASE_FRAGMENT}
`;

// Get Paginated Faqs Query
export const PAGINATED_FAQS = gql`
  ${FAQ_FRAGMENT}
  query PaginatedFaqs($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFaqs(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FaqFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Get All Faqs Query
export const ALL_FAQS = gql`
  ${FAQ_FRAGMENT}
  query ${TENANT_PREFIX}faqs($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}faqs(searchArg: $searchArg, sortArg: $sortArg) {
      ...FaqFragment
      ...BaseFragment
    }
  }
`;

export const ALL_FAQ_IDS = gql`
  query ${TENANT_PREFIX}faqs($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}faqs(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const SELECT_FAQS = gql`
  query faqs {
      ${TENANT_PREFIX}faqs {
        id
        question
        answer
      }
    }
`;

// Find Faq By ID Query
export const FIND_FAQ_BY_ID = gql`
  ${FAQ_FRAGMENT}
  query findFaqById($id: String!) {
    ${TENANT_PREFIX}findFaqById(id: $id) {
      ...FaqFragment
      ...BaseFragment
    }
  }
`;

// Create Faq Mutation
export const CREATE_FAQ = gql`
  ${FAQ_FRAGMENT}
  mutation createFaq($input: ${TENANT_PREFIX}FaqInput!) {
    ${TENANT_PREFIX}createFaq(faq: $input) {
      ...FaqFragment
      ...BaseFragment
    }
  }
`;

// Update Faq Mutation
export const UPDATE_FAQ_BY_ID = gql`
  ${FAQ_FRAGMENT}
  mutation updateFaq($input: ${TENANT_PREFIX}FaqInput!, $id: String!) {
    ${TENANT_PREFIX}updateFaq(faq: $input, id: $id) {
      ...FaqFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FAQ = gql`
  mutation deleteFaq($id: String!) {
    ${TENANT_PREFIX}deleteFaq(id: $id)
  }
`;

export const DELETE_FAQS = gql`
  mutation deleteFaqs($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFaqs(ids: $ids)
  }
`;

export const FAQS_CSV = gql`
  query ${TENANT_PREFIX}FaqCSV(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}FaqCSV(
      searchArg: $searchArg
      columnArg: $columnArg
      sortArg: $sortArg
    )
  }
`;
