import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}SalesOrder`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

const SALES_ORDER_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment SalesOrderFragment on ${MODEL_NAME} {
      id
      soNo
      soDate
      soAmount
      prefferedPickUpDateTime
      customer {
        id
        name
      }
      franchisee {
        id
        name
        primaryContact {
          id
          fullName
          email
          mobile
        }
      }
      recordOwner {
        id
        firstName
        lastName
        fullName
      }
      location {
        id
        name
        fullAddress
      }
      status {
        id
        name
      }
      isTemplate
      warehousee {
        id
        name
      }
      contact { 
        id
        fullName
        email
        mobile
      }
      job {
        id
        jobNo
      }
      site {
        id
        siteName
        address
        fullAddress
      }
      totalAmountGSTInclusive
      totalQuantity
      invoices {
        id
      }
      salesOrderItems {
        invoiceDetailId
        invoiceDetail {
          id
        }
      }
      ...BaseFragment
    }
`;

const SALES_ORDER_BY_ID_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment SalesOrderByIdFragment on ${MODEL_NAME} {
      id
      soNo
      soDate
      soAmount
      prefferedPickUpDateTime
      customer {
        id
        name
        billingAddress
        ayrMobile
        gst
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
      }
      franchisee {
        id
        name
        legalName
        ayrEmail
        ayrMobile
        gst
        billingAddress
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
        primaryContact {
          id
          fullName
          email
          mobile
        }
      }
      warehousee {
        id
        name
      }
      recordOwner {
        id
        firstName
        lastName
        fullName
      }
      location {
        id
        name
        fullAddress
        billingAccountId
        billingAccount {
          id
          name
          legalName
          billingAddress
          ayrMobile
          gst
          bStreetAddress
          bSuburb
          bCity
          bRegion
          bPostalCode
        }
        financeEmail
        commissionType
        commission
      }
      status {
        id
        name
      }
      isTemplate
      customerReference
      invoiceAsPackage
      orderType
      notes
      contact {
        id
        fullName
        phone
        mobile
        email
        jobTitle
      }
      site {
        id
        siteName
        lastActivity
        address
        fullAddress
      }
      gstType
      gst
      totalAmountGSTInclusive
      totalQuantity
      drQuantity
      backOrderQuantity
      totalSOAmount
      totalPaid
      balanceDue
      latePickupFee
      deliveryFee
      job {
        id
        jobNo
      }
      invoices {
        id
        invoiceNo
        xeroStatus
        totalAmount
        outstandingBalance
      }
      deliveriesAndReturns {
        id
        purchaseOrder {
          id
          poNo
        }
      }
      ...BaseFragment
    }
`;

export const ALL_SALES_ORDERS = gql`
  ${SALES_ORDER_FRAGMENT}
  query ${TENANT_PREFIX}salesOrders($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}salesOrders(sortArg: $sortArg, searchArg: $searchArg) {
      ...SalesOrderFragment
    }
  }
`;

export const SELECT_SALES_ORDERS = gql`
  query ${TENANT_PREFIX}salesOrders {
    ${TENANT_PREFIX}salesOrders {
      id
      soNo
    }
  }
`;

export const PAGINATED_SALES_ORDERS = gql`
  ${SALES_ORDER_FRAGMENT}
  query ${TENANT_PREFIX}paginatedSalesOrders($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedSalesOrders(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...SalesOrderFragment
      }
      pageInfo {
        count
        pageCount
        pageSize
        skip
        take
      }
    }
  }
`;

// export const SALES_ORDER_STATUS = gql`
//   query ${TENANT_PREFIX}getModuleWorkflowStatus{
//     ${TENANT_PREFIX}getModuleWorkflowStatus(code: "${MODULE_CODE}") {
//       id
//       name
//     }
// }`;

export const FIND_SALES_ORDER_BY_ID = gql`
  ${SALES_ORDER_BY_ID_FRAGMENT}
  query ${TENANT_PREFIX}findSalesOrderById($id: String!) {
    ${TENANT_PREFIX}findSalesOrderById(id: $id) {
      ...SalesOrderByIdFragment
    }
  }
`;

export const DELETE_SALES_ORDER_BY_IDS = gql`
  mutation ${TENANT_PREFIX}deleteSalesOrders($ids: [String!]!) {
    ${TENANT_PREFIX}deleteSalesOrders(ids: $ids)
  }
`;

export const DELETE_SALES_ORDER_BY_ID = gql`
  mutation ${TENANT_PREFIX}deleteSalesOrder($id: String!) {
    ${TENANT_PREFIX}deleteSalesOrder(id: $id)
  }
`;

export const SALES_ORDER_DASHBOARD = gql`
  query ${TENANT_PREFIX}salesOrderDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}salesOrderDashboard(dashboardArg: $dashboardArg) {
        all
        created
        inProgress
        partiallyDelivered
        delivered
        rejected
        cancelled
        returned
        generatedInvoice
        completed
        void
    }
  }
`;

export const UPDATE_SALES_ORDER_STATUS = gql`
  mutation ${TENANT_PREFIX}updateSalesOrderStatus(
    $status: ${TENANT_PREFIX}SalesOrderStatusInput!, 
    $id: String!) {
    ${TENANT_PREFIX}updateSalesOrderStatus(status: $status, id: $id) {
      id
    }
  }
`;

export const CREATE_SALES_ORDER = gql`
  mutation ${TENANT_PREFIX}createSalesOrder($input: ${TENANT_PREFIX}SalesOrderInput!) {
    ${TENANT_PREFIX}createSalesOrder(salesOrderInput: $input) {
      id
      soNo
    }
  }
`;

export const UPDATE_SALES_ORDER = gql`
  mutation ${TENANT_PREFIX}updateSalesOrder($input: ${TENANT_PREFIX}SalesOrderInput!, $id: String!) {
    ${TENANT_PREFIX}updateSalesOrder(salesOrderInput: $input, id: $id) {
      id
      soNo
    }
  }
`;

export const GET_SALES_ORDER_DASHBOARD = gql`
  query ${TENANT_PREFIX}salesOrdersDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}salesOrdersDashboard(dashboardArg: $dashboardArg) {
      all
      created
      inProgress
      partiallyDelivered   
      delivered
      rejected
      cancelled
      returned
      generatedInvoice
      completed
      void
    }
  }
`;
