import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'QualityAudit';
const TITLE_SMALL = 'qualityAudit';
const TITLE_FRAGMENT = 'QualityAuditFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_QUALITY_AUDIT_TITLE = 'paginatedQualityAudits';
// Lightweight fragment for list views - only essential fields
export const QUALITY_AUDIT_LIST_FRAGMENT = gql`
  fragment QualityAuditListFragment on ${MODEL_NAME} {
    id
    qaNo
    qaScore
    createdAt
    locationId
    rectificationDate
    location {
      id
      name
    }
    job {
      id
      jobNo
      account {
        id
        name
        primaryContact {
          id
          firstName
          lastName
        }
      }
    }
    recordOwnerId
    recordOwner {
      id
      firstName
      lastName
      fullName
    }
    reviewedById
    reviewedBy {
      id
      firstName
      lastName
      fullName
    }
    status {
      id
      name
    }
    qaAreas {
      id
      area
      assessment
    }
    qaSpecifications {
      id
      specification
      assessment
      qaAreaId
      qualityAuditId
    }
    ...BaseFragment
  }
  ${BASE_FRAGMENT}
`;

export const QUALITY_AUDIT_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    locationId
    location {
      id
      name
    }
    job {
      location {
        id
        fullAddress
        city
        name
      }
      contact {
        id
        firstName
        lastName
        fullName
        mobile
        email
        status {
          id
          name
        }
      }
      account {
        accountNumber
        accountType
        name
        id
        status {
          id
          name
        }
        primaryContact {
          id
          firstName
          fullName
          lastName
          jobTitle
          phone
          mobile
          email
          secondaryEmail
          preferredMethodOfCommunication
        }
      }
      site {
        id
        siteName
        lastActivity
        streetAddress
        suburb
        city
        region
        country {
          name
        }
        area {
          id
        }
        address
        findStreet
        fullAddress
      }
      id
      jobNo
      jobAmount
      jobDetails {
        id
        area
        jobSpecification {
          id
          specifications
          serviceProviderAssignments {
            id
            serviceProvider {
              id
              name
            }
          }
        }
      }
      jobBillings {
        id
        serviceProvider {
          id
          name
        }
      }
    }
    franchisees {
      id
      name
    }
    auditMonth
    id
    franchiseeNotes
    customerNotes
    rectificationDate
    meetWithCustomer
    recordOwnerId
    recordOwner {
      id
      lastName
      jobTitle
      mobile
      name
      email
      firstName
      fullName
      phone
    }
    reviewedById
    reviewedBy {
      id
      lastName
      firstName
      fullName
      email
    }
    reasonForNotMeeting
    whoDidYouMeet
    qaScore
    qaNo
    createdAt
    status {
      id
      name
    }
    qaAreas {
      id
      area
      assessment
    }
    qaSpecifications {
      id
      specification
      assessment
      notes
      qaAreaId
      qualityAuditId
    }
  }
  ${BASE_FRAGMENT}
`;

// Lightweight paginated query for list views
export const PAGINATED_QUALITY_AUDIT_LIST = gql`
  ${QUALITY_AUDIT_LIST_FRAGMENT}
  query paginatedQualityAuditsList($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_QUALITY_AUDIT_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...QualityAuditListFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Full paginated query for detail views
export const PAGINATED_QUALITY_AUDIT = gql`
  ${QUALITY_AUDIT_FRAGMENT}
  query ${PAGINATED_QUALITY_AUDIT_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_QUALITY_AUDIT_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_QUALITY_AUDIT = gql`
  ${QUALITY_AUDIT_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_QUALITY_AUDIT_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const ALL_QUALITY_AUDIT_IDS_MIN = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}(sortArg: $sortArg, searchArg: $searchArg) {
      id
      qaNo
    }
  }
`;

// Lightweight query for dashboard counts - returns id, status, and rectificationDate for counting
export const ALL_QUALITY_AUDIT_STATUS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}Status($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}(sortArg: $sortArg, searchArg: $searchArg) {
      id
      rectificationDate
      status {
        id
        name
      }
    }
  }
`;

export const FIND_QUALITY_AUDIT_BY_ID = gql`
  ${QUALITY_AUDIT_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ByIdId: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ByIdId) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_QUALITY_AUDIT_BY_ID = gql`
  ${QUALITY_AUDIT_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}Input: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}Input: $${TITLE_SMALL}Input, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_QUALITY_AUDIT = gql`
  ${QUALITY_AUDIT_FRAGMENT}
  mutation create${TITLE}($qualityAuditInput: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(qualityAuditInput: $qualityAuditInput) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_QUALITY_AUDIT = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_QUALITY_AUDITS = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}Id: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}Id)
  }
`;

export const GET_QUALITY_AUDIT_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const QUALITY_AUDIT_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}Dashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}Dashboard(dashboardArg: $dashboardArg) {
     all
     pending
     complete
     cancelled
     overdue
     created
     in_progress
    }
  }
`;

export const UPDATE_QUALITY_AUDIT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateQualityAuditStatus($${TENANT_PREFIX}updateQualityAuditStatusId: String!, $qualityAuditStatusInput: ${TENANT_PREFIX}QualityAuditStatusInput!) {
    ${TENANT_PREFIX}updateQualityAuditStatus(id: $${TENANT_PREFIX}updateQualityAuditStatusId, qualityAuditStatusInput: $qualityAuditStatusInput) {
      id
      qaNo
    }
  }
`;
