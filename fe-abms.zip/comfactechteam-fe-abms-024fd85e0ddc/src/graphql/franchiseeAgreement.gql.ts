import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}FranchiseeAgreement`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FRANCHISEE_FRAGMENT = gql`
  fragment FranchiseeFragment on ${MODEL_NAME} {
    agreementDate
    agreementType
    annualIncome
    assignmentFee
    agreementPDF
    agreementNo
    trainingStartDate
    commencementDate
    brand
    businessPurchaseAmount
    businessToPurchase {
      id
      name
    }
    equipmentFee
    expiryDateofEntireAgreement
    firstAveGrossWeeklyRevenue
    firstAveNoOfWeeks
    fourthAveGrossWeeklyRevenue
    createdBy
    createdByName
    franchiseeType
    franchisee {
      id
      name
      primaryContact {
        id
        fullName
        email
        mobile
      }
    }
    franchiseeFee
    possessionDate
    id
    installmentArrangement
    notes
    originalCommencement
    thirdAveNoOfYears
    orgId
    monthlyWorkLevelAmount
    thirdAveGrossWeeklyRevenue
    royalty
    renewalDate
    secondAveGrossWeeklyRevenue
    status {
    id
    name
    }
    location {
    name
    id
    }
    secondAveNoOfWeeks
    signedFile
    signedFileKey
    signedFileMetaData
    signedFileDownloadUrl
    vehiclePurchaseAmount
    weeklyFeeInvoiceStartDate
    weeklyWorkLevelAmount
    withVehicle
    parentAgreement {
      id
      agreementNo
    }
    workLevelType
    vehicle {
      make
      model
      year
      id
    }
    recruitment {
      id
      recruitmentNo
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_SITES = gql`
  ${FRANCHISEE_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedSites {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...FranchiseeFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_FRANCHISEE_AGREEMENT = gql`
  ${FRANCHISEE_FRAGMENT}
  query ${TENANT_PREFIX}franchiseeAgreements($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}franchiseeAgreements(sortArg: $sortArg, searchArg: $searchArg) {
      ...FranchiseeFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_FRANCHISEE_AGREEMENTS = gql`
  ${FRANCHISEE_FRAGMENT}
  query ${TENANT_PREFIX}paginatedFranchiseeAgreements($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFranchiseeAgreements(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...FranchiseeFragment
        ...BaseFragment
      }
    }
  }
`;

export const SELECT_SITES = gql`
  query ${TENANT_PREFIX}sites{
    ${TENANT_PREFIX}sites{
      id
      siteName
      lastActivity
      fullAddress
    }
  }
`;

export const FIND_AGREEMENT_BY_ID = gql`
  ${FRANCHISEE_FRAGMENT}
  query ${TENANT_PREFIX}findFranchiseeAgreementById($${TENANT_PREFIX}findFranchiseeAgreementByIdId: String!) {
    ${TENANT_PREFIX}findFranchiseeAgreementById(id: $${TENANT_PREFIX}findFranchiseeAgreementByIdId) {
      ...FranchiseeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_AGREEMENT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateFranchiseeAgreementStatus($${TENANT_PREFIX}updateFranchiseeAgreementStatusId: String!, $status: ${TENANT_PREFIX}FranchiseeAgreementStatusInput!) {
    ${TENANT_PREFIX}updateFranchiseeAgreementStatus(id: $${TENANT_PREFIX}updateFranchiseeAgreementStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_FRANCHISEE_AGREEMENT = gql`
  mutation ${TENANT_PREFIX}updateFranchiseeAgreement($franchiseeAgreement: ${TENANT_PREFIX}FranchiseeAgreementInput!, $${TENANT_PREFIX}updateFranchiseeAgreementId: String!) {
    ${TENANT_PREFIX}updateFranchiseeAgreement(franchiseeAgreement: $franchiseeAgreement, id: $${TENANT_PREFIX}updateFranchiseeAgreementId) {
      id
    }
  }
`;

export const CREATE_FRANCHISEE_AGREEMENT = gql`
  ${FRANCHISEE_FRAGMENT}
  mutation ${TENANT_PREFIX}createFranchiseeAgreement($franchiseeAgreement: ${TENANT_PREFIX}FranchiseeAgreementInput!) {
    ${TENANT_PREFIX}createFranchiseeAgreement(franchiseeAgreement: $franchiseeAgreement) {
      ...FranchiseeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FRANCHISEE_AGREEMENTS = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeAgreements($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFranchiseeAgreements(ids: $ids)
  }
`;

export const DELETE_FRANCHISEE_AGREEMENT = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeAgreement($${TENANT_PREFIX}deleteFranchiseeAgreementId: String!) {
    ${TENANT_PREFIX}deleteFranchiseeAgreement(id: $${TENANT_PREFIX}deleteFranchiseeAgreementId)
  }
`;

export const GET_FRANCHISEE_AGREEMENT_SIGNED_FILE_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getFranchiseeAgreementSignedFileUploadUrl(
    $fileName: String!
    $contentType: String!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getFranchiseeAgreementSignedFileUploadUrl(
      fileName: $fileName
      contentType: $contentType
      expiresIn: $expiresIn
    ) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;
