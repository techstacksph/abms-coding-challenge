import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const AUDIT_TRAILS = gql`
  query ${TENANT_PREFIX}auditTrails($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}auditTrails(searchArg: $searchArg, sortArg: $sortArg) {
      id
      moduleId
      recordId
      actionType
      content
      changes {
        before
        after
      }
      createdAt
      updatedAt
      createdBy
      updatedBy
      createdByName
      updatedByName
    }
  }
`;

export const PAGINATED_AUDIT_TRAILS = gql`
  query ${TENANT_PREFIX}paginatedAuditTrails($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedAuditTrails(pageArg: $pageArg, searchArg: $searchArg) {
      data {
        id
        moduleId
        recordId
        actionType
        content
        changes {
          before
          after
        }
        createdAt
        updatedAt
        createdBy
        updatedBy
        createdByName
        updatedByName
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const FIND_AUDIT_TRAIL_BY_ID = gql`
  query ${TENANT_PREFIX}findAuditTrailById($id: String!) {
    ${TENANT_PREFIX}findAuditTrailById(id: $id) {
      id
      moduleId
      recordId
      actionType
      content
      changes {
        before
        after
      }
      createdAt
      updatedAt
      createdBy
      updatedBy
      createdByName
      updatedByName
    }
  }
`;
