import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const TITLE = 'PurchaseOrder';
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PURCHASE_ORDER_FRAGMENT = gql`
  fragment PurchaseOrderFragment on ${MODEL_NAME} {
    id
    orgId
    poNo
    platformId
    poDate
    poFile
    supplierId
    contactId
    reference
    warehouseId
    deliveryAddress
    notes
    paymentTermId
    sendOrdersViaEmail
    bulk
    eta
    gstType
    subTotal
    gst
    totalAmount
    amountPaid
    balanceDue
    statusId
    deliveriesAndReturns {
      id
    }
    poItems {
      id
      orgId
      updatedAt
      quantity
      unitPrice
      amount
      drQuantity
      backOrderQuantity
      lineNo
      statusId
      reference {
        id 
        jobNo
      }
      referenceId
      soldTo {
        id 
        name
      }
      soldToId
      status {
        id 
        name
      }
      deliveryDate
      item {
        color
        brand
        dimension
        description
        name
        itemCode
        weight
        pricing
      }
      itemId
      uomId
      uom {
        id
        name
        code
      }
    }
    supplier {
      id
      orgId
      accountNumber
      accountType
      name
      notes
      requiresPO
      website
      bankAccountNo
      gst
      nzbn
      locationId
      interestedServicesId
      primaryContact {
        id 
        fullName
        firstName
        lastName
        email
        phone
        mobile
        jobTitle
        
      }
      pFindAddress
      pStreetAddress
      pSuburb
      pCity
      pRegion
      pPostalCode
      pViewLocation
      isSameAsPhysicalAddress
      bFindAddress
      bStreetAddress
      bSuburb
      bCity
      bRegion
      bPostalCode
      legalName
      franchiseeType
      startDate
      ayrMobile
      ayrEmail
      irdNo
      recruitmentId
      supplierAccountNo
      bankAccountName
      bankName
      bankAddress
      statusNotes
      subconAccountNo
      subconType
      physicalAddress
      billingAddress
      hasDeals
    }
    contact {
      id
      orgId
      firstName
      lastName
      fullName
      jobTitle
      notes
      phone
      mobile
      email
      secondaryEmail
      preferredMethodOfCommunication
      doNotContact
      suburb
      city
      areaId
      region
      postalCode
      countryId
      viewlocation
      address
      uploadPhoto
      dateOfBirth
      startDate
      endDate
      completionDate
      contactTypes
      fullAddress
    }
    warehouse {
      id
      orgId
      name
      code
      description
      address
      streetAddress
      suburb
      city
      region
      postalcode
      country
      area
    }
    recordOwner {
      id
      orgId
      name
      lastName
      firstName
      fullName
      email
      userName
      status
      phone
      mobile
      jobTitle
    }
    department {
      id
      orgId
      lockedBy
      timeLocked
      name
      description
      userIds
      parentDepartmentId
      platformId
    }
    location {
      id
      orgId
      name
      description
      address
      streetAddress
      suburb
      city
      areaId
      region
      postalCode
      countryCode
      countryId
      billingAccountId
      parentLocationId
      financeEmail
      billingAccount {
        id
        name
        legalName
        billingAddress
        ayrMobile
        gst
        bankAccountNo
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
      }
    }
    customer {
      id
      orgId
      accountNumber
      accountType
      name
      notes
      requiresPO
      bankAccountNo
      gst
      nzbn
      locationId
      interestedServicesId
      primaryContact {
        id
        fullName
      }
      pFindAddress
      pStreetAddress
      pSuburb
      pCity
      pRegion
      pPostalCode
      bFindAddress
      bStreetAddress
      bSuburb
      bCity
      bRegion
      bPostalCode
      legalName
      franchiseeType
      startDate
      ayrMobile
      ayrEmail
      irdNo
      recruitmentId
      supplierAccountNo
      physicalAddress
      billingAddress
      hasDeals
    }
    status {
      id
      name
      description
    }
    salesOrderNoId
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_PURCHASE_ORDERS = gql`
  ${PURCHASE_ORDER_FRAGMENT}
  query paginatedPurchaseOrder($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPurchaseOrders(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PurchaseOrderFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_PURCHASE_ORDERS = gql`
  ${PURCHASE_ORDER_FRAGMENT}
  query ${TENANT_PREFIX}purchaseOrders($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}purchaseOrders(sortArg: $sortArg, searchArg: $searchArg) {
      ...PurchaseOrderFragment
      ...BaseFragment
    }
  }
`;

export const ALL_PURCHASE_ORDERS_IDS = gql`
  query ${TENANT_PREFIX}purchaseOrdersIds($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}purchaseOrders(sortArg: $sortArg, searchArg: $searchArg) {
      id
      supplier {
        id
      }
    }
  }
`;

export const SELECT_PURCHASE_ORDERS = gql`
  query ${TENANT_PREFIX}purchaseOrders{
    ${TENANT_PREFIX}purchaseOrders{
      id
      poDate
      poFile
      poNo
      notes
    }
  }
`;

export const FIND_PURCHASE_ORDER_BY_ID = gql`
  ${PURCHASE_ORDER_FRAGMENT}
  query ${TENANT_PREFIX}findPurchaseOrderById($${TENANT_PREFIX}findPurchaseOrderByIdId: String!) {
    ${TENANT_PREFIX}findPurchaseOrderById(id: $${TENANT_PREFIX}findPurchaseOrderByIdId) {
      ...PurchaseOrderFragment
      ...BaseFragment
    }
  }
`;

export const PURCHASE_ORDER_DASHBOARD = gql`
  query ${TENANT_PREFIX}purchaseOrdersDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}purchaseOrdersDashboard(dashboardArg: $dashboardArg) {
      all
      created
      approved
      sentToSupplier
      partiallyDelivered
      delivered
      rejected
      cancelled
      returned
    }
  }
`;

export const COUNT_CREATED_PURCHASE_ORDERS = gql`
  query ${TENANT_PREFIX}paginatedPurchaseOrders($searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedPurchaseOrders(searchArg: $searchArg) {
      pageInfo {
        count
      }
    }
  }
`;

export const UPDATE_PURCHASE_ORDER = gql`
  ${PURCHASE_ORDER_FRAGMENT}
  mutation ${TENANT_PREFIX}updatePurchaseOrder($${TENANT_PREFIX}updatePurchaseOrderId: String!, $purchaseOrder: ${TENANT_PREFIX}PurchaseOrderInput!) {
    ${TENANT_PREFIX}updatePurchaseOrder(id: $${TENANT_PREFIX}updatePurchaseOrderId, purchaseOrder: $purchaseOrder) {
      ...PurchaseOrderFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_PURCHASE_ORDER = gql`
  ${PURCHASE_ORDER_FRAGMENT}
  mutation ${TENANT_PREFIX}createPurchaseOrder($purchaseOrder: ${TENANT_PREFIX}PurchaseOrderInput!) {
    ${TENANT_PREFIX}createPurchaseOrder(purchaseOrder: $purchaseOrder) {
      ...PurchaseOrderFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_PURCHASE_ORDER = gql`
  mutation ${TENANT_PREFIX}deletePurchaseOrder($${TENANT_PREFIX}deletePurchaseOrderId: String!) {
    ${TENANT_PREFIX}deletePurchaseOrder(id: $${TENANT_PREFIX}deletePurchaseOrderId)
  }
`;

export const DELETE_PURCHASE_ORDERS = gql`
  mutation ${TENANT_PREFIX}deletePurchaseOrders($ids: [String!]!) {
    ${TENANT_PREFIX}deletePurchaseOrders(ids: $ids)
  }
`;

export const UPDATE_PURCHASE_ORDER_STATUS = gql`
  mutation ${TENANT_PREFIX}updatePurchaseOrderStatus($id: String!, $status: ${TENANT_PREFIX}PurchaseOrderStatusInput!) {
    ${TENANT_PREFIX}updatePurchaseOrderStatus(id: $id, status: $status) {
      id
    }
  }
`;
