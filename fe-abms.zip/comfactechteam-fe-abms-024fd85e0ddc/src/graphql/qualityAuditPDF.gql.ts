import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}QualityAuditPDF`;

export const QUALITY_AUDIT_PDF_FRAGMENT = gql`
  fragment QualityAuditPDFFragment on ${MODEL_NAME} {
    id
    qualityAuditId
    qualityAudit {
      id
      qaNo
    }
    type
    serviceProviderId
    serviceProvider {
      id
      name
    }
    pdf
    fileName
    file
    createdAt
    updatedAt
    createdBy
    updatedBy
  }
`;

export const CREATE_QUALITY_AUDIT_PDF = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}createQualityAuditPDF($qualityAuditPDF: ${MODEL_NAME}Input!) {
    ${TENANT_PREFIX}createQualityAuditPDF(qualityAuditPDF: $qualityAuditPDF) {
      ...QualityAuditPDFFragment
    }
  }
`;

export const CREATE_MULTIPLE_QUALITY_AUDIT_PDFS = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}createMultipleQualityAuditPDFs($qualityAuditPDFs: [${MODEL_NAME}Input!]!) {
    ${TENANT_PREFIX}createMultipleQualityAuditPDFs(qualityAuditPDFs: $qualityAuditPDFs) {
      ...QualityAuditPDFFragment
    }
  }
`;

export const UPDATE_QUALITY_AUDIT_PDF = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}updateQualityAuditPDF($qualityAuditPDF: ${MODEL_NAME}Input!, $id: String!) {
    ${TENANT_PREFIX}updateQualityAuditPDF(qualityAuditPDF: $qualityAuditPDF, id: $id) {
      ...QualityAuditPDFFragment
    }
  }
`;

export const DELETE_QUALITY_AUDIT_PDF = gql`
  mutation ${TENANT_PREFIX}deleteQualityAuditPDF($id: String!) {
    ${TENANT_PREFIX}deleteQualityAuditPDF(id: $id)
  }
`;

export const DELETE_QUALITY_AUDIT_PDFS = gql`
  mutation ${TENANT_PREFIX}deleteQualityAuditPDFs($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQualityAuditPDFs(ids: $ids)
  }
`;

export const FIND_QUALITY_AUDIT_PDF_BY_ID = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  query ${TENANT_PREFIX}findQualityAuditPDFById($id: String!) {
    ${TENANT_PREFIX}findQualityAuditPDFById(id: $id) {
      ...QualityAuditPDFFragment
    }
  }
`;

export const FIND_QUALITY_AUDIT_PDFS = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  query ${TENANT_PREFIX}qualityAuditPDFs($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}qualityAuditPDFs(searchArg: $searchArg, sortArg: $sortArg) {
      ...QualityAuditPDFFragment
    }
  }
`;

export const PAGINATED_QUALITY_AUDIT_PDFS = gql`
  ${QUALITY_AUDIT_PDF_FRAGMENT}
  query ${TENANT_PREFIX}paginatedQualityAuditPDFs($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedQualityAuditPDFs(pageArg: $pageArg, searchArg: $searchArg) {
      data {
        ...QualityAuditPDFFragment
      }
      pageInfo {
        count
      }
    }
  }
`;
