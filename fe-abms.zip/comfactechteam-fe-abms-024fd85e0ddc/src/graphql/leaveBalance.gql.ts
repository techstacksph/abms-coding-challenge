import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const LEAVE_BALANCE_FRAGMENT = gql`
  fragment LeaveBalanceFragment on ${TENANT_PREFIX}LeaveBalance {
    id
    employee {
      id
      firstName
      lastName
    }
    effectiveDate
    notes
    leaveTypeDetails {
      id
      leaveTypeId
      leaveBalanceId
      beginningBalance
      availableBalance
      leaveType {
        id
        name
      }
      createdAt
      updatedAt
      createdBy
      updatedBy
      createdByName
      updatedByName
    }
    createdAt
    updatedAt
    createdBy
    updatedBy
    createdByName
    updatedByName
    deletedAt
    deletedBy
  }
`;

export const PAGINATED_LEAVE_BALANCES = gql`
  ${LEAVE_BALANCE_FRAGMENT}
  query ${TENANT_PREFIX}paginatedLeaveBalances($pageArg: ${TENANT_PREFIX}PageArg!, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedLeaveBalances(pageArg: $pageArg, searchArg: $searchArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...LeaveBalanceFragment
      }
    }
  }
`;

export const ALL_LEAVE_BALANCES = gql`
  ${LEAVE_BALANCE_FRAGMENT}
  query ${TENANT_PREFIX}leaveBalances($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leaveBalances(sortArg: $sortArg, searchArg: $searchArg) {
      ...LeaveBalanceFragment
    }
  }
`;

export const FIND_LEAVE_BALANCE_BY_ID = gql`
  ${LEAVE_BALANCE_FRAGMENT}
  query ${TENANT_PREFIX}findLeaveBalanceById($id: String!) {
    ${TENANT_PREFIX}findLeaveBalanceById(id: $id) {
      ...LeaveBalanceFragment
    }
  }
`;

export const ALL_LEAVE_BALANCES_IDS = gql`
  query ${TENANT_PREFIX}leaveBalancesIds {
    ${TENANT_PREFIX}leaveBalances {
      id
    }
  }
`;

export const DELETE_LEAVE_BALANCES = gql`
  mutation ${TENANT_PREFIX}deleteLeaveBalances($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLeaveBalances(ids: $ids)
  }
`;

export const ALL_LEAVE_TYPES = gql`
  query ${TENANT_PREFIX}leaveTypesForBalance {
    ${TENANT_PREFIX}leaveTypes {
      id
      name
      code
    }
  }
`;

export const CREATE_LEAVE_BALANCE = gql`
  mutation ${TENANT_PREFIX}createLeaveBalance($leaveBalance: ${TENANT_PREFIX}LeaveBalanceInput!) {
    ${TENANT_PREFIX}createLeaveBalance(leaveBalance: $leaveBalance) {
      id
      employee {
        id
        firstName
        lastName
      }
    }
  }
`;

export const UPDATE_LEAVE_BALANCE = gql`
  mutation ${TENANT_PREFIX}updateLeaveBalance($id: String!, $leaveBalance: ${TENANT_PREFIX}LeaveBalanceInput!) {
    ${TENANT_PREFIX}updateLeaveBalance(id: $id, leaveBalance: $leaveBalance) {
      id
      employee {
        id
        firstName
        lastName
      }
    }
  }
`;

export const CREATE_LEAVE_TYPE_DETAILS = gql`
  mutation ${TENANT_PREFIX}createLeaveTypeDetails($leaveTypeDetails: ${TENANT_PREFIX}LeaveTypeDetailsInput!) {
    ${TENANT_PREFIX}createLeaveTypeDetails(leaveTypeDetails: $leaveTypeDetails) {
      id
      leaveType {
        id
        name
      }
      beginningBalance
      availableBalance
    }
  }
`;

export const UPDATE_LEAVE_TYPE_DETAILS = gql`
  mutation ${TENANT_PREFIX}updateLeaveTypeDetails($id: String!, $leaveTypeDetails: ${TENANT_PREFIX}LeaveTypeDetailsInput!) {
    ${TENANT_PREFIX}updateLeaveTypeDetails(id: $id, leaveTypeDetails: $leaveTypeDetails) {
      id
      leaveType {
        id
        name
      }
      beginningBalance
      availableBalance
    }
  }
`;

export const DELETE_LEAVE_TYPE_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteLeaveTypeDetails($id: String!) {
    ${TENANT_PREFIX}deleteLeaveTypeDetails(id: $id)
  }
`;
