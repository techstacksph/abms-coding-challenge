import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}NotificationAndAlert`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const NOTIFICATION_FRAGMENT = gql`
  fragment NotificationFragment on ${MODEL_NAME} {
    id
    subject
    description
    module
    icon
    read
    createdAt
    createdBy
    createdByName
    updatedAt
    updatedBy
    updatedByName
    deletedAt
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    orgId
    user {
      id
      firstName
      lastName
      email
    }
    task {
      id
      taskSubject
    }
    event {
      id
      subject
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_NOTIFICATIONS = gql`
  ${NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}notificationAndAlerts(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}notificationAndAlerts(sortArg: $sortArg, searchArg: $searchArg) {
      ...NotificationFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_NOTIFICATIONS = gql`
  ${NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedNotificationAndAlerts(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $pageArg: ${TENANT_PREFIX}PageArg
  ) {
    ${TENANT_PREFIX}paginatedNotificationAndAlerts(
      searchArg: $searchArg
      pageArg: $pageArg
    ) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...NotificationFragment
        ...BaseFragment
      }
    }
  }
`;

export const UNREAD_NOTIFICATION_COUNT = gql`
  query ${TENANT_PREFIX}unreadNotificationCount {
    ${TENANT_PREFIX}unreadNotificationCount
  }
`;

export const FIND_NOTIFICATION_BY_ID = gql`
  ${NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}findNotificationAndAlertById($${TENANT_PREFIX}findNotificationAndAlertByIdId: String!) {
    ${TENANT_PREFIX}findNotificationAndAlertById(id: $${TENANT_PREFIX}findNotificationAndAlertByIdId) {
      ...NotificationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_NOTIFICATION = gql`
  ${NOTIFICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateNotificationAndAlert(
    $notificationAndAlert: ${TENANT_PREFIX}NotificationAndAlertInput!
    $${TENANT_PREFIX}updateNotificationAndAlertId: String!
  ) {
    ${TENANT_PREFIX}updateNotificationAndAlert(
      notificationAndAlert: $notificationAndAlert
      id: $${TENANT_PREFIX}updateNotificationAndAlertId
    ) {
      ...NotificationFragment
      ...BaseFragment
    }
  }
`;

export const MARK_NOTIFICATION_READ = gql`
  ${NOTIFICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateNotificationAndAlert($${TENANT_PREFIX}updateNotificationAndAlertId: String!) {
    ${TENANT_PREFIX}updateNotificationAndAlert(
      notificationAndAlert: { read: true }
      id: $${TENANT_PREFIX}updateNotificationAndAlertId
    ) {
      ...NotificationFragment
      ...BaseFragment
    }
  }
`;

export const MARK_NOTIFICATION_UNREAD = gql`
  ${NOTIFICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateNotificationAndAlert($${TENANT_PREFIX}updateNotificationAndAlertId: String!) {
    ${TENANT_PREFIX}updateNotificationAndAlert(
      notificationAndAlert: { read: false }
      id: $${TENANT_PREFIX}updateNotificationAndAlertId
    ) {
      ...NotificationFragment
      ...BaseFragment
    }
  }
`;

export const MARK_ALL_NOTIFICATIONS_AS_READ = gql`
  mutation ${TENANT_PREFIX}markAllNotificationsAsRead {
    ${TENANT_PREFIX}markAllNotificationsAsRead
  }
`;
