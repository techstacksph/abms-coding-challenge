import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Industry`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INDUSTRY_FRAGMENT = gql`
  fragment IndustryFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_INDUSTRIES = gql`
  ${INDUSTRY_FRAGMENT}
  query paginatedIndustries($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedIndustries(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...IndustryFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_INDUSTRIES = gql`
  ${INDUSTRY_FRAGMENT}
  query ${TENANT_PREFIX}industries($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}industries(sortArg: $sortArg, searchArg: $searchArg) {
      ...IndustryFragment
      ...BaseFragment
    }
  }
`;

export const ALL_INDUSTRIES_IDS = gql`
  query ${TENANT_PREFIX}industries($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}industries(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_INDUSTRY_BY_ID = gql`
  ${INDUSTRY_FRAGMENT}
  query findIndustryById($${TENANT_PREFIX}findIndustryByIdId: String!) {
    ${TENANT_PREFIX}findIndustryById(id: $${TENANT_PREFIX}findIndustryByIdId) {
      ...IndustryFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INDUSTRY_BY_ID = gql`
  ${INDUSTRY_FRAGMENT}
  mutation updateIndustry($industry: ${TENANT_PREFIX}IndustryInput!, $${TENANT_PREFIX}updateIndustryId: String!) {
    ${TENANT_PREFIX}updateIndustry(industry: $industry, id: $${TENANT_PREFIX}updateIndustryId) {
      ...IndustryFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_INDUSTRY = gql`
  ${INDUSTRY_FRAGMENT}
  mutation createIndustry($industry: ${TENANT_PREFIX}IndustryInput!) {
    ${TENANT_PREFIX}createIndustry(industry: $industry) {
      ...IndustryFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_INDUSTRY = gql`
  mutation deleteIndustry($${TENANT_PREFIX}deleteIndustryById: String!) {
    ${TENANT_PREFIX}deleteIndustry(id: $${TENANT_PREFIX}deleteIndustryById)
  }
`;

export const DELETE_INDUSTRIES = gql`
  mutation deleteIndustries($ids: [String!]!) {
    ${TENANT_PREFIX}deleteIndustries(ids: $ids)
  }
`;

export const GET_INDUSTRIES_CSV = gql`
  query ${TENANT_PREFIX}IndustryCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}IndustryCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
