import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Answer`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ANSWER_FRAGMENT = gql`
  fragment AnswerFragment on ${MODEL_NAME} {
    id
    answer
    comment
    questionnaire {
      id
    }
    module {
      id
      name
    }
    performanceReview {
      id
    }
    lead {
      id
    }
    recruitment {
      id
    }
    question {
      id
      name
      type
      description
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_ANSWERS = gql`
  ${ANSWER_FRAGMENT}
  query ${TENANT_PREFIX}paginatedAnswers($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedAnswers(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...AnswerFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_ANSWERS = gql`
  ${ANSWER_FRAGMENT}
  query ${TENANT_PREFIX}answers($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}answers(sortArg: $sortArg, searchArg: $searchArg) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const FIND_ANSWER_BY_ID = gql`
  ${ANSWER_FRAGMENT}
  query ${TENANT_PREFIX}findAnswerById($${TENANT_PREFIX}findAnswerByIdId: String!) {
    ${TENANT_PREFIX}findAnswerById(id: $${TENANT_PREFIX}findAnswerByIdId) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ANSWER = gql`
  ${ANSWER_FRAGMENT}
  mutation ${TENANT_PREFIX}updateAnswer($answer: ${TENANT_PREFIX}AnswerInput!, $${TENANT_PREFIX}updateAnswerId: String!) {
    ${TENANT_PREFIX}updateAnswer(answer: $answer, id: $${TENANT_PREFIX}updateAnswerId) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ANSWERS = gql`
  ${ANSWER_FRAGMENT}
  mutation ${TENANT_PREFIX}updateAnswers($ids: [String!]!, $answers: [${TENANT_PREFIX}AnswerInput!]!) {
    ${TENANT_PREFIX}updateAnswers(ids: $ids, answers: $answers) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ANSWER = gql`
  ${ANSWER_FRAGMENT}
  mutation ${TENANT_PREFIX}createAnswer($answer: ${TENANT_PREFIX}AnswerInput!) {
    ${TENANT_PREFIX}createAnswer(answer: $answer) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ANSWERS = gql`
  ${ANSWER_FRAGMENT}
  mutation ${TENANT_PREFIX}createAnswers($answers: [${TENANT_PREFIX}AnswerInput!]!) {
    ${TENANT_PREFIX}createAnswers(answers: $answers) {
      ...AnswerFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ANSWER = gql`
  mutation ${TENANT_PREFIX}deleteAnswer($${TENANT_PREFIX}deleteAnswerId: String!) {
    ${TENANT_PREFIX}deleteAnswer(id: $${TENANT_PREFIX}deleteAnswerId)
  }
`;

export const DELETE_ANSWERS = gql`
  mutation ${TENANT_PREFIX}deleteAnswers($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAnswers(ids: $ids)
  }
`;

export const GET_ANSWER_CSV = gql`
  query ${TENANT_PREFIX}AnswerCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}AnswerCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
