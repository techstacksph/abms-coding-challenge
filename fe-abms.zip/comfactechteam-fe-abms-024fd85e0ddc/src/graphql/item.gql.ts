import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Item`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ITEM_FRAGMENT = gql`
  fragment ItemFragment on ${MODEL_NAME} {
    id
    name
    description
    parentItem {
      id
      name
      description
      itemCode
      productImage
    }
    parentItemId
    childItems {
      id
      name
      description
      pricing
      itemCode
      productImage
      uom {
        id
      }
    }
    kitItems {
      id
      qty
      childItemId
      childItem {
        id
        name
        description
        pricing
        itemCode
        productImage
        uom {
          id
        }
      }
    }
    specifications {
      id
      specificationName
    }
    itemCategory {
      id
      name
    }
    itemSubcategory {
      id
      name
    }
    itemType
    itemTags {
      id
      name
    }
    primaryTag {
      id
    }
    itemStatus
    isKit
    brand
    modelNo
    country {
      id
      name
    }
    supplierId
    maxDemandPerDay
    uom {
      id
      name
    }
    size
    dimension
    color
    weight
    workflowStatus {
      name
      id
    }
    pricing
    itemCode
    productImage
    variantTypeId
    serviceTypeId
    video
    itemsCatalogues {
      id
      file
      fileKey
      downloadUrl
      item {
        id
        name
        description
        pricing
        itemCode
        productImage
        uom {
          id
        }
      }
    }
    itemVariantTypes {
      id
      variantType {
        id
        name
      }
    }
    inventoryAssetAcount{
      id
      accountCode
    }
    costOfGoodsSoldAccount{
      id
      accountCode
    }
    salesAccount{
      id
      accountCode
    }
  }

  ${BASE_FRAGMENT}
`;

export const ITEM_VARIANT_FRAGMENT = gql`
  fragment ItemVariantFragment on ${TENANT_PREFIX}ItemVariantType {
    id
    variantType{
      id
      name
    }
  }
`;

export const PAGINATED_ITEMS = gql`
  ${ITEM_FRAGMENT}
  query paginatedItems($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedItems(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...ItemFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_ITEMS = gql`
  ${ITEM_FRAGMENT}
  query ${TENANT_PREFIX}items($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}items(sortArg: $sortArg, searchArg: $searchArg) {
      ...ItemFragment
      ...BaseFragment
    }
  }
`;

export const GET_DEAL_ITEMS = gql`
  query ${TENANT_PREFIX}items($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}items(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      description
      itemCode
      specifications {
        id
        specificationName
      }
      uom {
        name
      }
      itemVariantTypes {
        variantType {
          id
          name
        }
      }
    }
  }
`;

export const GET_DEAL_ITEMS_PAGINATED = gql`
  query ${TENANT_PREFIX}paginatedItems($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedItems(pageArg: $pageArg, searchArg: $searchArg) {
      data {
        id
        name
        description
        itemCode
        serviceTypeId
        specifications {
          id
          specificationName
        }
        uom {
          name
        }
        itemVariantTypes {
          variantType {
            id
            name
          }
        }
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_ITEMS_IDS = gql`
  query ${TENANT_PREFIX}items($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}items(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const ALL_ITEMS_TAGS = gql`
  query ${TENANT_PREFIX}itemTags($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemTags(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
    }
  }
`;

export const FIND_ITEM_BY_ID = gql`
  ${ITEM_FRAGMENT}
  query ${TENANT_PREFIX}findItemById($${TENANT_PREFIX}findItemByIdId: String!) {
    ${TENANT_PREFIX}findItemById(id: $${TENANT_PREFIX}findItemByIdId) {
      ...ItemFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ITEM_BY_ID = gql`
  ${ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}updateItem($item: ${TENANT_PREFIX}ItemInput!, $${TENANT_PREFIX}updateItemId: String!) {
    ${TENANT_PREFIX}updateItem(item: $item, id: $${TENANT_PREFIX}updateItemId) {
      ...ItemFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ITEM = gql`
  ${ITEM_FRAGMENT}
  mutation ${TENANT_PREFIX}createItem($item: ${TENANT_PREFIX}ItemInput!) {
    ${TENANT_PREFIX}createItem(item: $item) {
      ...ItemFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ITEM = gql`
  mutation ${TENANT_PREFIX}deleteItem($${TENANT_PREFIX}deleteItemId: String!) {
    ${TENANT_PREFIX}deleteItem(id: $${TENANT_PREFIX}deleteItemId)
  }
`;

export const DELETE_ITEMS = gql`
  mutation ${TENANT_PREFIX}deleteItems($ids: [String!]!) {
    ${TENANT_PREFIX}deleteItems(ids: $ids)
  }
`;

export const GET_ITEM_CSV = gql`
  query Query(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}ItemCSV(sortArg: $sortArg, columnArg: $columnArg, searchArg: $searchArg)
  }
`;

export const GET_ITEM_DASHBOARD = gql`
  query ${TENANT_PREFIX}itemsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}itemsDashboard(dashboardArg: $dashboardArg) {
      allProducts
      activeProducts
      inactiveProducts
      allServices
      activeServices
      inactiveServices
    }
  }
`;

export const UPSERT_ITEM_SPECIFICATIONS = gql`
  mutation ${TENANT_PREFIX}upsertSpecificationDetailSchemas(
    $updateSpecificationDetails: [${TENANT_PREFIX}SpecificationDetailInput!]!
  ) {
    ${TENANT_PREFIX}upsertSpecificationDetailSchemas(
      updateSpecificationDetails: $updateSpecificationDetails
    ) {
      id
    }
  }
`;

export const DELETE_SPECIFICATIONS = gql`
  mutation ${TENANT_PREFIX}deleteSpecificationDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteSpecificationDetails(ids: $ids)
  }
`;

export const CREATE_ITEM_CATALOGUE = gql`
  mutation ${TENANT_PREFIX}createItemsCatalogue($itemsCatalogue: ${TENANT_PREFIX}ItemsCatalogueInput!) {
    ${TENANT_PREFIX}createItemsCatalogue(itemsCatalogue: $itemsCatalogue) {
      id
    }
  }
`;

export const DELETE_ITEM_CATALOGUE = gql`
  mutation ${TENANT_PREFIX}deleteItemsCatalogue($${TENANT_PREFIX}deleteItemsCatalogueId: String!) {
    ${TENANT_PREFIX}deleteItemsCatalogue(id: $${TENANT_PREFIX}deleteItemsCatalogueId)
  }
`;

export const UPDATE_ITEM_STATUS = gql`
  mutation ${TENANT_PREFIX}updateItemStatus($status: Boolean!, $${TENANT_PREFIX}updateItemStatusId: String!) {
    ${TENANT_PREFIX}updateItemStatus(status: $status, id: $${TENANT_PREFIX}updateItemStatusId) {
      id
    }
  }
`;

export const CREATE_ITEM_VARIANT_TYPES = gql`
  mutation ${TENANT_PREFIX}createItemVariantTypes($itemVariantTypes: [${TENANT_PREFIX}ItemVariantTypeInput!]!) {
    ${TENANT_PREFIX}createItemVariantTypes(itemVariantTypes: $itemVariantTypes) {
      id
    }
  }
`;

export const DELETE_ITEM_VARIANT_TYPES = gql`
  mutation ${TENANT_PREFIX}deleteItemVariantTypesByItem($itemId: String!) {
    ${TENANT_PREFIX}deleteItemVariantTypesByItem(itemId: $itemId)
  }
`;

export const UPDATE_WORKFLOW_STATUS = gql`
  mutation ${TENANT_PREFIX}updateItemWorkflowStatus($status: ${TENANT_PREFIX}ItemStatusInput!, $${TENANT_PREFIX}updateItemWorkflowStatusId: String!) {
    ${TENANT_PREFIX}updateItemWorkflowStatus(status: $status, id: $${TENANT_PREFIX}updateItemWorkflowStatusId) {
      id
    }
  }
`;

export const CREATE_ITEM_TAG = gql`
  mutation ${TENANT_PREFIX}createItemTag($itemTag: ${TENANT_PREFIX}ItemTagInput!) {
    ${TENANT_PREFIX}createItemTag(itemTag: $itemTag) {
      id
      name
    }
  }
`;

export const UPDATE_ITEM_TAG = gql`
  mutation ${TENANT_PREFIX}updateItemTag($itemTag: ${TENANT_PREFIX}ItemTagInput!, $id: String!) {
    ${TENANT_PREFIX}updateItemTag(itemTag: $itemTag, id: $id) {
      id
      name
    }
  }
`;

export const DELETE_ITEM_TAG = gql`
  mutation ${TENANT_PREFIX}deleteItemTag($id: String!) {
    ${TENANT_PREFIX}deleteItemTag(id: $id)
  }
`;

export const GET_ITEM_TAGS = gql`
  query ${TENANT_PREFIX}itemTags($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemTags(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
    }
  }
`;

export const GET_ITEMS_CATALOGUE_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getItemsCatalogueUploadUrl($input: ${TENANT_PREFIX}PresignedUploadUrlInput!) {
    ${TENANT_PREFIX}getItemsCatalogueUploadUrl(input: $input) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;

export const ITEM_INVENTORY_FRAGMENT = gql`
  fragment ItemInventoryFragment on ${TENANT_PREFIX}WarehouseItem {
    id
    itemId
    begBalance
    debit
    credit
    stockOnHand
    minimumLevel
    safetyLevel
    stockValue
    warehouseId
    warehouse {
      id
      name
      code
    }
    item {
      id
      name
      itemCode
      description
      itemType
      productImage
      workflowStatus {
        name
        id
      }
    }
  }
`;

export const GET_ITEM_INVENTORY = gql`
  ${ITEM_INVENTORY_FRAGMENT}
  query ${TENANT_PREFIX}itemInventory($itemId: String!, $sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}warehouseItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...ItemInventoryFragment
    }
  }
`;

export const PAGINATED_ITEM_INVENTORY = gql`
  ${ITEM_INVENTORY_FRAGMENT}
  query ${TENANT_PREFIX}paginatedItemInventory($itemId: String!, $searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg!) {
    ${TENANT_PREFIX}paginatedWarehouseItems(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ItemInventoryFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
        hasNext
        hasPrevious
      }
    }
  }
`;
