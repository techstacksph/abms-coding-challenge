import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}DeliveryAndReturn`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DELIVERY_RETURN_FRAGMENT = gql`
  fragment DeliveryReturnsFragment on ${MODEL_NAME} {
    id
    drNo
    drDate
    drType
    drNotes
    relatedRecordType
    preferredPickupDateTime
    finalPickupDate
    finalPickupTime
    pickUpLocation
    wDeliveryFee
    deliveryFee
    wLatePickupFee
    latePickupFee
    returnDateTime
    pickupPhoto
    actualPickupDateTime
    pickupById
    pickupBy {
      id
      name
    }
    signature
    deliveredById
    deliveredBy {
      id
      name
    }
    deliveryDateTime
    deliveryPhoto
    geolocation
    franchisee {
      id
      name
      accountNumber
      accountType
      primaryContact {
        phone
        email
      }
    }
    franchiseeId
    customerId
    customer {
      id
      name
      accountNumber
      billingAddress
      bCountry {
        name
      }
    }
    customerId
    supplier {
      id
      name
      accountNumber
      accountType
      primaryContact {
        phone
        email
      }
    }
    supplierId
    contact {
      id
      fullName
      phone
      mobile
      email
      jobTitle
    }
    contactId
    site {
      id
      siteName
      address
      fullAddress
      lastActivity
    }
    siteId
    salesOrder {
      id
      soNo
      soDate
      orderType
    }
    salesOrderId
    purchaseOrder {
      id
      poNo
    }
    purchaseOrderId
    warehouse {
      id
      name
      code
    }
    warehouseId
    location {
      id
      name
      financeEmail
      billingAccountId
      billingAccount {
        id
        name
        legalName
        billingAddress
        primaryContact {
          phone
        }
      }
    }
    locationId
    status {
      id
      name
    }
    statusId
    recordOwner {
      id
      firstName
      lastName
      fullName
    }
    recordOwnerId
    totalDrQty
    totalRefQty
    totalAmount
  }

  ${BASE_FRAGMENT}
`;

// Optimized fragment for paginated list view - only includes fields actually used in table
export const DELIVERY_RETURN_LIST_FRAGMENT = gql`
  fragment DeliveryReturnsListFragment on ${MODEL_NAME} {
    id
    drNo
    drDate
    drType
    relatedRecordType
    franchiseeId
    franchisee {
      id
      name
      accountNumber
      accountType
    }
    customerId
    customer {
      id
      name
      accountNumber
    }
    supplierId
    supplier {
      id
      name
      accountNumber
      accountType
    }
    salesOrderId
    salesOrder {
      id
      soNo
    }
    purchaseOrderId
    purchaseOrder {
      id
      poNo
    }
    locationId
    location {
      id
      name
    }
    warehouse {
      id
      name
    }
    statusId
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_DELIVERY_RETURNS_OPTIMIZED = gql`
  ${DELIVERY_RETURN_LIST_FRAGMENT}
  query paginatedDeliveryReturnsOptimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDeliveryAndReturns(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DeliveryReturnsListFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_DELIVERY_RETURNS = gql`
  ${DELIVERY_RETURN_FRAGMENT}
  query ${TENANT_PREFIX}deliveryAndReturns($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deliveryAndReturns(sortArg: $sortArg, searchArg: $searchArg) {
      ...DeliveryReturnsFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DELIVERY_RETURN_ID = gql`
  query ${TENANT_PREFIX}deliveryAndReturns($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deliveryAndReturns(sortArg: $sortArg, searchArg: $searchArg) {
      id
      drNo
      status{
        id
        name
      }
    }
  }
`;

export const FIND_DELIVERY_RETURN_BY_ID = gql`
  ${DELIVERY_RETURN_FRAGMENT}
  query ${TENANT_PREFIX}findDeliveryAndReturnById($${TENANT_PREFIX}findDeliveryAndReturnByIdId: String!) {
    ${TENANT_PREFIX}findDeliveryAndReturnById(id: $${TENANT_PREFIX}findDeliveryAndReturnByIdId) {
      ...DeliveryReturnsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DELIVERY_RETURN = gql`
  ${DELIVERY_RETURN_FRAGMENT}
  mutation ${TENANT_PREFIX}createDeliveryAndReturn($deliveryAndReturn: ${TENANT_PREFIX}DeliveryAndReturnInput!) {
    ${TENANT_PREFIX}createDeliveryAndReturn(deliveryAndReturn: $deliveryAndReturn) {
      ...DeliveryReturnsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DELIVERY_RETURN = gql`
  ${DELIVERY_RETURN_FRAGMENT}
  mutation ${TENANT_PREFIX}updateDeliveryAndReturn($deliveryAndReturn: ${TENANT_PREFIX}DeliveryAndReturnInput!, $${TENANT_PREFIX}updateDeliveryAndReturnId: String!) {
    ${TENANT_PREFIX}updateDeliveryAndReturn(deliveryAndReturn: $deliveryAndReturn, id: $${TENANT_PREFIX}updateDeliveryAndReturnId) {
      ...DeliveryReturnsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_DELIVERY_RETURN = gql`
  mutation ${TENANT_PREFIX}deleteDeliveryAndReturn($${TENANT_PREFIX}deleteDeliveryAndReturnId: String!) {
    ${TENANT_PREFIX}deleteDeliveryAndReturn(id: $${TENANT_PREFIX}deleteDeliveryAndReturnId)
  }
`;

export const DELETE_DELIVERY_RETURNS = gql`
  mutation ${TENANT_PREFIX}deleteDeliveryAndReturns($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDeliveryAndReturns(ids: $ids)
  }
`;

export const UPDATE_DELIVERY_RETURN_STATUS = gql`
  mutation ${TENANT_PREFIX}updateDeliveryAndReturnStatus($id: String!, $statusId: String!, $statusNotes: String) {
    ${TENANT_PREFIX}updateDeliveryAndReturnStatus(id: $id, statusId: $statusId, statusNotes: $statusNotes) {
      id
      status {
        id
        name
      }
    }
  }
`;

// Dashboard query removed - will calculate counts from ALL query manually

export const SELECT_DELIVERY_RETURN = gql`
  query ${TENANT_PREFIX}deliveryAndReturns($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deliveryAndReturns(sortArg: $sortArg, searchArg: $searchArg) {
      id
      pickUpLocation
      purchaseOrder {
        id
        poNo
      }
      salesOrder {
        id
        soNo
      }
      salesOrderItems {
        id
      }
      drNo
      createdAt
      updatedAt
    }
  }
`;

export const FIND_BILLING_ACCOUNT_BY_ID = gql`
  query ${TENANT_PREFIX}findAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      id
      name
      legalName
      billingAddress
      bStreetAddress
      bSuburb
      bCity
      bRegion
      bPostalCode
      gst
      primaryContact {
        phone
      }
      bCountry {
        name
      }
    }
  }
`;

export const FIND_CUSTOMER_BILLING_ACCOUNT_BY_ID = gql`
  query ${TENANT_PREFIX}findCustomerAccountById($${TENANT_PREFIX}findAccountByIdId: String!) {
    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      id
      name
      legalName
      billingAddress
      bStreetAddress
      bSuburb
      bPostalCode
      gst
      primaryContact {
        phone
      }
      bCountry {
        name
      }
    }
  }
`;
