import { gql } from '@apollo/client';
import { MODULE_CODE } from '@/views/franchisee-management/recruitment/common/constants';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

// import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Recruitment`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

const RECRUITMENT_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment RecruitmentFragment on ${MODEL_NAME} {
      id
      lastActivity
      lastActivityDate
      contact {
        id
        fullName
        companies {
          companyName  
        }
      }
      recordOwner {
        id
        name
      }
      location {
        id
        name
        fullAddress
      }
      rating
      recruitmentNo
      status {
        name
      }
      ...BaseFragment
    }
`;

const RECRUITMENT_BY_ID_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment RecruitmentFragment on ${MODEL_NAME} {
      id
      lastActivity
      lastActivityDate
      contact {
        id
        fullName
        phone
        mobile
        email
        jobTitle
        companies {
          companyName
        }
      }
      recordOwner {
        id
        name
      }
      location {
        id
        name
      }
      rating
      recruitmentNo
      salesPrice
      date
      type
      franchiseeType
      notes
      companyName
      tradingName
      status {
        id
        name
      }
      source {
        id
        name
      }
      account {
        id
        name
      }
      recruitmentServiceTypes {
        id
        serviceType {
          id
          servicetype
        }
      }
      agreement {
        id
        agreementNo
      }
      answers {
        id
        answer
        questionnaire {
          id
        }
        question {
          id
          name
          type
        }
      }
      ...BaseFragment
    }
`;

export const ALL_RECRUITMENTS = gql`
  ${RECRUITMENT_FRAGMENT}
  query ${TENANT_PREFIX}Recruitment($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}Recruitment(sortArg: $sortArg, searchArg: $searchArg) {
      ...RecruitmentFragment
    }
  }
`;

export const ALL_RECRUITMENTS_IDS = gql`
  query ${TENANT_PREFIX}Recruitment($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}Recruitment(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const PAGINATED_RECRUITMENTS = gql`
  ${RECRUITMENT_FRAGMENT}
  query ${TENANT_PREFIX}paginatedRecruitments($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedRecruitments(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...RecruitmentFragment
      }
      pageInfo {
        count
        pageCount
        pageSize
        skip
        take
      }
    }
  }
`;

export const RECRUITMENT_STATUS = gql`
  query ${TENANT_PREFIX}getModuleWorkflowStatus{
    ${TENANT_PREFIX}getModuleWorkflowStatus(code: "${MODULE_CODE}") {
      id
      name  
    }
}`;

export const FIND_RECRUITMENT_BY_ID = gql`
  ${RECRUITMENT_BY_ID_FRAGMENT}
  query ${TENANT_PREFIX}findRecruitmentById($${TENANT_PREFIX}findRecruitmentByIdId: String!) {
    ${TENANT_PREFIX}findRecruitmentById(id: $${TENANT_PREFIX}findRecruitmentByIdId) {
      ...RecruitmentFragment
    }
  }
`;

export const DELETE_RECRUITMENT_BY_IDS = gql`
  mutation ${TENANT_PREFIX}deleteRecruitments($ids: [String!]!) {
    ${TENANT_PREFIX}deleteRecruitments(ids: $ids)
  }
`;

export const DELETE_RECRUITMENT_BY_ID = gql`
  mutation ${TENANT_PREFIX}deleteRecruitment($id: String!) {
    ${TENANT_PREFIX}deleteRecruitment(id: $id)
  }
`;

export const RECRUITMENT_DASHBOARD = gql`
  query ${TENANT_PREFIX}recruitmentDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}recruitmentDashboard(dashboardArg: $dashboardArg) {
      allRecruitments
      newRecruitments
      potentialRecruitments
      qualifiedRecruitments
      unqualifiedRecruitments
    }
  }
`;

export const UPDATE_RECRUITMENT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateRecruitmentStatus(
    $status: ${TENANT_PREFIX}RecruitmentStatusInput!,
    $${TENANT_PREFIX}updateRecruitmentStatusId: String!) {
    ${TENANT_PREFIX}updateRecruitmentStatus(status: $status, id: $${TENANT_PREFIX}updateRecruitmentStatusId) {
      id
    }
  }
`;

export const CREATE_RECRUITMENT = gql`
  mutation ${TENANT_PREFIX}createRecruitment($recruitment: ${TENANT_PREFIX}RecruitmentInput!) {
    ${TENANT_PREFIX}createRecruitment(recruitment: $recruitment) {
      id
      recruitmentNo
    }
  }
`;

export const UPDATE_RECRUITMENT = gql`
  mutation ${TENANT_PREFIX}updateRecruitment(
    $${TENANT_PREFIX}updateRecruitmentId: String!,
    $recruitment: ${TENANT_PREFIX}RecruitmentInput!
  ) {
    ${TENANT_PREFIX}updateRecruitment(id: $${TENANT_PREFIX}updateRecruitmentId, recruitment: $recruitment) {
      id
      recruitmentNo
    }
  }
`;

export const GET_RECRUITMENT_CSV = gql`
  query ${TENANT_PREFIX}RecruitmentCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}RecruitmentCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
