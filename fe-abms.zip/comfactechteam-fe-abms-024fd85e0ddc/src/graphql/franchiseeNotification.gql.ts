import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}FranchiseeNotification`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FRANCHISEE_NOTIFICATION_FRAGMENT = gql`
  fragment FranchiseeNotificationFragment on ${MODEL_NAME} {
    id
    subject
    subjectLower
    message
    locationId
    sendSMS
    commId
    commType
    sentDateTime
    location {
      id
      name
    }
    recipients {
      franchisee {
        id
        name
        primaryContact {
          email
          uploadPhoto
          mobile 
          phone
          fullName
        }
      }
    }
    status {
      id
      name
    }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_FRANSHISEE_NOTIFICATIONS = gql`
  ${FRANCHISEE_NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}franchiseeNotifications($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}franchiseeNotifications(sortArg: $sortArg, searchArg: $searchArg) {
      recipientNames
      ...FranchiseeNotificationFragment
      ...BaseFragment
    }
  }
`;

export const ALL_FRANCHISEE_NOTIFICATION_IDS = gql`
  query ${TENANT_PREFIX}franchiseeNotificationIds(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}franchiseeNotifications(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const PAGINATED_FRANCHISEE_NOTIFICATIONS = gql`
  ${FRANCHISEE_NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedFranchiseeNotifications($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFranchiseeNotifications(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FranchiseeNotificationFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const FIND_FRANCHISEE_NOTIFICATION_BY_ID = gql`
  ${FRANCHISEE_NOTIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}findFranchiseeNotificationById($${TENANT_PREFIX}findFranchiseeNotificationByIdId: String!) {
    ${TENANT_PREFIX}findFranchiseeNotificationById(id: $${TENANT_PREFIX}findFranchiseeNotificationByIdId) {
      ...FranchiseeNotificationFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_FRANCHISEE_NOTIFICATION = gql`
  ${FRANCHISEE_NOTIFICATION_FRAGMENT}
  mutation createFranchiseeNotification($franchiseeNotification: ${TENANT_PREFIX}FranchiseeNotificationInput!) {
    ${TENANT_PREFIX}createFranchiseeNotification(franchiseeNotification: $franchiseeNotification) {
      ...FranchiseeNotificationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_NOTIFICATION_BY_ID = gql`
  ${FRANCHISEE_NOTIFICATION_FRAGMENT}
  mutation updateFranchiseeNotification($franchiseeNotification: ${TENANT_PREFIX}FranchiseeNotificationInput!, $${TENANT_PREFIX}updateFranchiseeNotificationId: String!) {
    ${TENANT_PREFIX}updateFranchiseeNotification(franchiseeNotification: $franchiseeNotification, id: $${TENANT_PREFIX}updateFranchiseeNotificationId) {
      ...FranchiseeNotificationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_NOTIFICATION_STATUS = gql`
  mutation ${TENANT_PREFIX}updateFranchiseeNotificationStatus($${TENANT_PREFIX}updateFranchiseeNotificationStatusId: String!, $status: String!) {
    ${TENANT_PREFIX}updateFranchiseeNotificationStatus(id: $${TENANT_PREFIX}updateFranchiseeNotificationStatusId, status: $status) {
      id
    }
  }
`;

export const DELETE_FRANCHISEE_NOTIFICATION = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeNotification($${TENANT_PREFIX}deleteFranchiseeNotificationId: String!) {
    ${TENANT_PREFIX}deleteFranchiseeNotification(id: $${TENANT_PREFIX}deleteFranchiseeNotificationId)
  } 
`;

export const DELETE_FRANCHISEE_NOTIFICATIONS = gql`
  mutation deleteFranchiseeNotifications($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFranchiseeNotifications(ids: $ids)
  }
`;

export const GET_FRANCHISEE_NOTIFICATIONS_CSV = gql`
  query ${TENANT_PREFIX}franchiseeNotificationCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}franchiseeNotificationCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
