import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const GET_PRESIGNED_URL = gql`
  query ${TENANT_PREFIX}getPresignedUploadUrl($input: ${TENANT_PREFIX}PresignedUploadUrlInput!) {
    ${TENANT_PREFIX}getPresignedUploadUrl(input: $input) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;

export const GET_DOCUMENT_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getDocumentUploadUrl(
    $fileName: String!
    $fileNumber: Float!
    $contentType: String
    $fileSize: Float
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getDocumentUploadUrl(
      fileName: $fileName
      fileNumber: $fileNumber
      contentType: $contentType
      fileSize: $fileSize
      expiresIn: $expiresIn
    ) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;

export const GET_DOCUMENT_UPLOAD_URLS = gql`
  query ${TENANT_PREFIX}getDocumentUploadUrls(
    $files: [${TENANT_PREFIX}DocumentUploadFileInput!]!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getDocumentUploadUrls(files: $files, expiresIn: $expiresIn) {
      fileNumber
      uploadUrl
      s3Key
      s3Url
      expiresIn
      fileName
    }
  }
`;

export const GET_DOCUMENT_DOWNLOAD_URL = gql`
  query ${TENANT_PREFIX}getDocumentDownloadUrl(
    $documentId: String!
    $fileNumber: Float!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getDocumentDownloadUrl(
      documentId: $documentId
      fileNumber: $fileNumber
      expiresIn: $expiresIn
    )
  }
`;
