import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CreditBureau`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CREDIT_BUREAU_FRAGMENT = gql`
  fragment CreditBureauFragment on ${MODEL_NAME} {
    id
    legalName
    tradingName
    businessType
    businessNumber
    dateOfInc
    noOfEmployees
    companyNumber
    creditBureauNo
    accountCode
    regFindAddress
    bilFindAddress
    dirFirstName
    dirLastName
    dirEmail
    dirMobile
    dirPhone
    dirFindAddress
    bilFirstName
    bilLastName
    bilJobTitle
    bilEmail
    bilMobile
    bilPhone
    companyName1
    contactName1
    traEmail1
    traPhone1
    companyName2
    contactName2
    traEmail2
    traPhone2
    companyName3
    contactName3
    traEmail3
    traPhone3
    name
    sigJobTitle
    sigEmail
    signature
    regLongtitude
    regLatitude
    regPlaceId
    bilLongtitude
    bilLatitude
    bilPlaceId
    dirLongtitude
    dirLatitude
    dirPlaceId
    status{
      id
      name
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_CREDIT_BUREAU = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  query ${TENANT_PREFIX}paginatedCreditBureaus($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCreditBureaus(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CreditBureauFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CREDIT_BUREAU = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  query ${TENANT_PREFIX}creditBureaus($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}creditBureaus(sortArg: $sortArg, searchArg: $searchArg) {
      ...CreditBureauFragment
      ...BaseFragment
    }
  }
`;

export const FIND_CREDIT_BUREAU_BY_ID = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  query ${TENANT_PREFIX}findCreditBureauById($${TENANT_PREFIX}findCreditBureauByIdId: String!) {
    ${TENANT_PREFIX}findCreditBureauById(id: $${TENANT_PREFIX}findCreditBureauByIdId) {
      ...CreditBureauFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CREDIT_BUREAU_BY_ID = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCreditBureau($creditBureau: ${TENANT_PREFIX}CreditBureauInput!, $${TENANT_PREFIX}updateCreditBureauId: String!) {
    ${TENANT_PREFIX}updateCreditBureau(creditBureau: $creditBureau, id: $${TENANT_PREFIX}updateCreditBureauId) {
      ...CreditBureauFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CREDIT_BUREAU_STATUS = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCreditBureauStatus($${TENANT_PREFIX}updateCreditBureauStatusId: String!, $status: ${TENANT_PREFIX}CreditBureauStatusInput!) {
    ${TENANT_PREFIX}updateCreditBureauStatus(id: $${TENANT_PREFIX}updateCreditBureauStatusId, status: $status) {
      ...CreditBureauFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CREDIT_BUREAU = gql`
  ${CREDIT_BUREAU_FRAGMENT}
  mutation ${TENANT_PREFIX}createCreditBureau($creditBureau: ${TENANT_PREFIX}CreditBureauInput!) {
    ${TENANT_PREFIX}createCreditBureau(creditBureau: $creditBureau) {
      ...CreditBureauFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CREDIT_BUREAU = gql`
  mutation ${TENANT_PREFIX}deleteCreditBureau($${TENANT_PREFIX}deleteCreditBureauId: String!) {
    ${TENANT_PREFIX}deleteCreditBureau(id: $${TENANT_PREFIX}deleteCreditBureauId)
  }
`;

export const DELETE_CREDIT_BUREAUS = gql`
  mutation ${TENANT_PREFIX}deleteCreditBureaus($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCreditBureaus(ids: $ids)
  }
`;

export const GET_CREDIT_BUREAU_CSV = gql`
  query ${TENANT_PREFIX}CreditBureauCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}CreditBureauCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const ALL_CREDIT_BUREAU_IDS = gql`
  query ${TENANT_PREFIX}creditBureaus($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}creditBureaus(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;
