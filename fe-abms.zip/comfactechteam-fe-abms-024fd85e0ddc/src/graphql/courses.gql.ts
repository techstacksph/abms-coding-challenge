/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Course`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const COURSE_FRAGMENT = gql`
  fragment CourseFragment on ${MODEL_NAME} {
    id
    course
    code
    description
  }
  ${BASE_FRAGMENT}
`;

// Get Paginated Courses Query
export const PAGINATED_COURSES = gql`
  ${COURSE_FRAGMENT}
  query PaginatedCourses($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCourses(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CourseFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Get All Courses Query
export const ALL_COURSES = gql`
  ${COURSE_FRAGMENT}
  query ${TENANT_PREFIX}courses($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}courses(searchArg: $searchArg, sortArg: $sortArg) {
      ...CourseFragment
      ...BaseFragment
    }
  }
`;

export const ALL_COURSE_IDS = gql`
  query ${TENANT_PREFIX}courses($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}courses(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const ALL_COURSES_ID = gql`
  query ${TENANT_PREFIX}coursesIds($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}courses(searchArg: $searchArg, sortArg: $sortArg) {
      id
      course
      code
    }
  }
`;

export const SELECT_COURSES = gql`
  query courses {
      ${TENANT_PREFIX}courses {
        id
        course
        code
      }
    }
`;

// Find Course By ID Query
export const FIND_COURSE_BY_ID = gql`
  ${COURSE_FRAGMENT}
  query findCourseById($id: String!) {
    ${TENANT_PREFIX}findCourseById(id: $id) {
      ...CourseFragment
      ...BaseFragment
    }
  }
`;

// Create Course Mutation
export const CREATE_COURSE = gql`
  ${COURSE_FRAGMENT}
  mutation createCourse($input: ${TENANT_PREFIX}CourseInput!) {
    ${TENANT_PREFIX}createCourse(course: $input) {
      ...CourseFragment
      ...BaseFragment
    }
  }
`;

// Update Course Mutation
export const UPDATE_COURSE_BY_ID = gql`
  ${COURSE_FRAGMENT}
  mutation updateCourse($input: ${TENANT_PREFIX}CourseInput!, $id: String!) {
    ${TENANT_PREFIX}updateCourse(course: $input, id: $id) {
      ...CourseFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_COURSE = gql`
  mutation deleteCourse($id: String!) {
    ${TENANT_PREFIX}deleteCourse(id: $id)
  }
`;

export const DELETE_COURSES = gql`
  mutation deleteCourses($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCourses(ids: $ids)
  }
`;

export const COURSES_CSV = gql`
  query ${TENANT_PREFIX}CourseCSV(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}CourseCSV(
      searchArg: $searchArg
      columnArg: $columnArg
      sortArg: $sortArg
    )
  }
`;
