/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'InvoiceTemplate';
const TITLE_SMALL = 'invoiceTemplate';
const TITLE_FRAGMENT = 'InvoiceTemplateFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_INVOICE_TEMPLATES_TITLE = 'paginatedInvoiceTemplates';

export const INVOICE_TEMPLATE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    reference
    invoiceTemplateNo
    date
    invoiceDate
    due
    repeat
    thisTransactionEvery
    endDate
    generationDate
    subtotal
    gstAmount
    gstType
    totalAmount
    type
    subType
    status {
      id
      name
    }
    notes
    account {
      id
      name
      accountType
      pStreetAddress
      physicalAddress
    }
    billingAccount {
      id
      name
      
    }

    invoiceTemplateContacts {
      id
      contact {
        id
        fullName
        firstName
        lastName
      }
    }
    invoiceTemplateDetails {
      id
      billTemplate {
        id
        billTemplateNo
      }
      description
      qty
      unitPrice
      lineAmount
      commissionAmount
      commissionType
      bci
      dontmerge
      job {
        id
        jobNo
      }
      item {
        id
        name
      }
      accountCode {
        id
        accountCode
      }
      serviceProvider {
        id
        name
      }
    }
    jobs {
      id
      jobNo
    }
    location {
      id
      name
    }
    invoices {
      id
    }
    xero {
      id
      xeroAccount
    }
    orgId
    recordLocked
    lockedBy
    timeLocked
  }
  ${BASE_FRAGMENT}
`;

export const ALL_INVOICE_TEMPLATES = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const PAGINATED_INVOICE_TEMPLATES = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  query ${PAGINATED_INVOICE_TEMPLATES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_INVOICE_TEMPLATES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_INVOICE_TEMPLATE_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_INVOICE_TEMPLATE_BY_ID = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ById: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ById) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_INVOICE_TEMPLATE = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_INVOICE_TEMPLATE = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_INVOICE_TEMPLATE = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_INVOICE_TEMPLATES = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const UPDATE_INVOICE_TEMPLATE_STATUS = gql`
  mutation ${TENANT_PREFIX}update${TITLE}Status($status: String!, $id: String!) {
    ${TENANT_PREFIX}update${TITLE}Status(status: $status, id: $id) {
      id
    }
  }
`;

export const GET_INVOICE_TEMPLATE_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}Dashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}Dashboard(dashboardArg: $dashboardArg) {
      all
      active
      inactive
    }
  }
`;

export const UPDATE_INVOICE_TEMPLATE_TOTALS = gql`
  ${INVOICE_TEMPLATE_FRAGMENT}
  mutation update${TITLE}Totals($id: String!, $totals: ${TENANT_PREFIX}${TITLE}TotalInput!) {
    ${TENANT_PREFIX}update${TITLE}Totals(id: $id, totals: $totals) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const FORCE_GENERATE_INVOICE = gql`
  mutation ${TENANT_PREFIX}forceGenerateInvoice($invoiceTemplateId: String!) {
    ${TENANT_PREFIX}forceGenerateInvoice(invoiceTemplateId: $invoiceTemplateId) {
      id
      invoiceNo
    }
  }
`;

export const GET_INVOICE_TEMPLATE_CSV = gql`
  query ${TENANT_PREFIX}InvoiceTemplateCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}InvoiceTemplateCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
