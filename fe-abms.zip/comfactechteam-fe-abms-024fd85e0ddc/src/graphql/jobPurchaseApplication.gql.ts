import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

/**
 * Public query to get questionnaire questions for Job Purchase Application
 * Returns the questionnaire with type RECRUITMENT_LOCAL including all questions and options
 */
export const PUBLIC_GET_JOB_PURCHASE_APPLICATION_QUESTIONS = gql`
  query ${TENANT_PREFIX}publicGetJobPurchaseApplicationQuestions {
    ${TENANT_PREFIX}publicGetJobPurchaseApplicationQuestions {
      id
      questionnaire
      description
      type
      questions {
        id
        name
        description
        type
        numAnswers
        options {
          id
          name
        }
      }
      status {
        id
        name
      }
    }
  }
`;

/**
 * Public mutation to create a Job Purchase Application
 * This creates both Contact and Recruitment records in a single call
 * Used by the public franchisee application form
 */
export const PUBLIC_CREATE_JOB_PURCHASE_APPLICATION = gql`
  mutation ${TENANT_PREFIX}publicCreateJobPurchaseApplication(
    $jobPurchaseApplication: ${TENANT_PREFIX}JobPurchaseApplicationInput!
  ) {
    ${TENANT_PREFIX}publicCreateJobPurchaseApplication(
      jobPurchaseApplication: $jobPurchaseApplication
    ) {
      contact {
        id
        firstName
        lastName
        email
        mobile
        phone
      }
      recruitment {
        id
        recruitmentNo
        tradingName
        companyName
        date
        location {
          id
          name
        }
        status {
          id
          name
        }
        answers {
          id
          answer
          question {
            id
            name
          }
          questionnaire {
            id
          }
        }
      }
    }
  }
`;

/**
 * Public query to get locations for the application form dropdown
 */
export const PUBLIC_LOCATIONS = gql`
  query ${TENANT_PREFIX}publicLocations(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}publicLocations(searchArg: $searchArg, sortArg: $sortArg) {
      id
      name
    }
  }
`;

/**
 * Public query to get paginated locations
 */
export const PUBLIC_PAGINATED_LOCATIONS = gql`
  query ${TENANT_PREFIX}publicPaginatedLocations(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $pageArg: ${TENANT_PREFIX}PageArg
  ) {
    ${TENANT_PREFIX}publicPaginatedLocations(
      searchArg: $searchArg
      pageArg: $pageArg
    ) {
      data {
        id
        name
      }
      pageInfo {
        count
        pageCount
        pageSize
        skip
        take
      }
    }
  }
`;

/**
 * Public query to get areas for the application form dropdown
 */
export const PUBLIC_AREAS = gql`
  query ${TENANT_PREFIX}publicAreas(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}publicAreas(searchArg: $searchArg, sortArg: $sortArg) {
      id
      area
    }
  }
`;

/**
 * Public query to get countries for the application form dropdown
 */
export const PUBLIC_COUNTRIES = gql`
  query ${TENANT_PREFIX}publicCountries(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}publicCountries(searchArg: $searchArg, sortArg: $sortArg) {
      id
      name
      code
    }
  }
`;
