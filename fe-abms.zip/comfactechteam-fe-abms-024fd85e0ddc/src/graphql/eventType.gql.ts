import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}EventType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const EVENT_TYPE_FRAGMENT = gql`
  fragment EventTypeFragment on ${MODEL_NAME} {
    id
    code
    description
    name
    events {
      id
      subject
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_EVENT_TYPES = gql`
  ${EVENT_TYPE_FRAGMENT}
  query paginatedEventTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedEventTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...EventTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_EVENT_TYPES = gql`
  query ${TENANT_PREFIX}eventTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}eventTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      code
      description
      updatedAt
      updatedBy
    }
  }
`;

export const ALL_EVENT_TYPES_IDS = gql`
  query ${TENANT_PREFIX}eventTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}eventTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_EVENT_TYPE_BY_ID = gql`
  ${EVENT_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}findEventTypeById($${TENANT_PREFIX}findEventTypeByIdId: String!) {
    ${TENANT_PREFIX}findEventTypeById(id: $${TENANT_PREFIX}findEventTypeByIdId) {
      ...EventTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_EVENT_TYPE = gql`
  ${EVENT_TYPE_FRAGMENT}
  mutation createEventType($eventType: ${TENANT_PREFIX}EventTypeInput!) {
    ${TENANT_PREFIX}createEventType(eventType: $eventType) {
      ...EventTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_EVENT_TYPE_BY_ID = gql`
  ${EVENT_TYPE_FRAGMENT}
  mutation updateEventType($eventType: ${TENANT_PREFIX}EventTypeInput!, $${TENANT_PREFIX}updateEventTypeId: String!) {
    ${TENANT_PREFIX}updateEventType(eventType: $eventType, id: $${TENANT_PREFIX}updateEventTypeId) {
      ...EventTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_EVENT_TYPE = gql`
  mutation ${TENANT_PREFIX}deleteEventType($${TENANT_PREFIX}deleteEventTypeId: String!) {
    ${TENANT_PREFIX}deleteEventType(id: $${TENANT_PREFIX}deleteEventTypeId)
  } 
`;

export const DELETE_EVENT_TYPES = gql`
  mutation deleteEventTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEventTypes(ids: $ids)
  }
`;

export const GET_EVENT_TYPES_CSV = gql`
  query ${TENANT_PREFIX}eventTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}eventTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
