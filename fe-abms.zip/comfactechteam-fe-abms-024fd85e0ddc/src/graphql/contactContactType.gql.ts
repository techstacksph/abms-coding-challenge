import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ContactContactType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CONTACT_CONTACT_TYPE_FRAGMENT = gql`
  fragment ContactContactTypeFragment on ${MODEL_NAME} {
    id
    contactType {
      id
      name
    }
    contact {
      id
      firstName
      lastName
      statusId
    }
  }
  ${BASE_FRAGMENT}
`;

export const CREATE_CONTACT_CONTACT_TYPE = gql`
  ${CONTACT_CONTACT_TYPE_FRAGMENT}
  mutation ${TENANT_PREFIX}createContactContactType($contactContactType: ${TENANT_PREFIX}ContactContactTypeInput!) {
    ${TENANT_PREFIX}createContactContactType(contactContactType: $contactContactType) {
      ...ContactContactTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CONTACT_CONTACT_TYPES = gql`
  ${CONTACT_CONTACT_TYPE_FRAGMENT}
  mutation ${TENANT_PREFIX}createContactContactTypes($contactContactTypes: [${TENANT_PREFIX}ContactContactTypeInput!]!) {
    ${TENANT_PREFIX}createContactContactTypes(contactContactTypes: $contactContactTypes) {
      ...ContactContactTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CONTACT_CONTACT_TYPES = gql`
  mutation ${TENANT_PREFIX}deleteContactContactTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteContactContactTypes(ids: $ids)
  }
`;
