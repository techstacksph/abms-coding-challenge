/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PaymentTerm`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PAYMENT_TERM_FRAGMENT = gql`
  fragment PaymentTermFragment on ${MODEL_NAME} {
    id
    code
    paymentTerm
    description
    createdByName
    updatedByName
  }
  ${BASE_FRAGMENT}
`;

// Get Paginated Payment Terms Query
export const PAGINATED_PAYMENT_TERMS = gql`
  ${PAYMENT_TERM_FRAGMENT}
  query PaginatedPaymentTerms($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPaymentTerm(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PaymentTermFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Get All Payment Terms Query
export const ALL_PAYMENT_TERMS = gql`
  ${PAYMENT_TERM_FRAGMENT}
  query ${TENANT_PREFIX}paymentTerms($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}paymentTerms(searchArg: $searchArg, sortArg: $sortArg) {
      ...PaymentTermFragment
      ...BaseFragment
    }
  }
`;

export const ALL_PAYMENT_IDS = gql`
  ${PAYMENT_TERM_FRAGMENT}
  query ${TENANT_PREFIX}paymentTerms($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}paymentTerms(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const ALL_PAYMENT_TERMS_ID = gql`
  query ${TENANT_PREFIX}paymentTermsIds($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}paymentTerms(searchArg: $searchArg, sortArg: $sortArg) {
      id
      paymentTerm
      code
    }
  }
`;

export const SELECT_PAYMENT_TERMS = gql`
  query paymentTerms {
      ${TENANT_PREFIX}paymentTerms {
        id
        paymentTerm
        code
      }
    }
`;

// Find Payment Term By ID Query
export const FIND_PAYMENT_TERM_BY_ID = gql`
  ${PAYMENT_TERM_FRAGMENT}
  query findPaymentTermById($id: String!) {
    ${TENANT_PREFIX}findPaymentTermById(id: $id) {
      ...PaymentTermFragment
      ...BaseFragment
    }
  }
`;

// Create Payment Term Mutation
export const CREATE_PAYMENT_TERM = gql`
  ${PAYMENT_TERM_FRAGMENT}
  mutation createPaymentTerm($input: ${TENANT_PREFIX}PaymentTermInput!) {
    ${TENANT_PREFIX}createPaymentTerm(paymentTerm: $input) {
      ...PaymentTermFragment
      ...BaseFragment
    }
  }
`;

// Update Payment Term Mutation
export const UPDATE_PAYMENT_TERM_BY_ID = gql`
  ${PAYMENT_TERM_FRAGMENT}
  mutation updatePaymentTerm($input: ${TENANT_PREFIX}PaymentTermInput!, $id: String!) {
    ${TENANT_PREFIX}updatePaymentTerm(paymentTerm: $input, id: $id) {
      ...PaymentTermFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_PAYMENT_TERM = gql`
  mutation deletePaymentTerm($id: String!) {
    ${TENANT_PREFIX}deletePaymentTerm(id: $id)
  }
`;

export const DELETE_PAYMENT_TERMS = gql`
  mutation deletePaymentTerms($ids: [String!]!) {
    ${TENANT_PREFIX}deletePaymentTerms(ids: $ids)
  }
`;

export const PAYMENT_TERMS_CSV = gql`
  query ${TENANT_PREFIX}PaymentTermCSV(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}PaymentTermCSV(
      searchArg: $searchArg
      columnArg: $columnArg
      sortArg: $sortArg
    )
  }
`;
