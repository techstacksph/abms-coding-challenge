import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}JobProcessing`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const JOB_PROCESSING_FRAGMENT = gql`
  fragment JobProcessingFragment on ${MODEL_NAME} {
    id
    batchJobTransfer{
      id
      transferNo
    }
    job{
      id
      jobNo
    }
    account{
      id
      name
    }
    site{
      id
      siteName
      streetAddress
      suburb
      city
      region
      postalCode
      country{
        id
        name
      }
    }
    jobSchedules
    status{
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_JOB_PROCESSING = gql`
  ${JOB_PROCESSING_FRAGMENT}
  query paginatedJobProcessings($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedJobProcessings(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobProcessingFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_JOB_PROCESSINGS = gql`
  ${JOB_PROCESSING_FRAGMENT}
  query ${TENANT_PREFIX}jobProcessings($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobProcessings(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobProcessingFragment
      ...BaseFragment
    }
  }
`;

export const ALL_JOB_PROCESSINGS_IDS = gql`
  query ${TENANT_PREFIX}jobProcessings($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobProcessings(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_JOB_PROCESSING_BY_ID = gql`
  ${JOB_PROCESSING_FRAGMENT}
  query findJobProcessingById($${TENANT_PREFIX}findJobProcessingByIdId: String!) {
    ${TENANT_PREFIX}findJobProcessingById(id: $${TENANT_PREFIX}findJobProcessingByIdId) {
      ...JobProcessingFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_JOB_PROCESSING_BY_ID = gql`
  ${JOB_PROCESSING_FRAGMENT}
  mutation updateJobProcessing($jobProcessing: ${TENANT_PREFIX}JobProcessingInput!, $${TENANT_PREFIX}updateJobProcessingId: String!) {
    ${TENANT_PREFIX}updateJobProcessing(jobProcessing: $jobProcessing, id: $${TENANT_PREFIX}updateJobProcessingId) {
      ...JobProcessingFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_JOB_PROCESSING = gql`
  ${JOB_PROCESSING_FRAGMENT}
  mutation createJobProcessing($jobProcessing: ${TENANT_PREFIX}JobProcessingInput!) {
    ${TENANT_PREFIX}createJobProcessing(jobProcessing: $jobProcessing) {
      ...JobProcessingFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_JOB_PROCESSING = gql`
  mutation deleteJobProcessing($${TENANT_PREFIX}deleteJobProcessingById: String!) {
    ${TENANT_PREFIX}deleteJobProcessing(id: $${TENANT_PREFIX}deleteJobProcessingById)
  }
`;

export const DELETE_JOB_PROCESSINGS = gql`
  mutation deleteJobProcessings($ids: [String!]!) {
    ${TENANT_PREFIX}deleteJobProcessings(ids: $ids)
  }
`;
