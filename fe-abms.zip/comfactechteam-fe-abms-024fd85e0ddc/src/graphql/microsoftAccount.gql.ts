import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}MicrosoftAccount`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const MICROSOFT_ACCOUNT_FRAGMENT = gql`
  fragment MicrosoftAccountFragment on ${MODEL_NAME} {
    accessToken
    calendarDeltaToken
    createdAt
    createdBy
    createdByName
    deletedAt
    deletedBy
    email
    id
    lastCalendarSync
    lockedBy
    microsoftAccount
    orgId
    permissionScopes
    purpose
    recordLocked
    refreshToken
    timeLocked
    token
    tokenExpirationDate
    updatedAt
    updatedBy
    updatedByName
    user {
      id
      firstName
      lastName
      userName
      email
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_MICROSOFT_ACCOUNTS = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}microsoftAccounts($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}microsoftAccounts(searchArg: $searchArg, sortArg: $sortArg) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const ALL_MICROSOFT_ACCOUNTS_IDS = gql`
  query ${TENANT_PREFIX}microsoftAccountsIds($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}microsoftAccounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      microsoftAccount
    }
  }
`;

export const PAGINATED_MICROSOFT_ACCOUNTS = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}paginatedMicrosoftAccounts($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedMicrosoftAccounts(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...MicrosoftAccountFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
      sort {
        field
        direction
      }
    }
  }
`;

export const FIND_MICROSOFT_ACCOUNT_BY_ID = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  query ${TENANT_PREFIX}findMicrosoftAccountById($${TENANT_PREFIX}findMicrosoftAccountByIdId: String!) {
    ${TENANT_PREFIX}findMicrosoftAccountById(id: $${TENANT_PREFIX}findMicrosoftAccountByIdId) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_MICROSOFT_ACCOUNT = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}createMicrosoftAccount($microsoftAccount: ${TENANT_PREFIX}MicrosoftAccountInput!) {
    ${TENANT_PREFIX}createMicrosoftAccount(microsoftAccount: $microsoftAccount) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_MICROSOFT_ACCOUNT = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}updateMicrosoftAccount($id: String!, $microsoftAccount: ${TENANT_PREFIX}MicrosoftAccountInput!) {
    ${TENANT_PREFIX}updateMicrosoftAccount(id: $id, microsoftAccount: $microsoftAccount) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_MICROSOFT_ACCOUNT = gql`
  mutation ${TENANT_PREFIX}deleteMicrosoftAccount($id: String!) {
    ${TENANT_PREFIX}deleteMicrosoftAccount(id: $id)
  }
`;

export const DELETE_MICROSOFT_ACCOUNTS = gql`
  mutation ${TENANT_PREFIX}deleteMicrosoftAccounts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteMicrosoftAccounts(ids: $ids)
  }
`;

export const CONNECT_MICROSOFT_ACCOUNT_OAUTH = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}connectMicrosoftAccountOAuth(
    $code: String!
    $tenantId: String!
    $clientId: String!
    $clientSecret: String!
    $redirectUri: String!
    $userId: String!
    $orgId: String!
    $purpose: String
    $permissionScopes: [String!]
  ) {
    ${TENANT_PREFIX}connectMicrosoftAccountOAuth(
      code: $code
      tenantId: $tenantId
      clientId: $clientId
      clientSecret: $clientSecret
      redirectUri: $redirectUri
      userId: $userId
      orgId: $orgId
      purpose: $purpose
      permissionScopes: $permissionScopes
    ) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const FORCE_REFRESH_MICROSOFT_ACCOUNT = gql`
  ${MICROSOFT_ACCOUNT_FRAGMENT}
  mutation ${TENANT_PREFIX}forceRefreshMicrosoftAccount($id: String!) {
    ${TENANT_PREFIX}forceRefreshMicrosoftAccount(id: $id) {
      ...MicrosoftAccountFragment
      ...BaseFragment
    }
  }
`;

export const CLEAR_OUTLOOK_EVENTS = gql`
  mutation ${TENANT_PREFIX}clearOutlookEvents($microsoftAccountId: String!) {
    ${TENANT_PREFIX}clearOutlookEvents(microsoftAccountId: $microsoftAccountId)
  }
`;
