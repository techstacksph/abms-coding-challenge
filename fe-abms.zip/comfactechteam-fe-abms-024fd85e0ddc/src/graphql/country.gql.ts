import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Country`;

export const COUNTRY_FRAGMENT = gql`
  fragment CountryFragment on ${MODEL_NAME} {
    id
    name
    code
  }
`;

export const ALL_COUNTRIES = gql`
  ${COUNTRY_FRAGMENT}
  query ${TENANT_PREFIX}countries($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
  ${TENANT_PREFIX}countries(sortArg: $sortArg, searchArg: $searchArg) {
    ...CountryFragment
  }
}
`;
