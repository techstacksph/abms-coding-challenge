import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Deal`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DEAL_FRAGMENT = gql`
  fragment DealFragment on ${MODEL_NAME} {
    id
    dealname
    changeAmountAndSpecs
    job{
      id
      jobNo
    }
    site {
      id
      accountId
      siteName
      streetAddress
      suburb
      city
      lastActivity
      region
      country {
        name
      }
      area {
        area
      }
      address
      findStreet
      fullAddress
      postalCode
    }
    recordOwner {
      id
      firstName
      lastName
      fullName
      createdByName
    }
    account {
      id
      name
      accountType
      primaryContact {
        id
      }
    }
    location {
      id
      name
      billingAccount {
        id
        name 
        legalName
      }
    }
    dealType {
      id
      name
    }
    createdAt
    status {
      id
      name
    }
    costingAmount
    contact {
      firstName
      id
      companies {
        companyName
        industryId
        notes
      }
      email
      fullName
      mobile
      phone
      jobTitle
      contactContactType {
        contactType {
          name
        }
      }
    }
    telesales {
      id
      fullName
    }
    notes
    targetCloseDate
    preferredStartDate
    typeofPremise {
      id
      name
    }
    preferredStartDate
    serviceAgreement
    validityInMonths
    cleaningTime
    specialNotes
    totalDailyAmount
    totalMonthlyAmount
    totalWeeklyAmount
    reason
    priceList{
      id
      name
    }
    priceAdjustment
    preferredStartDate
    totalCleaningDuration
    weeksPerAnnum
    frequency
    worktype
    daysPerWeek
    days
    dealNo
    serviceType {
      id
      servicetype
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_SITE_DEALS = gql`
  ${DEAL_FRAGMENT}
  query ${TENANT_PREFIX}paginatedDeals($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDeals(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...DealFragment
        ...BaseFragment
      }
    }
  }
`;

export const PAGINATED_DEALS = gql`
  ${DEAL_FRAGMENT}
  query ${TENANT_PREFIX}paginatedDeals($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDeals(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...DealFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_DEALS_TYPE = gql`
  query ${TENANT_PREFIX}dealTypes {
    ${TENANT_PREFIX}dealTypes {
      id
      name
    }
  }
`;

export const ALL_DEALS = gql`
  ${DEAL_FRAGMENT}
  query ${TENANT_PREFIX}deals($sortArg: [abmsSortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deals(sortArg: $sortArg, searchArg: $searchArg) {
      ...DealFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DEALS_IDS = gql`
  query ${TENANT_PREFIX}deals($sortArg: [abmsSortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}deals(sortArg: $sortArg, searchArg: $searchArg) {
      id
      recordOwner {
        id
        firstName
        lastName
      }
    }
  }
`;

export const SELECT_DEALS = gql`
  query ${TENANT_PREFIX}deals{
    ${TENANT_PREFIX}deals{
      id
      dealname
      dealNo
    }
  }
`;

export const ALL_MODULES = gql`
  query ${TENANT_PREFIX}modules {
    abmsmodules {
      code
      id
      name
      isIncludedInDeal
    }
  }
`;

export const ALL_DEAL_TYPE = gql`
  query ${TENANT_PREFIX}dealTypes {
    ${TENANT_PREFIX}dealTypes {
      id
      name
    }
  }
`;

export const FIND_DEAL_BY_ID = gql`
  ${DEAL_FRAGMENT}
  query ${TENANT_PREFIX}findDealById($${TENANT_PREFIX}findDealByIdId: String!) {
    ${TENANT_PREFIX}findDealById(id: $${TENANT_PREFIX}findDealByIdId) {
      ...DealFragment
      ...BaseFragment
      dealOrderDetails {
        id
        relatedItemId
        area
        cleaningTime
        quantity
        amount
        duration
        frequency
        days
        notes
        minimumCharge
        profitMargin
        dailyAmount
        weeklyAmount
        added
        sortOrder
        dealSpecifications {
          id
          specifications
          days
          sortOrder
          variant {
            id 
            name
          }
          createdAt
        }
      }
    }
  }
`;

export const UPDATE_DEAL_BY_ID = gql`
  ${DEAL_FRAGMENT}
  mutation ${TENANT_PREFIX}updateDeal($deal: ${TENANT_PREFIX}DealInput!, $${TENANT_PREFIX}updateDealId: String!) {
    ${TENANT_PREFIX}updateDeal(deal: $deal, id: $${TENANT_PREFIX}updateDealId) {
      ...DealFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DEALS = gql`
  mutation ${TENANT_PREFIX}createDeal($deal: abmsDealInput!) {
    ${TENANT_PREFIX}createDeal(deal: $deal) {
      id
      dealname
      recordOwner {
        id
        firstName
        lastName
        createdByName
      }
      location {
        id
        name
      }
      dealType {
        id
        name
      }
      telesales {
        fullName
      }
      notes
      targetCloseDate
    }
  }
`;

export const CREATE_ASSIGNEE = gql`
  mutation ${TENANT_PREFIX}createDealAssignees($dealAssignees: [${TENANT_PREFIX}DealAssigneeInput!]!) {
    ${TENANT_PREFIX}createDealAssignees(dealAssignees: $dealAssignees) {
      id
    }
  }
`;

export const CREATE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}createDealWatchers($dealWatchers: [${TENANT_PREFIX}DealWatcherInput!]!) {
    ${TENANT_PREFIX}createDealWatchers(dealWatchers: $dealWatchers) {
      id
    }
  }
`;

export const DELETE_DEALS = gql`
  mutation ${TENANT_PREFIX}deleteDeals($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDeals(ids: $ids)
  }
`;

export const DELETE_DEAL = gql`
  mutation ${TENANT_PREFIX}deleteDeal($${TENANT_PREFIX}deleteDealId: String!) {
    ${TENANT_PREFIX}deleteDeal(id: $${TENANT_PREFIX}deleteDealId)
  }
`;

export const DELETE_ASSIGNEE = gql`
  mutation ${TENANT_PREFIX}deleteDealAssignees($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDealAssignees(ids: $ids)
  }
`;

export const DELETE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}deleteDealWatchers($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDealWatchers(ids: $ids)
  }
`;

export const SELECT_DEAL_TYPE = gql`
  query ${TENANT_PREFIX}dealTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}dealTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      code
    }
  }
`;

export const DEAL_WORKFLOW_STATUS = gql`
  query ${TENANT_PREFIX}workflowProcesses($searchArg: [abmsSearchArg!]) {
    ${TENANT_PREFIX}workflowProcesses(searchArg: $searchArg) {
      id
      name
      workflowStatuses {
        id
        name
      }
    }
  }
`;

export const GET_DEALS_DASHBOARD = gql`
  query ${TENANT_PREFIX}dealsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}dealsDashboard(dashboardArg: $dashboardArg) {
      all
      created
      pending
      closedWon
      closedLost
    }
  }
`;

export const UPDATE_DEAL_STATUS = gql`
  mutation ${TENANT_PREFIX}updateDealStatus($${TENANT_PREFIX}updateDealStatusId: String!, $status: ${TENANT_PREFIX}DealStatusInput!) {
    ${TENANT_PREFIX}updateDealStatus(id: $${TENANT_PREFIX}updateDealStatusId, status: $status) {
      id
    }
  }
`;

// Order details
export const CREATE_ORDER_DETAIL = gql`
  mutation ${TENANT_PREFIX}createOrderDetail($dealOrderDetail: ${TENANT_PREFIX}DealOrderDetailInput!) {
    ${TENANT_PREFIX}createOrderDetail(dealOrderDetail: $dealOrderDetail) {
      id
      orgId
      createdAt
      updatedAt
      deletedAt
      createdBy
      updatedByName
      createdByName
      updatedBy
      deletedBy
      recordLocked
      lockedBy
      timeLocked
      area
      cleaningTime
      quantity
      amount
      duration
      frequency
      days
      notes
      minimumCharge
      profitMargin
      dailyAmount
      weeklyAmount
      added
      dealSpecifications {
        id
        specifications
        days
      }
    }
  }
`;

export const UPDATE_ORDER_DETAILS = gql`
  mutation ${TENANT_PREFIX}updateOrderDetail($id: String!, $dealOrderDetail: ${TENANT_PREFIX}DealOrderDetailInput!) {
    ${TENANT_PREFIX}updateOrderDetail(id: $id, dealOrderDetail: $dealOrderDetail) {
      id
    }
  }
`;

export const DELETE_ORDER_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteOrderDetails($id: [String!]!) {
    ${TENANT_PREFIX}deleteOrderDetails(ids: $id)
  }
`;

export const CREATE_DEAL_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}createDealSpecification($dealSpecification: ${TENANT_PREFIX}DealSpecificationInput!) {
    ${TENANT_PREFIX}createDealSpecification(dealSpecification: $dealSpecification) {
      id
    }
  }
`;

export const UPDATE_DEAL_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}updateDealSpecification($id: String!, $dealSpecification: ${TENANT_PREFIX}DealSpecificationInput!) {
    ${TENANT_PREFIX}updateDealSpecification(id: $id, dealSpecification: $dealSpecification) {
      id
    }
  }
`;

export const ALL_DEAL_TEMPLATES = gql`
  query ${TENANT_PREFIX}dealTemplates($searchArg: [abmsSearchArg!], $sortArg: [abmsSortArg!]) {
    ${TENANT_PREFIX}dealTemplates(searchArg: $searchArg, sortArg: $sortArg) {
      id
      dealTemplate
      description
      dealTemplateDetails {
        id
        area
        frequency
        sortOrder
        item {
          id
        }
      }
      dealTemplateSpecifications {
        id
        dealTemplateDetail {
          id
        }
        specifications
        days
        sortOrder
        variant {
          id
        }
      }
    }
  }
`;

export const OPTIMIZED_PAGINATED_DEALS = gql`
  query ${TENANT_PREFIX}paginatedDealsOptimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDeals(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        id
        dealNo
        dealname
        costingAmount
        createdAt
        targetCloseDate
        job {
         id
         jobNo
        }
        account {
          id
          name
          accountType
        }
        
        site {
          id
          siteName
          address
          fullAddress
          lastActivity
        }
        
        contact {
          id
          fullName
          jobTitle
          phone
          mobile
          email
        }
        
        location {
          id
          name
        }
        
        recordOwner {
          id
          firstName
          lastName
        }
        
        status {
          id
          name
        }

      }
    }
  }
`;

export const GET_DEALS_CSV = gql`
  query ${TENANT_PREFIX}DealCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}DealCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
