import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}InsuranceDetail`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INSURANCE_DETAILS_FRAGMENT = gql`
  fragment InsuranceDetailsFragment on ${MODEL_NAME} {
    id
    name
    account{
      id
    }
    date
    file
    fileKey
    fileMetaData
    fileDownloadUrl
    insuranceType{
      id
      name
      code
    }
    policyNo
    renewalDate
    status{
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_INSURANCE_DETAILS = gql`
  ${INSURANCE_DETAILS_FRAGMENT}
  query paginatedInsuranceDetails($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedInsuranceDetails(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...InsuranceDetailsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_INSURANCE_DETAILS = gql`
  ${INSURANCE_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}insuranceDetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}insuranceDetails(sortArg: $sortArg, searchArg: $searchArg) {
      ...InsuranceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const FIND_INSURANCE_DETAIL_BY_ID = gql`
  ${INSURANCE_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}findInsuranceDetailById($${TENANT_PREFIX}findInsuranceDetailByIdId: String!) {
    ${TENANT_PREFIX}findInsuranceDetailById(id: $${TENANT_PREFIX}findInsuranceDetailByIdId) {
      ...InsuranceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INSURANCE_DETAIL = gql`
  ${INSURANCE_DETAILS_FRAGMENT}
  mutation ${TENANT_PREFIX}updateInsuranceDetail($insuranceDetail: ${TENANT_PREFIX}InsuranceDetailInput!, $${TENANT_PREFIX}updateInsuranceDetailId: String!) {
    ${TENANT_PREFIX}updateInsuranceDetail(insuranceDetail: $insuranceDetail, id: $${TENANT_PREFIX}updateInsuranceDetailId) {
      ...InsuranceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_INSURANCE_DETAIL = gql`
  ${INSURANCE_DETAILS_FRAGMENT}
  mutation ${TENANT_PREFIX}createInsuranceDetail($insuranceDetail: ${TENANT_PREFIX}InsuranceDetailInput!) {
    ${TENANT_PREFIX}createInsuranceDetail(insuranceDetail: $insuranceDetail) {
      ...InsuranceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_INSURANCE_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteInsuranceDetail($${TENANT_PREFIX}deleteInsuranceDetailId: String!) {
    ${TENANT_PREFIX}deleteInsuranceDetail(id: $${TENANT_PREFIX}deleteInsuranceDetailId)
  }
`;

export const DELETE_INSURANCE_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteInsuranceDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteInsuranceDetails(ids: $ids)
  }
`;

export const UPDATE_INSURANCE_DETAIL_STATUS = gql`
  mutation ${TENANT_PREFIX}updateInsuranceDetailStatus($${TENANT_PREFIX}updateInsuranceDetailStatusId: String!, $status: ${TENANT_PREFIX}InsuranceDetailStatusInput!) {
    ${TENANT_PREFIX}updateInsuranceDetailStatus(id: $${TENANT_PREFIX}updateInsuranceDetailStatusId, status: $status) {
      id
    }
  }
`;

export const GET_INSURANCE_DETAIL_FILE_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getInsuranceDetailFileUploadUrl(
    $fileName: String!
    $contentType: String!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getInsuranceDetailFileUploadUrl(
      fileName: $fileName
      contentType: $contentType
      expiresIn: $expiresIn
    ) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;
