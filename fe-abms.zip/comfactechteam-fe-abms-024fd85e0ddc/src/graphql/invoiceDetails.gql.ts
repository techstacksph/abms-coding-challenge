import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}InvoiceDetails`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INVOICE_DETAILS_FRAGMENT = gql`
  fragment InvoiceDetailsFragment on ${MODEL_NAME} {
    id
    accountCodeId
    description
    itemId
    jobId
    invoiceId
    qty
    unitPrice
    lineAmount
    dontMerge
    bci
    serviceProviderId
    serviceTypeId
    commissions
    commissionType
    account {
      id
      name
    }
    accountCode {
      id
      accountCode
      code
    }
    invoiceTemplate {
      id
      invoiceTemplateNo
    }
    item {
      id
      name
    }
    job {
      id
      jobNo
    }
    serviceProvider {
      id
      name
    }
    serviceType {
      id
      servicetype
    }
    orgId
    recordLocked
    lockedBy
    timeLocked
    createdAt
    createdBy
    createdByName
    updatedAt
    updatedBy
    updatedByName
    deletedAt
    deletedBy
  }

  ${BASE_FRAGMENT}
`;

export const ALL_INVOICE_DETAILS = gql`
  ${INVOICE_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}invoicedetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}invoicedetails(sortArg: $sortArg, searchArg: $searchArg) {
      ...InvoiceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_INVOICE_DETAILS = gql`
  ${INVOICE_DETAILS_FRAGMENT}
  query AbmspaginatedInvoiceDetails(
    $searchArg: [abmsSearchArg!]
    $pageArg: abmsPageArg
  ) {
    abmspaginatedInvoiceDetails(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...InvoiceDetailsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_INVOICE_DETAILS_IDS = gql`
  query AbmsinvoiceDetails(
    $sortArg: [abmsSortArg!]
    $searchArg: [abmsSearchArg!]
  ) {
    abmsinvoicedetails(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_INVOICE_DETAILS_BY_ID = gql`
  ${INVOICE_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}findInvoiceDetailsById($${TENANT_PREFIX}findInvoiceDetailsByIdId: String!) {
    ${TENANT_PREFIX}findInvoiceDetailsById(id: $${TENANT_PREFIX}findInvoiceDetailsByIdId) {
      ...InvoiceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INVOICE_DETAILS = gql`
  ${INVOICE_DETAILS_FRAGMENT}
  mutation ${TENANT_PREFIX}updateInvoiceDetails($invoicedetails: ${TENANT_PREFIX}InvoiceDetailsInput!, $${TENANT_PREFIX}updateInvoiceDetailsId: String!) {
    ${TENANT_PREFIX}updateInvoiceDetails(invoicedetails: $invoicedetails, id: $${TENANT_PREFIX}updateInvoiceDetailsId) {
      ...InvoiceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_INVOICE_DETAILS = gql`
  ${INVOICE_DETAILS_FRAGMENT}
  mutation ${TENANT_PREFIX}createInvoiceDetails($invoicedetails: ${TENANT_PREFIX}InvoiceDetailsInput!) {
    ${TENANT_PREFIX}createInvoiceDetails(invoicedetails: $invoicedetails) {
      ...InvoiceDetailsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_INVOICE_DETAILS = gql`
  mutation AbmsdeleteInvoiceDetails($id: String!) {
    abmsdeleteInvoiceDetails(id: $id)
  }
`;
