import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CreditDebitNote`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CREDIT_DEBIT_NOTE_FRAGMENT = gql`
  fragment CreditDebitNoteFragment on ${MODEL_NAME} {
    id
    createdBy
    createdByName
    creditAmountGST
    debitAmountGST
    creditDebitNo
    job {
      id
      jobNo
    }
    location {
      id
      name
    }
    status {
      id
      name
    }
    createdAt
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_CREDIT_DEBIT_NOTES = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${TENANT_PREFIX}paginatedCreditDebitNotes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCreditDebitNotes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CreditDebitNoteFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CREDIT_DEBIT_NOTES = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${TENANT_PREFIX}creditDebitNotes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}creditDebitNotes(sortArg: $sortArg, searchArg: $searchArg) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const FIND_CREDIT_DEBIT_NOTE_BY_ID = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  query ${TENANT_PREFIX}findCreditDebitNoteById($${TENANT_PREFIX}findCreditDebitNoteByIdId: String!) {
    ${TENANT_PREFIX}findCreditDebitNoteById(id: $${TENANT_PREFIX}findCreditDebitNoteByIdId) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CREDIT_DEBIT_NOTE_BY_ID = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCreditDebitNote($creditDebitNote: ${TENANT_PREFIX}CreditDebitNoteInput!, $${TENANT_PREFIX}updateCreditDebitNoteId: String!) {
    ${TENANT_PREFIX}updateCreditDebitNote(creditDebitNote: $creditDebitNote, id: $${TENANT_PREFIX}updateCreditDebitNoteId) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CREDIT_DEBIT_NOTE = gql`
  ${CREDIT_DEBIT_NOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}createCreditDebitNote($creditDebitNote: ${TENANT_PREFIX}CreditDebitNoteInput!) {
    ${TENANT_PREFIX}createCreditDebitNote(creditDebitNote: $creditDebitNote) {
      ...CreditDebitNoteFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CREDIT_DEBIT_NOTE = gql`
  mutation ${TENANT_PREFIX}deleteCreditDebitNote($${TENANT_PREFIX}deleteCreditDebitNoteId: String!) {
    ${TENANT_PREFIX}deleteCreditDebitNote(id: $${TENANT_PREFIX}deleteCreditDebitNoteId)
  }
`;

export const DELETE_CREDIT_DEBIT_NOTES = gql`
  mutation ${TENANT_PREFIX}deleteCreditDebitNotes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCreditDebitNotes(ids: $ids)
  }
`;

export const GET_CREDIT_DEBIT_NOTE_CSV = gql`
  query ${TENANT_PREFIX}CreditDebitNoteCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}CreditDebitNoteCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
