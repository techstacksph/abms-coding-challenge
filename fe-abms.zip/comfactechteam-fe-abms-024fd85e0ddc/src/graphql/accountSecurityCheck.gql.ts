import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}FSecurityCheck`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ACCOUNT_SECURITY_CHECK_FRAGMENT = gql`
  fragment AccountSecurityCheckFragment on ${MODEL_NAME} {
    id
    name
    securityCheckType{
      id
      name
    }
    staff{
      id
      firstName
      lastName
    }
    account{
      id
    }
    date
    documentFile
    documentFileKey
    documentFileMetaData
    downloadUrl
    expirationDate
    statusId
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_ACCOUNT_SECURITY_CHECKS = gql`
  ${ACCOUNT_SECURITY_CHECK_FRAGMENT}
  query ${TENANT_PREFIX}fPaginatedSecurityChecks($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}fPaginatedSecurityChecks(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ... AccountSecurityCheckFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_ACCOUNT_SECURITY_CHECKS = gql`
  ${ACCOUNT_SECURITY_CHECK_FRAGMENT}
  query ${TENANT_PREFIX}fSecurityChecks($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}fSecurityChecks(sortArg: $sortArg, searchArg: $searchArg) {
      ... AccountSecurityCheckFragment
      ...BaseFragment
    }
  }
`;

export const FIND_ACCOUNT_SECURITY_CHECKS_BY_ID = gql`
  ${ACCOUNT_SECURITY_CHECK_FRAGMENT}
  query ${TENANT_PREFIX}findFSecurityCheckById($${TENANT_PREFIX}findFSecurityCheckByIdId: String!) {
    ${TENANT_PREFIX}findFSecurityCheckById(id: $${TENANT_PREFIX}findFSecurityCheckByIdId) {
      ... AccountSecurityCheckFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ACCOUNT_SECURITY_CHECK = gql`
  ${ACCOUNT_SECURITY_CHECK_FRAGMENT}
  mutation ${TENANT_PREFIX}updateFSecurityCheck($securityCheck: ${TENANT_PREFIX}FSecurityCheckInput!, $${TENANT_PREFIX}updateFSecurityCheckId: String!) {
    ${TENANT_PREFIX}updateFSecurityCheck(securityCheck: $securityCheck, id: $${TENANT_PREFIX}updateFSecurityCheckId) {
      ... AccountSecurityCheckFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ACCOUNT_SECURITY_CHECK = gql`
  ${ACCOUNT_SECURITY_CHECK_FRAGMENT}
  mutation ${TENANT_PREFIX}createFSecurityCheck($securityCheck: ${TENANT_PREFIX}FSecurityCheckInput!) {
    ${TENANT_PREFIX}createFSecurityCheck(securityCheck: $securityCheck) {
      ... AccountSecurityCheckFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ACCOUNT_SECURITY_CHECK = gql`
  mutation ${TENANT_PREFIX}deleteFSecurityCheck($${TENANT_PREFIX}deleteFSecurityCheckId: String!) {
    ${TENANT_PREFIX}deleteFSecurityCheck(id: $${TENANT_PREFIX}deleteFSecurityCheckId)
  }
`;

export const DELETE_ACCOUNT_SECURITY_CHECKS = gql`
  mutation ${TENANT_PREFIX}deleteFSecurityChecks($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFSecurityChecks(ids: $ids)
  }
`;

export const GET_SECURITY_CHECK_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getSecurityCheckDocumentUploadUrl(
    $fileName: String!
    $contentType: String
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getSecurityCheckDocumentUploadUrl(
      fileName: $fileName
      contentType: $contentType
      expiresIn: $expiresIn
    ) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;
