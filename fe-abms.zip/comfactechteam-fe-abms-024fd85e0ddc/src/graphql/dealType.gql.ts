import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}DealType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DEAL_TYPE_FRAGMENT = gql`
  fragment DealTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
    newSales
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_DEAL_TYPES = gql`
  ${DEAL_TYPE_FRAGMENT}
  query paginatedDealTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDealTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DealTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_DEAL_TYPES = gql`
  ${DEAL_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}dealTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}dealTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...DealTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DEAL_TYPES_IDS = gql`
  query ${TENANT_PREFIX}dealTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}dealTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_DEAL_TYPE_BY_ID = gql`
  ${DEAL_TYPE_FRAGMENT}
  query findDealTypeById($${TENANT_PREFIX}findDealTypeByIdId: String!) {
    ${TENANT_PREFIX}findDealTypeById(id: $${TENANT_PREFIX}findDealTypeByIdId) {
      ...DealTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DEAL_TYPE_BY_ID = gql`
  ${DEAL_TYPE_FRAGMENT}
  mutation updateDealType($dealType: ${TENANT_PREFIX}DealTypeInput!, $${TENANT_PREFIX}updateDealTypeId: String!) {
    ${TENANT_PREFIX}updateDealType(dealType: $dealType, id: $${TENANT_PREFIX}updateDealTypeId) {
      ...DealTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DEAL_TYPE = gql`
  ${DEAL_TYPE_FRAGMENT}
  mutation createDealType($dealType: ${TENANT_PREFIX}DealTypeInput!) {
    ${TENANT_PREFIX}createDealType(dealType: $dealType) {
      ...DealTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_DEAL_TYPE = gql`
  mutation deleteDealType($${TENANT_PREFIX}deleteDealTypeById: String!) {
    ${TENANT_PREFIX}deleteDealType(id: $${TENANT_PREFIX}deleteDealTypeById)
  }
`;

export const DELETE_DEAL_TYPES = gql`
  mutation deleteDealTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDealTypes(ids: $ids)
  }
`;

export const GET_DEAL_TYPE_CSV = gql`
  query ${TENANT_PREFIX}DealTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}DealTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
