import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Channel`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CHANNEL_FRAGMENT = gql`
  fragment ChannelFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CHANNELS = gql`
  ${CHANNEL_FRAGMENT}
  query paginatedChannels($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedChannels(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ChannelFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CHANNELS = gql`
  ${CHANNEL_FRAGMENT}
  query ${TENANT_PREFIX}channels($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}channels(sortArg: $sortArg, searchArg: $searchArg) {
      ...ChannelFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CHANNELS_IDS = gql`
  query ${TENANT_PREFIX}channels($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}channels(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CHANNEL_BY_ID = gql`
  ${CHANNEL_FRAGMENT}
  query findChannelById($${TENANT_PREFIX}findChannelByIdId: String!) {
    ${TENANT_PREFIX}findChannelById(id: $${TENANT_PREFIX}findChannelByIdId) {
      ...ChannelFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CHANNEL_BY_ID = gql`
  ${CHANNEL_FRAGMENT}
  mutation updateChannel($channel: ${TENANT_PREFIX}ChannelInput!, $${TENANT_PREFIX}updateChannelId: String!) {
    ${TENANT_PREFIX}updateChannel(channel: $channel, id: $${TENANT_PREFIX}updateChannelId) {
      ...ChannelFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CHANNEL = gql`
  ${CHANNEL_FRAGMENT}
  mutation createChannel($channel: ${TENANT_PREFIX}ChannelInput!) {
    ${TENANT_PREFIX}createChannel(channel: $channel) {
      ...ChannelFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CHANNEL = gql`
  mutation deleteChannel($${TENANT_PREFIX}deleteChannelById: String!) {
    ${TENANT_PREFIX}deleteChannel(id: $${TENANT_PREFIX}deleteChannelById)
  }
`;

export const DELETE_CHANNELS = gql`
  mutation deleteChannels($ids: [String!]!) {
    ${TENANT_PREFIX}deleteChannels(ids: $ids)
  }
`;

export const GET_CHANNEL_CSV = gql`
  query ${TENANT_PREFIX}ChannelCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}ChannelCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
