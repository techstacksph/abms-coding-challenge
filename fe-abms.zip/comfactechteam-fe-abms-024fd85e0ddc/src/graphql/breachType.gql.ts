import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}BreachType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const BREACH_TYPE_FRAGMENT = gql`
  fragment BreachTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_BREACH_TYPES = gql`
  ${BREACH_TYPE_FRAGMENT}
  query paginatedBreachTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedBreachTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...BreachTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_BREACH_TYPES = gql`
  ${BREACH_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}breachTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}breachTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...BreachTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_BREACH_TYPES_IDS = gql`
  query ${TENANT_PREFIX}breachTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}breachTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_BREACH_TYPE_BY_ID = gql`
  ${BREACH_TYPE_FRAGMENT}
  query findBreachTypeById($${TENANT_PREFIX}findBreachTypeByIdId: String!) {
    ${TENANT_PREFIX}findBreachTypeById(id: $${TENANT_PREFIX}findBreachTypeByIdId) {
      ...BreachTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_BREACH_TYPE_BY_ID = gql`
  ${BREACH_TYPE_FRAGMENT}
  mutation updateBreachType($breachType: ${TENANT_PREFIX}BreachTypeInput!, $${TENANT_PREFIX}updateBreachTypeId: String!) {
    ${TENANT_PREFIX}updateBreachType(breachType: $breachType, id: $${TENANT_PREFIX}updateBreachTypeId) {
      ...BreachTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_BREACH_TYPE = gql`
  ${BREACH_TYPE_FRAGMENT}
  mutation createBreachType($breachType: ${TENANT_PREFIX}BreachTypeInput!) {
    ${TENANT_PREFIX}createBreachType(breachType: $breachType) {
      ...BreachTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_BREACH_TYPE = gql`
  mutation deleteBreachType($${TENANT_PREFIX}deleteBreachTypeById: String!) {
    ${TENANT_PREFIX}deleteBreachType(id: $${TENANT_PREFIX}deleteBreachTypeById)
  }
`;

export const DELETE_BREACH_TYPES = gql`
  mutation deleteBreachTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteBreachTypes(ids: $ids)
  }
`;

export const GET_BREACH_TYPE_CSV = gql`
  query ${TENANT_PREFIX}BreachTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}BreachTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
