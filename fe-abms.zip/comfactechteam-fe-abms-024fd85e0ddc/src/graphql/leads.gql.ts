import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Lead`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const LEAD_FRAGMENT = gql`
  fragment LeadsFragment on ${MODEL_NAME} {
    company
    id
    location{
      id
      name
    }
    recordOwner{
      id
      firstName
      lastName
    }
    serviceTypeId
    qualifiedDate
    unqualifiedDate
    account{
      id
      name
    }
    leadQuestions {
      id
      leadQuestion
      noOfAnswers
      options
      type
      answer
    }
    site{
      id
      accountId
      siteName
      fullAddress
      address
      streetAddress
      suburb
      city
      region
      postalCode
      placeId
      longitude
      latitude
      countryId
      lastActivity
      updatedAt
      createdAt
      area{
        id
        area
      }
      country{
        id
        code
        name
      }
    }
    primaryContact{
      id
      fullName
      firstName
      lastName
      phone
      mobile
      email
      jobTitle
    }
    source{
      id
      name
    }
    rating
    notes
    status{
      id
      name
    }
    lead
    lastActivity
  }

  ${BASE_FRAGMENT}
`;

// Optimized fragment for paginated list view - only includes fields actually used in table
export const LEAD_LIST_FRAGMENT = gql`
  fragment LeadsListFragment on ${MODEL_NAME} {
    id
    company
    lead
    lastActivity
    serviceTypeId
    location{
      id
      name
    }
    recordOwner{
      id
      firstName
      lastName
    }
    account{
      id
      name
    }
    site{
      id
      accountId
      siteName
      fullAddress
      lastActivity
    }
    primaryContact{
      id
      firstName
      lastName
      phone
      mobile
      email
      jobTitle
    }
    status{
      id
      name
    }
    updatedAt
    createdAt
  }
`;

export const PAGINATED_LEADS = gql`
  ${LEAD_FRAGMENT}
  query paginatedLeads($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedLeads(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...LeadsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Optimized paginated query for list view
export const PAGINATED_LEADS_OPTIMIZED = gql`
  ${LEAD_LIST_FRAGMENT}
  query paginatedLeadsOptimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedLeads(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...LeadsListFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_LEADS = gql`
  ${LEAD_FRAGMENT}
  query ${TENANT_PREFIX}leads($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leads(sortArg: $sortArg, searchArg: $searchArg) {
      ...LeadsFragment
      ...BaseFragment
    }
  }
`;

export const ALL_LEADS_IDS = gql`
  query ${TENANT_PREFIX}leads($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leads(sortArg: $sortArg, searchArg: $searchArg) {
      id
      recordOwner{
        id
        firstName
        lastName
      }
    }
  }
`;

export const SELECT_LEADS = gql`
  query ${TENANT_PREFIX}leads{
    ${TENANT_PREFIX}leads{
      id
      company
      lead
    }
  }
`;

export const FIND_LEAD_BY_ID = gql`
  ${LEAD_FRAGMENT}
  query ${TENANT_PREFIX}findLeadById($${TENANT_PREFIX}findLeadByIdId: String!) {
    ${TENANT_PREFIX}findLeadById(id: $${TENANT_PREFIX}findLeadByIdId) {
      ...LeadsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LEAD = gql`
  ${LEAD_FRAGMENT}
  mutation ${TENANT_PREFIX}updateLead($lead: ${TENANT_PREFIX}LeadInput!, $${TENANT_PREFIX}updateLeadId: String!) {
    ${TENANT_PREFIX}updateLead(lead: $lead, id: $${TENANT_PREFIX}updateLeadId) {
      ...LeadsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_LEAD = gql`
  ${LEAD_FRAGMENT}
  mutation ${TENANT_PREFIX}createLead($lead: ${TENANT_PREFIX}LeadInput!) {
    ${TENANT_PREFIX}createLead(lead: $lead) {
      ...LeadsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_LEAD = gql`
  mutation ${TENANT_PREFIX}deleteLead($${TENANT_PREFIX}deleteLeadId: String!) {
    ${TENANT_PREFIX}deleteLead(id: $${TENANT_PREFIX}deleteLeadId)
  }
`;

export const DELETE_LEADS = gql`
  mutation ${TENANT_PREFIX}deleteLeads($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLeads(ids: $ids)
  }
`;

export const UPDATE_LEAD_STATUS = gql`
  mutation ${TENANT_PREFIX}updateLeadStatus($${TENANT_PREFIX}updateLeadStatusId: String!, $status: ${TENANT_PREFIX}LeadStatusInput!) {
    ${TENANT_PREFIX}updateLeadStatus(id: $${TENANT_PREFIX}updateLeadStatusId, status: $status) {
      id
    }
  }
`;

export const GET_LEADS_DASHBOARD = gql`
  query ${TENANT_PREFIX}leadsDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}leadsDashboard(dashboardArg: $dashboardArg) {
      all
      new
      qualified
      unqualified
    }
  }
`;
