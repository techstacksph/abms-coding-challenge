import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Case`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CASE_FRAGMENT = gql`
  fragment CaseFragment on ${MODEL_NAME} {
    id
    subject
    caseDescription
    caseIdentifier
    dateReceived
    rectificationDate
    severity
    caseNo
    jobId
    account{
      id
      name
      accountType
      ayrMobile
      status{
        id
        name
      }
      primaryContact {
        id
        firstName
        lastName
        jobTitle
        phone
        mobile
        email
      }
    }
    contact{
      id
      firstName
      lastName
      jobTitle
      phone
      mobile
      email
    }
    caseType{
      id
      name
    }
    breachType{
      id
      name
    }
    channel{
      id
      name
    }
    location{
      id
      name
    }
    recordOwner{
      id
      firstName
      lastName
    }
    franchisee{
      id
      name
    }
    caseWatchers{
      watcher{
        id
        firstName
        lastName
      }
    }
    job{
      id
      jobNo
    }
    status{
      id
      name
    }
    qualityAudit {
      id
      qaNo
    }
    employee {
      id
      firstName
      lastName
      fullName
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CASES = gql`
  ${CASE_FRAGMENT}
  query paginatedCases($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCases(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CaseFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CASES = gql`
  ${CASE_FRAGMENT}
  query ${TENANT_PREFIX}cases($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}cases(sortArg: $sortArg, searchArg: $searchArg) {
      ...CaseFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CASES_IDS = gql`
  query ${TENANT_PREFIX}casesIds($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}cases(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_CASES = gql`
  query ${TENANT_PREFIX}cases{
    ${TENANT_PREFIX}cases{
      id
      subject
      caseNo
    }
  }
`;

export const FIND_CASE_BY_ID = gql`
  ${CASE_FRAGMENT}
  query ${TENANT_PREFIX}findCaseById($${TENANT_PREFIX}findCaseByIdId: String!) {
    ${TENANT_PREFIX}findCaseById(id: $${TENANT_PREFIX}findCaseByIdId) {
      ...CaseFragment
      ...BaseFragment
    }
  }
`;

export const CASE_DASHBOARD = gql`
  query ${TENANT_PREFIX}casesDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}casesDashboard(dashboardArg: $dashboardArg) {
      all
      open
      reviewed
      completed
      overdue
    }
  }
`;

export const UPDATE_CASE_BY_ID = gql`
  ${CASE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCase($caseInput: ${TENANT_PREFIX}CaseInput!, $${TENANT_PREFIX}updateCaseId: String!) {
    ${TENANT_PREFIX}updateCase(caseInput: $caseInput, id: $${TENANT_PREFIX}updateCaseId) {
      ...CaseFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE = gql`
  ${CASE_FRAGMENT}
  mutation ${TENANT_PREFIX}createCase($caseInput: ${TENANT_PREFIX}CaseInput!) {
    ${TENANT_PREFIX}createCase(caseInput: $caseInput) {
      ...CaseFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CASE = gql`
  mutation ${TENANT_PREFIX}deleteCase($${TENANT_PREFIX}deleteCaseId: String!) {
    ${TENANT_PREFIX}deleteCase(id: $${TENANT_PREFIX}deleteCaseId)
  }
`;

export const DELETE_CASES = gql`
  mutation ${TENANT_PREFIX}deleteCases($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCases(ids: $ids)
  }
`;

export const UPDATE_CASE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateCaseStatus($${TENANT_PREFIX}updateCaseStatusId: String!, $status: ${TENANT_PREFIX}CaseStatusInput!) {
    ${TENANT_PREFIX}updateCaseStatus(id: $${TENANT_PREFIX}updateCaseStatusId, status: $status) {
      id
    }
  }
`;

export const CREATE_CASE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}createCaseWatchers($caseWatchers: [${TENANT_PREFIX}CaseWatcherInput!]!) {
    ${TENANT_PREFIX}createCaseWatchers(caseWatchers: $caseWatchers) {
      id
    }
  }
`;

export const DELETE_CASE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}deleteWatchersByCase($caseId: String!) {
    ${TENANT_PREFIX}deleteWatchersByCase(caseId: $caseId)
  }
`;
