import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

/**
 * GraphQL query for checking service provider availability
 * Optimized backend endpoint that replaces 3 separate queries with complex client-side calculations
 */
export const CHECK_SERVICE_PROVIDER_AVAILABILITY = gql`
  query CheckServiceProviderAvailability($locationId: String!) {
    ${TENANT_PREFIX}checkServiceProviderAvailability(locationId: $locationId) {
      recommendations {
        serviceProviders
        workLevelType
        monthlyWorkLevelAmount
        monthlyRecurringIncome
        difference
        status
        location
        accountId
      }
      jobPurchases {
        franchisee
        jobPurchase
        amount
        status
        accountId
        jobPurchaseId
      }
    }
  }
`;

/**
 * GraphQL query for paginated job purchase availability
 * Server-side pagination for efficient loading of sold job purchases
 */
export const JOB_PURCHASE_AVAILABILITY = gql`
  query JobPurchaseAvailability(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $pageArg: ${TENANT_PREFIX}PageArg
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}jobPurchaseAvailability(
      searchArg: $searchArg
      pageArg: $pageArg
      sortArg: $sortArg
    ) {
      data {
        franchisee
        jobPurchase
        amount
        status
        accountId
        jobPurchaseId
      }
      pageInfo {
        count
        pageSize
        pageCount
        skip
        take
      }
    }
  }
`;
