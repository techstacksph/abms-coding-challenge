import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Question`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const QUESTION_FRAGMENT = gql`
  fragment QuestionsFragment on ${MODEL_NAME} {
    id
    name
    type
    description
    numAnswers
    options{
        id
        name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_QUESTIONS = gql`
  ${QUESTION_FRAGMENT}
  query paginatedQuestions($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedQuestions(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...QuestionsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_QUESTIONS = gql`
  ${QUESTION_FRAGMENT}
  query ${TENANT_PREFIX}questions($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}questions(sortArg: $sortArg, searchArg: $searchArg) {
      ...QuestionsFragment
      ...BaseFragment
    }
  }
`;

export const FIND_QUESTION_BY_ID = gql`
  ${QUESTION_FRAGMENT}
  query findQuestionById($${TENANT_PREFIX}findQuestionById: String!) {
    ${TENANT_PREFIX}findQuestionById(id: $${TENANT_PREFIX}findQuestionById) {
      ...QuestionsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_QUESTION_BY_ID = gql`
  ${QUESTION_FRAGMENT}
  mutation updateQuestion($question: ${TENANT_PREFIX}QuestionInputSchema!, $${TENANT_PREFIX}updateQuestionId: String!) {
    ${TENANT_PREFIX}updateQuestion(question: $question, id: $${TENANT_PREFIX}updateQuestionId) {
      ...QuestionsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_QUESTION = gql`
  ${QUESTION_FRAGMENT}
  mutation createQuestion($question: ${TENANT_PREFIX}QuestionInputSchema!) {
    ${TENANT_PREFIX}createQuestion(question: $question) {
      ...QuestionsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_QUESTION = gql`
  mutation deleteQuestion($${TENANT_PREFIX}deleteQuestionById: String!) {
    ${TENANT_PREFIX}deleteQuestion(id: $${TENANT_PREFIX}deleteQuestionById)
  }
`;

export const DELETE_QUESTIONS = gql`
  mutation deleteQuestions($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQuestions(ids: $ids)
  }
`;
