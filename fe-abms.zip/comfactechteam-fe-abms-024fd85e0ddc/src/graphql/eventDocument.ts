import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Document`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DOCUMENT_FRAGMENT = gql`
  fragment DocumentFragment on ${MODEL_NAME} {
    id
    eventId
    documentName
    documentTypeId
    description
    documentType {
      id
      description
    }
    event {
      id
      subject
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_DOCUMENTS = gql`
  ${DOCUMENT_FRAGMENT}
  query ${TENANT_PREFIX}documents($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}documents(searchArg: $searchArg, sortArg: $sortArg) {
      ...DocumentFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_DOCUMENTS = gql`
  query ${TENANT_PREFIX}documents {
    ${TENANT_PREFIX}documents {
      id
      documentName
      documentTypeId
      documentType {
        id
        name
      }
    }
  }
`;

export const FIND_TASK_BY_ID = gql`
  query ${TENANT_PREFIX}findDocumentById($abmsfindDocumentByIdId: String!) {
    ${TENANT_PREFIX}findDocumentById(id: $abmsfindDocumentByIdId) {
      id
      documentName
      documentTypeId
      documentType {
        id
        description
      }
      updatedAt
      updatedBy
      updatedByName
    }
  }
`;

export const DELETE_DOCUMENT = gql`
  mutation ${TENANT_PREFIX}deleteDocument($abmsdeleteDocumentId: String!) {
    ${TENANT_PREFIX}deleteDocument(id: $abmsdeleteDocumentId)
  }
`;

export const DELETE_DOCUMENTS = gql`
  mutation ${TENANT_PREFIX}deleteDocuments($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDocuments(ids: $ids)
  }
`;

export const PAGINATED_DOCUMENT = gql`
  ${DOCUMENT_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedTasks {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...DocumentFragment
        ...BaseFragment
      }
    }
  }
`;

export const FIND_DOCUMENT_BY_NAME = gql`
  ${DOCUMENT_FRAGMENT}
  query ${TENANT_PREFIX}findDocumentByName($documentName: String!) {
    ${TENANT_PREFIX}findDocumentByName(documentName: $documentName) {
      ...DocumentFragment
      ...BaseFragment
    }
  }
`;
