import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Department`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DEPARTMENT_FRAGMENT = gql`
  fragment DepartmentFragment on ${MODEL_NAME} {
    id
    name
    description
    parentDepartmentId
    parentDepartment {
      id
      name
    } 
    childDepartments {
      id
      name
    }
    users {
      id
      firstName
      lastName
      userName
      email
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_DEPARTMENTS = gql`
  ${DEPARTMENT_FRAGMENT}
  query paginatedDepartments($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDepartments(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DepartmentFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_DEPARTMENTS = gql`
  ${DEPARTMENT_FRAGMENT}
  query ${TENANT_PREFIX}departments($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}departments(sortArg: $sortArg, searchArg: $searchArg) {
      ...DepartmentFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DEPARTMENTS_IDS = gql`
  query ${TENANT_PREFIX}departments($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}departments(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_DEPARTMENT = gql`
  query ${TENANT_PREFIX}departments($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}departments(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
    }
  }
`;

export const PARENT_DEPARTMENTS = gql`
  query departments {
    ${TENANT_PREFIX}departments {
      id
      name
    }
  }
`;

export const FIND_DEPARTMENT_BY_ID = gql`
  ${DEPARTMENT_FRAGMENT}
  query findDepartmentById($${TENANT_PREFIX}findDepartmentByIdId: String!) {
    ${TENANT_PREFIX}findDepartmentById(id: $${TENANT_PREFIX}findDepartmentByIdId) {
      ...DepartmentFragment
      ...BaseFragment
    }
  }
`;

export const FIND_DEPARTMENT_BY_NAME = gql`
  ${DEPARTMENT_FRAGMENT}
  query findDepartmentByName($${TENANT_PREFIX}findDepartmentByName: String!) {
    ${TENANT_PREFIX}findDepartmentByName(name: $${TENANT_PREFIX}findDepartmentByName) {
      ...DepartmentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DEPARTMENT_BY_ID = gql`
  ${DEPARTMENT_FRAGMENT}
  mutation updateDepartment($department: ${TENANT_PREFIX}DepartmentInput!, $${TENANT_PREFIX}updateDepartmentId: String!) {
    ${TENANT_PREFIX}updateDepartment(department: $department, id: $${TENANT_PREFIX}updateDepartmentId) {
      ...DepartmentFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DEPARTMENT = gql`
  ${DEPARTMENT_FRAGMENT}
  mutation createDepartment($department: ${TENANT_PREFIX}DepartmentInput!) {
    ${TENANT_PREFIX}createDepartment(department: $department) {
      ...DepartmentFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_DEPARTMENT = gql`
  mutation deleteDepartment($${TENANT_PREFIX}deleteDepartmentId: String!) {
    ${TENANT_PREFIX}deleteDepartment(id: $${TENANT_PREFIX}deleteDepartmentId)
  }
`;

export const DELETE_DEPARTMENTS = gql`
  mutation deleteDepartment($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDepartments(ids: $ids)
  }
`;
