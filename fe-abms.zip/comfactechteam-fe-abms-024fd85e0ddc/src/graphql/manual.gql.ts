/* eslint-disable no-unused-vars */
import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Manual`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const MANUAL_FRAGMENT = gql`
  fragment ManualFragment on ${MODEL_NAME} {
    id
    manualTitle
    description
    file
    course {
      id
      course
    }
    createdByName
    updatedByName
  }
  ${BASE_FRAGMENT}
`;

// Get Paginated Manuals Query
export const PAGINATED_MANUALS = gql`
  ${MANUAL_FRAGMENT}
  query PaginatedManuals($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedManuals(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ManualFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

// Get All Manuals Query
export const ALL_MANUALS = gql`
  ${MANUAL_FRAGMENT}
  query ${TENANT_PREFIX}manuals($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}manuals(searchArg: $searchArg, sortArg: $sortArg) {
      ...ManualFragment
      ...BaseFragment
    }
  }
`;

export const ALL_MANUAL_IDS = gql`
  query ${TENANT_PREFIX}manuals($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}manuals(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const ALL_MANUALS_ID = gql`
  query ${TENANT_PREFIX}manualsIds($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}manuals(searchArg: $searchArg, sortArg: $sortArg) {
      id
      manualTitle
      file
    }
  }
`;

export const SELECT_MANUALS = gql`
  query manuals {
      ${TENANT_PREFIX}manuals {
        id
        manualTitle
        file
      }
    }
`;

// Find Manual By ID Query
export const FIND_MANUAL_BY_ID = gql`
  ${MANUAL_FRAGMENT}
  query findManualById($id: String!) {
    ${TENANT_PREFIX}findManualById(id: $id) {
      ...ManualFragment
      ...BaseFragment
    }
  }
`;

// Create Manual Mutation
export const CREATE_MANUAL = gql`
  ${MANUAL_FRAGMENT}
  mutation createManual($input: ${TENANT_PREFIX}ManualInput!) {
    ${TENANT_PREFIX}createManual(manual: $input) {
      ...ManualFragment
      ...BaseFragment
    }
  }
`;

// Update Manual Mutation
export const UPDATE_MANUAL_BY_ID = gql`
  ${MANUAL_FRAGMENT}
  mutation updateManual($input: ${TENANT_PREFIX}ManualInput!, $id: String!) {
    ${TENANT_PREFIX}updateManual(manual: $input, id: $id) {
      ...ManualFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_MANUAL = gql`
  mutation deleteManual($id: String!) {
    ${TENANT_PREFIX}deleteManual(id: $id)
  }
`;

export const DELETE_MANUALS = gql`
  mutation deleteManuals($ids: [String!]!) {
    ${TENANT_PREFIX}deleteManuals(ids: $ids)
  }
`;

export const MANUALS_CSV = gql`
  query ${TENANT_PREFIX}ManualCSV(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}ManualCSV(
      searchArg: $searchArg
      columnArg: $columnArg
      sortArg: $sortArg
    )
  }
`;
