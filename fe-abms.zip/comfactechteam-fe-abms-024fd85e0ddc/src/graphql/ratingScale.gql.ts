import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}RatingScale`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const RATING_SCALE_FRAGMENT = gql`
  fragment RatingScaleFragment on ${MODEL_NAME} {
    id
    description
    name
    rating
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_RATING_SCALES = gql`
  ${RATING_SCALE_FRAGMENT}
  query ${TENANT_PREFIX}paginatedRatingScales($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
  ${TENANT_PREFIX}paginatedRatingScales(searchArg: $searchArg, pageArg: $pageArg) {
    data {
        ...RatingScaleFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      } 
  }
}
`;

export const ALL_RATING_SCALES = gql`
  ${RATING_SCALE_FRAGMENT}
  query AbmsRatingScales(
    $sortArg: [abmsSortArg!]
    $searchArg: [abmsSearchArg!]
  ) {
    abmsRatingScales(sortArg: $sortArg, searchArg: $searchArg) {
      ...RatingScaleFragment
      ...BaseFragment
    }
  }
`;

export const ALL_RATING_SCALE_IDS = gql`
  query AbmsRatingScaleIds(
    $sortArg: [abmsSortArg!]
    $searchArg: [abmsSearchArg!]
  ) {
    abmsRatingScales(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_RATING_SCALE_BY_ID = gql`
  ${RATING_SCALE_FRAGMENT}
  query AbmsfindRatingScaleById($id: String!) {
    abmsfindRatingScaleById(id: $id) {
      ...RatingScaleFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_RATING_SCALE_BY_ID = gql`
  ${RATING_SCALE_FRAGMENT}
  mutation AbmsupdateRatingScale(
    $ratingScale: abmsRatingScaleInput!
    $abmsupdateRatingScaleId: String!
  ) {
    abmsupdateRatingScale(
      ratingScale: $ratingScale
      id: $abmsupdateRatingScaleId
    ) {
      ...RatingScaleFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_RATING_SCALE = gql`
  ${RATING_SCALE_FRAGMENT}
  mutation ${TENANT_PREFIX}createRatingScale($ratingScale: ${TENANT_PREFIX}RatingScaleInput!) {
  ${TENANT_PREFIX}createRatingScale(ratingScale: $ratingScale) {
    ...RatingScaleFragment
    ...BaseFragment    
  }
}

`;

export const DELETE_RATING_SCALES = gql`
  mutation AbmsdeleteRatingScales($ids: [String!]!) {
    abmsdeleteRatingScales(ids: $ids)
  }
`;

export const DELETE_RATING_SCALE = gql`
  mutation AbmsdeleteRatingScale($abmsdeleteRatingScaleId: String!) {
    abmsdeleteRatingScale(id: $abmsdeleteRatingScaleId)
  }
`;

export const GET_RATING_SCALES_CSV = gql`
  query Query(
    $sortArg: [abmsSortArg!]
    $columnArg: [abmsColumnArg!]
    $searchArg: [abmsSearchArg!]
  ) {
    abmsRatingScaleCSV(
      sortArg: $sortArg
      columnArg: $columnArg
      searchArg: $searchArg
    )
  }
`;
