import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

const MODEL_NAME = `${TENANT_PREFIX}DocumentTemplate`;

const DocumentTemplateFragment = gql`
  fragment DocumentTemplateFragment on ${MODEL_NAME}{
    id
    name
    documentTypeId
    description
    file1
    file2
    file3
    file4
    file5
    file1Key
    file2Key
    file3Key
    file4Key
    file5Key
    file1MetaData
    file2MetaData
    file3MetaData
    file4MetaData
    file5MetaData
    downloadUrl1
    downloadUrl2
    downloadUrl3
    downloadUrl4
    downloadUrl5
    access
    type
    updatedAt
    updatedBy
    updatedByName
  }
`;

export const ALL_DOCUMENT_TEMPLATE = gql`
  ${DocumentTemplateFragment}
  query ${TENANT_PREFIX}documentTemplates($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}documentTemplates(sortArg: $sortArg, searchArg: $searchArg) {
      ...DocumentTemplateFragment
    }
  }
`;

export const ALL_DOCUMENT_TEMPLATE_IDS = gql`
  query ${TENANT_PREFIX}documentTemplates($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}documentTemplates(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const PAGINATED_DOCUMENT_TEMPLATE = gql`
  ${DocumentTemplateFragment}
  query ${TENANT_PREFIX}paginatedDocumentTemplate($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDocumentTemplate(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DocumentTemplateFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const CREATE_DOCUMENT_TEMPLATE = gql`
    mutation ${TENANT_PREFIX}createDocumentTemplate($documentTemplate: ${TENANT_PREFIX}DocumentTemplateInput!) {
    ${TENANT_PREFIX}createDocumentTemplate(documentTemplate: $documentTemplate) {
      id
    }
  }
`;

export const UPDATE_DOCUMENT_TEMPLATE = gql`
  mutation ${TENANT_PREFIX}updateDocumentTemplate($documentTemplate: ${TENANT_PREFIX}DocumentTemplateInput!, $id: String!) {
    ${TENANT_PREFIX}updateDocumentTemplate(documentTemplate: $documentTemplate, id: $id) {
      id
    }
  }
`;

export const FIND_DOCUMENT_TEMPLATE_BY_ID = gql`
  ${DocumentTemplateFragment}
  query ${TENANT_PREFIX}findDocumentTemplateById($${TENANT_PREFIX}findDocumentTemplateByIdId: String!) {
    ${TENANT_PREFIX}findDocumentTemplateById(id: $${TENANT_PREFIX}findDocumentTemplateByIdId) {
      ...DocumentTemplateFragment
    }
  }
`;

export const DELETE_DOCUMENT_TEMPLATES = gql`
  mutation ${TENANT_PREFIX}deleteDocumentTemplates($ids: [String!]!) {
   ${TENANT_PREFIX}deleteDocumentTemplates(ids: $ids)
  }
`;

export const DELETE_DOCUMENT_TEMPLATE_BY_ID = gql`
  mutation ${TENANT_PREFIX}deleteDocumentTemplate($id: String!) {
    ${TENANT_PREFIX}deleteDocumentTemplate(id: $id)
  }
`;

// S3 Upload URL queries
export const GET_DOCUMENT_TEMPLATE_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getDocumentTemplateUploadUrl(
    $fileName: String!
    $fileNumber: Float!
    $contentType: String
    $fileSize: Float
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getDocumentTemplateUploadUrl(
      fileName: $fileName
      fileNumber: $fileNumber
      contentType: $contentType
      fileSize: $fileSize
      expiresIn: $expiresIn
    ) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;

export const GET_DOCUMENT_TEMPLATE_UPLOAD_URLS = gql`
  query ${TENANT_PREFIX}getDocumentTemplateUploadUrls(
    $files: [${TENANT_PREFIX}DocumentUploadFileInput!]!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getDocumentTemplateUploadUrls(
      files: $files
      expiresIn: $expiresIn
    ) {
      fileNumber
      uploadUrl
      s3Key
      s3Url
      expiresIn
      fileName
    }
  }
`;
