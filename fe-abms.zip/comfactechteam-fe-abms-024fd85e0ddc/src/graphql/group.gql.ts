import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Group`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const GROUP_FRAGMENT = gql`
  fragment GroupFragment on ${MODEL_NAME} {
    id
    name
    description
    locationId
    departmentId
    functionId
    location {
      id
      name
    }
    department {
      id
      name
    }
    function {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_GROUPS = gql`
  ${GROUP_FRAGMENT}
  query paginatedGroups($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedGroups(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...GroupFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_GROUPS = gql`
  ${GROUP_FRAGMENT}
  query ${TENANT_PREFIX}groups($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}groups(searchArg: $searchArg, sortArg: $sortArg) {
      ...GroupFragment
      ...BaseFragment
    }
  }
`;

export const ALL_GROUPS_IDS = gql`
  query ${TENANT_PREFIX}groups($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}groups(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const SELECT_GROUP = gql`
  query groups {
    ${TENANT_PREFIX}groups {
      id
      name
    }
  }
`;

export const FIND_GROUP_BY_ID = gql`
  ${GROUP_FRAGMENT}
  query findGroupById($${TENANT_PREFIX}findGroupByIdId: String!) {
    ${TENANT_PREFIX}findGroupById(id: $${TENANT_PREFIX}findGroupByIdId) {
      ...GroupFragment
      ...BaseFragment
    }
  }
`;

export const FIND_GROUP_BY_NAME = gql`
  ${GROUP_FRAGMENT}
  query findGroupByName($${TENANT_PREFIX}findGroupByName: String!) {
    ${TENANT_PREFIX}findGroupByName(name: $${TENANT_PREFIX}findGroupByName) {
      ...GroupFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_GROUP_BY_ID = gql`
  ${GROUP_FRAGMENT}
  mutation updateGroup($group: ${TENANT_PREFIX}GroupInput!, $${TENANT_PREFIX}updateGroupId: String!) {
    ${TENANT_PREFIX}updateGroup(group: $group, id: $${TENANT_PREFIX}updateGroupId) {
      ...GroupFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_GROUP = gql`
  ${GROUP_FRAGMENT}
  mutation createGroup($group: ${TENANT_PREFIX}GroupInput!) {
    ${TENANT_PREFIX}createGroup(group: $group) {
      ...GroupFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_GROUP = gql`
  mutation deleteGroup($id: String!) {
    ${TENANT_PREFIX}deleteGroup(id: $id)
  }
`;

export const DELETE_GROUPS = gql`
  mutation deleteGroup($ids: [String!]!) {
    ${TENANT_PREFIX}deleteGroups(ids: $ids)
  }
`;
