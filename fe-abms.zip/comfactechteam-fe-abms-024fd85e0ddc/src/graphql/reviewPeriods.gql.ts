import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ReviewPeriod`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const REVIEW_PERIOD_DETAILS_FRAGMENT = gql`
  fragment ReviewPeriodDetailsFragment on ${TENANT_PREFIX}ReviewPeriodDetails {
    id
    employeeId
    selfReviewRate
    managerReviewRate
    orgId
    performanceReviewId
    reviewPeriodId
    recordLocked
    lockedBy
    timeLocked
    createdAt
    updatedAt
    createdBy
    updatedBy
    createdByName
    updatedByName
    deletedAt
    deletedBy
    employee {
      id
      firstName
      lastName
      email
    }
    reviewPeriodDetailsToDepartments {
      id
      departmentId
      reviewPeriodDetailsId
    }
    reviewPeriodDetailsToUsers {
      id
      managerId
      reviewPeriodDetailsId
    }
  }
`;

export const REVIEW_PERIOD_FRAGMENT = gql`
  fragment ReviewPeriodFragment on ${MODEL_NAME} {
    id
    title
    startDate
    endEmployee
    endManager
    lookOutEmployee
    lookOutManager
    remindersBegin
    notes
    exPending
    overallScore
    recordLocked
    lockedBy
    timeLocked
    orgId
    status {
      id
      name
    }
    statusId
    reviewPeriodDetails {
      ...ReviewPeriodDetailsFragment
    }
    reviewPeriodEmployees {
      id
    }
    reviewPeriodQuestionnaires {
      id
      questionnaire {
        id
        type
      }
    }
    weightedScore
    document1
    document2
    document3
    document4
    document5
    createdAt
    updatedAt
    createdBy
    updatedBy
    createdByName
    updatedByName
    deletedAt
    deletedBy
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_REVIEW_PERIODS = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  ${REVIEW_PERIOD_FRAGMENT}
  query ${TENANT_PREFIX}paginatedReviewPeriods($pageArg: ${TENANT_PREFIX}PageArg!, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedReviewPeriods(pageArg: $pageArg, searchArg: $searchArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...ReviewPeriodFragment
        ...BaseFragment
      }
    }
  }
`;

export const PAGINATED_REVIEW_PERIOD_DETAILS = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}paginatedReviewPeriodDetails($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedReviewPeriodDetails(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ReviewPeriodDetailsFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_REVIEW_PERIOD_DETAILS = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}reviewPeriodDetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}reviewPeriodDetails(sortArg: $sortArg, searchArg: $searchArg) {
      ...ReviewPeriodDetailsFragment
    }
  }
`;

export const ALL_REVIEW_PERIODS = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  ${REVIEW_PERIOD_FRAGMENT}
  query ${TENANT_PREFIX}reviewPeriods($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}reviewPeriods(sortArg: $sortArg, searchArg: $searchArg) {
      ...ReviewPeriodFragment
      ...BaseFragment
    }
  }
`;

export const GET_REVIEW_PERIOD = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  ${REVIEW_PERIOD_FRAGMENT}
  query ${TENANT_PREFIX}reviewPeriod($id: ID!) {
    ${TENANT_PREFIX}reviewPeriod(id: $id) {
      ...ReviewPeriodFragment
      ...BaseFragment
    }
  }
`;

export const FIND_REVIEW_PERIOD_BY_ID = gql`
  ${REVIEW_PERIOD_DETAILS_FRAGMENT}
  ${REVIEW_PERIOD_FRAGMENT}
  query ${TENANT_PREFIX}findReviewPeriodById($id: String!) {
    ${TENANT_PREFIX}findReviewPeriodById(id: $id) {
      ...ReviewPeriodFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_REVIEW_PERIODS = gql`
  mutation ${TENANT_PREFIX}deleteReviewPeriods($ids: [String!]!) {
    ${TENANT_PREFIX}deleteReviewPeriods(ids: $ids)
  }
`;

export const UPDATE_REVIEW_PERIOD_STATUS = gql`
  mutation ${TENANT_PREFIX}updateReviewPeriod($id: String!, $reviewPeriod: ${TENANT_PREFIX}ReviewPeriodInput!) {
    ${TENANT_PREFIX}updateReviewPeriod(id: $id, reviewPeriod: $reviewPeriod) {
      id
    }
  }
`;

export const CREATE_REVIEW_PERIOD = gql`
  mutation ${TENANT_PREFIX}createReviewPeriod($reviewPeriod: ${TENANT_PREFIX}ReviewPeriodInput!) {
    ${TENANT_PREFIX}createReviewPeriod(reviewPeriod: $reviewPeriod) {
      id
      title
    }
  }
`;

export const UPDATE_REVIEW_PERIOD = gql`
  mutation ${TENANT_PREFIX}updateReviewPeriod($id: String!, $reviewPeriod: ${TENANT_PREFIX}ReviewPeriodInput!) {
    ${TENANT_PREFIX}updateReviewPeriod(id: $id, reviewPeriod: $reviewPeriod) {
      id
      title
    }
  }
`;

export const CREATE_REVIEW_PERIOD_DETAILS = gql`
  mutation ${TENANT_PREFIX}createReviewPeriodDetails($reviewPeriodDetails: ${TENANT_PREFIX}ReviewPeriodDetailsInput!) {
    ${TENANT_PREFIX}createReviewPeriodDetails(reviewPeriodDetails: $reviewPeriodDetails) {
      id
      employeeId
      selfReviewRate
      managerReviewRate
      reviewPeriodId
    }
  }
`;

export const UPDATE_REVIEW_PERIOD_DETAILS = gql`
  mutation ${TENANT_PREFIX}updateReviewPeriodDetails($reviewPeriodDetails: ${TENANT_PREFIX}ReviewPeriodDetailsInput!, $id: String!) {
    ${TENANT_PREFIX}updateReviewPeriodDetails(reviewPeriodDetails: $reviewPeriodDetails, id: $id) {
      id
      employeeId
      selfReviewRate
      managerReviewRate
      reviewPeriodId
    }
  }
`;

export const DELETE_REVIEW_PERIOD_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteReviewPeriodDetails($id: String!) {
    ${TENANT_PREFIX}deleteReviewPeriodDetails(id: $id)
  }
`;
