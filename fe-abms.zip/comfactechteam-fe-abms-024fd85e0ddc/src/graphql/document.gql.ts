import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Document`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DOCUMENT_FRAGMENT = gql`
  fragment DocumentFragment on ${MODEL_NAME} {
    id
    documentName
    description
    documentType {
      id
      name
      description
    }
    event {
      id
      subject
    }
    account {
      id
      name
    }
    lead {
      id
      lead
    }
    purchaseOrder{
      id
      poNo
    }
    deal {
      id
      dealNo
      dealname
    }
    site {
      id
      siteName
      lastActivity
    }
    job {
      id
      jobNo
    }
    case {
      id
      caseNo
    }
    training {
      id
      trainingDate
    }
    qualityAudit {
      id
      qaNo
    }
    task {
     id
     taskSubject
    }
    eventId
    relatedTo {
      id
      name
    }
    bill{
      id
      billNo
    }
    evaluation{
      id
      evaluationDate
    }
    invoice{
      id
      invoiceNo
      autoNumber
    }
    salesOrder{
      id
      soNo
    }
    businessForSale{
      id
      businessNo
    }
    deliveryReturn{
      id
      # deliveryReturnNo
    }
    agreementsAndContracts{
      id
      agreementsContractNo
      type
    }
    creditDebitNote{
      id
      creditDebitNo
    }
    employee{
      id
      fullName
    }
    jobPurchaseApplication{
      id
      jobPurchaseNo
    }
    performanceReview{
      id
      perfReviewNo
    }
    recruitment{
      id
      recruitmentNo
    }
    franchiseeAgreement{
      id
      agreementNo
    }
    accountId
    #agreementId
    agreementsAndContractsId
    billId
    businessForSaleId
    caseId
    dealId
    deliveryReturnId
    documentTypeId
    creditDebitNoteId
    employeeId
    evaluationId
    eventId
    franchiseeAgreementId
    invoiceId
    jobId
    jobPurchaseApplicationId
    leadId
    performanceReviewId
    purchaseOrderId
    qualityAuditId
    recruitmentId
    salesOrderId
    siteId
    taskId
    trainingId
    relatedTo {
      id
      name
    }
    relatedToId
    file1
    file2
    file3
    file4
    file5
    file1Key
    file2Key
    file3Key
    file4Key
    file5Key
    file1MetaData
    file2MetaData
    file3MetaData
    file4MetaData
    file5MetaData
    downloadUrl1
    downloadUrl2
    downloadUrl3
    downloadUrl4
    downloadUrl5
  }
  ${BASE_FRAGMENT}
`;

export const ALL_DOCUMENTS = gql`
  ${DOCUMENT_FRAGMENT}
  query ${TENANT_PREFIX}documents($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}documents(searchArg: $searchArg, sortArg: $sortArg) {
      ...DocumentFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DOCUMENTS_IDS = gql`
  query ${TENANT_PREFIX}documents($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}documents(searchArg: $searchArg, sortArg: $sortArg) {
      id
      account{
        id
      }
      deal{
        id
      }
    }
  }
`;

export const PAGINATED_DOCUMENTS = gql`
  ${DOCUMENT_FRAGMENT}
  query PageInfo($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDocument(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...DocumentFragment
        ...BaseFragment
      }
    }
  }
`;

export const CREATE_DOCUMENT = gql`
  mutation ${TENANT_PREFIX}createDocument(
    $document: ${TENANT_PREFIX}DocumentInput!
    $isVirtual: Boolean
    $parentId: String
    $parentType: ParentType
    $startDate: String
  ) {
    ${TENANT_PREFIX}createDocument(
      document: $document
      isVirtual: $isVirtual
      parentId: $parentId
      parentType: $parentType
      startDate: $startDate
    ) {
      id
      documentName
      taskId
      eventId
    }
  }
`;

export const FIND_DOCUMENT_BY_ID = gql`
  ${DOCUMENT_FRAGMENT}
  query ${TENANT_PREFIX}findDocumentById($${TENANT_PREFIX}findDocumentByIdId: String!) {
    ${TENANT_PREFIX}findDocumentById(id: $${TENANT_PREFIX}findDocumentByIdId) {
      ...DocumentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DOCUMENT_BY_ID = gql`
  mutation ${TENANT_PREFIX}updateDocument($document: ${TENANT_PREFIX}DocumentInput!, $${TENANT_PREFIX}updateDocumentId: String!) {
    ${TENANT_PREFIX}updateDocument(document: $document, id: $${TENANT_PREFIX}updateDocumentId) {
      id
      documentName
    }
  }
`;

export const DELETE_DOCUMENT = gql`
  mutation ${TENANT_PREFIX}deleteDocument($${TENANT_PREFIX}deleteDocumentId: String!) {
    ${TENANT_PREFIX}deleteDocument(id: $${TENANT_PREFIX}deleteDocumentId)
  }
`;

export const DELETE_DOCUMENTS = gql`
  mutation ${TENANT_PREFIX}deleteDocuments($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDocuments(ids: $ids)
  }
`;
