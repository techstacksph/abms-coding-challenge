import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CaseType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CASE_TYPE_FRAGMENT = gql`
  fragment CaseTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CASE_TYPES = gql`
  ${CASE_TYPE_FRAGMENT}
  query paginatedCaseTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCaseTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CaseTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CASE_TYPES = gql`
  ${CASE_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}caseTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}caseTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...CaseTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CASE_TYPES_IDS = gql`
  query ${TENANT_PREFIX}caseTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}caseTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CASE_TYPE_BY_ID = gql`
  ${CASE_TYPE_FRAGMENT}
  query findCaseTypeById($${TENANT_PREFIX}findCaseTypeByIdId: String!) {
    ${TENANT_PREFIX}findCaseTypeById(id: $${TENANT_PREFIX}findCaseTypeByIdId) {
      ...CaseTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CASE_TYPE_BY_ID = gql`
  ${CASE_TYPE_FRAGMENT}
  mutation updateCaseType($caseType: ${TENANT_PREFIX}CaseTypeInput!, $${TENANT_PREFIX}updateCaseTypeId: String!) {
    ${TENANT_PREFIX}updateCaseType(caseType: $caseType, id: $${TENANT_PREFIX}updateCaseTypeId) {
      ...CaseTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE_TYPE = gql`
  ${CASE_TYPE_FRAGMENT}
  mutation createCaseType($caseType: ${TENANT_PREFIX}CaseTypeInput!) {
    ${TENANT_PREFIX}createCaseType(caseType: $caseType) {
      ...CaseTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CASE_TYPE = gql`
  mutation deleteCaseType($${TENANT_PREFIX}deleteCaseTypeById: String!) {
    ${TENANT_PREFIX}deleteCaseType(id: $${TENANT_PREFIX}deleteCaseTypeById)
  }
`;

export const DELETE_CASE_TYPES = gql`
  mutation deleteCaseTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCaseTypes(ids: $ids)
  }
`;
