import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PremiseType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PREMISE_TYPE_FRAGMENT = gql`
  fragment PremiseTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_PREMISE_TYPES = gql`
  ${PREMISE_TYPE_FRAGMENT}
  query paginatedPremiseTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPremiseTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PremiseTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_PREMISE_TYPES = gql`
  ${PREMISE_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}premiseTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}premiseTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...PremiseTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_PREMISE_TYPES_IDS = gql`
  query ${TENANT_PREFIX}premiseTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}premiseTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_PREMISE_TYPE_BY_ID = gql`
  ${PREMISE_TYPE_FRAGMENT}
  query findPremiseTypeById($${TENANT_PREFIX}findPremiseTypeByIdId: String!) {
    ${TENANT_PREFIX}findPremiseTypeById(id: $${TENANT_PREFIX}findPremiseTypeByIdId) {
      ...PremiseTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_PREMISE_TYPE_BY_ID = gql`
  ${PREMISE_TYPE_FRAGMENT}
  mutation updatePremiseType($premiseType: ${TENANT_PREFIX}PremiseTypeInput!, $${TENANT_PREFIX}updatePremiseTypeId: String!) {
    ${TENANT_PREFIX}updatePremiseType(premiseType: $premiseType, id: $${TENANT_PREFIX}updatePremiseTypeId) {
      ...PremiseTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_PREMISE_TYPE = gql`
  ${PREMISE_TYPE_FRAGMENT}
  mutation createPremiseType($premiseType: ${TENANT_PREFIX}PremiseTypeInput!) {
    ${TENANT_PREFIX}createPremiseType(premiseType: $premiseType) {
      ...PremiseTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_PREMISE_TYPE = gql`
  mutation deletePremiseType($${TENANT_PREFIX}deletePremiseTypeById: String!) {
    ${TENANT_PREFIX}deletePremiseType(id: $${TENANT_PREFIX}deletePremiseTypeById)
  }
`;

export const DELETE_PREMISE_TYPES = gql`
  mutation deletePremiseTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deletePremiseTypes(ids: $ids)
  }
`;

export const GET_PREMISE_TYPE_CSV = gql`
  query ${TENANT_PREFIX}PremiseTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}PremiseTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
