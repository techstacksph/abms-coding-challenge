import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const CREATE_CLIENT_HUB_ACCESS = gql`
  mutation ${TENANT_PREFIX}createClientHubAccess($input: ${TENANT_PREFIX}CreateClientHubAccessInput!) {
    ${TENANT_PREFIX}createClientHubAccess(input: $input) {
      success
      message
      userId
    }
  }
`;

export const UPDATE_CLIENT_HUB_PASSWORD = gql`
  mutation ${TENANT_PREFIX}updateClientHubPassword($input: ${TENANT_PREFIX}UpdateClientHubPasswordInput!) {
    ${TENANT_PREFIX}updateClientHubPassword(input: $input) {
      success
      message
    }
  }
`;
