import { gql } from '@apollo/client';

export const ALL_PAYMENT_HISTORY = gql`
  query AllPaymentHistory($invoiceId: String!) {
    paymentHistory(invoiceId: $invoiceId) {
      id
      paymentDate
      amountPaid
      paymentType
      paymentReference
      paymentStatus
      createdAt
      updatedAt
    }
  }
`;

export const PAGINATED_PAYMENT_HISTORY = gql`
  query PaginatedPaymentHistory(
    $invoiceId: String!
    $pageArg: PageArg
    $searchArg: [SearchArg]
    $sortArg: [SortArg]
  ) {
    paginatedPaymentHistory(
      invoiceId: $invoiceId
      pageArg: $pageArg
      searchArg: $searchArg
      sortArg: $sortArg
    ) {
      data {
        id
        paymentDate
        amountPaid
        paymentType
        paymentReference
        paymentStatus
        createdAt
        updatedAt
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
        hasNext
        hasPrevious
      }
    }
  }
`;

export const FIND_PAYMENT_HISTORY_BY_ID = gql`
  query FindPaymentHistoryById($id: String!) {
    paymentHistory(id: $id) {
      id
      paymentDate
      amountPaid
      paymentType
      paymentReference
      paymentStatus
      createdAt
      updatedAt
    }
  }
`;

export const CREATE_PAYMENT_HISTORY = gql`
  mutation CreatePaymentHistory($input: CreatePaymentHistoryInput!) {
    createPaymentHistory(input: $input) {
      id
      paymentDate
      amountPaid
      paymentType
      paymentReference
      paymentStatus
      createdAt
      updatedAt
    }
  }
`;

export const UPDATE_PAYMENT_HISTORY = gql`
  mutation UpdatePaymentHistory(
    $id: String!
    $input: UpdatePaymentHistoryInput!
  ) {
    updatePaymentHistory(id: $id, input: $input) {
      id
      paymentDate
      amountPaid
      paymentType
      paymentReference
      paymentStatus
      createdAt
      updatedAt
    }
  }
`;

export const DELETE_PAYMENT_HISTORY = gql`
  mutation DeletePaymentHistory($id: String!) {
    deletePaymentHistory(id: $id) {
      id
    }
  }
`;
