import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}WarehouseItem`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INVENTORY_FRAGMENT = gql`
  fragment InventoryFragment on ${MODEL_NAME} {
    id
    inventoryItemNo
    itemId
    begBalance
    debit
    credit
    stockOnHand
    minimumLevel
    safetyLevel
    stockValue
    warehouseId
    warehouse {
      id
      name
      code
    }
    item {
      id
      name
      itemCode
      description
      itemType
      productImage
      itemCategory {
        id
        name
      }
      itemSubcategory {
        id
        name
      }
      workflowStatus {
        name
        id
      }
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_INVENTORY_ITEMS = gql`
  ${INVENTORY_FRAGMENT}
  query ${TENANT_PREFIX}paginatedWarehouseItems($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedWarehouseItems(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...InventoryFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_INVENTORY_ITEMS = gql`
  ${INVENTORY_FRAGMENT}
  query ${TENANT_PREFIX}warehouseItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}warehouseItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...InventoryFragment
      ...BaseFragment
    }
  }
`;

export const FIND_INVENTORY_ITEM_BY_ID = gql`
  ${INVENTORY_FRAGMENT}
  query ${TENANT_PREFIX}findWarehouseItemById($${TENANT_PREFIX}findWarehouseItemByIdId: String!) {
    ${TENANT_PREFIX}findWarehouseItemById(id: $${TENANT_PREFIX}findWarehouseItemByIdId) {
      ...InventoryFragment
      ...BaseFragment
    }
  }
`;

export const GET_INVENTORY_DASHBOARD = gql`
  query ${TENANT_PREFIX}inventoryDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}inventoryDashboard(dashboardArg: $dashboardArg) {
      all
      belowMinimumLevel
      belowSafetyLevel
      bestSellingItem
      slowMovingItem
      data
    }
  }
`;

export const GET_INVENTORY_CSV = gql`
  query ${TENANT_PREFIX}warehouseItemCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}warehouseItemCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const DELETE_INVENTORY_ITEMS = gql`
  mutation ${TENANT_PREFIX}deleteWarehouseItems($ids: [String!]!) {
    ${TENANT_PREFIX}deleteWarehouseItems(ids: $ids)
  }
`;
