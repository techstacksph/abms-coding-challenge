import { gql } from '@apollo/client';

import environment from '../config/environment';

// import { getBaseFragment } from './base.gql';

const { TENANT_PREFIX } = environment;

export const ALL_JOB_BILLINGS = gql`
  query ${TENANT_PREFIX}jobBillings($sortArg: [abmsSortArg!], $searchArg: [abmsSearchArg!]) {
    ${TENANT_PREFIX}jobBillings(sortArg: $sortArg, searchArg: $searchArg) {
      id
      serviceProvider {
        id
        name
      }
      schedule
      cleaningTime
      hours
      jobAmount
      commissionType
      commission
      payableAmount
    }
  }
`;

export const CREATE_JOBS_BILLING = gql`
  mutation ${TENANT_PREFIX}createJobBilling($input: ${TENANT_PREFIX}JobBillingInput!) {
    ${TENANT_PREFIX}createJobBilling(jobBilling: $input) {
      id
    }
  }
`;

export const UPDATE_JOB_BILLING = gql`
  mutation ${TENANT_PREFIX}updateJobBilling($id: String!, $input: ${TENANT_PREFIX}JobBillingInput!) {
    ${TENANT_PREFIX}updateJobBilling(id: $id, jobBilling: $input) {
      id
    }
  }
`;
