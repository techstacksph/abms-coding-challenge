import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}JobPDF`;

export const JOB_PDF_FRAGMENT = gql`
  fragment JobPDFFragment on ${MODEL_NAME} {
    id
    job {
     id
     jobNo
     keyAccount {
       id
       name
       fullName
     }
    }
    type
    serviceProviderId
    serviceProvider {
      id
      name
    }
    pdf
    fileName
    file
    # downloadUrl
    createdAt
    updatedAt
    createdBy
    updatedBy
  }
`;

export const CREATE_JOB_PDF = gql`
  ${JOB_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}createJobPDF($jobPDF: ${MODEL_NAME}Input!) {
    ${TENANT_PREFIX}createJobPDF(jobPDF: $jobPDF) {
      ...JobPDFFragment
    }
  }
`;

export const UPDATE_JOB_PDF = gql`
  ${JOB_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}updateJobPDF($jobPDF: ${MODEL_NAME}Input!, $id: String!) {
    ${TENANT_PREFIX}updateJobPDF(jobPDF: $jobPDF, id: $id) {
      ...JobPDFFragment
    }
  }
`;

export const DELETE_JOB_PDF = gql`
  mutation ${TENANT_PREFIX}deleteJobPDF($id: String!) {
    ${TENANT_PREFIX}deleteJobPDF(id: $id)
  }
`;

export const DELETE_JOB_PDFS = gql`
  mutation ${TENANT_PREFIX}deleteJobPDFs($ids: [String!]!) {
    ${TENANT_PREFIX}deleteJobPDFs(ids: $ids)
  }
`;

export const CREATE_MULTIPLE_JOB_PDFS = gql`
  ${JOB_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}createMultipleJobPDFs($jobPDFs: [${MODEL_NAME}Input!]!) {
    ${TENANT_PREFIX}createMultipleJobPDFs(jobPDFs: $jobPDFs) {
      ...JobPDFFragment
    }
  }
`;

export const FIND_JOB_PDF_BY_ID = gql`
  ${JOB_PDF_FRAGMENT}
  query ${TENANT_PREFIX}findJobPDFById($id: String!) {
    ${TENANT_PREFIX}findJobPDFById(id: $id) {
      ...JobPDFFragment
    }
  }
`;

export const FIND_JOB_PDFS = gql`
  ${JOB_PDF_FRAGMENT}
  query ${TENANT_PREFIX}jobPDFs($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}jobPDFs(searchArg: $searchArg, sortArg: $sortArg) {
      ...JobPDFFragment
    }
  }
`;

export const PAGINATED_JOB_PDFS = gql`
  ${JOB_PDF_FRAGMENT}
  query ${TENANT_PREFIX}paginatedJobPDFs($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedJobPDFs(pageArg: $pageArg, searchArg: $searchArg) {
      data {
        ...JobPDFFragment
      }
      pageInfo {
        count
      }
    }
  }
`;
