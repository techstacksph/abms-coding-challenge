import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}LeadQuestion`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const LEAD_QUESTION_FRAGMENT = gql`
  fragment LeadQuestionFragment on ${MODEL_NAME} {
    leadQuestion
    type
    options
    noOfAnswers
    answer
  }
  
  ${BASE_FRAGMENT}
`;

export const FIND_LEAD_QUESTION_BY_ID = gql`
  ${LEAD_QUESTION_FRAGMENT}
  query ${TENANT_PREFIX}findLeadQuestionById($${TENANT_PREFIX}findLeadQuestionByIdId: String!) {
    ${TENANT_PREFIX}findLeadQuestionById(id: $${TENANT_PREFIX}findLeadQuestionByIdId) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const GET_LEAD_QUESTIONS = gql`
  ${LEAD_QUESTION_FRAGMENT}
  query ${TENANT_PREFIX}leadQuestions(
    $searchArg: [${TENANT_PREFIX}SearchArg], 
    $sortArg: [${TENANT_PREFIX}SortArg]
  ) {
    ${TENANT_PREFIX}leadQuestions(searchArg: $searchArg, sortArg: $sortArg) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const GET_PAGINATED_LEAD_QUESTIONS = gql`
  ${LEAD_QUESTION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedLeadQuestions(
    $pageArg: ${TENANT_PREFIX}PageArg, 
    $searchArg: [${TENANT_PREFIX}SearchArg]
  ) {
    ${TENANT_PREFIX}paginatedLeadQuestions(pageArg: $pageArg, searchArg: $searchArg) {
      data {
        ...LeadQuestionFragment
        ...BaseFragment
      }
      pageInfo {
        count
        total
        page
        pageCount
      }
    }
  }
`;

export const CREATE_LEAD_QUESTION = gql`
  ${LEAD_QUESTION_FRAGMENT}
  mutation ${TENANT_PREFIX}createLeadQuestion($leadQuestion: ${TENANT_PREFIX}LeadQuestionInput!) {
    ${TENANT_PREFIX}createLeadQuestion(leadQuestion: $leadQuestion) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_LEAD_QUESTIONS = gql`
  ${LEAD_QUESTION_FRAGMENT}
  mutation ${TENANT_PREFIX}createLeadQuestions($leadQuestions: [${TENANT_PREFIX}LeadQuestionInput!]!) {
    ${TENANT_PREFIX}createLeadQuestions(leadQuestions: $leadQuestions) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LEAD_QUESTION = gql`
  ${LEAD_QUESTION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateLeadQuestion(
    $${TENANT_PREFIX}updateLeadQuestionId: String!, 
    $leadQuestion: ${TENANT_PREFIX}LeadQuestionInput!
  ) {
    ${TENANT_PREFIX}updateLeadQuestion(id: $${TENANT_PREFIX}updateLeadQuestionId, leadQuestion: $leadQuestion) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LEAD_QUESTIONS = gql`
  ${LEAD_QUESTION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateLeadQuestions($ids: [String!]!, $leadQuestions: [${TENANT_PREFIX}LeadQuestionInput!]!) {
    ${TENANT_PREFIX}updateLeadQuestions(ids: $ids, leadQuestions: $leadQuestions) {
      ...LeadQuestionFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_LEAD_QUESTION = gql`
  mutation ${TENANT_PREFIX}deleteLeadQuestion($${TENANT_PREFIX}deleteLeadQuestionId: String!) {
    ${TENANT_PREFIX}deleteLeadQuestion(id: $${TENANT_PREFIX}deleteLeadQuestionId)
  }
`;

export const DELETE_LEAD_QUESTIONS = gql`
  mutation ${TENANT_PREFIX}deleteLeadQuestions($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLeadQuestions(ids: $ids)
  }
`;

export const EXPORT_LEAD_QUESTIONS_CSV = gql`
  query ${TENANT_PREFIX}LeadQuestionCSV(
    $columnArg: [${TENANT_PREFIX}ColumnArg!],
    $searchArg: [${TENANT_PREFIX}SearchArg!],
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}LeadQuestionCSV(
      columnArg: $columnArg,
      searchArg: $searchArg,
      sortArg: $sortArg
    )
  }
`;
