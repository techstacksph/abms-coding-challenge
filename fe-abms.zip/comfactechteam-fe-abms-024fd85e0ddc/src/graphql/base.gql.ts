import { disableFragmentWarnings, gql } from '@apollo/client';

if (process.env.NODE_ENV == 'test') {
  disableFragmentWarnings();
}

export const getBaseFragment = model => gql`
  fragment BaseFragment on ${model} {
    createdAt
    createdBy
    updatedAt
    updatedBy
    updatedByName
    createdByName
  }
`;

export const getBaseFragmentWithUniqueName = model => gql`
  fragment BaseFragment_${model} on ${model} {
    createdAt
    createdBy
    updatedAt
    updatedBy
    updatedByName
    createdByName
  }
`;
