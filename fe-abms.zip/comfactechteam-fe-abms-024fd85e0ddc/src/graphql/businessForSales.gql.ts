import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}BusinessForSale`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const BUSINESS_FOR_SALES_FRAGMENT = gql`
  fragment BusinessForSalesFragment on ${MODEL_NAME} {
    id
    businessNo
    businessValue
    equipmentPrice
    vehiclePrice
    vehicleYear
    monthlyWorklevelAmount
    doYouHaveABuyer
    reasonForSelling
    franchisee {
      id
      name
      physicalAddress
      primaryContact {
        id
        firstName
        lastName
      }
    }
    processor {
      id
      firstName
      lastName
      fullName
    }
    location {
      id
      name
    }
    status {
      id
      name
    }
    relatedUserAccount {
      id
      firstName
      lastName
      fullName
    }
    orgId
    recordLocked
    lockedBy
    timeLocked
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_BUSINESS_FOR_SALES = gql`
  ${BUSINESS_FOR_SALES_FRAGMENT}
  query ${TENANT_PREFIX}paginatedBusinessForSales($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedBusinessForSales(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...BusinessForSalesFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_BUSINESS_FOR_SALES = gql`
  ${BUSINESS_FOR_SALES_FRAGMENT}
  query ${TENANT_PREFIX}businessForSales($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}businessForSales(sortArg: $sortArg, searchArg: $searchArg) {
      ...BusinessForSalesFragment
      ...BaseFragment
    }
  }
`;

export const ALL_BUSINESS_FOR_SALES_IDS = gql`
  query ${TENANT_PREFIX}businessForSales($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}businessForSales(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_BUSINESS_FOR_SALES = gql`
  query ${TENANT_PREFIX}businessForSales($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}businessForSales(sortArg: $sortArg, searchArg: $searchArg) {
      id
      businessNo
    }
  }
`;

export const FIND_BUSINESS_FOR_SALES_BY_ID = gql`
  ${BUSINESS_FOR_SALES_FRAGMENT}
  query ${TENANT_PREFIX}findBusinessForSaleById($${TENANT_PREFIX}findBusinessForSaleByIdId: String!) {
    ${TENANT_PREFIX}findBusinessForSaleById(id: $${TENANT_PREFIX}findBusinessForSaleByIdId) {
      ...BusinessForSalesFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_BUSINESS_FOR_SALES_BY_ID = gql`
  ${BUSINESS_FOR_SALES_FRAGMENT}
  mutation ${TENANT_PREFIX}updateBusinessForSale($businessForSale: ${TENANT_PREFIX}BusinessForSaleInput!, $${TENANT_PREFIX}updateBusinessForSalesId: String!) {
    ${TENANT_PREFIX}updateBusinessForSale(businessForSale: $businessForSale, id: $${TENANT_PREFIX}updateBusinessForSalesId) {
      ...BusinessForSalesFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_BUSINESS_FOR_SALES = gql`
  ${BUSINESS_FOR_SALES_FRAGMENT}
  mutation ${TENANT_PREFIX}createBusinessForSale($businessForSale: ${TENANT_PREFIX}BusinessForSaleInput!) {
    ${TENANT_PREFIX}createBusinessForSale(businessForSale: $businessForSale) {
      ...BusinessForSalesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_BUSINESS_FOR_SALES = gql`
  mutation ${TENANT_PREFIX}deleteBusinessForSales($ids: [String!]!) {
    ${TENANT_PREFIX}deleteBusinessForSales(ids: $ids)
  }
`;

export const DELETE_BUSINESS_FOR_SALES_MULTIPLE = gql`
  mutation ${TENANT_PREFIX}deleteBusinessForSaleMultiple($ids: [String!]!) {
    ${TENANT_PREFIX}deleteBusinessForSalesMultiple(ids: $ids)
  }
`;

export const UPDATE_BUSINESS_FOR_SALES_STATUS = gql`
  mutation ${TENANT_PREFIX}updateBusinessForSaleStatus($${TENANT_PREFIX}updateBusinessForSalesStatusId: String!, $status: String!) {
    ${TENANT_PREFIX}updateBusinessForSalesStatus(id: $${TENANT_PREFIX}updateBusinessForSalesStatusId, status: $status) {
      id
    }
  }
`;

// Corrected query for activity component - fixes GraphQL validation issues
export const FIND_BUSINESS_FOR_SALE_BY_ID_FOR_ACTIVITY = gql`
  query ${TENANT_PREFIX}findBusinessForSaleById($${TENANT_PREFIX}findBusinessForSaleByIdId: String!) {
    ${TENANT_PREFIX}findBusinessForSaleById(id: $${TENANT_PREFIX}findBusinessForSaleByIdId) {
      id
      businessNo
      businessValue
      franchisee {
        id
        name
        physicalAddress
        primaryContact {
          id
          firstName
          lastName
        }
      }
      processor {
        id
        firstName
        lastName
        fullName
      }
      location {
        id
        name
      }
      status {
        id
        name
      }
      relatedUserAccount {
        id
        firstName
        lastName
        fullName
      }
      orgId
      recordLocked
      lockedBy
      timeLocked
      ...BaseFragment
    }
  }
  ${BASE_FRAGMENT}
`;

export const BUSINESS_FOR_SALE_DASHBOARD = gql`
  query ${TENANT_PREFIX}businessForSaleDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}businessForSaleDashboard(dashboardArg: $dashboardArg) {
    all
    ayrAcceptedSale
    ayrDeclinedSale
    submitted
    }
  }
`;
