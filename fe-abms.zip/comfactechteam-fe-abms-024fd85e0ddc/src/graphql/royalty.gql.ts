import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}RoyaltySheet`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ROYALTY_SHEET_FRAGMENT = gql`
  fragment RoyaltySheetFragment on ${MODEL_NAME} {
    id
    royaltySheetNo
    date
    location {
      id
      name
    }
    status {
      id
      name
      color
      bgColor
    }
    ${BASE_FRAGMENT}
  }
`;

export const PAGINATED_ROYALTY_SHEETS = gql`
  query PaginatedRoyaltySheets(
    $sortArg: [SortArg]
    $searchArg: [SearchArg]
    $paginationArg: PaginationArg
  ) {
    ${TENANT_PREFIX}paginatedRoyaltySheets(
      sortArg: $sortArg
      searchArg: $searchArg
      paginationArg: $paginationArg
    ) {
      paginatedData {
        ...RoyaltySheetFragment
      }
      pageInfo {
        count
        pageCount
        hasNext
        hasPrevious
      }
    }
  }
  ${ROYALTY_SHEET_FRAGMENT}
`;

export const ALL_ROYALTY_SHEETS = gql`
  query AllRoyaltySheets($sortArg: [SortArg], $searchArg: [SearchArg]) {
    ${TENANT_PREFIX}allRoyaltySheets(sortArg: $sortArg, searchArg: $searchArg) {
      ...RoyaltySheetFragment
    }
  }
  ${ROYALTY_SHEET_FRAGMENT}
`;
