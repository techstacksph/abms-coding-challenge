import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Companies`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const COMPANIES_FRAGMENT = gql`
  fragment CompaniesFragment on ${MODEL_NAME} {
    id
    industryId
    fullName
    accountId
    bAreaId
    bCity
    bCountry
    bFindAddress
    bPostalCode
    bRegion
    bStreetAddress
    orgId
    createdAt
    updatedAt
    deletedAt
    createdBy
    updatedByName
    updatedBy
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    companyName
    parentCompanyId
    notes
    contactId
    phoneNo
    mobileNo
    email
    website
    locationId
    recordOwnerId
    pFindAddress
    pStreetAddress
    pSuburb
    pCity
    pAreaId
    pRegion
    pPostalCode
    pCountry
    bSuburb
    isSamePhysicalAddress
    location {
      id
      name
    }
    parentCompanies {
      id
      companyName
    }
    recordOwner {
      id
      fullName
    }
    childCompanies {
      id
      companyName
    }
    industry {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_COMPANIES = gql`
  ${COMPANIES_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedCompanies {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...CompaniesFragment
        ...CompaniesFragment
      }
    }
  }
`;

export const ALL_COMPANIES = gql`
  ${COMPANIES_FRAGMENT}
  query ${TENANT_PREFIX}companiess($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}companiess(sortArg: $sortArg, searchArg: $searchArg) {
      ...CompaniesFragment
      ...BaseFragment
    }
  }
`;

export const FIND_COMPANIES_BY_ID = gql`
  ${COMPANIES_FRAGMENT}
  query ${TENANT_PREFIX}findCompaniesById($${TENANT_PREFIX}findCompaniesByIdId: String!) {
    ${TENANT_PREFIX}findCompaniesById(id: $${TENANT_PREFIX}findCompaniesByIdId) {
      ...CompaniesFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_COMPANIES_BY_ID = gql`
  ${COMPANIES_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCompanies($companies: ${TENANT_PREFIX}CompaniesInput!, $${TENANT_PREFIX}updateCompaniesId: String!) {
    ${TENANT_PREFIX}updateCompanies(companies: $companies, id: $${TENANT_PREFIX}updateCompaniesId) {
      ...CompaniesFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_COMPANIES = gql`
  ${COMPANIES_FRAGMENT}
  mutation ${TENANT_PREFIX}createCompanies($companies: abmsCompaniesInput!) {
    ${TENANT_PREFIX}createCompanies(companies: $companies) {
      ...CompaniesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_COMPANIES = gql`
  mutation ${TENANT_PREFIX}deleteCompanies($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCompanies(ids: $ids)
  }
`;

export const DELETE_COMPANY = gql`
  mutation ${TENANT_PREFIX}deleteCompany($${TENANT_PREFIX}deleteCompanyId: String!) {
    ${TENANT_PREFIX}deleteCompany(id: $${TENANT_PREFIX}deleteCompanyId)
  }
`;
