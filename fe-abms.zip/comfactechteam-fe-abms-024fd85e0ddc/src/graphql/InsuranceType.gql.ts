import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}InsuranceType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INSURANCE_TYPE_FRAGMENT = gql`
  fragment InsuranceTypeFragment on ${MODEL_NAME} {
    id
    code
    description
    name
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_INSURANCE_TYPES = gql`
  ${INSURANCE_TYPE_FRAGMENT}
  query paginatedInsuranceTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedInsuranceTypes(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...InsuranceTypeFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_INSURANCE_TYPES = gql`
  query ${TENANT_PREFIX}insuranceTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}insuranceTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
      name
      code
      description
      updatedAt
      updatedBy
    }
  }
`;

export const ALL_INSURANCE_TYPES_IDS = gql`
  query ${TENANT_PREFIX}insuranceTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}insuranceTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_INSURANCE_TYPE_BY_ID = gql`
  ${INSURANCE_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}findInsuranceTypeById($${TENANT_PREFIX}findInsuranceTypeByIdId: String!) {
    ${TENANT_PREFIX}findInsuranceTypeById(id: $${TENANT_PREFIX}findInsuranceTypeByIdId) {
      ...InsuranceTypeFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_INSURANCE_TYPES = gql`
  query ${TENANT_PREFIX}insuranceTypes{
    ${TENANT_PREFIX}insuranceTypes{
      id
      name
    }
  }
`;

export const CREATE_INSURANCE_TYPE = gql`
  ${INSURANCE_TYPE_FRAGMENT}
  mutation createInsuranceType($insuranceType: ${TENANT_PREFIX}InsuranceTypeInput!) {
    ${TENANT_PREFIX}createInsuranceType(insuranceType: $insuranceType) {
      ...InsuranceTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INSURANCE_TYPE_BY_ID = gql`
  ${INSURANCE_TYPE_FRAGMENT}
  mutation updateInsuranceType($insuranceType: ${TENANT_PREFIX}InsuranceTypeInput!, $${TENANT_PREFIX}updateInsuranceTypeId: String!) {
    ${TENANT_PREFIX}updateInsuranceType(insuranceType: $insuranceType, id: $${TENANT_PREFIX}updateInsuranceTypeId) {
      ...InsuranceTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_INSURANCE_TYPE = gql`
  mutation ${TENANT_PREFIX}deleteInsuranceType($${TENANT_PREFIX}deleteInsuranceTypeId: String!) {
    ${TENANT_PREFIX}deleteInsuranceType(id: $${TENANT_PREFIX}deleteInsuranceTypeId)
  } 
`;

export const DELETE_INSURANCE_TYPES = gql`
  mutation deleteInsuranceTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteInsuranceTypes(ids: $ids)
  }
`;

export const GET_INSURANCE_TYPES_CSV = gql`
  query ${TENANT_PREFIX}insuranceTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}InsuranceTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
