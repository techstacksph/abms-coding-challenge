import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CheckList`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CHECKLIST_FRAGMENT = gql`
  fragment ChecklistFragment on ${MODEL_NAME} {
    id
    description
    name
    status {
      name
      id
    }
    checklist {
      id
      checklist
      description
      updatedAt
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_CHECKLISTS = gql`
  ${CHECKLIST_FRAGMENT}
  query AbmspaginatedCheckList(
    $searchArg: [abmsSearchArg!]
    $pageArg: abmsPageArg
  ) {
    abmspaginatedCheckList(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ChecklistFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CHECKLISTS = gql`
  ${CHECKLIST_FRAGMENT}
  query AbmsCheckLists($sortArg: [abmsSortArg!], $searchArg: [abmsSearchArg!]) {
    abmsCheckLists(sortArg: $sortArg, searchArg: $searchArg) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;

export const ALL_CHECKLISTS_IDS = gql`
  query AbmsCheckLists($sortArg: [abmsSortArg!], $searchArg: [abmsSearchArg!]) {
    abmsCheckLists(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CHECKLIST_BY_ID = gql`
  ${CHECKLIST_FRAGMENT}
  query AbmsfindCheckListById($id: String!) {
    abmsfindCheckListById(id: $id) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CHECKLIST_BY_ID = gql`
  ${CHECKLIST_FRAGMENT}
  mutation AbmsupdateCheckList(
    $checkList: abmsCheckListInput!
    $abmsupdateCheckListId: String!
  ) {
    abmsupdateCheckList(checkList: $checkList, id: $abmsupdateCheckListId) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CHECKLIST = gql`
  ${CHECKLIST_FRAGMENT}
  mutation AbmscreateCheckList($checkList: abmsCheckListInput!) {
    abmscreateCheckList(checkList: $checkList) {
      ...ChecklistFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CHECKLISTS = gql`
  mutation AbmsdeleteCheckListInformations($ids: [String!]!) {
    abmsdeleteCheckListInformations(ids: $ids)
  }
`;

export const DELETE_CHECKLIST = gql`
  mutation AbmsdeleteCheckListInformation($abmsdeleteCheckListId: String!) {
    abmsdeleteCheckListInformation(id: $abmsdeleteCheckListId)
  }
`;

export const DELETE_CHECKLISTS_DETAILS = gql`
  mutation AbmsdeleteCheckListDetails($ids: [String!]!) {
    abmsdeleteCheckListDetails(ids: $ids)
  }
`;

export const GET_CHECKLISTS_CSV = gql`
  query Query(
    $sortArg: [abmsSortArg!]
    $columnArg: [abmsColumnArg!]
    $searchArg: [abmsSearchArg!]
  ) {
    abmsCheckListCSV(
      sortArg: $sortArg
      columnArg: $columnArg
      searchArg: $searchArg
    )
  }
`;
