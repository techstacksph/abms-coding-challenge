import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}SalesOrderItem`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

const SALES_ORDER_ITEM_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment SalesOrderItemFragment on ${MODEL_NAME} {
      id
      quantity
      amount
      lineNo
      stockonhand
      backOrderQuantity
      salesorder {
        id
        soNo
      }
      item {
        id
        name
        description
        productImage
        itemCode
        pricing
      }
      uomId
      status {
        id
        name
      }
      invoiceDetailId
      invoiceDetail {
        id
      }
      ...BaseFragment
    }
`;

const SALES_ORDER_ITEM_BY_ID_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment SalesOrderItemFragment on ${MODEL_NAME} {
      id
      quantity
      amount
      stockonhand
      backOrderQuantity
      drQuantity {
        id
        name
      }
      salesorder {
        id
        soNo
      }
      items {
        id
        name
        description
        code
        price
      }
      uomId
      status {
        id
        name
      }
      ...BaseFragment
    }
`;

export const ALL_SALES_ORDER_ITEMS = gql`
  ${SALES_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}salesOrderItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}salesOrderItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...SalesOrderItemFragment
    }
  }
`;

export const PAGINATED_SALES_ORDER_ITEMS = gql`
  ${SALES_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}paginatedSalesOrderItems($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedSalesOrderItems(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...SalesOrderItemFragment
      }
      pageInfo {
        count
        pageCount
        pageSize
        skip
        take
      }
    }
  }
`;

export const FIND_SALES_ORDER_ITEM_BY_ID = gql`
  ${SALES_ORDER_ITEM_BY_ID_FRAGMENT}
  query ${TENANT_PREFIX}findSalesOrderItemById($id: String!) {
    ${TENANT_PREFIX}findSalesOrderItemById(id: $id) {
      ...SalesOrderItemFragment
    }
  }
`;

export const FIND_SALES_ORDER_ITEMS_BY_SALES_ORDER_ID = gql`
  ${SALES_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}salesOrderItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}salesOrderItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...SalesOrderItemFragment
    }
  }
`;

export const DELETE_SALES_ORDER_ITEM_BY_IDS = gql`
  mutation ${TENANT_PREFIX}deleteSalesOrderItems($ids: [String!]!) {
    ${TENANT_PREFIX}deleteSalesOrderItems(ids: $ids)
  }
`;

export const DELETE_SALES_ORDER_ITEM_BY_ID = gql`
  mutation ${TENANT_PREFIX}deleteSalesOrderItem($id: String!) {
    ${TENANT_PREFIX}deleteSalesOrderItem(id: $id)
  }
`;

export const UPDATE_SALES_ORDER_ITEM_STATUS = gql`
  mutation ${TENANT_PREFIX}updateSalesOrderItemStatus(
    $status: ${TENANT_PREFIX}WorkflowStatusInput!, 
    $id: String!) {
    ${TENANT_PREFIX}updateSalesOrderItemStatus(status: $status, id: $id) {
      id
    }
  }
`;

export const CREATE_SALES_ORDER_ITEM = gql`
  mutation ${TENANT_PREFIX}createSalesOrderItem($input: ${TENANT_PREFIX}SalesOrderItemInput!) {
    ${TENANT_PREFIX}createSalesOrderItem(salesOrderItemInput: $input) {
      id
    }
  }
`;

export const UPDATE_SALES_ORDER_ITEM = gql`
  mutation ${TENANT_PREFIX}updateSalesOrderItem($input: ${TENANT_PREFIX}SalesOrderItemInput!, $id: String!) {
    ${TENANT_PREFIX}updateSalesOrderItem(salesOrderItemInput: $input, id: $id) {
      id
    }
  }
`;

export const BULK_CREATE_SALES_ORDER_ITEMS = gql`
  mutation ${TENANT_PREFIX}bulkCreateSalesOrderItems($inputs: [${TENANT_PREFIX}SalesOrderItemInput!]!) {
    ${TENANT_PREFIX}bulkCreateSalesOrderItems(salesOrderItemInputs: $inputs) {
      id
    }
  }
`;

// Query to fetch sales order items for minimum level calculation
// Returns SO items for a specific item where the parent SO is completed
export const GET_COMPLETED_SALES_ORDER_ITEMS_BY_ITEM = gql`
  query ${TENANT_PREFIX}salesOrderItemsForMinLevel($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}salesOrderItems(sortArg: $sortArg, searchArg: $searchArg) {
      id
      quantity
      itemId
      salesorder {
        id
        soNo
        status {
          id
          name
        }
      }
    }
  }
`;