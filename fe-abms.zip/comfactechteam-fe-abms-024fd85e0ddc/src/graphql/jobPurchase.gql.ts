import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'JobPurchase';
const TITLE_FRAGMENT = 'JobPurchaseFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_JOB_PURCHASES_TITLE = 'paginatedJobPurchases';
const MARKETPLACE_JOB_PURCHASE_TITLE = `${TENANT_PREFIX}MarketplaceJobPurchase`;

export const MARKETPLACE_JOB_PURCHASES_FRAGMENT = gql`
  fragment MarketplaceJobPurchasesFragment on ${MARKETPLACE_JOB_PURCHASE_TITLE} {
    id
    jobPurchase{
      id
      createdAt
      jobPurchaseNo
      platformId
      brandFeeCur
      brandFeeNew
      collectionFeeCur
      collectionFeeNew
      deposit
      depositAmount
      finance
      monthlyDeposit
      monthlyIncomeCur
      monthlyIncomeNew
      monthlyWorkLevelCur
      monthlyWorkLevelNew
      paymentMonth
      royaltyFeeCur
      royaltyFeeNew
      status {
        id
        name
      }
      techFeeCur
      techFeeNew
      weeklyIncomeCur
      weeklyIncomeNew
      weeklyWorkLevelCur
      weeklyWorkLevelNew
      account{
        id
        name
      }
      location{
        id
        name
      }
    }
    marketplace{
      id
    }
  }
`;

export const JOB_PURCHASE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    orgId
    jobPurchaseNo
    platformId
    brandFeeCur
    brandFeeNew
    collectionFeeCur
    collectionFeeNew
    deposit
    depositAmount
    finance
    monthlyDeposit
    monthlyIncomeCur
    monthlyIncomeNew
    monthlyWorkLevelCur
    monthlyWorkLevelNew
    paymentMonth
    royaltyFeeCur
    royaltyFeeNew
    statusId
    status {
      id
      name
    }
    techFeeCur
    techFeeNew
    weeklyIncomeCur
    weeklyIncomeNew
    weeklyWorkLevelCur
    weeklyWorkLevelNew
    location {
    id
    name
    }
    account {
      id
      name
      accountType
      primaryContact {
        id
        firstName
        lastName
        fullName
        phone
        mobile
        email
        jobTitle
      }
    }
    marketplaceJobPurchases {
      id
      jobPurchaseId
      marketplaceId
      marketplace {
        id
      }
    }
    recordLocked
    lockedBy
    timeLocked
    deletedAt
    deletedBy
  }
  ${BASE_FRAGMENT}
`;

export const JOB_PURCHASE_BY_ID_FRAGMENT = gql`
  fragment JobPurchaseByIdFragment on ${MODEL_NAME} {
    id
    orgId
    jobPurchaseNo
    platformId
    brandFeeCur
    brandFeeNew
    collectionFeeCur
    collectionFeeNew
    deposit
    depositAmount
    finance
    monthlyDeposit
    monthlyIncomeCur
    monthlyIncomeNew
    monthlyWorkLevelCur
    monthlyWorkLevelNew
    paymentMonth
    royaltyFeeCur
    royaltyFeeNew
    statusId
    status {
      id
      name
      description
    }
    techFeeCur
    techFeeNew
    weeklyIncomeCur
    weeklyIncomeNew
    weeklyWorkLevelCur
    weeklyWorkLevelNew
    account {
      id
      name
      accountType
      primaryContact {
        id
        firstName
        lastName
        fullName
        phone
        mobile
        email
        jobTitle
      }
    }
    location {
      id
      name
    }
    marketplaceJobPurchases {
      id
      orgId
      jobPurchaseId
      marketplaceId
      marketplace {
        id
      }
      recordLocked
      lockedBy
      timeLocked
    }
    recordLocked
    lockedBy
    timeLocked
    deletedAt
    deletedBy
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_JOB_PURCHASES = gql`
  ${JOB_PURCHASE_FRAGMENT}
  query ${PAGINATED_JOB_PURCHASES_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOB_PURCHASES_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_JOB_PURCHASES = gql`
  ${JOB_PURCHASE_FRAGMENT}
  query ${TENANT_PREFIX}jobPurchases($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobPurchases(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_JOB_PURCHASE = gql`
  mutation ${TENANT_PREFIX}deleteJobPurchase($${TENANT_PREFIX}deleteJobPurchaseId: String!) {
    ${TENANT_PREFIX}deleteJobPurchase(id: $${TENANT_PREFIX}deleteJobPurchaseId)
  }
`;

export const DELETE_JOB_PURCHASES = gql`
  mutation ${TENANT_PREFIX}deleteJobPurchases($ids: [String!]!) {
    ${TENANT_PREFIX}deleteJobPurchases(ids: $ids)
  }
`;

export const UPDATE_JOB_PURCHASE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateJobPurchaseStatus($${TENANT_PREFIX}updateJobPurchaseStatusId: String!, $status: ${TENANT_PREFIX}JobPurchaseStatusInput!) {
    ${TENANT_PREFIX}updateJobPurchaseStatus(id: $${TENANT_PREFIX}updateJobPurchaseStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_JOB_PURCHASE = gql`
  mutation ${TENANT_PREFIX}updateJobPurchase($jobPurchase: ${TENANT_PREFIX}JobPurchaseInput!, $${TENANT_PREFIX}updateJobPurchaseId: String!) {
    ${TENANT_PREFIX}updateJobPurchase(jobPurchase: $jobPurchase, id: $${TENANT_PREFIX}updateJobPurchaseId) {
      id
    }
  }
`;

export const FIND_JOB_PURCHASE_BY_ID = gql`
  query ${TENANT_PREFIX}findJobPurchaseById($${TENANT_PREFIX}findJobPurchaseByIdId: String!) {
    ${TENANT_PREFIX}findJobPurchaseById(id: $${TENANT_PREFIX}findJobPurchaseByIdId) {
      ...JobPurchaseByIdFragment
      ...BaseFragment
    }
  }
  ${JOB_PURCHASE_BY_ID_FRAGMENT}
`;

export const ALL_JOB_PURCHASE_IDS = gql`
  query ${TENANT_PREFIX}allJobPurchaseIds($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobPurchases(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const PAGINATED_MARKETPLACE_JOB_PURCHASES = gql`
  ${MARKETPLACE_JOB_PURCHASES_FRAGMENT}
  query ${TENANT_PREFIX}paginatedMarketplaceJobPurchases($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedMarketplaceJobPurchases(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...MarketplaceJobPurchasesFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_MARKETPLACE_JOB_PURCHASES = gql`
${MARKETPLACE_JOB_PURCHASES_FRAGMENT}
  query ${TENANT_PREFIX}marketplaceJobPurchases($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}marketplaceJobPurchases(sortArg: $sortArg, searchArg: $searchArg) {
      ...MarketplaceJobPurchasesFragment
    }
  }
`;
