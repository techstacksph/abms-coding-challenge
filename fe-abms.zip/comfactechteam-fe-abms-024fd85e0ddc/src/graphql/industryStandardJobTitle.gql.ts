import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Industry`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INDUSTRY_FRAGMENT = gql`
  fragment IndustryFragment on ${MODEL_NAME} {
    id
    name
  }

  ${BASE_FRAGMENT}
`;

export const ALL_INDUSTRY_STANDARAD = gql`
  ${INDUSTRY_FRAGMENT}
  query ${TENANT_PREFIX}industrieStandardJobTitles($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}industrieStandardJobTitles(sortArg: $sortArg, searchArg: $searchArg) {
      ...IndustryFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_INDUSTRY_STANDARDS = gql`
  query industrieStandardJobTitles {
      ${TENANT_PREFIX}industrieStandardJobTitles {
        id
        name
      }
    }
`;
