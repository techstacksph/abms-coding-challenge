import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

// Assuming this file exists and exports the base fragment

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PurchaseOrderItem`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PURCHASE_ORDER_ITEM_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment PurchaseOrderItemFragment on ${MODEL_NAME} {
    id
    orgId
    platformId
    purchaseOrderId
    lineNo
    quantity
    unitPrice
    amount
    drQuantity
    backOrderQuantity
    deliveryDate
    itemId
    referenceId
    soldToId
    statusId
    uomId
    recordLocked
    lockedBy
    timeLocked
    item {
      id
      name
      description
      itemCode
    }
    reference {
      id
    }
    soldTo {
      id
      name
    }
    status {
      id
      name
    }
    uom {
      id
      name
    }
    ...BaseFragment
  }
`;

export const PURCHASE_ORDER_ITEM_BY_ID_FRAGMENT = gql`
  ${BASE_FRAGMENT}
  fragment PurchaseOrderItemByIdFragment on ${MODEL_NAME} {
    id
    orgId
    platformId
    purchaseOrderId
    lineNo
    quantity
    unitPrice
    amount
    drQuantity
    backOrderQuantity
    deliveryDate
    itemId
    referenceId
    soldToId
    statusId
    uomId
    recordLocked
    lockedBy
    timeLocked
    item {
      id
      name
      description
      productImage
      itemCode
    }
    reference {
      id
    }
    soldTo {
      id
      name
    }
    status {
      id
      name
    }
    uom {
      id
      name
    }
    ...BaseFragment
  }
`;

export const ALL_PURCHASE_ORDER_ITEMS = gql`
  ${PURCHASE_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}purchaseOrderItems($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}purchaseOrderItems(sortArg: $sortArg, searchArg: $searchArg) {
      ...PurchaseOrderItemFragment
    }
  }
`;

export const PAGINATED_PURCHASE_ORDER_ITEMS = gql`
  ${PURCHASE_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}paginatedPurchaseOrderItems($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedPurchaseOrderItems(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...PurchaseOrderItemFragment
      }
      pageInfo {
        count
        pageCount
        pageSize
        skip
        take
      }
    }
  }
`;

export const FIND_PURCHASE_ORDER_ITEM_BY_ID = gql`
  ${PURCHASE_ORDER_ITEM_BY_ID_FRAGMENT}
  query ${TENANT_PREFIX}findPurchaseOrderItemById($id: String!) {
    ${TENANT_PREFIX}findPurchaseOrderItemById(id: $id) {
      ...PurchaseOrderItemByIdFragment
    }
  }
`;

export const FIND_PURCHASE_ORDER_ITEMS_BY_PURCHASE_ORDER_ID = gql`
  ${PURCHASE_ORDER_ITEM_FRAGMENT}
  query ${TENANT_PREFIX}findPurchaseOrderItemsByPurchaseOrderId($purchaseOrderId: String!) {
    ${TENANT_PREFIX}findPurchaseOrderItemsByPurchaseOrderId(purchaseOrderId: $purchaseOrderId) {
      ...PurchaseOrderItemFragment
    }
  }
`;

export const DELETE_PURCHASE_ORDER_ITEM_BY_IDS = gql`
  mutation ${TENANT_PREFIX}deletePurchaseOrderItems($ids: [String!]!) {
    ${TENANT_PREFIX}deletePurchaseOrderItems(ids: $ids)
  }
`;

export const DELETE_PURCHASE_ORDER_ITEM_BY_ID = gql`
  mutation ${TENANT_PREFIX}deletePurchaseOrderItem($id: String!) {
    ${TENANT_PREFIX}deletePurchaseOrderItem(id: $id)
  }
`;

export const UPDATE_PURCHASE_ORDER_ITEM_STATUS = gql`
  mutation ${TENANT_PREFIX}updatePurchaseOrderItemStatus(
    $statusId: String!,
    $id: String!
  ) {
    ${TENANT_PREFIX}updatePurchaseOrderItemStatus(statusId: $statusId, id: $id) {
      id
    }
  }
`;

export const CREATE_PURCHASE_ORDER_ITEM = gql`
  mutation ${TENANT_PREFIX}createPurchaseOrderItem($input: ${TENANT_PREFIX}PurchaseOrderItemInput!) {
    ${TENANT_PREFIX}createPurchaseOrderItem(purchaseOrderItem: $input) {
      id
    }
  }
`;

export const UPDATE_PURCHASE_ORDER_ITEM = gql`
  mutation ${TENANT_PREFIX}updatePurchaseOrderItem($input: ${TENANT_PREFIX}PurchaseOrderItemInput!, $id: String!) {
    ${TENANT_PREFIX}updatePurchaseOrderItem(purchaseOrderItem: $input, id: $id) {
      id
    }
  }
`;

export const BULK_CREATE_PURCHASE_ORDER_ITEMS = gql`
  mutation ${TENANT_PREFIX}bulkCreatePurchaseOrderItems($inputs: [${TENANT_PREFIX}PurchaseOrderItemInput!]!) {
    ${TENANT_PREFIX}bulkCreatePurchaseOrderItems(purchaseOrderItems: $inputs) {
      id
    }
  }
`;

// Query to fetch purchase order items for minimum level calculation
// Returns PO items for a specific item
export const GET_PURCHASE_ORDER_ITEMS_BY_ITEM = gql`
  query ${TENANT_PREFIX}purchaseOrderItemsForMinLevel($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}purchaseOrderItems(sortArg: $sortArg, searchArg: $searchArg) {
      id
      purchaseOrderId
      itemId
    }
  }
`;