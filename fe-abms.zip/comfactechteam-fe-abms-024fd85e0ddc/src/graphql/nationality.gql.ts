import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Nationality`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const NATIONALITY_FRAGMENT = gql`
  fragment NationalityFragment on ${MODEL_NAME} {
    id
    name
  }

  ${BASE_FRAGMENT}
`;

export const ALL_NATIONALITIES = gql`
  ${NATIONALITY_FRAGMENT}
  query ${TENANT_PREFIX}nationalities($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}nationalities(searchArg: $searchArg, sortArg: $sortArg) {
      ...NationalityFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_NATIONALITIES = gql`
  query nationalities {
      ${TENANT_PREFIX}nationalities {
        id
        name
      }
    }
`;
