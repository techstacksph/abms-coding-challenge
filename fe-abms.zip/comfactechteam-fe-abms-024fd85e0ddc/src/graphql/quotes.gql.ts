import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Quote`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const QUOTE_FRAGMENT = gql`
  fragment QuoteFragment on ${MODEL_NAME} {
    id
    orgId
    createdAt
    updatedAt
    deletedAt
    createdBy
    updatedByName
    createdByName
    updatedBy
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    dealId
    quoteNo
    autoNumber
    file
    coverLetter
    approvalDateTime
    dealAmount
    statusId
    approvalDateTime
    attachment1
    attachment2
    attachment3
    attachment4
    attachment5
    signature
    notes{
    id
    createdAt
    createdBy
    createdByName
    updatedAt
    updatedBy
    updatedByName
    notes
    }
    declinedNotes
    signedQuote
    signedQuoteKey
    pdfFile
    pdfFileKey
    status{
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_QUOTES = gql`
  ${QUOTE_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedQuotes {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...QuoteFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_QUOTES_TYPE = gql`
  query ${TENANT_PREFIX}quoteTypes {
    ${TENANT_PREFIX}quoteTypes {
      id
      name
    }
  }
`;

export const ALL_QUOTES = gql`
  ${QUOTE_FRAGMENT}
  query ${TENANT_PREFIX}quotes($sortArg: [abmsSortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}quotes(sortArg: $sortArg, searchArg: $searchArg) {
      ...QuoteFragment
      ...BaseFragment
    }
  }
`;

export const ALL_MODULES = gql`
  query ${TENANT_PREFIX}modules {
    abmsmodules {
      code
      id
      name
      isIncludedInQuote
    }
  }
`;

export const ALL_QUOTE_TYPE = gql`
  query ${TENANT_PREFIX}quoteTypes {
    ${TENANT_PREFIX}quoteTypes {
      id
      name
    }
  }
`;

export const FIND_QUOTE_BY_ID = gql`
  ${QUOTE_FRAGMENT}
  query ${TENANT_PREFIX}findQuoteById($${TENANT_PREFIX}findQuoteByIdId: String!) {
    ${TENANT_PREFIX}findQuoteById(id: $${TENANT_PREFIX}findQuoteByIdId) {
      ...QuoteFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_QUOTE_BY_ID = gql`
  ${QUOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateQuote($quote: ${TENANT_PREFIX}QuoteInput!, $${TENANT_PREFIX}updateQuoteId: String!) {
    ${TENANT_PREFIX}updateQuote(quote: $quote, id: $${TENANT_PREFIX}updateQuoteId) {
      ...QuoteFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_QUOTES = gql`
  mutation ${TENANT_PREFIX}createQuote($quote: abmsQuoteInput!) {
    ${TENANT_PREFIX}createQuote(quote: $quote) {
      id
      quoteNo
    }
  }
`;

export const CREATE_ASSIGNEE = gql`
  mutation ${TENANT_PREFIX}createQuoteAssignees($quoteAssignees: [${TENANT_PREFIX}QuoteAssigneeInput!]!) {
    ${TENANT_PREFIX}createQuoteAssignees(quoteAssignees: $quoteAssignees) {
      id
    }
  }
`;

export const CREATE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}createQuoteWatchers($quoteWatchers: [${TENANT_PREFIX}QuoteWatcherInput!]!) {
    ${TENANT_PREFIX}createQuoteWatchers(quoteWatchers: $quoteWatchers) {
      id
    }
  }
`;

export const DELETE_QUOTES = gql`
  mutation ${TENANT_PREFIX}deleteQuotes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQuotes(ids: $ids)
  }
`;

export const DELETE_QUOTE = gql`
  mutation ${TENANT_PREFIX}deleteQuote($${TENANT_PREFIX}deleteQuoteId: String!) {
    ${TENANT_PREFIX}deleteQuote(id: $${TENANT_PREFIX}deleteQuoteId)
  }
`;

export const DELETE_ASSIGNEE = gql`
  mutation ${TENANT_PREFIX}deleteQuoteAssignees($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQuoteAssignees(ids: $ids)
  }
`;

export const DELETE_WATCHERS = gql`
  mutation ${TENANT_PREFIX}deleteQuoteWatchers($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQuoteWatchers(ids: $ids)
  }
`;

export const UPDATE_QUOTE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateQuoteStatus($${TENANT_PREFIX}updateQuoteStatusId: String!, $status: ${TENANT_PREFIX}QuoteStatusInput!) {
    ${TENANT_PREFIX}updateQuoteStatus(id: $${TENANT_PREFIX}updateQuoteStatusId, status: $status) {
      id
      quoteNo
    }
  }
`;

export const SELECT_QUOTE_TYPE = gql`
  query ${TENANT_PREFIX}quoteTypes {
    ${TENANT_PREFIX}quoteTypes {
      id
      name
      code
    }
  }
`;

export const QUOTE_WORKFLOW_STATUS = gql`
  query ${TENANT_PREFIX}workflowProcesses($searchArg: [abmsSearchArg!]) {
    ${TENANT_PREFIX}workflowProcesses(searchArg: $searchArg) {
      id
      name
      workflowStatuses {
        id
        name
      }
    }
  }
`;

export const GET_QUOTES_DASHBOARD = gql`
  query ${TENANT_PREFIX}quotesDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}quotesDashboard(dashboardArg: $dashboardArg) {
      all
      created
      pending
      closedWon
      closedLost
    }
  }
`;

export const POST_COMMENT = gql`
  ${QUOTE_FRAGMENT}
  mutation ${TENANT_PREFIX}postComment($comment: String!, $${TENANT_PREFIX}postCommentId: String!) {
    ${TENANT_PREFIX}postComment(comment: $comment, id: $${TENANT_PREFIX}postCommentId) {
      ...QuoteFragment
      ...BaseFragment
    }
  }
`;

export const REJECT_QUOTE = gql`
  mutation ${TENANT_PREFIX}rejectQuote($statusNotes: String!, $${TENANT_PREFIX}rejectQuoteId: String!) {
    ${TENANT_PREFIX}rejectQuote(statusNotes: $statusNotes, id: $${TENANT_PREFIX}rejectQuoteId) {
      id
      quoteNo
    }
  }
`;

export const APPROVE_QUOTE = gql`
  mutation ${TENANT_PREFIX}approveQuote($preferredDate: DateTimeISO!, $${TENANT_PREFIX}approveQuoteId: String!, $attachment: String, $approverName: String, $approverTitle: String) {
    ${TENANT_PREFIX}approveQuote(preferredDate: $preferredDate, id: $${TENANT_PREFIX}approveQuoteId, attachment: $attachment, approverName: $approverName, approverTitle: $approverTitle) {
      id
      quoteNo
    }
  }
`;

export const ALL_COMMENTS = gql`
  query ${TENANT_PREFIX}allComments($id: String!) {
    ${TENANT_PREFIX}allComments(id: $id) {
      id
      createdAt
      createdBy
      createdByName
      updatedAt
      updatedBy
      updatedByName
      commType
      subjectEmail
      bodyEmail
      bodyEmailPreview
      messageSMS
      subjectCall
      callType
      callOutcome
      from
      fromEmail
      toEmail
      ccEmail
      ccEmailText
      bccEmail
      toSMS
      recipient
      account {
        id
        name
      }
      deal {
        id
      }
      quote {
        id
        quoteNo
      }
      module {
        id
        name
        code
      }
    }
  }
`;

export const PUBLIC_FIND_QUOTE_BY_ID = gql`
  query ${TENANT_PREFIX}publicFindQuoteById($id: String!) {
    ${TENANT_PREFIX}publicFindQuoteById(id: $id) {
      id
      approvalDateTime
      attachment1
      attachment2
      attachment3
      attachment4
      attachment5
      autoNumber
      communicationLogs {
        id
        createdAt
        createdBy
        createdByName
        updatedAt
        updatedBy
        updatedByName
        commType
        subjectEmail
        bodyEmail
        bodyEmailPreview
        messageSMS
        subjectCall
        callType
        callOutcome
        from
        fromEmail
        toEmail
        ccEmail
        ccEmailText
        bccEmail
        toSMS
        recipient
      }
      coverLetter
      createdAt
      createdBy
      createdByName
      deal {
        id
        preferredStartDate
      }
      dealAmount
      dealId
      deletedAt
      deletedBy
      file
      files
      lockedBy
      notes {
        id
        notes
        createdAt
        createdBy
        createdByName
        updatedAt
        updatedBy
        updatedByName
      }
      orgId
      quoteNo
      recordLocked
      salesOrder {
        id
      }
      salesOrderId
      signature
      signedQuote
      signedQuoteKey
      pdfFile
      pdfFileKey
      status {
        id
        name
      }
      statusId
      timeLocked
      updatedAt
      updatedBy
      updatedByName
    }
  }
`;
