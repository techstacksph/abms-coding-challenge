import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CaseAttachment`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CASE_ATTACHMENT_FRAGMENT = gql`
  fragment CaseAttachmentFragment on ${MODEL_NAME} {
    id
    caseAttachment
    description
    case{
      id
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CASE_ATTACHMENTS = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  query paginatedCaseAttachments($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCaseAttachments(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CaseAttachmentFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CASE_ATTACHMENTS = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  query ${TENANT_PREFIX}caseAttachments($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}caseAttachments(sortArg: $sortArg, searchArg: $searchArg) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const FIND_CASE_ATTACHMENT_BY_ID = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  query findCaseAttachmentById($${TENANT_PREFIX}findCaseAttachmentByIdId: String!) {
    ${TENANT_PREFIX}findCaseAttachmentById(id: $${TENANT_PREFIX}findCaseAttachmentByIdId) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CASE_ATTACHMENT = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  mutation updateCaseAttachment($caseAttachment: ${TENANT_PREFIX}CaseAttachmentInput!, $${TENANT_PREFIX}updateCaseAttachmentId: String!) {
    ${TENANT_PREFIX}updateCaseAttachment(caseAttachment: $caseAttachment, id: $${TENANT_PREFIX}updateCaseAttachmentId) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CASE_ATTACHMENTS = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCaseAttachments($ids: [String!]!, $caseAttachments: [${TENANT_PREFIX}CaseAttachmentInput!]!) {
    ${TENANT_PREFIX}updateCaseAttachments(ids: $ids, caseAttachments: $caseAttachments) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE_ATTACHMENT = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  mutation createCaseAttachment($caseAttachment: ${TENANT_PREFIX}CaseAttachmentInput!) {
    ${TENANT_PREFIX}createCaseAttachment(caseAttachment: $caseAttachment) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE_ATTACHMENTS = gql`
  ${CASE_ATTACHMENT_FRAGMENT}
  mutation ${TENANT_PREFIX}createCaseAttachments($caseAttachments: [${TENANT_PREFIX}CaseAttachmentInput!]!) {
    ${TENANT_PREFIX}createCaseAttachments(caseAttachments: $caseAttachments) {
      ...CaseAttachmentFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CASE_ATTACHMENT = gql`
  mutation deleteCaseAttachment($${TENANT_PREFIX}deleteCaseAttachmentById: String!) {
    ${TENANT_PREFIX}deleteCaseAttachment(id: $${TENANT_PREFIX}deleteCaseAttachmentById)
  }
`;

export const DELETE_CASE_ATTACHMENTS = gql`
  mutation deleteCaseAttachments($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCaseAttachments(ids: $ids)
  }
`;
