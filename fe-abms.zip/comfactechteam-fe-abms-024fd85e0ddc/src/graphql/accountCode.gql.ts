import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}AccountCode`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ACCOUNT_CODE_FRAGMENT = gql`
  fragment AccountCodeFragment on ${MODEL_NAME} {
    id
    code
    description
    accountName
    accountType
    accountCategory
    accountCode
    royaltySheet
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_ACCOUNT_CODE = gql`
  ${ACCOUNT_CODE_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedAccountCode {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...AccountCodeFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_ACCOUNT_CODES = gql`
  ${ACCOUNT_CODE_FRAGMENT}
  query ${TENANT_PREFIX}AccountCodes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accountCodes(sortArg: $sortArg, searchArg: $searchArg) {
      ...AccountCodeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_ACCOUNT_CODES_IDS = gql`
  query ${TENANT_PREFIX}AccountCodes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}accountCodes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_ACCOUNT_CODE_BY_ID = gql`
  ${ACCOUNT_CODE_FRAGMENT}
  query ${TENANT_PREFIX}findAccountCodeById($${TENANT_PREFIX}findAccountCodeByIdId: String!) {
    ${TENANT_PREFIX}findAccountCodeById(id: $${TENANT_PREFIX}findAccountCodeByIdId) {
      ...AccountCodeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ACCOUNT_CODE_BY_ID = gql`
  ${ACCOUNT_CODE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateAccountCode($accountCode: ${TENANT_PREFIX}AccountCodeInput!, $${TENANT_PREFIX}updateAccountCodeId: String!) {
    ${TENANT_PREFIX}updateAccountCode(accountCode: $accountCode, id: $${TENANT_PREFIX}updateAccountCodeId) {
      ...AccountCodeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ACCOUNT_CODE = gql`
  ${ACCOUNT_CODE_FRAGMENT}
  mutation ${TENANT_PREFIX}createAccountCode($accountCode: abmsAccountCodeInput!) {
    ${TENANT_PREFIX}createAccountCode(accountCode: $accountCode) {
      ...AccountCodeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ACCOUNT_CODES = gql`
  mutation ${TENANT_PREFIX}deleteAccountCodes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAccountCodes(ids: $ids)
  }
`;

export const DELETE_ACCOUNT_CODE = gql`
  mutation ${TENANT_PREFIX}deleteAccountCode($${TENANT_PREFIX}deleteAccountCodeId: String!) {
    ${TENANT_PREFIX}deleteAccountCode(id: $${TENANT_PREFIX}deleteAccountCodeId)
  }
`;

export const GET_ACCOUNT_CODES_CSV = gql`
  query ${TENANT_PREFIX}accountCodeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}AccountCodeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_ACCOUNT_CODES = gql`
  query ${TENANT_PREFIX}accountCodes{
    ${TENANT_PREFIX}accountCodes{
      id
      accountCode
      accountType
    }
  }
`;
