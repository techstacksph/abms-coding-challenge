import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Invoice`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INVOICE_FRAGMENT = gql`
  fragment InvoiceFragment on ${MODEL_NAME} {
    id
    autoNumber
    invoiceNo
    accountId
    billingAccountId
    invoiceDate
    reference
    dueDate
    locationId
    xeroId
    salesOrderId
    invoiceTemplateId
    subType
    statusId
    xeroStatus
    type
    gstType
    subtotal
    gstAmount
    totalAmount
    outstandingBalance
    account {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      ayrMobile
      gst
      bankAccountNo
      accountType
      location {
        id
        name
        address
        financeEmail
      }
    }
    billingAccount {
      id
      name
      legalName
      accountType
      billingAddress
      physicalAddress
      ayrMobile
      gst
      bankAccountNo
      bStreetAddress
      bSuburb
      bPostalCode
      location {
        id
        name
        address
        financeEmail
      }
    }
    xero{
      id
      xeroAccount
    }
    invoiceContacts {
      id
      contact {
        id
        firstName
        lastName
        fullName
        email
      }
    }
    location {
      id
      name
      financeEmail
      billingAccount {
        id
        name
        legalName
        billingAddress
        ayrMobile
        gst
        bankAccountNo
        bStreetAddress
        bSuburb
        bCity
        bRegion
        bPostalCode
      }
    }
    salesOrder {
      id
      soNo
    }
    invoiceTemplate {
      id
      invoiceTemplateNo
      generationDate
      account {
        id
        name
      }
    }
    status {
      id
      name
    }
    invoiceJobs {
      id
      job {
        id
        jobNo
      }
    }
    events {
      id
      subject
    }
    communicationLogs {
      id
      commType
    }
    notes
    relatedNotes {
      id
      notes
    }
    document {
      id
      documentName
    }
    bills {
      id
      reference
    }
    tasks {
      id
      taskSubject
    }
    invoiceDetails {
      bci
      dontMerge
      id
      job{
        id
        jobNo
      }
      item{
        id
        name
      }
      serviceProvider{
        id
        name
      }
      accountCode{
        id
        accountCode
      }
      description
      qty
      unitPrice
      lineAmount
      accountCodeId
      accountCode {
        id
        code
        accountCode
      }
      commissions
      commissionType
      serviceProviderId
      serviceProvider {
        id
        name
      }
      bci
      dontMerge
    }
    fileKey
    fileMetaData
    fileDownloadUrl
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_INVOICES = gql`
  ${INVOICE_FRAGMENT}
  query ${TENANT_PREFIX}paginatedInvoices($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedInvoices(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...InvoiceFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_INVOICES = gql`
  ${INVOICE_FRAGMENT}
  query ${TENANT_PREFIX}invoices($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}invoices(sortArg: $sortArg, searchArg: $searchArg) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const ALL_INVOICES_IDS = gql`
  query ${TENANT_PREFIX}invoices($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}invoices(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_INVOICES = gql`
  query ${TENANT_PREFIX}invoices {
    ${TENANT_PREFIX}invoices {
      id
      invoiceNo
    }
  }
`;

export const FIND_INVOICE_BY_ID = gql`
  ${INVOICE_FRAGMENT}
  query ${TENANT_PREFIX}findInvoiceById($${TENANT_PREFIX}findInvoiceByIdId: String!) {
    ${TENANT_PREFIX}findInvoiceById(id: $${TENANT_PREFIX}findInvoiceByIdId) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INVOICE_BY_ID = gql`
  ${INVOICE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateInvoice($invoice: ${TENANT_PREFIX}InvoiceInput!, $${TENANT_PREFIX}updateInvoiceId: String!) {
    ${TENANT_PREFIX}updateInvoice(invoice: $invoice, id: $${TENANT_PREFIX}updateInvoiceId) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_INVOICE = gql`
  ${INVOICE_FRAGMENT}
  mutation ${TENANT_PREFIX}createInvoice($invoice: ${TENANT_PREFIX}InvoiceInput!) {
    ${TENANT_PREFIX}createInvoice(invoice: $invoice) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_INVOICE_SIMPLE = gql`
  mutation ${TENANT_PREFIX}createInvoice($invoice: ${TENANT_PREFIX}InvoiceInput!) {
    ${TENANT_PREFIX}createInvoice(invoice: $invoice) {
      id
      invoiceNo
      accountId
      billingAccountId
      invoiceDate
      dueDate
      reference
      subType
      gstType
      subtotal
      gstAmount
      totalAmount
    }
  }
`;

export const DELETE_INVOICE = gql`
  mutation ${TENANT_PREFIX}deleteInvoice($${TENANT_PREFIX}deleteInvoiceId: String!) {
    ${TENANT_PREFIX}deleteInvoice(id: $${TENANT_PREFIX}deleteInvoiceId)
  }
`;

export const DELETE_INVOICES = gql`
  mutation ${TENANT_PREFIX}deleteInvoices($ids: [String!]!) {
    ${TENANT_PREFIX}deleteInvoices(ids: $ids)
  }
`;

export const GET_INVOICE_CSV = gql`
  query ${TENANT_PREFIX}InvoiceCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}InvoiceCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const INVOICE_DASHBOARD = gql`
  query ${TENANT_PREFIX}InvoiceDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}InvoiceDashboard(dashboardArg: $dashboardArg) {
      allInvoices
      createdInvoices
      reviewedInvoices
      exportedInvoices
      jobTransferred
    }
  }
`;

export const UPDATE_INVOICE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateInvoiceStatus($${TENANT_PREFIX}updateInvoiceStatusId: String!, $status: ${TENANT_PREFIX}InvoiceStatusInput!) {
    ${TENANT_PREFIX}updateInvoiceStatus(id: $${TENANT_PREFIX}updateInvoiceStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_INVOICE_TOTALLS = gql`
  ${INVOICE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateInvoiceTotals($id: String!, $totals: ${TENANT_PREFIX}InvoiceTotalInput!) {
    ${TENANT_PREFIX}updateInvoiceTotals(id: $id, totals: $totals) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INVOICE_PDF = gql`
  ${INVOICE_FRAGMENT}
  mutation ${TENANT_PREFIX}updateInvoicePDF($id: String!, $invoicePDF: ${TENANT_PREFIX}InvoicePDFInput!) {
    ${TENANT_PREFIX}updateInvoicePDF(id: $id, invoicePDF: $invoicePDF) {
      ...InvoiceFragment
      ...BaseFragment
    }
  }
`;

export const GET_INVOICE_FILE_UPLOAD_URL = gql`
  query ${TENANT_PREFIX}getInvoiceFileUploadUrl($fileName: String!, $contentType: String!, $expiresIn: Float) {
    ${TENANT_PREFIX}getInvoiceFileUploadUrl(fileName: $fileName, contentType: $contentType, expiresIn: $expiresIn) {
      uploadUrl
      s3Key
      s3Url
      expiresIn
    }
  }
`;
