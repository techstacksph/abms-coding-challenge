import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragmentWithUniqueName } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}QARecurring`;
const BASE_FRAGMENT = getBaseFragmentWithUniqueName(MODEL_NAME);
const BASE_FRAGMENT_NAME = `BaseFragment_${MODEL_NAME}`;

export const QA_RECURRING_FRAGMENT = gql`
  fragment QaRecurringFragment on ${MODEL_NAME} {
    id
    startDate
    endDate
    frequency
    freqInt
    days
    date
    weekOrder
    dayWeek
    month
    year
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_QA_RECURRING = gql`
  ${QA_RECURRING_FRAGMENT}
  query ${TENANT_PREFIX}PaginatedQARecurrings($pageArg: ${TENANT_PREFIX}PageArg, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}PaginatedQARecurrings(pageArg: $pageArg, searchArg: $searchArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...QaRecurringFragment
        ...${BASE_FRAGMENT_NAME}
      }
    }
  }
`;

export const ALL_QA_RECURRING = gql`
  ${QA_RECURRING_FRAGMENT}
  query ${TENANT_PREFIX}QARecurrings($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}QARecurrings(sortArg: $sortArg, searchArg: $searchArg) {
      ...QaRecurringFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_QA_RECURRING_IDS = gql`
  query ${TENANT_PREFIX}QARecurrings($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}QARecurrings(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_QA_RECURRING_BY_ID = gql`
  ${QA_RECURRING_FRAGMENT}
  query ${TENANT_PREFIX}FindQARecurringById($id: String!) {
    ${TENANT_PREFIX}FindQARecurringById(id: $id) {
      ...QaRecurringFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_QA_RECURRING_BY_ID = gql`
  ${QA_RECURRING_FRAGMENT}
  mutation ${TENANT_PREFIX}UpdateQARecurring($qaRecurring: ${TENANT_PREFIX}QARecurringInput!, $id: String!) {
    ${TENANT_PREFIX}UpdateQARecurring(qaRecurring: $qaRecurring, id: $id) {
      ...QaRecurringFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_QA_RECURRING = gql`
  ${QA_RECURRING_FRAGMENT}
  mutation ${TENANT_PREFIX}CreateQARecurring($qaRecurring: ${TENANT_PREFIX}QARecurringInput!) {
    ${TENANT_PREFIX}CreateQARecurring(qaRecurring: $qaRecurring) {
      ...QaRecurringFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_QA_RECURRINGS = gql`
  mutation ${TENANT_PREFIX}DeleteQARecurrings($ids: [String!]!) {
    ${TENANT_PREFIX}DeleteQARecurrings(ids: $ids)
  }
`;

export const DELETE_QA_RECURRING = gql`
  mutation ${TENANT_PREFIX}DeleteQARecurring($id: String!) {
    ${TENANT_PREFIX}DeleteQARecurring(id: $id)
  }
`;

export const GET_QA_RECURRING_CSV = gql`
  query ${TENANT_PREFIX}QARecurringCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}QARecurringCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_QA_RECURRING = gql`
  query ${TENANT_PREFIX}QARecurrings{
    ${TENANT_PREFIX}QARecurrings{
      id
    }
  }
`;
