import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const CREATE_FRANCHISEE_NOTIFICATION_RECIPIENTS = gql`
  mutation ${TENANT_PREFIX}createFrachiseeNotificationRecipients($franchiseeNotificationRecipients: [${TENANT_PREFIX}FranchiseeNotificationRecipientInput!]!) {
    ${TENANT_PREFIX}createFrachiseeNotificationRecipients(franchiseeNotificationRecipients: $franchiseeNotificationRecipients) {
      id
      franchiseeNotification {
        id
        subject
        message
        locationId
        sendSMS
      }
      franchisee {
        id
        name
      }
    }
  }
`;

export const DELETE_FRANCHISEE_NOTIFICATION_RECIPIENTS = gql`
  mutation ${TENANT_PREFIX}deleteRecipientsByFranchiseeNotification($franchiseeNotificationId: String!) {
    ${TENANT_PREFIX}deleteRecipientsByFranchiseeNotification(franchiseeNotificationId: $franchiseeNotificationId)
  }
`;
