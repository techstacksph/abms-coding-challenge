import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Function`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FUNCTION_FRAGMENT = gql`
  fragment FunctionFragment on ${MODEL_NAME} {
    id
    name
    description
    parentFunction {
      id
      name
    } 
    childFunctions {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_FUNCTIONS = gql`
  ${FUNCTION_FRAGMENT}
  query paginatedFunctions($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFunctions(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FunctionFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_FUNCTIONS = gql`
  ${FUNCTION_FRAGMENT}
  query ${TENANT_PREFIX}functions($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}functions(searchArg: $searchArg, sortArg: $sortArg) {
      ...FunctionFragment
      ...BaseFragment
    }
  }
`;

export const ALL_FUNCTIONS_IDS = gql`
  query ${TENANT_PREFIX}functions($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}functions(searchArg: $searchArg, sortArg: $sortArg) {
      id
      name
    }
  }
`;

export const SELECT_FUNCTIONS = gql`
  query functions {
    ${TENANT_PREFIX}functions {
      id
      name
    }
  }
`;

export const PARENT_FUNCTION = gql`
  query functions {
    ${TENANT_PREFIX}functions {
      id
      name
    }
  }
`;

export const FIND_FUNCTION_BY_ID = gql`
  ${FUNCTION_FRAGMENT}
  query findFunctionById($${TENANT_PREFIX}findFunctionByIdId: String!) {
    ${TENANT_PREFIX}findFunctionById(id: $${TENANT_PREFIX}findFunctionByIdId) {
      ...FunctionFragment
      ...BaseFragment
    }
  }
`;

export const FIND_FUNCTION_BY_NAME = gql`
  ${FUNCTION_FRAGMENT}
  query findFunctionByName($${TENANT_PREFIX}findFunctionByName: String!) {
    ${TENANT_PREFIX}findFunctionByName(name: $${TENANT_PREFIX}findFunctionByName) {
      ...FunctionFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FUNCTIONS = gql`
  mutation deleteFunctions($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFunctions(ids: $ids)
  }
`;

export const DELETE_FUNCTION = gql`
  mutation ${TENANT_PREFIX}deleteFunction($id: String!) {
    ${TENANT_PREFIX}deleteFunction(id: $id)
  }
`;

export const CREATE_FUNCTION = gql`
  mutation ${TENANT_PREFIX}createFunction($func: ${TENANT_PREFIX}FunctionInput!) {
    ${TENANT_PREFIX}createFunction(func: $func) {
      id
      name
    }
  }
`;

export const UPDATE_FUNCTION_BY_ID = gql`
  mutation ${TENANT_PREFIX}updateFunction($${TENANT_PREFIX}updateFunctionId: String!, $func: ${TENANT_PREFIX}FunctionInput!) {
    ${TENANT_PREFIX}updateFunction(id: $${TENANT_PREFIX}updateFunctionId, func: $func) {
      id
      name
    }
  }
`;
