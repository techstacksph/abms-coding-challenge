import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Contact`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CONTACTS_FRAGMENT = gql`
  fragment ContactsFragment on ${MODEL_NAME} {
    id
    orgId
    createdAt
    updatedAt
    deletedAt
    createdBy
    updatedByName
    updatedBy
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    firstName
    lastName
    jobTitle
    notes
    phone
    mobile
    email
    secondaryEmail
    preferredMethodOfCommunication
    doNotContact
    contactTypes
    contactTypeId
    contactAccountId
    contactCompanyId
    siteId
    placeId
    latitude
    longitude
    site {
      id
      accountId
      siteName
      lastActivity
    }
    areaId
    area {
      id
      area
    }
    dealId
    statusId
    streetAddress
    suburb
    city
    region
    postalCode
    countryId
    viewlocation
    address
    fullName
    findAddress
    contactAccounts {
      id
      account {
        id
        name
        accountType
      }
    }
    contactCompanies {
      id
      companies {
        id
        companyName
      }
    }
    contactContactType {
      id
      contactType {
        id
        name
      }
    }
    country {
      id
      code
      name
    }
    site {
      id
      accountId
      siteName
      lastActivity
    }
    status {
      id
      name
    }
    uploadPhoto
    dateOfBirth
    startDate
    endDate
    completionDate
    portalUser
    locationId
    location {
      id
      name
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_CONTACTS = gql`
  ${CONTACTS_FRAGMENT}
  query paginatedContacts($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedContacts(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...ContactsFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_CONTACTS = gql`
  ${CONTACTS_FRAGMENT}
  query ${TENANT_PREFIX}contacts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contacts(sortArg: $sortArg, searchArg: $searchArg) {
      ...ContactsFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_CONTACTS = gql`
  query ${TENANT_PREFIX}contacts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contacts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      firstName
      lastName
      fullName
      jobTitle
      phone
      mobile
      email
      uploadPhoto
      siteId
      status {
        id
        name
      }
    }
  }
`;
export const ALL_CONTACTS_IDS = gql`
  query ${TENANT_PREFIX}contacts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contacts(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_CONTACTS_BY_ID = gql`
  ${CONTACTS_FRAGMENT}
  query ${TENANT_PREFIX}findContactById($${TENANT_PREFIX}findContactByIdId: String!) {
    ${TENANT_PREFIX}findContactById(id: $${TENANT_PREFIX}findContactByIdId) {
      ...ContactsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CONTACTS_BY_ID = gql`
  ${CONTACTS_FRAGMENT}
  mutation ${TENANT_PREFIX}updateContact($contact: ${TENANT_PREFIX}ContactInput!, $${TENANT_PREFIX}updateContactId: String!) {
    ${TENANT_PREFIX}updateContact(contact: $contact, id: $${TENANT_PREFIX}updateContactId) {
      ...ContactsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CONTACTS = gql`
  ${CONTACTS_FRAGMENT}
  mutation ${TENANT_PREFIX}createContact($contact: abmsContactInput!) {
    ${TENANT_PREFIX}createContact(contact: $contact) {
      ...ContactsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CONTACTS = gql`
  mutation ${TENANT_PREFIX}deleteContacts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteContacts(ids: $ids)
  }
`;

export const DELETE_CONTACT = gql`
  mutation ${TENANT_PREFIX}deleteContact($${TENANT_PREFIX}deleteContactId: String!) {
    ${TENANT_PREFIX}deleteContact(id: $${TENANT_PREFIX}deleteContactId)
  }
`;

export const UPDATE_CONTACTS_STATUS = gql`
  mutation ${TENANT_PREFIX}updateContactStatus($${TENANT_PREFIX}updateContactStatusId: String!, $status: ${TENANT_PREFIX}ContactStatusInput!) {
    ${TENANT_PREFIX}updateContactStatus(id: $${TENANT_PREFIX}updateContactStatusId, status: $status) {
      id
      fullName
    }
  }
`;

export const GET_CONTACT_CSV = gql`
  query ${TENANT_PREFIX}contactCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}contactCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const ATTACH_SITE_TO_CONTACT = gql`
  mutation ${TENANT_PREFIX}attachContactSite($inputs: ${TENANT_PREFIX}ContactSiteInput!) {
    ${TENANT_PREFIX}attachContactSite(inputs: $inputs)
  }
`;

export const SELECT_CONTACTS_WITH_ACCOUNT_ID = gql`
 query ${TENANT_PREFIX}contacts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contacts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      firstName
      lastName
      fullName
      jobTitle
      phone
      mobile
      email
      uploadPhoto
      contactAccountId
    }
  }
`;

export const ALL_CONTACT_ACCOUNTS = gql`
  query ${TENANT_PREFIX}contactAccounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contactAccounts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      contact{
        id
      }
    }
  }
`;

// Query for global options - fetches all contacts with their account associations
export const SELECT_ACCOUNTS_CONTACTS = gql`
  query ${TENANT_PREFIX}contacts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contacts(sortArg: $sortArg, searchArg: $searchArg) {
      id
      firstName
      lastName
      fullName
      jobTitle
      phone
      mobile
      email
      uploadPhoto
      contactAccounts {
        id
        account {
          id
        }
      }
    }
  }
`;
