import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}LeaveType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const LEAVE_TYPE_FRAGMENT = gql`
  fragment LeaveTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_LEAVE_TYPES = gql`
  ${LEAVE_TYPE_FRAGMENT}
  query paginatedLeaveTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedLeaveTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...LeaveTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_LEAVE_TYPES = gql`
  ${LEAVE_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}leaveTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leaveTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...LeaveTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_LEAVE_TYPES_IDS = gql`
  query ${TENANT_PREFIX}leaveTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}leaveTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_LEAVE_TYPE_BY_ID = gql`
  ${LEAVE_TYPE_FRAGMENT}
  query findLeaveTypeById($${TENANT_PREFIX}findLeaveTypeByIdId: String!) {
    ${TENANT_PREFIX}findLeaveTypeById(id: $${TENANT_PREFIX}findLeaveTypeByIdId) {
      ...LeaveTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_LEAVE_TYPE_BY_ID = gql`
  ${LEAVE_TYPE_FRAGMENT}
  mutation updateLeaveType($leaveType: ${TENANT_PREFIX}LeaveTypeInput!, $${TENANT_PREFIX}updateLeaveTypeId: String!) {
    ${TENANT_PREFIX}updateLeaveType(leaveType: $leaveType, id: $${TENANT_PREFIX}updateLeaveTypeId) {
      ...LeaveTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_LEAVE_TYPE = gql`
  ${LEAVE_TYPE_FRAGMENT}
  mutation createLeaveType($leaveType: ${TENANT_PREFIX}LeaveTypeInput!) {
    ${TENANT_PREFIX}createLeaveType(leaveType: $leaveType) {
      ...LeaveTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_LEAVE_TYPE = gql`
  mutation deleteLeaveType($${TENANT_PREFIX}deleteLeaveTypeById: String!) {
    ${TENANT_PREFIX}deleteLeaveType(id: $${TENANT_PREFIX}deleteLeaveTypeById)
  }
`;

export const DELETE_LEAVE_TYPES = gql`
  mutation deleteLeaveTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteLeaveTypes(ids: $ids)
  }
`;

export const GET_LEAVE_TYPES_CSV = gql`
  query ${TENANT_PREFIX}leaveTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}leaveTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
