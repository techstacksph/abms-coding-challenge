import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME_AREA = `${TENANT_PREFIX}QaArea`;
const MODEL_NAME_SPEC = `${TENANT_PREFIX}QaSpecification`;
const BASE_FRAGMENT_AREA = getBaseFragment(MODEL_NAME_AREA);
const BASE_FRAGMENT_SPEC = getBaseFragment(MODEL_NAME_SPEC);

export const QA_AREA_FRAGMENT = gql`
  fragment QaAreaFragment on ${MODEL_NAME_AREA} {
    id
    area
    assessment
  }
  ${BASE_FRAGMENT_AREA}
`;

export const QA_SPECIFICATION_FRAGMENT = gql`
  fragment QaSpecificationFragment on ${MODEL_NAME_SPEC} {
    id
    specification
    assessment
    notes
    qaAreaId
    qualityAuditId
  }
  ${BASE_FRAGMENT_SPEC}
`;

export const ALL_QA_AREAS = gql`
  ${QA_AREA_FRAGMENT}
  query ${TENANT_PREFIX}qaAreas($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}qaAreas(sortArg: $sortArg, searchArg: $searchArg) {
      ...QaAreaFragment
      ...BaseFragment
    }
  }
`;

export const ALL_QA_SPECIFICATIONS = gql`
  ${QA_SPECIFICATION_FRAGMENT}
  query ${TENANT_PREFIX}qaSpecifications($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}qaSpecifications(sortArg: $sortArg, searchArg: $searchArg) {
      ...QaSpecificationFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_QA_AREA = gql`
  ${QA_AREA_FRAGMENT}
  mutation ${TENANT_PREFIX}createQaArea($qaArea: ${TENANT_PREFIX}QaAreaInput!) {
    ${TENANT_PREFIX}createQaArea(qaArea: $qaArea) {
      ...QaAreaFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_QA_AREA = gql`
  ${QA_AREA_FRAGMENT}
  mutation ${TENANT_PREFIX}updateQaArea($qaArea: ${TENANT_PREFIX}QaAreaInput!, $id: String!) {
    ${TENANT_PREFIX}updateQaArea(qaArea: $qaArea, id: $id) {
      ...QaAreaFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_QA_SPECIFICATION = gql`
  ${QA_SPECIFICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}createQaSpecification($qaSpecification: ${TENANT_PREFIX}QaSpecificationInput!) {
    ${TENANT_PREFIX}createQaSpecification(qaSpecification: $qaSpecification) {
      ...QaSpecificationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_QA_SPECIFICATION = gql`
  ${QA_SPECIFICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateQaSpecification($qaSpecification: ${TENANT_PREFIX}QaSpecificationInput!, $id: String!) {
    ${TENANT_PREFIX}updateQaSpecification(qaSpecification: $qaSpecification, id: $id) {
      ...QaSpecificationFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_QA_AREA = gql`
  mutation ${TENANT_PREFIX}deleteQaArea($id: String!) {
    ${TENANT_PREFIX}deleteQaArea(id: $id)
  }
`;

export const DELETE_QA_SPECIFICATION = gql`
  mutation ${TENANT_PREFIX}deleteQaSpecification($id: String!) {
    ${TENANT_PREFIX}deleteQaSpecification(id: $id)
  }
`;
