import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const EVENT_MODULES = gql`
  query ${TENANT_PREFIX}modules($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}modules(searchArg: $searchArg, sortArg: $sortArg) {
      code
      id
      name
      isIncludedInEvent
    }
  }
`;

export const GET_WORKFLOW_STATUS = gql`
  query ${TENANT_PREFIX}getModuleWorkflowStatus($code: String!){
    ${TENANT_PREFIX}getModuleWorkflowStatus(code: $code){
      id
      name
    }
  }
`;

export const ALL_MODULES = gql`
query ${TENANT_PREFIX}modules($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!] = [{field: "code", direction: asc}]) {
  ${TENANT_PREFIX}modules(searchArg: $searchArg, sortArg: $sortArg) {
    code
    id
    name
    isIncludedInEvent
    isIncludedInTask
  }
}
`;
