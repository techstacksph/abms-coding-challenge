import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Option`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const OPTION_FRAGMENT = gql`
  fragment OptionsFragment on ${MODEL_NAME} {
    id
    name
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_OPTIONS = gql`
  ${OPTION_FRAGMENT}
  query paginatedOptions($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedOptions(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...OptionsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_OPTIONS = gql`
  ${OPTION_FRAGMENT}
  query ${TENANT_PREFIX}options($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}options(sortArg: $sortArg, searchArg: $searchArg) {
      ...OptionsFragment
      ...BaseFragment
    }
  }
`;

export const FIND_OPTION_BY_ID = gql`
  ${OPTION_FRAGMENT}
  query findOptionById($${TENANT_PREFIX}findOptionById: String!) {
    ${TENANT_PREFIX}findOptionById(id: $${TENANT_PREFIX}findOptionById) {
      ...OptionsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_OPTION_BY_ID = gql`
  ${OPTION_FRAGMENT}
  mutation updateOption($option: ${TENANT_PREFIX}OptionInputSchema!, $${TENANT_PREFIX}updateOptionId: String!) {
    ${TENANT_PREFIX}updateOption(option: $option, id: $${TENANT_PREFIX}updateOptionId) {
      ...OptionsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_OPTION = gql`
  ${OPTION_FRAGMENT}
  mutation createOption($option: ${TENANT_PREFIX}OptionInputSchema!) {
    ${TENANT_PREFIX}createOption(option: $option) {
      ...OptionsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_OPTION = gql`
  mutation deleteOption($${TENANT_PREFIX}deleteOptionById: String!) {
    ${TENANT_PREFIX}deleteOption(id: $${TENANT_PREFIX}deleteOptionById)
  }
`;

export const DELETE_OPTIONS = gql`
  mutation deleteOptions($ids: [String!]!) {
    ${TENANT_PREFIX}deleteOptions(ids: $ids)
  }
`;
