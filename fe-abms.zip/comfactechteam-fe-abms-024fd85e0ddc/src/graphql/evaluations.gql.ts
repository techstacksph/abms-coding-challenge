import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Evaluation`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const EVALUATION_FRAGMENT = gql`
  fragment EvaluationFragment on ${MODEL_NAME} {
    id
    franchisee {
      id
      name
      physicalAddress
      location {
        id
        name
      }
      locationId
      primaryContact {
        id
        firstName
        lastName
      }
    }
    franchiseeId
    evaluatedBy {
      id
      firstName
      lastName

    }
    evaluatedById
    evaluationDate
    evaluationDetails {
      id
      evaluationId
      evaluationDetail
      type
      remark
      notes
      orgId
      recordLocked
      lockedBy
      timeLocked
      createdAt
      createdBy
      createdByName
      updatedAt
      updatedBy
      updatedByName
      deletedAt
      deletedBy
    }
    location {
      id
      name
    }
    locationId
    status {
      id
      name
    }
    statusId
    notes
    orgId
    recordLocked
    lockedBy
    timeLocked
    communicationLogs {
      id
    }
    documents {
      id
    }
    events {
      id
    }
    tasks {
      id
    }
    relatedNotes {
      id
    }
  }
  ${BASE_FRAGMENT}
`;

// A lighter fragment for create to avoid selecting nested relations that may not
// be immediately resolvable by the API at creation time.
export const EVALUATION_CREATE_FRAGMENT = gql`
  fragment EvaluationCreateFragment on ${MODEL_NAME} {
    id
    franchiseeId
    evaluatedById
    evaluationDate
    locationId
    statusId
    notes
  }
`;

export const PAGINATED_EVALUATIONS = gql`
  ${EVALUATION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedEvaluations($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedEvaluations(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...EvaluationFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_EVALUATIONS = gql`
  ${EVALUATION_FRAGMENT}
  query ${TENANT_PREFIX}evaluation($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}evaluation(sortArg: $sortArg, searchArg: $searchArg) {
      ...EvaluationFragment
      ...BaseFragment
    }
  }
`;

export const ALL_EVALUATIONS_IDS = gql`
  query ${TENANT_PREFIX}evaluation($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}evaluation(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_EVALUATION_BY_ID = gql`
  ${EVALUATION_FRAGMENT}
  query ${TENANT_PREFIX}findEvaluationById($${TENANT_PREFIX}findEvaluationByIdId: String!) {
    ${TENANT_PREFIX}findEvaluationById(id: $${TENANT_PREFIX}findEvaluationByIdId) {
      ...EvaluationFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_EVALUATION_BY_ID = gql`
  ${EVALUATION_FRAGMENT}
  mutation ${TENANT_PREFIX}updateEvaluation($evaluationInput: ${TENANT_PREFIX}EvaluationInput!, $${TENANT_PREFIX}updateEvaluationId: String!) {
    ${TENANT_PREFIX}updateEvaluation(evaluationInput: $evaluationInput, id: $${TENANT_PREFIX}updateEvaluationId) {
      ...EvaluationFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_EVALUATION = gql`
  ${EVALUATION_CREATE_FRAGMENT}
  ${BASE_FRAGMENT}
  mutation ${TENANT_PREFIX}createEvaluation($evaluationInput: ${TENANT_PREFIX}EvaluationInput!) {
    ${TENANT_PREFIX}createEvaluation(evaluationInput: $evaluationInput) {
      ...EvaluationCreateFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_EVALUATION = gql`
  mutation ${TENANT_PREFIX}deleteEvaluation($${TENANT_PREFIX}deleteEvaluationId: String!) {
    ${TENANT_PREFIX}deleteEvaluation(id: $${TENANT_PREFIX}deleteEvaluationId)
  }
`;

export const DELETE_EVALUATIONS = gql`
  mutation ${TENANT_PREFIX}deleteEvaluations($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEvaluations(ids: $ids)
  }
`;

export const UPDATE_EVALUATION_STATUS = gql`
  mutation ${TENANT_PREFIX}updateEvaluationStatus($${TENANT_PREFIX}updateEvaluationStatusId: String!, $status: ${TENANT_PREFIX}EvaluationStatusInput!) {
    ${TENANT_PREFIX}updateEvaluationStatus(id: $${TENANT_PREFIX}updateEvaluationStatusId, status: $status) {
      id
    }
  }
`;

export const CREATE_EVALUATION_DETAILS = gql`
  mutation ${TENANT_PREFIX}createEvaluationDetails($evaluationDetailsInput: ${TENANT_PREFIX}EvaluationDetailsInput!) {
    ${TENANT_PREFIX}createEvaluationDetails(evaluationDetailsInput: $evaluationDetailsInput) {
      id
      evaluationId
      evaluationDetail
      type
      remark
      notes
      orgId
      recordLocked
      lockedBy
      timeLocked
      createdAt
      createdBy
      createdByName
      updatedAt
      updatedBy
      updatedByName
      deletedAt
      deletedBy
    }
  }
`;

export const DELETE_EVALUATION_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteEvaluationDetail($${TENANT_PREFIX}deleteEvaluationDetailId: String!) {
    ${TENANT_PREFIX}deleteEvaluationDetail(id: $${TENANT_PREFIX}deleteEvaluationDetailId)
  }
`;

export const DELETE_EVALUATION_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteEvaluationDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEvaluationDetails(ids: $ids)
  }
`;

export const UPDATE_EVALUATION_DETAIL = gql`
  mutation ${TENANT_PREFIX}updateEvaluationDetails($evaluationDetailsInput: ${TENANT_PREFIX}EvaluationDetailsInput!, $${TENANT_PREFIX}updateEvaluationDetailsId: String!) {
    ${TENANT_PREFIX}updateEvaluationDetails(evaluationDetailsInput: $evaluationDetailsInput, id: $${TENANT_PREFIX}updateEvaluationDetailsId) {
      id
      evaluationId
      evaluationDetail
      type
      remark
      notes
      orgId
      recordLocked
      lockedBy
      timeLocked
      createdAt
      createdBy
      createdByName
      updatedAt
      updatedBy
      updatedByName
      deletedAt
      deletedBy
    }
  }
`;
