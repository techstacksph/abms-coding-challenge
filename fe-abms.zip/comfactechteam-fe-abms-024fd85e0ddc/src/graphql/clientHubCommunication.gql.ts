import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ClientHubCommunication`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CLIENT_HUB_COMMUNICATION_FRAGMENT = gql`
  fragment ClientHubCommunicationFragment on ${MODEL_NAME} {
    id
    subject
    message
    type
    actionRequired
    
    # Relationship fields
    site {
      id
      accountId
      siteName
      address
      fullAddress
      lastActivity
    }
    status {
      id
      name
    }
    
  }

  ${BASE_FRAGMENT}
`;

export const GET_PAGINATED_CLIENT_HUB_COMMUNICATIONS = gql`
  ${CLIENT_HUB_COMMUNICATION_FRAGMENT}
  query ${TENANT_PREFIX}paginatedClientHubCommunications($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedClientHubCommunications(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ClientHubCommunicationFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const GET_CLIENT_HUB_COMMUNICATIONS = gql`
  ${CLIENT_HUB_COMMUNICATION_FRAGMENT}
  query ${TENANT_PREFIX}clientHubCommunications($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}clientHubCommunications(searchArg: $searchArg, sortArg: $sortArg) {
      ...ClientHubCommunicationFragment
      ...BaseFragment
    }
  }
`;

export const GET_CLIENT_HUB_COMMUNICATIONS_IDS = gql`
  query ${TENANT_PREFIX}clientHubCommunications($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}clientHubCommunications(searchArg: $searchArg, sortArg: $sortArg) {
      id
    }
  }
`;

export const GET_CLIENT_HUB_COMMUNICATION_BY_ID = gql`
  ${CLIENT_HUB_COMMUNICATION_FRAGMENT}
  query findClientHubCommunicationById($${TENANT_PREFIX}findClientHubCommunicationByIdId: String!) {
    ${TENANT_PREFIX}findClientHubCommunicationById(id: $${TENANT_PREFIX}findClientHubCommunicationByIdId) {
      ...ClientHubCommunicationFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CLIENT_HUB_COMMUNICATION = gql`
  mutation ${TENANT_PREFIX}createClientHubCommunication($clientHubCommunication: ${TENANT_PREFIX}ClientHubCommunicationInput!) {
    ${TENANT_PREFIX}createClientHubCommunication(clientHubCommunication: $clientHubCommunication) {
      id
      subject
    }
  }
`;

export const UPDATE_CLIENT_HUB_COMMUNICATION = gql`
  mutation ${TENANT_PREFIX}updateClientHubCommunication($clientHubCommunication: ${TENANT_PREFIX}ClientHubCommunicationInput!, $${TENANT_PREFIX}updateClientHubCommunicationId: String!) {
    ${TENANT_PREFIX}updateClientHubCommunication(clientHubCommunication: $clientHubCommunication, id: $${TENANT_PREFIX}updateClientHubCommunicationId) {
      id
      subject
    }
  }
`;

export const DELETE_CLIENT_HUB_COMMUNICATION_BY_ID = gql`
  mutation ${TENANT_PREFIX}deleteClientHubCommunication($${TENANT_PREFIX}deleteClientHubCommunicationId: String!) {
    ${TENANT_PREFIX}deleteClientHubCommunication(id: $${TENANT_PREFIX}deleteClientHubCommunicationId) {
      id
    }
  }
`;

export const DELETE_CLIENT_HUB_COMMUNICATION = gql`
  mutation ${TENANT_PREFIX}deleteClientHubCommunications($ids: [String!]!) {
    ${TENANT_PREFIX}deleteClientHubCommunications(ids: $ids)
  }
`;

export const SELECT_CLIENT_HUB_COMMUNICATIONS = gql`
  query ${TENANT_PREFIX}clientHubCommunications($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}clientHubCommunications(searchArg: $searchArg, sortArg: $sortArg) {
      id
      subject
      message
      type
      actionRequired
      status {
        id
        name
      }
      site {
        id
        accountId
        siteName
        lastActivity
      }
    }
  }
`;

export const UPDATE_CLIENT_HUB_COMMUNICATION_STATUS_TO_READ = gql`
  ${CLIENT_HUB_COMMUNICATION_FRAGMENT}
  mutation ${TENANT_PREFIX}abmsupdateClientHubCommunicationStatusToRead($${TENANT_PREFIX}abmsupdateClientHubCommunicationStatusToReadId: String!) {
    ${TENANT_PREFIX}abmsupdateClientHubCommunicationStatusToRead(id: $${TENANT_PREFIX}abmsupdateClientHubCommunicationStatusToReadId) {
      ...ClientHubCommunicationFragment
      ...BaseFragment
    }
  }
`;
