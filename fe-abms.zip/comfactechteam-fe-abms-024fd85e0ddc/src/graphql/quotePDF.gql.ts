import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}QuotePDF`;

export const QUOTE_PDF_FRAGMENT = gql`
  fragment QuotePDFFragment on ${MODEL_NAME} {
    id
    #quoteId
    quotePDF
    #version
    createdAt
    updatedAt
    createdBy
    updatedBy
  }
`;

export const CREATE_QUOTE_PDF = gql`
  ${QUOTE_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}createQuotePDF($quotePDF: ${MODEL_NAME}Input!) {
    ${TENANT_PREFIX}createQuotePDF(quotePDF: $quotePDF) {
      ...QuotePDFFragment
    }
  }
`;

export const UPDATE_QUOTE_PDF = gql`
  ${QUOTE_PDF_FRAGMENT}
  mutation ${TENANT_PREFIX}updateQuotePDF($quotePDF: ${MODEL_NAME}Input!, $id: String!) {
    ${TENANT_PREFIX}updateQuotePDF(quotePDF: $quotePDF, id: $id) {
      ...QuotePDFFragment
    }
  }
`;

export const FIND_QUOTE_PDF_BY_ID = gql`
  ${QUOTE_PDF_FRAGMENT}
  query ${TENANT_PREFIX}findQuotePDFById($id: String!) {
    ${TENANT_PREFIX}findQuotePDFById(id: $id) {
      ...QuotePDFFragment
    }
  }
`;

export const FIND_QUOTE_PDF_BY_QUOTE_ID = gql`
  ${QUOTE_PDF_FRAGMENT}
  query ${TENANT_PREFIX}findQuotePDFByQuoteId($quoteId: String!) {
    ${TENANT_PREFIX}findQuotePDFByQuoteId(quoteId: $quoteId) {
      ...QuotePDFFragment
    }
  }
`;

export const DELETE_QUOTE_PDF = gql`
  mutation ${TENANT_PREFIX}deleteQuotePDF($id: String!) {
    ${TENANT_PREFIX}deleteQuotePDF(id: $id)
  }
`;

export const GET_QUOTE_PDF_DOWNLOAD_URL = gql`
  query ${TENANT_PREFIX}getQuotePDFDownloadUrl(
    $quotePDFId: String!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getQuotePDFDownloadUrl(
      quotePDFId: $quotePDFId
      expiresIn: $expiresIn
    )
  }
`;

export const GET_QUOTE_PDF_DOWNLOAD_URL_BY_S3_KEY = gql`
  query ${TENANT_PREFIX}getQuotePDFDownloadUrlByS3Key(
    $s3Key: String!
    $expiresIn: Float
  ) {
    ${TENANT_PREFIX}getQuotePDFDownloadUrlByS3Key(
      s3Key: $s3Key
      expiresIn: $expiresIn
    )
  }
`;
