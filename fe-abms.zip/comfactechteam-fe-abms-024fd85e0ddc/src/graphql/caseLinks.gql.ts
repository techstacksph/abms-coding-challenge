import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CaseLink`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CASE_LINK_FRAGMENT = gql`
  fragment CaseLinkFragment on ${MODEL_NAME} {
    id
    caseLink
    description
    case{
      id
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_CASE_LINKS = gql`
  ${CASE_LINK_FRAGMENT}
  query paginatedCaseLinks($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedCaseLinks(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...CaseLinkFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_CASE_LINKS = gql`
  ${CASE_LINK_FRAGMENT}
  query ${TENANT_PREFIX}caseLinks($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}caseLinks(sortArg: $sortArg, searchArg: $searchArg) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const FIND_CASE_LINK_BY_ID = gql`
  ${CASE_LINK_FRAGMENT}
  query findCaseLinkById($${TENANT_PREFIX}findCaseLinkByIdId: String!) {
    ${TENANT_PREFIX}findCaseLinkById(id: $${TENANT_PREFIX}findCaseLinkByIdId) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CASE_LINK = gql`
  ${CASE_LINK_FRAGMENT}
  mutation updateCaseLink($caseLink: ${TENANT_PREFIX}CaseLinkInput!, $${TENANT_PREFIX}updateCaseLinkId: String!) {
    ${TENANT_PREFIX}updateCaseLink(caseLink: $caseLink, id: $${TENANT_PREFIX}updateCaseLinkId) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_CASE_LINKS = gql`
  ${CASE_LINK_FRAGMENT}
  mutation ${TENANT_PREFIX}updateCaseLinks($ids: [String!]!, $caseLinks: [${TENANT_PREFIX}CaseLinkInput!]!) {
    ${TENANT_PREFIX}updateCaseLinks(ids: $ids, caseLinks: $caseLinks) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE_LINK = gql`
  ${CASE_LINK_FRAGMENT}
  mutation createCaseLink($caseLink: ${TENANT_PREFIX}CaseLinkInput!) {
    ${TENANT_PREFIX}createCaseLink(caseLink: $caseLink) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_CASE_LINKS = gql`
  ${CASE_LINK_FRAGMENT}
  mutation ${TENANT_PREFIX}createCaseLinks($caseLinks: [${TENANT_PREFIX}CaseLinkInput!]!) {
    ${TENANT_PREFIX}createCaseLinks(caseLinks: $caseLinks) {
      ...CaseLinkFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CASE_LINK = gql`
  mutation deleteCaseLink($${TENANT_PREFIX}deleteCaseLinkById: String!) {
    ${TENANT_PREFIX}deleteCaseLink(id: $${TENANT_PREFIX}deleteCaseLinkById)
  }
`;

export const DELETE_CASE_LINKS = gql`
  mutation deleteCaseLinks($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCaseLinks(ids: $ids)
  }
`;
