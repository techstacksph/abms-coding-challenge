import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Questionnaire`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const QUESTIONNAIRE_FRAGMENT = gql`
  fragment QuestionnairesFragment on ${MODEL_NAME} {
    id
    questionnaire
    type
    description
    job{
        id
        name
    }
    status{
      id
      name
    }
    questions{
        id
        name
        type
        description
        numAnswers
        options{
          id 
          name
        }
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_QUESTIONNAIRES = gql`
  ${QUESTIONNAIRE_FRAGMENT}
  query paginatedQuestionnaires($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedQuestionnaires(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...QuestionnairesFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_QUESTIONNAIRES = gql`
  ${QUESTIONNAIRE_FRAGMENT}
  query ${TENANT_PREFIX}questionnaires($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}questionnaires(sortArg: $sortArg, searchArg: $searchArg) {
      ...QuestionnairesFragment
      ...BaseFragment
    }
  }
`;

export const ALL_QUESTIONNAIRES_IDS = gql`
  query ${TENANT_PREFIX}questionnaires($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}questionnaires(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_QUESTIONNAIRE_BY_ID = gql`
  ${QUESTIONNAIRE_FRAGMENT}
  query findQuestionnaireById($${TENANT_PREFIX}findQuestionnaireById: String!) {
    ${TENANT_PREFIX}findQuestionnaireById(id: $${TENANT_PREFIX}findQuestionnaireById) {
      ...QuestionnairesFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_QUESTIONNAIRE_BY_ID = gql`
  ${QUESTIONNAIRE_FRAGMENT}
  mutation updateQuestionnaire($questionnaire: ${TENANT_PREFIX}QuestionnaireInputSchema!, $${TENANT_PREFIX}updateQuestionnaireId: String!) {
    ${TENANT_PREFIX}updateQuestionnaire(questionnaire: $questionnaire, id: $${TENANT_PREFIX}updateQuestionnaireId) {
      ...QuestionnairesFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_QUESTIONNAIRE = gql`
  ${QUESTIONNAIRE_FRAGMENT}
  mutation createQuestionnaire($questionnaire: ${TENANT_PREFIX}QuestionnaireInputSchema!) {
    ${TENANT_PREFIX}createQuestionnaire(questionnaire: $questionnaire) {
      ...QuestionnairesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_QUESTIONNAIRE = gql`
  mutation deleteQuestionnaire($${TENANT_PREFIX}deleteQuestionnaireById: String!) {
    ${TENANT_PREFIX}deleteQuestionnaire(id: $${TENANT_PREFIX}deleteQuestionnaireById)
  }
`;

export const DELETE_QUESTIONNAIRES = gql`
  mutation deleteQuestionnaires($ids: [String!]!) {
    ${TENANT_PREFIX}deleteQuestionnaires(ids: $ids)
  }
`;

export const UPDATE_QUESTIONNAIRE_STATUS = gql`
  mutation ${TENANT_PREFIX}updateQuestionnaireStatus($statusId: String!, $${TENANT_PREFIX}updateQuestionnaireStatusId: String!) {
    ${TENANT_PREFIX}updateQuestionnaireStatus(
      statusId: $statusId,
      id: $${TENANT_PREFIX}updateQuestionnaireStatusId
    ) {
      id
    }
  }
`;

export const GET_QUESTIONNAIRES_CSV = gql`
  query ${TENANT_PREFIX}QuestionnaireCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}QuestionnaireCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
