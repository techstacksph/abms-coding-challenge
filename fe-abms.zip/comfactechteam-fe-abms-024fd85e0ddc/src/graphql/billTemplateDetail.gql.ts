import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'BillTemplateDetail';
const TITLE_SMALL = 'billTemplateDetail';
const TITLE_FRAGMENT = 'BillTemplateDetailFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
// const PAGINATED_BILL_TEMPLATE_DETAILS_TITLE = 'paginatedBillTemplateDetails';

export const BILL_TEMPLATE_DETAIL_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    description
    qty
    unitPrice
    lineAmount
    billTemplate {
      id
      reference
      billTemplateNo
    }
    item {
      id
      name
    }
    job {
      id
      jobNo
    }
    accountCode {
      id
      accountName
      accountCode
    }
    serviceType {
      id
      servicetype
    }
    recordLocked
    lockedBy
    timeLocked
  }
  ${BASE_FRAGMENT}
`;

export const ALL_BILL_TEMPLATE_DETAILS = gql`
  ${BILL_TEMPLATE_DETAIL_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_BILL_TEMPLATE_DETAILS_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_BILL_TEMPLATE_DETAIL_BY_ID = gql`
  ${BILL_TEMPLATE_DETAIL_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ById: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ById) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_BILL_TEMPLATE_DETAIL = gql`
  ${BILL_TEMPLATE_DETAIL_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_BILL_TEMPLATE_DETAIL = gql`
  ${BILL_TEMPLATE_DETAIL_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_BILL_TEMPLATE_DETAILS = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;
