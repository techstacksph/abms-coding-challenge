import { gql } from '@apollo/client';
import environment from '@/config/environment';

const { TENANT_PREFIX } = environment;

const TITLE = 'ActionPlan';
const TITLE_FRAGMENT = 'ActionPlanFragment';

export const ACTION_PLAN_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${TENANT_PREFIX}${TITLE} {
    id
    title
    description
    caseId
    qualityAuditId
    dueDate
    case {
      id
      caseNo
    }
    qualityAudit {
      id
      qaNo
    }
    actionPlanAssignees {
      id
      actionPlan {
        id
        title
      }
      assignee {
        id
        firstName
        lastName
        email
      }
      createdAt
      createdBy
      createdByName
      deletedAt
      deletedBy
    }
    task {
      id
      taskType {
        id
      }
      taskSubject
      status {
        id
        name
      }
    }
    recordLocked
    lockedBy
    timeLocked
    orgId
    deletedAt
    deletedBy
    createdAt
    createdBy
    createdByName
    updatedAt
    updatedBy
    updatedByName
  }
`;

export const ALL_ACTION_PLANS = gql`
  ${ACTION_PLAN_FRAGMENT}
  query ${TENANT_PREFIX}actionPlans($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}actionPlans(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
    }
  }
`;

export const PAGINATED_ACTION_PLANS = gql`
  ${ACTION_PLAN_FRAGMENT}
  query ${TENANT_PREFIX}paginatedActionPlans($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedActionPlans(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const CREATE_ACTION_PLAN = gql`
  ${ACTION_PLAN_FRAGMENT}
  mutation ${TENANT_PREFIX}createActionPlan($actionPlan: ${TENANT_PREFIX}ActionPlanInput!) {
    ${TENANT_PREFIX}createActionPlan(actionPlan: $actionPlan) {
      ...${TITLE_FRAGMENT}
    }
  }
`;

export const UPDATE_ACTION_PLAN = gql`
  ${ACTION_PLAN_FRAGMENT}
  mutation ${TENANT_PREFIX}updateActionPlan($id: String!, $actionPlan: ${TENANT_PREFIX}ActionPlanInput!) {
    ${TENANT_PREFIX}updateActionPlan(id: $id, actionPlan: $actionPlan) {
      ...${TITLE_FRAGMENT}
    }
  }
`;

export const DELETE_ACTION_PLANS = gql`
  mutation ${TENANT_PREFIX}deleteActionPlans($ids: [String!]!) {
    ${TENANT_PREFIX}deleteActionPlans(ids: $ids)
  }
`;

export const DELETE_ACTION_PLAN = gql`
    mutation ${TENANT_PREFIX}deleteActionPlan($id: String!) {
      ${TENANT_PREFIX}deleteActionPlan(id: $id)
    }
  `;
