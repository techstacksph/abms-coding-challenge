import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ItemSubCategory`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const ITEM_SUBCATEGORY_FRAGMENT = gql`
  fragment ItemSubcategoryFragment on ${MODEL_NAME} {
    id
    name
    description
    code
    active
    isno
    itemCategoryId
    category {
        id
        name
      }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_ITEM_SUBCATEGORIES = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  query ${TENANT_PREFIX}paginatedItemSubcategories($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedItemSubcategories(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ItemSubcategoryFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_ITEM_SUBCATEGORIES = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  query ${TENANT_PREFIX}itemSubcategories($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemSubcategories(sortArg: $sortArg, searchArg: $searchArg) {
      ...ItemSubcategoryFragment
      ...BaseFragment
      
    }
  }
`;

export const ALL_ITEM_SUBCATEGORIES_IDS = gql`
  query ${TENANT_PREFIX}itemSubcategories($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}itemSubcategories(sortArg: $sortArg, searchArg: $searchArg) {
      id
      
    }
  }
`;

export const FIND_ITEM_SUBCATEGORY_BY_ID = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  query findItemSubcategoryById($${TENANT_PREFIX}findItemSubcategoryByIdId: String!) {
    ${TENANT_PREFIX}findItemSubcategoryById(id: $${TENANT_PREFIX}findItemSubcategoryByIdId) {
      ...ItemSubcategoryFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_ITEM_SUBCATEGORY_BY_ID = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  mutation updateItemSubCategory($itemSubCategory: ${TENANT_PREFIX}ItemSubCategoryInput!, $${TENANT_PREFIX}updateItemSubCategoryId: String!) {
    ${TENANT_PREFIX}updateItemSubCategory(itemSubCategory: $itemSubCategory, id: $${TENANT_PREFIX}updateItemSubCategoryId) {
      ...ItemSubcategoryFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_ITEM_SUBCATEGORY = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  mutation createItemSubcategory($itemSubCategory: ${TENANT_PREFIX}ItemSubCategoryInput!) {
    ${TENANT_PREFIX}createItemSubcategory(itemSubCategory: $itemSubCategory) {
      ...ItemSubcategoryFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_ITEM_SUBCATEGORY = gql`
  mutation deleteItemSubcategory($${TENANT_PREFIX}deleteItemSubcategoryById: String!) {
    ${TENANT_PREFIX}deleteItemSubcategory(id: $${TENANT_PREFIX}deleteItemSubcategoryById)
  }
`;

export const DELETE_ITEM_SUBCATEGORIES = gql`
  mutation deleteItemSubcategories($ids: [String!]!) {
    ${TENANT_PREFIX}deleteItemSubcategories(ids: $ids)
  }
`;

export const GET_ITEM_SUBCATEGORIES_CSV = gql`
  query ${TENANT_PREFIX}itemSubcategoryCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}itemSubcategoryCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_ITEM_SUBCATEGORIES = gql`
  query ${TENANT_PREFIX}itemSubcategories {
    ${TENANT_PREFIX}itemSubcategories {
      id
      name
      itemCategoryId
    }
  }
`;

export const QUICK_CREATE_ITEM_SUBCATEGORY = gql`
  ${ITEM_SUBCATEGORY_FRAGMENT}
  mutation quickCreateItemSubcategory($input: ${TENANT_PREFIX}QuickCreateItemSubCategoryInput!) {
    ${TENANT_PREFIX}quickCreateItemSubcategory(input: $input) {
      ...ItemSubcategoryFragment
      ...BaseFragment
    }
  }
`;
