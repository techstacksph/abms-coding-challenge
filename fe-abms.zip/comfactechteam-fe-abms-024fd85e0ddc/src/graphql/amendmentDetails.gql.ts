import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}AmendmentDetail`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FRANCHISEE_AMENDMENT_FRAGMENT = gql`
  fragment FranchiseeAmendmentFragment on ${MODEL_NAME} {
    account {
      id
      name
    },
    accountId,
    agreementId,
    amendmentType {
      id
      name
    },
    details,
    franchiseeAgreement {
      id
    },
    id,
    job {
      id
      jobNo
    },
    jobId,
    lockedBy,
    orgId,
    recordLocked,
    timeLocked,
    value,
    typeId,
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_FRANCHISEE_AMENDMENTS = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  query paginatedFranchiseeAmendments($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFranchiseeAmendments(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FranchiseeAmendmentFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const PAGINATED_AMENDMENT_DETAILS = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  query ${TENANT_PREFIX}paginatedAmendmentDetails($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedAmendmentDetails(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FranchiseeAmendmentFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
      sort {
        field
        direction
      }
    }
  }
`;

export const ALL_FRANCHISEE_AMENDMENTS = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  query ${TENANT_PREFIX}amendmentDetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}amendmentDetails(sortArg: $sortArg, searchArg: $searchArg) {
      ...FranchiseeAmendmentFragment
      ...BaseFragment
    }
  }
`;

export const FIND_FRANCHISEE_AMENDMENT_BY_ID = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  query ${TENANT_PREFIX}findAmendmentDetailById($${TENANT_PREFIX}findAmendmentDetailByIdId: String!) {
    ${TENANT_PREFIX}findAmendmentDetailById(id: $${TENANT_PREFIX}findAmendmentDetailByIdId) {
      ...FranchiseeAmendmentFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_AMENDMENT_BY_ID = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  mutation ${TENANT_PREFIX}updateAmendmentDetail($amendmentDetail: ${TENANT_PREFIX}AmendmentDetailInput!, $${TENANT_PREFIX}updateAmendmentDetailId: String!) {
    ${TENANT_PREFIX}updateAmendmentDetail(amendmentDetail: $amendmentDetail, id: $${TENANT_PREFIX}updateAmendmentDetailId) {
      ...FranchiseeAmendmentFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_FRANCHISEE_AMENDMENT = gql`
  ${FRANCHISEE_AMENDMENT_FRAGMENT}
  mutation ${TENANT_PREFIX}createAmendmentDetail($amendmentDetail: ${TENANT_PREFIX}AmendmentDetailInput!) {
    ${TENANT_PREFIX}createAmendmentDetail(amendmentDetail: $amendmentDetail) {
      ...FranchiseeAmendmentFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FRANCHISEE_AMENDMENT = gql`
  mutation ${TENANT_PREFIX}deleteAmendmentDetail($${TENANT_PREFIX}deleteAmendmentDetailId: String!) {
    ${TENANT_PREFIX}deleteAmendmentDetail(id: $${TENANT_PREFIX}deleteAmendmentDetailId)
  }
`;

export const DELETE_FRANCHISEE_AMENDMENTS = gql`
  mutation ${TENANT_PREFIX}deleteAmendmentDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAmendmentDetails(ids: $ids)
  }
`;
