import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}InvoiceTemplateDetail`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const INVOICE_TEMPLATE_DETAILS_FRAGMENT = gql`
  fragment InvoiceTemplateDetailsFragment on ${MODEL_NAME} {
    id
    job{
      id
      jobNo
    }
    serviceType{
      id
      servicetype
    }
    serviceProvider {
      id
      name
    }
    item{
      id
      name
    }
    description
    unitPrice
    qty
    accountCode{
      id
      accountCode
    }
    lineAmount
    commissionAmount
    bci
    dontmerge
    commissionType
    billTemplate {
      id
      billTemplateNo
      reference
      status { id name }
      account { id name }
      billingAccount { id name }
      location { id name }
      xeroAccount { id xeroAccount }
      jobs { id jobNo }
      billTemplateContacts { id contact { id fullName } }
      billTemplateDetails {
        id
        description
        qty
        unitPrice
        lineAmount
        job { id jobNo }
        item { id name }
        accountCode { id accountCode }
      }
      gstType
      subtotal
      gstAmount
      totalAmount
      type
      subType
      notes
    }
  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_INVOICE_TEMPLATE_DETAILS = gql`
  ${INVOICE_TEMPLATE_DETAILS_FRAGMENT}
  query paginatedInvoiceTemplateDetails($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedInvoiceTemplateDetails(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...InvoiceTemplateDetailsFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_INVOICE_TEMPLATE_DETAILS = gql`
  query ${TENANT_PREFIX}invoiceTemplateDetails($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}invoiceTemplateDetails(sortArg: $sortArg, searchArg: $searchArg) {
      id
      description
      qty
      unitPrice
      lineAmount
      commissionAmount
      bci
      dontmerge
      commissionType
      job {
        id
        jobNo
      }
      serviceProvider {
        id
        name
      }
      item {
        id
        name
      }
      accountCode {
        id
        accountCode
      }
      updatedAt
      updatedBy
    }
  }
`;

export const FIND_INVOICE_TEMPLATE_DETAIL_BY_ID = gql`
  ${INVOICE_TEMPLATE_DETAILS_FRAGMENT}
  query ${TENANT_PREFIX}findInvoiceTemplateDetailById($${TENANT_PREFIX}findInvoiceTemplateDetailByIdId: String!) {
    ${TENANT_PREFIX}findInvoiceTemplateDetailById(id: $${TENANT_PREFIX}findInvoiceTemplateDetailByIdId) {
      ...InvoiceTemplateDetailsFragment
      ...BaseFragment
    }
  }
`;

export const SELECT_INVOICE_TEMPLATE_DETAILS = gql`
  query ${TENANT_PREFIX}invoiceTemplateDetails{
    ${TENANT_PREFIX}invoiceTemplateDetails{
      id
      description
    }
  }
`;

export const CREATE_INVOICE_TEMPLATE_DETAIL = gql`
  ${INVOICE_TEMPLATE_DETAILS_FRAGMENT}
  mutation createInvoiceTemplateDetail($invoiceTemplateDetail: ${TENANT_PREFIX}InvoiceTemplateDetailInput!) {
    ${TENANT_PREFIX}createInvoiceTemplateDetail(invoiceTemplateDetail: $invoiceTemplateDetail) {
      ...InvoiceTemplateDetailsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_INVOICE_TEMPLATE_DETAIL_BY_ID = gql`
  ${INVOICE_TEMPLATE_DETAILS_FRAGMENT}
  mutation updateInvoiceTemplateDetail($invoiceTemplateDetail: ${TENANT_PREFIX}InvoiceTemplateDetailInput!, $${TENANT_PREFIX}updateInvoiceTemplateDetailId: String!) {
    ${TENANT_PREFIX}updateInvoiceTemplateDetail(invoiceTemplateDetail: $invoiceTemplateDetail, id: $${TENANT_PREFIX}updateInvoiceTemplateDetailId) {
      ...InvoiceTemplateDetailsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_INVOICE_TEMPLATE_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteInvoiceTemplateDetail($${TENANT_PREFIX}deleteInvoiceTemplateDetailId: String!) {
    ${TENANT_PREFIX}deleteInvoiceTemplateDetail(id: $${TENANT_PREFIX}deleteInvoiceTemplateDetailId)
  } 
`;

export const DELETE_INVOICE_TEMPLATE_DETAILS = gql`
  mutation deleteInvoiceTemplateDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteInvoiceTemplateDetails(ids: $ids)
  }
`;

export const GET_INVOICE_TEMPLATE_DETAILS_CSV = gql`
  query ${TENANT_PREFIX}InvoiceTemplateDetailCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}InvoiceTemplateDetailCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const CREATE_INVOICE_TEMPLATE_DETAILS = gql`
  ${INVOICE_TEMPLATE_DETAILS_FRAGMENT}
  mutation ${TENANT_PREFIX}createInvoiceTemplateDetails($invoiceTemplateDetails: [${TENANT_PREFIX}InvoiceTemplateDetailInput!]!) {
    ${TENANT_PREFIX}createInvoiceTemplateDetails(invoiceTemplateDetails: $invoiceTemplateDetails) {
      ...InvoiceTemplateDetailsFragment
      ...BaseFragment
    }
  }
`;
