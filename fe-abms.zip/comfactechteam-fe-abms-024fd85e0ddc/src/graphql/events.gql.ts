import { gql } from '@apollo/client';
import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

export const ALL_EVENTS = gql`
  query ${TENANT_PREFIX}events($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}events(sortArg: $sortArg, searchArg: $searchArg) {
      id
      subject
      status{
        id
        name
      }
      eventType{
        id
        name
      }
      assigneeNames
      relatedTo{
        id
        name
        code
      }
      startDate
      startTime
      endTime
      locationText
      popupReminder
      account {
        id 
      }
      evaluation{
        id
      }
      bill{
        id
        billNo
      }
      invoice{
        id
        invoiceNo
      }
      #training{
       # id
       # trainingNo
      #}
      businessForSale{
        id
        businessNo
      }
      deliveryAndReturn {
        id
        drNo
      }
      eventAssignees {
        assignee {
          firstName
          lastName
        }
      }
      account {
        id
      }
      relatedTasks {
      id
      }
      assigneeJson {
        id
        name
      }
      employee{
        id
        fullName
        firstName
        lastName
      }
      salesOrder{
        id
        soNo
      }
      qualityAudit{
        id
        qaNo
      }
      purchaseOrder{
        id
        poNo
      }
      recruitment{
        id
        recruitmentNo
      }
      recurringId
      eventRecurring {
        date
        dayWeek
        days
        endDate
        frequency
        freqInt
        month
        startDate
        weekOrder
        year
      }
      isVirtual
      parentEventId
      parentEvent {
        id
        subject
      }
    }
  }
`;

export const ALL_EVENTS_ID = gql`
  query ${TENANT_PREFIX}events($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}events(sortArg: $sortArg, searchArg: $searchArg) {
      id
      status{
        id
        name
      }
    }
  }
`;

export const SELECT_EVENT_TYPE = gql`
  query ${TENANT_PREFIX}eventTypes {
    ${TENANT_PREFIX}eventTypes {
      id
      name
    }
  }
`;

export const FIND_EVENT_BY_ID = gql`
  query ${TENANT_PREFIX}findEventById(
    $${TENANT_PREFIX}findEventByIdId: String!
    $isVirtual: Boolean
    $parentEventId: String
    $startDate: String
    $recurringEditOption: String
  ) {
    ${TENANT_PREFIX}findEventById(
      id: $${TENANT_PREFIX}findEventByIdId
      isVirtual: $isVirtual
      parentEventId: $parentEventId
      startDate: $startDate
      recurringEditOption: $recurringEditOption
    ) {
      account {
        id
        name
      }
      bill {
        id
        billNo
      }
      businessForSale {
        id
        businessNo
      }
      case {
        id
        caseNo
      }
      communicationLog {
        id
        createdByName
        createdAt
        commType
      }
      deal {
        id
        dealname
        dealNo
      }
      deliveryAndReturn {
        id
        pickUpLocation
        drNo
      }
      description
      document {
        id
        documentName
      }
      employee{
        id
        fullName
        firstName
        lastName
      }
      endTime
      evaluation {
        id
        evaluationDate
      }
      eventAssignees{
        assignee{
          id
          name
        }
      }
      eventRecurring {
        date
        dayWeek
        days
        endDate
        eventId
        frequency
        freqInt
        id
        month
        startDate
        weekOrder
        year
      }
      eventType{
        id
        name
      }
      eventWatchers{
        watcher{
          id
          name
        }
      }
      id
      invoice {
        id
        invoiceNo
      }
      job {
        id
        jobNo
      }
      jobPurchase {
        id
        jobPurchaseNo
      }
      jobSchedule {
        id
        title
      }
      latitude
      lead {
        id
        lead
        company
      }
      location {
        id
        name
      }
      locationText
      longitude
      popupReminder
      purchaseOrder{
        id
        poNo
      }
      qualityAudit{
        id
        qaNo
      }
      quote {
        id
        quoteNo
      }
      recruitment{
        id
        recruitmentNo
      }
      relatedTasks {
        id
        taskSubject
      }
      relatedTo{
        id
        name
        code
      }
      salesOrder{
        id
        soNo
      }
      sendEmail
      startDate
      startTime
      status{
        id
        name
      }
      # stockControl {
      #   id
      #   controlNo
      # }
      subject
      willCompleteWithNotes
      isVirtual
      parentEventId
    }
  }
`;

export const GET_EVENT_STATUSES = gql`
  query ${TENANT_PREFIX}eventStatuses {
    ${TENANT_PREFIX}eventStatuses {
      id
      name
    }
  }
`;

export const CREATE_EVENT = gql`
  mutation ${TENANT_PREFIX}createEvent($event: ${TENANT_PREFIX}EventInput!) {
    ${TENANT_PREFIX}createEvent(event: $event) {
      id
      redirectId
      isVirtualRedirect
      redirectParentId
      redirectStartDate
    }
  }
`;

export const CREATE_EVENT_ASSIGNEE = gql`
  mutation ${TENANT_PREFIX}createEventAssignees($eventAssignees: [${TENANT_PREFIX}EventAssigneeInput!]!) {
    ${TENANT_PREFIX}createEventAssignees(eventAssignees: $eventAssignees) {
      id
    }
  }
`;

export const CREATE_EVENT_WATCHERS = gql`
  mutation ${TENANT_PREFIX}createEventWatchers($eventWatchers: [${TENANT_PREFIX}EventWatcherInput!]!) {
    ${TENANT_PREFIX}createEventWatchers(eventWatchers: $eventWatchers) {
      id
    }
  }
`;

export const UPDATE_EVENT = gql`
  mutation ${TENANT_PREFIX}updateEvent(
    $event: ${TENANT_PREFIX}EventInput!
    $${TENANT_PREFIX}updateEventId: String!
  ) {
    ${TENANT_PREFIX}updateEvent(event: $event, id: $${TENANT_PREFIX}updateEventId) {
      id
    }
  }
`;

export const DELETE_EVENT_ASSIGNEES = gql`
  mutation ${TENANT_PREFIX}deleteAssigneesByEvent($eventId: String!) {
    ${TENANT_PREFIX}deleteAssigneesByEvent(eventId: $eventId)
  }
`;

export const DELETE_EVENT_WATCHERS = gql`
  mutation ${TENANT_PREFIX}deleteWatchersByEvent($eventId: String!) {
    ${TENANT_PREFIX}deleteWatchersByEvent(eventId: $eventId)
  }
`;

export const ALL_EVENTS_CALENDAR = gql`
  query ${TENANT_PREFIX}events($searchArg: [${TENANT_PREFIX}SearchArg!]) {
  ${TENANT_PREFIX}events(searchArg: $searchArg) {
    id
    orgId
    createdAt
    updatedAt
    deletedAt
    createdBy
    updatedByName
    createdByName
    updatedBy
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    subject
    description
    locationText
    startDate
    startTime
    endTime
    popupReminder
    sendEmail
    willCompleteWithNotes
    eventTypeId
    eventType {
      code
      id
      name
    }
    statusId
    statusNotes
    locationId
    relatedTo {
      code
      color
      id
      name
    }
    taskId
    relatedTasks {
      id
      orgId
      createdAt
      updatedAt
      deletedAt
      createdBy
      updatedByName
      createdByName
      updatedBy
      deletedBy
      recordLocked
      lockedBy
      timeLocked
      taskSubject
      description
      popupReminder
      sendEmail
      sendSMS
      startDate
      startTime
      startTime2
      allDay
      qualityAuditId
      salesOrderId
      purchaseOrderId
      evaluationId
      recruitmentId
      assigneeNames
    }
    recurringId
    eventRecurring {
      date
      dayWeek
      days
      endDate
      frequency
      freqInt
      month
      startDate
      weekOrder
      year
      __typename

    }
    eventWatchers {
      id
      watcher {
        fullName
        firstName
        lastName
        id
        __typename
      }
      __typename
    }
    assigneeJson {
      name
    }
    eventAssignees {
      id
      assignee {
        id
        fullName
        firstName
        lastName
        name
        profilePic
        __typename
      }
      __typename
    }
    relatedToId
    qualityAuditId
    salesOrderId
    purchaseOrderId
    evaluationId
    __typename
    recruitmentId
    trainingId
    invoiceId
    billId
    quoteId
    communicationLogId
    account {
      id
      name
      accountCode {
        accountCode
        accountName
      }
      accountNumber
    }
    job {
      id
      jobNo
    }
    case {
      caseNo
      id
    }
    communicationLog {
      id
    }
    deal {
      id
      dealname
      dealNo
    }
    document {
      id
      documentName
    }
    job {
      id
      jobNo
    }
    lead {
      id
      lead
    }
    quote {
      id
      quoteNo
    }
    location {
      id
      name
    }
    status {
      id
      name
      __typename
    }
    bill{
      id
      billNo
    }
    deliveryAndReturn{
      id
      drNo
    }
    employee{
      id
      fullName
    }
    invoice{
      id
      invoiceNo
    }
    jobPurchase{
      id
      jobPurchaseNo
    }
    purchaseOrder{
      id
      poNo
    }
    qualityAudit{
      id
      qaNo
    }
    recruitment{
      id
      recruitmentNo
    }
    salesOrder{
      id
      soNo
    }
    isVirtual
    parentEventId
    parentEvent {
      id
      subject
    }
  }
}
`;

export const ALL_EVENT_STATUS = gql`
  query ${TENANT_PREFIX}events($sortArg: [abmsSortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}events(sortArg: $sortArg, searchArg: $searchArg) {
      status {
        id
        name
      }
      startDate
      endTime
      eventAssignees {
        assignee {
          name
          id
        }
      }
      startTime
    }
  }
`;

export const DELETE_EVENTS = gql`
  mutation ${TENANT_PREFIX}deleteEvents($events: [${TENANT_PREFIX}EventDeleteInput!]!, $recurringDeleteOption: String) {
    ${TENANT_PREFIX}deleteEvents(events: $events, recurringDeleteOption: $recurringDeleteOption)
  }
`;

export const DELETE_EVENT = gql`
  mutation ${TENANT_PREFIX}deleteEvent(
    $${TENANT_PREFIX}deleteEventId: String!
    $recurringDeleteOption: String
    $isVirtual: Boolean
    $parentEventId: String
    $startDate: String
  ) {
    ${TENANT_PREFIX}deleteEvent(
      id: $${TENANT_PREFIX}deleteEventId
      recurringDeleteOption: $recurringDeleteOption
      isVirtual: $isVirtual
      parentEventId: $parentEventId
      startDate: $startDate
    )
  }
`;

export const UPDATE_EVENT_STATUS = gql`
  mutation ${TENANT_PREFIX}updateEventStatus(
    $${TENANT_PREFIX}updateEventStatusId: String!,
    $status: ${TENANT_PREFIX}EventStatusInput!
  ) {
    ${TENANT_PREFIX}updateEventStatus(id: $${TENANT_PREFIX}updateEventStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_EVENT_DATE = gql`
  mutation ${TENANT_PREFIX}updateEventDate($id: String!, $date: DateTimeISO, $start: DateTimeISO, $end: DateTimeISO) {
    ${TENANT_PREFIX}updateEventDate(id: $id, date: $date, start: $start, end: $end) {
      id
      startDate
    }
  }
`;

export const CREATE_EVENT_RECURRING = gql`
  mutation ${TENANT_PREFIX}createEventRecurring($eventrecurring: ${TENANT_PREFIX}EventRecurringInput!) {
    ${TENANT_PREFIX}createEventRecurring(eventrecurring: $eventrecurring) {
      id
    }
  }
`;

export const UPDATE_EVENT_RECURRING = gql`
  mutation ${TENANT_PREFIX}updateEventRecurring(
    $eventrecurring: ${TENANT_PREFIX}EventRecurringInput!,
    $${TENANT_PREFIX}updateEventRecurringId: String!) {
      ${TENANT_PREFIX}updateEventRecurring(eventrecurring: $eventrecurring, id: $${TENANT_PREFIX}updateEventRecurringId) {
      id
    }
  }`;

export const EVENT_DASHBOARD = gql`
  query ${TENANT_PREFIX}eventDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}eventDashboard(dashboardArg: $dashboardArg) {
      cancelled
      completed
      open
      overdue
    }
  }
`;

export const OLDEST_EVENT_DATE = gql`
  query ${TENANT_PREFIX}oldestEventDate {
    ${TENANT_PREFIX}oldestEventDate
  }
`;

export const PAGINATED_EVENTS = gql`
  query ${TENANT_PREFIX}paginatedEvents($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedEvents(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        id
        subject
        willCompleteWithNotes
        status {
          id
          name
        }
        eventType {
          id
          name
        }
        relatedTo {
          id
          name
          code
        }
        lead {
          id
        }
        assigneeNames
        startDate
        startTime
        endTime
        locationText
        popupReminder
        eventAssignees {
          assignee {
            id
            firstName
            lastName
          }
        }
        account {
          id
        }
       assigneeJson {
        id
        name
       }
       recurringId
       eventRecurring {
         date
         dayWeek
         days
         endDate
         frequency
         freqInt
         month
         startDate
         weekOrder
         year
       }
       isVirtual
       parentEventId
       parentEvent {
         id
         subject
       }
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const GET_EVENT_ASSIGNEE = gql`
  query ${TENANT_PREFIX}findEventById($${TENANT_PREFIX}findEventByIdId: String!) {
    ${TENANT_PREFIX}findEventById(id: $${TENANT_PREFIX}findEventByIdId) {
      eventAssignees {
        assignee {
          id
          email
          name
          mobile
        }
      }
    }
  }
`;
