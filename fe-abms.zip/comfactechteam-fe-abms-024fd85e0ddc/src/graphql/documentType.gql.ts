import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}DocumentType`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const DOCUMENT_TYPE_FRAGMENT = gql`
  fragment DocumentTypeFragment on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_DOCUMENT_TYPES = gql`
  ${DOCUMENT_TYPE_FRAGMENT}
  query paginatedDocumentTypes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedDocumentTypes(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...DocumentTypeFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_DOCUMENT_TYPES = gql`
  ${DOCUMENT_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}documentTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}documentTypes(sortArg: $sortArg, searchArg: $searchArg) {
      ...DocumentTypeFragment
      ...BaseFragment
    }
  }
`;

export const ALL_DOCUMENT_TYPES_IDS = gql`
  query ${TENANT_PREFIX}documentTypes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}documentTypes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_DOCUMENT_TYPE_BY_ID = gql`
  ${DOCUMENT_TYPE_FRAGMENT}
  query findDocumentTypeById($${TENANT_PREFIX}findDocumentTypeByIdId: String!) {
    ${TENANT_PREFIX}findDocumentTypeById(id: $${TENANT_PREFIX}findDocumentTypeByIdId) {
      ...DocumentTypeFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_DOCUMENT_TYPE_BY_ID = gql`
  ${DOCUMENT_TYPE_FRAGMENT}
  mutation updateDocumentType($documentType: ${TENANT_PREFIX}DocumentTypeInput!, $${TENANT_PREFIX}updateDocumentTypeId: String!) {
    ${TENANT_PREFIX}updateDocumentType(documentType: $documentType, id: $${TENANT_PREFIX}updateDocumentTypeId) {
      ...DocumentTypeFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_DOCUMENT_TYPE = gql`
  ${DOCUMENT_TYPE_FRAGMENT}
  mutation createDocumentType($documentType: ${TENANT_PREFIX}DocumentTypeInput!) {
    ${TENANT_PREFIX}createDocumentType(documentType: $documentType) {
      ...DocumentTypeFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_DOCUMENT_TYPE = gql`
  mutation deleteDocumentType($${TENANT_PREFIX}deleteDocumentTypeId: String!) {
    ${TENANT_PREFIX}deleteDocumentType(id: $${TENANT_PREFIX}deleteDocumentTypeId)
  }
`;

export const DELETE_DOCUMENT_TYPES = gql`
  mutation deleteDocumentTypes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteDocumentTypes(ids: $ids)
  }
`;

export const GET_DOCUMENT_TYPE_CSV = gql`
  query ${TENANT_PREFIX}DocumentTypeCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}DocumentTypeCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const SELECT_DOCUMENT_TYPES = gql`
  query ${TENANT_PREFIX}documentTypes {
    ${TENANT_PREFIX}documentTypes {
    id
    name
    }
  }
`;
