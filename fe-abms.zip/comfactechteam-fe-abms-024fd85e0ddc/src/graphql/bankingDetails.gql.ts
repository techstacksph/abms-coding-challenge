import { gql } from '@apollo/client';

import environment from '@/config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

// Fragment for BankingDetails
export const BANKING_DETAIL_FRAGMENT = gql`
  fragment BankingDetailFragment on ${TENANT_PREFIX}BankingDetails {
    id
    bankAccountNo
    notes
    status {
      id
      name
    }
    employee {
      id
      fullName
    }
    createdAt
    updatedAt
  }
`;

// Query to get all banking details for an employee
export const ALL_BANKING_DETAILS = gql`
  query ${TENANT_PREFIX}bankingDetailsList($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}bankingDetailsList(searchArg: $searchArg, sortArg: $sortArg) {
      ...BankingDetailFragment
    }
  }
  ${BANKING_DETAIL_FRAGMENT}
`;

// Query to find a specific banking detail by ID
export const FIND_BANKING_DETAIL_BY_ID = gql`
  query ${TENANT_PREFIX}findBankingDetailsById($${TENANT_PREFIX}findBankingDetailsByIdId: String!) {
    ${TENANT_PREFIX}findBankingDetailsById(id: $${TENANT_PREFIX}findBankingDetailsByIdId) {
      ...BankingDetailFragment
    }
  }
  ${BANKING_DETAIL_FRAGMENT}
`;

// Mutation to create a new banking detail
export const CREATE_BANKING_DETAIL = gql`
  mutation ${TENANT_PREFIX}createBankingDetails($bankingDetails: ${TENANT_PREFIX}BankingDetailsInput!) {
    ${TENANT_PREFIX}createBankingDetails(bankingDetails: $bankingDetails) {
      id
    }
  }
`;

// Query to get status by code for banking details
export const GET_BANKING_DETAIL_STATUS = gql`
  query ${TENANT_PREFIX}getModuleWorkflowStatus {
    ${TENANT_PREFIX}getModuleWorkflowStatus(code: "bankingdetail") {
      id
      name
    }
  }
`;

// Mutation to update an existing banking detail
export const UPDATE_BANKING_DETAIL = gql`
  mutation ${TENANT_PREFIX}updateBankingDetails($${TENANT_PREFIX}updateBankingDetailsId: String!, $bankingDetails: ${TENANT_PREFIX}BankingDetailsInput!) {
    ${TENANT_PREFIX}updateBankingDetails(id: $${TENANT_PREFIX}updateBankingDetailsId, bankingDetails: $bankingDetails) {
      id
    }
  }
`;

// Mutation to delete a banking detail
export const DELETE_BANKING_DETAIL = gql`
  mutation ${TENANT_PREFIX}deleteBankingDetails($${TENANT_PREFIX}deleteBankingDetailsId: String!) {
    ${TENANT_PREFIX}deleteBankingDetails(id: $${TENANT_PREFIX}deleteBankingDetailsId)
  }
`;

// Mutation to delete multiple banking details
export const DELETE_BANKING_DETAILS = gql`
  mutation ${TENANT_PREFIX}deleteAllBankingDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deleteAllBankingDetails(ids: $ids)
  }
`;

// Mutation to update banking detail status
export const UPDATE_BANKING_DETAIL_STATUS = gql`
  mutation ${TENANT_PREFIX}updateBankingDetailsStatus($${TENANT_PREFIX}updateBankingDetailsStatusId: String!, $status: ${TENANT_PREFIX}BankingDetailsStatusInput!) {
    ${TENANT_PREFIX}updateBankingDetailsStatus(id: $${TENANT_PREFIX}updateBankingDetailsStatusId, status: $status) { id }
  }
`;
