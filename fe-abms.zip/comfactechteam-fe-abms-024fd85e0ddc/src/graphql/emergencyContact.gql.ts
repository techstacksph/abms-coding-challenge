import { gql } from '@apollo/client';
import environment from '@/config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}EmergencyContacts`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const EMERGENCY_CONTACT_FRAGMENT = gql`
  fragment EmergencyContactFragment on ${MODEL_NAME} {
    id
    contactName
    relationship
    phoneNo
    mobileNo
    employee { id fullName }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_EMERGENCY_CONTACTS = gql`
  query ${TENANT_PREFIX}emergencyContacts($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}emergencyContacts(searchArg: $searchArg, sortArg: $sortArg) {
      ...EmergencyContactFragment
      ...BaseFragment
    }
  }
  ${EMERGENCY_CONTACT_FRAGMENT}
`;

export const FIND_EMERGENCY_CONTACT_BY_ID = gql`
  query ${TENANT_PREFIX}findEmergencyContactsById($${TENANT_PREFIX}findEmergencyContactsByIdId: String!) {
    ${TENANT_PREFIX}findEmergencyContactsById(id: $${TENANT_PREFIX}findEmergencyContactsByIdId) {
      ...EmergencyContactFragment
      ...BaseFragment
    }
  }
  ${EMERGENCY_CONTACT_FRAGMENT}
`;

export const CREATE_EMERGENCY_CONTACT = gql`
  mutation ${TENANT_PREFIX}createEmergencyContacts($emergencyContacts: ${TENANT_PREFIX}EmergencyContactsInput!) {
    ${TENANT_PREFIX}createEmergencyContacts(emergencyContacts: $emergencyContacts) { id }
  }
`;

export const UPDATE_EMERGENCY_CONTACT = gql`
  mutation ${TENANT_PREFIX}updateEmergencyContacts($emergencyContacts: ${TENANT_PREFIX}EmergencyContactsInput!, $${TENANT_PREFIX}updateEmergencyContactsId: String!) {
    ${TENANT_PREFIX}updateEmergencyContacts(emergencyContacts: $emergencyContacts, id: $${TENANT_PREFIX}updateEmergencyContactsId) { id }
  }
`;

export const DELETE_EMERGENCY_CONTACT = gql`
  mutation ${TENANT_PREFIX}deleteEmergencyContact($${TENANT_PREFIX}deleteEmergencyContactId: String!) {
    ${TENANT_PREFIX}deleteEmergencyContact(id: $${TENANT_PREFIX}deleteEmergencyContactId)
  }
`;

export const DELETE_EMERGENCY_CONTACTS = gql`
  mutation ${TENANT_PREFIX}deleteEmergencyContacts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteEmergencyContacts(ids: $ids)
  }
`;
