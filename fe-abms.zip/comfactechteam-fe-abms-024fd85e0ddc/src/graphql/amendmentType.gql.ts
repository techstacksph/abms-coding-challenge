import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TITLE = 'AmendmentType';
const TITLE_SMALL = TITLE.toLowerCase();
const TITLE_FRAGMENT = 'AmendmentTypeFragment';
const BASE_FRAGMENT_NAME = 'BaseFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);
const PAGINATED_AMENDMENT_TYPE_TITLE = 'paginatedAmendmentTypes';
export const AMENDMENT_TYPE_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    name
    description
    code
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_AMENDMENT_TYPE = gql`
  ${AMENDMENT_TYPE_FRAGMENT}
  query ${PAGINATED_AMENDMENT_TYPE_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_AMENDMENT_TYPE_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_AMENDMENT_TYPE = gql`
  ${AMENDMENT_TYPE_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_AMENDMENT_TYPE_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_AMENDMENT_TYPE_BY_ID = gql`
  ${AMENDMENT_TYPE_FRAGMENT}
  query find${TITLE}ById($${TENANT_PREFIX}find${TITLE}ByIdId: String!) {
    ${TENANT_PREFIX}find${TITLE}ById(id: $${TENANT_PREFIX}find${TITLE}ByIdId) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const UPDATE_AMENDMENT_TYPE_BY_ID = gql`
  ${AMENDMENT_TYPE_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_AMENDMENT_TYPE = gql`
  ${AMENDMENT_TYPE_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

// export const CREATE_AMENDMENT_TYPE = gql`
//   ${AMENDMENT_FRAGMENT}
//   mutation ${TENANT_PREFIX}createAmendment($amendmentType: ${TENANT_PREFIX}AmendmentInput!) {
//     ${TENANT_PREFIX}createAmendment(amendmentType: $amendmentType) {
//       ...AmendmentFragment
//       ...BaseFragment
//     }
//   }
// `;

export const DELETE_AMENDMENT_TYPE = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_AMENDMENT_TYPES = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const GET_AMENDMENT_TYPE_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
