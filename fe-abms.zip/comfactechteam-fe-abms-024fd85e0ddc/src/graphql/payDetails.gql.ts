import { gql } from '@apollo/client';
import environment from '@/config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PayDetail`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PAY_DETAIL_FRAGMENT = gql`
  fragment PayDetailFragment on ${MODEL_NAME} {
    id
    effectiveFrom
    payRate
    payRateFrequency
    workHourPerWeek
    ordinaryWorkDay
    ectRate
    reasonForChange
    notes
    relatedEmploymentHistory
    employee { id fullName }
  }
  ${BASE_FRAGMENT}
`;

export const ALL_PAY_DETAILS = gql`
  query ${TENANT_PREFIX}allPayDetails($employeeId: String!) {
    ${TENANT_PREFIX}allPayDetails(employeeId: $employeeId) {
      ...PayDetailFragment
      ...BaseFragment
    }
  }
  ${PAY_DETAIL_FRAGMENT}
`;

export const FIND_PAY_DETAIL_BY_ID = gql`
  query ${TENANT_PREFIX}findPayDetailById($${TENANT_PREFIX}findPayDetailByIdId: String!) {
    ${TENANT_PREFIX}findPayDetailById(id: $${TENANT_PREFIX}findPayDetailByIdId) {
      ...PayDetailFragment
      ...BaseFragment
    }
  }
  ${PAY_DETAIL_FRAGMENT}
`;

export const CREATE_PAY_DETAIL = gql`
  mutation ${TENANT_PREFIX}createPayDetail($payDetail: ${TENANT_PREFIX}PayDetailInput!) {
    ${TENANT_PREFIX}createPayDetail(payDetail: $payDetail) { id }
  }
`;

export const UPDATE_PAY_DETAIL = gql`
  mutation ${TENANT_PREFIX}updatePayDetail($payDetail: ${TENANT_PREFIX}PayDetailInput!, $${TENANT_PREFIX}updatePayDetailId: String!) {
    ${TENANT_PREFIX}updatePayDetail(payDetail: $payDetail, id: $${TENANT_PREFIX}updatePayDetailId) { id }
  }
`;

export const DELETE_PAY_DETAIL = gql`
  mutation ${TENANT_PREFIX}deletePayDetail($${TENANT_PREFIX}deletePayDetailId: String!) {
    ${TENANT_PREFIX}deletePayDetail(id: $${TENANT_PREFIX}deletePayDetailId)
  }
`;

export const DELETE_PAY_DETAILS = gql`
  mutation ${TENANT_PREFIX}deletePayDetails($ids: [String!]!) {
    ${TENANT_PREFIX}deletePayDetails(ids: $ids)
  }
`;

export const UPDATE_PAY_DETAIL_STATUS = gql`
  mutation ${TENANT_PREFIX}updatePayDetailStatus($${TENANT_PREFIX}updatePayDetailStatusId: String!, $status: ${TENANT_PREFIX}StatusInput!) {
    ${TENANT_PREFIX}updatePayDetailStatus(id: $${TENANT_PREFIX}updatePayDetailStatusId, status: $status) { id }
  }
`;
