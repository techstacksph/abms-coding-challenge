import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ContactCompanies`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CONTACT_COMPANIES_FRAGMENT = gql`
  fragment ContactCompaniesFragment on ${MODEL_NAME} {
    id
    companies {
      id
      companyName
    }
  }
  ${BASE_FRAGMENT}
`;

export const CREATE_CONTACT_COMPANIES = gql`
  ${CONTACT_COMPANIES_FRAGMENT}
  mutation ${TENANT_PREFIX}createContactCompanies($contactCompanies: [${TENANT_PREFIX}ContactCompaniesInput!]!) {
    ${TENANT_PREFIX}createContactCompanies(contactCompanies: $contactCompanies) {
      ...ContactCompaniesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CONTACT_COMPANIES = gql`
  mutation ${TENANT_PREFIX}deleteContactCompanies($ids: [String!]!) {
    ${TENANT_PREFIX}deleteContactCompanies(ids: $ids)
  }
`;
