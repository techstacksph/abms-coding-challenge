import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PreferredProducts`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PREFERRED_PRODUCTS_FRAGMENT = gql`
  fragment PreferredProductsFragment on ${MODEL_NAME} {
    id
    jobId
    job {
      id
      jobNo
    }
    itemId
    item {
      id
      name
      description
      itemCode
      productImage
      itemType
    }
    itemCode
    itemCategoryId
    itemCategory {
      id
      name
    }
    itemSubcategoryId
    itemSubcategory {
      id
      name
    }
    filename
    file
    statusId
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_PREFERRED_PRODUCTS = gql`
  ${PREFERRED_PRODUCTS_FRAGMENT}
  query ${TENANT_PREFIX}preferredProducts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}preferredProducts(sortArg: $sortArg, searchArg: $searchArg) {
      ...PreferredProductsFragment
      ...BaseFragment
    }
  }
`;

export const ALL_PREFERRED_PRODUCT_IDS = gql`
  query ${TENANT_PREFIX}preferredProducts($searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}preferredProducts(searchArg: $searchArg) {
      itemId
    }
  }
`;

export const PAGINATED_PREFERRED_PRODUCTS = gql`
  ${PREFERRED_PRODUCTS_FRAGMENT}
  query ${TENANT_PREFIX}paginatedPreferredProducts(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $pageArg: ${TENANT_PREFIX}PageArg
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
  ) {
    ${TENANT_PREFIX}paginatedPreferredProducts(searchArg: $searchArg, pageArg: $pageArg, sortArg: $sortArg, columnArg: $columnArg) {
      data {
        ...PreferredProductsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const FIND_PREFERRED_PRODUCTS_BY_ID = gql`
  ${PREFERRED_PRODUCTS_FRAGMENT}
  query ${TENANT_PREFIX}findPreferredProductsById($${TENANT_PREFIX}findPreferredProductsByIdId: String!) {
    ${TENANT_PREFIX}findPreferredProductsById(id: $${TENANT_PREFIX}findPreferredProductsByIdId) {
      ...PreferredProductsFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_PREFERRED_PRODUCTS = gql`
  ${PREFERRED_PRODUCTS_FRAGMENT}
  mutation ${TENANT_PREFIX}createPreferredProducts($preferredProducts: ${TENANT_PREFIX}PreferredProductsInput!) {
    ${TENANT_PREFIX}createPreferredProducts(preferredProducts: $preferredProducts) {
      ...PreferredProductsFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_PREFERRED_PRODUCTS = gql`
  ${PREFERRED_PRODUCTS_FRAGMENT}
  mutation ${TENANT_PREFIX}updatePreferredProducts($preferredProducts: ${TENANT_PREFIX}PreferredProductsInput!, $${TENANT_PREFIX}updatePreferredProductsId: String!) {
    ${TENANT_PREFIX}updatePreferredProducts(preferredProducts: $preferredProducts, id: $${TENANT_PREFIX}updatePreferredProductsId) {
      ...PreferredProductsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_PREFERRED_PRODUCT = gql`
  mutation ${TENANT_PREFIX}deletePreferredProduct($${TENANT_PREFIX}deletePreferredProductId: String!) {
    ${TENANT_PREFIX}deletePreferredProduct(id: $${TENANT_PREFIX}deletePreferredProductId)
  }
`;

export const DELETE_PREFERRED_PRODUCTS = gql`
  mutation ${TENANT_PREFIX}deletePreferredProducts($ids: [String!]!) {
    ${TENANT_PREFIX}deletePreferredProducts(ids: $ids)
  }
`;

export const GET_PREFERRED_PRODUCTS_CSV = gql`
  query ${TENANT_PREFIX}preferredProductsCSV(
    $sortArg: [${TENANT_PREFIX}SortArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}preferredProductsCSV(sortArg: $sortArg, searchArg: $searchArg)
  }
`;
