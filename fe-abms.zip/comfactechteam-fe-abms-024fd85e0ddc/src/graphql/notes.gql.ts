import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}Note`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const NOTES_FRAGMENT = gql`
  fragment NotesFragment on ${MODEL_NAME} {
    id
    orgId
    deletedAt
    deletedBy
    recordLocked
    lockedBy
    timeLocked
    notes
    accountId
    account {
      id
      name 
    }
    companyId
    company {
      id
      companyName
    }
    dealId
    deal {
      id
      dealname
    }
    siteId
    site {
      id
      siteName
      lastActivity
    }
    job{
      id
      jobNo
    }
    qualityAuditId
    caseId
    case {
      id
      autoNumber
      caseNo
    }
    task{
      id
    }
    recruitmentId
    deliveryAndReturnId

  }
  ${BASE_FRAGMENT}
`;

export const PAGINATED_NOTES = gql`
  ${NOTES_FRAGMENT}
  query paginatedNotes($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedNotes(searchArg: $searchArg, pageArg: $pageArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...NotesFragment
        ...BaseFragment
      }
    }
  }
`;

export const ALL_NOTES = gql`
  ${NOTES_FRAGMENT}
  query ${TENANT_PREFIX}notes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}notes(sortArg: $sortArg, searchArg: $searchArg) {
      ...NotesFragment
      ...BaseFragment
    }
  }
`;

export const ALL_NOTES_IDS = gql`
  query ${TENANT_PREFIX}notes {
    ${TENANT_PREFIX}notes {
      id
    }
  }
`;

export const ALL_NOTES_IDS_BY_MODULE = gql`
  query ${TENANT_PREFIX}notes($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}notes(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const FIND_NOTE_BY_ID = gql`
  ${NOTES_FRAGMENT}
  query ${TENANT_PREFIX}findNoteById($${TENANT_PREFIX}findNoteByIdId: String!) {
    ${TENANT_PREFIX}findNoteById(id: $${TENANT_PREFIX}findNoteByIdId) {
      ...NotesFragment
      ...BaseFragment
    }
  }
`;

export const CHECK_NOTE = gql`
  query ${TENANT_PREFIX}findNoteById($${TENANT_PREFIX}findNoteByIdId: String!) {
    ${TENANT_PREFIX}findNoteById(id: $${TENANT_PREFIX}findNoteByIdId) {
      id
    }
  }
`;

export const UPDATE_NOTE_BY_ID = gql`
  ${NOTES_FRAGMENT}
  mutation ${TENANT_PREFIX}updateNote($note: ${TENANT_PREFIX}NoteInput!, $${TENANT_PREFIX}updateNoteId: String!) {
    ${TENANT_PREFIX}updateNote(note: $note, id: $${TENANT_PREFIX}updateNoteId) {
      ...NotesFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_NOTE = gql`
  ${NOTES_FRAGMENT}
  mutation ${TENANT_PREFIX}createNote(
    $note: ${TENANT_PREFIX}NoteInput!
    $isVirtual: Boolean
    $parentId: String
    $parentType: ParentType
    $startDate: String
  ) {
    ${TENANT_PREFIX}createNote(
      note: $note
      isVirtual: $isVirtual
      parentId: $parentId
      parentType: $parentType
      startDate: $startDate
    ) {
      ...NotesFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_NOTES = gql`
  mutation ${TENANT_PREFIX}deleteNotes($ids: [String!]!) {
    ${TENANT_PREFIX}deleteNotes(ids: $ids)
  }
`;

export const DELETE_NOTE = gql`
  mutation ${TENANT_PREFIX}deleteNote($${TENANT_PREFIX}deleteNoteId: String!) {
    ${TENANT_PREFIX}deleteNote(id: $${TENANT_PREFIX}deleteNoteId)
  }
`;
