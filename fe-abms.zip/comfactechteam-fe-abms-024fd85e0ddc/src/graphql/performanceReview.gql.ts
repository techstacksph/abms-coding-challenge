import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}PerformanceReview`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const PERFORMANCE_REVIEW_FRAGMENT = gql`
  fragment PerformanceReviewFragment on ${MODEL_NAME} {
    id
    relatedManager {
      id
      firstName
      lastName
      fullName
    }
    relatedManagerId
    employee {
      id
      firstName
      lastName
      fullName
    }
    prDepartments {
      id
      department {
        id
        name
      }
    }
    prQuestionnaires {
      id
      questionnaire {
        id
        questionnaire
        questions {
          id
          name
          type
          description
          numAnswers
          options {
            id
            name
          }
        }
      }
    }
    reviewDate
    dueDate
    notes
    perfReviewNo
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_PERFORMANCE_REVIEWS = gql`
  ${PERFORMANCE_REVIEW_FRAGMENT}
  query ${TENANT_PREFIX}paginatedPerformanceReviews($pageArg: ${TENANT_PREFIX}PageArg!, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}paginatedPerformanceReviews(pageArg: $pageArg, searchArg: $searchArg) {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...PerformanceReviewFragment
        ...BaseFragment
      }
    }
  }
`;

export const SELECT_PERFORMANCE_REVIEWS = gql`
  query ${TENANT_PREFIX}performanceReviews {
    ${TENANT_PREFIX}performanceReviews {
      id
      dueDate
      reviewDate
      score
      status {
        id
        name
      }
    }
  }
`;

export const GET_PERFORMANCE_REVIEW = gql`
  ${PERFORMANCE_REVIEW_FRAGMENT}
  query ${TENANT_PREFIX}performanceReviews($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}performanceReviews(sortArg: $sortArg, searchArg: $searchArg) {
      ...PerformanceReviewFragment
      ...BaseFragment
    }
  }
`;

export const FIND_PERFORMANCE_REVIEW_BY_ID = gql`
  ${PERFORMANCE_REVIEW_FRAGMENT}
  query ${TENANT_PREFIX}findPerformanceReviewById($${TENANT_PREFIX}findPerformanceReviewByIdId: String!) {
    ${TENANT_PREFIX}findPerformanceReviewById(id: $${TENANT_PREFIX}findPerformanceReviewByIdId) {
      ...PerformanceReviewFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_PERFORMANCE_REVIEW_STATUS = gql`
  mutation ${TENANT_PREFIX}updatePerformanceReviewStatus($${TENANT_PREFIX}updatePerformanceReviewStatusId: String!, $status: ${TENANT_PREFIX}PerformanceReviewStatusInput!) {
    ${TENANT_PREFIX}updatePerformanceReviewStatus(id: $${TENANT_PREFIX}updatePerformanceReviewStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_PERFORMANCE_REVIEW = gql`
  mutation ${TENANT_PREFIX}updatePerformanceReview($performanceReview: ${TENANT_PREFIX}PerformanceReviewInput!, $${TENANT_PREFIX}updatePerformanceReviewId: String!) {
    ${TENANT_PREFIX}updatePerformanceReview(performanceReview: $performanceReview, id: $${TENANT_PREFIX}updatePerformanceReviewId) {
      id
    }
  }
`;

export const CREATE_PERFORMANCE_REVIEW = gql`
  mutation ${TENANT_PREFIX}createPerformanceReview($performanceReview: ${TENANT_PREFIX}PerformanceReviewInput!) {
    ${TENANT_PREFIX}createPerformanceReview(performanceReview: $performanceReview) {
      id
      perfReviewNo
    }
  }
`;

export const DELETE_PERFORMANCE_REVIEWS = gql`
  mutation ${TENANT_PREFIX}deletePerformanceReviews($ids: [String!]!) {
    ${TENANT_PREFIX}deletePerformanceReviews(ids: $ids)
  }
`;

export const DELETE_PERFORMANCE_REVIEW = gql`
  mutation ${TENANT_PREFIX}deletePerformanceReview($${TENANT_PREFIX}deletePerformanceReviewId: String!) {
    ${TENANT_PREFIX}deletePerformanceReview(id: $${TENANT_PREFIX}deletePerformanceReviewId)
  }
`;

export const CREATE_PR_DEPARTMENTS = gql`
  mutation ${TENANT_PREFIX}createPRDepartments($prDepartments: [${TENANT_PREFIX}PRDepartmentInput!]!) {
    ${TENANT_PREFIX}createPRDepartments(prDepartments: $prDepartments) {
      id
    }
  }
`;

export const CREATE_PR_QUESTIONNAIRES = gql`
  mutation ${TENANT_PREFIX}createPRQuestionnaires($prQuestionnaires: [${TENANT_PREFIX}PRQuestionnaireInput!]!) {
    ${TENANT_PREFIX}createPRQuestionnaires(prQuestionnaires: $prQuestionnaires) {
      id
    }
  }
`;

export const DELETE_PR_QUESTIONNAIRE_BY_PR = gql`
  mutation ${TENANT_PREFIX}deletePRQuestionnaireByPR($performanceReviewId: String!) {
    ${TENANT_PREFIX}deletePRQuestionnaireByPR(performanceReviewId: $performanceReviewId)
  }
`;

export const DELETE_PR_DEPARTMENT_BY_PR = gql`
  mutation ${TENANT_PREFIX}deletePRDepartmentByPR($performanceReviewId: String!) {
    ${TENANT_PREFIX}deletePRDepartmentByPR(performanceReviewId: $performanceReviewId)
  }
`;

export const GET_PERFORMANCE_REVIEW_DASHBOARD = gql`
  query abmsperformanceReviewsDashboard($dashboardArg: [abmsDashboardArg!]!) {
    abmsperformanceReviewsDashboard(dashboardArg: $dashboardArg) {
      all
      cancelled
      completed
      pending
      reviewInProgreaa
    }
  }
`;

export const ALL_PERFORMANCE_REVIEWS_IDS = gql`
  query ${TENANT_PREFIX}performanceReviews($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}performanceReviews(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const CREATE_PERFORMANCE_REVIEW_QUESTIONS = gql`
  mutation ${TENANT_PREFIX}createPerformanceReviewQuestions($performanceReviewQuestions: [${TENANT_PREFIX}PerformanceReviewQuestionInput!]!) {
    ${TENANT_PREFIX}createPerformanceReviewQuestions(performanceReviewQuestions: $performanceReviewQuestions) {
      id
    }
  }
`;

export const UPDATE_PERFORMANCE_REVIEW_QUESTION = gql`
  mutation ${TENANT_PREFIX}updatePerformanceReviewQuestion($performanceReviewQuestion: ${TENANT_PREFIX}PerformanceReviewQuestionInput!, $${TENANT_PREFIX}updatePerformanceReviewQuestionId: String!) {
    ${TENANT_PREFIX}updatePerformanceReviewQuestion(performanceReviewQuestion: $performanceReviewQuestion, id: $${TENANT_PREFIX}updatePerformanceReviewQuestionId) {
      id
    }
  }
`;

export const DELETE_PERFORMANCE_REVIEW_QUESTIONS = gql`
  mutation ${TENANT_PREFIX}deletePerformanceReviewQuestions($ids: [String!]!) {
    ${TENANT_PREFIX}deletePerformanceReviewQuestions(ids: $ids)
  }
`;

export const GET_PERFORMANCE_REVIEW_QUESTIONS = gql`
  query ${TENANT_PREFIX}performanceReviewQuestions($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}performanceReviewQuestions(sortArg: $sortArg, searchArg: $searchArg) {
      id
      performanceReview {
        id
      }
      questionnaire {
        id
        questionnaire
      }
      question {
        id
        name
        type
        description
        numAnswers
        options {
          id
          name
        }
      }
      rating {
        id
        ratingName
        ratingDescription
        scale
        ratingScales {
          id
          name
          description
          rating
        }
      }
      comment
      prqQuestionnaires {
        id
        questionnaire {
          id
          questionnaire
        }
      }
      prqQuestions {
        id
        question {
          id
          name
          type
          description
          numAnswers
          options {
            id
            name
          }
        }
      }
    }
  }
`;
