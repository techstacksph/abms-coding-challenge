import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragmentWithUniqueName } from './base.gql';

const TITLE = 'Job';
const TITLE_SMALL = TITLE.toLowerCase();
const TITLE_FRAGMENT = 'JobsFragment';
const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}${TITLE}`;
const BASE_FRAGMENT = getBaseFragmentWithUniqueName(MODEL_NAME);
const BASE_FRAGMENT_NAME = `BaseFragment_${MODEL_NAME}`;
const PAGINATED_JOBS_TITLE = 'paginatedJobs';

// New optimized fragment for the flattened jobs list view
export const JOBS_LIST_VIEW_FRAGMENT = gql`
  fragment JobsListViewFragment on ${TENANT_PREFIX}JobsListView {
    id
    jobNo
    forSale
    lookAfter
    workType
    startDate
    endDate
    keyCollectDate
    cancelledDate
    firstInvoice
    dealAmount
    jobAmount
    payableAmount
    
    # Location fields (flattened)
    locationId
    locationName
    locationAddress
    locationCostToBuyRate
    locationCommission
    locationCommissionRate
    locationCommissionType
    
    # Status fields (flattened)
    statusId
    statusName
    
    # Account fields (flattened)
    accountId
    accountName
    accountType
    
    # Site fields (flattened)
    siteId
    siteName
    siteAddress
    lastActivity
    
    # Contact fields (flattened)
    contactId
    contactFullName
    contactJobTitle
    contactPhone
    contactMobile
    contactEmail
    
    # Deal Owner fields (flattened)
    dealOwnerId
    dealOwnerName
    dealOwnerFirstName
    dealOwnerLastName
    dealOwnerJobTitle
    
    # Key Account fields (flattened)
    keyAccountId
    keyAccountName
    keyAccountFirstName
    keyAccountLastName
    
    # Supervisor fields (flattened)
    supervisorId
    supervisorName
    supervisorFirstName
    supervisorLastName
    supervisorJobTitle
    supervisorMobile
    
    # Service provider fields (aggregated as id:name pairs)
    serviceProviders
    serviceProviderIds
    
    # Base fields
    createdAt
    updatedAt
    createdBy
    updatedBy
    createdByName
    updatedByName
  }
`;

// New optimized paginated query using the view
export const PAGINATED_JOBS_VIEW_OPTIMIZED = gql`
  ${JOBS_LIST_VIEW_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}ViewOptimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}Optimized(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobsListViewFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const JOBS_FRAGMENT = gql`
  fragment ${TITLE_FRAGMENT} on ${MODEL_NAME} {
    id
    jobNo
    forSale
    serviceProviderIds
    account {
      id
      accountType
      name
      status {
        id
        name
      }
    }
    invoiceTemplates {  
      id
      invoiceTemplateNo
    }
    billTemplates {
      id
    }
    jobDetails {
      id
      area
      frequency
      notes
      dealOrderDetailsId
      jobSpecification {
        id
        specifications
        dealSpecification {
         id
        }
        time
        variants {
          id
          name
        }
        variantsId
        serviceProviderAssignments {
          id
          serviceProvider {
            id
            name
          }
          days
        }
      }
      serviceProvider {
        id
        name
        accountType
      }
    }
    jobBillings {
      id
      serviceProviderId
      serviceProvider {
        id
        name
      }
      schedule
      cleaningTime
      hours
      jobAmount
      commissionType
      commission
      payableAmount
    }
    site {
      id
      accountId
      siteName
      streetAddress
      suburb
      city
      lastActivity
      region
      country {
        name
      }
      area {
        id
      }
      address
      findStreet
      fullAddress
      createdAt
      updatedAt
    }
    contact {
      id
      address
      firstName
      fullName
      firstName
      lastName
      jobTitle
      mobile
      email
      phone
      status {
      id
      name
      }
    }
    keyAccount {
      name
      fullName
      firstName
      lastName
      id
    }
    serviceProviders {
      serviceProvider {
        accountType
        name
        id
      }
    }
    workType
    jobAmount
    qaFrequency
    qaFrequencyTxt
    startDate
    lookAfter
    status {
      id
      name
    }
    deal {
      id
      dealNo
      dealname
      cleaningTime
      totalCleaningDuration
      notes
      weeksPerAnnum
      specialNotes
      serviceType {
        id
        servicetype
        expenseAccountCode {
          id
          accountCode
        }
        salesAccountCode {
          id
          accountCode
        }
      }
      dealType {
        id
        name
      }
      typeofPremise {
        id
        name
      }
      costingAmount
      recordOwner {
        fullName
        firstName
        id
        lastName
        name
      }
      dealOrderDetails {
        id
        area
        frequency
        notes
        quantity
        relatedItemId
        amount
        duration
        days
        dailyAmount
        weeklyAmount
        minimumCharge
        profitMargin
        dealSpecifications {
          id
          specifications
          variant {
            id
            name
          }
          days
        }
      }
    }
      specialNotes
      deals {
        id
        dealNo
      }
      dealAmount
      dealOwner {
        id
        jobTitle
        fullName
        firstName
        lastName
      }
      telesales {
        fullName
        firstName
        lastName
        id
      }
      weeksPerAnnum
      location {
        id
        fullAddress
        area {
          id
        }
        xeroAccount {
          id
        }
        name
        costToBuyRate
        commission
        commissionRate
        commissionType
      }
      supervisor {
        id
        jobTitle
        fullName
        firstName
        lastName
        mobile
        name
        phone
        email
      }
      keyCollectDate
      cancelledDate
      endDate
      firstInvoice
    qaRecurring {
      id
      startDate
      endDate
      frequency
      freqInt
      days
      date
      weekOrder
      dayWeek
      month
      year
    }
  }
  ${BASE_FRAGMENT}
`;

// Optimized fragment for list view - only includes fields needed for display
export const JOBS_LIST_FRAGMENT = gql`
  fragment JobsListFragment on ${MODEL_NAME} {
    id
    jobNo
    forSale
    lookAfter
    deal {
      id
      dealNo
      dealname
      cleaningTime
      totalCleaningDuration
      serviceType {
        id
        servicetype
        expenseAccountCode {
          id
          accountCode
        }
        salesAccountCode {
          id
          accountCode
        }
      }
      costingAmount
      recordOwner {
        fullName
        firstName
        id
        lastName
        name
      }
      dealOrderDetails {
        id
        area
        frequency
        notes
        quantity
        relatedItemId
        dealSpecifications {
          id
          specifications
          variant {
            id
            name
          }
          days
        }
      }
    }
    dealOwner {
      id
      jobTitle
      fullName
      firstName
      lastName
    }
    workType
    startDate
    account {
      id
      name
      accountType
    }
    site {
      id
      accountId
      siteName
      address
      lastActivity
      suburb
      area{
        id
      }
    }
    contact {
      id
      fullName
      jobTitle
      phone
      mobile
      email
    }
    keyAccount {
      name
      fullName
      firstName
      lastName
      id
    }
    jobDetails {
      id
      area
      frequency
      notes
      dealOrderDetailsId
      dealOrderDetails {
        id
        relatedItemId
      }
      jobSpecification {
        id
        specifications
        dealSpecification {
         id
        }
        time
        variants {
          id
          name
        }
        serviceProviderAssignments {
          id
          serviceProvider {
            id
            name
          }
          days
        }
      }
      serviceProvider {
        id
        name
        accountType
      }
    }
    serviceProviders {
      serviceProvider {
        id
        name
        accountType
      }
    }
    jobBillings {
      id
      serviceProvider {
        id
        name
      }
      schedule
      cleaningTime
      hours
      jobAmount
      commissionType
      commission
      payableAmount
    }
    status {
      id
      name
    }
    location {
        id
      fullAddress
      area {
        id
      }
      name
      costToBuyRate
      commission
      commissionRate
      commissionType
      xeroAccount {
        id
      }
    }
    supervisor {
        id
        jobTitle
        fullName
        firstName
        lastName
        mobile
        name
        phone
        email
    }
    keyCollectDate
    cancelledDate
    endDate
    firstInvoice
    weeksPerAnnum 
    dealAmount
    qaFrequency
    qaRecurring {
      id
      startDate
      endDate
      frequency
      freqInt
      days
      date
      weekOrder
      dayWeek
      month
      year
    }
  }
  ${BASE_FRAGMENT}
`;

// Minimal fragment for jobs list - only includes fields actually displayed in columns
export const JOBS_LIST_MINIMAL_FRAGMENT = gql`
  fragment JobsListMinimalFragment on ${MODEL_NAME} {
    id
    jobNo
    lookAfter
    workType
    startDate
    jobAmount
    dealAmount
    weeksPerAnnum
    keyCollectDate
    forSale
    account {
      id
      name
    }
    site {
      id
      accountId
      siteName
      address
      lastActivity
    }
    contact {
      id
      fullName
      jobTitle
      phone
      mobile
      email
    }
    keyAccount {
      id
      firstName
      lastName
    }
    deal {
      id
    }
    dealOwner {
      id
    }
    location {
      id
    }
    supervisor {
      id
    }
    jobBillings {
      serviceProvider {
        id
        name
      }
      jobAmount
    }
    serviceProviders {
      serviceProvider {
        id
        name
      }
    }
    jobDetails {
      id
      area
      frequency
      notes
      jobSpecification {
        id
        specifications
        variants {
          id
          name
        }
      }
    }
    status {
      id
      name
    }
    qaFrequency
    qaRecurring {
      id
      startDate
      endDate
      frequency
      freqInt
      days
      date
      weekOrder
      dayWeek
      month
      year
    }
  }
  ${BASE_FRAGMENT}
`;

export const JOBS_LIST_MINIMAL_FRAGMENT_TEMPLATES = gql`
  query ${TENANT_PREFIX}jobsMinimalTemplates($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}jobs(sortArg: $sortArg, searchArg: $searchArg) {
      id
      jobNo
      jobBillings {
        serviceProvider {
          id
          name
        }
        jobAmount
      }
      status {
        id
        name
      }
    }
  }
`;

// Original paginated query with full fragment
export const PAGINATED_JOBS = gql`
  ${JOBS_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...${TITLE_FRAGMENT}
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

// Optimized paginated query for list view
export const PAGINATED_JOBS_OPTIMIZED = gql`
  ${JOBS_LIST_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}Optimized($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobsListFragment
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

// Minimal paginated query for jobs list
export const PAGINATED_JOBS_MINIMAL = gql`
  ${JOBS_LIST_MINIMAL_FRAGMENT}
  query ${PAGINATED_JOBS_TITLE}Minimal($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}${PAGINATED_JOBS_TITLE}(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...JobsListMinimalFragment
        ...${BASE_FRAGMENT_NAME}
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  } 
`;

export const ALL_JOBS = gql`
  ${JOBS_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

// Optimized ALL_JOBS query for list view and exports
export const ALL_JOBS_OPTIMIZED = gql`
  ${JOBS_LIST_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}sOptimized($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobsListFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

// Minimal ALL_JOBS query for list view and exports
export const ALL_JOBS_MINIMAL = gql`
  ${JOBS_LIST_MINIMAL_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}sMinimal($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      ...JobsListMinimalFragment
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const ALL_JOBS_IDS = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const SELECT_JOBS = gql`
  query ${TENANT_PREFIX}jobs{
    ${TENANT_PREFIX}jobs{
      id
      jobNo
      serviceProviderIds
    }
  }
`;
export const SELECT_JOBS_WITH_FILTER = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}s($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
      jobNo
    }
  }
`;

// Lightweight jobs query: returns only id and jobNo to reduce read complexity and avoid timeouts
export const ALL_JOBS_LIGHT = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}sLight($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(sortArg: $sortArg, searchArg: $searchArg) {
      id
      jobNo
    }
  }
`;

export const FIND_JOBS_BY_ID = gql`
  ${JOBS_FRAGMENT}
  query findJobById($${TENANT_PREFIX}findJobById: String!) {
    ${TENANT_PREFIX}findJobById(id: $${TENANT_PREFIX}findJobById) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const FIND_JOBS_BY_SEARCH = gql`
  ${JOBS_FRAGMENT}
  query ${TENANT_PREFIX}${TITLE_SMALL}s($searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE_SMALL}s(searchArg: $searchArg, sortArg: $sortArg) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const FIND_JOB_FOR_MARKETPLACE = gql`
  query findJobById($${TENANT_PREFIX}findJobById: String!) {
    ${TENANT_PREFIX}findJobById(id: $${TENANT_PREFIX}findJobById) {
      account
      {
        id
      }
      contact
      {
        id
      }
      dealAmount
      deal{
        id
      }
      dealOwner
      {
        id
      }
      keyAccount
      {
        id
      }
      keyCollectDate
      location
      {
        id
      }
      site
      {
        id
      }
      startDate
      status
      {
        id
      }
      supervisor
      {
        id
      }
      weeksPerAnnum
      workType
    }
  }
`;

export const UPDATE_JOB_BY_ID = gql`
  ${JOBS_FRAGMENT}
  mutation ${TENANT_PREFIX}updateJob($job: ${TENANT_PREFIX}JobInput!, $${TENANT_PREFIX}updateJobId: String!) {
    ${TENANT_PREFIX}updateJob(job: $job, id: $${TENANT_PREFIX}updateJobId) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;
export const UPDATE_JOBS_BY_ID = gql`
  ${JOBS_FRAGMENT}
  mutation update${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!, $${TENANT_PREFIX}update${TITLE}Id: String!) {
    ${TENANT_PREFIX}update${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}, id: $${TENANT_PREFIX}update${TITLE}Id) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const CREATE_JOBS = gql`
  ${JOBS_FRAGMENT}
  mutation create${TITLE}($${TITLE_SMALL}: ${TENANT_PREFIX}${TITLE}Input!) {
    ${TENANT_PREFIX}create${TITLE}(${TITLE_SMALL}: $${TITLE_SMALL}) {
      ...${TITLE_FRAGMENT}
      ...${BASE_FRAGMENT_NAME}
    }
  }
`;

export const DELETE_JOBS = gql`
  mutation delete${TITLE}($${TENANT_PREFIX}delete${TITLE}ById: String!) {
    ${TENANT_PREFIX}delete${TITLE}(id: $${TENANT_PREFIX}delete${TITLE}ById)
  }
`;

export const DELETE_JOBSS = gql`
  mutation delete${TITLE}s($ids: [String!]!) {
    ${TENANT_PREFIX}delete${TITLE}s(ids: $ids)
  }
`;

export const GET_JOBS_CSV = gql`
  query ${TENANT_PREFIX}${TITLE}CSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}${TITLE}CSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

export const JOB_DASHBOARD = gql`
  query ${TENANT_PREFIX}${TITLE_SMALL}sDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!) {
    ${TENANT_PREFIX}${TITLE_SMALL}sDashboard(dashboardArg: $dashboardArg) {
      all
      created
      allocated
      complete
      completed
      cancelled
      cancel
      on_hold
    }
  }
`;

export const UPDATE_JOB_STATUS = gql`
  mutation ${TENANT_PREFIX}updateJobStatus($${TENANT_PREFIX}updateJobStatusId: String!, $status: ${TENANT_PREFIX}JobStatusInput!) {
    ${TENANT_PREFIX}updateJobStatus(id: $${TENANT_PREFIX}updateJobStatusId, status: $status) {
      id
    }
  }
`;

export const ALLOCATE_JOB = gql`
  mutation allocateJob(
    $jobId: String!
    $shouldGenerateSchedules: Boolean
    $startDate: DateTimeISO
    $endDate: DateTimeISO
    $generateFirstInvoice: Boolean
  ) {
    ${TENANT_PREFIX}allocateJob(
      jobId: $jobId
      shouldGenerateSchedules: $shouldGenerateSchedules
      startDate: $startDate
      endDate: $endDate
      generateFirstInvoice: $generateFirstInvoice
    ) {
      id
    }
  }
`;

export const CANCEL_ONE_OFF_JOB = gql`
  mutation ${TENANT_PREFIX}cancelOneOffJobSchedules($job: ${TENANT_PREFIX}CancelJobOneOffInput!) {
    ${TENANT_PREFIX}cancelOneOffJobSchedules(job: $job) {
      id
    }
  }
`;

export const CANCEL_RECURRING_JOB = gql`
  mutation ${TENANT_PREFIX}cancelRecurringJobSchedules($job: ${TENANT_PREFIX}CancelJobRecurringInput!) {
    ${TENANT_PREFIX}cancelRecurringJobSchedules(job: $job) {
      id
      title
      status {
        id
        name
      }
      job {
        id
        jobNo
        status {
          id
          name
        }
      }
    }
  }
`;

export const REVERT_JOB_TO_ALLOCATED = gql`
  mutation ${TENANT_PREFIX}revertJobToAllocated($job: ${TENANT_PREFIX}RevertJobToAllocatedInput!) {
    ${TENANT_PREFIX}revertJobToAllocated(job: $job) {
      id
      title
      status {
        id
        name
      }
      job {
        id
        jobNo
        status {
          id
          name
        }
      }
    }
  }
`;

export const RESCHEDULE_JOB = gql`
  mutation ${TENANT_PREFIX}rescheduleJob($job: ${TENANT_PREFIX}RescheduleJobInput!) {
    ${TENANT_PREFIX}rescheduleJob(job: $job) {
      id
      title
      startDate
      status {
        id
        name
      }
      job {
        id
        jobNo
        status {
          id
          name
        }
      }
    }
  }
`;

export const DRY_RUN_TRANSFER_JOB = gql`
  query ${TENANT_PREFIX}dryRunTransferJob($dryRunTransfer: ${TENANT_PREFIX}DryRunTransferJobInput!) {
    ${TENANT_PREFIX}dryRunTransferJob(dryRunTransfer: $dryRunTransfer) {
      movementRecords {
        id
        serviceProviderId
        serviceProviderName
        from
        to
        jobStartDate
        tookoverDate
        lastCleaningDate
        notes
        noteKey
        isExisting
        isUpdated
        days
        weekdays
        weekends
        continuesToNextPeriod
        serviceProviderIncome
        dailyAmountRC
        receivables
        dailyAmountPY
        payables
      }
      periodsInfo {
        from
        to
        movementCount
      }
    }
  }
`;

export const TRANSFER_JOB = gql`
  mutation ${TENANT_PREFIX}transferJob($transfer: ${TENANT_PREFIX}TransferJobInput!) {
    ${TENANT_PREFIX}transferJob(transfer: $transfer)
  }
`;
