import { gql } from '@apollo/client';

import environment from '../config/environment';

const TENANT_PREFIX = environment.TENANT_PREFIX;

const GLOBAL_SEARCH_FRAGMENT = gql`
  fragment GlobalSearchFragment on ${TENANT_PREFIX}GlobalSearch {
    id
    module
    name
    redirectTo
  }
`;

export const ALL_GLOBAL_SEARCH = gql`
  ${GLOBAL_SEARCH_FRAGMENT}
  query ${TENANT_PREFIX}globalSearch($searchArg: String) {
    ${TENANT_PREFIX}globalSearch(searchArg: $searchArg) {
      ...GlobalSearchFragment
    }
  }
`;
