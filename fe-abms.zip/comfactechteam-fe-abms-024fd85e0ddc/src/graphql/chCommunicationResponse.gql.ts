import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}CHCommunicationResponse`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CHCommunicationResponseFragment = gql`
  fragment CHCommunicationResponseFragment on ${MODEL_NAME} {
    id
    createdAt
    updatedAt
    createdBy
    updatedBy
    createdByName
    updatedByName
    response
    source
    clientHubCommunication {
      id
      subject
      message
      type
      actionRequired
      site {
        id
        siteName
        lastActivity
      }
      status {
        id
        name
      }
    }
  }

  ${BASE_FRAGMENT}
`;

export const GET_CH_COMMUNICATION_RESPONSES = gql`
  query GetCHCommunicationResponses(
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}chcommunicationresponses(searchArg: $searchArg, sortArg: $sortArg) {
      ...CHCommunicationResponseFragment
      ...BaseFragment
    }
  }
  ${CHCommunicationResponseFragment}
`;

export const GET_PAGINATED_CH_COMMUNICATION_RESPONSES = gql`
  query GetPaginatedCHCommunicationResponses(
    $pageArg: ${TENANT_PREFIX}PageArg!
    $searchArg: [${TENANT_PREFIX}SearchArg!]
  ) {
    ${TENANT_PREFIX}paginatedCHCommunicationResponses(
      pageArg: $pageArg
      searchArg: $searchArg
    ) {
      data {
        ...CHCommunicationResponseFragment
        ...BaseFragment
      }
      pageInfo {
        count
        pageSize
        pageCount
        skip
        take
      }
    }
  }
  ${CHCommunicationResponseFragment}
`;

export const GET_CH_COMMUNICATION_RESPONSE_BY_ID = gql`
  query GetCHCommunicationResponseById($${TENANT_PREFIX}findCHCommunicationResponseByIdId: String!) {
    ${TENANT_PREFIX}findCHCommunicationResponseById(id: $${TENANT_PREFIX}findCHCommunicationResponseByIdId) {
      ...CHCommunicationResponseFragment
    }
  }
  ${CHCommunicationResponseFragment}
`;

export const CREATE_CH_COMMUNICATION_RESPONSE = gql`
  mutation CreateCHCommunicationResponse(
    $chcommunicationresponse: ${TENANT_PREFIX}CHCommunicationResponseInput!
  ) {
    ${TENANT_PREFIX}createCHCommunicationResponse(chcommunicationresponse: $chcommunicationresponse) {
      ...CHCommunicationResponseFragment
      ...BaseFragment
    }
  }
  ${CHCommunicationResponseFragment}
`;

export const UPDATE_CH_COMMUNICATION_RESPONSE = gql`
  mutation UpdateCHCommunicationResponse(
    $${TENANT_PREFIX}updateCHCommunicationResponseId: String!
    $chcommunicationresponse: ${TENANT_PREFIX}CHCommunicationResponseInput!
  ) {
    ${TENANT_PREFIX}updateCHCommunicationResponse(id: $${TENANT_PREFIX}updateCHCommunicationResponseId, chcommunicationresponse: $chcommunicationresponse) {
      ...CHCommunicationResponseFragment
    }
  }
  ${CHCommunicationResponseFragment}
`;

export const DELETE_CH_COMMUNICATION_RESPONSE = gql`
  mutation DeleteCHCommunicationResponse($${TENANT_PREFIX}deleteCHCommunicationResponseId: String!) {
    ${TENANT_PREFIX}deleteCHCommunicationResponse(id: $${TENANT_PREFIX}deleteCHCommunicationResponseId)
  }
`;

export const DELETE_CH_COMMUNICATION_RESPONSES = gql`
  mutation DeleteCHCommunicationResponses($ids: [String!]!) {
    ${TENANT_PREFIX}deleteCHCommunicationResponses(ids: $ids)
  }
`;
