import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}FranchiseeOnboarding`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FRANCHISEE_ONBOARDING_FRAGMENT = gql`
  fragment FranchiseeOnboardingFragment on ${MODEL_NAME} {
    id
    onboardingNo
    franchisee {
      id
      name
      recruitmentId
    }
    checklist {
      id
      name
      description
    }
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_SITES = gql`
  ${FRANCHISEE_ONBOARDING_FRAGMENT}
  query PageInfo {
    ${TENANT_PREFIX}paginatedSites {
      pageInfo {
        take
        skip
        pageCount
        count
        pageSize
      }
      data {
        ...FranchiseeOnboardingFragment
        ...BaseFragment
      }
    }
  }
`;

export const SELECT_SITES = gql`
  query ${TENANT_PREFIX}sites{
    ${TENANT_PREFIX}sites{
      id
      siteName
      fullAddress
    }
  }
`;

export const GET_FRANCHISEE_ONBOARDING = gql`
  ${FRANCHISEE_ONBOARDING_FRAGMENT}
  query ${TENANT_PREFIX}franchiseeOnboarding($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}franchiseeOnboarding(sortArg: $sortArg, searchArg: $searchArg) {
      ...FranchiseeOnboardingFragment
      ...BaseFragment
    }
  }
`;

export const FIND_ONBOARDING_BY_ID = gql`
  ${FRANCHISEE_ONBOARDING_FRAGMENT}
  query ${TENANT_PREFIX}findFranchiseeOnboardingById($${TENANT_PREFIX}findFranchiseeOnboardingByIdId: String!) {
    ${TENANT_PREFIX}findFranchiseeOnboardingById(id: $${TENANT_PREFIX}findFranchiseeOnboardingByIdId) {
      ...FranchiseeOnboardingFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_ONBOARDING_STATUS = gql`
  mutation ${TENANT_PREFIX}updateFranchiseeOnboardingStatus($${TENANT_PREFIX}updateFranchiseeOnboardingStatusId: String!, $status: ${TENANT_PREFIX}FranchiseeOnboardingStatusInput!) {
    ${TENANT_PREFIX}updateFranchiseeOnboardingStatus(id: $${TENANT_PREFIX}updateFranchiseeOnboardingStatusId, status: $status) {
      id
    }
  }
`;

export const UPDATE_FRANCHISEE_ONBOARDING = gql`
  mutation ${TENANT_PREFIX}updateFranchiseeOnboarding($franchiseeOnboarding: ${TENANT_PREFIX}FranchiseeOnboardingInput!, $${TENANT_PREFIX}updateFranchiseeOnboardingId: String!) {
    ${TENANT_PREFIX}updateFranchiseeOnboarding(franchiseeOnboarding: $franchiseeOnboarding, id: $${TENANT_PREFIX}updateFranchiseeOnboardingId) {
      id
    }
  }
`;

export const CREATE_FRANCHISEE_ONBOARDING = gql`
  ${FRANCHISEE_ONBOARDING_FRAGMENT}
  mutation ${TENANT_PREFIX}createFranchiseeOnboarding($franchiseeOnboardingInput: ${TENANT_PREFIX}FranchiseeOnboardingInput!) {
    ${TENANT_PREFIX}createFranchiseeOnboarding(franchiseeOnboardingInput: $franchiseeOnboardingInput) {
      ...FranchiseeOnboardingFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FRANCHISEE_ONBOARDINGS = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeOnboardings($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFranchiseeOnboardings(ids: $ids)
  }
`;

export const DELETE_FRANCHISEE_ONBOARDING = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeOnboarding($${TENANT_PREFIX}deleteFranchiseeOnboardingId: String!) {
    ${TENANT_PREFIX}deleteFranchiseeOnboarding(id: $${TENANT_PREFIX}deleteFranchiseeOnboardingId)
  }
`;
