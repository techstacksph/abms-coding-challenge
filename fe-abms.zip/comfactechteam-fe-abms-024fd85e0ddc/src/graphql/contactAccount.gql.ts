import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}ContactAccount`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const CONTACT_ACCOUNTS_FRAGMENT = gql`
  fragment ContactAccountsFragment on ${MODEL_NAME} {
    id
    account {
      id
      name
      status {
        id
        name
      }
      location {
        id
        name
      }
      primaryContact {
        id
        fullName
        firstName
        lastName
        jobTitle
        uploadPhoto
        address
        phone
        mobile
        email
        secondaryEmail
        contactTypes
        status {
          name
        }
      }
      accountType 
    }
    contact {
      id
      fullName
      jobTitle
      uploadPhoto
      address
      firstName
      lastName
      phone
      mobile
      email
      secondaryEmail
      contactTypes
      status {
        name
      }
    }
  }
  ${BASE_FRAGMENT}
`;

export const SELECT_CONTACT_ACCOUNTS = gql`
  query ${TENANT_PREFIX}contactAccounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contactAccounts(sortArg: $sortArg, searchArg: $searchArg) {
      contact {
        id
        fullName
        mobile
        email
        phone
        jobTitle
        status {
          name
        }
      }
    }
  }
`;

export const CONTACT_ACCOUNTS = gql`
  ${CONTACT_ACCOUNTS_FRAGMENT}
  query ${TENANT_PREFIX}contactAccounts($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}contactAccounts(sortArg: $sortArg, searchArg: $searchArg) {
      ...ContactAccountsFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_CONTACT_ACCOUNTS = gql`
  ${CONTACT_ACCOUNTS_FRAGMENT}
  query ${TENANT_PREFIX}paginatedContactAccounts($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedContactAccounts(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...ContactAccountsFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const CREATE_CONTACT_ACCOUNTS = gql`
  ${CONTACT_ACCOUNTS_FRAGMENT}
  mutation ${TENANT_PREFIX}createContactAccounts($contactAccounts: [${TENANT_PREFIX}ContactAccountInput!]!) {
    ${TENANT_PREFIX}createContactAccounts(contactAccounts: $contactAccounts) {
      ...ContactAccountsFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_CONTACT_ACCOUNTS = gql`
  mutation ${TENANT_PREFIX}deleteContactAccounts($ids: [String!]!) {
    ${TENANT_PREFIX}deleteContactAccounts(ids: $ids)
  }
`;

export const GET_SMS_RECIPIENTS = gql`
  query ${TENANT_PREFIX}getToSMSData($searchArg: [abmsSearchArg!], $abmsfindAccountByIdId: String!) {
    ${TENANT_PREFIX}contactAccounts(searchArg: $searchArg) {
      contact {
        id
        fullName
        mobile
      }
    }

    ${TENANT_PREFIX}findAccountById(id: $${TENANT_PREFIX}findAccountByIdId) {
      primaryContact {
        id
        fullName
        mobile
      }
    }
  }
`;
