import { gql } from '@apollo/client';
import environment from '@/config/environment';

import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}BatchJobTransfer`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const BATCH_JOB_TRANSFER_FRAGMENT = gql`
  fragment BatchJobTransferFragment on ${MODEL_NAME} {
    id
    transferNo
    allJob
    transferDate
    notes
    referenceServiceProvider {
      id
      name
    }
    newServiceProvider {
      id
      name
    }
    location {
      id
      name
    }
    status {
      id
      name
    }
  }

  ${BASE_FRAGMENT}
`;

export const ALL_BATCH_JOB_TRANSFERS = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  query ${TENANT_PREFIX}batchJobTransfers($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}batchJobTransfers(sortArg: $sortArg, searchArg: $searchArg) {
      ...BatchJobTransferFragment
      ...BaseFragment
    }
  }
`;

export const PAGINATED_BATCH_JOB_TRANSFERS = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  query paginatedBatchJobTransfers($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedBatchJobTransfers(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...BatchJobTransferFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const FIND_BATCH_JOB_TRANSFER_BY_ID = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  query ${TENANT_PREFIX}findBatchJobTransferById($${TENANT_PREFIX}findBatchJobTransferByIdId: String!) {
    ${TENANT_PREFIX}findBatchJobTransferById(id: $${TENANT_PREFIX}findBatchJobTransferByIdId) {
      ...BatchJobTransferFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_BATCH_JOB_TRANSFER = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  mutation createBatchJobTransfer($batchJobTransfer: ${TENANT_PREFIX}BatchJobTransferInput!) {
    ${TENANT_PREFIX}createBatchJobTransfer(batchJobTransfer: $batchJobTransfer) {
      ...BatchJobTransferFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_BATCH_JOB_TRANSFER_BY_ID = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  mutation updateBatchJobTransfer($batchJobTransfer: ${TENANT_PREFIX}BatchJobTransferInput!, $${TENANT_PREFIX}updateBatchJobTransferId: String!) {
    ${TENANT_PREFIX}updateBatchJobTransfer(batchJobTransfer: $batchJobTransfer, id: $${TENANT_PREFIX}updateBatchJobTransferId) {
      ...BatchJobTransferFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_BATCH_JOB_TRANSFERS = gql`
  mutation deleteBatchJobTransfers($ids: [String!]!) {
    deleteBatchJobTransfers(ids: $ids) {
      id
    }
  }
`;

export const DELETE_BATCH_JOB_TRANSFER = gql`
  mutation deleteBatchJobTransfer($${TENANT_PREFIX}deleteBatchJobTransferId: String!) {
    ${TENANT_PREFIX}deleteBatchJobTransfer(id: $${TENANT_PREFIX}deleteBatchJobTransferId)
  }
`;

export const ALL_BATCH_JOB_TRANSFER_IDS = gql`
  query ${TENANT_PREFIX}batchJobTransfers($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}batchJobTransfers(sortArg: $sortArg, searchArg: $searchArg) {
      id
    }
  }
`;

export const UPDATE_BATCH_JOB_TRANSFER_STATUS = gql`
  ${BATCH_JOB_TRANSFER_FRAGMENT}
  mutation updateBatchJobTransferStatus($${TENANT_PREFIX}updateBatchJobTransferStatusId: String!, $${TENANT_PREFIX}updateBatchJobTransferStatusStatusId: String!) {
    ${TENANT_PREFIX}updateBatchJobTransferStatus(id: $${TENANT_PREFIX}updateBatchJobTransferStatusId, statusId: $${TENANT_PREFIX}updateBatchJobTransferStatusStatusId) {
      ...BatchJobTransferFragment
      ...BaseFragment
    }
  }
`;

export const BATCH_JOB_TRANSFER_DASHBOARD = gql`
  query ${TENANT_PREFIX}batchJobTransferDashboard($dashboardArg: [${TENANT_PREFIX}DashboardArg!]!, $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}batchJobTransferDashboard(dashboardArg: $dashboardArg, searchArg: $searchArg) {
      all
      ongoing
      completed
      voided
    }
  }
`;

// CSV Export
export const GET_BATCH_JOB_TRANSFER_CSV = gql`
  query ${TENANT_PREFIX}BatchJobTransferCSV(
    $columnArg: [${TENANT_PREFIX}ColumnArg!]
    $searchArg: [${TENANT_PREFIX}SearchArg!]
    $sortArg: [${TENANT_PREFIX}SortArg!]
  ) {
    ${TENANT_PREFIX}BatchJobTransferCSV(
      columnArg: $columnArg
      searchArg: $searchArg
      sortArg: $sortArg
    )
  }
`;
