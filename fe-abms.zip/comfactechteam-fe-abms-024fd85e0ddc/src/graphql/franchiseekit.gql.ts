import { gql } from '@apollo/client';

import environment from '../config/environment';
import { getBaseFragment } from './base.gql';

const TENANT_PREFIX = environment.TENANT_PREFIX;
const MODEL_NAME = `${TENANT_PREFIX}FranchiseeKit`;
const BASE_FRAGMENT = getBaseFragment(MODEL_NAME);

export const FRANCHISEE_KIT_FRAGMENT = gql`
  fragment FranchiseeKitFragment on ${MODEL_NAME} {
    id
    kit
    issuedBy{
      id
      firstName
      lastName
    }
    issuedDate
    notes
  }

  ${BASE_FRAGMENT}
`;

export const PAGINATED_FRANCHISEE_KITS = gql`
  ${FRANCHISEE_KIT_FRAGMENT}
  query paginatedFranchiseeKits($searchArg: [${TENANT_PREFIX}SearchArg!], $pageArg: ${TENANT_PREFIX}PageArg) {
    ${TENANT_PREFIX}paginatedFranchiseeKits(searchArg: $searchArg, pageArg: $pageArg) {
      data {
        ...FranchiseeKitFragment
        ...BaseFragment
      }
      pageInfo {
        count
        skip
        take
        pageSize
        pageCount
      }
    }
  }
`;

export const ALL_FRANCHISEE_KITS = gql`
  ${FRANCHISEE_KIT_FRAGMENT}
  query ${TENANT_PREFIX}franchiseeKits($sortArg: [${TENANT_PREFIX}SortArg!], $searchArg: [${TENANT_PREFIX}SearchArg!]) {
    ${TENANT_PREFIX}franchiseeKits(sortArg: $sortArg, searchArg: $searchArg) {
      ...FranchiseeKitFragment
      ...BaseFragment
    }
  }
`;

export const FIND_FRANCHISEE_KIT_BY_ID = gql`
  ${FRANCHISEE_KIT_FRAGMENT}
  query ${TENANT_PREFIX}findFranchiseeKitById($${TENANT_PREFIX}findFranchiseeKitByIdId: String!) {
    ${TENANT_PREFIX}findFranchiseeKitById(id: $${TENANT_PREFIX}findFranchiseeKitByIdId) {
      ...FranchiseeKitFragment
      ...BaseFragment
    }
  }
`;

export const UPDATE_FRANCHISEE_KIT_BY_ID = gql`
  ${FRANCHISEE_KIT_FRAGMENT}
  mutation ${TENANT_PREFIX}updateFranchiseeKit($franchiseeKit: ${TENANT_PREFIX}FranchiseeKitInput!, $${TENANT_PREFIX}updateFranchiseeKitId: String!) {
    ${TENANT_PREFIX}updateFranchiseeKit(franchiseeKit: $franchiseeKit, id: $${TENANT_PREFIX}updateFranchiseeKitId) {
      ...FranchiseeKitFragment
      ...BaseFragment
    }
  }
`;

export const CREATE_FRANCHISEE_KIT = gql`
  ${FRANCHISEE_KIT_FRAGMENT}
  mutation ${TENANT_PREFIX}createFranchiseeKit($franchiseeKit: ${TENANT_PREFIX}FranchiseeKitInput!) {
    ${TENANT_PREFIX}createFranchiseeKit(franchiseeKit: $franchiseeKit) {
      ...FranchiseeKitFragment
      ...BaseFragment
    }
  }
`;

export const DELETE_FRANCHISEE_KIT = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeKit($${TENANT_PREFIX}deleteFranchiseeKitId: String!) {
    ${TENANT_PREFIX}deleteFranchiseeKit(id: $${TENANT_PREFIX}deleteFranchiseeKitId)
  }
`;

export const DELETE_FRANCHISEE_KITS = gql`
  mutation ${TENANT_PREFIX}deleteFranchiseeKits($ids: [String!]!) {
    ${TENANT_PREFIX}deleteFranchiseeKits(ids: $ids)
  }
`;
