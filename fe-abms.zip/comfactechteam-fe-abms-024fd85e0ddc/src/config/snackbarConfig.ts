import { ArgsProps, NotificationConfig } from 'antd/es/notification/interface';
import { DuplicatePreventionConfig } from '../utils/snackbar.utils';

export const snackbarConfig: Partial<ArgsProps> = {
  duration: 5,
  message: '', // Will be overridden when called
};

export const config: NotificationConfig = {
  placement: 'topRight' as const,
  maxCount: 1, // Allow up to 3 notifications at once
};

export const duplicatePreventionConfig: DuplicatePreventionConfig = {
  timeWindow: 3000, // Prevent duplicates for 3 seconds
  preventByContent: true, // Prevent based on message content
  preventByTypeAndContent: false, // Allow same content with different types (success vs error)
};
