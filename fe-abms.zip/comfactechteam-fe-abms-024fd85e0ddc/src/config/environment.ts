/// <reference types="vite/client" />
// Environment configuration aligned from all 5 repositories

// Helper function to validate required environment variables
const validateRequiredEnvVar = (
  name: string,
  value: string | undefined
): string => {
  if (!value) {
    throw new Error(
      `Required environment variable ${name} is not set. ` +
        `Please check your .env file and ensure ${name} is properly configured. ` +
        `You can copy env.example to .env and update the values.`
    );
  }
  return value;
};

// Validate required environment variables
const APOLLO_URI = validateRequiredEnvVar(
  'VITE_APOLLO_URI',
  import.meta.env.VITE_APOLLO_URI
);
const AUTH_URI = validateRequiredEnvVar(
  'VITE_AUTH_URI',
  import.meta.env.VITE_AUTH_URI
);
const API_URL = validateRequiredEnvVar(
  'VITE_API_URL',
  import.meta.env.VITE_API_URL
);

const environment = {
  // API Service Endpoints
  APOLLO_URI,
  APOLLO_WS: import.meta.env.VITE_APOLLO_WS || '',
  AUTH_URI,

  // ABMS Backend Service (for OAuth callbacks and direct backend communication)
  ABMS_BACKEND_URI:
    import.meta.env.VITE_ABMS_BACKEND_URI || 'http://localhost:8083',

  // Legacy API URL
  API_URL,
  API_TIMEOUT: parseInt(import.meta.env.VITE_API_TIMEOUT || '5000'),

  // Tenant Configuration
  TENANT_PREFIX: import.meta.env.VITE_TENANT_PREFIX || 'abms',

  // External Services
  GOOGLE_API_KEY: import.meta.env.VITE_GOOGLE_API_KEY,

  // Logging Configuration
  LOG_LEVEL: import.meta.env.VITE_LOG_LEVEL || 'info',

  // Development Configuration
  NODE_ENV: import.meta.env.MODE,
  BUSINESS_PORTAL_URL: (() => {
    const env = import.meta.env.VITE_ENV || 'LOCAL';
    const envVars = {
      LOCAL: import.meta.env.VITE_BUSINESS_PORTAL_URL_LOCAL,
      DEV: import.meta.env.VITE_BUSINESS_PORTAL_URL_DEV,
      SANDBOX: import.meta.env.VITE_BUSINESS_PORTAL_URL_SANDBOX,
      PRODUCTION: import.meta.env.VITE_BUSINESS_PORTAL_URL_PRODUCTION,
    };
    return envVars[env as keyof typeof envVars] || '';
  })(),
  QUOTE_PORTAL_URL: (() => {
    const env = import.meta.env.VITE_ENV || 'LOCAL';
    const envVars = {
      LOCAL:
        import.meta.env.VITE_QUOTE_PORTAL_URL_LOCAL || 'http://localhost:3000',
      DEV: import.meta.env.VITE_QUOTE_PORTAL_URL_DEV,
      SANDBOX: import.meta.env.VITE_QUOTE_PORTAL_URL_SANDBOX,
      PRODUCTION: import.meta.env.VITE_QUOTE_PORTAL_URL_PRODUCTION,
    };
    return envVars[env as keyof typeof envVars] || '';
  })(),
};

export default environment;
