import { isValueValid } from '@/utils/helper.utils';
import { CaseType, convertCase } from '@/utils/string.utils';

// Chart configuration for Ant Design Charts
export const axisConfig = {
  x: {
    fontFamily: 'Manrope',
    fontSize: 12,
    fontWeight: 400,
    fill: '#717A89',
    labelFontFamily: 'Manrope',
    labelFontWeight: 400,
    labelAutoRotate: false,
    labelAutoHide: false,
    labelFontSize: 12,
    labelFill: '#717A89',
    line: true,
    titleFontFamily: 'Manrope',
    titleFontSize: 12,
    titleFontWeight: 400,
    titleFill: '#717A89',
    title: false,
    tick: true,
    labelFormatter: (text: string) => {
      return isValueValid(text) && typeof text === 'string'
        ? convertCase(text, CaseType.SENTENCE_CASE)
        : text;
    },
  },
  y: {
    fontFamily: 'Manrope',
    fontSize: 12,
    fontWeight: 400,
    fill: '#717A89',
    grid: true,
    labelFontFamily: 'Manrope',
    labelFontWeight: 400,
    labelFill: '#717A89',
    labelAutoRotate: false,
    labelAutoHide: false,
    labelFontSize: 12,
    line: true,
    title: false,
    tick: true,
    titleFontFamily: 'Manrope',
    titleFontSize: 12,
    titleFontWeight: 400,
    titleFill: '#717A89',
  },
};

export const chartConfig = {
  column: {
    axis: axisConfig,
  },
  dualAxes: {
    axis: axisConfig,
  },
};

export const themeConfig = {
  styleSheet: {
    fontFamily: 'Manrope',
    fontSize: 12,
    fontWeight: 400,
    // fill: '#717A89',
    fill: '#000',
  },
};
