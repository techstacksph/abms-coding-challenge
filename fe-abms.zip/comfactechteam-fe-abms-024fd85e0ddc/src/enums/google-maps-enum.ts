export const GOOGLE_MAP_ZOOM = 100;
