export enum ParentType {
  TASK = 'TASK',
  EVENT = 'EVENT',
}
