export enum NotificationAndAlertIconsEnum {
  EVENT = 'EVENT',
  TASK_ALT = 'TASK_ALT',
  ALARM = 'ALARM',
  NOTIFICATIONS = 'NOTIFICATIONS',
}
