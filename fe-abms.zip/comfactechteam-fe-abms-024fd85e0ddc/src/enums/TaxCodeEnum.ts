export enum SourceOfIncomeEnum {
  PRIMARY = 'PRIMARY',
  SECONDARY = 'SECONDARY',
  OTHER_INCOME = 'OTHER_INCOME',
  NON_DISCLOSED = 'NON_DISCLOSED',
}

export enum TaxCodeEnum {
  ND = 'ND',
  M = 'M',
  M_SL = 'M SL',
  ME = 'ME',
  ME_SL = 'ME SL',
  SB = 'SB',
  SB_SL = 'SB_SL',
  S = 'S',
  S_SL = 'S SL',
  SH = 'SH',
  SH_SL = 'SH SL',
  ST = 'ST',
  ST_SL = 'ST SL',
  SA = 'SA',
  SA_SL = 'SA SL',
  CAE = 'CAE',
  EDW = 'EDW',
  NSW = 'NSW',
  STC = 'STC',
  STC_SL = 'STC SL',
}