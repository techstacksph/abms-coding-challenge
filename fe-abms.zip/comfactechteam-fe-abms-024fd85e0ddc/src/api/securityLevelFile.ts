/**
 * Security Level Configuration API Service
 *
 * Updates security level configuration via msvc-authorization endpoints
 * This is for DEV/SANDBOX environments only
 */

import axios from 'axios';
import Cookies from 'universal-cookie';
import env from '@/config/environment';
import { SecurityLevelConfigurationDto } from '@/unathorized-components/dto/SecurityLevelDto';

const cookies = new Cookies();

/**
 * Get Authorization headers with JWT token from cookies
 */
const getAuthHeaders = () => {
  const accessToken = cookies.get('access_token');
  const refreshToken = cookies.get('refresh_token');
  return {
    ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    ...(refreshToken ? { refresh_token: refreshToken } : {}),
    'Content-Type': 'application/json',
  };
};

export interface SecurityLevelConfig {
  id: string;
  name: 'Low' | 'Medium' | 'High';
  configuration: SecurityLevelConfigurationDto;
}

/**
 * Get security level by name from database
 */
export const readSecurityLevelFromFile = async (
  levelName: 'Low' | 'Medium' | 'High'
): Promise<SecurityLevelConfig | null> => {
  try {
    // Query security levels and find by name
    const response = await axios.get(
      `${env.AUTH_URI}/v1/security-levels/by-name/${levelName}`,
      {
        headers: getAuthHeaders(),
      }
    );
    return response.data;
  } catch (error) {
    console.error(`Failed to read security level for ${levelName}:`, error);
    throw error;
  }
};

/**
 * Update security level configuration in database
 */
export const writeSecurityLevelToFile = async (
  levelName: 'Low' | 'Medium' | 'High',
  configuration: SecurityLevelConfigurationDto
): Promise<void> => {
  try {
    // First get the security level to find its ID
    const level = await readSecurityLevelFromFile(levelName);
    if (!level) {
      throw new Error(`Security level '${levelName}' not found`);
    }

    // Update the configuration
    await axios.patch(
      `${env.AUTH_URI}/v1/security-levels/${level.id}/configuration`,
      { configuration },
      {
        headers: getAuthHeaders(),
      }
    );
  } catch (error) {
    console.error(`Failed to update security level for ${levelName}:`, error);
    throw error;
  }
};

/**
 * Get all security level configurations from database
 */
export const getAllSecurityLevelsFromFile = async (): Promise<
  SecurityLevelConfig[]
> => {
  try {
    const response = await axios.get(`${env.AUTH_URI}/v1/security-levels`, {
      headers: getAuthHeaders(),
    });
    return response.data;
  } catch (error) {
    console.error('Failed to read all security levels:', error);
    throw error;
  }
};

/**
 * Get description of what is being edited
 */
export const getSecurityLevelFilePath = (): string => {
  return 'Database (securityLevels table) via msvc-authorization API';
};
