import axios from 'axios';

import environment from '../config/environment';
import { ChangePasswordDto } from '../dto/changePasswordDto';
import { apiErrorMessages } from '../utils/messages.utils';

export const changePassword = async (data: ChangePasswordDto): Promise<any> => {
  try {
    const result = await axios.patch(
      `${environment.API_URL}/v1/auth/user/change-password-token`,
      JSON.stringify({
        password: data.password,
        token: data.token,
        userName: data.userName,
      }),
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    return result?.data;
  } catch (err) {
    const errorObj = err as any;
    if (errorObj?.response) {
      const { data } = errorObj.response;
      const error = apiErrorMessages[data.message];
      throw error;
    }

    throw errorObj?.message;
  }
};
