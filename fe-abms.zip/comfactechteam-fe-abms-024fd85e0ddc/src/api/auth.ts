import axios from 'axios';

import environment from '@/config/environment';
import { apiErrorMessages } from '../utils/messages.utils';

export const resetPassword = async (email: string, loginName: string) => {
  try {
    const result = await axios.post(
      `${environment.API_URL}/v1/auth/user/generate-token`,
      {
        email,
        host: window.location.origin,
        loginName,
      }
    );

    if (result?.data) {
      return result.data?.valid;
    }
  } catch (err) {
    const errorObj = err as any;
    if (errorObj?.response) {
      const { data } = errorObj.response;
      const error = apiErrorMessages[data.message];
      throw error;
    }

    throw errorObj?.message;
  }
};
