export class ChangePasswordDto {
  password!: string;
  token!: string;
  userName!: string;
}
