import React, { createContext, useContext, ReactNode } from 'react';
import { useRecordLock, RecordLockInfo } from '@/hooks/useRecordLock';

interface RecordLockContextValue {
  /**
   * Current lock information
   */
  lockInfo: RecordLockInfo | null;

  /**
   * Whether lock operation is in progress
   */
  isLoading: boolean;

  /**
   * Whether the record can be edited (lock is owned by current user)
   */
  canEdit: boolean;

  /**
   * Acquire lock for the record
   */
  acquireLock: () => Promise<boolean>;

  /**
   * Release lock for the record
   */
  releaseLock: () => Promise<boolean>;

  /**
   * Refresh lock status
   */
  refreshLock: () => void;
}

const RecordLockContext = createContext<RecordLockContextValue | null>(null);

export interface RecordLockProviderProps {
  /**
   * Record type (e.g., 'job', 'contact', 'account')
   */
  recordType: string;

  /**
   * Record ID
   */
  recordId: string;

  /**
   * Whether to automatically acquire lock on mount
   * Default: true
   */
  autoAcquire?: boolean;

  /**
   * Whether to automatically release lock on unmount
   * Default: true
   */
  autoRelease?: boolean;

  /**
   * Children components
   */
  children: ReactNode;
}

/**
 * Provider component that manages record locking for all child components
 *
 * @example
 * ```tsx
 * <RecordLockProvider recordType="job" recordId="123" autoAcquire>
 *   <JobEditForm />
 * </RecordLockProvider>
 * ```
 */
export const RecordLockProvider: React.FC<RecordLockProviderProps> = ({
  recordType,
  recordId,
  autoAcquire = true,
  autoRelease = true,
  children,
}) => {
  const lockState = useRecordLock({
    recordType,
    recordId,
    autoAcquire,
    autoRelease,
    pollInterval: 30000, // Poll every 30 seconds
  });

  return (
    <RecordLockContext.Provider value={lockState}>
      {children}
    </RecordLockContext.Provider>
  );
};

/**
 * Hook to access record lock context
 *
 * @example
 * ```tsx
 * const { canEdit, lockInfo } = useRecordLockContext();
 *
 * if (!canEdit) {
 *   return <div>Record is locked</div>;
 * }
 * ```
 */
export const useRecordLockContext = (): RecordLockContextValue => {
  const context = useContext(RecordLockContext);

  if (!context) {
    throw new Error(
      'useRecordLockContext must be used within a RecordLockProvider'
    );
  }

  return context;
};

/**
 * Hook to safely access record lock context without throwing error
 * Returns null if not within RecordLockProvider
 * Useful for components that should work with or without record locking
 *
 * @example
 * ```tsx
 * const lockContext = useRecordLockContextSafe();
 * const lockInfo = lockContext?.lockInfo;
 *
 * // lockInfo will be null if not wrapped in RecordLockProvider
 * ```
 */
export const useRecordLockContextSafe = (): RecordLockContextValue | null => {
  const context = useContext(RecordLockContext);
  return context;
};
