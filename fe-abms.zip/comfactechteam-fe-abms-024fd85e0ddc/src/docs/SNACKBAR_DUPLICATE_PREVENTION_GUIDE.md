# Snackbar Duplicate Prevention Guide

## Overview

This guide explains how to prevent duplicate snackbar messages in the fe-abms application. The implementation provides automatic deduplication of identical messages within a configurable time window, improving user experience by preventing message spam.

## Problem Statement

Before this implementation, the application had the following issues:

1. **Duplicate messages**: Rapid user interactions could trigger identical snackbar messages
2. **Message spam**: Multiple identical notifications could appear simultaneously
3. **Poor user experience**: Users were overwhelmed by duplicate notifications
4. **No control mechanism**: No way to prevent or control duplicate messages

## Solution

The solution implements a message tracking system that prevents duplicate messages based on content and optionally message type, within a configurable time window.

## Key Features

### 1. **Automatic Deduplication**

- Messages with identical content are prevented within a time window (default: 3 seconds)
- Configurable time window for different use cases
- Memory efficient with automatic cleanup of expired entries

### 2. **Flexible Configuration**

- Prevent by content only (default)
- Prevent by content and type combination
- Customizable time windows
- Manual tracker clearing

### 3. **Backward Compatibility**

- Original snackbar functionality remains unchanged
- New duplicate-checking functions are additive
- Existing code continues to work without modification

## Usage Examples

### Basic Usage

```typescript
import { useSnackbarWithDuplicateCheck } from '@/hooks/useSnackbarWithDuplicateCheck';

const MyComponent = () => {
  const showMessage = useSnackbarWithDuplicateCheck();

  const handleSave = async () => {
    try {
      await saveData();
      // This will only show once even if called multiple times rapidly
      showMessage.success('Data saved successfully!');
    } catch (error) {
      showMessage.error('Failed to save data');
    }
  };

  return <button onClick={handleSave}>Save</button>;
};
```

### Form Submission

```typescript
const FormComponent = () => {
  const showMessage = useSnackbarWithDuplicateCheck();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (isSubmitting) return;

    setIsSubmitting(true);
    try {
      await submitForm();
      // Prevents duplicate success messages
      showMessage.success('Form submitted successfully!');
    } catch (error) {
      showMessage.error('Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <button onClick={handleSubmit} disabled={isSubmitting}>
      Submit
    </button>
  );
};
```

### Mutation Hook Integration

```typescript
const useMutationWithSnackbar = (mutationFn, successMessage) => {
  const showMessage = useSnackbarWithDuplicateCheck();

  return useMutation({
    mutationFn,
    onSuccess: () => {
      // Automatic deduplication prevents spam
      showMessage.success(successMessage);
    },
    onError: error => {
      showMessage.error('Operation failed');
    },
  });
};
```

## Configuration

### Default Configuration

```typescript
// src/config/snackbarConfig.ts
export const duplicatePreventionConfig: DuplicatePreventionConfig = {
  timeWindow: 3000, // 3 seconds
  preventByContent: true, // Prevent based on message content
  preventByTypeAndContent: false, // Allow same content with different types
};
```

### Custom Configuration

```typescript
import { snackbarUtils } from '@/utils/snackbar.utils';

// Configure globally
snackbarUtils.configure({
  timeWindow: 5000, // 5 seconds
  preventByTypeAndContent: true, // Stricter prevention
});

// Or configure per use case
const handleSpecialCase = () => {
  snackbarUtils.configure({ timeWindow: 1000 }); // 1 second for this case
  showMessage.info('Special message');
  snackbarUtils.configure({ timeWindow: 3000 }); // Reset to default
};
```

## API Reference

### useSnackbarWithDuplicateCheck()

Returns an object with duplicate-checking snackbar functions:

```typescript
interface SnackbarWithDuplicateCheck {
  show: (message: SnackbarMessage) => boolean;
  success: (message: ReactNode | string) => boolean;
  error: (message: ReactNode | string) => boolean;
  warning: (message: ReactNode | string) => boolean;
  info: (message: ReactNode | string) => boolean;
  originalSnackbar: (config: any) => void;
}
```

### snackbarUtils

Utility functions for managing duplicate prevention:

```typescript
snackbarUtils.configure(config: Partial<DuplicatePreventionConfig>): void
snackbarUtils.clearTracker(): void
snackbarUtils.getConfig(): DuplicatePreventionConfig
snackbarUtils.success(message, snackbarFn): boolean
snackbarUtils.error(message, snackbarFn): boolean
snackbarUtils.warning(message, snackbarFn): boolean
snackbarUtils.info(message, snackbarFn): boolean
```

## Migration Guide

### For New Code

Simply use the new hook:

```typescript
// ✅ New code - with duplicate prevention
import { useSnackbarWithDuplicateCheck } from '@/hooks/useSnackbarWithDuplicateCheck';

const showMessage = useSnackbarWithDuplicateCheck();
showMessage.success('Success message');
```

### For Existing Code

Existing code continues to work unchanged:

```typescript
// ✅ Existing code - still works
import { useSnackbar } from '@/styled-components/hooks/useSnackbar';

const { snackbar } = useSnackbar();
snackbar({ type: 'success', message: 'Success message' });
```

To add duplicate prevention to existing code:

```typescript
// Before
const { snackbar } = useSnackbar();
snackbar({ type: 'success', message: 'Success message' });

// After
const showMessage = useSnackbarWithDuplicateCheck();
showMessage.success('Success message');
```

## Best Practices

### 1. **Use for User Actions**

Always use duplicate prevention for user-triggered actions:

- Form submissions
- Save operations
- Delete confirmations
- API calls

### 2. **Configure Appropriately**

- Use shorter time windows (1-2s) for rapid actions
- Use longer time windows (3-5s) for slower operations
- Consider message type when configuring prevention

### 3. **Handle Edge Cases**

```typescript
const handleCriticalOperation = () => {
  // For critical operations, you might want to clear tracker first
  snackbarUtils.clearTracker();
  showMessage.error('Critical error occurred');
};
```

### 4. **Testing**

```typescript
// In tests, clear tracker between test cases
afterEach(() => {
  snackbarUtils.clearTracker();
});
```

## Advanced Usage

### Custom Message Keys

```typescript
const showMessage = useSnackbarWithDuplicateCheck();

showMessage.show({
  message: 'Custom message',
  type: 'info',
  key: 'unique-key', // Custom key for this message
  duration: 10,
});
```

### Conditional Prevention

```typescript
const showConditionalMessage = (allowDuplicates = false) => {
  if (allowDuplicates) {
    // Use original snackbar for duplicates
    const { snackbar } = useSnackbar();
    snackbar({ type: 'info', message: 'Duplicate allowed' });
  } else {
    // Use duplicate prevention
    showMessage.info('Duplicate prevented');
  }
};
```

## Performance Considerations

1. **Memory Usage**: The tracker automatically cleans up expired entries
2. **Time Complexity**: O(1) for duplicate checking, O(n) for cleanup (where n is tracked messages)
3. **Storage**: Only message keys and timestamps are stored, not full message content

## Troubleshooting

### Messages Not Showing

```typescript
// Check if message is being prevented
const wasShown = showMessage.success('Test message');
console.log('Message shown:', wasShown);
```

### Clear Tracker

```typescript
// If you need to force show a message
snackbarUtils.clearTracker();
showMessage.success('This will definitely show');
```

### Debug Configuration

```typescript
// Check current configuration
console.log('Current config:', snackbarUtils.getConfig());
```

## Testing

### Unit Tests

```typescript
import { snackbarUtils } from '@/utils/snackbar.utils';

describe('Snackbar Duplicate Prevention', () => {
  beforeEach(() => {
    snackbarUtils.clearTracker();
  });

  it('should prevent duplicate messages', () => {
    const mockSnackbar = jest.fn();

    const result1 = snackbarUtils.success('Test message', mockSnackbar);
    const result2 = snackbarUtils.success('Test message', mockSnackbar);

    expect(result1).toBe(true);
    expect(result2).toBe(false);
    expect(mockSnackbar).toHaveBeenCalledTimes(1);
  });
});
```

### Integration Tests

```typescript
import { render, fireEvent, waitFor } from '@testing-library/react';

test('prevents duplicate success messages on rapid clicks', async () => {
  const { getByText } = render(<MyComponent />);
  const button = getByText('Save');

  // Click rapidly
  fireEvent.click(button);
  fireEvent.click(button);
  fireEvent.click(button);

  await waitFor(() => {
    // Should only see one success message
    expect(document.querySelectorAll('.ant-notification-notice')).toHaveLength(1);
  });
});
```

## Conclusion

The snackbar duplicate prevention system provides a robust solution for managing notification spam while maintaining backward compatibility. By implementing this system, the application provides a better user experience with cleaner, less cluttered notifications.

The system is designed to be:

- **Easy to use**: Simple hook-based API
- **Flexible**: Configurable for different use cases
- **Performant**: Efficient memory usage and cleanup
- **Compatible**: Works alongside existing code
- **Testable**: Easy to test and debug

For questions or issues, refer to the examples in `src/utils/__examples__/snackbar.duplicate.examples.tsx`.
