# Code Review Checklist

## Overview
This document provides a comprehensive checklist for code reviews in the ABMS frontend application. It ensures consistency, maintainability, and adherence to established patterns across the codebase.

---

## 1. DataTable Component Usage

### ✅ **MUST USE DataTable Component**
- **Rule**: All main module lists should use the `DataTable` component unless there's a justified reason
- **Location**: `src/components/DataTable.tsx`
- **Check**: Look for custom table implementations in list views

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Custom table implementation
<Table columns={columns} data={data} />

// ✅ CORRECT - Using DataTable component
<DataTable
  columns={columns}
  paginatedQuery={PAGINATED_QUERY}
  allQuery={ALL_QUERY}
  searchFields={searchFields}
  sortArg={sortArg}
  page={page}
  setPage={setPage}
/>
```

### 🔍 **Justification Required**
If not using DataTable, developer must provide:
- Performance reasons (large datasets)
- Specific UI requirements not supported by DataTable
- Legacy compatibility issues
- Document the decision in code comments

---

## 2. Global Options Usage

### ✅ **Available Global Options**
Current global options available via `useGlobalOptions` hook:

```typescript
const {
  locations,           // LocationModel[]
  accounts,           // AccountModel[]
  areas,              // AreaModel[]
  users,              // User[]
  employees,          // EmployeeModel[]
  departments,        // Department[]
  sites,              // SitesModel[]
  contacts,           // ContactModel[]
  dealTypes,          // DealTypeModel[]
  leaveTypes,         // LeaveType[]
  modules,            // Module[]
  warehouses,         // WarehouseModel[]
  itemCategories,     // ItemCategories[]
  uoms,               // UOMModel[]
  items,              // ItemModel[]
  itemSubcategories,  // ItemSubcategoryModel[]
} = useGlobalOptions({
  locations: true,
  accounts: true,
  // ... specify only what you need
});
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Individual queries for common data
const { data: locations } = useQuery(GET_LOCATIONS);
const { data: accounts } = useQuery(GET_ACCOUNTS);

// ✅ CORRECT - Using global options
const { locations, accounts } = useGlobalOptions({
  locations: true,
  accounts: true,
});
```

### 🔍 **Check for Duplicate Queries**
- Look for multiple components making the same GraphQL queries
- Ensure common data (locations, accounts, etc.) uses global options
- Verify queries are not duplicated across related components

---

## 3. Export Fields Implementation

### ✅ **Export Fields Best Practices**

#### Empty Data Handling
```typescript
// ✅ CORRECT - Return empty string for missing data
{
  title: 'Contact Name',
  field: 'contact.fullName',
  transform: (fullName, allData) => {
    return allData?.contact?.fullName || '';
  },
}

// ❌ WRONG - Using "No data" fallback
{
  title: 'Contact Name',
  field: 'contact.fullName',
  transform: (fullName, allData) => {
    return allData?.contact?.fullName || 'No data';
  },
}
```

#### Data Validation
```typescript
import { isValueValid } from '@/utils/helper.utils';

{
  title: 'Complex Field',
  field: 'complexData',
  transform: (fieldValue, allData) => {
    if (!isValueValid(allData?.someField)) return '';
    
    // Process valid data
    return processData(allData.someField);
  },
}
```

### ❌ **Common Violations**
- Using "No data", "No contact", "No account" in export fields
- Not validating data before processing
- Inconsistent empty data handling across fields

---

## 4. Table Empty State Display

### ✅ **Proper Empty State Implementation**

#### DataTable Component
```typescript
// ✅ CORRECT - DataTable handles empty state automatically
<DataTable
  columns={columns}
  data={data}
  // emptyState is handled internally
/>
```

#### Custom Tables
```typescript
// ✅ CORRECT - Custom empty state
<Table
  columns={columns}
  data={data}
  emptyState={<EmptyState iconW='200px' title='No data to display.' />}
/>
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Blank cells instead of "No data"
<td>{data?.field || ''}</td>

// ✅ CORRECT - Using NoData component
<td>{haveData(data?.field) ? data.field : <NoData />}</td>
```

### 🔍 **Check CSS for Empty Cells**
```css
/* ✅ CORRECT - CSS for empty table cells */
table tbody td:empty:before {
  content: 'No data';
  color: var(--table-no-data);
}
```

---

## 5. Currency Formatting

### ✅ **Use Helper Utilities**

#### Standard Currency Formatting
```typescript
import { formatCurrency, formatNumber } from '@/utils/helper.utils';

// ✅ CORRECT - Using helper utilities
const formattedAmount = formatCurrency(1234.56);
// Result: "$ 1,234.56"

const formattedNumber = formatNumber(1234.56);
// Result: "1234.56"
```

#### Custom Currency Formatting
```typescript
// ✅ CORRECT - Consistent formatting pattern
const currencyFormat = (value: number) => {
  if (typeof value !== 'number' || isNaN(value)) return '';
  
  return value
    .toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      useGrouping: true,
    })
    .replace(/^(\$)(\d)/, '$1 $2');
};
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Inconsistent currency formatting
const amount = `$${value.toFixed(2)}`;

// ❌ WRONG - Manual formatting without helpers
const formatted = value.toLocaleString();
```

---

## 6. Date Formatting

### ✅ **Use Date Utils**

#### Standard Date Formats
```typescript
import { 
  dateFormat, 
  dateTimeFormat, 
  formatDate, 
  formatDateTime,
  formatToNZTime 
} from '@/utils/date.utils';

// ✅ CORRECT - Using date utils
const formattedDate = formatDate(date, dateFormat);
const formattedDateTime = formatDateTime(date, dateTimeFormat);
const nzTime = formatToNZTime(date);
```

#### Available Date Formats
```typescript
export const dateFormat = 'DD/MM/YYYY';           // Default date format
export const dateTimeFormat = 'DD/MM/YYYY, hh:mm A';
export const calendarFormat = 'DD MMM YYYY';
export const timeFormat = 'hh:mm A';
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Hardcoded date formats
const formatted = dayjs(date).format('DD/MM/YYYY');

// ❌ WRONG - Inconsistent date formatting
const formatted = moment(date).format('MM/DD/YYYY');
```

---

## 7. Label Case Formatting

### ✅ **Use Sentence Case**

#### Helper Function
```typescript
import { toSentenceCase } from '@/utils/helper.utils';

// ✅ CORRECT - Using helper function
const label = toSentenceCase('CONTACT_NAME');
// Result: "Contact name"

const label2 = toSentenceCase('user_email_address');
// Result: "User email address"
```

#### Manual Implementation
```typescript
// ✅ CORRECT - Manual sentence case conversion
const convertToSentenceCase = (text: string) => {
  if (!text) return '';
  return text
    .split('_')
    .map((word, index) =>
      index === 0
        ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        : word.toLowerCase()
    )
    .join(' ');
};
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Inconsistent case formatting
const label = 'CONTACT_NAME';  // All caps
const label2 = 'contactName';  // Camel case
const label3 = 'Contact Name'; // Title case (should be sentence case)
```

---

## 8. Sorting Implementation

### ✅ **Backend Sorting Only**

#### Frontend Implementation
```typescript
// ✅ CORRECT - Enable backend sorting
{
  title: 'Site name',
  key: 'site.siteName',
  dataIndex: 'site.siteName',
  sorter: true,  // Backend sorting enabled
}

// ✅ CORRECT - No frontend sorting function
{
  title: 'Status',
  key: 'status',
  dataIndex: 'status',
  sorter: true,  // Backend handles sorting
}
```

#### Backend Implementation
```typescript
// ✅ CORRECT - Using BaseResolver.toSortObject()
if (sortArg) {
  const sorting = this.toSortObject(sortArg);
  dataOptions.findManyOptions.order = sorting;
}
```

### ❌ **Common Violations**
```typescript
// ❌ WRONG - Frontend sorting functions
{
  title: 'Name',
  key: 'name',
  sorter: (a, b) => a.name.localeCompare(b.name),  // Frontend sorting
}

// ❌ WRONG - Manual sorting logic
{
  title: 'Date',
  key: 'date',
  sorter: () => 0,  // Disabled sorting
}
```

### 🔍 **Sorting Field References**
- Use correct field references: `site.siteName` not `siteId`
- Use `contactType.name` not `contactTypeId`
- Use `recordOwner.fullName` not `recordOwnerId`

---

## 9. Code Review Process

### 🔍 **Pre-Review Checklist**
- [ ] All main module lists use DataTable component
- [ ] Global options are used for common data
- [ ] Export fields return empty strings for missing data
- [ ] Tables display "No data" for empty cells
- [ ] Currency formatting uses helper utilities
- [ ] Date formatting uses date utils
- [ ] Labels are in sentence case
- [ ] Sorting is handled by backend only
- [ ] No duplicate queries across components

### 📝 **Review Questions**
1. **DataTable Usage**: Why isn't DataTable being used for this list?
2. **Global Options**: Are there any queries that could use global options?
3. **Export Fields**: Do export fields handle empty data correctly?
4. **Empty States**: Are empty table cells showing "No data"?
5. **Formatting**: Are currency and date formatting consistent?
6. **Labels**: Are all labels in sentence case?
7. **Sorting**: Is sorting handled by the backend?

### 🚨 **Critical Issues**
- Frontend sorting implementations
- Hardcoded formatting instead of utilities
- "No data" messages in export fields
- Missing DataTable usage without justification
- Duplicate queries for common data

---

## 10. Quick Reference

### Import Statements
```typescript
// Common imports for code review
import { DataTable } from '@/components/DataTable';
import { useGlobalOptions } from '@/hooks/useGlobalOptions';
import { formatCurrency, formatNumber, toSentenceCase, isValueValid } from '@/utils/helper.utils';
import { dateFormat, formatDate, formatDateTime } from '@/utils/date.utils';
import { NoData } from '@/components/NoData';
```

### Utility Functions
```typescript
// Currency formatting
formatCurrency(amount)           // "$ 1,234.56"
formatNumber(amount)            // "1234.56"

// Date formatting
formatDate(date, dateFormat)     // "25/12/2024"
formatDateTime(date)            // "25/12/2024, 02:30 PM"

// Text formatting
toSentenceCase('CONTACT_NAME')  // "Contact name"
isValueValid(value)             // true/false for validation
```

---

## 11. Examples

### ✅ **Good Implementation Example**
```typescript
import { DataTable } from '@/components/DataTable';
import { useGlobalOptions } from '@/hooks/useGlobalOptions';
import { formatCurrency, toSentenceCase } from '@/utils/helper.utils';
import { dateFormat, formatDate } from '@/utils/date.utils';

const MyComponent = () => {
  const { locations, accounts } = useGlobalOptions({
    locations: true,
    accounts: true,
  });

  const columns = [
    {
      title: toSentenceCase('CONTACT_NAME'),  // Results in "Contact name"
      key: 'contact.fullName',
      dataIndex: 'contact.fullName',
      sorter: true,
      render: (value) => value || <NoData />,
    },
    {
      title: 'Amount',  // Single word - already correct
      key: 'amount',
      dataIndex: 'amount',
      sorter: true,
      render: (value) => formatCurrency(value),
    },
    {
      title: 'Created date',  // Sentence case: first letter capitalized, rest lowercase
      key: 'createdAt',
      dataIndex: 'createdAt',
      sorter: true,
      render: (value) => formatDate(value, dateFormat),
    },
  ];

  return (
    <DataTable
      columns={columns}
      paginatedQuery={PAGINATED_QUERY}
      allQuery={ALL_QUERY}
      searchFields={searchFields}
      sortArg={sortArg}
      page={page}
      setPage={setPage}
    />
  );
};
```

### ❌ **Bad Implementation Example**
```typescript
// ❌ WRONG - Multiple violations
const MyComponent = () => {
  const { data: locations } = useQuery(GET_LOCATIONS);  // Should use global options
  const { data: accounts } = useQuery(GET_ACCOUNTS);    // Should use global options

  const columns = [
    {
      title: 'CONTACT NAME',  // Should be "Contact name" (sentence case)
      key: 'contactId',       // Wrong field reference
      dataIndex: 'contactId',
      sorter: (a, b) => a.contactId.localeCompare(b.contactId),  // Frontend sorting
      render: (value) => value || '',  // Should show "No data"
    },
    {
      title: 'Amount',
      key: 'amount',
      dataIndex: 'amount',
      render: (value) => `$${value.toFixed(2)}`,  // Should use formatCurrency
    },
    {
      title: 'Created Date',  // Should be "Created date" (sentence case)
      key: 'createdAt',
      dataIndex: 'createdAt',
      render: (value) => dayjs(value).format('MM/DD/YYYY'),  // Should use date utils
    },
  ];

  return (
    <Table columns={columns} data={data} />  // Should use DataTable
  );
};
```

---

## 12. Resources

### Documentation
- [DataTable Component Guide](./docs/GENERIC_COMPONENT_REFACTORING_GUIDE.md)
- [Global Options Enhancement](./docs/GLOBAL_OPTIONS_ENHANCEMENT.md)
- [Export Fields Guide](./docs/EXPORT_FIELDS_GUIDE.md)
- [Date Format Assessment](./docs/DATE-FORMAT-ASSESSMENT.md)
- [Frontend Sorting Fixes](./docs/FRONTEND_SORTING_FIXES_CHANGELOG.md)

### Key Files
- `src/components/DataTable.tsx` - Main table component
- `src/hooks/useGlobalOptions.ts` - Global options hook
- `src/utils/helper.utils.tsx` - Helper utilities
- `src/utils/date.utils.ts` - Date formatting utilities
- `src/components/NoData.tsx` - Empty state component

---

*This checklist should be used for all code reviews to ensure consistency and maintainability across the ABMS frontend application.*
