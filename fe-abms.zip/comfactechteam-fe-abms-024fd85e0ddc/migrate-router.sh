#!/bin/bash

# Script to migrate @reach/router to react-router-dom

echo "Starting migration from @reach/router to react-router-dom..."

# Files to update
files=(
  "src/components/SetttingsSideMenu.tsx"
  "src/components/Link.tsx"
  "src/components/navbar/Logo.tsx"
  "src/components/navbar/NavLink.tsx"
  "src/components/navbar/NavRightMenu.tsx"
  "src/components/navbar/TopNav.tsx"
  "src/components/navbar/menuItem/Search.tsx"
  "src/unathorized-components/views/forgotPassword/index.tsx"
  "src/unathorized-components/views/resetPassword/expired/index.tsx"
  "src/unathorized-components/views/login/index.tsx"
  "src/unathorized-components/views/resetPassword/success/index.tsx"
  "src/constants/QuickAddList.tsx"
  "src/constants/ProfileMenuList.tsx"
)

# Replace imports
for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "Updating $file..."
    
    # Replace navigate import
    sed -i '' 's/import { navigate } from .@reach\/router./import { useNavigate } from "react-router-dom";/g' "$file"
    sed -i '' 's/import { navigate as /import { useNavigate as /g' "$file"
    
    # Replace Link import
    sed -i '' 's/import { Link } from .@reach\/router./import { Link } from "react-router-dom";/g' "$file"
    sed -i '' 's/import { Link as RouterLink } from .@reach\/router./import { Link as RouterLink } from "react-router-dom";/g' "$file"
    
    # Replace useLocation import
    sed -i '' 's/import { useLocation } from .@reach\/router./import { useLocation } from "react-router-dom";/g' "$file"
    
    # Replace useParams import
    sed -i '' 's/import { useParams } from .@reach\/router./import { useParams } from "react-router-dom";/g' "$file"
    
    echo "Updated $file"
  else
    echo "File $file not found, skipping..."
  fi
done

echo "Migration imports completed!"
echo "Note: You will need to manually update the usage patterns for navigate() calls"
