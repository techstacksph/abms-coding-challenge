You are analyzing a Jira ticket to understand its requirements, current implementation status, and what work remains.

Task 
Perform a comprehensive analysis of Jira ticket: {{ticket}}

Configuration 
Bitbucket Workspace: comfactechteam
Bitbucket Project: AYR BMS
Analysis Steps 
Extract Ticket Information

If given a URL, extract the ticket key from it (e.g., from https://ctoltd.atlassian.net/browse/PROJ-123, extract "PROJ-123")
Use mcp__mcp-atlassian__jira_get_issue to fetch the ticket details with fields: "*all"
Get complete issue data including: summary, description, status, assignee, reporter, labels, comments, priority, created, updated, epic links, fixVersions, components, subtasks, and all custom fields
Examine Ticket History

Use mcp__mcp-atlassian__jira_batch_get_changelogs to get the full change history
Identify key events:
Status transitions (Created → In Progress → Done, etc.)
Assignee changes
Priority changes
Field updates (story points, sprint changes, etc.)
Note patterns like multiple reopenings or long periods in certain statuses
Review Comments & Discussions

Analyze all comments from the issue, focusing on recent ones
Identify:
Blockers or dependencies mentioned
Implementation decisions and technical discussions
Questions or concerns raised by team members
Acceptance criteria discussions or clarifications
Testing notes or feedback
Search Related Code in Bitbucket

Use mcp__bitbucket__bb_search with:
workspaceSlug: "comfactechteam"
scope: "code"
query: ticket key and relevant feature keywords
Search for:
Direct references to the ticket key in commit messages or code comments
Feature/component names mentioned in the ticket
Related file paths if mentioned in comments
Class names, function names, or API endpoints from the description
Search Related Pull Requests

Use mcp__bitbucket__bb_search with:
workspaceSlug: "comfactechteam"
scope: "pullrequests"
query: ticket key
For each PR found, use mcp__bitbucket__bb_get_pr to get details
Analyze:
PR status (merged, open, declined)
Code changes and their scope
PR comments and review feedback
Whether the PR fully addresses the ticket
Examine Repository Commits

Use mcp__bitbucket__bb_get_commit_history for relevant repositories
Look for commits mentioning the ticket key
Review commit messages for implementation details
Identify Linked Items & Dependencies

Check for linked issues in the ticket (blocks, is blocked by, relates to, duplicates)
If this is part of an Epic, analyze the Epic's overall progress
Review subtasks if any exist and their completion status
Check for mentions of other tickets in comments
Gap Analysis

Extract acceptance criteria from:
Description (often formatted as checklists, bullet points, or "AC:" sections)
Comments clarifying requirements
Definition of Done from team conventions
Compare acceptance criteria with implementation:
Merged PRs and their scope
Code found in repositories
Resolved subtasks
Test coverage mentioned in PRs or comments
Identify what's complete vs. what's remaining
Generate Comprehensive Summary

Provide a structured report with:

📋 Ticket Overview 
Key: [ticket key]
Title: [summary]
Status: [current status]
Priority: [priority]
Assignee: [current assignee or "Unassigned"]
Reporter: [reporter]
Epic: [epic link if exists]
Sprint: [current sprint if exists]
Labels: [labels]
Components: [components]
Created: [date]
Last Updated: [date]
📝 Description Summary 
[Concise summary of what the ticket is asking for, including key requirements and acceptance criteria]

📅 Ticket History Timeline 
[Chronological key events from changelog:]

[Date]: Created by [user]
[Date]: Status changed from X → Y
[Date]: Assigned to [user]
[Date]: [other significant changes]
[Note any patterns like multiple reopenings, extended time in certain statuses]
💬 Recent Comments Analysis 
[Summary of the 5-10 most recent or relevant comments:]

[Date] - [Author]: [Key point or decision]
[Date] - [Author]: [Important discussion or blocker]
[Highlight: implementation decisions, blockers, questions needing answers, testing feedback]
💻 Related Code Implementation 
Pull Requests 
[List PRs related to this ticket:]

PR #[number]: [title] - [Status: Merged/Open/Declined]
Repository: [repo name]
Branch: [source → destination]
Files changed: [count]
Key changes: [brief summary]
Code References 
[Code found in repositories:]

Repository: [repo name]
File: [file path]:[line]
Context: [what was found]
Commits 
[Relevant commits mentioning the ticket:]

[hash]: [commit message] - [date]
🔗 Linked Issues & Dependencies 
[Any blocking, blocked by, or related tickets:]

[Link Type]: [TICKET-KEY] - [Summary] ([Status])
[Subtasks if any:]
✅ [TICKET-KEY]: [Summary] (Done)
⬜ [TICKET-KEY]: [Summary] (In Progress/To Do)
🔍 Gap Analysis 
✅ Completed Work 
[What has been done based on code, PRs, commits, and subtasks:]

[Specific feature/requirement completed]
[PR merged implementing X]
[Subtask Y completed]
🔨 Remaining Work 
[What still needs to be done based on acceptance criteria, open items, and analysis:]

[Missing feature or requirement]
[Acceptance criteria not yet met]
[Open subtask]
[Unresolved comment or question]
⚠️ Blockers & Risks 
[Any blockers, dependencies, or risks identified:]

[Blocker from linked ticket]
[Technical dependency mentioned in comments]
[Risk or concern from discussions]
🎯 Recommendations 
[Suggested next steps based on the analysis:]

[Immediate action needed]
[Follow-up task]
[Clarification required]
Summary 
[2-3 sentence executive summary of the ticket's current state and what needs to happen next]

Important Notes 
If you cannot find the ticket, verify the ticket key format and that you have access to the Jira project
For Bitbucket searches, always use workspace "comfactechteam"
If initial code search returns too many results (>50), refine with more specific keywords from the ticket description
Pay special attention to comments from the last 30 days as they contain current context
Look for acceptance criteria marked with "AC:", "Acceptance Criteria:", or formatted as checklists in the description
Check both the original description AND comments for updated or clarified requirements
If the ticket status is "Done" or "Closed" but you're asked to analyze it, focus on lessons learned and implementation details