// Cache version - will be replaced during build process
const CACHE_VERSION = 'BUILD_TIME_VERSION'; // Will be replaced during build
const CACHE_NAME = `abms-cache-${CACHE_VERSION}`;
const STATIC_CACHE_NAME = `abms-static-${CACHE_VERSION}`;

// Install event - cache core app shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      // Cache static assets with versioned name
      caches.open(STATIC_CACHE_NAME).then((cache) => {
        return cache.addAll([
          '/',
          '/index.html',
          '/favicon.svg'
        ]);
      }),
      // Skip waiting to activate immediately
      self.skipWaiting()
    ])
  );
});

// Fetch event - smart caching strategy
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Skip caching for API calls, GraphQL, non-GET requests, and unsupported schemes
  if (url.pathname.startsWith('/api/') || 
      url.pathname.includes('graphql') ||
      event.request.method !== 'GET' ||
      !['http:', 'https:'].includes(url.protocol)) {
    return;
  }

  // For hashed assets (JS, CSS files), strictly network only - no cache fallback
  if (url.pathname.includes('/assets/') && (url.pathname.includes('.js') || url.pathname.includes('.css'))) {
    event.respondWith(fetch(event.request));
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((cached) => {
        // If cached, return it BUT also update in background
        if (cached) {
          // Update cache in background (stale-while-revalidate)
          fetch(event.request)
            .then(response => {
              // Clone the response before checking its status
              const responseClone = response.clone();
              if (response.ok) {
                caches.open(CACHE_NAME).then(cache => {
                  // Additional protocol check before caching
                  if (['http:', 'https:'].includes(url.protocol)) {
                    try {
                      cache.put(event.request, responseClone);
                    } catch (error) {
                      // Silently ignore caching errors for unsupported schemes
                      console.warn('Failed to cache request:', error.message);
                    }
                  }
                });
              }
            })
            .catch(() => {
              // Ignore fetch errors in background update
            });
          return cached;
        }
        
        // If not cached, fetch and cache
        return fetch(event.request)
          .then(response => {
            // Clone the response before checking its status
            const responseClone = response.clone();
            // Only cache successful responses
            if (response.ok) {
              caches.open(CACHE_NAME).then(cache => {
                // Additional protocol check before caching
                if (['http:', 'https:'].includes(url.protocol)) {
                  try {
                    cache.put(event.request, responseClone);
                  } catch (error) {
                    // Silently ignore caching errors for unsupported schemes
                    console.warn('Failed to cache request:', error.message);
                  }
                }
              });
            }
            return response;
          })
          .catch(() => {
            // Fallback for offline
            if (event.request.destination === 'document') {
              return caches.match('/index.html');
            }
            throw new Error('Network error and no cache available');
          });
      })
  );
});

// Activate event - clean up old caches and force revalidation
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      // Take control of all clients immediately
      self.clients.claim(),
      // Clean up ALL existing caches to force revalidation
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            console.log('Deleting cache:', cacheName);
            return caches.delete(cacheName);
          })
        );
      })
    ])
  );
});