import { test, expect, Page } from '@playwright/test';
import { config } from 'dotenv';
config();

// const BASE_URL = process.env.PW_BASE_URL || 'http://localhost:3000';

// Test Data Constants
const TEST_DATA = {
  validDocument: {
    documentName: 'Test Task Document',
    documentType: 'Contract',
    description: 'This is a test document created for task testing purposes.',
    file: 'test-document.pdf',
  },
  updatedDocument: {
    documentName: 'Updated Task Document',
    documentType: 'Invoice',
    description: 'This document has been updated with new information.',
    file: 'updated-document.pdf',
  },
  invalidDocument: {
    documentName: '',
    documentType: '',
    description: '',
    file: '',
  },
};

// Selectors organized by functionality
const SELECTORS = {
  // Navigation and Layout
  navigation: {
    calendarMenu:
      '[data-testid="calendar-menu"], .ant-menu-item:has-text("Calendar")',
    tasksMenu: '[data-testid="tasks-menu"], .ant-menu-item:has-text("Tasks")',
    sideMenu: '.ant-menu, [role="menu"]',
    breadcrumb: '.ant-breadcrumb, [aria-label="Breadcrumb"]',
  },

  // List Page Elements
  listPage: {
    pageTitle:
      'h1:has-text("Tasks"), .page-title, [data-testid="page-title"], :has-text("Tasks"):visible',
    newButton:
      '[data-testid="new-button"], button:has-text("New"), .ant-btn:has-text("New")',
    searchInput:
      '[data-testid="search-input"], .ant-input[placeholder*="Search"], input[placeholder*="search" i]',
    filterButton:
      '[data-testid="filter-button"], button:has-text("Filter"), .ant-btn:has-text("Filter")',
    exportButton:
      '[data-testid="export-button"], button:has-text("Export"), .ant-btn:has-text("Export")',
    clearFiltersButton:
      '[data-testid="clear-filters"], button:has-text("Clear"), .ant-btn:has-text("Clear")',
  },

  // Table Components
  table: {
    container: '.ant-table, [data-testid="data-table"], table',
    header: '.ant-table-thead, thead',
    body: '.ant-table-tbody, tbody',
    row: '.ant-table-row, tr[data-row-key], tbody tr, .theme-provider-table-row',
    cell: '.ant-table-cell, td, .theme-provider-table-cell',
    noData: '.ant-empty, .no-data, [data-testid="no-data"]',
    loading: '.ant-spin, .loading, [data-testid="loading"]',
    sortButton:
      '.theme-provider-table-column-sorters, .ant-table-column-sorters',
    taskSubjectSort:
      '.theme-provider-table-column-sorters:has(.theme-provider-table-column-title:has-text("Task subject"))',
  },

  // Pagination
  pagination: {
    container: '.ant-pagination, [data-testid="pagination"]',
    prevButton: '.ant-pagination-prev, [aria-label="Previous page"]',
    nextButton: '.ant-pagination-next, [aria-label="Next page"]',
    pageNumber: '.ant-pagination-item, [data-testid="page-number"]',
    pageSize: '.ant-pagination-options-size-changer, [data-testid="page-size"]',
  },

  // Task View Elements
  taskView: {
    container: '.task-view, [data-testid="task-view"]',
    tabs: '.ant-tabs, [data-testid="tabs"]',
    documentsTab:
      '.ant-tabs-tab:has-text("Documents"), [data-testid="documents-tab"]',
    activitiesTab:
      '.ant-tabs-tab:has-text("Activities"), [data-testid="activities-tab"]',
    taskInfoTab:
      '.ant-tabs-tab:has-text("Task info"), [data-testid="task-info-tab"]',
  },

  // Documents Tab Elements
  documentsTab: {
    container: '.documents-tab, [data-testid="documents-tab-content"]',
    newDocumentButton:
      '[data-testid="new-document-button"], button:has-text("New Document"), .ant-btn:has-text("New")',
    documentsTable: '.ant-table, [data-testid="documents-table"], table',
    noDocumentsMessage:
      '.ant-empty, .no-documents, [data-testid="no-documents"]',
  },

  // Document Form Fields
  documentForm: {
    container: '.ant-form, form, [data-testid="document-form-spin"]',
    documentNameInput:
      '[data-testid="document-name"], input[name="documentName"], .ant-input[placeholder*="Document name"] , [id="documentName"]',
    documentTypeSelect:
      '[data-testid="document-type-select"], [data-testid="documentTypeId"], .ant-select, [id="documentTypeId"]',
    descriptionTextarea:
      '[data-testid="description"], textarea[name="description"], .ant-input[placeholder*="Description"] [id="description"]',
    fileUpload:
      '[data-testid="file-upload"], input[type="file"], .ant-upload, [name="file"]',
    relatedRecordSection: '.related-record, [data-testid="related-record"]',
  },

  // Buttons and Actions
  buttons: {
    save: '[data-testid="header-form-save-button"], [data-testid="footer-form-save-button"], button:has-text("Save"), .ant-btn-primary:has-text("Save")',
    cancel:
      '[data-testid="header-form-cancel-button"], [data-testid="footer-form-cancel-button"], button:has-text("Cancel"), .ant-btn:has-text("Cancel")',
    edit: '[data-testid="edit-button"], button:has-text("Edit"), .ant-btn:has-text("Edit")',
    delete:
      '[data-testid="delete-button"], button:has-text("Delete"), .ant-btn-danger',
    confirm:
      '[data-testid="confirm-button"], button:has-text("Confirm"), .ant-btn-primary:has-text("OK")',
  },

  // Action Menu and Dropdowns
  actionMenu: {
    trigger:
      '[data-testid="action-menu"], .ant-dropdown-trigger, button[aria-haspopup="true"]',
    dropdown: '.ant-dropdown, [data-testid="action-dropdown"]',
    editAction:
      '[data-testid="edit-action"], .ant-dropdown-menu-item:has-text("Edit")',
    deleteAction:
      '[data-testid="delete-action"], .ant-dropdown-menu-item:has-text("Delete")',
    viewAction:
      '[data-testid="view-action"], .ant-dropdown-menu-item:has-text("View")',
  },

  // Status Actions
  status: {
    statusBadge: '.ant-badge, .status-badge, [data-testid="status-badge"]',
    statusSelect: '[data-testid="status-select"], .ant-select',
    statusOption: '.ant-select-item, [data-testid="status-option"]',
    updateButton:
      '[data-testid="update-status"], button:has-text("Update Status")',
  },

  // Modals and Dialogs
  modal: {
    container: '.ant-modal, [data-testid="modal"], [role="dialog"]',
    title: '.ant-modal-title, [data-testid="modal-title"]',
    content: '.ant-modal-body, [data-testid="modal-content"]',
    footer: '.ant-modal-footer, [data-testid="modal-footer"]',
    closeButton:
      '.ant-modal-close, [data-testid="modal-close"], button[aria-label="Close"]',
  },

  // Error and Success Messages
  messages: {
    error: '.ant-message-error, .error-message, [data-testid="error-message"]',
    success:
      '.ant-message-success, .success-message, [data-testid="success-message"]',
    warning:
      '.ant-message-warning, .warning-message, [data-testid="warning-message"]',
    validation:
      '.ant-form-item-explain-error, .field-error, [data-testid="validation-error"]',
  },

  // Search and Filter
  search: {
    input: '[data-testid="search-input"], input[placeholder*="search" i]',
    button: '[data-testid="search-button"], button:has-text("Search")',
    clear: '[data-testid="clear-search"], button:has-text("Clear")',
    results: '[data-testid="search-results"], .search-results',
  },

  // Dashboard Cards
  dashboard: {
    card: '.dashboard-card, [data-testid="dashboard-card"], .ant-card',
    cardTitle: '.ant-card-head-title, [data-testid="card-title"]',
    cardValue: '.card-value, [data-testid="card-value"]',
    allCard: '[data-testid="all-card"], .dashboard-card:has-text("All")',
    overdueCard:
      '[data-testid="overdue-card"], .dashboard-card:has-text("Overdue")',
    openCard: '[data-testid="open-card"], .dashboard-card:has-text("Open")',
    completedCard:
      '[data-testid="completed-card"], .dashboard-card:has-text("Completed")',
  },

  // Filter Panel
  filterPanel: {
    container: '.filter-panel, [data-testid="filter-panel"]',
    clearAllButton:
      '[data-testid="clear-all-filters"], button:has-text("Clear All")',
    applyButton: '[data-testid="apply-filters"], button:has-text("Apply")',
    filterField: '.filter-field, [data-testid="filter-field"]',
  },
};

// Page Object Model
class TaskDocumentsPage {
  constructor(private page: Page) {}

  // Navigation Methods
  async login(
    username: string = 'eugene@ayr-dev',
    password: string = 'Ctodev@123'
  ) {
    console.log('🔐 Attempting to log in...');
    await this.page.goto('/');
    await this.page.waitForLoadState('networkidle');

    // Check if already logged in
    const isLoggedIn = await this.page.locator('body').textContent();
    if (isLoggedIn?.includes('Calendar') || isLoggedIn?.includes('Tasks')) {
      console.log('✅ Already logged in');
      return;
    }

    // Perform login if needed
    const usernameField = this.page
      .locator('[data-testid="username"], input[name="username"]')
      .first();
    const passwordField = this.page
      .locator('[data-testid="password"], input[name="password"]')
      .first();
    const loginButton = this.page
      .locator('[data-testid="login-button"], button[type="submit"]')
      .first();

    if (await usernameField.isVisible()) {
      console.log('📝 Filling login credentials...');
      await usernameField.fill(username);
      await passwordField.fill(password);

      console.log('🔘 Clicking login button...');
      await loginButton.click();

      // Wait for navigation after login
      await this.page.waitForLoadState('networkidle');
      await this.page.waitForTimeout(2000);

      // Verify login success
      const currentUrl = this.page.url();
      const bodyText = await this.page.locator('body').textContent();

      const loginSuccessful =
        !bodyText?.includes('Please enter your username and password') &&
        !currentUrl.includes('/login') &&
        (bodyText?.includes('Calendar') ||
          bodyText?.includes('Tasks') ||
          currentUrl.includes('/calendar'));

      if (loginSuccessful) {
        console.log('✅ Login successful');
      } else {
        console.log('❌ Login failed - still on login page');
        throw new Error(`Login failed with ${username}/${password}`);
      }
    }
  }

  async navigateToTasks() {
    console.log('🧭 Navigating to Tasks module...');

    // Try multiple navigation strategies
    const strategies = [
      // Direct URL navigation
      async () => {
        await this.page.goto('/calendar/tasks');
        await this.page.waitForLoadState('networkidle');
      },
      // Menu navigation
      async () => {
        const calendarMenu = this.page
          .locator(SELECTORS.navigation.calendarMenu)
          .first();
        if (await calendarMenu.isVisible()) {
          await calendarMenu.click();
          await this.page.waitForTimeout(500);
        }

        const tasksMenu = this.page
          .locator(SELECTORS.navigation.tasksMenu)
          .first();
        if (await tasksMenu.isVisible()) {
          await tasksMenu.click();
          await this.page.waitForLoadState('networkidle');
        }
      },
    ];

    for (const strategy of strategies) {
      try {
        await strategy();
        // Verify we're on the right page
        const pageTitle = this.page
          .locator(SELECTORS.listPage.pageTitle)
          .first();
        if (await pageTitle.isVisible({ timeout: 5000 })) {
          console.log('✅ Successfully navigated to Tasks page');
          return;
        }
      } catch (error) {
        console.log(`⚠️ Navigation strategy failed: ${error.message}`);
        continue;
      }
    }

    throw new Error('Failed to navigate to Tasks page');
  }

  async clearSpecificFilters() {
    console.log('🎯 Clearing specific filters (assignees and status)...');

    // Wait for 5 seconds to ensure all filter options are loaded
    console.log('⏳ Waiting 5 seconds for filter options to load...');
    await this.page.waitForTimeout(5000);

    // Clear assignees filter
    try {
      console.log('👥 Clearing assignees filter...');

      // Try multiple approaches to find the assignees filter
      let assigneesFilter = null;

      // First try the exact data-cy from the screenshot
      assigneesFilter = this.page
        .locator('[data-cy="filter-taskAssignees.assignee.id"]')
        .first();
      if (await assigneesFilter.isVisible({ timeout: 2000 })) {
        console.log('✅ Found assignees filter using exact data-cy');
      } else {
        // Try alternative selectors
        const alternativeSelectors = [
          '[data-cy="filter-taskAssignee"]',
          '[data-testid="assignees-filter"]',
          '.ant-select[placeholder*="assignee" i]',
          '.ant-select[placeholder*="Assigned to" i]',
          '.ant-select[placeholder*="Assignees" i]',
          '.theme-provider-select[data-cy*="taskAssignee"]',
          '.theme-provider-select[data-cy*="assignee"]',
        ];

        for (const selector of alternativeSelectors) {
          try {
            const filter = this.page.locator(selector).first();
            if (await filter.isVisible({ timeout: 1000 })) {
              assigneesFilter = filter;
              console.log(
                `✅ Found assignees filter using selector: ${selector}`
              );
              break;
            }
          } catch {
            continue;
          }
        }
      }

      if (!assigneesFilter) {
        console.log('❌ Could not find assignees filter with any selector');
        return;
      }

      console.log('assigneesFilter found:', assigneesFilter);
      console.log(
        'Is visible:',
        await assigneesFilter.isVisible({ timeout: 5000 })
      );
      if (await assigneesFilter.isVisible({ timeout: 5000 })) {
        console.log('👥 Found assignees filter, clearing...');

        // For select text fields, try multiple clearing approaches
        let cleared = false;

        // Method 1: Try to clear using the clear button within the filter
        try {
          const clearButton = assigneesFilter
            .locator(
              '[class*="select-clear"], .ant-select-clear, .ant-select-selection-clear'
            )
            .first();
          if (await clearButton.isVisible({ timeout: 1000 })) {
            await clearButton.click();
            console.log('✅ Assignees filter cleared using clear button');
            cleared = true;
          }
        } catch (error) {
          console.log(
            '⚠️ Clear button not found, trying alternative methods...'
          );
        }

        // Method 2: Try to clear by selecting all text and deleting
        if (!cleared) {
          try {
            await assigneesFilter.click();
            await this.page.waitForTimeout(300);
            await this.page.keyboard.press('Control+a'); // Select all text
            await this.page.keyboard.press('Delete'); // Delete selected text
            console.log('✅ Assignees filter cleared using keyboard shortcuts');
            cleared = true;
          } catch (error) {
            console.log('⚠️ Keyboard clearing failed, trying next method...');
          }
        }

        // Method 3: Try to clear by setting value to empty string
        if (!cleared) {
          try {
            await assigneesFilter.fill('');
            console.log('✅ Assignees filter cleared using fill method');
            cleared = true;
          } catch (error) {
            console.log('⚠️ Fill method failed, trying next method...');
          }
        }

        // Method 4: Try to clear by setting input value
        if (!cleared) {
          try {
            await assigneesFilter.evaluate(el => {
              if (el instanceof HTMLInputElement) {
                el.value = '';
              }
            });
            console.log('✅ Assignees filter cleared using evaluate method');
            cleared = true;
          } catch (error) {
            console.log('⚠️ Evaluate method failed...');
          }
        }

        if (!cleared) {
          console.log('⚠️ All clearing methods failed for assignees filter');
        }

        await this.page.waitForTimeout(500);
      }
    } catch (error) {
      console.log('⚠️ Could not clear assignees filter:', error.message);
    }

    // Clear status filter
    try {
      console.log('📊 Clearing status filter...');

      // Try multiple approaches to find the status filter
      let statusFilter = null;

      // First try the exact data-cy from the screenshot
      statusFilter = this.page.locator('[data-cy="filter-status"]').first();
      if (await statusFilter.isVisible({ timeout: 2000 })) {
        console.log('✅ Found status filter using exact data-cy');
      } else {
        // Try alternative selectors based on the HTML structure
        const alternativeSelectors = [
          '[data-testid="status-filter"]',
          '.ant-select[placeholder*="status" i]',
          '.ant-select[placeholder*="Status" i]',
          '.theme-provider-select[activedescendant*="rc_select"]',
          '.theme-provider-select-selection-placeholder:has-text("Status")',
          '.theme-provider-select-selection-placeholder:has-text("status")',
          '.ant-select-selection-placeholder:has-text("Status")',
          '.ant-select-selection-placeholder:has-text("status")',
        ];

        for (const selector of alternativeSelectors) {
          try {
            const filter = this.page.locator(selector).first();
            if (await filter.isVisible({ timeout: 1000 })) {
              statusFilter = filter;
              console.log(`✅ Found status filter using selector: ${selector}`);
              break;
            }
          } catch {
            continue;
          }
        }
      }

      if (!statusFilter) {
        console.log('❌ Could not find status filter with any selector');
        return;
      }

      console.log('statusFilter found:', statusFilter);
      console.log(
        'Is visible:',
        await statusFilter.isVisible({ timeout: 5000 })
      );

      if (await statusFilter.isVisible({ timeout: 3000 })) {
        console.log('📊 Found status filter, clearing...');

        // For select text fields, try multiple clearing approaches
        let cleared = false;

        // Method 1: Try to clear using the clear button within the filter
        try {
          const clearButton = statusFilter
            .locator(
              '[class*="select-clear"], .ant-select-clear, .ant-select-selection-clear'
            )
            .first();
          if (await clearButton.isVisible({ timeout: 1000 })) {
            await clearButton.click();
            console.log('✅ Status filter cleared using clear button');
            cleared = true;
          }
        } catch {
          console.log(
            '⚠️ Clear button not found, trying alternative methods...'
          );
        }

        // Method 2: Try to clear by selecting all text and deleting
        if (!cleared) {
          try {
            await statusFilter.click();
            await this.page.waitForTimeout(300);
            await this.page.keyboard.press('Control+a'); // Select all text
            await this.page.keyboard.press('Delete'); // Delete selected text
            console.log('✅ Status filter cleared using keyboard shortcuts');
            cleared = true;
          } catch {
            console.log('⚠️ Keyboard clearing failed, trying next method...');
          }
        }

        // Method 3: Try to clear by setting value to empty string
        if (!cleared) {
          try {
            await statusFilter.fill('');
            console.log('✅ Status filter cleared using fill method');
            cleared = true;
          } catch {
            console.log('⚠️ Fill method failed, trying next method...');
          }
        }

        // Method 4: Try to clear by setting input value
        if (!cleared) {
          try {
            await statusFilter.evaluate(el => {
              if (el instanceof HTMLInputElement) {
                el.value = '';
              }
            });
            console.log('✅ Status filter cleared using evaluate method');
            cleared = true;
          } catch {
            console.log('⚠️ Evaluate method failed...');
          }
        }

        if (!cleared) {
          console.log('⚠️ All clearing methods failed for status filter');
        }

        await this.page.waitForTimeout(500);
      }
    } catch (error) {
      console.log('⚠️ Could not clear status filter:', error.message);
    }

    // Wait for filters to be applied
    await this.page.waitForLoadState('networkidle');
    console.log('✅ Specific filters cleared');
  }

  async clickFirstTaskRow() {
    console.log('🔗 Clicking first task row to navigate to view page...');

    // Wait for table to load using the exact class from the HTML structure
    console.log('🔍 Waiting for table rows to load...');
    await this.page
      .locator('.theme-provider-table-row')
      .first()
      .waitFor({ state: 'visible', timeout: 15000 })
      .catch(() => {
        console.log('⚠️ Table row not visible after 15 seconds, continuing...');
      });

    // Try multiple selector strategies for task links, prioritizing the actual task subject
    const linkSelectors = [
      '[data-cy="text-link"]', // Primary selector from screenshot - this should be the task subject
      '.theme-provider-table-cell-content a[href*="/calendar/tasks/"]', // Task links within table cell content
      'td:first-child a[href*="/calendar/tasks/"]', // First column (usually subject) with task URLs
      'a[href*="/calendar/tasks/"][data-cy="text-link"]', // Task URLs with text-link data-cy
      '.theme-provider-typography[data-cy="text-link"]', // Typography with data-cy
      'a.theme-provider-typography[href*="/calendar/tasks/"]', // Typography links with task URLs
    ];

    let firstTaskLink = null;
    let workingSelector = '';

    console.log('🔍 Searching for task links with multiple selectors...');

    for (const selector of linkSelectors) {
      try {
        console.log(`  🔍 Trying selector: ${selector}`);
        const links = this.page.locator(selector);
        const count = await links.count();
        console.log(`    - Found ${count} elements`);

        if (count > 0) {
          const firstLink = links.first();
          const isVisible = await firstLink.isVisible({ timeout: 2000 });
          const linkText = await firstLink.textContent();
          const href = await firstLink.getAttribute('href');

          console.log(`    - First link text: "${linkText?.trim()}"`);
          console.log(`    - First link href: "${href}"`);
          console.log(`    - Is visible: ${isVisible}`);

          if (isVisible && href && href.includes('/calendar/tasks/')) {
            // Additional validation: make sure it's not a button or action link
            const linkText = await firstLink.textContent();
            const isButton =
              (await firstLink.getAttribute('role')) === 'button' ||
              (await firstLink.getAttribute('type')) === 'button' ||
              linkText?.toLowerCase().includes('new') ||
              linkText?.toLowerCase().includes('add') ||
              linkText?.toLowerCase().includes('create');

            if (!isButton) {
              firstTaskLink = firstLink;
              workingSelector = selector;
              console.log(`✅ Found working selector: ${selector}`);
              break;
            } else {
              console.log(`⚠️ Skipping button/action link: "${linkText}"`);
            }
          }
        }
      } catch (error) {
        console.log(`    - Error with selector: ${error.message}`);
      }
    }

    if (firstTaskLink) {
      console.log(`🎯 Using selector: ${workingSelector}`);
      const linkText = await firstTaskLink.textContent();
      const href = await firstTaskLink.getAttribute('href');
      console.log(`🔗 Clicking task link: "${linkText?.trim()}" -> ${href}`);

      // Click the task link to navigate to view page
      await firstTaskLink.click();

      // Wait for navigation to complete
      await this.page.waitForLoadState('networkidle');
      console.log('✅ Successfully navigated to task view page');
    } else {
      console.log('❌ No task links found with any selector');
      throw new Error('No task links found in table');
    }
  }

  async navigateToDocumentsTab() {
    console.log('📄 Navigating to Documents tab...');

    // Debug: Check what tabs are available on the page
    console.log('🔍 Checking all available tabs...');
    const allTabs = this.page.locator('[role="tab"]');

    const tabCount = await allTabs.count();
    console.log(`📊 Found ${tabCount} tabs with role="tab"`);

    // Log details of each tab for debugging
    for (let i = 0; i < Math.min(tabCount, 10); i++) {
      try {
        const tab = allTabs.nth(i);
        const tabText = await tab.textContent();
        const tabId = await tab.getAttribute('id');
        const tabRole = await tab.getAttribute('role');
        const tabAriaSelected = await tab.getAttribute('aria-selected');
        const tabClass = await tab.getAttribute('class');

        console.log(
          `Tab ${i}: text="${tabText?.trim()}", id="${tabId}", role="${tabRole}", aria-selected="${tabAriaSelected}", class="${tabClass}"`
        );
      } catch (error) {
        console.log(`Tab ${i}: Error getting details`);
      }
    }

    // Try multiple selector strategies
    const selectorStrategies = [
      '[role="tab"][aria-selected="true"][id*="documents" i]',
      '[role="tab"][id*="documents" i]',
      '.them-provider-tabs-tab-btn[id*="documents" i]',
      '[role="tab"]:has-text("Documents")',
      '[id*="documents" i]',
      'div:has-text("Documents")',
    ];

    let documentsTab = null;
    let workingSelector = '';

    for (const selector of selectorStrategies) {
      try {
        console.log(`🔍 Trying selector: ${selector}`);
        const tab = this.page.locator(selector).first();
        const count = await tab.count();
        console.log(`  - Found ${count} elements`);

        if (count > 0) {
          const isVisible = await tab.isVisible({ timeout: 2000 });
          console.log(`  - Is visible: ${isVisible}`);

          if (isVisible) {
            documentsTab = tab;
            workingSelector = selector;
            console.log(`✅ Found working selector: ${selector}`);
            break;
          }
        }
      } catch (error) {
        console.log(`  - Error with selector: ${error.message}`);
      }
    }

    if (documentsTab) {
      console.log(`🎯 Using selector: ${workingSelector}`);
      await documentsTab.click();
      await this.page.waitForLoadState('networkidle');
      console.log('✅ Successfully navigated to Documents tab');
    } else {
      console.log('❌ Documents tab not found with any selector');
      throw new Error('Documents tab not visible');
    }
  }

  async clickNewDocumentButton() {
    console.log('➕ Clicking New Document button...');

    // Use the exact data-cy attribute from the screenshot for reliable button finding
    const newDocumentButton = this.page
      .locator('[data-cy="list-button-new"]')
      .first();

    if (await newDocumentButton.isVisible({ timeout: 5000 })) {
      const buttonText = await newDocumentButton.textContent();
      console.log(
        `✅ Found New Document button with text: "${buttonText?.trim()}"`
      );

      await newDocumentButton.click();
      await this.page.waitForLoadState('networkidle');
      console.log('✅ New Document button clicked successfully');
    } else {
      console.log('❌ New Document button not found');
      throw new Error('New Document button not visible');
    }
  }

  async fillDocumentForm(data: typeof TEST_DATA.validDocument) {
    console.log('📝 Filling document form...');

    // Wait for form to be visible
    await this.page
      .locator(SELECTORS.documentForm.container)
      .first()
      .waitFor({ state: 'visible', timeout: 10000 });

    // Wait for network requests to complete before filling out fields
    console.log('🌐 Waiting for network requests to complete...');
    await this.page.waitForLoadState('networkidle', { timeout: 15000 });

    // Wait 10 seconds before filling out fields to ensure form is fully loaded
    // console.log('⏳ Waiting 10 seconds for form to fully load before filling fields...');
    // await this.page.waitForTimeout(10000);

    // Fill Document Name
    if (data.documentName) {
      console.log(`📝 Filling document name: ${data.documentName}`);
      const documentNameField = this.page
        .locator(SELECTORS.documentForm.documentNameInput)
        .first();

      if (await documentNameField.isVisible({ timeout: 5000 })) {
        await documentNameField.clear();
        await documentNameField.fill(data.documentName);
        console.log('✅ Filled document name field');
      } else {
        console.log('❌ Document name field not visible');
      }
    }

    // Fill Document Type using dropdown selection method from reference
    if (data.documentType) {
      console.log(`🔽 Selecting document type: ${data.documentType}`);
      await this.selectFromDropdown(
        SELECTORS.documentForm.documentTypeSelect,
        data.documentType,
        'Document Type'
      );
    }

    // Fill Description
    if (data.description) {
      console.log(`📝 Filling description: ${data.description}`);
      const descriptionField = this.page
        .locator(SELECTORS.documentForm.descriptionTextarea)
        .first();

      if (await descriptionField.isVisible({ timeout: 5000 })) {
        await descriptionField.clear();
        await descriptionField.fill(data.description);
        console.log('✅ Filled description field');
      } else {
        console.log('❌ Description field not visible');
      }
    }

    // Handle File Upload using Playwright's fill method
    if (data.file) {
      console.log(`📁 Uploading file: ${data.file}`);

      // Look for file upload field
      const fileUploadField = this.page
        .locator(SELECTORS.documentForm.fileUpload)
        .first();

      if (await fileUploadField.isVisible({ timeout: 5000 })) {
        // Use Playwright's fill method to set the file path
        // await fileUploadField.fill(data.file);
        await fileUploadField.setInputFiles({
          name: 'file.txt',
          mimeType: 'text/plain',
          buffer: Buffer.from('this is test'),
        });
        console.log(`✅ File uploaded: ${data.file}`);
      } else {
        console.log('⚠️ File upload field not found, but continuing...');
      }
    }

    console.log('✅ Document form filled successfully');
  }

  // Add dropdown selection method from reference file
  async selectFromDropdown(
    fieldSelector: string,
    optionText: string,
    fieldName: string = 'field'
  ) {
    console.log(`🔽 Selecting "${optionText}" from ${fieldName} dropdown...`);

    const dropdown = this.page.locator(fieldSelector).first();

    // Wait for dropdown to be visible
    await dropdown.waitFor({ state: 'visible', timeout: 10000 });

    // Wait for any pending network requests to complete
    await this.page.waitForLoadState('networkidle', { timeout: 15000 });

    // Click to open dropdown
    await dropdown.click();

    console.log(`⏳ Waiting for ${fieldName} options to load...`);

    // Wait for options to appear
    await this.page.waitForSelector('[role="option"]', { timeout: 10000 });

    // Try to find the exact option first
    const exactOption = this.page
      .locator(`[role="option"]:has-text("${optionText}")`)
      .first();

    if (await exactOption.isVisible({ timeout: 2000 })) {
      await exactOption.click();
      console.log(
        `✅ Selected exact option: "${optionText}" from ${fieldName}`
      );
    } else {
      // Fallback to first available option
      const firstOption = this.page.locator('[role="option"]').first();
      if (await firstOption.isVisible()) {
        const firstOptionText = await firstOption.textContent();
        await firstOption.click();
        console.log(
          `✅ Selected first available option: "${firstOptionText?.trim()}" from ${fieldName}`
        );
      } else {
        console.log(`⚠️ No options found for ${fieldName}`);
      }
    }

    await this.page.waitForTimeout(500);
  }

  async saveDocumentForm() {
    console.log('💾 Saving document form...');
    const saveButton = this.page.locator(SELECTORS.buttons.save).first();

    if (await saveButton.isVisible({ timeout: 5000 })) {
      await saveButton.click();
      await this.page.waitForLoadState('networkidle');
      console.log('✅ Document form saved successfully');
    } else {
      console.log('❌ Save button not found');
      throw new Error('Save button not visible');
    }
  }

  // Verification Methods
  async verifyPageTitle(expectedTitle: string) {
    const title = this.page.locator(SELECTORS.listPage.pageTitle).first();
    await expect(title).toContainText(expectedTitle);
  }

  async verifySuccessMessage() {
    const successMessage = this.page
      .locator(SELECTORS.messages.success)
      .first();
    await expect(successMessage).toBeVisible({ timeout: 10000 });
  }

  async verifyDocumentViewPage() {
    console.log('🔍 Verifying redirection to document view page...');

    // Wait for page load after document creation
    await this.page.waitForLoadState('networkidle');

    // Check if we're on a document view page (URL should contain document ID)
    const currentUrl = this.page.url();
    if (currentUrl.includes('/documents/') || currentUrl.includes('/view/')) {
      console.log('✅ Successfully redirected to document view page');
      console.log(`📍 Current URL: ${currentUrl}`);
    } else {
      throw new Error('Not redirected to document view page');
    }

    // Verify document view content is visible
    const documentViewContent = this.page
      .locator('[data-testid="document-view"], .document-view, [role="main"]')
      .first();
    if (await documentViewContent.isVisible({ timeout: 5000 })) {
      console.log('✅ Document view content is visible');
    } else {
      console.log(
        '⚠️ Document view content not found, but URL indicates we are on view page'
      );
    }
  }

  async verifyTableHasData() {
    const tableRows = this.page.locator(SELECTORS.table.row);
    await expect(tableRows.first())
      .toBeVisible({ timeout: 1000 })
      .catch(() => {
        console.log(
          '⚠️ Table row not visible after 1 second, continuing with test...'
        );
      });
  }

  async verifyDocumentsTabContent() {
    const documentsTabContent = this.page
      .locator(SELECTORS.documentsTab.container)
      .first();
    await expect(documentsTabContent).toBeVisible({ timeout: 5000 });
  }

  async verifyNewDocumentButton() {
    const newDocumentButton = this.page
      .locator(SELECTORS.documentsTab.newDocumentButton)
      .first();
    await expect(newDocumentButton).toBeVisible({ timeout: 5000 });
  }

  async verifyDocumentFormFields() {
    // Verify document name field
    const documentNameField = this.page
      .locator(SELECTORS.documentForm.documentNameInput)
      .first();
    await expect(documentNameField).toBeVisible({ timeout: 5000 });

    // Verify document type field
    const documentTypeField = this.page
      .locator(SELECTORS.documentForm.documentTypeSelect)
      .first();
    await expect(documentTypeField).toBeVisible({ timeout: 5000 });

    // Verify description field
    const descriptionField = this.page
      .locator(SELECTORS.documentForm.descriptionTextarea)
      .first();
    await expect(descriptionField).toBeVisible({ timeout: 5000 });

    console.log('✅ All document form fields are visible');
  }

  async sortByTaskSubject() {
    console.log('🔄 Sorting table by Task subject...');
    const sortButton = this.page
      .locator(SELECTORS.table.taskSubjectSort)
      .first();

    // Wait for the sort button to be visible
    await sortButton.waitFor({ state: 'visible', timeout: 10000 });

    // Click the sort button to sort the table
    await sortButton.click();
    await sortButton.click();

    // Wait for the table to update after sorting
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(1000);

    console.log('✅ Table sorted by Task subject');
  }

  async waitForTimeout(ms: number) {
    await this.page.waitForTimeout(ms);
  }
}

// Test Suite - Using serial execution to stop on first failure
test.describe.serial('Task Documents Tab E2E Tests', () => {
  let taskDocumentsPage: TaskDocumentsPage;

  test.beforeEach(async ({ page }) => {
    taskDocumentsPage = new TaskDocumentsPage(page);
    // Authentication state is loaded from global setup
    // Verify we're logged in by checking for authenticated content
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed - still on login page');
    }
  });

  test.describe.serial('Basic Setup and Navigation', () => {
    test('should navigate to tasks module', async () => {
      try {
        await taskDocumentsPage.navigateToTasks();
        await taskDocumentsPage.verifyPageTitle('Tasks');
        console.log('✅ Navigation to tasks module completed successfully');
      } catch (error) {
        console.error('❌ Navigation to tasks module failed:', error.message);
        throw error; // This will stop subsequent tests
      }
    });
  });

  test.describe.serial('Task Documents Tab Testing', () => {
    test('should complete the basic Task Documents Tab workflow', async () => {
      try {
        // Step 1: Go to /Task
        console.log('📍 Step 1: Going to /Task...');
        await taskDocumentsPage.navigateToTasks();

        // Step 2: Clear filters
        console.log('🧹 Step 2: Clearing filters...');
        await taskDocumentsPage.clearSpecificFilters();

        // Step 3: Click the first link (wait for the page to load)
        console.log(
          '🔗 Step 3: Clicking first task link and waiting for page load...'
        );
        await taskDocumentsPage.clickFirstTaskRow();

        // Wait 15 seconds for the page to fully load before navigating to documents tab
        // console.log('⏳ Waiting 15 seconds for page to fully load...');
        // await taskDocumentsPage.page.waitForTimeout(15000);

        // Step 4: Navigate to documents tab
        console.log('📄 Step 4: Navigating to documents tab...');
        await taskDocumentsPage.navigateToDocumentsTab();

        // Step 5: Create a new document by clicking the + Documents button
        console.log('➕ Step 5: Creating a new document...');
        await taskDocumentsPage.clickNewDocumentButton();
        await taskDocumentsPage.fillDocumentForm(TEST_DATA.validDocument);
        await taskDocumentsPage.waitForTimeout(20000);
        await taskDocumentsPage.saveDocumentForm();

        // Verify successful creation and redirection to document view
        console.log('🔍 Verifying document creation and redirection...');
        await taskDocumentsPage.verifySuccessMessage();
        await taskDocumentsPage.verifyDocumentViewPage();

        console.log(
          '✅ Task Documents Tab workflow completed successfully - Document created and redirected to view'
        );
      } catch (error) {
        console.error('❌ Task Documents Tab workflow failed:', error.message);
        throw error; // This will stop subsequent tests
      }
    });
  });
});

// Export for use in other test files
export { TaskDocumentsPage, TEST_DATA, SELECTORS };
