# E2E Testing with Shared Authentication

This project uses Playwright with a global authentication setup to avoid repeated login operations across test files.

## How It Works

### Global Setup
- `global-setup.ts` runs once before all tests
- Performs login and saves authentication state to `auth-state.json`
- All test projects automatically load this authentication state

### Authentication Flow
1. Global setup logs in with credentials: `eugene@ayr-dev` / `Ctodev@123`
2. Authentication state is saved to `e2e/auth-state.json`
3. All tests start with this authenticated state loaded
4. Tests verify authentication before proceeding

## Usage in Test Files

### Option 1: Using the Custom Fixture (Recommended)

```typescript
import { test, expect } from './fixtures/auth';

test.describe('My Feature Tests', () => {
  test('should do something with authenticated user', async ({ authenticatedPage }) => {
    // authenticatedPage is already logged in and verified
    await authenticatedPage.goto('/my-feature');
    // ... rest of your test
  });
});
```

### Option 2: Manual Verification in beforeEach

```typescript
import { test, expect } from '@playwright/test';

test.describe('My Feature Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Authentication state is automatically loaded
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    // Verify we're logged in
    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed - still on login page');
    }
  });

  test('should do something', async ({ page }) => {
    // page is already authenticated
    await page.goto('/my-feature');
    // ... rest of your test
  });
});
```

## Benefits

- **Faster Tests**: Login happens only once globally, not before each test
- **More Reliable**: Reduces authentication-related flakiness
- **Easier Maintenance**: Single place to update login logic
- **Consistent State**: All tests start from the same authenticated state

## Files Structure

```
e2e/
├── global-setup.ts          # Global authentication setup
├── fixtures/
│   └── auth.ts              # Custom fixture for authenticated tests
├── auth-state.json          # Saved authentication state (auto-generated)
└── *.spec.ts               # Your test files
```

## Configuration

The authentication setup is configured in `playwright.config.ts`:

```typescript
export default defineConfig({
  globalSetup: './e2e/global-setup.ts',
  projects: [
    {
      name: 'chromium',
      use: {
        storageState: 'e2e/auth-state.json', // Load saved auth state
      },
    },
  ],
});
```

## Troubleshooting

### Authentication Fails
- Check if credentials in `global-setup.ts` are correct
- Verify the login selectors match your application
- Delete `auth-state.json` to force re-authentication

### Tests Still Show Login Page
- Ensure `storageState` is configured in `playwright.config.ts`
- Check that global setup completed successfully
- Verify the authentication verification logic in your tests

### Running Tests

```bash
# Run all tests (global setup runs automatically)
npx playwright test

# Run specific test file
npx playwright test hr-compliance-performance-review.spec.ts

# Run with UI mode
npx playwright test --ui
```