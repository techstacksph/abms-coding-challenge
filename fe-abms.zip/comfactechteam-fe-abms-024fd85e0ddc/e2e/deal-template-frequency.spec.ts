import { test, expect, Page } from '@playwright/test';
import { config } from 'dotenv';
config();

const BASE_URL = process.env.PW_BASE_URL || 'http://localhost:3000';

// Test Data Constants
const TEST_DATA = {
  dealTemplate: {
    dealTemplate: 'Test Deal Template',
    description: 'Test Description',
    serviceType: 'Pest Control',
    area: 'Test Area',
    frequency: 'WEEKLY',
  },
};

// Selectors organized by functionality
const SELECTORS = {
  // Navigation and Layout
  navigation: {
    settingsMenu: 'button:has(span.material-symbols-outlined:has-text("settings"))',
    dealTemplatesLink: 'a[href="/settings/deal-templates"]',
    sideMenu: '.ant-menu, [role="menu"]',
    breadcrumb: '.ant-breadcrumb, [aria-label="Breadcrumb"]',
  },

  newPage: {
    pageTitle:
      '[data-cy="text-text"]:has-text("New deal template")',
  },

  viewPage: {
    fieldValidation: {
      serviceType: '[data-cy="text-text"]:has-text("Service type")',
    },
    button: {
      edit: '[data-testid="view-edit-button"]',
    }
  },

  // List Page Elements
  listPage: {
    pageTitle:
      '[data-cy="text-text"]:has-text("Deal templates")',
    newButton:
      '[data-cy="text-link"]:has-text("Deal template")',
    searchInput:
      '[data-testid="search-input"], .ant-input[placeholder*="Search"], input[placeholder*="search" i]',
    filterButton:
      '[data-testid="filter-button"], button:has-text("Filter"), .ant-btn:has-text("Filter")',
    exportButton:
      '[data-testid="export-button"], button:has-text("Export"), .ant-btn:has-text("Export")',
  },

  // Table Components
  table: {
    container: '.ant-table, [data-testid="data-table"], table',
    header: '.ant-table-thead, thead',
    body: '.ant-table-tbody, tbody',
    row: '.ant-table-row, tr[data-row-key], tbody tr, .theme-provider-table-row',
    cell: '.ant-table-cell, td, .theme-provider-table-cell',
    noData: '.ant-empty, .no-data, [data-testid="no-data"]',
    loading: '.ant-spin, .loading, [data-testid="loading"]',
    sortButton:
      '.theme-provider-table-column-sorters, .ant-table-column-sorters',
    performanceReviewNoSort:
      '.theme-provider-table-column-sorters:has(.theme-provider-table-column-title:has-text("Performance review no."))',
  },

  // Pagination
  pagination: {
    container: '.ant-pagination, [data-testid="pagination"]',
    prevButton: '.ant-pagination-prev, [aria-label="Previous page"]',
    nextButton: '.ant-pagination-next, [aria-label="Next page"]',
    pageNumber: '.ant-pagination-item, [data-testid="page-number"]',
    pageSize: '.ant-pagination-options-size-changer, [data-testid="page-size"]',
  },

  // Form Fields
  form: {

    container: '.ant-form, form, [data-testid="performance-review-form"]',
    serviceTypeSelect: '[data-testid="service-type-select"], [data-testid="serviceTypeId"]',
    dealTemplateInput: '[data-testid="dealTemplate"]',
    descriptionInput: '[data-testid="description"]',
    areaInput: '[data-testid="area"]',
    frequencySelect: '[data-testid="frequency"]',
  },

  // Buttons and Actions
  buttons: {
    save: '[data-testid="header-form-save-button"], [data-testid="footer-form-save-button"], button:has-text("Save"), .ant-btn-primary:has-text("Save")',
    cancel:
      '[data-testid="header-form-cancel-button"], [data-testid="footer-form-cancel-button"], button:has-text("Cancel"), .ant-btn:has-text("Cancel")',
    edit: '[data-testid="edit-button"], button:has-text("Edit"), .ant-btn:has-text("Edit")',
    delete:
      '[data-testid="delete-button"], button:has-text("Delete"), .ant-btn-danger',
    confirm:
      '[data-testid="confirm-button"], button:has-text("Confirm"), .ant-btn-primary:has-text("OK")',
    addDetails: 'button:has-text("Details")',
  },

  // Action Menu and Dropdowns
  actionMenu: {
    trigger:
      '[data-testid="action-menu"], .ant-dropdown-trigger, button[aria-haspopup="true"]',
    dropdown: '.ant-dropdown, [data-testid="action-dropdown"]',
    editAction:
      '[data-testid="edit-action"], .ant-dropdown-menu-item:has-text("Edit")',
    deleteAction:
      '[data-testid="delete-action"], .ant-dropdown-menu-item:has-text("Delete")',
    viewAction:
      '[data-testid="view-action"], .ant-dropdown-menu-item:has-text("View")',
  },

  // Status Actions
  status: {
    statusBadge: '.ant-badge, .status-badge, [data-testid="status-badge"]',
    statusSelect: '[data-testid="status-select"], .ant-select',
    statusOption: '.ant-select-item, [data-testid="status-option"]',
    updateButton:
      '[data-testid="update-status"], button:has-text("Update Status")',
  },

  // Modals and Dialogs
  modal: {
    container: '.ant-modal, [data-testid="modal"], [role="dialog"]',
    title: '.ant-modal-title, [data-testid="modal-title"]',
    content: '.ant-modal-body, [data-testid="modal-content"]',
    footer: '.ant-modal-footer, [data-testid="modal-footer"]',
    closeButton:
      '.ant-modal-close, [data-testid="modal-close"], button[aria-label="Close"]',
  },

  // Error and Success Messages
  messages: {
    error: '.ant-message-error, .error-message, [data-testid="error-message"]',
    success:
      '.ant-message-success, .success-message, [data-testid="success-message"]',
    warning:
      '.ant-message-warning, .warning-message, [data-testid="warning-message"]',
    validation:
      '.ant-form-item-explain-error, .field-error, [data-testid="validation-error"]',
  },

  // Search and Filter
  search: {
    input: '[data-testid="search-input"], input[placeholder*="search" i]',
    button: '[data-testid="search-button"], button:has-text("Search")',
    clear: '[data-testid="clear-search"], button:has-text("Clear")',
    results: '[data-testid="search-results"], .search-results',
  },

  // Dashboard Cards
  dashboard: {
    card: '.dashboard-card, [data-testid="dashboard-card"], .ant-card',
    cardTitle: '.ant-card-head-title, [data-testid="card-title"]',
    cardValue: '.card-value, [data-testid="card-value"]',
    allCard: '[data-testid="all-card"], .dashboard-card:has-text("All")',
    pendingCard:
      '[data-testid="pending-card"], .dashboard-card:has-text("Pending")',
    completedCard:
      '[data-testid="completed-card"], .dashboard-card:has-text("Completed")',
  },
};

// Page Object Model
class DealTemplatePage {
  constructor(private page: Page) {}

  // Navigation Methods
  async login(
    username: string = 'dev@comfactechoptions.com',
    password: string = '8F7Mb83sGa'
  ) {
    console.log('🔐 Attempting to log in...');
    await this.page.goto('/');
    await this.page.waitForLoadState('networkidle');

    // Check if already logged in
    const isLoggedIn = await this.page.locator('body').textContent();
    if (
      isLoggedIn?.includes('Calendar') ||
      isLoggedIn?.includes('Deal templates')
    ) {
      console.log('✅ Already logged in');
      return;
    }

    // Perform login if needed
    const usernameField = this.page
      .locator('[data-testid="username"], input[name="username"]')
      .first();
    const passwordField = this.page
      .locator('[data-testid="password"], input[name="password"]')
      .first();
    const loginButton = this.page
      .locator('[data-testid="login-button"], button[type="submit"]')
      .first();

    if (await usernameField.isVisible()) {
      console.log('📝 Filling login credentials...');
      await usernameField.fill(username);
      await passwordField.fill(password);

      console.log('🔘 Clicking login button...');
      await loginButton.click();

      // Wait for navigation after login
      await this.page.waitForLoadState('networkidle');
      await this.page.waitForTimeout(2000);

      // Verify login success by checking if we're no longer on login page
      const currentUrl = this.page.url();
      const bodyText = await this.page.locator('body').textContent();

      const loginSuccessful =
        !bodyText?.includes('Please enter your username and password') &&
        !currentUrl.includes('/login') &&
        (bodyText?.includes('Calendar') ||
          bodyText?.includes('Deal templates') ||
          currentUrl.includes('/calendar'));

      if (loginSuccessful) {
        console.log('✅ Login successful');
      } else {
        console.log('❌ Login failed - still on login page');
        throw new Error(`Login failed with ${username}/${password}`);
      }
    }
  }

  async navigateToDealTemplate() {
    console.log('🧭 Navigating to Deal Template module...');

    // Try multiple navigation strategies
    const strategies = [
      // Direct URL navigation
      async () => {
        await this.page.goto('/settings/deal-templates');
        await this.page.waitForLoadState('networkidle');
      },
      // Menu navigation
      async () => {
        const settingsMenu = this.page
          .locator(SELECTORS.navigation.settingsMenu)
          .first();
        if (await settingsMenu.isVisible()) {
          await settingsMenu.click();
          await this.page.waitForTimeout(500);
        }

        const dealTemplatesLink = this.page
          .locator(SELECTORS.navigation.dealTemplatesLink)
          .first();
        if (await dealTemplatesLink.isVisible()) {
          await dealTemplatesLink.click();
          await this.page.waitForLoadState('networkidle');
        }
      },
    ];

    for (const strategy of strategies) {
      try {
        await strategy();
        // Verify we're on the right page
        const pageTitle = this.page
          .locator(SELECTORS.listPage.pageTitle)
          .first();
        if (await pageTitle.isVisible({ timeout: 5000 })) {
          console.log('✅ Successfully navigated to Deal Templates page');
          return;
        }
      } catch (error) {
        console.log(`⚠️ Navigation strategy failed: ${error.message}`);
        continue;
      }
    }

    throw new Error('Failed to navigate to Deal Templates page');
  }
  

  async clickNewButton() {
    console.log('➕ Clicking New button...');

    const selectors = [
      'a[href*="/new"]',
      SELECTORS.listPage.newButton,
      'button:has-text("New")',
      '.ant-btn:has-text("New")',
    ];

    for (const selector of selectors) {
      try {
        const element = this.page.locator(selector).first();
        if (await element.isVisible({ timeout: 2000 })) {
          console.log(`✅ Found New button with selector: ${selector}`);

          // Check if it's a link or button
          const tagName = await element.evaluate(el =>
            el.tagName.toLowerCase()
          );
          const href = await element.getAttribute('href');

          if (tagName === 'a' && href) {
            console.log(`🔗 Navigating to: ${href}`);
            await element.click();
          } else {
            await element.click();
          }

          await this.page.waitForLoadState('networkidle');
          console.log('✅ New button clicked successfully');
          return;
        }
      } catch (error) {
        console.log(`⚠️ Selector ${selector} failed: ${error.message}`);
        continue;
      }
    }

    throw new Error('Could not find or click New button');
  }

  // Form Interaction Methods
  async selectFromDropdown(
    fieldSelector: string,
    optionText: string,
    fieldName: string = 'field'
  ) {
    console.log(`🔽 Selecting "${optionText}" from ${fieldName} dropdown...`);

    const dropdown = this.page.locator(fieldSelector).first();

    // Wait for dropdown to be visible
    await dropdown.waitFor({ state: 'visible', timeout: 10000 });

    // Wait for any pending network requests to complete
    await this.page.waitForLoadState('networkidle', { timeout: 15000 });

    // Click to open dropdown
    await dropdown.click();

    console.log(`⏳ Waiting for ${fieldName} options to load...`);

    // Wait for options to appear
    await this.page.waitForSelector('[role="option"]', { timeout: 10000 });

    // Click the first available option
    const firstOption = this.page.locator('[role="option"]').first();
    await firstOption.click();

    console.log(`✅ Selected first available option from ${fieldName}`);
    await this.page.waitForTimeout(500);
  }

  async fillDealTemplateForm(
    data: typeof TEST_DATA.dealTemplate
  ) {
    console.log('📝 Filling deal template form...');

    // Wait for form to be visible
    await this.page
      .locator(SELECTORS.form.container)
      .first()
      .waitFor({ state: 'visible', timeout: 10000 });

    if (data.dealTemplate) {
        await this.page.locator(SELECTORS.form.dealTemplateInput).fill(data.dealTemplate);
    }

    if (data.description) {
        await this.page.locator(SELECTORS.form.descriptionInput).fill(data.description);
    }

    if (data.serviceType) {
      await this.selectFromDropdown(
        SELECTORS.form.serviceTypeSelect,
        data.serviceType,
        'Service Type'
      );
    }

    await this.page.locator(SELECTORS.buttons.addDetails).click();

    if (data.area) {
        await this.page.locator(SELECTORS.form.areaInput).fill(data.area);
    }

    if (data.frequency) {
        await this.selectFromDropdown(
            SELECTORS.form.frequencySelect,
            data.frequency,
            'Frequency'
        );
    }

    console.log('✅ Form filled successfully');
  }

  async saveForm() {
    console.log('💾 Saving form...');
    const saveButton = this.page.locator(SELECTORS.buttons.save).first();

    // Check if save button is already visible
    const isVisible = await saveButton
      .isVisible({ timeout: 2000 })
      .catch(() => false);

    if (isVisible) {
      console.log('✅ Save button is visible, clicking...');
      await saveButton.click();
    } else {
      console.log(
        '⚠️ Save button not visible, trying alternative selectors...'
      );

      // Try alternative save button selectors
      const alternativeSelectors = [
        '[data-testid="footer-form-save-button"]',
        '[data-testid="header-form-save-button"]',
        'button:has-text("Save")',
        '.ant-btn-primary:has-text("Save")',
        'button[type="submit"]',
      ];

      let clicked = false;
      for (const selector of alternativeSelectors) {
        try {
          const altButton = this.page.locator(selector).first();
          if (await altButton.isVisible({ timeout: 1000 })) {
            console.log(`✅ Found save button with selector: ${selector}`);
            await altButton.click();
            clicked = true;
            break;
          }
        } catch (error) {
          console.log(`⚠️ Selector ${selector} failed: ${error.message}`);
          continue;
        }
      }

      if (!clicked) {
        console.log('⚠️ Could not find any save button, but continuing...');
      }
    }

    await this.page.waitForLoadState('networkidle');
    console.log('✅ Form save process completed');
  }

  // Verification Methods
  async verifyPageTitle(expectedTitle: string) {
    const title = this.page.locator(SELECTORS.listPage.pageTitle).first();
    await expect(title).toContainText(expectedTitle);
  }

  async verifySuccessMessage() {
    const successMessage = this.page
      .locator(SELECTORS.messages.success)
      .first();
    await expect(successMessage).toBeVisible({ timeout: 10000 });
  }

  async verifyFrequencyInViewPage(frequency: string) {
    const frequencyElement = this.page.locator(`:text("${frequency}")`);
    await expect(frequencyElement.first()).toBeVisible();
  }
}

// Test Suite
test.describe('Deal Template E2E Tests', () => {
  let dealTemplatePage: DealTemplatePage;

  test.beforeEach(async ({ page }) => {
    dealTemplatePage = new DealTemplatePage(page);
    // Authentication state is loaded from global setup
    // Verify we're logged in by checking for authenticated content
    await page.goto('/');
    //await page.waitForLoadState('networkidle');

    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed - still on login page');
    }
  });

  test('should create a new deal template with frequency', async () => {
    await dealTemplatePage.navigateToDealTemplate();
    await dealTemplatePage.clickNewButton();
    await dealTemplatePage.fillDealTemplateForm(TEST_DATA.dealTemplate);
    await dealTemplatePage.saveForm();
    await dealTemplatePage.verifySuccessMessage();
    await dealTemplatePage.verifyFrequencyInViewPage(TEST_DATA.dealTemplate.frequency);
  });
});
