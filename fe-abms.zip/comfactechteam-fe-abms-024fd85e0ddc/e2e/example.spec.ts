import { test, expect } from '@playwright/test';

test.describe('ABMS Application', () => {
  test('should load the homepage', async ({ page }) => {
    await page.goto('/');

    // Wait for the page to load
    await page.waitForLoadState('networkidle');

    // Check if the page title is set
    await expect(page).toHaveTitle(/ABMS|Vite/);

    // Check if the main content is visible
    const body = page.locator('body');
    await expect(body).toBeVisible();
  });

  test('should handle navigation', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Look for common navigation elements
    const navigation = page.locator(
      'nav, [role="navigation"], .ant-menu, .ant-layout-header'
    );

    // If navigation exists, test it
    if ((await navigation.count()) > 0) {
      await expect(navigation.first()).toBeVisible();
    }
  });

  test('should be responsive', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Test mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    await page.waitForTimeout(500);

    const body = page.locator('body');
    await expect(body).toBeVisible();

    // Test desktop viewport
    await page.setViewportSize({ width: 1920, height: 1080 });
    await page.waitForTimeout(500);

    await expect(body).toBeVisible();
  });

  test('should handle errors gracefully', async ({ page }) => {
    // Test 404 page or error handling
    await page.goto('/non-existent-page');

    // Should not crash and should show some content
    const body = page.locator('body');
    await expect(body).toBeVisible();
  });
});
