import { chromium } from '@playwright/test';
import { config } from 'dotenv';
config();

const BASE_URL = process.env.PW_BASE_URL || 'http://localhost:3005';
/**
 * Global setup for Playwright tests
 * Performs authentication once and saves the state for all tests
 */
async function globalSetup() {
  console.log('🔐 Setting up global authentication...');

  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    // Navigate to login page
    console.log('🌐 Navigating to login page...');
    // await page.goto('http://localhost:3000');
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    // Check if already logged in
    const bodyText = await page.locator('body').textContent();
    if (
      bodyText?.includes('HR & Compliance') ||
      bodyText?.includes('Performance review')
    ) {
      console.log('✅ Already logged in, saving current state...');
      await context.storageState({ path: 'e2e/auth-state.json' });
      return;
    }

    // Perform login
    console.log('📝 Filling login credentials...');
    const usernameField = page
      .locator('[data-testid="username"], input[name="username"]')
      .first();
    const passwordField = page
      .locator('[data-testid="password"], input[name="password"]')
      .first();
    const loginButton = page
      .locator('[data-testid="login-button"], button[type="submit"]')
      .first();

    // Wait for fields to be visible
    await usernameField.waitFor({ state: 'visible', timeout: 10000 });
    await passwordField.waitFor({ state: 'visible', timeout: 10000 });
    await loginButton.waitFor({ state: 'visible', timeout: 10000 });

    // Fill credentials
    await usernameField.fill('eugene@ayr-dev');
    await passwordField.fill('Ctodev@123');

    // Click login button
    console.log('🔘 Clicking login button...');
    await loginButton.click();

    // Wait for navigation after login
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(2000);

    // Verify login success
    const currentUrl = page.url();
    const postLoginBodyText = await page.locator('body').textContent();

    console.log('🔍 Debug info:');
    console.log('Current URL:', currentUrl);
    console.log(
      'Body contains "Please enter your username":',
      postLoginBodyText?.includes('Please enter your username and password')
    );
    console.log('URL includes "/login":', currentUrl.includes('/login'));
    console.log(
      'Body contains "HR & Compliance":',
      postLoginBodyText?.includes('HR & Compliance')
    );
    console.log(
      'Body contains "Performance review":',
      postLoginBodyText?.includes('Performance review')
    );
    console.log('URL includes "/calendar":', currentUrl.includes('/calendar'));
    console.log(
      'First 500 chars of body:',
      postLoginBodyText?.substring(0, 500)
    );

    const loginSuccessful =
      !postLoginBodyText?.includes('Please enter your username and password') &&
      !currentUrl.includes('/login') &&
      (postLoginBodyText?.includes('HR & Compliance') ||
        postLoginBodyText?.includes('Performance review') ||
        currentUrl.includes('/calendar'));

    if (loginSuccessful) {
      console.log('✅ Login successful, saving authentication state...');
      // Save authentication state for all tests
      await context.storageState({ path: 'e2e/auth-state.json' });
    } else {
      console.log('❌ Login failed during global setup');
      throw new Error('Global authentication setup failed');
    }
  } catch (error) {
    console.error('❌ Global setup failed:', error);
    throw error;
  } finally {
    await browser.close();
  }

  console.log('✅ Global authentication setup completed');
}

export default globalSetup;
