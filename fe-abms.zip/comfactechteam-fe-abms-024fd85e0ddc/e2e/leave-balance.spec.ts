import { test, expect } from '@playwright/test';

/**
 * Minimal Leave Balance E2E Tests
 * Following the same pattern as review periods tests
 */

// Simple Selectors - Based on actual HTML structure from the page
const SELECTORS = {
  // Navigation
  settingsMenu: '.ant-menu-item:has-text("Settings")',
  leaveBalanceMenu: '.ant-menu-item:has-text("Leave balances")',

  // List Page
  pageTitle: '[data-cy="text-text"]:has-text("Leave balances")',
  newButton: 'a[href*="/settings/leave-balance/new"]',

  // Form Fields - Generic selectors that should work
  employeeSelect: 'input[placeholder*="employee"], .ant-select-selector',
  effectivityDatePicker: 'input[placeholder*="date"], .ant-picker-input input',
  notesTextarea: 'textarea',

  // Buttons - Fallback selectors for different button types
  saveButton:
    'button:has-text("Save"), [data-cy="header-form-submit"], [data-testid="header-form-save-button"]',
  cancelButton:
    'button:has-text("Cancel"), [data-cy="header-form-cancel"], [data-testid="header-form-cancel-button"]',
  editButton: 'button:has-text("Edit"), [data-testid="view-edit-button"]',
  deleteButton:
    'button:has-text("Delete"), [data-cy="view-delete"], [data-testid="view-delete-button"]',

  // Table
  tableRowTitleLink: 'a[data-cy="text-link"], tbody tr a',

  // Search
  searchInput: 'input[placeholder*="search"], [data-cy="list-input-search"]',

  // View Page Navigation
  backButton: 'button:has-text("Back"), [data-testid="view-back-button"]',
  nextButton: 'button:has-text("Next"), [data-cy="view-next"]',
  previousButton: 'button:has-text("Previous"), [data-cy="view-previous"]',
};

test.describe('Leave Balances', () => {
  test.beforeEach(async ({ page }) => {
    // Simple login - just go to the page (authentication handled by global setup)
    await page.goto('/settings/leave-balance');
    await page.waitForLoadState('networkidle');
  });

  test('should navigate to leave balances', async ({ page }) => {
    // Verify we're on the right page
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(4000);
    await expect(
      page.locator(SELECTORS.tableRowTitleLink).first()
    ).toBeVisible();
  });

  test('should search leave balances', async ({ page }) => {
    // Find search input and type
    const searchInput = page.locator(SELECTORS.searchInput).first();

    if (await searchInput.isVisible({ timeout: 5000 })) {
      await searchInput.fill('test');
      await page.waitForTimeout(1000);

      // Verify we have some results (or no results, both are valid)
      const tableRows = page.locator('tbody tr');
      await expect(tableRows.first())
        .toBeVisible({ timeout: 5000 })
        .catch(() => {
          console.log('No search results found, which is also valid');
        });
    } else {
      console.log('Search input not found, skipping search test');
    }
  });

  test('should navigate between records', async ({ page }) => {
    // Click on the first title link to go to view page
    await page.locator(SELECTORS.tableRowTitleLink).first().click();
    await page.waitForLoadState('networkidle');

    // Check if next/previous buttons are available
    const nextButton = page.locator(SELECTORS.nextButton).first();
    const prevButton = page.locator(SELECTORS.previousButton).first();

    // Try to navigate to next record if available
    if (await nextButton.isVisible({ timeout: 3000 })) {
      await nextButton.click();
      await page.waitForLoadState('networkidle');

      // Verify we're still on a view page
      await expect(page.locator(SELECTORS.editButton)).toBeVisible();
    } else {
      console.log('Next button not available or disabled');
    }

    // Try to navigate to previous record if available
    if (await prevButton.isVisible({ timeout: 3000 })) {
      await prevButton.click();
      await page.waitForLoadState('networkidle');

      // Verify we're still on a view page
      await expect(page.locator(SELECTORS.editButton)).toBeVisible();
    } else {
      console.log('Previous button not available or disabled');
    }
  });

  test('should handle form validation errors', async ({ page }) => {
    // Click new button
    await page.locator(SELECTORS.newButton).first().click();
    await page.waitForLoadState('networkidle');

    // Try to save without filling required fields
    await page.locator(SELECTORS.saveButton).first().click();

    // Verify we should NOT be on view page - should still be on form page
    await expect(page.locator(SELECTORS.editButton)).not.toBeVisible({
      timeout: 5000,
    });

    // Check for validation errors (required field indicators)
    const requiredFields = page.locator('.theme-provider-form-item-required');
    await expect(requiredFields.first()).toBeVisible({ timeout: 5000 });

    // Verify we're still on the form by checking for save button
    await expect(page.locator(SELECTORS.saveButton)).toBeVisible({
      timeout: 5000,
    });
  });
});
