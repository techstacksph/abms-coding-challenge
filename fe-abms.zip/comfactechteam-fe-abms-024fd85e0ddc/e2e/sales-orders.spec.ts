import { test, expect } from '@playwright/test';

/**
 * Comprehensive Sales Orders E2E Tests
 * Following the same pattern as review periods and other E2E tests
 */

// Test Data
const TEST_DATA = {
  validSalesOrder: {
    soDate: '15/09/2025',
    preferredPickUpDate: '20/09/2025',
    notes: 'Test sales order created via E2E automation',
    orderType: 'For Customer', // Required field
    customerName: 'Airabell', // Based on HTML data
    franchiseeName: 'test', // Based on HTML data
    siteName: 'Main Site', // Required field
    warehouseName: 'Test123', // Based on HTML data
    locationName: 'Default Location', // Required field
    recordOwnerName: 'Admin User', // Required field
    itemName: 'Test Item',
    quantity: '5',
    unitPrice: '10.00',
  },
  searchTerm: 'SO0000',
  statusToChange: 'In Progress',
};

// Selectors - Based on actual HTML structure and data-cy attributes from the provided snippets
const SELECTORS = {
  // Navigation
  purchasingMenu: '.ant-menu-item:has-text("Purchasing & Inventory")',
  salesOrdersMenu: '.ant-menu-submenu-title:has-text("Sales order")',

  // List Page
  pageTitle: '[data-cy="text-text"]:has-text("Sales order")',
  breadcrumbActive: '[data-cy="text-title"]:has-text("Sales order")',
  newButton: 'a[href*="/purchasing&inventory/sales-order/new"]',

  // Module Cards (Status Overview)
  allSOCard: '[data-cy="module-card-All SO"]',
  createdCard: '[data-cy="module-card-Created"]',
  inProgressCard: '[data-cy="module-card-In progress"]',
  partiallyDeliveredCard: '[data-cy="module-card-Partially delivered"]',
  deliveredCard: '[data-cy="module-card-Delivered"]',
  invoicedCard: '[data-cy="module-card-Invoiced"]',

  // Search and Filters
  searchInput: '[data-cy="list-input-search"]',
  dateFilter: '[data-cy="filter-soDate_date"]',
  customerFilter: '[data-cy="filter-customer.name"]',
  franchiseeFilter: '[data-cy="filter-franchisee.name"]',
  contactFilter: '[data-cy="filter-contact.fullName"]',
  locationFilter: '[data-cy="filter-location.id"]',
  statusFilter: '[data-cy="filter-status.name"]',

  // Table
  tableRow: 'tbody tr',
  tableRowTitleLink: 'a[data-cy="text-link"]',
  statusTag: '[data-cy*="status-tag"]',
  moreActionsButton: 'button[data-testid="MoreVertIcon"]',

  // Form Fields - Based on FormInput component pattern
  soDateInput: '[data-cy="input-soDate"]',
  orderTypeRadio: '[data-cy="Order type"]',
  customerSelect: '[data-cy="input-customerId"]',
  franchiseeSelect: '[data-cy="input-franchiseeId"]',
  contactSelect: '[data-cy="input-contactId"]',
  siteSelect: '[data-cy="input-siteId"]',
  warehouseSelect: '[data-cy="input-warehouseeId"]',
  locationSelect: '[data-cy="input-locationId"]',
  recordOwnerSelect: '[data-cy="input-recordOwnerId"]',
  preferredPickUpDateInput: '[data-cy="input-prefferedPickUpDateTime"]',
  notesTextarea: '[data-cy="input-notes"]',
  invoiceAsPackageCheckbox: '[data-cy="input-invoiceAsPackage"]',

  // Form Buttons
  saveButton:
    '[data-cy="header-form-submit"], [data-testid="header-form-save-button"]',
  cancelButton:
    '[data-cy="header-form-cancel"], [data-testid="header-form-cancel-button"]',
  addItemButton: '[data-cy="list-button-new"]',

  // View Page
  editButton: '[data-testid="view-edit-button"]',
  deleteButton: '[data-cy="view-delete"], [data-testid="view-delete-button"]',
  backButton: '[data-testid="view-back-button"]',
  nextButton: '[data-cy="view-next"]',
  previousButton: '[data-cy="view-previous"]',

  // Status Actions
  inProgressAction: '[data-cy="workflow-In Progress"]',
  completedAction: '[data-cy="workflow-Completed"]',
  deliveredAction: '[data-cy="workflow-Delivered"]',

  // Item Modal/Form
  itemModal: '.theme-provider-modal',
  itemNameInput: '[data-cy="input-name"]',
  itemCodeInput: '[data-cy="input-itemCode"]',
  quantityInput: '[data-cy="input-quantity"]',
  unitPriceInput: '[data-cy="input-unitPrice"]',
  itemSaveButton: '[data-cy="modal-button-submit"]',
  itemCancelButton: '[data-cy="modal-button-cancel"]',
  modalCloseButton: '.theme-provider-modal-close',

  // Validation
  requiredFieldIndicator: '.theme-provider-form-item-required',

  // Template Selection
  addFromTemplateButton: 'button:has-text("Add from template")',
  templateModal: '.theme-provider-modal',
  templateSearchInput: '[data-cy="input-search"]',
  templateSelectButton: '[data-cy="modal-button-submit"]',
};

test.describe('Sales Orders', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to sales orders page
    await page.goto('/purchasing&inventory/sales-order');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(4000); // Allow time for data to load
  });

  test('should navigate to sales orders list page', async ({ page }) => {
    // Verify module cards are loaded
    await expect(page.locator(SELECTORS.allSOCard)).toBeVisible();
    await expect(page.locator(SELECTORS.createdCard)).toBeVisible();

    // Verify table has data
    const tableRows = page.locator(SELECTORS.tableRow);
    await expect(tableRows.first()).toBeVisible();
  });

  test('should display sales order statistics cards', async ({ page }) => {
    // Check all status cards are visible
    const cards = [
      SELECTORS.allSOCard,
      SELECTORS.createdCard,
      SELECTORS.inProgressCard,
      SELECTORS.partiallyDeliveredCard,
      SELECTORS.deliveredCard,
      SELECTORS.invoicedCard,
    ];

    for (const card of cards) {
      await expect(page.locator(card)).toBeVisible();
    }
  });

  test('should search sales orders', async ({ page }) => {
    const searchInput = page.locator(SELECTORS.searchInput).first();

    if (await searchInput.isVisible({ timeout: 5000 })) {
      await searchInput.fill(TEST_DATA.searchTerm);
      await page.waitForTimeout(1000);

      // Verify search results
      const tableRows = page.locator(SELECTORS.tableRow);
      await expect(tableRows.first()).toBeVisible();
    } else {
      console.log('Search input not found, skipping search test');
    }
  });

  test('should change sales order status to in progress', async ({ page }) => {
    // Navigate to view page
    await page.locator(SELECTORS.tableRowTitleLink).first().click();
    await page.waitForLoadState('networkidle');

    // Look for in progress action button
    const inProgressButton = page.locator(SELECTORS.inProgressAction).first();

    if (await inProgressButton.isVisible({ timeout: 5000 })) {
      await inProgressButton.click();

      // Confirm if modal appears
      const confirmButton = page.locator('button:has-text("Confirm")').first();
      if (await confirmButton.isVisible({ timeout: 2000 })) {
        await confirmButton.click();
      }

      // Verify status changed
      await expect(page.locator('[data-cy*="In Progress"]')).toBeVisible({
        timeout: 5000,
      });
    } else {
      console.log(
        'In Progress button not available, skipping status change test'
      );
    }
  });

  test('should navigate between sales order records', async ({ page }) => {
    // Navigate to view page
    await page.locator(SELECTORS.tableRowTitleLink).first().click();
    await page.waitForLoadState('networkidle');

    // Check navigation buttons
    const nextButton = page.locator(SELECTORS.nextButton).first();
    const prevButton = page.locator(SELECTORS.previousButton).first();

    // Try to navigate to next record
    if (await nextButton.isVisible({ timeout: 3000 })) {
      await nextButton.click();
      await page.waitForLoadState('networkidle');
      await expect(page.locator(SELECTORS.editButton)).toBeVisible();
    } else {
      console.log('Next button not available or disabled');
    }

    // Try to navigate to previous record
    if (await prevButton.isVisible({ timeout: 3000 })) {
      await prevButton.click();
      await page.waitForLoadState('networkidle');
      await expect(page.locator(SELECTORS.editButton)).toBeVisible();
    } else {
      console.log('Previous button not available or disabled');
    }
  });

  test('should handle form validation errors', async ({ page }) => {
    // Click new sales order button
    await page.locator(SELECTORS.newButton).first().click();
    await page.waitForLoadState('networkidle');

    // Try to save without filling required fields
    await page.locator(SELECTORS.saveButton).first().click();

    // Verify we're still on form page (validation should prevent save)
    await expect(page.locator(SELECTORS.editButton)).not.toBeVisible({
      timeout: 5000,
    });

    // Check for validation errors
    const requiredFields = page.locator(SELECTORS.requiredFieldIndicator);
    await expect(requiredFields.first()).toBeVisible({ timeout: 5000 });

    // Fill only some fields and try to save
    await page.locator(SELECTORS.notesTextarea).fill('Test notes');

    // Try to save again
    await page.locator(SELECTORS.saveButton).first().click();

    // Should still be on form page due to missing required fields
    await expect(page.locator(SELECTORS.editButton)).not.toBeVisible({
      timeout: 5000,
    });
    await expect(page.locator(SELECTORS.saveButton)).toBeVisible({
      timeout: 5000,
    });
  });

  test('should handle empty search results gracefully', async ({ page }) => {
    const searchInput = page.locator(SELECTORS.searchInput).first();

    if (await searchInput.isVisible({ timeout: 5000 })) {
      // Search for non-existent term
      await searchInput.fill('NONEXISTENT_SEARCH_TERM_12345');
      await page.waitForTimeout(1000);

      // Should handle empty results gracefully (either no rows or empty state)
      const tableRows = page.locator(SELECTORS.tableRow);
      const rowCount = await tableRows.count();

      // Either no rows or empty state should be handled
      if (rowCount === 0) {
        console.log(
          'No search results found - this is expected for non-existent term'
        );
      } else {
        console.log(
          `${rowCount} rows found - search may not be working as expected`
        );
      }
    } else {
      console.log('Search input not found, skipping empty search test');
    }
  });
});
