import { test as base, expect } from '@playwright/test';

/**
 * Custom fixture that provides authenticated page context
 * This fixture can be used across all test files for consistent authentication
 */
export const test = base.extend<{
  authenticatedPage: any;
}>({
  authenticatedPage: async ({ page }, use) => {
    // Navigate to home page - authentication state is already loaded from global setup
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Verify authentication was successful
    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed - user is not logged in');
    }

    // Pass the authenticated page to the test
    await use(page);
  },
});

export { expect };
