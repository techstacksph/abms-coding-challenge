import { test, expect, Page } from '@playwright/test';
import { config } from 'dotenv';
config();

const BASE_URL = process.env.PW_BASE_URL || 'http://localhost:3000';

// Test Data Constants
const TEST_DATA = {
  validPerformanceReview: {
    employee: 'Prince Rastogi',
    manager: 'Auto-selected',
    department: 'Executive & Administrative',
    questionnaire: 'Skip for now',
    reviewDate: '31/08/2025',
    notes:
      'Excellent performance throughout the year. Exceeded all targets and showed great leadership skills.',
  },
  updatedPerformanceReview: {
    employee: 'Alice Johnson',
    manager: 'Bob Wilson',
    department: 'Marketing',
    questionnaire: 'Mid-Year Review',
    reviewDate: '2024-06-30',
    notes:
      'Good progress on key objectives. Areas for improvement identified and action plan created.',
  },
  invalidPerformanceReview: {
    employee: '',
    manager: '',
    department: '',
    questionnaire: '',
    reviewDate: '',
    notes: '',
  },
};

// Selectors organized by functionality
const SELECTORS = {
  // Navigation and Layout
  navigation: {
    settingsMenu: 'button:has(span.material-symbols-outlined:has-text("settings"))',
    dealTemplatesLink: 'a[href="/settings/deal-templates"]',
    sideMenu: '.ant-menu, [role="menu"]',
    breadcrumb: '.ant-breadcrumb, [aria-label="Breadcrumb"]',
  },

  newPage: {
    pageTitle:
      '[data-cy="text-text"]:has-text("New deal template")',
  },

  viewPage: {
    fieldValidation: {
      serviceType: '[data-cy="text-text"]:has-text("Service type")',
    },
    button: {
      edit: '[data-testid="view-edit-button"]',
    }
  },

  // List Page Elements
  listPage: {
    pageTitle:
      '[data-cy="text-text"]:has-text("Deal templates")',
    newButton:
      '[data-cy="text-link"]:has-text("Deal template")',
    searchInput:
      '[data-testid="search-input"], .ant-input[placeholder*="Search"], input[placeholder*="search" i]',
    filterButton:
      '[data-testid="filter-button"], button:has-text("Filter"), .ant-btn:has-text("Filter")',
    exportButton:
      '[data-testid="export-button"], button:has-text("Export"), .ant-btn:has-text("Export")',
  },

  // Table Components
  table: {
    container: '.ant-table, [data-testid="data-table"], table',
    header: '.ant-table-thead, thead',
    body: '.ant-table-tbody, tbody',
    row: '.ant-table-row, tr[data-row-key], tbody tr, .theme-provider-table-row',
    cell: '.ant-table-cell, td, .theme-provider-table-cell',
    noData: '.ant-empty, .no-data, [data-testid="no-data"]',
    loading: '.ant-spin, .loading, [data-testid="loading"]',
    sortButton:
      '.theme-provider-table-column-sorters, .ant-table-column-sorters',
    performanceReviewNoSort:
      '.theme-provider-table-column-sorters:has(.theme-provider-table-column-title:has-text("Performance review no."))',
  },

  // Pagination
  pagination: {
    container: '.ant-pagination, [data-testid="pagination"]',
    prevButton: '.ant-pagination-prev, [aria-label="Previous page"]',
    nextButton: '.ant-pagination-next, [aria-label="Next page"]',
    pageNumber: '.ant-pagination-item, [data-testid="page-number"]',
    pageSize: '.ant-pagination-options-size-changer, [data-testid="page-size"]',
  },

  // Form Fields
  form: {

    container: '.ant-form, form, [data-testid="performance-review-form"]',
    serviceTypeSelect: '[data-testid="service-type-select"], [data-testid="serviceTypeId"]',
    employeeSelect:
      '[data-testid="employee-select"], [data-testid="employeeId"]',
    managerSelect: '[data-testid="manager-select"], [data-testid="managerId"]',
    departmentSelect:
      '[data-testid="department-select"], [data-testid="departmentIds"]',
    questionnaireSelect:
      '[data-testid="questionnaire-select"], [data-testid="questionnaireIds"]',
    reviewDatePicker:
      '[data-testid="review-date-input"], [data-testid="review-date"], [data-testid="reviewDate"], .ant-picker',
    notesTextarea:
      '[data-testid="notes"], textarea[placeholder*="notes" i], .ant-input',
  },

  // Buttons and Actions
  buttons: {
    save: '[data-testid="header-form-save-button"], [data-testid="footer-form-save-button"], button:has-text("Save"), .ant-btn-primary:has-text("Save")',
    cancel:
      '[data-testid="header-form-cancel-button"], [data-testid="footer-form-cancel-button"], button:has-text("Cancel"), .ant-btn:has-text("Cancel")',
    edit: '[data-testid="edit-button"], button:has-text("Edit"), .ant-btn:has-text("Edit")',
    delete:
      '[data-testid="delete-button"], button:has-text("Delete"), .ant-btn-danger',
    confirm:
      '[data-testid="confirm-button"], button:has-text("Confirm"), .ant-btn-primary:has-text("OK")',
  },

  // Action Menu and Dropdowns
  actionMenu: {
    trigger:
      '[data-testid="action-menu"], .ant-dropdown-trigger, button[aria-haspopup="true"]',
    dropdown: '.ant-dropdown, [data-testid="action-dropdown"]',
    editAction:
      '[data-testid="edit-action"], .ant-dropdown-menu-item:has-text("Edit")',
    deleteAction:
      '[data-testid="delete-action"], .ant-dropdown-menu-item:has-text("Delete")',
    viewAction:
      '[data-testid="view-action"], .ant-dropdown-menu-item:has-text("View")',
  },

  // Status Actions
  status: {
    statusBadge: '.ant-badge, .status-badge, [data-testid="status-badge"]',
    statusSelect: '[data-testid="status-select"], .ant-select',
    statusOption: '.ant-select-item, [data-testid="status-option"]',
    updateButton:
      '[data-testid="update-status"], button:has-text("Update Status")',
  },

  // Modals and Dialogs
  modal: {
    container: '.ant-modal, [data-testid="modal"], [role="dialog"]',
    title: '.ant-modal-title, [data-testid="modal-title"]',
    content: '.ant-modal-body, [data-testid="modal-content"]',
    footer: '.ant-modal-footer, [data-testid="modal-footer"]',
    closeButton:
      '.ant-modal-close, [data-testid="modal-close"], button[aria-label="Close"]',
  },

  // Error and Success Messages
  messages: {
    error: '.ant-message-error, .error-message, [data-testid="error-message"]',
    success:
      '.ant-message-success, .success-message, [data-testid="success-message"]',
    warning:
      '.ant-message-warning, .warning-message, [data-testid="warning-message"]',
    validation:
      '.ant-form-item-explain-error, .field-error, [data-testid="validation-error"]',
  },

  // Search and Filter
  search: {
    input: '[data-testid="search-input"], input[placeholder*="search" i]',
    button: '[data-testid="search-button"], button:has-text("Search")',
    clear: '[data-testid="clear-search"], button:has-text("Clear")',
    results: '[data-testid="search-results"], .search-results',
  },

  // Dashboard Cards
  dashboard: {
    card: '.dashboard-card, [data-testid="dashboard-card"], .ant-card',
    cardTitle: '.ant-card-head-title, [data-testid="card-title"]',
    cardValue: '.card-value, [data-testid="card-value"]',
    allCard: '[data-testid="all-card"], .dashboard-card:has-text("All")',
    pendingCard:
      '[data-testid="pending-card"], .dashboard-card:has-text("Pending")',
    completedCard:
      '[data-testid="completed-card"], .dashboard-card:has-text("Completed")',
  },
};

// Page Object Model
class DealTemplatePage {
  constructor(private page: Page) {}

  // Navigation Methods
  async login(
    username: string = 'dev@comfactechoptions.com',
    password: string = '8F7Mb83sGa'
  ) {
    console.log('🔐 Attempting to log in...');
    await this.page.goto('/');
    await this.page.waitForLoadState('networkidle');

    // Check if already logged in
    const isLoggedIn = await this.page.locator('body').textContent();
    if (
      isLoggedIn?.includes('Calendar') ||
      isLoggedIn?.includes('Deal templates')
    ) {
      console.log('✅ Already logged in');
      return;
    }

    // Perform login if needed
    const usernameField = this.page
      .locator('[data-testid="username"], input[name="username"]')
      .first();
    const passwordField = this.page
      .locator('[data-testid="password"], input[name="password"]')
      .first();
    const loginButton = this.page
      .locator('[data-testid="login-button"], button[type="submit"]')
      .first();

    if (await usernameField.isVisible()) {
      console.log('📝 Filling login credentials...');
      await usernameField.fill(username);
      await passwordField.fill(password);

      console.log('🔘 Clicking login button...');
      await loginButton.click();

      // Wait for navigation after login
      await this.page.waitForLoadState('networkidle');
      await this.page.waitForTimeout(2000);

      // Verify login success by checking if we're no longer on login page
      const currentUrl = this.page.url();
      const bodyText = await this.page.locator('body').textContent();

      const loginSuccessful =
        !bodyText?.includes('Please enter your username and password') &&
        !currentUrl.includes('/login') &&
        (bodyText?.includes('Calendar') ||
          bodyText?.includes('Deal templates') ||
          currentUrl.includes('/calendar'));

      if (loginSuccessful) {
        console.log('✅ Login successful');
      } else {
        console.log('❌ Login failed - still on login page');
        throw new Error(`Login failed with ${username}/${password}`);
      }
    }
  }

  async navigateToDealTemplate() {
    console.log('🧭 Navigating to Deal Template module...');

    // Try multiple navigation strategies
    const strategies = [
      // Direct URL navigation
      async () => {
        await this.page.goto('/settings/deal-templates');
        await this.page.waitForLoadState('networkidle');
      },
      // Menu navigation
      async () => {
        const settingsMenu = this.page
          .locator(SELECTORS.navigation.settingsMenu)
          .first();
        if (await settingsMenu.isVisible()) {
          await settingsMenu.click();
          await this.page.waitForTimeout(500);
        }

        const dealTemplatesLink = this.page
          .locator(SELECTORS.navigation.dealTemplatesLink)
          .first();
        if (await dealTemplatesLink.isVisible()) {
          await dealTemplatesLink.click();
          await this.page.waitForLoadState('networkidle');
        }
      },
    ];

    for (const strategy of strategies) {
      try {
        await strategy();
        // Verify we're on the right page
        const pageTitle = this.page
          .locator(SELECTORS.listPage.pageTitle)
          .first();
        if (await pageTitle.isVisible({ timeout: 5000 })) {
          console.log('✅ Successfully navigated to Deal Templates page');
          return;
        }
      } catch (error) {
        console.log(`⚠️ Navigation strategy failed: ${error.message}`);
        continue;
      }
    }

    throw new Error('Failed to navigate to Deal Templates page');
  }
  

  async clickNewButton() {
    console.log('➕ Clicking New button...');

    const selectors = [
      'a[href*="/new"]',
      SELECTORS.listPage.newButton,
      'button:has-text("New")',
      '.ant-btn:has-text("New")',
    ];

    for (const selector of selectors) {
      try {
        const element = this.page.locator(selector).first();
        if (await element.isVisible({ timeout: 2000 })) {
          console.log(`✅ Found New button with selector: ${selector}`);

          // Check if it's a link or button
          const tagName = await element.evaluate(el =>
            el.tagName.toLowerCase()
          );
          const href = await element.getAttribute('href');

          if (tagName === 'a' && href) {
            console.log(`🔗 Navigating to: ${href}`);
            await element.click();
          } else {
            await element.click();
          }

          await this.page.waitForLoadState('networkidle');
          console.log('✅ New button clicked successfully');
          return;
        }
      } catch (error) {
        console.log(`⚠️ Selector ${selector} failed: ${error.message}`);
        continue;
      }
    }

    throw new Error('Could not find or click New button');
  }

  // Form Interaction Methods
  async selectFromDropdown(
    fieldSelector: string,
    optionText: string,
    fieldName: string = 'field'
  ) {
    console.log(`🔽 Selecting "${optionText}" from ${fieldName} dropdown...`);

    const dropdown = this.page.locator(fieldSelector).first();

    // Wait for dropdown to be visible
    await dropdown.waitFor({ state: 'visible', timeout: 10000 });

    // Wait for any pending network requests to complete
    await this.page.waitForLoadState('networkidle', { timeout: 15000 });

    // Click to open dropdown
    await dropdown.click();

    console.log(`⏳ Waiting for ${fieldName} options to load...`);

    // Wait for options to appear
    await this.page.waitForSelector('[role="option"]', { timeout: 10000 });

    // Click the first available option
    const firstOption = this.page.locator('[role="option"]').first();
    await firstOption.click();

    console.log(`✅ Selected first available option from ${fieldName}`);
    await this.page.waitForTimeout(500);
  }

  async fillPerformanceReviewForm(
    data: typeof TEST_DATA.validPerformanceReview
  ) {
    console.log('📝 Filling performance review form...');

    // Wait for form to be visible
    await this.page
      .locator(SELECTORS.form.container)
      .first()
      .waitFor({ state: 'visible', timeout: 10000 });

    // Fill Employee first (this will auto-select the manager)
    if (data.employee) {
      await this.selectFromDropdown(
        SELECTORS.form.employeeSelect,
        data.employee,
        'Employee'
      );

      // Wait for manager to be auto-selected after employee selection
      console.log('⏳ Waiting for manager to be auto-selected...');
      await this.page.waitForTimeout(1000);
    }

    // Note: Manager is auto-selected based on employee's primary manager
    // No need to manually select manager as it's handled automatically

    // Fill Department (optional - skip if no options available)
    if (data.department) {
      try {
        await this.selectFromDropdown(
          SELECTORS.form.departmentSelect,
          data.department,
          'Department'
        );
      } catch {
        console.log('⚠️ Department dropdown has no options, leaving blank');
      }
    }

    // Skip Questionnaire for now - seems to have issues
    // TODO: Fix questionnaire selection
    console.log('⚠️ Skipping questionnaire selection for now');

    // Fill Review Date
    console.log(`🗓️ Attempting to fill review date: ${data.reviewDate}`);
    if (data.reviewDate) {
      const datePicker = this.page
        .locator(SELECTORS.form.reviewDatePicker)
        .first();
      console.log('🔍 Checking if date picker is visible...');
      const isVisible = await datePicker.isVisible({ timeout: 5000 });
      console.log(`📅 Date picker visible: ${isVisible}`);

      if (isVisible) {
        console.log('📅 Clicking date picker...');
        await datePicker.click();
        await this.page.waitForTimeout(500);

        console.log(`📅 Filling date: ${data.reviewDate}`);
        await datePicker.fill(data.reviewDate);
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(500);
      } else {
        console.log(
          '❌ Date picker not visible - this could cause validation errors!'
        );
      }
    } else {
      console.log('❌ No review date provided in test data!');
    }

    // Fill Notes
    if (data.notes) {
      const notesField = this.page
        .locator(SELECTORS.form.notesTextarea)
        .first();
      if (await notesField.isVisible({ timeout: 5000 })) {
        await notesField.fill(data.notes);
        console.log('✅ Filled notes field');
      }
    }

    console.log('✅ Form filled successfully');
  }

  async saveForm() {
    console.log('💾 Saving form...');
    const saveButton = this.page.locator(SELECTORS.buttons.save).first();

    // Check if save button is already visible
    const isVisible = await saveButton
      .isVisible({ timeout: 2000 })
      .catch(() => false);

    if (isVisible) {
      console.log('✅ Save button is visible, clicking...');
      await saveButton.click();
    } else {
      console.log(
        '⚠️ Save button not visible, trying alternative selectors...'
      );

      // Try alternative save button selectors
      const alternativeSelectors = [
        '[data-testid="footer-form-save-button"]',
        '[data-testid="header-form-save-button"]',
        'button:has-text("Save")',
        '.ant-btn-primary:has-text("Save")',
        'button[type="submit"]',
      ];

      let clicked = false;
      for (const selector of alternativeSelectors) {
        try {
          const altButton = this.page.locator(selector).first();
          if (await altButton.isVisible({ timeout: 1000 })) {
            console.log(`✅ Found save button with selector: ${selector}`);
            await altButton.click();
            clicked = true;
            break;
          }
        } catch (error) {
          console.log(`⚠️ Selector ${selector} failed: ${error.message}`);
          continue;
        }
      }

      if (!clicked) {
        console.log('⚠️ Could not find any save button, but continuing...');
      }
    }

    await this.page.waitForLoadState('networkidle');
    console.log('✅ Form save process completed');
  }

  // Verification Methods
  async verifyPageTitle(expectedTitle: string) {
    const title = this.page.locator(SELECTORS.listPage.pageTitle).first();
    await expect(title).toContainText(expectedTitle);
  }

  async verifySuccessMessage() {
    const successMessage = this.page
      .locator(SELECTORS.messages.success)
      .first();
    await expect(successMessage).toBeVisible({ timeout: 10000 });
  }

  async verifyTableHasData() {
    const tableRows = this.page.locator(SELECTORS.table.row);
    await expect(tableRows.first())
      .toBeVisible({ timeout: 1000 })
      .catch(() => {
        console.log(
          '⚠️ Table row not visible after 1 second, continuing with test...'
        );
      });
  }

  async sortByPerformanceReviewNo() {
    console.log('🔄 Sorting table by Performance review no...');
    const sortButton = this.page
      .locator(SELECTORS.table.performanceReviewNoSort)
      .first();

    // Wait for the sort button to be visible
    await sortButton.waitFor({ state: 'visible', timeout: 10000 });

    // Click the sort button to sort the table
    await sortButton.click();
    await sortButton.click();

    // Wait for the table to update after sorting
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(1000);

    console.log('✅ Table sorted by Performance review no.');
  }

  async verifyFormValidationError() {
    const validationError = this.page
      .locator(SELECTORS.messages.validation)
      .first();
    await expect(validationError).toBeVisible({ timeout: 5000 });
  }

  async deleteFirstRecord() {
    console.log('🗑️ Deleting first record...');

    // First navigate to the view page by clicking the first record link
    await this.clickFirstRecordLink();
    console.log('✅ Navigated to view page');

    // Find and click the delete button on the view page
    const deleteButton = this.page.locator(
      '[data-cy="view-delete"], [data-testid="view-delete-button"]'
    );
    await deleteButton.waitFor({ state: 'visible', timeout: 5000 });
    await deleteButton.click();
    console.log('✅ Clicked delete button on view page');

    // Wait for confirmation modal and confirm deletion
    const confirmButton = this.page.locator('[data-cy="modal-button-submit"]');
    await confirmButton.waitFor({ state: 'visible', timeout: 5000 });
    await confirmButton.click();
    console.log('✅ Confirmed deletion');

    // Wait for the action to complete and navigation back to list
    await this.page.waitForLoadState('networkidle');
    console.log('✅ Record deletion completed');
  }

  async clickFirstRecordLink() {
    console.log(
      '🔗 Clicking first record PR number link to navigate to view page...'
    );

    // Wait for table to load
    await this.page
      .locator(SELECTORS.table.row)
      .first()
      .waitFor({ state: 'visible', timeout: 10000 })
      .catch(() => {
        console.log('⚠️ Table row not visible after 10 seconds, continuing...');
      });

    // Find the first row with actual content (skip spacer rows)
    const tableRows = await this.page.locator(SELECTORS.table.row).count();
    let actualDataRow: any = null;

    for (let i = 0; i < Math.min(tableRows, 5); i++) {
      const row = this.page.locator(SELECTORS.table.row).nth(i);
      const rowText = await row.textContent();
      const hasVisibleContent = rowText && rowText.trim().length > 0;

      if (hasVisibleContent) {
        actualDataRow = row;
        console.log(`✅ Found actual data row at index ${i}`);
        break;
      }
    }

    if (actualDataRow) {
      // Try to find PR number link in second cell
      const prNumberCell = actualDataRow.locator('td').nth(1);
      const prNumberLink = prNumberCell.locator('[data-cy="text-link"]');

      const linkExists = await prNumberLink.count();
      console.log(`🔗 Found ${linkExists} text-link elements in second cell`);

      if (linkExists > 0) {
        const linkText = await prNumberLink.textContent();
        console.log(`🔗 Link text: "${linkText?.trim()}"`);

        // Click the PR number link to navigate to view page
        await prNumberLink.waitFor({ state: 'visible', timeout: 5000 });
        await prNumberLink.click({ timeout: 5000 });

        // Wait for navigation to complete
        await this.page.waitForLoadState('networkidle');
        console.log(
          '✅ Successfully navigated to record view page via PR number link'
        );
      } else {
        console.log('❌ No text-link found in second cell');
        // Try alternative approach - look for any link in the row
        const anyLink = actualDataRow.locator('a').first();
        const anyLinkCount = await actualDataRow.locator('a').count();
        console.log(`🔗 Found ${anyLinkCount} total links in data row`);

        if (anyLinkCount > 0) {
          await anyLink.click({ timeout: 5000 });
          await this.page.waitForLoadState('networkidle');
          console.log('✅ Clicked first available link in row');
        } else {
          console.log('❌ No links found in data row at all');
        }
      }
    } else {
      console.log('❌ No data rows with content found');
    }
  }
}

// Test Suite
test.describe('Deal Template E2E Tests', () => {
  let dealTemplatePage: DealTemplatePage;

  test.beforeEach(async ({ page }) => {
    dealTemplatePage = new DealTemplatePage(page);
    // Authentication state is loaded from global setup
    // Verify we're logged in by checking for authenticated content
    await page.goto('/');
    //await page.waitForLoadState('networkidle');

    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed - still on login page');
    }
  });

  test.describe('Basic Setup and Navigation', () => {
    test('should navigate to deal template module', async () => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.verifyPageTitle('Deal templates');
    });

    test('should display page elements correctly', async ({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      //Verify key page elements are visible
      await expect(page.locator(SELECTORS.listPage.pageTitle).first()).toBeVisible();
      await expect(page.locator(SELECTORS.listPage.newButton).first()).toBeVisible();
      await expect(page.locator(SELECTORS.table.container)).toBeVisible();
    });
  });

  test.describe('Deal Template New Page Tests', () => {
    test('should be able to click on new button', async({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.clickNewButton();

      //await page.waitForLoadState('networkidle');

      await expect(page.locator(SELECTORS.newPage.pageTitle).first()).toBeVisible();
      await expect(page.locator(SELECTORS.form.serviceTypeSelect).first()).toBeVisible();
    })

    test('should be able to see the service type field in new page', async({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.clickNewButton();

      await page.waitForLoadState('networkidle');

      await expect(page.locator(SELECTORS.form.serviceTypeSelect).first()).toBeVisible();
    })

  })

  test.describe('Deal Template View Page Tests', () => {
    test('should be able to click on deal template link and service type field should be displayed', async({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.clickFirstRecordLink();

      await page.waitForLoadState('networkidle');

      await expect(page.locator(SELECTORS.viewPage.fieldValidation.serviceType).first()).toBeVisible();
    })
  })

  test.describe('Deal Template Edit Page Tests', () => {
    test('should be able to click on navigate to edit page', async({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.clickFirstRecordLink();

      await page.waitForLoadState('networkidle');


      await expect(page.locator(SELECTORS.viewPage.button.edit).first()).toBeVisible();
    })

    test('should be able to see the service type field in edit page', async({ page }) => {
      await dealTemplatePage.navigateToDealTemplate();
      await dealTemplatePage.clickFirstRecordLink();

      await page.waitForLoadState('networkidle');

      await page.locator(SELECTORS.viewPage.button.edit).first().click()

      await page.waitForLoadState('networkidle');

      await expect(page.locator(SELECTORS.form.serviceTypeSelect).first()).toBeVisible();
    })
  })
});

// Export for use in other test files
export { DealTemplatePage, TEST_DATA, SELECTORS };
