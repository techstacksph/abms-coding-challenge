# TypeScript Error Fixes - Action Plan

## Summary
Found 866 TypeScript errors across 346 files. Main categories:

### 1. Routes Object Access Errors (Major Priority)
**Files affected:** 346+ files
**Issue:** Properties like `.list`, `.edit`, `.view`, `.new` don't exist on `RouteValue` type
**Examples:**
- `Routes?.Users?.list` 
- `Routes?.Functions?.edit`
- `Routes['PriceLists']?.view`

**Root Cause:** The Routes pattern migration changed the Routes object structure but the type definitions weren't updated.

**Solution:** Update the Routes type definition to support the new helper functions

### 2. Component Prop Type Mismatches (High Priority)
**Files affected:** 50+ files
**Examples:**
- `size='medium'` not assignable to `SwitchSize`
- `loading` prop doesn't exist on Form components
- `gap` prop doesn't exist on Space component
- `type` and `title` prop mismatches on Modal components

**Solution:** Fix individual component prop types and update component interfaces

### 3. Missing Navigation Imports (Medium Priority) 
**Files affected:** 10+ files
**Issue:** `navigate` function not imported
**Solution:** Add proper navigation imports

### 4. Form Field Type Mismatches (Medium Priority)
**Files affected:** 30+ files  
**Issue:** FormSection fields don't match InputSection type
**Solution:** Update field type definitions

### 5. Filter Type Mismatches (Low Priority)
**Files affected:** 10+ files
**Issue:** Filter types don't match expected FilterType
**Solution:** Update filter type definitions

## Implementation Order:
1. Fix Routes type definitions (biggest impact)
2. Fix critical component prop mismatches  
3. Add missing imports
4. Fix form and filter types
5. Validate with `npx tsc --noEmit`

## Progress Tracking:
- [ ] Routes type fixes
- [ ] Component prop fixes  
- [ ] Missing import fixes
- [ ] Form type fixes
- [ ] Filter type fixes
- [ ] Final validation
