# GenericTab Events Components

This document provides comprehensive guidance for using the reusable Events components from the `@/components/GenericTab/events` folder.

## 📁 Component Structure

```
src/components/GenericTab/events/
├── EventForm.tsx
├── EventsDataTable.tsx
├── example-usage.tsx
└── index.ts
```

## 🎯 Components Overview

### Events Components
- **EventForm**: Reusable form for creating/editing events
- **EventsDataTable**: Reusable data table for displaying events with actions

## 🚀 Quick Start

### 1. Import Components

```tsx
import { EventForm, EventsDataTable } from '@/components/GenericTab/events';
```

### 2. Basic Usage

#### Events DataTable
```tsx
import { EventsDataTable } from '@/components/GenericTab/events';

const AccountEvents = () => {
  return (
    <EventsDataTable
      id="account-123"
      module="accounts"
      // Optional: Custom callbacks
      onNewEvent={() => console.log('New event')}
      onEditEvent={(event) => console.log('Edit event:', event)}
      onViewEvent={(event) => console.log('View event:', event)}
    />
  );
};
```

#### Events Form
```tsx
import { EventForm } from '@/components/GenericTab/events';

const NewAccountEvent = () => {
  const breadCrumbs = ['Accounts', 'Accounts', 'View Account', 'New Event'];

  return (
    <EventForm
      mode="new"
      breadCrumbs={breadCrumbs}
      accountId="account-123"
    />
  );
};
```

## 📋 Component Props

### EventsDataTable Props
```tsx
interface EventsDataTableProps {
  id?: string;                    // Related record ID (e.g., accountId, dealId)
  module?: string;                // Module name for field mapping
  tab?: string;                   // Current tab state
  setTab?: (val: string) => void; // Tab setter function
  breadCrumbs?: string[];         // Breadcrumb navigation
  onNewEvent?: () => void;        // Custom new event handler
  onEditEvent?: (event: EventModel) => void; // Custom edit handler
  onViewEvent?: (event: EventModel) => void; // Custom view handler
}
```

### EventForm Props
```tsx
interface EventFormProps {
  mode: 'new' | 'edit';          // Form mode
  breadCrumbs: string[];         // Breadcrumb navigation
  [key: string]: any;            // Additional props passed to providers
}
```

## 🏗️ Module Setup Requirements

### 1. Route Configuration

Each module using Events components needs the following routes:

```tsx
// Required routes for events
{
  path: '/your-module/:id/events',
  element: <EventsList />
},
{
  path: '/your-module/:id/events/new',
  element: <EventsNew />
},
{
  path: '/your-module/:id/events/:eventId/edit',
  element: <EventsEdit />
},
{
  path: '/your-module/:id/events/:eventId',
  element: <EventsView />
}
```

### 2. Component Templates

#### Events List Component
```tsx
// src/views/your-module/view/tabs/events/list/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { EventsDataTable } from '@/components/GenericTab/events';

const YourModuleEventsList = props => {
  const { id } = useParams();
  
  return (
    <EventsDataTable
      id={id}
      module="your-module"
      {...props}
    />
  );
};

export default YourModuleEventsList;
```

#### Events New Component
```tsx
// src/views/your-module/view/tabs/events/new/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { EventForm } from '@/components/GenericTab/events';

const YourModuleEventsNew = props => {
  const { id } = useParams();
  const breadCrumbs = ['Your Module', 'View Your Module', 'New Event'];

  return (
    <EventForm
      mode="new"
      breadCrumbs={breadCrumbs}
      yourModuleId={id}
      {...props}
    />
  );
};

export default YourModuleEventsNew;
```

#### Events Edit Component
```tsx
// src/views/your-module/view/tabs/events/edit/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { EventForm } from '@/components/GenericTab/events';

const YourModuleEventsEdit = props => {
  const { id, eventId } = useParams();
  const breadCrumbs = ['Your Module', 'View Your Module', 'Edit Event'];

  return (
    <EventForm
      mode="edit"
      breadCrumbs={breadCrumbs}
      yourModuleId={id}
      eventId={eventId}
      {...props}
    />
  );
};

export default YourModuleEventsEdit;
```

#### Events View Component
```tsx
// src/views/your-module/view/tabs/events/view/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';

const YourModuleEventsView = props => {
  const { id, eventId } = useParams();
  
  // Use existing event view components
  return (
    <EventView eventId={eventId} />
  );
};

export default YourModuleEventsView;
```

### 3. Tab Integration

Add the events tab to your module's main view:

```tsx
// In your module's main view component
{
  key: 'events',
  label: 'Events',
  children: <YourModuleEventsList {...props} />,
}
```

### 4. Integrate Events List into Module Tab View
**CRITICAL STEP**: You must integrate the events list into your module's tab view so it appears when users click on the Events tab.

#### Option A: Direct Integration in Tab Component
If your module has a tab component that handles the Events tab, update it to use the new List component:

```tsx
// src/views/your-module/view/tabs/events/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import YourModuleEventsList from './list';

const EventsTab = props => {
  const { id } = useParams();
  
  return (
    <YourModuleEventsList
      id={id}
      tab={props?.tab}
      setTab={props?.setTab}
      {...props}
    />
  );
};

export default EventsTab;
```

#### Option B: Update Existing Tab Structure
If your module uses a different tab structure, find the component that renders the Events tab and update it:

```tsx
// Example: In your module's main view component
const YourModuleView = () => {
  const [currentTab, setCurrentTab] = useState('info');
  
  const renderTabContent = () => {
    switch (currentTab) {
      case 'events':
        return (
          <YourModuleEventsList
            id={id}
            tab={currentTab}
            setTab={setCurrentTab}
          />
        );
      case 'info':
        return <InfoTab />;
      // ... other tabs
    }
  };
  
  return (
    <div>
      {/* Tab navigation */}
      <Tabs activeKey={currentTab} onChange={setCurrentTab}>
        <TabPane key="info" tab="Info" />
        <TabPane key="events" tab="Events" />
        {/* ... other tabs */}
      </Tabs>
      
      {/* Tab content */}
      {renderTabContent()}
    </div>
  );
};
```

#### Option C: Check for Existing Events Tab
Look for existing events tab implementations in your module and replace them:

```tsx
// Before: Old events implementation
case 'events':
  return <OldEventsComponent />;

// After: New GenericTab implementation
case 'events':
  return (
    <YourModuleEventsList
      id={id}
      tab={currentTab}
      setTab={setCurrentTab}
    />
  );
```

## 🔧 Module-Specific Configuration

### Field Mapping

The Events components use different field mappings based on the module:

- **Accounts**: `accountId`
- **Deals**: `dealId`
- **Leads**: `leadId`
- **Events**: `eventId`
- **Tasks**: `taskId`

### Custom Callbacks

You can provide custom callbacks for navigation and actions:

```tsx
const handleNewEvent = () => {
  // Custom navigation logic
  navigate('/custom-path');
};

const handleEditEvent = (event) => {
  // Custom edit logic
  openModal(event);
};

<EventsDataTable
  onNewEvent={handleNewEvent}
  onEditEvent={handleEditEvent}
/>
```

## 📚 Migration Guide

### From Module-Specific Components

If you have existing module-specific components, migrate them:

#### Before (Module-Specific)
```tsx
// Old way
import AccountEventsList from './AccountEventsList';
import AccountEventForm from './AccountEventForm';

// Usage
<AccountEventsList accountId={id} />
<AccountEventForm mode="new" accountId={id} />
```

#### After (Generic Components)
```tsx
// New way
import { EventsDataTable, EventForm } from '@/components/GenericTab/events';

// Usage
<EventsDataTable id={id} module="accounts" />
<EventForm mode="new" breadCrumbs={breadCrumbs} accountId={id} />
```

### Implementation Checklist
- [ ] Create List component (`list/index.tsx`)
- [ ] Create New component (`new/index.tsx`)
- [ ] Create Edit component (`edit/index.tsx`)
- [ ] Create View component (`view/index.tsx`)
- [ ] Add route configurations
- [ ] Add imports to lazyComponents
- [ ] **INTEGRATE INTO TAB VIEW** (Step 4)
- [ ] Test all event operations
- [ ] Test navigation flow

## 🐛 Troubleshooting

### Common Issues

1. **GraphQL Errors**: Ensure the correct field mapping is used for your module
2. **Navigation Issues**: Verify routes are properly configured
3. **Missing Data**: Check that the `id` prop is correctly passed
4. **Import Errors**: Ensure all required components are imported
5. **Events tab shows empty or old content**: **MISSING STEP** - You forgot to integrate the events list into your module's tab view. See "Step 4: Integrate Events List into Module Tab View" above.
6. **Events tab not appearing**: Check if the tab is properly configured in your module's tab structure

### Debug Tips

1. Check browser console for GraphQL errors
2. Verify route paths match your module structure
3. Ensure all required props are passed to components
4. Check that EventProvider is available

## ✅ Best Practices

1. **Consistent Naming**: Use consistent naming conventions across modules
2. **Error Handling**: Implement proper error boundaries
3. **Loading States**: Handle loading states appropriately
4. **Type Safety**: Use TypeScript interfaces for props
5. **Testing**: Test all event operations and navigation flows

## 📖 Examples

See the `example-usage.tsx` file for detailed usage examples:

- `src/components/GenericTab/events/example-usage.tsx`

## 🔄 Updates and Maintenance

When updating Events components:

1. Test across all modules using the components
2. Test across all modules using the components
3. Ensure backward compatibility
4. Update example usage files
5. Test navigation and form submission flows

---

This documentation provides a comprehensive guide for implementing reusable Events components across different modules in your application. 