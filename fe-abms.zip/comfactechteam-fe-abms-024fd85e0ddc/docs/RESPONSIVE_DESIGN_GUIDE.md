# Responsive Design Guide

This document provides a comprehensive guide for making pages responsive in the fe-abms project, based on the patterns used in TaskInfo.tsx and DealInfo.tsx.

## Table of Contents
1. [Core Responsive Patterns](#core-responsive-patterns)
2. [Media Query Breakpoints](#media-query-breakpoints)
3. [Grid System Implementation](#grid-system-implementation)
4. [Layout Strategies](#layout-strategies)
5. [Component Responsiveness](#component-responsiveness)
6. [Best Practices](#best-practices)
7. [Common Patterns](#common-patterns)

## Core Responsive Patterns

### 1. Import Required Dependencies

```typescript
import { Stack, Grid, useMediaQuery } from '@mui/material';
```

### 2. Define Media Query Breakpoints

```typescript
const isSmallScreen = useMediaQuery('(max-width:1550px)');
const isMediumScreen = useMediaQuery('(max-width:1280px)');
```

**Breakpoint Guidelines:**
- `isSmallScreen`: ≤1550px - For fine-tuning layouts
- `isMediumScreen`: ≤1280px - For tablet and smaller desktop layouts
- Consider adding `isMobileScreen`: ≤768px for mobile-specific layouts

## Media Query Breakpoints

### Standard Breakpoints
```typescript
// Large desktop (default)
const isLargeScreen = useMediaQuery('(min-width:1551px)');

// Small desktop/tablet landscape
const isSmallScreen = useMediaQuery('(max-width:1550px)');

// Tablet portrait
const isMediumScreen = useMediaQuery('(max-width:1280px)');

// Mobile
const isMobileScreen = useMediaQuery('(max-width:768px)');
```

### Usage Pattern
```typescript
// Conditional rendering based on screen size
{!isMediumScreen && (
  <Grid item md={12} lg={3}>
    {/* Sidebar content for large screens */}
  </Grid>
)}

{isMediumScreen && (
  <ViewModuleSections
    title='Related record'
    containerProps={{ width: '98%', marginTop: '32px' }}
  >
    {/* Same content moved below for smaller screens */}
  </ViewModuleSections>
)}
```

## Grid System Implementation

### Basic Grid Structure
```typescript
<Grid container spacing={3}>
  <Grid item md={12} lg={9}>
    {/* Main content area */}
  </Grid>
  <Grid item md={12} lg={3}>
    {/* Sidebar content */}
  </Grid>
</Grid>
```

### Grid Breakpoint System
- `xs`: 0px and up (mobile)
- `sm`: 600px and up (tablet)
- `md`: 900px and up (small desktop)
- `lg`: 1200px and up (large desktop)
- `xl`: 1536px and up (extra large)

### Responsive Grid Examples

#### Two-Column Layout
```typescript
<Grid container spacing={3}>
  {/* Main content - 9 columns on large, full width on smaller */}
  <Grid item md={12} lg={9}>
    <ViewModuleSections
      title='Main Content'
      containerProps={{ width: '98%' }}
    >
      {/* Content */}
    </ViewModuleSections>
  </Grid>
  
  {/* Sidebar - 3 columns on large, hidden on smaller */}
  {!isMediumScreen && (
    <Grid item md={12} lg={3}>
      <ViewModuleSections
        title='Sidebar'
        containerProps={{ width: '91%' }}
      >
        {/* Sidebar content */}
      </ViewModuleSections>
    </Grid>
  )}
</Grid>
```

#### Responsive Form Layout
```typescript
<Grid container spacing={isSmallScreen ? 1.5 : 3}>
  <Grid item xs={12} md={isSmallScreen ? 12 : 6}>
    <Descriptions
      items={formSection1(data)}
      subHeader={'Section 1'}
    />
  </Grid>
  <Grid item xs={12} md={isSmallScreen ? 12 : 6}>
    <Descriptions
      items={formSection2(data)}
      $css={isSmallScreen ? '' : 'margin-top: 40px !important;'}
    />
  </Grid>
</Grid>
```

## Layout Strategies

### 1. Sidebar-to-Stack Pattern
**Large screens**: Sidebar alongside main content
**Small screens**: Sidebar content moves below main content

```typescript
// Large screen layout
<Grid container spacing={3}>
  <Grid item md={12} lg={9}>
    {/* Main content */}
  </Grid>
  {!isMediumScreen && (
    <Grid item md={12} lg={3}>
      {/* Sidebar */}
    </Grid>
  )}
</Grid>

// Small screen layout
{isMediumScreen && (
  <>
    <ViewModuleSections
      title='Related record'
      containerProps={{ width: '98%', marginTop: '32px' }}
    >
      {/* Sidebar content */}
    </ViewModuleSections>
  </>
)}
```

### 2. Responsive Container Widths
```typescript
// Large screens - sidebar has smaller width
containerProps={{ width: '91%' }}

// Small screens - full width
containerProps={{ width: '98%' }}

// Main content - consistent width
containerProps={{ width: '98%' }}
```

### 3. Conditional Spacing
```typescript
// Adjust spacing based on screen size
<Grid container spacing={isSmallScreen ? 1.5 : 3}>
  <Grid item xs={12} md={isSmallScreen ? 12 : 6}>
    <Descriptions
      items={section1(data)}
      $css={isSmallScreen ? '' : 'margin-top: 40px !important;'}
    />
  </Grid>
</Grid>
```

## Component Responsiveness

### ViewModuleSections Responsive Props
```typescript
// Large screens
<ViewModuleSections
  title='Section Title'
  containerProps={{ width: '98%' }}
>

// Small screens with adjusted margins
<ViewModuleSections
  title='Section Title'
  containerProps={{ 
    width: '98%', 
    marginTop: '32px' 
  }}
>
```

### Table Responsiveness
```typescript
<ModuleTable
  columns={columns}
  data={data}
  tableProps={{
    tableLayout: 'fixed',
    pagination: {
      position: ['bottom', 'left'],
      pageSize: pageSize,
      showTotal: (total, range) => (
        <RowsPerPage
          total={total}
          range={range}
          setPageSize={setPageSize}
          defaultPageSize={10}
        />
      ),
    },
  }}
/>
```

## Best Practices

### 1. Progressive Enhancement
- Start with mobile-first design
- Add complexity for larger screens
- Use conditional rendering for different screen sizes

### 2. Consistent Breakpoints
- Use the same breakpoints across the application
- Document breakpoint decisions
- Consider component-specific breakpoints when needed

### 3. Container Width Management
```typescript
// Large screens: Sidebar content
containerProps={{ width: '91%' }}

// Small screens: Full width content
containerProps={{ width: '98%' }}

// Main content: Consistent width
containerProps={{ width: '98%' }}
```

### 4. Spacing and Margins
```typescript
// Responsive spacing
<Grid container spacing={isSmallScreen ? 1.5 : 3}>

// Conditional margins
$css={isSmallScreen ? '' : 'margin-top: 40px !important;'}

// Responsive margins
containerProps={{ 
  width: '98%', 
  marginTop: isMediumScreen ? '32px' : '20px' 
}}
```

### 5. Content Prioritization
- Show most important content first on mobile
- Use sidebar for secondary information on desktop
- Consider content hierarchy in responsive layouts

## Common Patterns

### Pattern 1: Two-Column to Single-Column
```typescript
// Implementation
<Grid container spacing={3}>
  <Grid item md={12} lg={9}>
    {/* Main content */}
  </Grid>
  {!isMediumScreen && (
    <Grid item md={12} lg={3}>
      {/* Sidebar */}
    </Grid>
  )}
</Grid>

{isMediumScreen && (
  <ViewModuleSections
    title='Sidebar Content'
    containerProps={{ width: '98%', marginTop: '32px' }}
  >
    {/* Sidebar content moved below */}
  </ViewModuleSections>
)}
```

### Pattern 2: Responsive Form Layout
```typescript
<Grid container spacing={isSmallScreen ? 1.5 : 3}>
  <Grid item xs={12} md={isSmallScreen ? 12 : 6}>
    {/* Form section 1 */}
  </Grid>
  <Grid item xs={12} md={isSmallScreen ? 12 : 6}>
    {/* Form section 2 */}
  </Grid>
</Grid>
```

### Pattern 3: Conditional Component Rendering
```typescript
{!isMediumScreen && (
  <ComponentForLargeScreens />
)}

{isMediumScreen && (
  <ComponentForSmallScreens />
)}
```

## Implementation Checklist

When making a page responsive, ensure you:

1. ✅ Import required dependencies (`Grid`, `useMediaQuery`)
2. ✅ Define appropriate breakpoints
3. ✅ Replace fixed layouts with Grid system
4. ✅ Implement conditional rendering for different screen sizes
5. ✅ Adjust container widths for different screen sizes
6. ✅ Handle spacing and margins responsively
7. ✅ Test on different screen sizes
8. ✅ Consider content hierarchy and user experience
9. ✅ Maintain consistent styling across breakpoints
10. ✅ Document any component-specific responsive behavior

## Example: Converting a Fixed Layout to Responsive

### Before (Fixed Layout)
```typescript
<Stack direction='row' gap='80px'>
  <Stack width='70%'>
    {/* Main content */}
  </Stack>
  <Stack width='30%'>
    {/* Sidebar */}
  </Stack>
</Stack>
```

### After (Responsive Layout)
```typescript
<Grid container spacing={3}>
  <Grid item md={12} lg={9}>
    <ViewModuleSections
      title='Main Content'
      containerProps={{ width: '98%' }}
    >
      {/* Main content */}
    </ViewModuleSections>
  </Grid>
  {!isMediumScreen && (
    <Grid item md={12} lg={3}>
      <ViewModuleSections
        title='Sidebar'
        containerProps={{ width: '91%' }}
      >
        {/* Sidebar content */}
      </ViewModuleSections>
    </Grid>
  )}
</Grid>

{isMediumScreen && (
  <ViewModuleSections
    title='Sidebar'
    containerProps={{ width: '98%', marginTop: '32px' }}
  >
    {/* Sidebar content moved below */}
  </ViewModuleSections>
)}
```

This guide provides a comprehensive reference for implementing responsive design patterns in the fe-abms project, ensuring consistency and maintainability across all components. 