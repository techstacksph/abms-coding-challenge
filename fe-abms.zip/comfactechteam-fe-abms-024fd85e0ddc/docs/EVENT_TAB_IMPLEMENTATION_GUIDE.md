# Event Tab Implementation Guide

This guide explains how to create an event tab for any module in the fe-abms application, using the accounts events tab as a reference implementation.

## Overview

The event tab implementation consists of several key components:
- **Main Tab Component**: Displays the events data table
- **Form Components**: Handle creating, editing, and viewing events
- **Generic Reusable Components**: Shared event functionality
- **Router Configuration**: Routes for CRUD operations
- **Lazy Loading**: Components are lazy-loaded for performance

## Directory Structure

For a module named `[MODULE]`, create the following structure:

```
src/views/[MODULE]/[MODULE]/view/tabs/Events/
├── index.tsx          # Main events tab component
├── new.tsx           # New event component
├── edit.tsx          # Edit event component
└── view.tsx          # View event component
```

## Implementation Steps

### 1. Create the Main Events Tab Component

Create `src/views/[MODULE]/[MODULE]/view/tabs/Events/index.tsx`:

```typescript
import React from 'react';
import { useParams } from '@/utils/navigation.utils';

import { EventsDataTable } from '@/components/GenericTab/events';
import useNavigate from '@/hooks/useNavigate';
import EventModel from '@/models/EventModel';
import { SearchComparator } from '@/typings/module.types';

const [MODULE]EventsTab = (props: {
  tab?: string;
  setTab?: (val: string) => void;
}) => {
  const { id } = useParams();
  const { navigate } = useNavigate('List');

  // Custom navigation handlers to stay within [MODULE] context
  const handleNewEvent = () => {
    navigate(`/[MODULE_ROUTE]/${id}/events/new?relatedToId=${id}`);
  };

  const handleEditEvent = (event: EventModel) => {
    navigate(`/[MODULE_ROUTE]/${id}/events/${event.id}/edit?relatedToId=${id}`);
  };

  const handleViewEvent = (event: EventModel) => {
    navigate(`/[MODULE_ROUTE]/${id}/events/${event.id}`);
  };

  // Search arguments for filtering events by [MODULE]
  const searchArg = [
    {
      fieldName: '[MODULE_FIELD].id', // e.g., 'account.id', 'contact.id'
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <EventsDataTable
      id={id}
      module='[MODULE_CODE]' // e.g., 'accounts', 'contacts'
      tab={props.tab}
      setTab={props.setTab}
      searchArg={searchArg}
      onNewEvent={handleNewEvent}
      onEditEvent={handleEditEvent}
      onViewEvent={handleViewEvent}
      viewRoute={`/[MODULE_ROUTE]/${id}/events/eventId`}
    />
  );
};

export default [MODULE]EventsTab;
```

### 2. Create the New Event Component

Create `src/views/[MODULE]/[MODULE]/view/tabs/Events/new.tsx`:

```typescript
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { EventForm } from '@/components/GenericTab/events';
import useGlobalOptions from '@/hooks/useGlobalOptions';
import useNavigate from '@/hooks/useNavigate';

const [MODULE]EventNew = () => {
  const { id } = useParams();
  const { navigate } = useNavigate();
  const { modules } = useGlobalOptions({
    modules: true,
  });

  // Find the [MODULE] module to get the correct moduleId
  const [MODULE_LOWER]Module = modules.find(m => m.code === '[MODULE_CODE]');

  const breadCrumbs = ['[MODULE_DISPLAY]', '[MODULE_SINGULAR]', 'Events', 'New Event'];

  return (
    <EventForm
      mode='new'
      breadCrumbs={breadCrumbs}
      relatedTo={{
        module: '[MODULE_CODE]',
        moduleId: [MODULE_LOWER]Module?.id,
      }}
      redirect={eventId => navigate(`/[MODULE_ROUTE]/${id}/events/${eventId}`)}
      [MODULE_LOWER]Id={id}
    />
  );
};

export default [MODULE]EventNew;
```

### 3. Create the Edit Event Component

Create `src/views/[MODULE]/[MODULE]/view/tabs/Events/edit.tsx`:

```typescript
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { EventForm } from '@/components/GenericTab/events';
import useGlobalOptions from '@/hooks/useGlobalOptions';
import useNavigate from '@/hooks/useNavigate';

const [MODULE]EventEdit = () => {
  const { id, eventId } = useParams();
  const { navigate } = useNavigate();
  const { modules } = useGlobalOptions({
    modules: true,
  });

  // Find the [MODULE] module to get the correct moduleId
  const [MODULE_LOWER]Module = modules.find(m => m.code === '[MODULE_CODE]');

  const breadCrumbs = ['[MODULE_DISPLAY]', '[MODULE_SINGULAR]', 'Events', 'Edit Event'];

  return (
    <EventForm
      mode='edit'
      breadCrumbs={breadCrumbs}
      id={eventId}
      relatedTo={{
        module: '[MODULE_CODE]',
        moduleId: [MODULE_LOWER]Module?.id,
      }}
      redirect={updatedEventId =>
        navigate(`/[MODULE_ROUTE]/${id}/events/${updatedEventId || eventId}`)
      }
      [MODULE_LOWER]Id={id}
    />
  );
};

export default [MODULE]EventEdit;
```

### 4. Create the View Event Component

Create `src/views/[MODULE]/[MODULE]/view/tabs/Events/view.tsx`:

```typescript
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import EventView from '@/views/calendar/events/view';

const [MODULE]EventView = () => {
  const { eventId, id } = useParams();

  const breadCrumbs = [
    { title: '[MODULE_DISPLAY]' },
    { title: '[MODULE_SINGULAR]' },
    { title: 'Events' },
    { title: 'View Event' },
  ];

  return (
    <EventView
      id={eventId}
      breadCrumbs={breadCrumbs}
      redirectBack={`/[MODULE_ROUTE]/${id}?tab=events`}
    />
  );
};

export default [MODULE]EventView;
```

### 5. Add Components to Lazy Loading

Add to `src/views/[MODULE]/lazyComponents.tsx`:

```typescript
// [MODULE]-specific Event components
export const [MODULE]EventNew = lazy(
  () => import('./[MODULE]/view/tabs/Events/new.tsx')
);
export const [MODULE]EventEdit = lazy(
  () => import('./[MODULE]/view/tabs/Events/edit.tsx')
);
export const [MODULE]EventView = lazy(
  () => import('./[MODULE]/view/tabs/Events/view.tsx')
);
```

### 6. Import Components in Module Index

Add to `src/views/[MODULE]/index.tsx` imports:

```typescript
import {
  // ... other imports
  [MODULE]EventNew,
  [MODULE]EventEdit,
  [MODULE]EventView,
} from './lazyComponents';
```

### 7. Configure Routes

Add routes to your module's router configuration in `src/views/[MODULE]/index.tsx`:

```typescript
{/* [MODULE]-specific Event Routes */}
<Route
  path='/:id/events/new'
  element={
    <RouteWithErrorBoundary
      moduleName='New [MODULE] Event'
      modulePath='/[MODULE_ROUTE]'
    >
      <LazyLoader>
        <[MODULE]EventNew {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
<Route
  path='/:id/events/:eventId/edit'
  element={
    <RouteWithErrorBoundary
      moduleName='Edit [MODULE] Event'
      modulePath='/[MODULE_ROUTE]'
    >
      <LazyLoader>
        <[MODULE]EventEdit {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
<Route
  path='/:id/events/:eventId'
  element={
    <RouteWithErrorBoundary
      moduleName='[MODULE] Event Details'
      modulePath='/[MODULE_ROUTE]'
    >
      <LazyLoader>
        <[MODULE]EventView {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
```

### 8. Add Tab to Module View

In your module's view component (`src/views/[MODULE]/[MODULE]/view/index.tsx`), add the events tab:

```typescript
import Event[MODULE]List from './tabs/Events';

// In the tabs configuration:
{
  key: 'events',
  label: 'Events',
  children: (
    <Event[MODULE]List 
      tab={tab} 
      setTab={setTab} 
    />
  ),
}
```

### 9. Update Constants File

Add your module to `src/components/GenericTab/events/constant.tsx`:

```typescript
export const relatedToModuleMap = {
  account: 'accountId',
  contact: 'contactId',
  site: 'siteId',
  employee: 'employeeId',
  user: 'userId',
  task: 'taskId',
  [MODULE_CODE]: '[MODULE_LOWER]Id', // Add your module here
};
```

## Configuration Parameters

Replace the following placeholders with your module-specific values:

| Placeholder | Description | Example (Accounts) |
|-------------|-------------|-------------------|
| `[MODULE]` | PascalCase module name | `Account` |
| `[MODULE_LOWER]` | camelCase module name | `account` |
| `[MODULE_CODE]` | Module code | `account` |
| `[MODULE_DISPLAY]` | Display name (plural) | `Accounts` |
| `[MODULE_SINGULAR]` | Display name (singular) | `Account` |
| `[MODULE_ROUTE]` | URL route path | `accounts` |
| `[MODULE_FIELD]` | GraphQL field name | `account` |

## Key Features Provided

### EventsDataTable Component
- **Data Display**: Shows events in a sortable, filterable table
- **Actions**: View, Edit, Delete actions for each event
- **Bulk Operations**: Select multiple events for bulk delete/export
- **Export**: CSV export functionality
- **Search**: Real-time search across event fields
- **Filtering**: Advanced filtering by date, assignee, etc.
- **Pagination**: Built-in pagination support

### EventForm Component
- **Dual Mode**: Handles both 'new' and 'edit' modes
- **Related Records**: Automatically links events to parent records
- **Validation**: Built-in form validation
- **Rich Editor**: Rich text editing for event descriptions
- **Date/Time**: Advanced date and time picker
- **Assignee Calendar**: Calendar view for assignee availability

### EventView Component
- **Full Details**: Complete event information display
- **Navigation**: Breadcrumb navigation
- **Actions**: Edit and delete capabilities
- **Related Data**: Shows linked records and relationships

## Backend Requirements

Ensure your module model has event relationship support:

1. **Database Model**: Include event relationships in your entity model
2. **GraphQL Schema**: Support event queries filtered by your module
3. **Permissions**: Ensure proper permissions for event CRUD operations

## Testing Checklist

- [ ] Events tab displays correctly in module view
- [ ] Can create new events linked to module record
- [ ] Can edit existing events
- [ ] Can view event details
- [ ] Can delete events (single and bulk)
- [ ] Search and filtering work correctly
- [ ] Export functionality works
- [ ] Navigation between event views works
- [ ] Breadcrumbs display correctly
- [ ] Related record linking works properly

## Common Issues and Solutions

### 1. Module Not Found Error
**Problem**: "Module not found" when accessing events
**Solution**: Ensure the module code matches exactly in `useGlobalOptions` and `relatedToModuleMap`

### 2. Navigation Issues
**Problem**: Events routes not working
**Solution**: Verify route configuration matches the expected pattern and all components are properly imported

### 3. Related Record Not Linking
**Problem**: Events not linking to parent module record
**Solution**: Check `searchArg` field name matches your GraphQL schema and ensure `relatedToModuleMap` is updated

### 4. Permission Errors
**Problem**: Users can't access event functionality
**Solution**: Verify backend permissions include event operations for the module

## Best Practices

1. **Consistent Naming**: Use consistent naming conventions across all components
2. **Error Handling**: Implement proper error boundaries and loading states
3. **Type Safety**: Use TypeScript interfaces for props and models
4. **Performance**: Leverage lazy loading and memoization where appropriate
5. **Accessibility**: Ensure components are accessible with proper ARIA labels
6. **Testing**: Write unit tests for custom navigation and filtering logic

## Example Implementation: Contacts Events Tab

Here's a complete example for implementing events on a contacts module:

```typescript
// src/views/contacts/contacts/view/tabs/Events/index.tsx
const ContactEventsTab = (props: { tab?: string; setTab?: (val: string) => void; }) => {
  // ... (implementation following the pattern above)
  const searchArg = [
    {
      fieldName: 'contact.id',
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <EventsDataTable
      id={id}
      module='contacts'
      searchArg={searchArg}
      viewRoute={`/contacts/${id}/events/eventId`}
      // ... other props
    />
  );
};
```

This implementation ensures consistency across all modules while providing flexibility for module-specific requirements. 