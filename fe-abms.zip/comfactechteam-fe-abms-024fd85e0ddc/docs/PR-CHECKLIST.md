# PR Checklist

## Core Quality Gates
- [ ] Lint passes: `yarn lint:check`
- [ ] Types pass: `yarn type-check`
- [ ] No unused imports/vars (auto-fix: `yarn lint:unused`)
- [ ] Unit/smoke tests updated if behavior changed
- [ ] Docs updated (if user-facing behavior or conventions changed)

## Date Formatting (UI vs API)
- [ ] UI displays use `dateFormat` or `dateTimeFormat` from `@/utils/date.utils`
- [ ] No UI renders using `'YYYY-MM-DD'` or `dateFormatY`
- [ ] API/payloads/filters use `dateFormatY` only when composing backend params or ISO strings
- [ ] No hardcoded format strings in UI (e.g., `'DD/MM/YYYY'`), import from `@/utils/date.utils`

## Inputs and Components
- [ ] Date inputs import from `@/styled-components` (`DatePicker`, `DateRangePicker`), not `antd`
- [ ] Do not pass `format` unless the UI requires a format different from the default
- [ ] For date range filters: display remains `dateFormat`; convert to `dateFormatY` when building query params

## Tables and Views
- [ ] Table columns and view pages render dates with `dateFormat` or `dateTimeFormat`
- [ ] No user-facing table/view date is shown as `YYYY-MM-DD`

## Helpers and Utilities
- [ ] New date helpers live in `@/utils/date.utils`
- [ ] Prefer helpers for display/transform over inline `dayjs(...).format(...)` in many places
- [ ] Use `formatToNZTime` when showing times that must be NZ TZ aware

## Regression Safety
- [ ] Added/updated tests or performed manual checks covering at least one view and one table with dates
- [ ] Verified filters send `dateFormatY` to backend while keeping UI as `dateFormat`

## Documentation Links
- [ ] Read `docs/DATE-FORMAT-ASSESSMENT.md` for rationale and current implementation
