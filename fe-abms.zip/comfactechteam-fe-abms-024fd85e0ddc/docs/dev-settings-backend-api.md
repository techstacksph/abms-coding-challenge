# Dev Settings Backend API Requirements

## Overview

The secret dev settings page requires backend API endpoints in `msvc-authorization` to read and write security level configurations directly in the database.

## Required Endpoints

### 1. Get Security Level by Name

**Endpoint**: `GET /v1/security-levels/by-name/:levelName`

**Parameters**:
- `levelName`: 'Low' | 'Medium' | 'High'

**Response**:
```json
{
  "name": "Low",
  "configuration": {
    "authentication": {
      "session": {
        "inactivityInMin": 240,
        "loginSession": 7200
      },
      "login": {
        "maxFailedLogin": 0,
        "userLockTimeInMins": 0
      },
      "password": {
        "minPasswordLength": 6,
        "requireNumber": false,
        "requireSpecialCharacter": false,
        "requireLowercaseCharacter": true,
        "requireUppercaseCharacter": true,
        "allowSequentialCharacters": true,
        "allowSamePassword": false
      }
    },
    "record": {
      "recordLockTimeInMins": 120
    }
  }
}
```

### 2. Update Security Level Configuration

**Endpoint**: `PATCH /v1/security-levels/:id/configuration`

**Parameters**:
- `id`: Security level UUID

**Body**:
```json
{
  "configuration": {
    // SecurityLevelConfigurationDto
  }
}
```

**Response**:
```json
{
  "id": "uuid",
  "name": "Low",
  "configuration": { /* updated config */ },
  "updatedAt": "2025-10-24T12:00:00Z"
}
```

### 3. Get All Security Levels (Existing)

**Endpoint**: `GET /v1/security-levels`

**Response**:
```json
[
  {
    "name": "Low",
    "configuration": { /* ... */ }
  },
  {
    "name": "Medium",
    "configuration": { /* ... */ }
  },
  {
    "name": "High",
    "configuration": { /* ... */ }
  }
]
```

## Implementation Details

### Database Approach
- Security levels are stored in the `securityLevels` table in PostgreSQL
- The `configuration` column is a JSONB type storing SecurityLevelConfigurationDto
- No file manipulation needed - direct database updates

### Required Endpoints

**1. GET /v1/security-levels/by-name/:levelName** (NEW)
- Query security levels table WHERE name = :levelName
- Return the security level entity with configuration

**2. PATCH /v1/security-levels/:id/configuration** (NEW)
- Update the configuration column for the specified security level
- Validate configuration against SecurityLevelConfigurationDto schema
- Return updated security level entity

**3. GET /v1/security-levels** (EXISTING)
- May already exist - returns all security levels
- If not, add query to return all security levels with configurations

### Security Considerations
- **Authentication**: Require valid JWT token
- **Authorization**: Admin/Super Admin only (role-based)
- **Validation**: Validate configuration schema before saving
- **Audit logging**: Log who changed what and when
- **Environment gating**: Consider restricting to DEV/SANDBOX via environment check

### Example TypeScript Service (NestJS)

```typescript
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SecurityLevelModel } from '../datasource/models/SecurityLevelModel';
import { SecurityLevelConfigurationDto } from '../dto/SecurityLevelDto';

@Injectable()
export class SecurityLevelService {
  constructor(
    @InjectRepository(SecurityLevelModel)
    private securityLevelRepository: Repository<SecurityLevelModel>,
  ) {}

  async findByName(name: string): Promise<SecurityLevelModel> {
    const level = await this.securityLevelRepository.findOne({ where: { name } });
    if (!level) {
      throw new NotFoundException(`Security level '${name}' not found`);
    }
    return level;
  }

  async updateConfiguration(
    id: string,
    configuration: SecurityLevelConfigurationDto,
  ): Promise<SecurityLevelModel> {
    const level = await this.securityLevelRepository.findOne({ where: { id } });
    if (!level) {
      throw new NotFoundException(`Security level with ID '${id}' not found`);
    }

    // Update configuration
    level.configuration = configuration;
    return await this.securityLevelRepository.save(level);
  }

  async findAll(): Promise<SecurityLevelModel[]> {
    return await this.securityLevelRepository.find();
  }
}
```

### Example Controller

```typescript
import { Controller, Get, Patch, Body, Param } from '@nestjs/common';
import { SecurityLevelService } from '../services/SecurityLevelService';
import { SecurityLevelConfigurationDto } from '../dto/SecurityLevelDto';

@Controller('security-levels')
export class SecurityLevelController {
  constructor(private readonly securityLevelService: SecurityLevelService) {}

  @Get('by-name/:name')
  async getByName(@Param('name') name: string) {
    return await this.securityLevelService.findByName(name);
  }

  @Patch(':id/configuration')
  async updateConfiguration(
    @Param('id') id: string,
    @Body('configuration') configuration: SecurityLevelConfigurationDto,
  ) {
    return await this.securityLevelService.updateConfiguration(id, configuration);
  }

  @Get()
  async getAll() {
    return await this.securityLevelService.findAll();
  }
}
```

## Frontend Usage

Once the backend endpoints are implemented, the frontend will automatically work as designed. The UI provides:

- Live editing of security level configurations
- Direct file modification warnings
- Post-save instructions for database reset
- Apollo cache invalidation

## Testing

1. **Unit tests**: Test file parsing and writing
2. **Integration tests**: Test endpoint responses
3. **E2E tests**: Test full flow from frontend UI to file write

## Rollout Plan

1. Implement backend endpoints in `msvc-authorization`
2. Add environment gating (DEV/SANDBOX only)
3. Test locally
4. Deploy to DEV environment
5. Document in team wiki
6. Train team on usage

## Security Notes

⚠️ **This is a powerful developer tool** - it directly modifies source code files. Use with caution and only in non-production environments.
