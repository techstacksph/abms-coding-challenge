# AltModuleTable to DataTable Migration Guide

## Overview

This document outlines the process of migrating from `AltModuleTable` to `DataTable` components in the fe-abms project. The migration provides better performance, consistency, and additional features like advanced loading states and filter management.

## Example: Deals List Migration

The deals list (`src/views/sales/deals/list/index.tsx`) was successfully migrated from `AltModuleTable` to `DataTable` using the jobs list as a reference implementation.

## Migration Steps

### 1. Update Imports

**Before:**

```typescript
import AltModuleTable from '@/components/AltModuleTable';
```

**After:**

```typescript
import DataTable from '@/components/DataTable';
```

### 2. Add Required State Variables

Add the following state variables for proper DataTable functionality:

```typescript
const [forceLoadAllData] = useState(false);
const [, setIsDataLoading] = useState(false);
```

### 3. Update Global Options Hook

Ensure you're getting loading states from your global options:

```typescript
const {
  locations: dbLocations,
  users: dbUsers,
  dealTypes: dbEventType,
  workflowStatuses: dbStatus,
  locationsLoading,        // Add these loading states
  usersLoading,
  dealTypesLoading,
  workflowStatusesLoading,
} = useGlobalOptions({
  locations: true,
  users: true,
  dealTypes: true,
  workflowStatuses: true,
  workflowStatusCode: 'deal',
});
```

### 4. Create Loading State Management

Add a comprehensive loading state check after all mutation hooks are declared:

```typescript
const isLoading = [
  locationsLoading,
  usersLoading,
  dealTypesLoading,
  workflowStatusesLoading,
  deleteLoading,
  updateStatusLoading,
].includes(true);
```

### 5. Update Table Component Configuration

**Before (AltModuleTable):**

```typescript
<AltModuleTable
  columns={taskListColumns}
  onChangeSelected={selected =>
    setSelected({ selected, type: 'multiple' })
  }
  actions={tableActions}
  paginationText={''}
  showTotal={false}
  paginatedQuery={OPTIMIZED_PAGINATED_DEALS}
  allQuery={ALL_DEALS}
  setAllQueryData={setAllQueryData}
  searchFields={searchArgs}
  refetch={{ refetch, setRefetch }}
  sortArg={sortArg}
  page={page}
  setPage={setPage}
  otherTableProps={{ scroll: { x: true } }}
  onTableChange={(pagination, filters, sorter, extra) => {
    // ... table change logic
  }}
/>
```

**After (DataTable):**

```typescript
<DataTable
  skipQueries={isLoading && searchArgs?.length == 0}
  filterLoading={isLoading && searchArgs?.length == 0}
  waitForFilters={true}
  hasRowSelections={true}
  columns={taskListColumns}
  forceLoadAllData={forceLoadAllData}
  allQuery={ALL_DEALS}
  paginatedQuery={OPTIMIZED_PAGINATED_DEALS}
  refetch={{ refetch, setRefetch }}
  searchFields={searchArgs}
  nameField='dealNo'
  onChangeSelected={selected => {
    setSelected({ selected, type: 'multiple' });
  }}
  setIsDataLoading={setIsDataLoading}
  loader={isLoading}
  setAllQueryData={setAllQueryData}
  module={'deals'}
  otherTableProps={{ scroll: { x: true } }}
  sortArg={sortArg}
  page={page}
  setPage={setPage}
  onTableChange={(pagination, filters, sorter, extra) => {
    // ... same table change logic
  }}
  actions={tableActions}
/>
```

### 6. Migrate Export Functionality

The export functionality needs to be updated from the old `exportData` prop to the new `onCustomExport` approach for better performance and user feedback.

**Before (Legacy Export):**

```typescript
import { mapArrToCSVFields, sortCSVData } from '@/utils/array.utils';

// In ModuleActions
<ModuleActions
  exportData={mapArrToCSVFields(allQueryFilteredData, exportFields)}
  // ... other props
/>
```

**After (Modern Export with Custom Handler):**

First, add required imports and state:

```typescript
import {
  mapArrToCSVFields,
  sortCSVData,
  convertToCSVBase64,
} from '@/utils/array.utils';
import { saveCSVFile } from '@/services/export.services';
import { useSnackbar } from '@/styled-components';

// Add export-related state
const [forceLoadAllData, setForceLoadAllData] = useState(false);
const [isDataLoading, setIsDataLoading] = useState(false);
const [isExporting, setIsExporting] = useState(false);
const { snackbar } = useSnackbar();
```

Note: The `convertToCSVBase64` function is now available as a generic utility in `@/utils/array.utils` and no longer needs to be defined locally in each component.

Add the export useEffect handler:

```typescript
// Reset forceLoadAllData when allQueryData is loaded and trigger export
useEffect(() => {
  if (
    forceLoadAllData &&
    !isDataLoading &&
    allQueryData &&
    allQueryData.length > 0
  ) {
    try {
      setIsExporting(true);
      const csvData = mapArrToCSVFields(
        sortCSVData(allQueryData, sortArg),
        exportFields
      );
      const base64CSV = convertToCSVBase64(csvData);
      saveCSVFile(base64CSV, MODULE_NAME);
      snackbar({ type: 'success', message: 'Data exported successfully!' });
    } catch (error) {
      console.error('Export error:', error);
      snackbar({ type: 'error', message: 'Failed to export data.' });
    } finally {
      setIsExporting(false);
      setForceLoadAllData(false);
    }
  }
}, [forceLoadAllData, allQueryData, isDataLoading, sortArg, snackbar]);
```

Update ModuleActions with the new export approach:

```typescript
<ModuleActions
  isExporting={isExporting}
  onCustomExport={async () => {
    try {
      if (allQueryData && allQueryData.length > 0) {
        // Data is already available, export immediately
        const csvData = mapArrToCSVFields(
          allQueryFilteredData,
          exportFields
        );
        const base64CSV = convertToCSVBase64(csvData);
        saveCSVFile(base64CSV, MODULE_NAME);
        snackbar({
          type: 'success',
          message: 'Data exported successfully!',
        });
        return csvData; // Return the processed data for compatibility
      } else {
        // Force load all data for export
        snackbar({
          type: 'info',
          message: 'Loading data for export...',
        });
        setForceLoadAllData(true);
        return []; // Return empty array while loading
      }
    } catch (error) {
      console.error('Export error:', error);
      snackbar({
        type: 'error',
        message: 'Failed to export data.',
      });
      return [];
    }
  }}
  onNoExport={() =>
    snackbar({ type: 'error', message: 'No rows available.' })
  }
  // ... other props (remove exportData prop)
/>
```

Ensure DataTable is configured with `forceLoadAllData`:

```typescript
<DataTable
  forceLoadAllData={forceLoadAllData}
  setIsDataLoading={setIsDataLoading}
  setAllQueryData={setAllQueryData}
  // ... other props
/>
```

### 7. Fix Filter Type Issues

If you encounter type compatibility issues with ModuleActions filters, use type casting:

```typescript
<ModuleActions
  filters={dbFilters as any}
  // ... other props
/>
```

## Key Differences Between AltModuleTable and DataTable

### New Required Props

| Prop | Description | Example Value |
|------|-------------|---------------|
| `skipQueries` | Skip queries when loading | `isLoading && searchArgs?.length == 0` |
| `filterLoading` | Show loading when filters are being processed | `isLoading && searchArgs?.length == 0` |
| `waitForFilters` | Wait for filters before loading data | `true` |
| `hasRowSelections` | Enable row selection functionality | `true` |
| `nameField` | Field name used for row identification | `'dealNo'` |
| `setIsDataLoading` | Callback to set data loading state | `setIsDataLoading` |
| `loader` | Overall loading state | `isLoading` |
| `module` | Module name for context | `'deals'` |

### Removed Props

| Prop | Reason |
|------|--------|
| `paginationText` | Not needed in DataTable |
| `showTotal` | Handled internally |

### Reordered Props

DataTable expects props in a specific order. Key positioning:

- Query-related props (`allQuery`, `paginatedQuery`) early
- Data handling props (`searchFields`, `refetch`) in middle
- UI props (`sortArg`, `page`, `setPage`) near end
- `actions` should be last

## Benefits of Migration

1. **Better Performance**: DataTable provides optimized rendering and data handling
2. **Consistent Loading States**: Unified loading state management across components
3. **Enhanced Filtering**: Better filter processing and waiting mechanisms
4. **Row Selection**: More robust row selection functionality
5. **Advanced Export**: Modern export functionality with user feedback and progress indicators
6. **Future-Proof**: DataTable is the standard component for new features

## Common Issues and Solutions

### 1. Type Compatibility with Filters

**Issue**: TypeScript errors with filter types
**Solution**: Use type casting `as any` for legacy filter implementations

### 2. Loading State Order

**Issue**: "Variable used before declaration" errors
**Solution**: Ensure `isLoading` is declared after all mutation hooks

### 3. Missing Loading States

**Issue**: Component doesn't show loading properly
**Solution**: Include all relevant loading states in the `isLoading` array

### 4. Export Functionality Not Working

**Issue**: Export button doesn't work or shows errors
**Solution**:

- Ensure `saveCSVFile` is imported from `@/services/export.services`
- Add `useSnackbar` hook for user feedback
- Include `forceLoadAllData` state and `setIsDataLoading` callback
- Add the `convertToCSVBase64` helper function
- Remove old `exportData` prop from ModuleActions

## Migration Checklist

- [ ] Update import from AltModuleTable to DataTable
- [ ] Add required state variables (`forceLoadAllData`, `setIsDataLoading`, `isExporting`)
- [ ] Update global options to include loading states
- [ ] Create comprehensive `isLoading` state after all hooks
- [ ] Update table component with new prop structure
- [ ] Migrate export functionality to `onCustomExport` approach
- [ ] Add `useSnackbar` hook and `saveCSVFile` import for export
- [ ] Import `convertToCSVBase64` from `@/utils/array.utils` (remove any local definitions)
- [ ] Add export useEffect handler
- [ ] Remove old `exportData` prop from ModuleActions
- [ ] Fix any filter type compatibility issues
- [ ] Test row selection functionality
- [ ] Test loading states
- [ ] Test sorting and pagination
- [ ] Test search functionality
- [ ] Test export functionality with user feedback

## Reference Implementation

The jobs list (`src/views/jobs/jobs/list/index.tsx`) serves as the reference implementation for DataTable usage. When migrating other components, use this as the canonical example for proper DataTable configuration.

## Next Steps

After completing a migration:

1. Test all table functionality thoroughly
2. Verify loading states work correctly
3. Ensure row selection operates as expected
4. Test export functionality with both immediate and force-load scenarios
5. Verify export user feedback (loading messages, success/error notifications)
6. Update any related documentation
7. Consider removing any unused AltModuleTable imports from the project
