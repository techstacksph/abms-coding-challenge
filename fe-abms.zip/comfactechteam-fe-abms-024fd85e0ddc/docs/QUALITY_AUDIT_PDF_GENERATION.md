# Quality Audit PDF Auto-Generation Implementation

## Overview

This document describes the automatic PDF generation and updating feature for Quality Audits. Every time a Quality Audit is created or updated, a PDF document is automatically generated and stored in the Documents section.

## Features Implemented

### 1. Automatic PDF Generation
- ✅ PDF is automatically generated when a new Quality Audit is created
- ✅ PDF is automatically updated when an existing Quality Audit is modified
- ✅ PDF is stored as a Document linked to the Quality Audit
- ✅ Version overwriting ensures only the latest PDF is available

### 2. PDF Content
The generated PDF includes:
- **Audit Information**: QA No, Status, Audit Month, Rectification Date, QA Score, Record Owner, Location
- **Job Information**: Job No, Site Name, Address, Account, Contact
- **Customer Meeting Details**: Meeting status, who was met, or reason for not meeting
- **Job Specifications & Assessment**: All areas and specifications with their assessments and notes
- **Notes**: Customer notes and Franchisee notes
- **Professional Layout**: AYR branding with logo and styled formatting

### 3. PDF View and Download
- ✅ View PDF button in the Quality Audit view page (top section)
- ✅ Download PDF button to save locally
- ✅ PDFs open in a new browser tab for easy viewing

## File Structure

### New Files Created

```
src/
├── components/
│   └── PDF/
│       └── QualityAuditPDF.tsx              # PDF template component
├── services/
│   └── qualityAuditPdf.services.ts          # PDF generation services
└── docs/
    └── QUALITY_AUDIT_PDF_GENERATION.md      # This documentation
```

### Modified Files

```
src/
├── graphql/
│   └── qualityAudit.gql.ts                  # Added documents field to query
└── views/
    └── customer-service/
        └── quality-audit/
            ├── common/
            │   └── components/
            │       └── QualityAuditFormProvider.tsx  # Added PDF generation logic
            └── view/
                └── tabs/
                    └── sections/
                        └── QualityAuditTopSection.tsx  # Added PDF view/download buttons
```

## Technical Implementation

### 1. PDF Component (`QualityAuditPDF.tsx`)

Uses `@react-pdf/renderer` to create a professional PDF layout:

```typescript
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';
import QualityAuditModel from '@/models/QualityAuditModel';

const QualityAuditPDF: React.FC<QualityAuditPDFProps> = ({ data }) => {
  return (
    <Document>
      <Page size='A4' style={styles.page}>
        {/* Header, sections, and content */}
      </Page>
    </Document>
  );
};
```

### 2. PDF Service (`qualityAuditPdf.services.ts`)

Provides utility functions for PDF generation:

- `generateQualityAuditPDF()`: Generates PDF and returns as File object
- `previewQualityAuditPDF()`: Opens PDF in new window
- `downloadQualityAuditPDF()`: Triggers PDF download
- `prepareQualityAuditPDFForUpload()`: Prepares PDF with base64 encoding for document creation
- `fileToBase64()`: Converts File to base64 with metadata

### 3. Form Provider Integration

#### On Create (New Quality Audit)
```typescript
const onFinish = async values => {
  // ... create quality audit ...
  
  // Auto-generate PDF after creating quality audit
  const pdfDocumentType = documentTypesNew?.find(
    dt => dt.name?.toLowerCase().includes('pdf')
  );
  
  if (pdfDocumentType && qualityAuditId) {
    const pdfData = await prepareQualityAuditPDFForUpload(
      newQualityAuditData,
      pdfDocumentType.id
    );
    
    await createDocumentNew({
      variables: { document: pdfData.documentInput }
    });
  }
};
```

#### On Update (Edit Quality Audit)
```typescript
const onFinish = async values => {
  // ... update quality audit ...
  
  // Auto-generate/update PDF
  const existingPDF = existingDocuments?.find(
    doc => doc.documentTypeId === pdfDocumentType.id &&
           doc.documentName?.includes('Quality Audit -')
  );
  
  if (existingPDF) {
    // Update existing PDF document
    await updateDocument({ ... });
  } else {
    // Create new PDF document
    await createDocument({ ... });
  }
};
```

### 4. View Page Integration

The `QualityAuditTopSection` component now includes:

```typescript
// Query for PDF documents
const { data: documents } = useQuery<Array<any>>({
  query: ALL_DOCUMENTS,
  options: {
    variables: {
      searchArg: [{
        fieldName: 'qualityAuditId',
        comparator: SearchComparator.EQUAL,
        searchValue: data?.id,
      }],
    },
  },
});

// Find PDF document
const pdfDocument = documents?.find(
  doc => doc.documentName?.includes('Quality Audit -')
);

// Render View and Download buttons
{pdfDocument && (
  <Stack direction='row' spacing={0.5}>
    <Button onClick={handleViewPDF}>View</Button>
    <Button onClick={handleDownloadPDF}>Download</Button>
  </Stack>
)}
```

## User Flow

### Creating a New Quality Audit

1. User fills out the Quality Audit form
2. User clicks "Save"
3. **System automatically:**
   - Creates the Quality Audit record
   - Generates a PDF with all Quality Audit data
   - Creates a Document record linked to the Quality Audit
   - Stores the PDF as base64 in the document's `file1` field
4. User is redirected to the Quality Audit view page
5. PDF is immediately available via View/Download buttons

### Updating an Existing Quality Audit

1. User edits the Quality Audit form
2. User clicks "Save"
3. **System automatically:**
   - Updates the Quality Audit record
   - Regenerates the PDF with updated data
   - Updates the existing PDF document (version overwrite)
4. User remains on or is redirected to the view page
5. Latest PDF is immediately available

### Viewing/Downloading the PDF

1. User navigates to Quality Audit view page
2. In the top section, next to status and other info, PDF buttons appear
3. **To view**: Click "View" → PDF opens in new browser tab
4. **To download**: Click "Download" → PDF is saved to user's downloads folder

## Data Mapping

### Quality Audit → PDF Mapping

| Quality Audit Field | PDF Section | PDF Field |
|---------------------|-------------|-----------|
| qaNo | Audit Information | Quality Audit No |
| status.name | Audit Information | Status (with color coding) |
| auditMonth | Audit Information | Audit Month |
| rectificationDate | Audit Information | Rectification Date |
| qaScore | Audit Information | QA Score |
| recordOwner.fullName | Audit Information | Record Owner |
| location.name | Audit Information | Location |
| job.jobNo | Job Information | Job No |
| job.site.siteName | Job Information | Site |
| job.site.fullAddress | Job Information | Address |
| job.account.name | Job Information | Account |
| job.contact.fullName | Job Information | Contact |
| meetWithCustomer | Customer Meeting | Meet with Customer |
| whoDidYouMeet | Customer Meeting | Who did you meet |
| reasonForNotMeeting | Customer Meeting | Reason for not meeting |
| qaAreas | Job Specifications | Area assessments |
| qaSpecifications | Job Specifications | Specification details with notes |
| customerNotes | Notes | Customer Notes |
| franchiseeNotes | Notes | Franchisee Notes |

## Configuration

### Document Type Requirement

The system requires a Document Type for PDFs. The code looks for a document type where:
- `name` contains "pdf" (case-insensitive), OR
- `code` contains "pdf" (case-insensitive)

**Important**: Ensure your system has a Document Type configured with "PDF" in its name or code.

### Filename Convention

Generated PDFs follow this naming convention:
```
QualityAudit-{qaNo}.pdf

Example: QualityAudit-QA-000123.pdf
```

### Document Naming Convention

Documents are created with this name:
```
Quality Audit - {qaNo}

Example: Quality Audit - QA-000123
```

## Troubleshooting

### PDF Not Generating

**Issue**: PDF doesn't appear after creating/updating Quality Audit

**Possible Causes**:
1. No PDF Document Type configured
   - Solution: Create a Document Type with "PDF" in the name or code

2. Document creation permission issue
   - Solution: Check user permissions for creating documents

3. Quality Audit data incomplete
   - Solution: Check console logs for errors

### PDF Not Displaying in View

**Issue**: View/Download buttons don't appear

**Possible Causes**:
1. Document not created successfully
   - Solution: Check Documents tab to verify PDF exists

2. Document type mismatch
   - Solution: Verify document type name/code contains "pdf"

3. Query not returning documents
   - Solution: Check browser console for GraphQL errors

### PDF Content Issues

**Issue**: PDF shows incorrect or missing data

**Possible Causes**:
1. Quality Audit data not fully loaded
   - Solution: Ensure all related data (job, location, etc.) is loaded before PDF generation

2. Field mapping issue
   - Solution: Check `QualityAuditPDF.tsx` component for correct field references

## Future Enhancements

Potential improvements for future iterations:

1. **Email PDF**: Add ability to email the PDF to customers/franchisees
2. **Custom Templates**: Allow users to customize PDF layout/branding per location
3. **Version History**: Keep track of all PDF versions instead of overwriting
4. **Batch Generation**: Generate PDFs for multiple Quality Audits at once
5. **Photo Inclusion**: Include photos from Quality Audit if available
6. **Digital Signatures**: Add support for digital signatures on PDFs
7. **Scheduled Generation**: Generate PDFs on a schedule (e.g., end of day)

## Dependencies

This implementation relies on the following packages:

- `@react-pdf/renderer`: ^4.3.0 - PDF generation
- `graphql`: ^16.8.1 - GraphQL queries/mutations
- `dayjs`: ^1.11.9 - Date formatting

All dependencies are already included in the project's `package.json`.

## Testing Checklist

Before deploying to production, verify:

- [ ] PDF generates correctly on Quality Audit creation
- [ ] PDF updates correctly on Quality Audit edit
- [ ] View button opens PDF in new tab
- [ ] Download button downloads PDF with correct filename
- [ ] PDF contains all required information
- [ ] PDF formatting is correct and professional
- [ ] Status colors display correctly
- [ ] Areas and specifications render properly
- [ ] Notes display correctly
- [ ] PDF works on different browsers (Chrome, Firefox, Safari, Edge)
- [ ] Mobile responsiveness of View/Download buttons
- [ ] Error handling works (missing data, document type, etc.)

## Support

For issues or questions regarding this implementation:

1. Check the console for error messages
2. Verify Document Type configuration
3. Check GraphQL query responses
4. Review the troubleshooting section above
5. Contact the development team with specific error details

## Changelog

### Version 1.0.0 (October 2025)
- Initial implementation of automatic PDF generation
- PDF component with professional layout
- Auto-generate on create and update
- View and download functionality
- Document integration and storage

