# URL Tab Persistence Guide

## Overview

This document describes the implementation of URL tab persistence in the fe-abms application, specifically focusing on the SiteView component and similar tabbed interfaces. The implementation ensures that users remain on the same tab when refreshing the page or navigating back/forward.

## Problem Statement

Prior to this implementation, tabbed interfaces had the following issues:

1. **Lost tab state on refresh**: When users refreshed the page, they would always return to the default tab regardless of which tab they were viewing
2. **Poor user experience**: Users had to manually navigate back to their desired tab after page refresh
3. **No URL sharing**: Users couldn't share direct links to specific tabs
4. **Inconsistent navigation**: Browser back/forward buttons didn't work properly with tab changes

## Solution

The solution implements URL-based tab state management using React Router's query parameters and the custom `useNavigate` hook.

### Key Components

#### 1. useNavigate Hook Integration

The `useNavigate` hook provides access to:
- `location`: Current URL location object
- `query`: Parsed query parameters from the URL
- `navigate`: Function to update the URL

```typescript
const { navigate, location, query } = useNavigate();
```

#### 2. Tab State Management

```typescript
const [tab, setTab] = useState('site-info');

// Initialize tab from URL query parameter
useEffect(() => {
  const tabFromUrl = query.tab;
  if (tabFromUrl) {
    setTab(tabFromUrl);
  }
}, [query.tab]);
```

#### 3. URL Update Handler

```typescript
const handleTabChange = (key: string) => {
  setTab(key);
  // Update URL with new tab parameter while preserving other query parameters
  const searchParams = new URLSearchParams(location.search);
  searchParams.set('tab', key);
  const newUrl = `${location.pathname}?${searchParams.toString()}`;
  navigate(newUrl);
};
```

## Implementation Details

### File: `src/views/accounts/accounts/view/tabs/sites/view/index.tsx`

#### Before Implementation

```typescript
// Old implementation with issues
useEffect(() => {
  if (location?.search) {
    const queryParam = getQueryParam(location.search, 'tab');
    if (queryParam) {
      setTab(queryParam);
    }
  }
}, []);

// Tab change handler
onChange={key => {
  setTab(key);
  navigate(`${props.location.pathname}?tab=${key}`);
}}
```

#### After Implementation

```typescript
// Enhanced implementation with proper URL persistence
const { navigate, location, query } = useNavigate();

// Initialize tab from URL query parameter
useEffect(() => {
  const tabFromUrl = query.tab;
  if (tabFromUrl) {
    setTab(tabFromUrl);
  }
}, [query.tab]);

const handleTabChange = (key: string) => {
  setTab(key);
  // Update URL with new tab parameter while preserving other query parameters
  const searchParams = new URLSearchParams(location.search);
  searchParams.set('tab', key);
  const newUrl = `${location.pathname}?${searchParams.toString()}`;
  navigate(newUrl);
};

// Usage in Tabs component
<Tabs
  activeKey={tab}
  onChange={handleTabChange}
  items={[...]}
/>
```

## Benefits

### 1. Persistent Tab State
- Users stay on the same tab when refreshing the page
- Tab state is preserved across browser sessions

### 2. Improved User Experience
- Direct links to specific tabs can be shared
- Browser back/forward buttons work correctly
- No need to manually navigate back to desired tabs

### 3. SEO and Accessibility
- Each tab has a unique URL
- Better for bookmarking and sharing
- Improved accessibility for screen readers

### 4. Query Parameter Preservation
- Other query parameters in the URL are maintained
- No loss of additional URL state when switching tabs

## Usage Examples

### Basic Implementation

```typescript
import useNavigate from '@/hooks/useNavigate';

const MyTabbedComponent = () => {
  const { navigate, location, query } = useNavigate();
  const [tab, setTab] = useState('default-tab');

  // Initialize from URL
  useEffect(() => {
    const tabFromUrl = query.tab;
    if (tabFromUrl) {
      setTab(tabFromUrl);
    }
  }, [query.tab]);

  // Handle tab changes
  const handleTabChange = (key: string) => {
    setTab(key);
    const searchParams = new URLSearchParams(location.search);
    searchParams.set('tab', key);
    const newUrl = `${location.pathname}?${searchParams.toString()}`;
    navigate(newUrl);
  };

  return (
    <Tabs
      activeKey={tab}
      onChange={handleTabChange}
      items={[
        { key: 'tab1', label: 'Tab 1', children: <Tab1Content /> },
        { key: 'tab2', label: 'Tab 2', children: <Tab2Content /> },
      ]}
    />
  );
};
```

### Advanced Implementation with Multiple Parameters

```typescript
const handleTabChange = (key: string) => {
  setTab(key);
  const searchParams = new URLSearchParams(location.search);
  
  // Update tab parameter
  searchParams.set('tab', key);
  
  // Preserve other parameters
  if (query.filter) searchParams.set('filter', query.filter);
  if (query.sort) searchParams.set('sort', query.sort);
  
  const newUrl = `${location.pathname}?${searchParams.toString()}`;
  navigate(newUrl);
};
```

## URL Examples

### Before Implementation
```
/sites/123/view
/sites/123/view?tab=contacts  (lost on refresh)
```

### After Implementation
```
/sites/123/view?tab=site-info
/sites/123/view?tab=contacts
/sites/123/view?tab=deals
/sites/123/view?tab=jobs
/sites/123/view?tab=activities
/sites/123/view?tab=system-info
```

## Migration Guide

### For Existing Components

1. **Update imports**:
   ```typescript
   // Remove if not needed elsewhere
   // import { getQueryParam } from '@/utils/string.utils';
   ```

2. **Enhance useNavigate destructuring**:
   ```typescript
   // Before
   const { navigate } = useNavigate();
   
   // After
   const { navigate, location, query } = useNavigate();
   ```

3. **Replace tab initialization**:
   ```typescript
   // Before
   useEffect(() => {
     if (location?.search) {
       const queryParam = getQueryParam(location.search, 'tab');
       if (queryParam) {
         setTab(queryParam);
       }
     }
   }, []);
   
   // After
   useEffect(() => {
     const tabFromUrl = query.tab;
     if (tabFromUrl) {
       setTab(tabFromUrl);
     }
   }, [query.tab]);
   ```

4. **Create handleTabChange function**:
   ```typescript
   const handleTabChange = (key: string) => {
     setTab(key);
     const searchParams = new URLSearchParams(location.search);
     searchParams.set('tab', key);
     const newUrl = `${location.pathname}?${searchParams.toString()}`;
     navigate(newUrl);
   };
   ```

5. **Update Tabs onChange**:
   ```typescript
   // Before
   onChange={key => {
     setTab(key);
     navigate(`${props.location.pathname}?tab=${key}`);
   }}
   
   // After
   onChange={handleTabChange}
   ```

## Testing

### Manual Testing Checklist

- [ ] Navigate to a tabbed component
- [ ] Switch between different tabs
- [ ] Verify URL updates with correct tab parameter
- [ ] Refresh the page
- [ ] Verify you remain on the same tab
- [ ] Test browser back/forward buttons
- [ ] Test sharing URLs with tab parameters
- [ ] Verify other query parameters are preserved

### Automated Testing

```typescript
describe('URL Tab Persistence', () => {
  it('should initialize tab from URL parameter', () => {
    // Test implementation
  });

  it('should update URL when tab changes', () => {
    // Test implementation
  });

  it('should preserve other query parameters', () => {
    // Test implementation
  });

  it('should maintain tab state on refresh', () => {
    // Test implementation
  });
});
```

## Best Practices

1. **Always use the useNavigate hook**: Leverage the built-in query parameter parsing
2. **Preserve existing parameters**: Use URLSearchParams to maintain other query parameters
3. **Handle edge cases**: Consider what happens when no tab parameter is present
4. **Test thoroughly**: Ensure the implementation works across different scenarios
5. **Document changes**: Update component documentation when implementing this pattern

## Related Documentation

- [Routing Guide](./ROUTING_GUIDE.md)
- [Views Architecture Guide](./VIEWS_ARCHITECTURE_GUIDE.md)
- [URL Parameter Fix Guide](./URL_PARAMETER_FIX_GUIDE.md)

## Conclusion

The URL tab persistence implementation provides a robust solution for maintaining tab state across page refreshes and navigation. By leveraging React Router's query parameters and the custom `useNavigate` hook, we ensure a consistent and user-friendly experience while maintaining clean, maintainable code.

This pattern can be applied to any tabbed interface in the application to provide the same benefits of persistent state and improved user experience. 