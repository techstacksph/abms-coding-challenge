# Husky Linting Pipeline Guide

## Overview

This guide provides a comprehensive explanation of the automated linting pipeline implemented in the fe-abms project using Husky git hooks. The pipeline ensures code quality and consistency by automatically running ESLint and Prettier checks before every commit, preventing low-quality code from entering the repository.

## What is Husky?

**Husky** is a popular tool that makes Git hooks easy to manage. Git hooks are scripts that run automatically every time a certain event occurs in a Git repository. In our case, we use Husky to run linting and formatting checks before commits are allowed to proceed.

### Key Benefits

- **Prevents bad code commits**: Automatically blocks commits that don't meet quality standards
- **Consistent code style**: Ensures all team members follow the same formatting rules
- **Early error detection**: Catches TypeScript and ESLint errors before code review
- **Automated fixes**: Automatically fixes many common formatting and linting issues

## Pipeline Components

### 1. Pre-commit Hook (`.husky/pre-commit`)

The main component that runs before every commit attempt:

```bash
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

echo "🚀 Running pre-commit checks..."

echo "🔧 Running ESLint and Prettier on staged TypeScript files..."
yarn lint-staged

if [ $? -ne 0 ]; then
  echo "❌ Linting failed. Please fix the errors above before committing."
  exit 1
fi

echo "✅ All checks passed! Ready to commit."
```

### 2. Lint-staged Configuration (`package.json`)

Defines which tools run on which file types:

```json
"lint-staged": {
  "src/**/*.{ts,tsx}": [
    "eslint --fix",
    "prettier --write"
  ]
}
```

### 3. ESLint Configuration (`.eslintrc.json`)

Defines the code quality rules and standards that must be met.

## How It Works

### Step-by-Step Process

1. **Developer makes code changes**

   ```bash
   # Edit files in src/
   vim src/components/MyComponent.tsx
   ```

2. **Stage files for commit**

   ```bash
   git add src/components/MyComponent.tsx
   git add src/utils/helper.ts
   ```

3. **Attempt to commit**

   ```bash
   git commit -m "feat: add new component functionality"
   ```

4. **Husky pre-commit hook triggers automatically**
   - Detects staged TypeScript/TSX files
   - Runs ESLint with `--fix` flag to automatically fix issues
   - Runs Prettier to format code consistently
   - Either allows commit or blocks it with error messages

5. **Commit outcome**
   - **✅ Success**: If all checks pass, commit proceeds normally
   - **❌ Failure**: If errors exist, commit is blocked and developer must fix issues

### Example Success Output

```
🚀 Running pre-commit checks...
🔧 Running ESLint and Prettier on staged TypeScript files...
✨  Done in 2.34s.
✅ All checks passed! Ready to commit.
[main a1b2c3d] feat: add new component functionality
 2 files changed, 45 insertions(+), 12 deletions(-)
```

### Example Failure Output

```
🚀 Running pre-commit checks...
🔧 Running ESLint and Prettier on staged TypeScript files...

/src/components/MyComponent.tsx
  15:7  error  'unusedVariable' is assigned a value but never used  @typescript-eslint/no-unused-vars
  23:1  error  Expected an assignment or function call instead saw an expression  @typescript-eslint/no-unused-expressions

❌ Linting failed. Please fix the errors above before committing.
```

## Installation and Setup

### For New Developers

If you're a new developer joining the project, follow these steps after cloning the repository:

1. **Install dependencies**

   ```bash
   yarn install
   ```

2. **Set up Husky git hooks**

   ```bash
   yarn prepare
   ```

   This command runs `husky install` automatically and sets up the pre-commit hooks on your local machine.

3. **Verify setup is working**

   ```bash
   # Check that .husky directory exists
   ls -la .husky/
   
   # Test the linting pipeline
   yarn lint-staged
   ```

**Important**: After running these commands, the linting pipeline will automatically run on every commit you make. Make sure to run `yarn prepare` after `yarn install` to ensure the git hooks are properly configured.

### Initial Setup (Already Done)

The pipeline is already configured in this repository. Here's what was set up:

1. **Install Husky**

   ```bash
   yarn add --dev husky
   ```

2. **Initialize Husky**

   ```bash
   yarn husky install
   ```

3. **Create pre-commit hook**

   ```bash
   yarn husky add .husky/pre-commit "yarn lint-staged"
   ```

4. **Configure package.json scripts**
   - Added `lint:staged` script
   - Updated `lint-staged` configuration

### Verification

To verify the setup is working:

1. **Check Husky installation**

   ```bash
   ls -la .husky/
   # Should show pre-commit file and _/ directory
   ```

2. **Test the hook manually**

   ```bash
   yarn lint-staged
   # Should run without errors on current staged files
   ```

## Available Scripts

### Linting Scripts

- `yarn lint`: Fix all auto-fixable lint errors in src/
- `yarn lint:check`: Check for lint errors without fixing
- `yarn lint:staged`: Run ESLint with --fix on staged files only
- `yarn lint:unused`: Find and fix unused imports

### Formatting Scripts

- `yarn format`: Format all files in src/ with Prettier
- `yarn format:check`: Check if files are properly formatted

### TypeScript Scripts

- `yarn type-check`: Run TypeScript compiler checks

## Working with the Pipeline

### Normal Workflow

1. Make your code changes
2. Stage files: `git add .`
3. Commit: `git commit -m "your message"`
4. Pipeline runs automatically
5. If successful, commit proceeds
6. If failed, fix errors and try again

### Handling Lint Errors

#### Auto-fixable Issues

Many issues are fixed automatically:

- Missing semicolons
- Incorrect indentation
- Single vs double quotes
- Trailing whitespace
- Import ordering

#### Manual Fixes Required

Some issues need manual attention:

- Unused variables/imports
- Type errors
- Logic errors flagged by ESLint rules
- Complex formatting issues

#### Example Fix Process

```bash
# 1. Commit fails with lint errors
git commit -m "fix: update component logic"
# ❌ Linting failed...

# 2. View the specific errors
yarn lint:check

# 3. Fix errors manually or run lint with fix
yarn lint

# 4. Stage fixed files
git add .

# 5. Try commit again
git commit -m "fix: update component logic"
# ✅ All checks passed!
```

### Emergency Override (Not Recommended)

If you absolutely need to bypass the pipeline:

```bash
git commit -m "emergency fix" --no-verify
```

**⚠️ Warning**: This skips all quality checks and should only be used in genuine emergencies.

## Configuration Customization

### Modifying ESLint Rules

Edit `.eslintrc.json` to adjust code quality rules:

```json
{
  "rules": {
    "@typescript-eslint/no-unused-vars": "warn",  // Change error to warning
    "prefer-const": "off"  // Disable rule entirely
  }
}
```

### Updating Lint-staged

Modify `package.json` to change which tools run:

```json
"lint-staged": {
  "src/**/*.{ts,tsx}": [
    "eslint --fix",
    "prettier --write",
    "yarn type-check"  // Add TypeScript checking
  ]
}
```

### Adding More File Types

Extend to other file types:

```json
"lint-staged": {
  "src/**/*.{ts,tsx}": [
    "eslint --fix",
    "prettier --write"
  ],
  "src/**/*.{js,jsx}": [
    "eslint --fix",
    "prettier --write"
  ],
  "*.md": [
    "prettier --write"
  ]
}
```

## Troubleshooting

### Common Issues

#### 1. Hook Not Running

**Problem**: Pre-commit hook doesn't execute
**Solution**:

```bash
# Reinstall husky
yarn husky install
# Check hook permissions
chmod +x .husky/pre-commit
```

#### 2. Lint-staged Not Found

**Problem**: `yarn lint-staged` command fails
**Solution**:

```bash
# Install lint-staged
yarn add --dev lint-staged
```

#### 3. Too Many Errors

**Problem**: Overwhelming number of lint errors on existing code
**Current Solution**: The pipeline only checks staged files (files you're currently changing), so existing errors in untouched files won't block your commits.

#### 4. Performance Issues

**Problem**: Pre-commit hook runs slowly
**Solutions**:

- Pipeline already optimized to only check staged files
- Uses `--fix` flag to auto-fix issues quickly
- Consider adding `--cache` flag to ESLint if needed

### Getting Help

1. **Check the logs**: Read the error messages carefully
2. **Run manually**: Use `yarn lint:check` to see all issues
3. **Fix incrementally**: Address one error type at a time
4. **Ask team**: Consult with team members for complex issues

## Best Practices

### For Developers

1. **Run checks locally**: Use `yarn lint` before committing
2. **Fix issues promptly**: Don't let lint errors accumulate
3. **Understand the rules**: Learn why certain patterns are discouraged
4. **Use auto-fix**: Let the tools do the formatting work

### For Team Leads

1. **Monitor compliance**: Check that team members aren't using `--no-verify`
2. **Update rules**: Regularly review and update ESLint configuration
3. **Training**: Ensure team understands the tools and their purpose
4. **Documentation**: Keep this guide updated with any changes

## Benefits and Impact

### Code Quality Improvements

- **Consistent style**: All code follows the same formatting rules
- **Fewer bugs**: ESLint catches common mistakes and anti-patterns
- **Better readability**: Consistent formatting makes code easier to review
- **Type safety**: Ensures TypeScript types are used correctly

### Development Process

- **Faster reviews**: Reviewers can focus on logic instead of style issues
- **Reduced conflicts**: Consistent formatting reduces merge conflicts
- **Team alignment**: Everyone follows the same standards automatically
- **Confidence**: Developers know their code meets quality standards

### Maintenance Benefits

- **Automated enforcement**: No need for manual style reviews
- **Scalable**: Works for teams of any size
- **Configurable**: Rules can be adjusted as team preferences evolve
- **Integrated**: Works seamlessly with existing Git workflow

## Conclusion

The Husky linting pipeline provides an automated, consistent, and reliable way to maintain code quality in the fe-abms project. By running checks before every commit, it ensures that only high-quality, properly formatted code enters the repository, leading to better maintainability and fewer bugs in production.

The pipeline is designed to be helpful rather than obstructive - it automatically fixes many issues and only blocks commits when manual intervention is truly needed. This creates a smooth development experience while maintaining high code quality standards.
