# Routing & Navigation Guide

## 📍 Overview

This guide explains how to properly handle routing, navigation, and page linking in the AYR FE-ABMS application. We now use React Router's **Data Router** (`createBrowserRouter`) with data prefetching capabilities through loaders, while maintaining type-safe helper functions for route generation.

## 🚀 Quick Start

### Import the Helper Functions

```typescript
import { getViewRoute, getListRoute, getNewRoute, getEditRoute } from '@/mfe-utilities';
```

### Basic Usage

```typescript
// ✅ CORRECT - Use helper functions
const accountViewUrl = getViewRoute('Account');
const tasksListUrl = getListRoute('Tasks');
const newLeadUrl = getNewRoute('Leads');
const editDealUrl = getEditRoute('Deals');

// ❌ DEPRECATED - Don't use direct Routes access
const accountViewUrl = Routes['Account'].view; // TypeScript error!
```

### Data Router with Loaders

```typescript
// ✅ CORRECT - Using loaders for data prefetching
import { useLoaderData } from 'react-router-dom';

const DealTemplatesView = () => {
  const dealTemplate = useLoaderData() as any;
  // Data is already available from the loader
  return <div>{dealTemplate.name}</div>;
};

// ✅ CORRECT - Creating loaders
export const dealTemplatesLoader = async ({ params }: { params: any }) => {
  const { id } = params;
  const result = await apolloFetch(FIND_DEAL_TEMPLATE_BY_ID, { id });
  
  if ('error' in result) {
    throw new Error('Failed to load deal template');
  }
  
  return result.data;
};
```

## 🔧 Route Helper Functions

### Available Functions

| Function | Purpose | Example |
|----------|---------|---------|
| `getViewRoute(module)` | View a specific record | `/accounts/view` |
| `getListRoute(module)` | List all records | `/accounts/list` |
| `getNewRoute(module)` | Create new record | `/accounts/new` |
| `getEditRoute(module)` | Edit existing record | `/accounts/edit` |

### Data Router Functions

| Function | Purpose | Example |
|----------|---------|---------|
| `useLoaderData()` | Access prefetched data | `const data = useLoaderData()` |
| `useParams()` | Access route parameters | `const { id } = useParams()` |
| `useNavigate()` | Programmatic navigation | `const navigate = useNavigate()` |

### Function Signatures

```typescript
getViewRoute(moduleName: string): string
getListRoute(moduleName: string): string  
getNewRoute(moduleName: string): string
getEditRoute(moduleName: string): string
```

### Data Router Hook Signatures

```typescript
useLoaderData(): any
useParams(): Readonly<Params<string>>
useNavigate(): NavigateFunction
```

## 🔗 Linking to Pages

### Using Link Component

```typescript
import Link from '@/components/Link';
import { getViewRoute } from '@/mfe-utilities';

// Link to view an account
<Link to={`${getViewRoute('Account')}/${accountId}`}>
  View Account
</Link>

// Link to accounts list
<Link to={getListRoute('Account')}>
  All Accounts
</Link>

// Link with query parameters
<Link to={`${getViewRoute('Account')}/${accountId}?tab=contacts`}>
  Account Contacts
</Link>
```

### In Table Columns

```typescript
import { getViewRoute } from '@/mfe-utilities';

const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    render: (name, record) => (
      <Link ellipsis to={`${getViewRoute('Account')}/${record.id}`}>
        {name}
      </Link>
    ),
  },
];
```

## 🧭 Navigation (Programmatic)

### Using useNavigate Hook

```typescript
import { useNavigate } from 'react-router-dom';
import { getViewRoute, getListRoute } from '@/mfe-utilities';

const navigate = useNavigate();

// Navigate to view page
const handleViewAccount = (accountId: string) => {
  navigate(`${getViewRoute('Account')}/${accountId}`);
};

// Navigate to list with state
const handleBackToList = () => {
  navigate(getListRoute('Account'), { 
    state: { from: 'account-view' } 
  });
};

// Navigate with query parameters
const handleViewWithTab = (accountId: string, tab: string) => {
  navigate(`${getViewRoute('Account')}/${accountId}?tab=${tab}`);
};
```

### Navigation in Form Handlers

```typescript
import { getViewRoute } from '@/mfe-utilities';

const onCreateSuccess = (newRecord) => {
  snackbar({ 
    type: 'success', 
    message: 'Account created successfully' 
  });
  navigate(`${getViewRoute('Account')}/${newRecord.id}`);
};

const onUpdateSuccess = (updatedRecord) => {
  snackbar({ 
    type: 'success', 
    message: 'Account updated successfully' 
  });
  navigate(`${getViewRoute('Account')}/${updatedRecord.id}`);
};
```

## 📋 Common Patterns

### Module Constants

Many components use module constants for consistency:

```typescript
// In module constants file
export const ROUTE_NAME = 'Account';
export const MODULE_NAME = 'Accounts';

// In components
import { ROUTE_NAME } from '../common/constants';
import { getViewRoute } from '@/mfe-utilities';

const viewUrl = getViewRoute(ROUTE_NAME);
```

### Data Loading with Loaders

```typescript
// ✅ CORRECT - Using loaders for data fetching
export const accountLoader = async ({ params }: { params: any }) => {
  const { id } = params;
  const result = await apolloFetch(FIND_ACCOUNT_BY_ID, { id });
  
  if ('error' in result) {
    throw new Error('Failed to load account');
  }
  
  return result.data;
};

// In component
const AccountView = () => {
  const account = useLoaderData() as any;
  const { id } = useParams();
  
  return <div>{account.name}</div>;
};
```

### Error Handling with Loaders

```typescript
// ✅ CORRECT - Error boundaries for loaders
export const accountLoader = async ({ params }: { params: any }) => {
  try {
    const { id } = params;
    const result = await apolloFetch(FIND_ACCOUNT_BY_ID, { id });
    
    if ('error' in result) {
      throw new Error('Failed to load account');
    }
    
    return result.data;
  } catch (error) {
    throw new Error(`Account not found: ${error.message}`);
  }
};

// Error boundary component
const AccountErrorBoundary = () => {
  return (
    <div>
      <h2>Error loading account</h2>
      <p>Please try again or contact support.</p>
    </div>
  );
};
```

### Dynamic Module Names

For dynamic routing based on variables:

```typescript
import { getViewRoute } from '@/mfe-utilities';

// With variable module names
const getModuleViewUrl = (moduleName: string, recordId: string) => {
  return `${getViewRoute(moduleName)}/${recordId}`;
};

// With optional chaining for safety
const getRelatedModuleUrl = (relatedModule?: string, recordId?: string) => {
  if (!relatedModule || !recordId) return null;
  return `${getViewRoute(relatedModule)}/${recordId}`;
};
```

### Tab Navigation

```typescript
import { getViewRoute } from '@/mfe-utilities';

// Navigate to specific tabs
const navigateToAccountContacts = (accountId: string) => {
  navigate(`${getViewRoute('Account')}/${accountId}?tab=contacts`);
};

const navigateToAccountSites = (accountId: string) => {
  navigate(`${getViewRoute('Account')}/${accountId}?tab=sites`);
};

// Generic tab navigation
const navigateToTab = (module: string, recordId: string, tab: string) => {
  navigate(`${getViewRoute(module)}/${recordId}?tab=${tab}`);
};
```

## 🎯 Form Integration

### Form Success Handlers

```typescript
import { getViewRoute, getListRoute } from '@/mfe-utilities';

// In FormProvider components
const FormProvider = ({ onSuccess, redirectTo }) => {
  const handleSuccess = (record) => {
    if (onSuccess) {
      onSuccess(record);
    }
    
    // Default redirect behavior
    const defaultRedirect = redirectTo || getViewRoute(MODULE_NAME);
    navigate(`${defaultRedirect}/${record.id}`);
  };
};
```

### Form Headers with Back Navigation

```typescript
import { getListRoute } from '@/mfe-utilities';

const FormHeader = ({ formType, moduleName }) => (
  <Header
    title={`${formType} ${moduleName}`}
    backUrl={getListRoute(moduleName)}
    onBack={() => navigate(getListRoute(moduleName))}
  />
);
```

## 🔧 Advanced Patterns

### Route Building Utilities

```typescript
import { getViewRoute } from '@/mfe-utilities';

// Utility for building complex routes
export const buildModuleRoute = (
  module: string, 
  action: 'view' | 'edit' | 'new', 
  id?: string,
  params?: Record<string, string>
) => {
  let route = '';
  
  switch (action) {
    case 'view':
      route = getViewRoute(module);
      break;
    case 'edit':
      route = getEditRoute(module);
      break;
    case 'new':
      route = getNewRoute(module);
      break;
  }
  
  if (id) {
    route += `/${id}`;
  }
  
  if (params) {
    const queryString = new URLSearchParams(params).toString();
    route += `?${queryString}`;
  }
  
  return route;
};

// Usage
const accountEditUrl = buildModuleRoute('Account', 'edit', '123', { tab: 'info' });
// Result: "/accounts/edit/123?tab=info"
```

### Creating Loaders for Routes

```typescript
// ✅ CORRECT - Loader with proper error handling
export const accountLoader = async ({ params }: { params: any }) => {
  const { id } = params;
  
  if (!id) {
    throw new Error('Account ID is required');
  }
  
  try {
    const result = await apolloFetch(FIND_ACCOUNT_BY_ID, { id });
    
    if ('error' in result) {
      throw new Error('Failed to load account');
    }
    
    return result.data;
  } catch (error) {
    throw new Error(`Account not found: ${error.message}`);
  }
};

// ✅ CORRECT - Loader with validation
export const accountListLoader = async ({ request }: { request: Request }) => {
  const url = new URL(request.url);
  const search = url.searchParams.get('search') || '';
  const page = parseInt(url.searchParams.get('page') || '1');
  
  try {
    const result = await apolloFetch(FIND_ACCOUNTS, { 
      search, 
      page,
      limit: 20 
    });
    
    if ('error' in result) {
      throw new Error('Failed to load accounts');
    }
    
    return result.data;
  } catch (error) {
    throw new Error(`Failed to load accounts: ${error.message}`);
  }
};
```

### Conditional Navigation

```typescript
import { getViewRoute, getListRoute } from '@/mfe-utilities';

const handleNavigation = (record, userRole) => {
  if (userRole === 'admin') {
    navigate(`${getViewRoute('Account')}/${record.id}?tab=admin`);
  } else if (userRole === 'manager') {
    navigate(`${getViewRoute('Account')}/${record.id}?tab=overview`);
  } else {
    navigate(getListRoute('Account'));
  }
};
```

## 📝 Module Names Reference

### Common Module Names

| Module | Route Name | Description |
|--------|------------|-------------|
| Accounts | `'Account'` | Customer accounts |
| Contacts | `'Contacts'` | Contact records |
| Leads | `'Leads'` | Sales leads |
| Deals | `'Deals'` | Sales deals |
| Jobs | `'Jobs'` | Service jobs |
| Tasks | `'Tasks'` | Task management |
| Events | `'Events'` | Calendar events |
| Users | `'Users'` | User management |
| Settings | `'Settings'` | Application settings |

### Module Constants Pattern

Many modules define constants for consistency:

```typescript
// In module constants
export const ROUTE_NAME = 'Account';
export const MODULE_NAME = 'Accounts';
export const MODULE_NAME_SINGULAR = 'Account';
```

## ⚠️ Best Practices

### DO's ✅

1. **Always use helper functions**
   ```typescript
   const url = getViewRoute('Account');
   ```

2. **Import only what you need**
   ```typescript
   import { getViewRoute, getListRoute } from '@/mfe-utilities';
   ```

3. **Use module constants when available**
   ```typescript
   import { ROUTE_NAME } from '../constants';
   const url = getViewRoute(ROUTE_NAME);
   ```

4. **Handle null/undefined safely**
   ```typescript
   if (moduleId && recordId) {
     navigate(`${getViewRoute(moduleId)}/${recordId}`);
   }
   ```

5. **Use loaders for data fetching**
   ```typescript
   // ✅ Prefer loaders over useEffect for data fetching
   const data = useLoaderData();
   ```

6. **Handle loader errors properly**
   ```typescript
   // ✅ Always throw errors in loaders for proper error boundaries
   if ('error' in result) {
     throw new Error('Failed to load data');
   }
   ```

7. **Use proper imports for React Router hooks**
   ```typescript
   // ✅ Use React Router hooks directly
   import { useNavigate, useLoaderData, useParams } from 'react-router-dom';
   ```

### DON'Ts ❌

1. **Don't use direct Routes object access**
   ```typescript
   // ❌ This will cause TypeScript errors
   const url = Routes['Account'].view;
   ```

2. **Don't hardcode route paths**
   ```typescript
   // ❌ Brittle and hard to maintain
   const url = '/accounts/view';
   ```

3. **Don't forget error handling**
   ```typescript
   // ❌ Missing null checks
   navigate(`${getViewRoute(moduleId)}/${recordId}`);
   ```

4. **Don't use useEffect for data fetching when loaders are available**
   ```typescript
   // ❌ Avoid this pattern when loaders exist
   useEffect(() => {
     fetchData(id);
   }, [id]);
   ```

5. **Don't use custom navigation hooks when React Router hooks are available**
   ```typescript
   // ❌ Don't use custom hooks
   import useNavigate from '@/hooks/useNavigate';
   
   // ✅ Use React Router hooks directly
   import { useNavigate } from 'react-router-dom';
   ```

## 🐛 Troubleshooting

### Common Issues

1. **TypeScript errors with Routes object**
   - **Problem**: `Property 'view' does not exist on type 'RouteValue'`
   - **Solution**: Replace with helper functions

2. **Missing imports**
   - **Problem**: `getViewRoute is not defined`
   - **Solution**: Import from `@/mfe-utilities`

3. **Invalid module names**
   - **Problem**: Route returns undefined
   - **Solution**: Check module name spelling and availability

4. **Loader not being called**
   - **Problem**: `useLoaderData()` returns undefined
   - **Solution**: Ensure route has `loader` prop configured in router

5. **Navigation not working**
   - **Problem**: `useNavigate` not working
   - **Solution**: Use `import { useNavigate } from 'react-router-dom'` instead of custom hooks

6. **Authentication redirects**
   - **Problem**: Always redirected to login
   - **Solution**: Check `AuthWrapper` configuration and token validation

### Migration Checklist

When updating old routing code:

- [ ] Replace `Routes['Module'].view` with `getViewRoute('Module')`
- [ ] Replace `Routes['Module'].list` with `getListRoute('Module')`
- [ ] Replace `Routes['Module'].new` with `getNewRoute('Module')`
- [ ] Replace `Routes['Module'].edit` with `getEditRoute('Module')`
- [ ] Add imports for helper functions
- [ ] Test navigation functionality
- [ ] Verify TypeScript compilation

### Data Router Migration Checklist

When migrating to use loaders:

- [ ] Replace `useEffect` data fetching with loaders
- [ ] Update component to use `useLoaderData()` instead of state
- [ ] Add `loader` prop to route configuration
- [ ] Add `errorElement` for proper error handling
- [ ] Update imports to use React Router hooks directly
- [ ] Test data loading and error scenarios
- [ ] Verify authentication still works correctly

## 📚 Examples

### Complete Component Example

```typescript
import React from 'react';
import { getViewRoute, getListRoute } from '@/mfe-utilities';
import { useNavigate } from 'react-router-dom';
import Link from '@/components/Link';

const AccountCard = ({ account }) => {
  const navigate = useNavigate();

  const handleViewAccount = () => {
    navigate(`${getViewRoute('Account')}/${account.id}`);
  };

  const handleEditAccount = () => {
    navigate(`${getEditRoute('Account')}/${account.id}`);
  };

  return (
    <div>
      <h3>
        <Link to={`${getViewRoute('Account')}/${account.id}`}>
          {account.name}
        </Link>
      </h3>
      
      <button onClick={handleViewAccount}>
        View Details
      </button>
      
      <button onClick={handleEditAccount}>
        Edit Account
      </button>
      
      <Link to={getListRoute('Account')}>
        Back to Accounts
      </Link>
    </div>
  );
};
```

### Complete Component with Loader Example

```typescript
import React from 'react';
import { useLoaderData, useParams, useNavigate } from 'react-router-dom';
import { getViewRoute, getListRoute } from '@/mfe-utilities';
import { apolloFetch } from '@/graphql/service';
import { FIND_ACCOUNT_BY_ID } from '@/graphql/accounts.gql';

// Loader function
export const accountLoader = async ({ params }: { params: any }) => {
  const { id } = params;
  const result = await apolloFetch(FIND_ACCOUNT_BY_ID, { id });
  
  if ('error' in result) {
    throw new Error('Failed to load account');
  }
  
  return result.data;
};

// Component using loader data
const AccountView = () => {
  const account = useLoaderData() as any;
  const { id } = useParams();
  const navigate = useNavigate();

  const handleEdit = () => {
    navigate(`${getEditRoute('Account')}/${id}`);
  };

  const handleBack = () => {
    navigate(getListRoute('Account'));
  };

  return (
    <div>
      <h1>{account.name}</h1>
      <p>{account.description}</p>
      
      <button onClick={handleEdit}>
        Edit Account
      </button>
      
      <button onClick={handleBack}>
        Back to Accounts
      </button>
    </div>
  );
};
```

