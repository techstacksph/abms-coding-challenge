# Router Architecture Documentation

## Overview

This application now uses React Router's **Data Router** (`createBrowserRouter`) for the entire application, providing data prefetching capabilities through loaders while maintaining authentication and authorization.

## Architecture Components

### 1. Main Router (`src/router.tsx`)

The central router configuration using `createBrowserRouter` that handles both authenticated and unauthenticated routes.

#### Key Features:
- **Authentication Wrapper**: All protected routes are wrapped with `AuthWrapper`
- **Data Loaders**: Support for prefetching data before component rendering
- **Error Boundaries**: Proper error handling for loader failures
- **Lazy Loading**: Components are loaded on-demand for better performance

#### Route Structure:
```typescript
export const router = createBrowserRouter([
  // Unauthorized Routes (no auth required)
  {
    path: '/login',
    element: <UnauthorizedLayout><Login /></UnauthorizedLayout>
  },
  // ... other unauthorized routes
  
  // Authenticated Routes (with AuthWrapper)
  {
    path: '/',
    element: <AuthWrapper><Navigate to="/calendar" /></AuthWrapper>
  },
  // ... all other protected routes
]);
```

### 2. Authentication Wrapper (`AuthWrapper`)

A component that handles authentication state and redirects unauthenticated users to login.

#### Features:
- **Token Validation**: Checks for valid access tokens
- **Permission Verification**: Validates user permissions via `getUserPermissions()`
- **Automatic Redirects**: Redirects to `/login` if not authenticated
- **Loading States**: Shows loading indicator during auth checks

### 3. Layout Components

#### `AppLayout`
- Includes `TopNav` for authenticated routes
- Provides consistent layout structure
- Used for all protected routes

#### `UnauthorizedLayout`
- Minimal layout without navigation
- Used for login, forgot password, etc.
- No authentication required

#### `SettingsLayout`
- Includes settings side menu
- Used specifically for settings routes
- Wrapped by `AppLayout`

### 4. Settings Router (`src/views/settings/settingsRouter.tsx`)

Specialized router configuration for settings pages with data loaders.

#### Features:
- **Data Loaders**: Prefetch data for settings views (e.g., `dealTemplatesLoader`)
- **Nested Routes**: Handles complex settings navigation
- **Error Handling**: Custom error boundaries for settings routes

#### Example Loader:
```typescript
export const dealTemplatesLoader = async ({ params }: { params: any }) => {
  const { id } = params;
  const result = await apolloFetch(FIND_DEAL_TEMPLATE_BY_ID, { id });
  
  if ('error' in result) {
    throw new Error('Failed to load deal template');
  }
  
  return result.data;
};
```

## Data Flow

### 1. Route Navigation
1. User navigates to a route
2. Router checks if route requires authentication
3. If unauthorized route → render directly
4. If authorized route → check authentication via `AuthWrapper`

### 2. Data Loading (for routes with loaders)
1. Route is accessed
2. Loader function executes (e.g., `dealTemplatesLoader`)
3. Data is prefetched before component renders
4. Component receives data via `useLoaderData()`
5. Component renders with data already available

### 3. Authentication Flow
1. `AuthWrapper` checks for access token
2. If no token → redirect to `/login`
3. If token exists → validate permissions
4. If valid → render protected content
5. If invalid → clear tokens and redirect to `/login`

## Usage Examples

### Using Loaders in Components
```typescript
import { useLoaderData } from 'react-router-dom';

const DealTemplatesView = () => {
  const dealTemplate = useLoaderData() as any;
  // Component renders with prefetched data
};
```

### Adding New Routes with Loaders
```typescript
// In settingsRouter.tsx
{
  path: '/settings/my-route/:id',
  element: <SettingsRoute><MyComponent /></SettingsRoute>,
  loader: myDataLoader,
  errorElement: <SettingsRoute><ErrorComponent /></SettingsRoute>
}
```

### Creating Loaders
```typescript
export const myDataLoader = async ({ params }: { params: any }) => {
  const result = await apolloFetch(MY_QUERY, { id: params.id });
  
  if ('error' in result) {
    throw new Error('Failed to load data');
  }
  
  return result.data;
};
```

## Benefits

1. **Performance**: Data is prefetched before component rendering
2. **User Experience**: Faster page loads and better perceived performance
3. **Error Handling**: Centralized error boundaries for data loading failures
4. **Type Safety**: Full TypeScript support for loaders and data
5. **Authentication**: Seamless integration with existing auth system
6. **Code Splitting**: Automatic lazy loading of components

## Migration Notes

- Replaced `BrowserRouter` + `NavigationProvider` with `createBrowserRouter`
- Moved authentication logic into `AuthWrapper` component
- Integrated unauthorized routes directly into main router
- Maintained existing route structure and navigation patterns
- Added data loaders for improved performance

## File Structure

```
src/
├── router.tsx                    # Main data router configuration
├── App.tsx                       # Uses RouterProvider with data router
├── views/settings/
│   └── settingsRouter.tsx        # Settings-specific routes with loaders
└── components/
    └── navbar/
        └── TopNav.tsx            # Navigation component
```

## Removed Files

The following files have been removed as they are no longer used with the new architecture:
- `src/routes/index.tsx` (AuthorizedRoutes) - ❌ **DELETED**
- `src/routes/AuthorizedRoutes.tsx` - ❌ **DELETED**
- `src/components/NavigationProvider.tsx` - ❌ **DELETED**
- `src/views/settings/index.tsx` - ❌ **DELETED**
- `src/routes/` directory - ❌ **DELETED** (entire directory removed)

## Cleanup Summary

✅ **Removed unused router files**
✅ **Cleaned up directory structure**
✅ **No broken imports remaining**
✅ **All functionality preserved in new architecture** 