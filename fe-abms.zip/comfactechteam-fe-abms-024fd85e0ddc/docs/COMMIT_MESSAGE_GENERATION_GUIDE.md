# Commit Message Generation Guide

## Overview

This guide provides a systematic approach to generating commit messages based on ticket board screenshots and staged code changes, following the established commit message format for the fe-abms project.

## Commit Message Format

### Header Format
```
TICKET-no-1,TICKET-no-2,TICKET-no-3 > Ticket-title-1,Ticket-title-2,Ticket-title-3
```

### Body Format
```
TICKET-no-1 
 - change description 1
 - change description 2

TICKET-no-2 
 - change description 1
 - change description 2

TICKET-no-3 
 - change description 1
```

## Step-by-Step Process

### Step 1: Analyze Screenshot

When provided with a ticket board screenshot, identify:

1. **All Visible Tickets**: Look for ticket numbers (e.g., ABMS-3773, ABMS-3525)
2. **Ticket Titles**: Extract the full title text for each ticket
3. **Ticket Status**: Note which column/status each ticket is in
4. **Priority/Urgency**: Look for any visual indicators

### Step 2: Analyze Staged Changes

When generating commit messages, always examine the actual staged changes:

1. **Review Modified Files**: Check what files were changed in the repository
2. **Understand Code Changes**: Analyze what functionality was added, modified, or removed
3. **Identify Patterns**: Look for common patterns like:
   - New utility functions added
   - Component migrations (AltModuleTable → DataTable)
   - Export functionality improvements
   - Documentation updates
   - Bug fixes or enhancements

### Step 3: Extract Ticket Information

Create a list of tickets with their information:

**Example from Screenshot Analysis:**
```
ABMS-3773: "Sites/Leads/Deals - Last activity FE ..."
ABMS-3525: "Deals - updates Integration"
ABMS-3789: "Leads - Last activity FE & Integration"  
ABMS-3790: "Backend Integration" (if visible)
```

### Step 4: Generate Header

Combine all tickets following the format:
```
TICKET-no-1,TICKET-no-2,TICKET-no-3 > Title-1,Title-2,Title-3
```

**Rules for Header:**
- List all ticket numbers separated by commas (no spaces)
- Follow with ` > ` (space, greater than, space)
- List all titles separated by commas
- Use exact titles from screenshot (trim if too long with ...)

### Step 5: Generate Body Based on Actual Changes

For each ticket, create a section based on the staged changes:

```
TICKET-no-1 
 - Enhanced convertToCSVBase64 utility function for better CSV export handling
 - Updated migration documentation with comprehensive export patterns

TICKET-no-2 
 - Migrated deals list to use modern export functionality with user feedback
 - Implemented progressive data building patterns for export transformations
```

**Rules for Body:**
- Each ticket section starts with ticket number + space + newline
- Each change starts with ` - ` (space, dash, space)
- Leave one blank line between ticket sections
- **Describe actual code changes, not generic descriptions**
- Group related changes under appropriate ticket

## Common Code Change Patterns

### Utility Function Enhancements
When utility functions are added or modified:
```
ABMS-XXXX 
 - Enhanced [function name] utility for [specific purpose]
 - Improved [specific functionality] with better error handling
```

### Component Migrations
When components are migrated from AltModuleTable to DataTable:
```
ABMS-XXXX 
 - Migrated [module] list from AltModuleTable to DataTable
 - Implemented modern export functionality with user feedback
 - Added comprehensive loading states and error handling
```

### Export Functionality Improvements
When export features are enhanced:
```
ABMS-XXXX 
 - Enhanced export functionality with custom export handlers
 - Added proper loading states and user feedback for export operations
 - Implemented progressive data building patterns for export transformations
```

### Documentation Updates
When documentation is added or updated:
```
ABMS-XXXX 
 - Created comprehensive [document name] with implementation guidelines
 - Updated migration guide with detailed patterns and best practices
 - Added troubleshooting section for common export issues
```

### Bug Fixes and Enhancements
When bugs are fixed or features enhanced:
```
ABMS-XXXX 
 - Fixed [specific issue] in [component/module]
 - Enhanced [specific functionality] with improved performance
 - Added proper error handling for [specific scenario]
```

## Screenshot Analysis Checklist

### ✅ Visual Elements to Look For

1. **Ticket Numbers**: Usually in format ABMS-XXXX
2. **Ticket Titles**: Full descriptive text
3. **Status Columns**: "IN PROGRESS", "FOR CODE REVIEW", "FOR MERGE", "ON HOLD"
4. **Assignee Indicators**: Profile pictures or initials
5. **Priority Indicators**: Colors, flags, or warning symbols
6. **Related Tickets**: Tickets that appear to be grouped or related

### ✅ Common Patterns in Screenshots

**Multi-Column Layout:**
- IN PROGRESS: Tickets currently being worked on
- FOR CODE REVIEW: Tickets ready for review
- FOR MERGE: Tickets ready to merge
- ON HOLD: Tickets temporarily paused

**Ticket Information:**
- Ticket number (top of card)
- Title (main text of card)
- Status indicators (progress bars, colors)
- Assignee (profile pictures)
- Time estimates or deadlines

## Code Change Analysis Checklist

### ✅ What to Look For in Staged Changes

1. **New Files Added**: New components, utilities, or documentation
2. **Modified Files**: Changes to existing functionality
3. **Deleted Files**: Removed deprecated code
4. **Import Changes**: New dependencies or updated imports
5. **Function Signatures**: New parameters or return types
6. **State Management**: New state variables or hooks
7. **Export Patterns**: Changes to export functionality
8. **Error Handling**: New try-catch blocks or error states

### ✅ Common File Patterns

**Utility Files**: `src/utils/*.ts`
- New helper functions
- Enhanced existing utilities
- Better error handling

**Component Files**: `src/components/*.tsx` or `src/views/*/list/index.tsx`
- Component migrations
- New props or functionality
- Updated render logic

**Documentation Files**: `docs/*.md`
- New guides or tutorials
- Updated migration documentation
- Best practices documentation

**GraphQL Files**: `src/graphql/*.gql.ts`
- New queries or mutations
- Updated query structures
- Enhanced data fetching

## Examples

### Example 1: Single Ticket with Code Changes
**Screenshot shows:** ABMS-3789 "Leads - Last activity FE & Integration"
**Staged changes:** Modified leads list component, added export functionality

**Generated Commit Message:**
```
ABMS-3789 > Leads - Last activity FE & Integration

ABMS-3789 
 - Migrated leads list from AltModuleTable to DataTable
 - Implemented modern export functionality with user feedback
 - Enhanced leads activity tracking and display functionality
 - Added comprehensive loading states for export operations
```

### Example 2: Multiple Tickets with Complex Changes
**Screenshot shows:** 
- ABMS-3773 "Sites/Leads/Deals - Last activity FE"
- ABMS-3525 "Deals - updates Integration"
- ABMS-3789 "Leads - Last activity FE & Integration"

**Staged changes:** Multiple component migrations, new utility functions, documentation updates

**Generated Commit Message:**
```
ABMS-3773,ABMS-3525,ABMS-3789 > Sites/Leads/Deals - Last activity FE,Deals - updates Integration,Leads - Last activity FE & Integration

ABMS-3773 
 - Enhanced convertToCSVBase64 utility function for better CSV export handling
 - Updated sites module for last activity functionality
 - Created comprehensive export fields implementation guide

ABMS-3525 
 - Migrated deals list from AltModuleTable to DataTable
 - Enhanced global options store to support deal types and workflow statuses
 - Implemented modern export functionality with user feedback

ABMS-3789 
 - Migrated leads list from AltModuleTable to DataTable
 - Implemented leads last activity FE and integration components
 - Added progressive data building patterns for export transformations
```

## Context Clues for Change Descriptions

### File Changes Context
When generating change descriptions, consider:

1. **GraphQL Files Modified**: "Updated [module] GraphQL queries"
2. **Component Files**: "Enhanced [component] functionality"
3. **Store/Hook Files**: "Implemented centralized data management"
4. **Documentation Added**: "Created documentation and migration guides"
5. **Configuration Changes**: "Updated configuration for improved standards"
6. **Utility Files**: "Enhanced [utility] function for [specific purpose]"

### Module-Specific Patterns
- **Deals**: Often involve global options, table migrations, workflow statuses
- **Leads**: Often involve activity tracking, form enhancements, data handling
- **Sites**: Often involve cross-module integration, activity tracking
- **Backend/Integration**: Often involve GraphQL optimization, data synchronization
- **Export**: Often involve CSV handling, user feedback, loading states

## Best Practices

### DO:
- ✅ Include ALL visible tickets in screenshot
- ✅ Use exact titles from screenshot (trim if necessary)
- ✅ **Analyze actual staged changes for accurate descriptions**
- ✅ Group related changes logically under appropriate tickets
- ✅ **Be specific about what was implemented/changed**
- ✅ Follow the exact format structure
- ✅ **Describe code changes, not generic improvements**

### DON'T:
- ❌ Skip tickets visible in the screenshot
- ❌ Make up ticket titles if not clearly visible
- ❌ Use generic descriptions like "fixed bugs"
- ❌ Deviate from the required format structure
- ❌ Include tickets not visible in the provided screenshot
- ❌ **Ignore actual code changes when generating descriptions**

## Troubleshooting

### Common Issues:

**Issue**: Can't see all ticket numbers clearly
**Solution**: Ask for clarification or better screenshot

**Issue**: Ticket titles are truncated with "..."
**Solution**: Use the visible portion and add "..." to match screenshot

**Issue**: Multiple tickets seem related
**Solution**: Group them in header but create separate sections for each

**Issue**: Uncertain about changes made
**Solution**: **Examine staged changes and describe actual modifications**

**Issue**: No staged changes visible
**Solution**: Ask user to stage changes or provide more context

## Template for Quick Reference

```
TICKET-1,TICKET-2,TICKET-3 > Title-1,Title-2,Title-3

TICKET-1 
 - [Description based on actual code changes]
 - [Additional changes if applicable]

TICKET-2 
 - [Description based on actual code changes]
 - [Additional changes if applicable]

TICKET-3 
 - [Description based on actual code changes]
 - [Additional changes if applicable]
```

## Validation Checklist

Before finalizing commit message:

- [ ] All visible tickets included in header
- [ ] Titles match screenshot exactly
- [ ] Format follows exact structure (commas, spaces, > symbol)
- [ ] Each ticket has its own section in body
- [ ] **Changes are based on actual staged modifications**
- [ ] **Descriptions are specific to code changes made**
- [ ] Blank lines between ticket sections
- [ ] Each change starts with ` - ` format
- [ ] **No generic descriptions like "improved performance" or "fixed bugs"**

## Automated Process

When generating commit messages, always follow this process:

1. **Extract tickets from screenshot** (numbers and titles)
2. **Analyze staged changes** in the repository
3. **Generate header** with all ticket numbers and titles
4. **Create body sections** based on actual code modifications
5. **Validate format** against the checklist
6. **Provide specific, actionable descriptions** of what was changed

This ensures commit messages are accurate, informative, and follow the established format while reflecting the actual work completed. 