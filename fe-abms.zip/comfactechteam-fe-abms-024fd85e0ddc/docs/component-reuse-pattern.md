# Component Reuse Pattern - Converting Duplicate Components to Wrappers

## Overview

This document describes the pattern for refactoring duplicate list/table components into thin wrappers that reuse existing full-featured components. This pattern eliminates code duplication, ensures consistency, and simplifies maintenance.

## Quick Reference - Module Conversion Status

| Module | Source Component | Wrapper Component | Status | LOC Saved | Notes |
|--------|------------------|-------------------|--------|-----------|-------|
| **Tasks** | `/views/calendar/tasks/list` | `/components/GenericTab/task/TasksDataTable.tsx` | ✅ **Completed** | ~700 | Reference implementation |
| **Activities** | `/views/activities/list` | `/components/GenericTab/activties/ActivitiesDataTable.tsx` | 🔄 **Ready** | ~700 est. | Multi-type dropdown needed |
| **Events** | `/views/calendar/events/list` | `/components/GenericTab/events/EventsDataTable.tsx` | 🔄 **Ready** | ~500 est. | Recurring events support |
| **Documents** | `/views/documents/list` | `/components/GenericTab/document/DocumentsDataTable.tsx` | 🔄 **Ready** | ~600 est. | Upload functionality |
| **Jobs** | `/views/jobs/jobs/list` | TBD | 📋 **To Assess** | TBD | Check for GenericTab version |
| **Deals** | `/views/sales/deals/list` | `/views/sales/deals/view/tabs/tasks.tsx` | ✅ **Reference** | N/A | Example wrapper pattern |

**Legend**:
- ✅ **Completed** - Refactoring done, tested, and documented
- 🔄 **Ready** - Source and wrapper identified, ready to refactor using this guide
- 📋 **To Assess** - Needs investigation to confirm pattern applicability
- ✅ **Reference** - Example implementation to follow

## When to Use This Pattern

Use this pattern when you have:
- Multiple components with similar functionality (list views, tables, data grids)
- Duplicate state management, queries, and UI logic across components
- A need for embedded versions of list components in different contexts (tabs, modals, etc.)
- Custom action handlers required for different contexts (navigation, callbacks)

## The Pattern

### Example: TasksDataTable → TasksList Refactoring

**Before**: `TasksDataTable` was a ~750-line standalone component with its own state, queries, filters, and table logic.

**After**: `TasksDataTable` is a ~42-line wrapper that delegates to `TasksList`.

---

## Step 1: Analyze the Source Component

### Identify the Full-Featured Component
Find the main, standalone list component that has all the features you need.

**Example**: `/src/views/calendar/tasks/list/index.tsx` (TasksList)

### Identify Duplicate Components
Find components that replicate the same functionality in different contexts.

**Example**: `/src/components/GenericTab/task/TasksDataTable.tsx`

### Find Existing Wrapper Examples
Look for components that already follow this pattern.

**Example**: `/src/views/sales/deals/view/tabs/tasks.tsx`

```tsx
import React from 'react';
import TasksList from '@/views/calendar/tasks/list';

const DealTasks = ({ data }) => {
  return <TasksList externalData={data}></TasksList>;
};

export default DealTasks;
```

---

## Step 2: Enhance the Source Component

### Add Props Interface

Add an interface to accept external configuration:

```tsx
interface TasksListProps {
  // Existing props
  data?: any;
  externalData?: any;

  // NEW: External search/filter args
  externalSearchArgs?: Array<any>;

  // NEW: Custom action handlers
  onCustomView?: (record: Task, event?: React.MouseEvent) => void;
  onCustomEdit?: (record: Task) => void;
  onCustomNew?: () => void;
}

const TasksList = (props: TasksListProps) => {
  const {
    externalSearchArgs = [],
    onCustomView,
    onCustomEdit,
    onCustomNew
  } = props;

  // ... rest of component
};
```

### Merge External Search Arguments

Update your search/filter logic to include external arguments:

```tsx
// BEFORE
const tableSearchArgs = useMemo(() => {
  const args = [...listFilters, ...search];
  // ... processing
  return args;
}, [listFilters, search]);

// AFTER
const tableSearchArgs = useMemo(() => {
  const args = [...listFilters, ...search, ...externalSearchArgs];
  // ... processing
  return args;
}, [listFilters, search, externalSearchArgs]);
```

### Add Conditional Custom Actions

Update action handlers to use custom handlers when provided:

```tsx
// For "New" button
ComponentCustom={
  onCustomNew ? (
    <ModuleActionNew
      onClick={onCustomNew}
      module={MODULE_NAME_SINGULAR}
    />
  ) : (
    <ModuleActionNew
      to={`${getListRoute(MODULE_NAME)}/new`}
      module={MODULE_NAME_SINGULAR}
    />
  )
}

// For table actions
actions={[
  {
    type: 'view',
    title: 'View details',
    onClick: (record: Task, event?: React.MouseEvent) => {
      if (onCustomView) {
        onCustomView(record, event);
      } else {
        // Default navigation logic
        navigate(`${getViewRoute(MODULE_NAME)}/${record?.id}`);
      }
    },
  },
  {
    type: 'edit',
    title: 'Edit',
    onClick: (record: Task) => {
      if (onCustomEdit) {
        onCustomEdit(record);
      } else {
        // Default navigation logic
        navigate(`${getListRoute(MODULE_NAME)}/${record.id}/edit`);
      }
    },
  },
  // ... other actions
]}
```

---

## Step 3: Update Supporting Components (if needed)

### Example: ModuleActionNew

If a supporting component needs enhancement, update it to support both patterns:

```tsx
// BEFORE - Only supports navigation
const ModuleActionNew = ({
  module,
  to,
  states,
  width = 'max-content',
}: {
  module: string;
  to: string;
  states?: any;
  width?: string;
}) => {
  return (
    <Link to={to} states={states}>
      {/* content */}
    </Link>
  );
};

// AFTER - Supports both navigation and onClick
const ModuleActionNew = ({
  module,
  to,
  onClick,
  states,
  width = 'max-content',
}: {
  module: string;
  to?: string;
  onClick?: () => void;
  states?: any;
  width?: string;
}) => {
  const content = (
    <Stack direction='row' sx={sx}>
      <PlusOutlined color='#FFF' />
      <Text color='#FFF'>{convertCase(module)}</Text>
    </Stack>
  );

  // If onClick is provided, render as clickable div
  if (onClick) {
    return (
      <div onClick={onClick} style={{ cursor: 'pointer' }}>
        {content}
      </div>
    );
  }

  // Otherwise render as Link
  return (
    <Link to={to || ''} states={states}>
      {content}
    </Link>
  );
};
```

---

## Step 4: Refactor the Duplicate Component

### Convert to Thin Wrapper

Replace all the duplicate logic with a simple wrapper:

```tsx
import React from 'react';
import TasksList from '@/views/calendar/tasks/list';
import Task from '@/models/Task';

interface TasksDataTableProps {
  id?: string;
  module?: string;
  tab?: string;
  setTab?: (val: string) => void;
  breadCrumbs?: string[];
  onNewTask?: () => void;
  onEditTask?: (task: Task) => void;
  onViewTask?: (task: Task, event?: React.MouseEvent) => void;
  searchArg?: Array<any>;
}

/**
 * TasksDataTable - A wrapper component that reuses TasksList
 * This component provides a way to embed the full tasks list functionality
 * in other contexts (like tabs in Deal/Account views) with custom action handlers.
 *
 * Pattern follows: /views/sales/deals/view/tabs/tasks.tsx
 */
const TasksDataTable: React.FC<TasksDataTableProps> = ({
  onNewTask,
  onEditTask,
  onViewTask,
  searchArg,
}) => {
  return (
    <TasksList
      externalData={true}
      externalSearchArgs={searchArg}
      onCustomNew={onNewTask}
      onCustomEdit={onEditTask}
      onCustomView={onViewTask}
    />
  );
};

export default TasksDataTable;
```

### Key Points:
- ✅ **Keep the original interface** - Maintains backward compatibility
- ✅ **Map props appropriately** - Connect wrapper props to source component props
- ✅ **Add documentation** - Explain the pattern and reference examples
- ✅ **Set `externalData={true}`** - Tells the source component it's being embedded

---

## Step 5: Verify the Refactoring

### 1. Type Check
```bash
yarn type-check
```

Look for errors related to your modified files:
```bash
yarn type-check 2>&1 | grep -E "(YourComponent|ModifiedFile)" || echo "No errors"
```

### 2. Find All Usages
```bash
# Find where the wrapper is imported
grep -r "import.*TasksDataTable" src/
```

### 3. Test Integration Points

Check a few usage examples to ensure the interface is compatible:

```tsx
// Example usage in /views/sales/deals/view/tabs/tasks/index.tsx
const DealsTasksTab: React.FC<DealsTasksTabProps> = props => {
  const { id } = useParams();
  const { navigate } = useNavigate('List');

  const handleNewTask = () => {
    navigate(`/sales/deals/${id}/tasks/new?module=deal&relatedToId=${id}`);
  };

  const handleEditTask = (task: Task) => {
    navigate(`/sales/deals/${id}/tasks/${task.id}/edit`);
  };

  const handleViewTask = (task: Task, event?: React.MouseEvent) => {
    const url = `/sales/deals/${id}/tasks/${task.id}`;
    if (event?.ctrlKey || event?.metaKey) {
      window.open(url, '_blank');
    } else {
      navigate(url);
    }
  };

  const searchArg = [
    {
      fieldName: 'deal.id',
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <TasksDataTable
      id={id}
      module='deals'
      onNewTask={handleNewTask}
      onEditTask={handleEditTask}
      onViewTask={handleViewTask}
      searchArg={searchArg}
    />
  );
};
```

---

## Common Patterns & Best Practices

### 1. External Data Mode

The source component should adapt its layout when `externalData={true}`:

```tsx
{!props.externalData && (
  <>
    <ListModuleHeader
      listTitle={MODULE_NAME}
      breadCrumbs={breadCrumbs}
      listSubtitle={MODULE_TAGLINE}
    />
    <Box px={5} pb='20px'>
      <ModuleCards cards={dashboardCards} />
    </Box>
  </>
)}

<Box padding={props.externalData ? '0px !important' : ''} px={5}>
  <Content
    $css={
      props.externalData
        ? 'padding: 0 !important; border: none !important'
        : 'padding: 20px 20px 0 20px !important;'
    }
  >
    {/* Table content */}
  </Content>
</Box>
```

### 2. Search Argument Merging

Always merge external search args at the end to allow overrides:

```tsx
const tableSearchArgs = useMemo(() => {
  // Internal filters and search come first
  const args = [...listFilters, ...search, ...externalSearchArgs];

  // Process/convert as needed
  return args.map(arg => {
    if (arg.comparator === SearchComparator.BETWEEN) {
      return {
        ...arg,
        searchValue: dayjs.isDayjs(arg.searchValue)
          ? arg.searchValue.toISOString()
          : arg.searchValue,
        searchValue1: dayjs.isDayjs(arg.searchValue1)
          ? arg.searchValue1.toISOString()
          : arg.searchValue1,
      };
    }
    return arg;
  });
}, [listFilters, search, externalSearchArgs]);
```

### 3. Conditional Handler Execution

Always check if custom handler exists before falling back to default:

```tsx
const handleAction = (record: Record) => {
  if (onCustomAction) {
    onCustomAction(record);
  } else {
    // Default behavior
    navigate(defaultPath);
  }
};
```

### 4. Prop Mapping

Map wrapper props to source component props clearly:

| Wrapper Prop | Source Prop | Purpose |
|--------------|-------------|---------|
| `searchArg` | `externalSearchArgs` | Additional filters |
| `onNewTask` | `onCustomNew` | Custom new action |
| `onEditTask` | `onCustomEdit` | Custom edit action |
| `onViewTask` | `onCustomView` | Custom view action |
| N/A | `externalData={true}` | Enables embedded mode |

---

## Benefits of This Pattern

### Code Reduction
- **Before**: 750 lines of duplicate logic per wrapper
- **After**: ~40 lines per wrapper
- **Savings**: ~95% code reduction

### Maintainability
- ✅ Single source of truth for features
- ✅ Bug fixes apply everywhere automatically
- ✅ New features added once, available everywhere
- ✅ Consistent UX across all contexts

### Flexibility
- ✅ Supports both standalone and embedded modes
- ✅ Custom actions for different contexts
- ✅ Additional filtering per use case
- ✅ Backward compatible with existing code

---

## Checklist for Refactoring

Use this checklist when converting components:

### Planning Phase
- [ ] Identify the full-featured source component
- [ ] Identify all duplicate components
- [ ] Find existing wrapper examples
- [ ] Document current usage patterns
- [ ] List required custom behaviors

### Implementation Phase
- [ ] Add interface to source component with optional props
- [ ] Add `externalSearchArgs` support
- [ ] Add custom handler props (`onCustomView`, `onCustomEdit`, `onCustomNew`)
- [ ] Update action handlers to check for custom handlers
- [ ] Update supporting components if needed
- [ ] Refactor wrapper to delegate to source
- [ ] Add documentation comments
- [ ] Maintain original wrapper interface

### Verification Phase
- [ ] Run TypeScript type checking
- [ ] Check for errors in modified files
- [ ] Find all usages of the wrapper
- [ ] Test integration in 2-3 usage examples
- [ ] Verify custom handlers work correctly
- [ ] Verify external search args work correctly
- [ ] Verify default behavior still works
- [ ] Check responsive design/layout

---

## Examples in Codebase

### Successfully Refactored

| Component | Source | Wrapper | LOC Saved |
|-----------|--------|---------|-----------|
| Tasks | `/views/calendar/tasks/list` | `/components/GenericTab/task/TasksDataTable.tsx` | ~700 |
| Deals (reference) | `/views/sales/deals/list` | `/views/sales/deals/view/tabs/tasks.tsx` | N/A |

### Candidates for Refactoring

The following components follow the same pattern and can be refactored using this guide:

#### 1. Activities Module
- **Source Component**: `/src/views/activities/list/index.tsx` (ActivitiesList)
- **Wrapper Component**: `/src/components/GenericTab/activties/ActivitiesDataTable.tsx`
- **Usage Count**: 29+ locations across modules
- **Custom Props Needed**:
  - `onNewActivity?: (activityType: string) => void` - Note: activityType parameter
  - `onEditActivity?: (activity: ActivityModel) => void`
  - `onViewActivity?: (activity: ActivityModel) => void`
  - `recipients?: any[]` - Additional recipient data
- **Special Considerations**:
  - Activities have multiple types (calls, notes, emails, SMS)
  - Need to handle dropdown for "New Activity" with type selection
  - May require `activityType` parameter in custom handlers

#### 2. Events Module
- **Source Component**: `/src/views/calendar/events/list/index.tsx` (EventsList)
- **Wrapper Component**: `/src/components/GenericTab/events/EventsDataTable.tsx`
- **Usage Count**: Multiple locations for embedded event views
- **Custom Props Needed**:
  - `onNewEvent?: () => void`
  - `onEditEvent?: (event: EventModel) => void`
  - `onViewEvent?: (event: EventModel) => void`
  - `searchArg?: Array<any>` - Filter by related entity
- **Special Considerations**:
  - Events may have calendar integration
  - Handle recurring events logic
  - Time zone considerations

#### 3. Documents Module
- **Source Component**: `/src/views/documents/list/index.tsx` (DocumentsList)
- **Wrapper Component**: `/src/components/GenericTab/document/DocumentsDataTable.tsx`
- **Usage Count**: 24+ locations across modules
- **Custom Props Needed**:
  - `onNewDocument?: () => void`
  - `onEditDocument?: (document: DocumentModel) => void`
  - `onViewDocument?: (document: DocumentModel) => void`
  - `onUpload?: () => void` - Custom upload handler
- **Special Considerations**:
  - Document upload functionality
  - File type filtering
  - Download/preview actions

#### 4. Jobs Module
- **Source Component**: `/src/views/jobs/jobs/list/index.tsx` (JobsList)
- **Wrapper Component**: Potential - check for GenericTab implementation
- **Custom Props Needed**:
  - `onNewJob?: () => void`
  - `onEditJob?: (job: JobModel) => void`
  - `onViewJob?: (job: JobModel) => void`
  - `searchArg?: Array<any>` - Filter by related entity

#### 5. Other Potential Candidates

Check these locations for similar patterns:
- **Cases**: `/views/customer-service/case/list` vs GenericTab version
- **Quotes**: Multiple quote list implementations
- **Invoices/Bills**: Finance module list views
- **Purchase Orders**: Inventory module list views

### Identification Checklist

Look for these patterns to identify candidates:
- ✅ Components with "DataTable" or "List" suffix in different directories
- ✅ Duplicate GraphQL queries (check for `PAGINATED_*`, `ALL_*` query patterns)
- ✅ Duplicate state management (`useState` with similar patterns)
- ✅ Similar filter logic across components
- ✅ Copy-pasted action configurations
- ✅ Multiple tab implementations importing the same wrapper component

### Quick Scan Command

Use this to find potential candidates:
```bash
# Find all GenericTab DataTable components
find src/components/GenericTab -name "*DataTable.tsx"

# Find corresponding list views
find src/views -path "*/list/index.tsx" | grep -E "(activities|events|documents|jobs|quotes|invoices)"

# Count usage of a GenericTab component
grep -r "ActivitiesDataTable" src/views | wc -l
```

---

## Module-Specific Implementation Notes

### Activities Module - Special Handling

Activities are more complex because they have multiple types. Here's how to handle them:

```tsx
// Source component enhancement
interface ActivitiesListProps {
  externalSearchArgs?: Array<any>;
  onCustomView?: (activity: ActivityModel) => void;
  onCustomEdit?: (activity: ActivityModel) => void;
  onCustomNew?: (activityType?: string) => void; // Note: optional activityType
}

// In the source component's "New" button section
ComponentCustom={
  onCustomNew ? (
    // Custom dropdown for multiple activity types
    <Dropdown
      menu={{
        items: [
          {
            key: 'note',
            label: 'Note',
            onClick: () => onCustomNew('note'),
          },
          {
            key: 'email',
            label: 'Email',
            onClick: () => onCustomNew('email'),
          },
          {
            key: 'sms',
            label: 'SMS',
            onClick: () => onCustomNew('sms'),
          },
          {
            key: 'call',
            label: 'Call',
            onClick: () => onCustomNew('call'),
          },
        ],
      }}
      trigger={['click']}
    >
      <Button type='primary'>
        <PlusOutlined /> New Activity <DownOutlined />
      </Button>
    </Dropdown>
  ) : (
    // Default dropdown...
  )
}
```

### Events Module - Recurring Events

Events may have recurring logic similar to tasks:

```tsx
interface EventsListProps {
  externalSearchArgs?: Array<any>;
  onCustomView?: (event: EventModel, event?: React.MouseEvent) => void;
  onCustomEdit?: (event: EventModel, recurringOption?: 'this' | 'following' | 'all') => void;
  onCustomNew?: () => void;
}

// Handle edit with recurring options
{
  type: 'edit',
  title: 'Edit',
  onClick: (record: EventModel) => {
    if (onCustomEdit) {
      onCustomEdit(record);
    } else {
      // Default logic
    }
  },
  // Add recurring event submenu if applicable
  children: (record: EventModel) => {
    if (!record.isRecurring) return undefined;

    return [
      {
        key: 'edit-this',
        label: 'This event',
        onClick: () => {
          if (onCustomEdit) {
            onCustomEdit(record, 'this');
          }
        },
      },
      // ... more options
    ];
  },
}
```

### Documents Module - Upload Actions

Documents need special handling for uploads:

```tsx
interface DocumentsListProps {
  externalSearchArgs?: Array<any>;
  onCustomView?: (document: DocumentModel) => void;
  onCustomEdit?: (document: DocumentModel) => void;
  onCustomNew?: () => void;
  onCustomUpload?: (files: File[]) => void; // Additional upload handler
}

// In the source component
ComponentCustom={
  <Stack direction='row' spacing={1}>
    {onCustomNew ? (
      <Button type='primary' onClick={onCustomNew}>
        <PlusOutlined /> New Document
      </Button>
    ) : (
      <Link to={`${getListRoute(MODULE_NAME)}/new`}>
        <Button type='primary'>
          <PlusOutlined /> New Document
        </Button>
      </Link>
    )}

    {onCustomUpload && (
      <Upload
        customRequest={({ file }) => {
          onCustomUpload([file as File]);
        }}
        showUploadList={false}
      >
        <Button icon={<UploadOutlined />}>
          Quick Upload
        </Button>
      </Upload>
    )}
  </Stack>
}
```

### Jobs Module - Status Workflow

Jobs may have complex status workflows:

```tsx
interface JobsListProps {
  externalSearchArgs?: Array<any>;
  onCustomView?: (job: JobModel) => void;
  onCustomEdit?: (job: JobModel) => void;
  onCustomNew?: () => void;
  onCustomStatusChange?: (job: JobModel, newStatus: string) => void;
}

// Status change actions
{
  type: 'group',
  title: 'Change Status',
},
{
  type: 'custom',
  title: 'Mark as In Progress',
  show: (record: JobModel) => record.status === 'New',
  onClick: (record: JobModel) => {
    if (onCustomStatusChange) {
      onCustomStatusChange(record, 'In Progress');
    } else {
      // Default status change logic
    }
  },
}
```

---

## Troubleshooting

### Issue: TypeScript errors after refactoring

**Solution**: Ensure all prop types match between wrapper and source:
```tsx
// Wrapper interface should match what's passed to source
interface WrapperProps {
  searchArg?: Array<any>; // Maps to externalSearchArgs
}

// Source interface
interface SourceProps {
  externalSearchArgs?: Array<any>;
}
```

### Issue: Custom handlers not firing

**Solution**: Check the action configuration uses the handler:
```tsx
{
  type: 'view',
  onClick: (record: Task, event?: React.MouseEvent) => {
    if (onCustomView) {
      onCustomView(record, event); // Make sure this is called
    } else {
      // default
    }
  },
}
```

### Issue: Layout issues in embedded mode

**Solution**: Ensure `externalData` mode adjusts styles:
```tsx
<Content
  $css={
    props.externalData
      ? 'padding: 0 !important; border: none !important'
      : 'padding: 20px 20px 0 20px !important;'
  }
>
```

### Issue: Filters not applying

**Solution**: Verify external search args are merged:
```tsx
const tableSearchArgs = useMemo(() => {
  const args = [...listFilters, ...search, ...externalSearchArgs];
  return args;
}, [listFilters, search, externalSearchArgs]); // Include in deps!
```

---

## Related Documentation

- [Git Branching Strategy](../CLAUDE.md#git-branching-strategy)
- [Component Organization](../CLAUDE.md#project-structure)
- [GraphQL Integration](../CLAUDE.md#working-with-graphql)
- [Testing Strategy](../CLAUDE.md#testing-strategy)

---

## Revision History

| Date | Author | Changes |
|------|--------|---------|
| 2025-01-04 | Claude Code | Initial documentation - TasksDataTable refactoring |
| 2025-01-04 | Claude Code | Added module-specific sections for Activities, Events, Documents, Jobs |
| 2025-01-04 | Claude Code | Added Quick Reference table with conversion status for all modules |

---

## Summary

**Yes, this document will help convert other modules!**

The document now includes:
- ✅ Generic step-by-step guide applicable to any module
- ✅ Module-specific implementation notes for Activities, Events, Documents, Jobs
- ✅ Quick Reference table showing conversion readiness for each module
- ✅ Specific considerations for each module type:
  - Activities: Multi-type dropdown (notes, emails, SMS, calls)
  - Events: Recurring events handling
  - Documents: Upload functionality
  - Jobs: Status workflow management
- ✅ Code examples for special cases
- ✅ Identification commands to find candidates
- ✅ Complete checklist for each conversion

**Estimated Impact**:
- Activities: ~700 LOC saved (29+ usage locations)
- Events: ~500 LOC saved (multiple usage locations)
- Documents: ~600 LOC saved (24+ usage locations)
- **Total Potential**: ~1,800+ additional lines of duplicate code that can be eliminated

**Note**: This pattern was successfully applied to TasksDataTable → TasksList refactoring. Use this as a reference for similar component consolidation efforts across Activities, Events, Documents, Jobs, and other modules.
