# CSV Export Guidelines for Record Lists

This document provides guidelines for implementing CSV export functionality in record list components using GraphQL CSV endpoints.

## Overview

CSV export functionality should use GraphQL CSV endpoints rather than manual frontend data mapping for better performance, scalability, and maintainability.

## Implementation Steps

### 1. GraphQL CSV Endpoint

First, add the CSV endpoint to your GraphQL file:

```typescript
// src/graphql/yourModule.gql.ts
export const GET_YOUR_MODULE_CSV = gql`
  query ${TENANT_PREFIX}YourModuleCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}YourModuleCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;
```

**Important Notes:**
- Check the GraphQL schema to determine the correct query name (singular or plural form)
- Common patterns: `${TENANT_PREFIX}ModuleNameCSV` or `${TENANT_PREFIX}ModuleNamesCSV`
- The endpoint accepts `columnArg`, `searchArg`, and `sortArg` parameters

### 2. Export Fields Configuration

Define export fields in your module's fields file:

```typescript
// src/views/yourModule/common/fields.ts
export const exportFields = [
  {
    title: 'Field Display Name',
    field: 'fieldName',
  },
  {
    title: 'Transformed Field',
    field: 'nestedField',
    transform: (data) => data?.name || '',
  },
  {
    title: 'Count Field',
    field: 'relatedItems',
    transform: (data) => data?.length || 0,
  },
  {
    title: 'Date Field',
    field: 'updatedAt',
    transform: (data) => data && dayjs(data).format(dateTimeFormat),
  },
];
```

**Field Configuration:**
- `title`: Column header in the CSV file
- `field`: The field name from your data model
- `transform` (optional): Function to transform the data before export

### 3. List Component Implementation

Update your list component to use the CSV endpoint:

```typescript
// src/views/yourModule/list/index.tsx
import { GET_YOUR_MODULE_CSV } from '@/graphql/yourModule.gql';
import { apolloFetch } from '@/graphql/service';
import { saveCSVFile } from '@/services/export.services';
import { exportFields } from '../common/fields';

const YourModuleList = () => {
  // ... existing code ...

  return (
    <ModuleActions
      // ... other props ...
      onCustomExport={async () => {
        try {
          const columnArg = exportFields.map(column => ({
            fieldLabel: column.title,
            fieldName: column.field,
          }));
          
          const recordsBlob = await apolloFetch<string>(GET_YOUR_MODULE_CSV, {
            columnArg,
            sortArg,
            searchArg: search,
          });

          if ('data' in recordsBlob) {
            saveCSVFile(recordsBlob.data, 'YourModuleName');
            snackbar({
              type: 'success',
              message: 'Data exported successfully!',
            });
          }
        } catch (error) {
          console.error('Export error:', error);
          snackbar({
            type: 'error',
            message: 'Failed to export data.',
          });
        }
      }}
    />
  );
};
```

### 4. Required Imports

Ensure you have the necessary imports:

```typescript
import { apolloFetch } from '@/graphql/service';
import { saveCSVFile } from '@/services/export.services';
import { GET_YOUR_MODULE_CSV } from '@/graphql/yourModule.gql';
import { exportFields } from '../common/fields';
```

## Best Practices

### 1. Error Handling

Always implement proper error handling:

```typescript
try {
  // CSV export logic
} catch (error) {
  console.error('Export error:', error);
  snackbar({
    type: 'error',
    message: 'Failed to export data.',
  });
}
```

### 2. User Feedback

Provide clear feedback to users:

```typescript
// Success message
snackbar({
  type: 'success',
  message: 'Data exported successfully!',
});

// Error message
snackbar({
  type: 'error',
  message: 'Failed to export data.',
});
```

### 3. Data Transformation

Use transform functions for complex data:

```typescript
{
  title: 'Related Items Count',
  field: 'relatedItems',
  transform: (data) => Array.isArray(data) ? data.length : 0,
},
{
  title: 'Formatted Date',
  field: 'createdAt',
  transform: (data) => data ? dayjs(data).format('YYYY-MM-DD HH:mm') : '',
},
{
  title: 'Nested Object',
  field: 'user',
  transform: (data) => data ? `${data.firstName} ${data.lastName}` : '',
},
```

### 4. Field Naming

Follow consistent naming conventions:

```typescript
// Good
{
  title: 'Account Name',
  field: 'accountName',
}

// Avoid
{
  title: 'Account Name',
  field: 'account.name', // Nested fields should use transform
}
```

## Common Patterns

### 1. Count Fields

For counting related items:

```typescript
{
  title: 'Specifications Count',
  field: 'specifications',
  transform: (data) => data?.length || 0,
}
```

### 2. Date Fields

For date formatting:

```typescript
{
  title: 'Updated At',
  field: 'updatedAt',
  transform: (data) => data && dayjs(data).format(dateTimeFormat),
}
```

### 3. Boolean Fields

For boolean values:

```typescript
{
  title: 'Active Status',
  field: 'isActive',
  transform: (data) => data ? 'Yes' : 'No',
}
```

### 4. Nested Object Fields

For nested object properties:

```typescript
{
  title: 'Contact Name',
  field: 'contact',
  transform: (data) => data ? `${data.firstName} ${data.lastName}` : '',
}
```

## Troubleshooting

### Common Issues

1. **GraphQL Validation Error**
   - Check the GraphQL schema to determine the correct query name (singular or plural form)
   - Common examples: `abmsDealTemplateCSV` (singular) vs `abmsDealTemplatesCSV` (plural)
   - Verify that the field name exists in the GraphQL schema

2. **Missing Fields**
   - Verify that all fields in `exportFields` exist in your data model
   - Use transform functions for computed or nested fields

3. **Export Button Not Showing**
   - Ensure `onCustomExport` is properly passed to `ModuleActions`
   - Check that the function is not throwing errors during initialization

4. **Empty CSV File**
   - Verify that `columnArg` is properly formatted
   - Check that `searchArg` and `sortArg` are correctly passed

### Debugging

Add console logs for debugging:

```typescript
onCustomExport={async () => {
  try {
    console.log('Export fields:', exportFields);
    console.log('Column arg:', columnArg);
    console.log('Search arg:', search);
    console.log('Sort arg:', sortArg);
    
    // ... rest of export logic
  } catch (error) {
    console.error('Export error:', error);
  }
}}
```

## Example Implementation

Here's a complete example for a deal templates module:

```typescript
// src/graphql/dealTemplates.gql.ts
export const GET_DEAL_TEMPLATES_CSV = gql`
  query ${TENANT_PREFIX}DealTemplateCSV($columnArg: [${TENANT_PREFIX}ColumnArg!], $searchArg: [${TENANT_PREFIX}SearchArg!], $sortArg: [${TENANT_PREFIX}SortArg!]) {
    ${TENANT_PREFIX}DealTemplateCSV(columnArg: $columnArg, searchArg: $searchArg, sortArg: $sortArg)
  }
`;

// Note: This example uses singular form (DealTemplateCSV) based on the GraphQL schema
// Other modules might use plural form (e.g., DealTemplatesCSV) - always check the schema

// src/views/settings/dealTemplates/common/fields.ts
export const exportFields = [
  {
    title: 'Deal Template',
    field: 'dealTemplate',
  },
  {
    title: 'Description',
    field: 'description',
  },
  {
    title: 'Details Count',
    field: 'dealTemplateDetails',
    transform: (data) => data?.length || 0,
  },
  {
    title: 'Specifications Count',
    field: 'dealTemplateSpecifications',
    transform: (data) => data?.length || 0,
  },
  {
    title: 'Updated At',
    field: 'updatedAt',
    transform: (data) => data && dayjs(data).format(dateTimeFormat),
  },
];

// src/views/settings/dealTemplates/list/index.tsx
import { GET_DEAL_TEMPLATES_CSV } from '@/graphql/dealTemplates.gql';
import { apolloFetch } from '@/graphql/service';
import { saveCSVFile } from '@/services/export.services';

const DealTemplatesList = () => {
  return (
    <ModuleActions
      onCustomExport={async () => {
        try {
          const columnArg = exportFields.map(column => ({
            fieldLabel: column.title,
            fieldName: column.field,
          }));
          
          const recordsBlob = await apolloFetch<string>(GET_DEAL_TEMPLATES_CSV, {
            columnArg,
            sortArg,
            searchArg: search,
          });

          if ('data' in recordsBlob) {
            saveCSVFile(recordsBlob.data, 'DealTemplates');
            snackbar({
              type: 'success',
              message: 'Deal templates exported successfully!',
            });
          }
        } catch (error) {
          console.error('Export error:', error);
          snackbar({
            type: 'error',
            message: 'Failed to export deal templates data.',
          });
        }
      }}
    />
  );
};
```

## Summary

- Use GraphQL CSV endpoints instead of manual frontend mapping
- Define export fields with proper transformations
- Implement proper error handling and user feedback
- Follow naming conventions and best practices
- Test thoroughly with various data scenarios

This approach ensures efficient, scalable, and maintainable CSV export functionality across all record list components. 