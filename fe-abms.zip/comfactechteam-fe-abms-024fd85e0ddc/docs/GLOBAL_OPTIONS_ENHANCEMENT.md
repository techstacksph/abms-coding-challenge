# Global Options Enhancement: Deal Types and Workflow Statuses

## Overview

This document describes the enhancement made to the global options system to support deal types and workflow statuses. The implementation follows the existing pattern established for other global options (locations, accounts, areas, etc.) and provides centralized, cached data management for these commonly used options.

## Background

Previously, components like the deals list were making individual GraphQL queries for deal types and workflow statuses using `useQuery` hooks. This approach had several drawbacks:

- **Performance**: Multiple components making the same queries
- **Consistency**: No guarantee that all components have the same data
- **Code Duplication**: Repeated query logic across components
- **Cache Management**: Individual cache management per component

## Solution

Extended the existing global options system to include deal types and workflow statuses, providing:

- Centralized data fetching and caching
- On-demand loading (only fetch when requested)
- Consistent data across all components
- Efficient cache management

## Changes Made

### 1. Global Options Store (`src/stores/globalOptionsStore.ts`)

#### Added State Properties
```typescript
interface GlobalOptionsState {
  // New state properties
  dealTypes: DealTypeModel[];
  workflowStatuses: WorkflowStatusModel[];
  dealTypesLoading: boolean;
  workflowStatusesLoading: boolean;
  
  // New helper actions
  _fetchDealTypes: (client: ApolloClient<any>, fetchPolicy: 'cache-first' | 'network-only') => Promise<void>;
  _fetchWorkflowStatuses: (client: ApolloClient<any>, fetchPolicy: 'cache-first' | 'network-only', code: string) => Promise<void>;
  
  // New public actions
  fetchDealTypes: (client: ApolloClient<any>) => Promise<void>;
  fetchWorkflowStatuses: (client: ApolloClient<any>, code: string) => Promise<void>;
  refreshDealTypes: (client: ApolloClient<any>) => Promise<void>;
  refreshWorkflowStatuses: (client: ApolloClient<any>, code: string) => Promise<void>;
  
  // New setters
  setDealTypes: (dealTypes: DealTypeModel[]) => void;
  setWorkflowStatuses: (workflowStatuses: WorkflowStatusModel[]) => void;
}
```

#### Implementation Details

**Deal Types Fetching**
```typescript
_fetchDealTypes: async (client, fetchPolicy: 'cache-first' | 'network-only') => {
  set({ dealTypesLoading: true });
  
  try {
    const { data } = await client.query({
      query: SELECT_DEAL_TYPE,
      fetchPolicy,
    });
    
    const [, dealTypes] = Object.entries(data)[0] as [string, DealTypeModel[]];
    
    set({
      dealTypes: dealTypes || [],
      dealTypesLoading: false,
    });
  } catch (error) {
    console.error('Error with deal types:', error);
    set({ dealTypesLoading: false });
  }
}
```

**Workflow Statuses Fetching**
```typescript
_fetchWorkflowStatuses: async (client, fetchPolicy: 'cache-first' | 'network-only', code: string) => {
  set({ workflowStatusesLoading: true });
  
  try {
    const { data } = await client.query({
      query: GET_WORKFLOW_STATUS,
      variables: { code },
      fetchPolicy,
    });
    
    const [, workflowStatuses] = Object.entries(data)[0] as [string, WorkflowStatusModel[]];
    
    set({
      workflowStatuses: workflowStatuses || [],
      workflowStatusesLoading: false,
    });
  } catch (error) {
    console.error('Error with workflow statuses:', error);
    set({ workflowStatusesLoading: false });
  }
}
```

### 2. Global Options Hook (`src/hooks/useGlobalOptions.ts`)

#### Extended Interface
```typescript
interface UseGlobalOptionsParams {
  locations?: boolean;
  accounts?: boolean;
  areas?: boolean;
  users?: boolean;
  sites?: boolean;
  contacts?: boolean;
  dealTypes?: boolean;              // New
  workflowStatuses?: boolean;       // New
  workflowStatusCode?: string;      // New - required when workflowStatuses is true
}
```

#### On-Demand Fetching
```typescript
// Deal Types
useEffect(() => {
  if (
    params.dealTypes &&
    dealTypes.length === 0 &&
    !dealTypesLoading &&
    !dealTypesInitiated.current
  ) {
    dealTypesInitiated.current = true;
    fetchDealTypes(client);
  }
}, [params.dealTypes]);

// Workflow Statuses
useEffect(() => {
  if (
    params.workflowStatuses &&
    workflowStatuses.length === 0 &&
    !workflowStatusesLoading &&
    !workflowStatusesInitiated.current &&
    params.workflowStatusCode
  ) {
    workflowStatusesInitiated.current = true;
    fetchWorkflowStatuses(client, params.workflowStatusCode);
  }
}, [params.workflowStatuses, params.workflowStatusCode]);
```

#### Return Values
```typescript
return {
  // Data
  dealTypes: params.dealTypes ? dealTypes : [],
  workflowStatuses: params.workflowStatuses ? workflowStatuses : [],
  
  // Loading states
  dealTypesLoading: params.dealTypes ? dealTypesLoading : false,
  workflowStatusesLoading: params.workflowStatuses ? workflowStatusesLoading : false,
  
  // Refresh methods
  refreshDealTypes: () => refreshDealTypes(client),
  refreshWorkflowStatuses: (code: string) => refreshWorkflowStatuses(client, code),
};
```

### 3. Updated Deals List (`src/views/sales/deals/list/index.tsx`)

#### Before (Multiple useQuery hooks)
```typescript
const { data: dbUsers } = useQuery<Array<User>>({
  query: ALL_USERS,
});
const { data: dbEventType } = useQuery<Array<DealTypeModel>>({
  query: SELECT_DEAL_TYPE,
});
const { locations: dbLocations } = useGlobalOptions({ locations: true });
const { data: dbStatus } = useQuery<Array<WorkflowStatusModel>>({
  query: GET_WORKFLOW_STATUS,
  options: {
    variables: {
      code: 'deal',
    },
  },
});
```

#### After (Single useGlobalOptions hook)
```typescript
const {
  locations: dbLocations,
  users: dbUsers,
  dealTypes: dbEventType,
  workflowStatuses: dbStatus,
} = useGlobalOptions({
  locations: true,
  users: true,
  dealTypes: true,
  workflowStatuses: true,
  workflowStatusCode: 'deal',
});
```

## Usage Examples

### Basic Usage
```typescript
// For components that only need deal types
const { dealTypes, dealTypesLoading } = useGlobalOptions({
  dealTypes: true,
});

// For components that need workflow statuses
const { workflowStatuses, workflowStatusesLoading } = useGlobalOptions({
  workflowStatuses: true,
  workflowStatusCode: 'deal', // Required parameter
});
```

### Combined Usage
```typescript
// For components that need multiple options
const {
  locations,
  users,
  dealTypes,
  workflowStatuses,
  isLoading
} = useGlobalOptions({
  locations: true,
  users: true,
  dealTypes: true,
  workflowStatuses: true,
  workflowStatusCode: 'deal',
});
```

### Using Convenience Hooks
```typescript
// Updated convenience hook includes all options
const allOptions = useAllGlobalOptions(); // Now includes dealTypes and workflowStatuses

// Basic options for common cases
const basicOptions = useBasicGlobalOptions(); // locations and accounts
```

## Benefits

### Performance Improvements
- **Reduced Network Requests**: Data is fetched once and cached globally
- **Faster Subsequent Loads**: Components using cached data load instantly
- **Optimized Bundle Size**: Removed duplicate query definitions

### Developer Experience
- **Consistent API**: Same pattern as existing global options
- **Type Safety**: Full TypeScript support with proper type inference
- **Simple Integration**: Easy to adopt in existing components

### Maintainability
- **Centralized Logic**: All global data fetching in one place
- **Reduced Code Duplication**: No need to repeat query logic
- **Easy Testing**: Centralized state management simplifies testing

## Migration Guide

### For New Components
Use the global options hook instead of individual queries:

```typescript
// ✅ Recommended
const { dealTypes, workflowStatuses } = useGlobalOptions({
  dealTypes: true,
  workflowStatuses: true,
  workflowStatusCode: 'deal',
});

// ❌ Avoid
const { data: dealTypes } = useQuery({ query: SELECT_DEAL_TYPE });
const { data: workflowStatuses } = useQuery({ 
  query: GET_WORKFLOW_STATUS,
  variables: { code: 'deal' }
});
```

### For Existing Components
Gradually migrate existing `useQuery` calls to use global options:

1. Replace individual queries with `useGlobalOptions`
2. Remove unused imports
3. Update variable names if necessary
4. Test functionality

## GraphQL Queries Used

### Deal Types
- **Query**: `SELECT_DEAL_TYPE` from `@/graphql/deals.gql`
- **Returns**: Array of `DealTypeModel` with `id`, `name`, and `code`

### Workflow Statuses
- **Query**: `GET_WORKFLOW_STATUS` from `@/graphql/module.gql`
- **Variables**: `{ code: string }` (e.g., 'deal')
- **Returns**: Array of `WorkflowStatusModel` with `id` and `name`

## Error Handling

Both implementations include proper error handling:

```typescript
try {
  // Fetch data
} catch (error) {
  console.error('Error with [resource]:', error);
  set({ [resource]Loading: false });
}
```

Errors are logged to the console and loading states are properly reset.

## Future Enhancements

### Potential Additions
- **Cache Invalidation**: Automatic refresh on data changes
- **Selective Refresh**: Refresh individual options without full reload
- **Background Sync**: Periodic data synchronization
- **Error Recovery**: Automatic retry on network failures

### Other Modules
This pattern can be extended to other commonly used options:
- Product categories
- Service types
- Priority levels
- Assignment types

## Testing Considerations

### Unit Tests
- Test fetch functions with mocked Apollo client
- Verify loading states during fetch operations
- Test error handling scenarios

### Integration Tests
- Test component behavior with global options
- Verify data consistency across components
- Test refresh functionality

### Performance Tests
- Measure improvement in load times
- Verify reduced network requests
- Test with large datasets

## Conclusion

The global options enhancement successfully provides a scalable, performant solution for managing commonly used dropdown options. The implementation follows established patterns, maintains backward compatibility, and provides significant performance and maintainability benefits.

The centralized approach ensures data consistency across the application while reducing code duplication and improving the developer experience. 