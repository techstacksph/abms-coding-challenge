# GenericTab Activities Components

This directory contains reusable activity components that can be used across different modules in the application. These components provide a unified interface for creating, editing, viewing, and listing activities (emails, SMS, calls, notes).

## Important Path Structure Note

**CRITICAL**: Instead of guessing or hardcoding paths, always use the `getViewRoute` function from `@/mfe-utilities` to get the correct URL. This ensures type safety and consistency across the application.

**Example**: 
```tsx
import { getViewRoute } from '@/mfe-utilities';

// ✅ CORRECT - Use getViewRoute
const parentViewPageUrl = `${getViewRoute('Account')}/${id}`;
const redirectUrl = `${getViewRoute('Account')}/${id}/activities`;

// ❌ INCORRECT - Don't hardcode paths
const parentViewPageUrl = `/accounts/${id}`;
const redirectUrl = `/accounts/${id}/activities`;
```

## Components Overview

### 1. ActivityForm
A reusable form component for creating and editing activities.

**Props:**
- `mode`: 'new' | 'edit' - The form mode
- `activityType`: string - The type of activity (email, sms, calls, note)
- `module`: string - The module code (e.g., 'event', 'account', 'deal')
- `breadCrumbs`: string[] - Breadcrumb navigation
- `recipients`: any[] - List of recipients (optional)
- `initialRecipientData`: any - Initial recipient data (optional)
- `initialWatcherData`: any - Initial watcher data (optional)
- `id`: string - Activity ID (required for edit mode)
- `redirectUrl`: string - Base URL for navigation after save (e.g., `/calendar/events/123/activities`)

### 2. ActivityFormWrapper
A wrapper around ActivityForm that provides callback support for new, edit, and cancel actions.

**Props:**
- All props from ActivityForm
- `onNewActivity`: (activityType: string, data: any) => void - Callback for new activity creation
- `onEditActivity`: (activityId: string, data: any) => void - Callback for activity editing
- `onCancel`: () => void - Callback for form cancellation

### 3. ActivitiesDataTable
A reusable data table component for displaying and managing activities.

**Props:**
- `id`: string - The parent record ID
- `module`: string - The module code
- `tab`: string - Current tab (optional)
- `setTab`: (val: string) => void - Tab setter function (optional)
- `breadCrumbs`: string[] - Breadcrumb navigation (optional)
- `recipients`: any[] - List of recipients (optional)
- `onEditActivity`: (activity: ActivityModel) => void - Callback for edit activity (optional)

**Note**: `onNewActivity` and `onViewActivity` callbacks are no longer needed as the ActivitiesDataTable component handles navigation internally based on the module configuration.

### 4. ActivityView
A generic component for viewing activity details.

**Props:**
- `breadCrumbs`: string[] - Breadcrumb navigation
- `parentViewPageUrl`: string - URL of the parent view page
- `activityId`: string - The activity ID to view
- `findDocumentsFunction`: (allDocumentsIdsData: any[], targetId: string) => any[] - Function to filter documents

### 5. ActivityViewNote
A generic component for viewing note details.

**Props:**
- `breadCrumbs`: string[] - Breadcrumb navigation
- `parentViewPageUrl`: string - URL of the parent view page
- `activityId`: string - The activity ID to view

## Module Setup Requirements

### 0. Required Folder Structure

**CRITICAL**: The folder structure for activity components must follow the standardized pattern used throughout the codebase. This ensures proper lazy loading and consistent imports.

#### Required Folder Structure:
```
/your-module/view/tabs/activities/
├── list/index.tsx
├── new/index.tsx
├── edit/index.tsx
├── view/index.tsx
└── view/note/index.tsx
```

#### Examples of Correct Structure:

**Training Activities:**
```
/trainings/view/tabs/activities/
├── list/index.tsx
├── new/index.tsx
├── edit/index.tsx
├── view/index.tsx
└── view/note/index.tsx
```

**Franchisee Management Activities:**
```
/franchisee-management/view/tabs/Activities/
├── list/index.tsx
├── new/index.tsx
├── edit/index.tsx
├── view/index.tsx
└── view/note/index.tsx
```

**Evaluation Activities:**
```
/Evaluations/view/tabs/activities/
├── list/index.tsx
├── new/index.tsx
├── edit/index.tsx
├── view/index.tsx
└── ViewNote.tsx
```

#### Lazy Loading Import Pattern:
```tsx
// In lazyComponents.tsx
export const YourModuleActivityList = lazy(
  () => import('./your-module/view/tabs/activities/list/index')
);
export const YourModuleActivityNew = lazy(
  () => import('./your-module/view/tabs/activities/new/index')
);
export const YourModuleActivityEdit = lazy(
  () => import('./your-module/view/tabs/activities/edit/index')
);
export const YourModuleActivityView = lazy(
  () => import('./your-module/view/tabs/activities/view/index')
);
export const YourModuleActivityViewNote = lazy(
  () => import('./your-module/view/tabs/activities/view/note/index')
);
```

**⚠️ Important Notes:**
- Each component must be in its own subdirectory with an `index.tsx` file
- The note component goes in `view/note/index.tsx` (not directly in the activities folder)
- This structure is required for proper lazy loading and consistent imports
- Do not use flat structure with direct files (e.g., `List.tsx`, `New.tsx`)

### 1. Route Configuration
Each module that uses activities must have the following routes configured:

```tsx
// Example for Calendar Events module
<Route path="/events/:id/activities" element={<EventActivityList />} />
<Route path="/events/:id/activities/new" element={<EventActivityNew />} />
<Route path="/events/:id/activities/:activityId/edit" element={<EventActivityEdit />} />
<Route path="/events/:id/activities/:activityId" element={<EventActivityView />} />
<Route path="/events/:id/activities/:activityId/note" element={<EventActivityViewNote />} />
```

### Real Module Examples

**Accounts Module:**
```tsx
<Route path="/:id/activities" element={<AccountActivityList />} />
<Route path="/:id/activities/new" element={<NewAccountActivity />} />
<Route path="/:id/activities/:activityId/edit" element={<EditAccountActivity />} />
<Route path="/:id/activities/:activityId" element={<ViewAccountActivity />} />
<Route path="/:id/activities/:activityId/note" element={<ViewAccountActivityNote />} />
```

**Calendar Events Module:**
```tsx
<Route path="/events/:id/activities" element={<EventActivityList />} />
<Route path="/events/:id/activities/new" element={<EventActivityNew />} />
<Route path="/events/:id/activities/:activityId/edit" element={<EventActivityEdit />} />
<Route path="/events/:id/activities/:activityId" element={<EventActivityView />} />
<Route path="/events/:id/activities/:activityId/note" element={<EventActivityViewNote />} />
```

**Calendar Tasks Module:**
```tsx
<Route path="/tasks/:id/activities" element={<TaskActivityList />} />
<Route path="/tasks/:id/activities/new" element={<NewTaskActivity />} />
<Route path="/tasks/:id/activities/:activityId/edit" element={<EditTaskActivity />} />
<Route path="/tasks/:id/activities/:activityId" element={<ViewTaskActivity />} />
<Route path="/tasks/:id/activities/:activityId/note" element={<ViewTaskNote />} />
```

**Evaluations Module (Franchisee Management):**
```tsx
<Route path="/evaluations/:evaluationId/activities" element={<EvaluationActivityList />} />
<Route path="/evaluations/:evaluationId/activities/new" element={<EvaluationActivityNew />} />
<Route path="/evaluations/:evaluationId/activities/:activityId/edit" element={<EvaluationActivityEdit />} />
<Route path="/evaluations/:evaluationId/activities/:activityId" element={<EvaluationActivityView />} />
<Route path="/evaluations/:evaluationId/activities/:activityId/note" element={<EvaluationActivityViewNote />} />
```

**Important Notes for Evaluations Module:**
- Uses internal routing in `index.tsx` (not separate router file)
- Route order is critical: specific activities routes must come before general evaluation routes
- Uses `evaluationId` parameter instead of `id`
- Module code is `'evaluation'` with field mapping `'evaluation': 'evaluationId'`
- Uses `useNavigate().query` for query parameters instead of `getQueryParam`

### 2. Required Route Components
Create these components for your module:

**Important**: Edit and View components should use `activityId` from `useParams()` instead of props to ensure proper routing and parameter extraction.

#### List Component
```tsx
// src/views/your-module/view/tabs/activities/List.tsx
import React from 'react';
import { useNavigate, useParams } from '@/utils/navigation.utils';
import { ActivitiesDataTable } from '@/components/GenericTab/activties';

const YourModuleActivityList = props => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  return (
    <ActivitiesDataTable
      id={id}
      module="your-module"
      tab={props?.tab}
      setTab={props?.setTab}
      onEditActivity={activity => {
        navigate(
          `${getViewRoute('YourModule')}/${id}/activities/${activity.id}/edit?activityType=${activity.commType?.toLowerCase()}`
        );
      }}
```

**Note**: Replace `'YourModule'` with the correct module name from the Routes constants:
- For accounts: `getViewRoute('Account')`
- For deals: `getViewRoute('Deals')`
- For jobs: `getViewRoute('Jobs')`
- For leads: `getViewRoute('Leads')`
- For events: `getViewRoute('Events')`
- For tasks: `getViewRoute('Tasks')`
    />
  );
};

export default YourModuleActivityList;
```

**Note**: The `onNewActivity` and `onViewActivity` callbacks are not needed as the ActivitiesDataTable component handles navigation internally based on the module configuration.

#### New Component
```tsx
// src/views/your-module/view/tabs/activities/New.tsx
import React, { useEffect, useState } from 'react';
import { useParams } from '@/utils/navigation.utils';
import { getQueryParam } from '@/utils/string.utils';
import { ActivityForm } from '@/components/GenericTab/activties';
import { useGlobalOptions } from '@/hooks/useGlobalOptions';

const YourModuleActivityNew = props => {
  const { id } = useParams();
  const activityType = getQueryParam(location.search, 'activityType');
  const breadCrumbs = ['Your Module', 'View Record', 'New Activity'];
  const [contacts, setContacts] = useState([]);

  // Use global options instead of ALL_CONTACTS query
  const { contacts: dbContacts } = useGlobalOptions({
    contacts: true,
  });

  const queryParams = new URLSearchParams(location.search);
  const email = queryParams.get('email');
  const mobile = queryParams.get('mobile');
  const name = queryParams.get('name');

  const initialRecipientData = {
    value: id,
    label: name,
    email,
    mobile,
  };

  useEffect(() => {
    if (dbContacts) {
      setContacts(dbContacts);
    }
  }, [dbContacts]);

  return (
    <ActivityForm
      mode="new"
      activityType={activityType || 'email'}
      module="your-module"
      breadCrumbs={breadCrumbs}
      recipients={contacts}
      recordId={id}
      redirectUrl={`${getViewRoute('YourModule')}/${id}/activities`}
      initialRecipientData={id !== 'undefined' ? initialRecipientData : undefined}
      {...props}
    />
  );
};

export default YourModuleActivityNew;
```

**Note**: Replace `'YourModule'` with the correct module name from the Routes constants:
- For accounts: `getViewRoute('Account')`
- For deals: `getViewRoute('Deals')`
- For jobs: `getViewRoute('Jobs')`
- For leads: `getViewRoute('Leads')`
- For events: `getViewRoute('Events')`
- For tasks: `getViewRoute('Tasks')`
```

**Note**: Instead of using the `ALL_CONTACTS` GraphQL query, use the `useGlobalOptions` hook with `contacts: true` to get the contacts data. This is more efficient and follows the application's data fetching patterns.

#### Edit Component
```tsx
// src/views/your-module/view/tabs/activities/Edit.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { ActivityForm } from '@/components/GenericTab/activties';

const YourModuleActivityEdit = props => {
  const { id, activityId } = useParams();
  const activityType = getQueryParam(location.search, 'activityType');
  const breadCrumbs = ['Your Module', 'View Record', 'Edit Activity'];

  return (
    <ActivityForm
      mode="edit"
      activityType={activityType || 'email'}
      module="your-module"
      breadCrumbs={breadCrumbs}
      recipients={recipients}
      recordId={id}
      id={activityId}
      redirectUrl={`${getViewRoute('YourModule')}/${id}/activities`}
      {...props}
    />
  );
};

**Note**: Replace `'YourModule'` with the correct module name from the Routes constants as shown in the New component example above.

export default YourModuleActivityEdit;
```

#### View Component
```tsx
// src/views/your-module/view/tabs/activities/View.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { getViewRoute } from '@/mfe-utilities';
import { ActivityView } from '@/components/GenericTab/activties';
import { findDocumentsByYourModuleId } from '@/utils/array.utils';

const YourModuleActivityView = props => {
  const { id, activityId } = useParams();

  const breadCrumbs = ['Your Module', 'View Record', 'View Activity'];
  const parentViewPageUrl = `${getViewRoute('YourModule')}/${id}`;

  return (
    <ActivityView
      breadCrumbs={breadCrumbs}
      parentViewPageUrl={parentViewPageUrl}
      activityId={activityId}
      findDocumentsFunction={findDocumentsByYourModuleId}
    />
  );
};

**Note**: Replace `'YourModule'` with the correct module name from the Routes constants:
- For accounts: `getViewRoute('Account')`
- For deals: `getViewRoute('Deals')`
- For jobs: `getViewRoute('Jobs')`
- For leads: `getViewRoute('Leads')`
- For events: `getViewRoute('Events')`
- For tasks: `getViewRoute('Tasks')`

export default YourModuleActivityView;
```

#### View Note Component
```tsx
// src/views/your-module/view/tabs/activities/ViewNote.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { getViewRoute } from '@/mfe-utilities';
import { ActivityViewNote } from '@/components/GenericTab/activties';

const YourModuleActivityViewNote = props => {
  const { id, activityId } = useParams();

  const breadCrumbs = ['Your Module', 'View Record', 'View Activity'];
  const parentViewPageUrl = `${getViewRoute('YourModule')}/${id}`;

  return (
    <ActivityViewNote
      breadCrumbs={breadCrumbs}
      parentViewPageUrl={parentViewPageUrl}
      activityId={activityId}
    />
  );
};

**Note**: Replace `'YourModule'` with the correct module name from the Routes constants as shown in the View component example above.

export default YourModuleActivityViewNote;
```

### 3. Utility Function
Create a utility function to filter documents for your module:

```tsx
// src/utils/array.utils.ts
export const findDocumentsByYourModuleId = (allDocumentsIdsData, targetYourModuleId) => {
  return allDocumentsIdsData.filter(
    documentData => documentData && documentData.yourModuleId === targetYourModuleId
  );
};
```

### 4. Module Constants
Define your module constants:

```tsx
// src/views/your-module/common/constants.ts
export const MODULE_CODE = 'your-module';
```

### 5. Integrate Activities List into Module Tab View
**CRITICAL STEP**: You must integrate the activities list into your module's tab view so it appears when users click on the Activities tab.

#### Option A: Direct Integration in Tab Component
If your module has a tab component that handles the Activities tab, update it to use the new List component:

```tsx
// src/views/your-module/view/tabs/Activities/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import AccountActivityList from './list';

const ActivitiesTab = props => {
  const { id } = useParams();
  
  return (
    <AccountActivityList
      id={id}
      tab={props?.tab}
      setTab={props?.setTab}
      {...props}
    />
  );
};

export default ActivitiesTab;
```

#### Option B: Update Existing Tab Structure
If your module uses a different tab structure, find the component that renders the Activities tab and update it:

```tsx
// Example: In your module's main view component
const YourModuleView = () => {
  const [currentTab, setCurrentTab] = useState('info');
  
  const renderTabContent = () => {
    switch (currentTab) {
      case 'activities':
        return (
          <AccountActivityList
            id={id}
            tab={currentTab}
            setTab={setCurrentTab}
          />
        );
      case 'info':
        return <InfoTab />;
      // ... other tabs
    }
  };
  
  return (
    <div>
      {/* Tab navigation */}
      <Tabs activeKey={currentTab} onChange={setCurrentTab}>
        <TabPane key="info" tab="Info" />
        <TabPane key="activities" tab="Activities" />
        {/* ... other tabs */}
      </Tabs>
      
      {/* Tab content */}
      {renderTabContent()}
    </div>
  );
};
```

#### Option C: Check for Existing Activities Tab
Look for existing activities tab implementations in your module and replace them:

```tsx
// Before: Old activities implementation
case 'activities':
  return <OldActivitiesComponent />;

// After: New GenericTab implementation
case 'activities':
  return (
    <AccountActivityList
      id={id}
      tab={currentTab}
      setTab={setCurrentTab}
    />
  );
```

## Usage Examples

### Basic Usage
```tsx
import { ActivityForm, ActivitiesDataTable } from '@/components/GenericTab/activties';
import { getViewRoute } from '@/mfe-utilities';

// Create new activity
<ActivityForm
  mode="new"
  activityType="email"
  module="event"
  breadCrumbs={['Calendar', 'Events', 'New Activity']}
  recipients={recipients}
  eventId={eventId}
  redirectUrl={`${getViewRoute('Events')}/${eventId}/activities`}
/>

// List activities
<ActivitiesDataTable
  id={recordId}
  module="event"
  tab={currentTab}
  setTab={setCurrentTab}
/>
```

### With Edit Callback Only
```tsx
import { ActivityFormWrapper, ActivitiesDataTable } from '@/components/GenericTab/activties';

const MyComponent = () => {
  const handleEditActivity = (activityId, data) => {
    console.log('Activity updated:', activityId, data);
    // Handle success
  };

  return (
    <ActivitiesDataTable
      id={recordId}
      module="event"
      tab={currentTab}
      setTab={setCurrentTab}
      onEditActivity={handleEditActivity}
    />
  );
};
```

**Note**: `onNewActivity` and `onViewActivity` callbacks are not needed as the ActivitiesDataTable component handles navigation internally.

## Module-Specific Configuration

### Recipients Data Structure
```tsx
const recipients = [
  {
    value: 'contact-id',
    label: 'Contact Name',
    mobile: '+1234567890',
    email: 'contact@example.com'
  }
];
```

### Module Field Mapping
The backend expects specific field names for different modules. Update the `relatedModuleFieldMap` in `src/constants/Activities.ts`:

```tsx
export const relatedModuleFieldMap = {
  'event': 'eventId',
  'account': 'accountId',
  'deal': 'dealId',
  'lead': 'leadId',
  'site': 'siteId',
  // Add your module here
  'your-module': 'yourModuleId'
};
```

### Activity Types
Supported activity types:
- `email` - Email communication
- `sms` - SMS communication
- `calls` - Call logs
- `note` - Notes

## Migration Guide

### From Old Activity Components
1. Replace individual activity components with `ActivityForm`
2. Update route configurations
3. Add required utility functions
4. Update module constants
5. **CRITICAL**: Integrate activities list into module tab view (Step 5 above)
6. Test navigation flow

### Implementation Checklist
- [ ] Create List component (`list/index.tsx`)
- [ ] Update New component (`new/index.tsx`)
- [ ] Update Edit component (`edit/index.tsx`)
- [ ] Update View component (`view/index.tsx`)
- [ ] Create ViewNote component (`view/note/index.tsx`)
- [ ] Add route configurations
- [ ] Add imports to lazyComponents
- [ ] **INTEGRATE INTO TAB VIEW** (Step 5)
- [ ] Test all activity types
- [ ] Test navigation flow

**Note**: Do not create implementation summary files. Use this guide as the single source of truth for GenericTab activities implementation.

### Example Migration
```tsx
// Old way
import NewEmail from '@/views/activities/new/email';
import NewSMS from '@/views/activities/new/sms';
import NewCallLog from '@/views/activities/new/callLog';
import NewNote from '@/views/activities/new/note';

// New way
import { ActivityForm } from '@/components/GenericTab/activties';

// Single component handles all activity types
<ActivityForm
  mode="new"
  activityType={activityType}
  module="your-module"
  breadCrumbs={breadCrumbs}
  recipients={recipients}
  redirectUrl={`/your-module/${id}/activities`}
/>
```

## Troubleshooting

### Common Issues

1. **Navigation not working**: Ensure `redirectUrl` prop is correctly set with the proper module path
2. **Activities not loading**: Check module field mapping in constants
3. **Form not saving**: Verify module-specific props (e.g., `eventId`, `accountId`)
4. **Route not found**: Create all required route components and configurations
5. **Activities tab shows empty or old content**: **MISSING STEP** - You forgot to integrate the activities list into your module's tab view. See "Step 5: Integrate Activities List into Module Tab View" above.
6. **Activities tab not appearing**: Check if the tab is properly configured in your module's tab structure
7. **Path errors**: **CRITICAL** - Always use `getViewRoute` from `@/mfe-utilities` instead of hardcoding paths. See "Important Path Structure Note" at the top of this document.
8. **Folder structure errors**: **CRITICAL** - Must follow the standardized folder structure. See "Required Folder Structure" section above.
   - ❌ **Wrong**: Flat structure with direct files (`List.tsx`, `New.tsx`, etc.)
   - ✅ **Correct**: Nested structure with `index.tsx` files in subdirectories
   - ❌ **Wrong**: Note component directly in activities folder
   - ✅ **Correct**: Note component in `view/note/index.tsx`

### Debug Steps
1. Check browser console for errors
2. Verify route configurations
3. Confirm module constants are set
4. Test navigation URLs manually
5. Check GraphQL queries and mutations

## Best Practices

1. **Consistent Naming**: Use consistent naming for your module routes
2. **Error Handling**: Implement proper error boundaries
3. **Loading States**: Add loading indicators where appropriate
4. **Validation**: Ensure proper form validation
5. **Testing**: Test all activity types and navigation flows
6. **Documentation**: Do not create implementation summary files - use this guide as the single source of truth
7. **Data Fetching**: Use `useGlobalOptions` hook instead of individual GraphQL queries for contacts data in new activity components
8. **Path Consistency**: Always use the correct module path - never use `/your-module/` in production code

## Module Path Reference

Use `getViewRoute` function to get the correct paths for your module implementation:

| Module | Route Name | getViewRoute Call | Activities Path Pattern |
|--------|------------|-------------------|------------------------|
| Accounts | `'Account'` | `getViewRoute('Account')` | `${getViewRoute('Account')}/:id/activities` |
| Deals | `'Deals'` | `getViewRoute('Deals')` | `${getViewRoute('Deals')}/:id/activities` |
| Jobs | `'Jobs'` | `getViewRoute('Jobs')` | `${getViewRoute('Jobs')}/:id/activities` |
| Leads | `'Leads'` | `getViewRoute('Leads')` | `${getViewRoute('Leads')}/:id/activities` |
| Events | `'Events'` | `getViewRoute('Events')` | `${getViewRoute('Events')}/:id/activities` |
| Tasks | `'Tasks'` | `getViewRoute('Tasks')` | `${getViewRoute('Tasks')}/:id/activities` |
| Cases | `'Cases'` | `getViewRoute('Cases')` | `${getViewRoute('Cases')}/:id/activities` |
| Documents | `'Documents'` | `getViewRoute('Documents')` | `${getViewRoute('Documents')}/:id/activities` |
| Evaluations | `'Evaluations'` | `getViewRoute('Evaluations')` | `${getViewRoute('Evaluations')}/:evaluationId/activities` |

**Example Usage:**
```tsx
import { getViewRoute } from '@/mfe-utilities';

// For accounts
const accountActivitiesPath = `${getViewRoute('Account')}/${id}/activities`;

// For deals
const dealActivitiesPath = `${getViewRoute('Deals')}/${id}/activities`;

// For jobs
const jobActivitiesPath = `${getViewRoute('Jobs')}/${id}/activities`;

// For evaluations
const evaluationActivitiesPath = `${getViewRoute('Evaluations')}/${evaluationId}/activities`;
```

## File Structure
```
src/
├── components/
│   └── GenericTab/
│       └── activties/
│           ├── ActivityForm.tsx
│           ├── ActivityFormWrapper.tsx
│           ├── ActivitiesDataTable.tsx
│           ├── ActivityView.tsx
│           ├── ActivityViewNote.tsx
│           ├── index.ts
│           └── example-usage.tsx
└── views/
    └── your-module/
        └── view/
            └── tabs/
                └── activities/
                    ├── list/
                    │   └── index.tsx
                    ├── new/
                    │   └── index.tsx
                    ├── edit/
                    │   └── index.tsx
                    ├── view/
                    │   ├── index.tsx
                    │   └── note/
                    │       └── index.tsx
                    └── (no direct files in activities folder)
``` 