# Views Folder Documentation - Developer & AI Guide

## Overview

The `views` folder contains all the main application modules and follows a consistent architectural pattern for CRUD operations. This documentation provides a comprehensive guide for creating records list pages, view pages, and edit pages.

## Folder Structure

```
views/
├── accounts/           # Customer account management
├── activities/         # Activity tracking (calls, notes, emails)
├── calendar/           # Calendar, tasks, events, SMS
├── customer-service/   # Cases, quality audits
├── documents/          # Document management
├── finance/            # Bills, invoices, credit/debit
├── franchisee-forms/   # Franchisee application forms
├── franchisee-management/ # Franchisee management
├── hr-&-compliance/    # Employee, performance reviews, leave
├── jobs/               # Job management, batch transfers
├── notifications/      # Notification system
├── page-not-found/     # 404 page
├── purchasing-&-inventory/ # Purchase orders, sales orders
├── quoteApprovalPortal/ # Quote approval system
├── sales/              # Deals, leads, sales management
└── settings/           # System configuration modules
```

## Standard Module Structure

Each module follows this consistent pattern:

```
module-name/
├── index.tsx           # Main module router with nested routes
├── common/             # Shared module resources
│   ├── constants/      # Module constants, enums
│   ├── components/     # Reusable module components
│   ├── fields.tsx      # Form field definitions
│   ├── columns.tsx     # Table column definitions
│   ├── filters.tsx     # Search/filter configurations
│   ├── services.ts     # Data transformation utilities
│   └── hooks/          # Custom hooks for the module
├── list/               # List/index page
│   └── index.tsx
├── new/                # Create new record page
│   └── index.tsx
├── edit/               # Edit existing record page
│   └── index.tsx
├── view/               # View record details page
│   ├── index.tsx
│   └── tabs/           # Tab components for view page
└── sub-module/         # Nested sub-modules (if applicable)
    ├── list/
    ├── new/
    ├── edit/
    └── view/
```

## Core Components & Patterns

### 1. List Page Pattern

**Location**: `module-name/list/index.tsx`

**Key Features**:
- Data table with pagination
- Search and filtering
- Bulk actions (delete, export)
- Create new record button
- Module header with title and actions

**Essential Imports**:
```tsx
import ModuleTable from '@/components/ModuleTable';
import ListModuleHeader from '@/components/modules/ListModuleHeader';
import ModuleActionNew from '@/components/modules/ModuleActionNew';
import ModuleAlert, { ModuleRowSelection } from '@/components/ModuleAlert';
import { Content, Container } from '@/styled-components';
```

**Standard Structure**:
```tsx
const ModuleList = props => {
  const [search, setSearch] = useState<string>();
  const [refetch, setRefetch] = useState<boolean>(false);
  const [selected, setSelected] = useState<ModuleRowSelection<ModelType>>({
    selected: [],
  });

  // GraphQL mutations for delete operations
  const [deleteRecords, { loading: deleteLoading }] = useMutation({
    query: DELETE_RECORDS_QUERY,
    successMessage: 'Records deleted successfully.',
  });

  return (
    <Content>
      <Container>
        <ListModuleHeader
          listTitle="Module Name"
          listSubtitle="Manage and organize records"
          // ... other props
        />
        
        <ModuleTable
          columns={listColumns}
          query={ALL_RECORDS_QUERY}
          searchFields={searchFields}
          exportFields={exportFields}
          // ... other props
        />
      </Container>
    </Content>
  );
};
```

### 2. View Page Pattern

**Location**: `module-name/view/index.tsx`

**Key Features**:
- Record details display
- Navigation between records
- Edit/Delete actions
- Tabbed interface for related data
- Breadcrumb navigation

**Essential Imports**:
```tsx
import ViewModuleHeader from '@/components/modules/ViewModuleHeader';
import { Container, Tabs } from '@/styled-components';
import useNavigate from '@/hooks/useNavigate';
import useQuery from '@/hooks/useQuery';
import useRecordNavigation from '@/hooks/useRecordNavigation';
```

**Standard Structure**:
```tsx
const ModuleView = props => {
  const { back } = useNavigate('View');
  const [tab, setTab] = useState('module-info');

  const { data, loading } = useQuery<ModelType>({
    isViewRecordQuery: true,
    query: FIND_RECORD_BY_ID,
    options: {
      variables: { id: props?.id },
    },
    onError: back,
  });

  const { onNext, onPrevious, disableNext, disablePrevious } = 
    useRecordNavigation({
      allRecordsQuery: ALL_RECORDS_IDS,
      currentRecordId: props?.id,
    });

  return (
    <Box>
      <ViewModuleHeader
        breadCrumbs={[/* breadcrumb items */]}
        title={data?.name || data?.title}
        deleteQuery={DELETE_RECORD}
        deleteId={data?.id}
        onNext={onNext}
        onPrevious={onPrevious}
        // ... other props
      />
      
      <Container>
        <Tabs
          activeKey={tab}
          onChange={setTab}
          items={[
            {
              key: 'module-info',
              label: 'Module Info',
              children: <ModuleInfo data={data} />,
            },
            // ... other tabs
          ]}
        />
      </Container>
    </Box>
  );
};
```

### 3. Edit Page Pattern

**Location**: `module-name/edit/index.tsx`

**Key Features**:
- Form with pre-populated data
- Validation and error handling
- Save/Cancel actions
- Form provider pattern

**Essential Imports**:
```tsx
import FormButtons from '@/components/FormButtons';
import { Form } from '@/styled-components';
import useFormQuery from '@/hooks/useFormQuery';
import useMutation from '@/hooks/useMutation';
import useNavigate from '@/hooks/useNavigate';
```

**Standard Structure**:
```tsx
const ModuleEdit = props => {
  const { id } = useParams();
  const { back } = useNavigate('Edit');

  const { form, loading: findLoading } = useFormQuery({
    query: FIND_RECORD_BY_ID,
    options: {
      variables: { id },
    },
    transformData: transformData,
  });

  const [updateRecord, { loading: updateLoading }] = useMutation({
    query: UPDATE_RECORD,
    successMessage: 'Record updated successfully.',
    onSuccess: back,
  });

  return (
    <ModuleFormProvider.Edit id={id}>
      <ModuleFormHeader view="Edit" />
      <MainForm />
    </ModuleFormProvider.Edit>
  );
};
```

### 4. New Page Pattern

**Location**: `module-name/new/index.tsx`

**Key Features**:
- Empty form for new record creation
- Validation and error handling
- Save/Cancel actions
- Form provider pattern

**Standard Structure**:
```tsx
const ModuleNew = props => {
  const { back } = useNavigate('New');

  const [createRecord, { loading }] = useMutation({
    query: CREATE_RECORD,
    successMessage: 'Record created successfully.',
    onSuccess: back,
  });

  return (
    <ModuleFormProvider.New>
      <ModuleFormHeader view="New" />
      <MainForm />
    </ModuleFormProvider.New>
  );
};
```

## Form Provider Pattern

Most modules use a Form Provider pattern for state management:

```tsx
// ModuleFormProvider.tsx
const ModuleFormProvider = {
  New: ({ children, ...props }) => (
    <FormProvider mode="new" {...props}>
      {children}
    </FormProvider>
  ),
  Edit: ({ children, id, ...props }) => (
    <FormProvider mode="edit" id={id} {...props}>
      {children}
    </FormProvider>
  ),
};
```

## Common Utilities

### Fields Definition
**Location**: `module-name/common/fields.tsx`

```tsx
export const moduleFields = {
  basicInfo: {
    fields: [
      {
        title: 'Field Label',
        field: 'fieldName',
        type: 'text' as InputFieldType,
        required: true,
        props: {
          ...labelSpan,
          rules: [required],
        },
      },
      // ... more fields
    ],
  },
};
```

### Columns Definition
**Location**: `module-name/common/columns.tsx`

```tsx
export const listColumns = [
  {
    title: 'Column Title',
    dataIndex: 'fieldName',
    key: 'fieldName',
    sorter: (a, b) => a.fieldName.localeCompare(b.fieldName),
    render: (_, record) => (
      <Link to={`${getViewRoute('ModuleName')}/${record.id}`}>
        {record.fieldName}
      </Link>
    ),
  },
  // ... more columns
];
```

## Routing Patterns

### Main Module Router
**Location**: `module-name/index.tsx`

```tsx
const ModuleRouter = props => (
  <Layout style={{ height: '90vh', overflow: 'hidden', background: 'white' }}>
    <SettingsSideMenu sideMenu={MenuItems} defaultMenu='list' />
    <Layout style={{ height: '90vh' }}>
      <Content style={{ overflow: 'auto' }}>
        <Routes>
          <Route path='/' element={<ModuleList {...props} />} />
          <Route path='/new' element={<ModuleNew {...props} />} />
          <Route path='/:id/edit' element={<ModuleEdit {...props} />} />
          <Route path='/:id' element={<ModuleView {...props} />} />
          
          {/* Nested routes for related modules */}
          <Route path='/:id/submodule/new' element={<SubmoduleNew {...props} />} />
          {/* ... more nested routes */}
        </Routes>
      </Content>
    </Layout>
  </Layout>
);
```

## Nested Module Patterns

For complex modules with sub-entities (like accounts with sites, contacts, etc.):

```
accounts/
├── accounts/
│   ├── list/
│   ├── new/
│   ├── edit/
│   └── view/
│       └── tabs/
│           ├── AccountInfo.tsx
│           ├── Sites/
│           │   ├── list/
│           │   ├── new/
│           │   ├── edit/
│           │   └── view/
│           ├── Contacts/
│           └── Activities/
├── contacts/
└── sites/
```

## Best Practices

### 1. Consistent Naming
- Use PascalCase for component files
- Use kebab-case for route paths
- Use camelCase for props and variables

### 2. Code Organization
- Keep common utilities in `common/` folder
- Separate concerns (fields, columns, services)
- Use TypeScript interfaces for props

### 3. Error Handling
- Always include error handling in queries
- Provide fallback UI states
- Use loading states appropriately

### 4. Performance
- Implement proper pagination
- Use React.memo for expensive components
- Lazy load tab content when possible

### 5. Accessibility
- Include proper ARIA labels
- Ensure keyboard navigation
- Maintain semantic HTML structure

## Debugging Common Issues

### 1. Data Not Displaying in View
- Check GraphQL query includes all required fields
- Verify data transformation in services
- Add console.log to debug data flow
- Ensure proper prop passing between components

### 2. Form Validation Issues
- Check field definitions in common/fields.tsx
- Verify form provider setup
- Ensure proper error handling

### 3. Routing Problems
- Check route definitions in main router
- Verify path parameters match component expectations
- Ensure proper navigation utilities usage

## Creating a New Module

### Step 1: Create Folder Structure
```bash
mkdir -p src/views/new-module/{list,new,edit,view/tabs,common/{components,constants}}
```

### Step 2: Create Base Files
1. `index.tsx` - Main router
2. `list/index.tsx` - List page
3. `new/index.tsx` - Create page
4. `edit/index.tsx` - Edit page
5. `view/index.tsx` - View page
6. `common/fields.tsx` - Form fields
7. `common/columns.tsx` - Table columns
8. `common/constants.ts` - Module constants

### Step 3: Add to Main Router
Add route in `src/routes/index.tsx`:
```tsx
<Route path='new-module/*' element={<NewModule {...props} />} />
```

### Step 4: Create GraphQL Queries
Add queries in `src/graphql/newModule.gql.ts`

### Step 5: Add to Side Navigation
Update appropriate menu configuration

## TypeScript Patterns

### Component Props Interface
```tsx
interface ModuleViewProps {
  id?: string;
  data?: ModuleType;
  loading?: boolean;
  onRefresh?: () => void;
}
```

### Form Field Types
```tsx
import { InputFieldType } from '@/typings/form.types';

type: 'text' as InputFieldType
```

### Model Interfaces
```tsx
interface ModuleModel {
  id: string;
  name: string;
  status: StatusModel;
  createdAt: string;
  updatedAt: string;
}
```