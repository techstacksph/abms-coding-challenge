# Environment Variable Alignment

This document explains how environment variables from all 5 repositories have been aligned into the fe-abms monorepo.

## Repository Analysis

### 1. mfe-abms-root (.env)
```bash
ENV=local
STATIC_PATH=../
LOG_LABEL=mfe-abms-root
PORT=9000
LOG_LEVEL=debug
APP_NAME=mfe-abms
AUTH_URL=http://localhost:8092
AUTH_SERVICE=/api/auth
APOLLO_URL=http://localhost:8080
APOLLO_SERVICE=/api/gw
APOLLO_WS_URL=ws://localhost:8080
MFE_APP_LIST='[...]'
MFE_HOME_APP_LIST='[...]'
```

### 2. mfe-abms-home (.env)
```bash
API_URL=http://localhost:8080
API_TIMEOUT=5000
TENANT_PREFIX=abms
```

### 3. mfe-abms-styled-components (.env)
```bash
PORT=8085
NODE_ENV=local
```

### 4. mfe-abms-utils (.env)
```bash
PORT=8081
AUTH_URI=http://localhost:8092
```

### 5. mfe-abms-unauthorize (.env)
```bash
PORT=8084
TENANT_PREFIX=abms
API_URL=http://localhost:8092
```

## Backend Services

### msvc-gw-apollo-abms (.env)
```bash
NODE_ENV=local
PORT=8080
AUTH_API_URL=http://localhost:8092
APOLLO_SERVICE_LIST=[{"name":"msvc-cto-bo","url":"http://localhost:8083"}]
LOG_LEVEL=info
DISABLE_AUTH=false
```

### msvc-authorization-abms (.env)
```bash
NODE_ENV=local
PORT=8092
# ... database and other configs
```

## Aligned Environment Variables

### API Service Endpoints
- `REACT_APP_APOLLO_URI` → GraphQL API endpoint (from msvc-gw-apollo-abms:8080)
- `REACT_APP_APOLLO_WS` → WebSocket endpoint (from msvc-gw-apollo-abms:8080)
- `REACT_APP_AUTH_URI` → Authentication service (from msvc-authorization-abms:8092)
- `REACT_APP_API_URL` → Legacy API URL (from mfe-abms-home)
- `REACT_APP_API_TIMEOUT` → API timeout (from mfe-abms-home)

### Tenant Configuration
- `REACT_APP_TENANT_PREFIX` → Tenant prefix (from mfe-abms-home and mfe-abms-unauthorize)

### External Services
- `REACT_APP_GOOGLE_API_KEY` → Google Maps API key (from mfe-abms-home)

### Development Configuration
- `NODE_ENV` → Environment mode
- `PORT` → Development server port (default: 3000)
- `REACT_APP_LOG_LEVEL` → Logging level

## Service Port Mapping

| Service | Original Port | Purpose |
|---------|---------------|---------|
| fe-abms (monorepo) | 3000 | Main application |
| mfe-abms-root | 9000 | MFE orchestrator |
| mfe-abms-utils | 8081 | Shared utilities |
| mfe-abms-home | 8086 | Main business app |
| mfe-abms-styled-components | 8085 | UI components |
| mfe-abms-unauthorize | 8084 | Authentication |
| msvc-gw-apollo-abms | 8080 | GraphQL Gateway |
| msvc-authorization-abms | 8092 | Auth service |
| msvc-abms | 8083 | Main business service |

## Usage

1. Copy `env.example` to `.env`
2. Update the environment variables as needed
3. The application will automatically use these variables through the environment configuration

## Environment Files

- `env.example` → Template with all variables
- `src/config/environment.ts` → Environment configuration
- `src/config/appConfig.ts` → Application configuration
- `vite.config.ts` → Vite configuration with proxy setup

## Proxy Configuration

The Vite development server is configured to proxy API calls:

- `/api/gw` → Apollo GraphQL Gateway (port 8080)
- `/api/auth` → Authentication service (port 8092)
- `/api/ws` → WebSocket service (port 8080)

This ensures seamless integration with the existing microservices architecture. 