# Styled Components Documentation

## Overview

The `/styled-components` folder contains a comprehensive design system and component library for the AYR ABMS frontend application. This folder provides reusable, styled components built on top of Ant Design with custom styling and functionality.

## Folder Structure

```
styled-components/
├── assets/           # Icons, images, and other static assets
├── components/       # Core UI components
│   ├── charts/       # Chart components
│   ├── containers/   # Layout containers (Space, Container, Content)
│   ├── forms/        # Form-related components
│   ├── icons/        # Icon components
│   ├── inputs/       # Input components (Button, Select, Input, etc.)
│   ├── layouts/      # Layout components
│   ├── module/       # Module-specific components
│   ├── typography/   # Text and typography components
│   ├── vectors/      # Vector graphics
│   └── widgets/      # Widget components (Modal, Badge, etc.)
├── hooks/            # Custom React hooks
├── services/         # Utility services (PDF generation, etc.)
├── theme/            # Theme configuration and providers
├── types/            # TypeScript type definitions
├── utils/            # Utility functions
└── index.ts          # Main export file
```

## Most Used Components

Based on codebase analysis, here are the most frequently used components:

### 1. Button (`components/inputs/Button.tsx`)

**Usage**: Primary UI interaction element with extensive styling options.

```tsx
import { Button } from '@/styled-components';

// Basic usage
<Button>Click me</Button>

// Primary button
<Button type="primary">Save</Button>

// Secondary/Ghost button
<Button type="primary" ghost>Cancel</Button>

// With custom styling
<Button 
  type="primary" 
  $css="width: 120px; background-color: #3137fd;"
>
  Submit
</Button>

// With icon
<Button 
  type="primary" 
  icon={<PlusOutlined />}
  onClick={handleClick}
>
  Add Item
</Button>
```

**Key Props**:
- `type`: 'primary' | 'default' | 'text' | 'link'
- `ghost`: boolean - for outline style
- `$css`: string - custom CSS styling
- `$inTable`: boolean - for table-specific sizing
- Standard Ant Design Button props

### 2. Modal (`components/widgets/Modal.tsx`)

**Usage**: Modal dialogs with custom styling and footer configuration.

```tsx
import { Modal } from '@/styled-components';

<Modal
  open={isOpen}
  onCancel={() => setIsOpen(false)}
  onSubmit={handleSubmit}
  title="Confirm Action"
  submitText="Confirm"
  cancelText="Cancel"
  modalProps={{
    width: 600,
    $css: "border-radius: 12px;"
  }}
>
  <p>Are you sure you want to proceed?</p>
</Modal>
```

**Key Props**:
- `open`: boolean - visibility state
- `onCancel`: function - cancel handler
- `onSubmit`: function - submit handler
- `title`: string | ReactNode - modal title
- `submitText`/`cancelText`: string - button labels
- `modalProps`: extended Ant Design Modal props
- `isDelete`: boolean - for delete confirmation styling
- `showFooter`: boolean - show/hide footer

### 3. FormSection (`components/forms/FormSection.tsx`)

**Usage**: Renders form fields in a structured layout.

```tsx
import { FormSection } from '@/styled-components';

const formFields = {
  title: "User Details",
  fields: [
    {
      type: 'text',
      field: 'firstName',
      title: 'First Name',
      required: true,
      inputProps: {
        placeholder: 'Enter first name'
      }
    },
    {
      type: 'select',
      field: 'role',
      title: 'Role',
      inputProps: {
        options: [
          { label: 'Admin', value: 'admin' },
          { label: 'User', value: 'user' }
        ]
      }
    }
  ]
};

<FormSection 
  fields={formFields}
  col={2}
  row={1}
  fieldRowGutter={[16, 16]}
/>
```

### 4. Input (`components/inputs/Input.tsx`)

**Usage**: Text input with custom styling.

```tsx
import { Input } from '@/styled-components';

// Text input
<Input.Text 
  placeholder="Enter text"
  value={value}
  onChange={handleChange}
  $css="border-radius: 8px;"
/>

// Password input
<Input.Password 
  placeholder="Enter password"
  value={password}
  onChange={handlePasswordChange}
/>
```

### 5. Text (`components/typography/Text.tsx`)

**Usage**: Typography component with size and weight variants.

```tsx
import { Text } from '@/styled-components';

<Text $type="lg" weight="bold">Large Bold Text</Text>
<Text $type="sm" color="#666">Small Gray Text</Text>
<Text weight="medium" $css="line-height: 1.5;">Custom Text</Text>
```

### 6. FormTableDraggable (`components/forms/FormTableDraggable.tsx`)

**Usage**: Draggable table for form data with dynamic rows.

```tsx
import { FormTableDraggable } from '@/styled-components';

const columnDefs = [
  {
    title: 'Item',
    render: (index) => (
      <FormInput field={`items.${index}.name`} />
    )
  },
  {
    title: 'Quantity',
    render: (index) => (
      <FormInput field={`items.${index}.quantity`} type="number" />
    )
  }
];

<FormTableDraggable
  name="orderItems"
  form={form}
  columnDefs={columnDefs}
  isDraggable={true}
  showCheckbox={true}
  showDelete={true}
/>
```

### 7. ModuleActions (`components/module/ModuleActions.tsx`)

**Usage**: Action bar with search, filters, export, and create functionality.

```tsx
import { ModuleActions } from '@/styled-components';

<ModuleActions
  title="Add New"
  onCreateNew={handleCreate}
  onSearch={handleSearch}
  onChangeFilter={handleFilter}
  filters={filterConfig}
  exportData={tableData}
  onUploadAccepted={handleImport}
/>
```

### 8. Space (`components/containers/Space.tsx`)

**Usage**: Spacing container for layout.

```tsx
import { Space } from '@/styled-components';

<Space direction="vertical" size={16}>
  <div>Item 1</div>
  <div>Item 2</div>
</Space>

<Space align="center" $css="width: 100%;">
  <Button>Left</Button>
  <Button>Right</Button>
</Space>
```

## Hooks

### useModal

**Usage**: Modal management hook.

```tsx
import { useModal } from '@/styled-components';

const [openModal, closeModal, contextModal] = useModal({
  title: 'Confirmation',
  message: 'Are you sure?',
  onSubmit: handleConfirm,
  type: 'warning'
});

// In component
return (
  <>
    <Button onClick={openModal}>Open Modal</Button>
    {contextModal}
  </>
);
```

### useSnackbar

**Usage**: Notification management.

```tsx
import { useSnackbar } from '@/styled-components';

const showNotification = useSnackbar();

// Show success message
showNotification('Operation completed successfully', 'success');

// Show error message
showNotification('Something went wrong', 'error');
```

## Common Errors and Solutions

### 1. **$css Prop Not Working**

**Error**: Custom styles not applying when using `$css` prop.

**Common Causes**:
- Missing `$` prefix in prop name
- CSS specificity issues
- Invalid CSS syntax

**Solution**:
```tsx
// ❌ Wrong
<Button css="color: red;">Button</Button>

// ✅ Correct
<Button $css="color: red !important;">Button</Button>

// ✅ For complex styles
<Button $css={`
  color: red;
  &:hover {
    background-color: blue;
  }
`}>Button</Button>
```

### 2. **Form Field Validation Errors**

**Error**: Form validation not working with FormSection components.

**Common Causes**:
- Missing `required` prop
- Incorrect field name mapping
- Missing form instance

**Solution**:
```tsx
// ✅ Correct FormSection usage
<Form form={form} onFinish={handleSubmit}>
  <FormSection 
    fields={{
      fields: [
        {
          type: 'text',
          field: 'email', // Must match form field name
          title: 'Email',
          required: true,
          rules: [
            { required: true, message: 'Email is required' },
            { type: 'email', message: 'Invalid email format' }
          ]
        }
      ]
    }}
  />
</Form>
```

### 3. **Modal Not Closing**

**Error**: Modal remains open after actions.

**Common Causes**:
- Not updating open state
- Missing onCancel handler
- Async operations blocking close

**Solution**:
```tsx
// ✅ Proper modal state management
const [isOpen, setIsOpen] = useState(false);

<Modal
  open={isOpen}
  onCancel={() => setIsOpen(false)}
  onSubmit={async () => {
    try {
      await handleSubmit();
      setIsOpen(false); // Close after successful submit
    } catch (error) {
      // Handle error, keep modal open
      console.error(error);
    }
  }}
>
  Modal Content
</Modal>
```

### 4. **Button Styling Conflicts**

**Error**: Button styles not applying correctly, especially with Ant Design overrides.

**Common Causes**:
- CSS specificity issues
- Theme conflicts
- Missing `!important` declarations

**Solution**:
```tsx
// ✅ Use higher specificity or !important
<Button 
  type="primary" 
  $css={`
    background-color: #3137fd !important;
    border-color: #3137fd !important;
    
    &:hover {
      background-color: #2128cc !important;
      border-color: #2128cc !important;
    }
  `}
>
  Button
</Button>
```

### 5. **FormTableDraggable Data Issues**

**Error**: Data not updating correctly in draggable tables.

**Common Causes**:
- Incorrect form field naming
- Missing form instance
- State synchronization issues

**Solution**:
```tsx
// ✅ Proper FormTableDraggable setup
<Form.List name="items">
  {(fields) => (
    <FormTableDraggable
      name="items"
      form={form}
      columnDefs={[
        {
          title: 'Name',
          render: (index) => (
            <Form.Item name={[index, 'name']}>
              <Input />
            </Form.Item>
          )
        }
      ]}
    />
  )}
</Form.List>
```

### 6. **Import Path Errors**

**Error**: Cannot resolve styled-components imports.

**Common Causes**:
- Incorrect import paths
- Missing exports in index files
- Circular dependencies

**Solution**:
```tsx
// ✅ Use the main export
import { Button, Modal, Text } from '@/styled-components';

// ❌ Avoid direct imports
import Button from '@/styled-components/components/inputs/Button';
```

### 7. **Theme Variables Not Working**

**Error**: CSS custom properties (theme variables) not applying.

**Common Causes**:
- ThemeProvider not wrapping the app
- Missing theme context
- Variable name typos

**Solution**:
```tsx
// ✅ Ensure ThemeProvider is properly set up
import { ThemeProvider } from '@/styled-components';

function App() {
  return (
    <ThemeProvider>
      <YourAppContent />
    </ThemeProvider>
  );
}

// ✅ Use correct variable names
<div style={{ color: 'var(--color-primary)' }}>Text</div>
```

### 8. **Performance Issues with Large Forms**

**Error**: Slow rendering with many form fields.

**Common Causes**:
- Re-rendering all fields on single field change
- Heavy validation rules
- Large datasets in selects

**Solution**:
```tsx
// ✅ Use Form.List optimization
<Form.List name="items">
  {(fields) => (
    <>
      {fields.map((field) => (
        <React.memo key={field.key}>
          <FormInput field={field.name} />
        </React.memo>
      ))}
    </>
  )}
</Form.List>

// ✅ Debounce search inputs
const debouncedSearch = useMemo(
  () => debounce(handleSearch, 300),
  []
);
```

## Best Practices

1. **Always use the main export**: Import from `@/styled-components` rather than specific component files
2. **Leverage $css prop**: Use for custom styling while maintaining component structure
3. **Follow naming conventions**: Use `$` prefix for styled-component props
4. **Handle async operations**: Properly manage loading states in modals and forms
5. **Optimize performance**: Use React.memo for complex form components
6. **Validate props**: Ensure required props are provided to avoid runtime errors
7. **Test components**: Always test component behavior with different prop combinations

## TypeScript Support

The styled-components library includes comprehensive TypeScript definitions. Most components accept generic props for type safety:

```tsx
interface FormData {
  name: string;
  email: string;
}

// Typed form usage
<FormSection<FormData> 
  fields={typedFields}
  onSubmit={(values: FormData) => {
    // values is properly typed
  }}
/>
```

This documentation should help developers understand and effectively use the styled-components library while avoiding common pitfalls and errors.
