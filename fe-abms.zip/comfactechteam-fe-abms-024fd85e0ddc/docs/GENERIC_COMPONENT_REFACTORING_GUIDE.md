# Generic Component Refactoring Guide: Converting Main Components to Support Embedded Tabs

## Overview

This guide provides a generic pattern for refactoring main list components to support both full-page views and embedded tab contexts while eliminating code duplication.

## The Problem

Typically, applications have:
- **Main components**: Full-featured pages with headers, dashboards, and complete functionality
- **Tab components**: Simplified embedded versions with duplicated logic

**Result**: Hundreds of lines of duplicated code per module, inconsistent behavior, and maintenance overhead.

## Generic Solution Pattern

### 1. Identify the Props Interface

Define a standardized props interface for your main component:

```typescript
interface GenericListProps {
  // UI Control Props
  hideDashboard?: boolean;         // Hide dashboard/stats cards (default: false)
  hideHeader?: boolean;            // Hide page header/breadcrumbs (default: false)  
  tabMode?: boolean;               // Embedded tab styling (default: false)
  
  // Content Customization Props
  columns?: any[];                 // Custom table columns (default: main component columns)
  filters?: any;                   // Custom filter configuration (default: main component filters)
  search?: (searchTerm: string) => void; // Custom search handler (default: main component search)
  
  // Data Filtering Props
  fixedFilter?: any[];             // Always-applied filters (default: [])
  parentFilter?: {                 // Parent context filter
    fieldName: string;
    value: string;
  };
  
  // Navigation Props
  customRoutes?: {                 // Custom navigation routes
    view?: (id: string) => string;
    edit?: (id: string) => string;
    new?: string;
  };
}
```

### 2. Implement Fallback Logic Pattern

Apply the "props with fallback" pattern throughout your component:

```typescript
const YourMainComponent = (props) => {
  const {
    hideDashboard = false,
    hideHeader = false,
    tabMode = false,
    columns,
    filters,
    search: customSearch,
    fixedFilter = [],
    parentFilter,
    customRoutes,
    ...otherProps
  } = props;

  // Your existing logic here...
  const defaultFilters = useFilters({ /* your filter config */ });
  const defaultColumns = useColumns();
  
  // Apply fallback pattern
  const finalFilters = filters ?? defaultFilters;
  const finalColumns = columns ?? defaultColumns;
  
  // Handle search with custom or default behavior
  const handleSearch = (e) => {
    const searchTerm = e.target.value;
    if (customSearch) {
      customSearch(searchTerm);
    } else {
      // Default search logic
      if (searchTerm) {
        setSearch(searchFields(searchTerm));
      } else {
        setSearch([]);
      }
    }
  };
  
  // Combine fixed and parent filters
  const allFixedFilters = useMemo(() => {
    const filters = [...fixedFilter];
    if (parentFilter) {
      filters.push({
        fieldName: parentFilter.fieldName,
        comparator: SearchComparator.EQUAL,
        searchValue: parentFilter.value,
      });
    }
    return filters;
  }, [fixedFilter, parentFilter]);
```

### 3. Implement Conditional UI Rendering

Use the props to conditionally render UI elements:

```typescript
return (
  <Content>
    {/* Conditional Header */}
    {!hideHeader && !tabMode && (
      <ListModuleHeader
        title={MODULE_NAME}
        tagline={MODULE_TAGLINE}
        breadcrumbs={props.breadcrumbs ?? defaultBreadcrumbs}
      />
    )}
    
    {/* Conditional Dashboard */}
    {!hideDashboard && !tabMode && (
      <Box px={5} pb="20px">
        <ModuleCards cards={dashboardCards} />
      </Box>
    )}
    
    {/* Adaptive Container Styling */}
    <Box px={tabMode ? 0 : 5}>
      <Content
        $css={
          tabMode
            ? 'padding: 0px !important; border: 0px;'
            : 'padding: 20px 20px 0 20px !important;'
        }
      >
        {/* Your main content */}
        <DataTable
          columns={finalColumns}
          filters={finalFilters}
          searchFields={combinedSearchFields}
          onSearch={handleSearch}
          // ... other props
        />
      </Content>
    </Box>
  </Content>
);
```

### 4. Handle Fixed Filters Integration

Ensure fixed filters are always applied to search/filter logic:

```typescript
const searchArgs = useMemo(() => {
  const fieldMap = new Map();

  // Add search arguments
  searchArg.forEach(searchItem => {
    fieldMap.set(searchItem.fieldName, searchItem);
  });

  // Add user search
  search.forEach(searchItem => {
    fieldMap.set(searchItem.fieldName, searchItem);
  });

  // Add fixed filters (always applied)
  allFixedFilters.forEach(filter => {
    fieldMap.set(filter.fieldName, filter);
  });

  // Add list filters
  listFilters.forEach(filter => {
    fieldMap.set(filter.fieldName, filter);
  });

  return Array.from(fieldMap.values());
}, [searchArg, search, allFixedFilters, listFilters]);
```

## Generic Tab Wrapper Pattern

### 1. Create Reusable Tab Wrapper

```typescript
// Generic tab wrapper template
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { SearchComparator } from '@/typings/module.types';

interface TabWrapperProps {
  parentId?: string;
  parentFieldName: string;  // e.g., 'site.id', 'account.id', 'contact.id'
  columns?: any[];
  customRoutes?: any;
  [key: string]: any;       // Allow additional props
}

const createTabWrapper = (
  MainComponent: React.ComponentType<any>,
  defaultColumns?: any,
  routeGenerator?: (parentId: string) => any
) => {
  return (props: TabWrapperProps) => {
    const { id } = useParams();
    const { parentId, parentFieldName, columns, customRoutes, ...otherProps } = props;
    const finalParentId = parentId || props?.id || id;

    return (
      <MainComponent
        hideDashboard={true}
        tabMode={true}
        columns={columns || (defaultColumns ? defaultColumns({ id: finalParentId }) : undefined)}
        parentFilter={{
          fieldName: parentFieldName,
          value: finalParentId,
        }}
        customRoutes={customRoutes || (routeGenerator ? routeGenerator(finalParentId) : undefined)}
        {...otherProps}
      />
    );
  };
};

export default createTabWrapper;
```

### 2. Use the Tab Wrapper

```typescript
// SiteDeals.tsx - Specific implementation
import createTabWrapper from '@/components/generic/createTabWrapper';
import DealsList from '@/views/sales/deals/list';
import { siteDealsListColumns } from './columns';

const siteRouteGenerator = (siteId: string) => ({
  view: (dealId: string) => `/accounts/sites/${siteId}/deals/${dealId}`,
  edit: (dealId: string) => `/sales/deals/${dealId}/edit`,
  new: `/accounts/sites/${siteId}/deals/new`,
});

const SiteDeals = createTabWrapper(
  DealsList,
  siteDealsListColumns,
  siteRouteGenerator
);

// Usage
<SiteDeals 
  parentFieldName="site.id" 
  parentId={siteId}
  {...props} 
/>
```

## Context-Specific Implementations

### Example 1: Contact Deals

```typescript
// ContactDeals.tsx
import createTabWrapper from '@/components/generic/createTabWrapper';
import DealsList from '@/views/sales/deals/list';
import { contactDealsListColumns } from './columns';

const contactRouteGenerator = (contactId: string) => ({
  view: (dealId: string) => `/accounts/contacts/${contactId}/deals/${dealId}`,
  edit: (dealId: string) => `/sales/deals/${dealId}/edit`,
  new: `/accounts/contacts/${contactId}/deals/new`,
});

const ContactDeals = createTabWrapper(
  DealsList,
  contactDealsListColumns,
  contactRouteGenerator
);

export default ContactDeals;
```

### Example 2: Account Jobs

```typescript
// AccountJobs.tsx
import createTabWrapper from '@/components/generic/createTabWrapper';
import JobsList from '@/views/jobs/list';
import { accountJobsListColumns } from './columns';

const accountJobsRouteGenerator = (accountId: string) => ({
  view: (jobId: string) => `/accounts/accounts/${accountId}/jobs/${jobId}`,
  edit: (jobId: string) => `/jobs/${jobId}/edit`,
  new: `/accounts/accounts/${accountId}/jobs/new`,
});

const AccountJobs = createTabWrapper(
  JobsList,
  accountJobsListColumns,
  accountJobsRouteGenerator
);

export default AccountJobs;
```

## Step-by-Step Migration Guide

### Phase 1: Analyze Current Implementation

1. **Identify duplicated components**:
   ```
   MainComponent.tsx      (~400 lines)
   TabComponent1.tsx      (~600 lines)  
   TabComponent2.tsx      (~500 lines)
   ```

2. **Document differences**:
   - UI variations (header, dashboard, styling)
   - Column differences
   - Filter variations
   - Navigation patterns

### Phase 2: Refactor Main Component

1. **Add props interface**:
   ```typescript
   interface MainComponentProps {
     hideDashboard?: boolean;
     tabMode?: boolean;
     columns?: any[];
     // ... other props
   }
   ```

2. **Implement fallback patterns**:
   ```typescript
   const finalColumns = columns ?? defaultColumns;
   const finalFilters = filters ?? defaultFilters;
   ```

3. **Add conditional rendering**:
   ```typescript
   {!hideDashboard && <Dashboard />}
   {!tabMode && <Header />}
   ```

4. **Update styling logic**:
   ```typescript
   <Box px={tabMode ? 0 : 5}>
     <Content $css={tabMode ? 'embedded-styles' : 'full-page-styles'}>
   ```

### Phase 3: Create Tab Wrappers

1. **Use generic wrapper pattern**:
   ```typescript
   const YourTabComponent = createTabWrapper(
     YourMainComponent,
     customColumns,
     routeGenerator
   );
   ```

2. **Test functionality**:
   - Search and filtering
   - Sorting and pagination
   - Actions and navigation
   - Data loading and error states

### Phase 4: Clean Up

1. **Remove old tab components**
2. **Update imports/exports**
3. **Update route configurations**
4. **Test all integration points**

## Benefits of This Pattern

### Code Reduction
- **Before**: MainComponent (400 lines) + TabComponent1 (600 lines) + TabComponent2 (500 lines) = 1,500 lines
- **After**: Enhanced MainComponent (450 lines) + TabWrapper1 (20 lines) + TabWrapper2 (20 lines) = 490 lines
- **Savings**: ~67% code reduction

### Consistency
- Single source of truth for all functionality
- Identical behavior across contexts
- Unified bug fixes and feature additions

### Maintainability  
- Changes made once, applied everywhere
- Easier testing and debugging
- Clear separation of concerns

### Flexibility
- Easy to create new embedded contexts
- Configurable for different use cases
- Extensible props interface

## Common Patterns by Module Type

### List/Table Modules
```typescript
interface ListModuleProps {
  hideDashboard?: boolean;
  tabMode?: boolean;
  columns?: any[];
  filters?: any;
  fixedFilter?: any[];
  parentFilter?: { fieldName: string; value: string };
}
```

### Form/Detail Modules  
```typescript
interface DetailModuleProps {
  hideHeader?: boolean;
  tabMode?: boolean;
  customFields?: any[];
  readOnly?: boolean;
  parentContext?: { type: string; id: string };
}
```

### Dashboard/Analytics Modules
```typescript
interface DashboardModuleProps {
  compactMode?: boolean;
  hiddenCards?: string[];
  customDateRange?: { start: Date; end: Date };
  parentFilter?: { fieldName: string; value: string };
}
```

## Real-World Example: Deals Component Refactoring

This pattern was successfully applied to the deals module with the following results:

### Before Refactoring
- Main deals list: 400+ lines
- Site deals tab: 700+ lines  
- Total duplicated functionality

### After Refactoring
- Enhanced main component: 450 lines with props support
- Site deals tab: 20 lines using the main component
- **68% code reduction** (680+ lines eliminated)

### Implementation
```typescript
// Main component usage (full page)
<DealsList />

// Tab usage (embedded)
<DealsList
  hideDashboard={true}
  tabMode={true}
  columns={siteDealsListColumns({ id: siteId })}
  fixedFilter={[{
    fieldName: 'site.id',
    comparator: SearchComparator.EQUAL,
    searchValue: siteId,
  }]}
/>
```

This generic pattern can be applied to any module that needs both standalone and embedded implementations, ensuring consistency while eliminating code duplication across your application. 