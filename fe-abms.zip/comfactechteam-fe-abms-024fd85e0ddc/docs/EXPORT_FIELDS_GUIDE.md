# Export Fields Implementation Guide

## Overview

This guide provides best practices and implementation patterns for creating export fields in the ABMS application. Export fields define how data is transformed and formatted when exporting records to CSV or other formats.

**Key Principles:**
1. **Export fields should match exactly what's displayed in the corresponding table columns**
2. **Exports must respect all current table filters and search criteria**
3. **Export order should follow the exact order of table columns**

## Basic Structure

Export fields are defined as an array of objects with the following structure:

```typescript
export const exportFields = [
  {
    title: 'Column Header',           // Must match column header exactly
    field: 'fieldName',               // Field path in the data object
    transform: (fieldValue, allData) => {  // Optional transformation function
      return formattedValue;
    },
  },
];
```

## Core Principles

### 1. Data Validation
Always validate data before displaying it to prevent empty or invalid values from appearing in exports.

**Use `isValueValid()` for validation:**
```typescript
import { isValueValid } from '@/utils/helper.utils';

// Check if a value is not null, undefined, or empty string
if (isValueValid(data.someField)) {
  // Use the field
}
```

### 2. Empty String Returns
**Always return empty strings for missing data, never "No data" messages:**
```typescript
// ✅ CORRECT - Return empty string
if (!contactData?.fullName) return '';

// ❌ WRONG - Don't use fallback messages
if (!contactData?.fullName) return 'No contact';
```

### 3. Progressive Data Building
Build complex field outputs progressively, only adding components that have valid data.

**Example - Contact Information:**
```typescript
{
  title: 'Primary contact',
  field: 'contact.fullName',
  transform: (contact, allData) => {
    const contactData = allData?.contact;
    if (!contactData?.fullName) return '';

    let result = contactData.fullName;

    if (isValueValid(contactData.jobTitle)) {
      result += `\n${contactData.jobTitle}`;
    }

    if (isValueValid(contactData.phone)) {
      result += `\n${contactData.phone}`;
    }

    if (isValueValid(contactData.mobile)) {
      result += `\n${contactData.mobile}`;
    }

    if (isValueValid(contactData.email)) {
      result += `\n${contactData.email}`;
    }

    return result;
  },
},
```

### 4. Filter Compliance
**Exports must respect all current table filters and search criteria:**

The export functionality should ensure that only data matching the current table filters is exported. This includes:
- Text search terms
- Status filters (Active/Inactive/All)
- Location filters
- Account type filters
- Any custom filters applied through the filter panel

**Implementation Pattern:**
```typescript
// In the export useEffect handler
useEffect(() => {
  if (
    forceLoadAllData &&
    !isDataLoading &&
    allQueryData &&
    allQueryData.length > 0
  ) {
    try {
      setIsExporting(true);
      // allQueryData contains filtered data when forceLoadAllData is true
      // because DataTable applies current searchArg filters to the query
      const csvData = mapArrToCSVFields(
        sortCSVData(allQueryData, sortArg),
        exportFields
      );
      const base64CSV = convertToCSVBase64(csvData);
      saveCSVFile(base64CSV, MODULE_NAME);
      snackbar({ type: 'success', message: 'Data exported successfully!' });
    } catch (error) {
      console.error('Export error:', error);
      snackbar({ type: 'error', message: 'Failed to export data.' });
    } finally {
      setIsExporting(false);
      setForceLoadAllData(false);
    }
  }
}, [forceLoadAllData, allQueryData, isDataLoading, sortArg, snackbar]);
```

### 4. Address Formatting
For address fields, combine multiple address components but only if they contain valid data.

**Example - Site with Address:**
```typescript
{
  title: 'Site',
  field: 'site.siteName',
  transform: (siteName, allData) => {
    if (!allData?.site?.siteName) return '';
    
    const address = allData?.site?.address || allData?.site?.fullAddress;
    return isValueValid(address)
      ? `${allData?.site?.siteName}\n${address}`
      : `${allData?.site?.siteName}`;
  },
},
```

## Column-Export Alignment

### Match Column Display Exactly
Export fields must render the same information as their corresponding table columns.

**Steps to ensure alignment:**
1. **Identify the column component** (e.g., `ViewPrimaryContactCard`, `StatusTag`)
2. **Extract the display logic** from the column render function
3. **Apply the same logic** in the export transform function
4. **Remove any React components** and convert to plain text

**Example - Account Column vs Export:**
```typescript
// Column render (from columns.tsx)
render: (_, record: DealModel) => (
  <Link to={`${Routes['Account']?.view}/${record?.account?.id}`}>
    {record?.account?.name}
  </Link>
)

// Export transform (from fields.tsx)
{
  title: 'Account',
  field: 'account.name',
  transform: (account, allData) => {
    return allData?.account?.name || '';  // Return empty string, not "No account"
  },
},
```

### Follow Table Column Order
Export fields must follow the exact same order as the table columns.

**Steps to ensure correct order:**
1. **Review table column definitions** in the columns file
2. **Match export field order** to table column order exactly
3. **Use exact column titles** for export field titles
4. **Maintain consistent casing** (e.g., "Bill no." not "Bill No.")

**Example - Table Columns vs Export Fields:**
```typescript
// Table columns (from columns.tsx)
export const listColumns = [
  { title: 'Account', ... },
  { title: 'Account type', ... },
  { title: 'Primary contact', ... },
  { title: 'Location', ... },
  { title: 'Status', ... },
];

// Export fields (from fields.tsx) - MUST follow same order
export const exportFields = [
  { title: 'Account', ... },
  { title: 'Account type', ... },
  { title: 'Primary contact', ... },
  { title: 'Location', ... },
  { title: 'Status', ... },
];
```

## Common Patterns

### Currency Formatting
```typescript
{
  title: 'Deal amount (GST exclusive)',
  field: 'costingAmount',
  transform: costingAmount => {
    if (!costingAmount && costingAmount !== 0) return '';
    
    return costingAmount < 0
      ? `($ ${formatNumber(Math.abs(costingAmount))})`
      : `$ ${formatNumber(costingAmount)}`;
  },
},
```

### Date/Time Formatting
```typescript
{
  title: 'Created at',
  field: 'createdAt',
  transform: data => {
    if (!data) return '';
    const dd = dayjs(data);
    return `${dd.format(dateFormat)} ${dd.format(timeFormat)}`;
  },
},
```

### Name Formatting
```typescript
{
  title: 'Record owner',
  field: 'recordOwner.fullName',
  transform: (statusData, allData) => {
    const owner = allData?.recordOwner;
    if (!owner?.firstName) return '';
    return `${owner.firstName} ${owner.lastName}`;
  },
},
```

### Status Formatting
```typescript
{
  title: 'Status',
  field: 'status.name',
  transform: (statusData, allData) => {
    return allData?.status?.name ? toSentenceCase(allData?.status?.name) : '';
  },
},
```

## Advanced Patterns

### Conditional Field Display
```typescript
{
  title: 'Contact Details',
  field: 'contact',
  transform: (contact, allData) => {
    const contactData = allData?.contact;
    if (!contactData?.fullName) return '';

    const details = [];
    
    if (isValueValid(contactData.fullName)) {
      details.push(contactData.fullName);
    }
    
    if (isValueValid(contactData.jobTitle)) {
      details.push(contactData.jobTitle);
    }
    
    return details.join('\n');
  },
},
```

### Multiple Field Combination
```typescript
{
  title: 'Location & Address',
  field: 'location.name',
  transform: (locationName, allData) => {
    const location = allData?.location?.name;
    const site = allData?.site;
    
    if (!isValueValid(location)) return '';
    
    let result = location;
    
    if (site && isValueValid(site.siteName)) {
      result += `\nSite: ${site.siteName}`;
      
      const address = site.address || site.fullAddress;
      if (isValueValid(address)) {
        result += `\nAddress: ${address}`;
      }
    }
    
    return result;
  },
},
```

### Array Data Handling
```typescript
{
  title: 'Services',
  field: 'services',
  transform: (services, allData) => {
    if (!Array.isArray(allData?.services) || allData.services.length === 0) {
      return '';
    }
    
    return allData.services
      .filter(service => isValueValid(service.name))
      .map(service => service.name)
      .join(', ');
  },
},
```

## Best Practices

### 1. Field Naming
- Use **exact column titles** from the table headers
- Keep titles concise but clear
- Use consistent naming conventions

### 2. Data Fallbacks
- **Always return empty strings** for missing data
- Never use "No data", "No contact", "No account" etc.
- Use consistent fallback patterns across fields

### 3. Formatting Consistency
- Use consistent date/time formats across all exports
- Apply consistent currency formatting
- Maintain consistent line break patterns

### 4. Performance Considerations
- Keep transform functions lightweight
- Avoid complex calculations in transform functions
- Cache expensive operations when possible

### 5. Error Handling
```typescript
{
  title: 'Complex Field',
  field: 'complexData',
  transform: (fieldValue, allData) => {
    try {
      // Complex transformation logic
      return processComplexData(allData);
    } catch (error) {
      console.error('Export transform error:', error);
      return '';  // Return empty string on error
    }
  },
},
```

## Common Utilities

### Required Imports
```typescript
import { isValueValid, formatNumber, toSentenceCase } from '@/utils/helper.utils';
import { dateFormat, timeFormat } from '@/utils/date.utils';
import dayjs from 'dayjs';
```

### Utility Functions
- `isValueValid(value)` - Check if value is not null/undefined/empty
- `formatNumber(amount)` - Format currency with commas and decimals
- `toSentenceCase(str)` - Convert string to sentence case
- `haveData(data)` - React component for displaying data or "No data" (DO NOT use in exports)

## Testing Export Fields

### Manual Testing
1. Export with complete data records
2. Export with missing/null fields
3. Export with empty arrays/objects
4. Verify formatting in different spreadsheet applications
5. **Compare exported data with table column display**
6. **Test export with various filter combinations**
7. **Verify export respects current table filters**

### Validation Checklist
- [ ] All fields handle null/undefined values gracefully
- [ ] Multi-line fields display correctly in CSV
- [ ] Currency values are properly formatted
- [ ] Dates are in consistent format
- [ ] **No "undefined" or "null" text appears in export**
- [ ] **No fallback messages like "No data" appear in export**
- [ ] Line breaks work correctly in target applications
- [ ] **Export content matches table column content exactly**
- [ ] **Export order matches table column order exactly**
- [ ] **Export respects current text search filters**
- [ ] **Export respects current status filters (Active/Inactive/All)**
- [ ] **Export respects current location filters**
- [ ] **Export respects current account type filters**
- [ ] **Export respects all custom filters applied through filter panel**

## Example Implementation

```typescript
export const dealExportFields = [
  {
    title: 'Deal no.',  // Exact column title
    field: 'dealNo',
  },
  {
    title: 'Account',   // Exact column title
    field: 'account.name',
    transform: (account, allData) => {
      return allData?.account?.name || '';  // Empty string, not "No account"
    },
  },
  {
    title: 'Site',     // Exact column title
    field: 'site.siteName',
    transform: (siteName, allData) => {
      if (!allData?.site?.siteName) return '';
      
      const address = allData?.site?.address || allData?.site?.fullAddress;
      return isValueValid(address)
        ? `${allData?.site?.siteName}\n${address}`
        : `${allData?.site?.siteName}`;
    },
  },
  {
    title: 'Primary contact',  // Exact column title
    field: 'contact.fullName',
    transform: (contact, allData) => {
      const contactData = allData?.contact;
      if (!contactData?.fullName) return '';

      let result = contactData.fullName;

      if (isValueValid(contactData.jobTitle)) {
        result += `\n${contactData.jobTitle}`;
      }

      if (isValueValid(contactData.phone)) {
        result += `\n${contactData.phone}`;
      }

      if (isValueValid(contactData.mobile)) {
        result += `\n${contactData.mobile}`;
      }

      if (isValueValid(contactData.email)) {
        result += `\n${contactData.email}`;
      }

      return result;
    },
  },
  {
    title: 'Deal amount (GST exclusive)',  // Exact column title
    field: 'costingAmount',
    transform: costingAmount => {
      if (!costingAmount && costingAmount !== 0) return '';
      
      return costingAmount < 0
        ? `($ ${formatNumber(Math.abs(costingAmount))})`
        : `$ ${formatNumber(costingAmount)}`;
    },
  },
];
```

## Troubleshooting

### Common Issues
1. **"undefined" appearing in export**: Check for proper null/undefined handling
2. **Line breaks not working**: Ensure consistent `\n` usage and proper CSV escaping
3. **Currency formatting issues**: Use `formatNumber()` utility consistently
4. **Fallback messages in export**: Replace all "No data" messages with empty strings
5. **Export doesn't match table**: Review column render logic and apply same logic to export
6. **Export order doesn't match table**: Ensure export fields follow exact table column order
7. **Export includes unfiltered data**: Verify `forceLoadAllData` uses current `searchArg` filters
8. **Export ignores search terms**: Check that `searchArg` includes both search and filter criteria

### Debug Tips
- Log transform function inputs: `console.log('Transform input:', fieldValue, allData)`
- Test with minimal data sets
- Validate field paths match actual data structure
- Check browser console for transformation errors
- **Compare side-by-side**: table display vs export output
- **Test filter combinations**: Verify exports respect multiple active filters
- **Check searchArg construction**: Ensure `[...search, ...listFilters]` includes all filters

## Filter Compliance Implementation

### How Filtered Export Works

The export functionality must respect all current table filters and search criteria. Here's the implementation pattern:

```typescript
// 1. Filter Collection
const searchArg = [...search, ...listFilters]; // Combines search + filters

// 2. Export Handler
const onCustomExport = async () => {
  try {
    // Always force load data with current filters for export
    // This ensures the export respects current search and filter criteria
    snackbar({
      type: 'info',
      message: 'Loading filtered data for export...',
    });
    setForceLoadAllData(true);
    return []; // Return empty array while loading
  } catch (error) {
    console.error('Export error:', error);
    snackbar({
      type: 'error',
      message: 'Failed to export data.',
    });
    return [];
  }
};

// 3. Export Processing
useEffect(() => {
  if (
    forceLoadAllData &&
    !isDataLoading &&
    allQueryData &&
    allQueryData.length > 0
  ) {
    try {
      setIsExporting(true);
      // allQueryData contains filtered data when forceLoadAllData is true
      // because DataTable applies current searchArg filters to the query
      const csvData = mapArrToCSVFields(
        sortCSVData(allQueryData, sortArg),
        exportFields
      );
      const base64CSV = convertToCSVBase64(csvData);
      saveCSVFile(base64CSV, MODULE_NAME);
      snackbar({ type: 'success', message: 'Data exported successfully!' });
    } catch (error) {
      console.error('Export error:', error);
      snackbar({ type: 'error', message: 'Failed to export data.' });
    } finally {
      setIsExporting(false);
      setForceLoadAllData(false);
    }
  }
}, [forceLoadAllData, allQueryData, isDataLoading, sortArg, snackbar]);
```

### Filter Types Supported

The export functionality should respect all current table filters:

- **Text Search**: Any search terms entered in the search box
- **Status Filters**: Active/Inactive/All status filters from dashboard cards
- **Location Filters**: Location-based filtering
- **Account Type Filters**: Customer/Franchisee/Supplier/Subcontractor filters
- **Custom Filters**: Any additional filters applied through the filter panel
- **Combined Filters**: Multiple filters working together

### Example Scenarios

- **Filtered by Status**: If user has "Active" filter applied, export only contains active records
- **Search + Filter**: If user searches "John" and filters by "Customer", export contains only customer records with "John" in the name
- **Location Filter**: If user filters by specific location, export only contains records from that location
- **Combined Filters**: All multiple filters work together in the export

---

This guide should be updated as new patterns and requirements emerge. Always test export functionality thoroughly before deploying to production. 