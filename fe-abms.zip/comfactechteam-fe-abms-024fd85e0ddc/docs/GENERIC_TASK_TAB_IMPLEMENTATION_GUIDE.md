# Generic Task Tab Implementation Guide

This guide provides a comprehensive approach to implementing generic task tabs that maintain proper context, routing, and user experience patterns established in the ABMS application.

## Table of Contents

1. [Overview](#overview)
2. [Architecture Pattern](#architecture-pattern)
3. [Step-by-Step Implementation](#step-by-step-implementation)
4. [Code Examples](#code-examples)
5. [Best Practices](#best-practices)
6. [Integration Points](#integration-points)
7. [Troubleshooting](#troubleshooting)

## Overview

The generic task tab pattern allows any module to integrate task management functionality while maintaining:
- **Context-aware routing** - Tasks stay within the parent module's navigation context
- **Proper data relationships** - Tasks are automatically linked to the parent record
- **Consistent user experience** - Unified interface across all modules
- **Reusable components** - Leverages existing `TasksDataTable` and `TaskForm` components

## Architecture Pattern

### URL Structure
```
/{parentModule}/{parentId}/tasks/{action}
```

**Examples:**
- `/accounts/123/tasks/new` - Create new account task
- `/deals/456/tasks/789/edit` - Edit task 789 for deal 456
- `/jobs/321/tasks/654` - View task 654 for job 321

### Component Hierarchy
```
ParentModule
├── ParentModuleView
│   ├── ParentModuleTabs
│   │   └── TasksTab (List)
│   └── TasksNew
│   └── TasksEdit
│   └── TasksView
```

## Step-by-Step Implementation

### Step 1: Router Configuration

Add task routes to your parent module's router:

```tsx
// src/views/{parentModule}/index.tsx
<Route
  path='/:id/tasks/new'
  element={
    <RouteWithErrorBoundary
      moduleName='New {ParentModule} Task'
      modulePath='/{parentModule}'
    >
      <LazyLoader>
        <{ParentModule}TasksNew {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
<Route
  path='/:id/tasks/:taskId/edit'
  element={
    <RouteWithErrorBoundary
      moduleName='Edit {ParentModule} Task'
      modulePath='/{parentModule}'
    >
      <LazyLoader>
        <{ParentModule}TasksEdit {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
<Route
  path='/:id/tasks/:taskId'
  element={
    <RouteWithErrorBoundary
      moduleName='View {ParentModule} Task'
      modulePath='/{parentModule}'
    >
      <LazyLoader>
        <{ParentModule}TasksView {...props} />
      </LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
```

### Step 2: Create Lazy Components

```tsx
// src/views/{parentModule}/lazyComponents.tsx
export const {ParentModule}TasksNew = lazy(
  () => import('./{parentModule}/view/tabs/Tasks/new')
);
export const {ParentModule}TasksEdit = lazy(
  () => import('./{parentModule}/view/tabs/Tasks/edit')
);
export const {ParentModule}TasksView = lazy(
  () => import('./{parentModule}/view/tabs/Tasks/view')
);
```

### Step 3: Implement Task List Component

```tsx
// src/views/{parentModule}/{parentModule}/view/tabs/Tasks/list/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import { TasksDataTable } from '@/components/GenericTab/task';
import useNavigate from '@/hooks/useNavigate';
import Task from '@/models/Task';
import { SearchComparator } from '@/typings/module.types';

const {ParentModule}TasksTab = (props: {
  tab?: string;
  setTab?: (val: string) => void;
}) => {
  const { id } = useParams();
  const { navigate } = useNavigate('List');

  // Custom navigation handlers to stay within parent module context
  const handleNewTask = () => {
    navigate(`/{parentModule}/${id}/tasks/new?module={parentModule}&relatedToId=${id}`);
  };

  const handleEditTask = (task: Task) => {
    navigate(`/{parentModule}/${id}/tasks/${task.id}/edit`);
  };

  const handleViewTask = (task: Task) => {
    navigate(`/{parentModule}/${id}/tasks/${task.id}`);
  };

  // Search arguments for filtering tasks by parent record
  const searchArg = [
    {
      fieldName: '{parentModule}.id', // Adjust field name based on your schema
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <TasksDataTable
      id={id}
      module='{parentModule}'
      tab={props.tab}
      setTab={props.setTab}
      breadCrumbs={['{ParentModule}', 'View {ParentModule}', 'Tasks']}
      onNewTask={handleNewTask}
      onEditTask={handleEditTask}
      onViewTask={handleViewTask}
      searchArg={searchArg}
    />
  );
};

export default {ParentModule}TasksTab;
```

### Step 4: Implement Task Creation Component

```tsx
// src/views/{parentModule}/{parentModule}/view/tabs/Tasks/new/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import useNavigate from '@/hooks/useNavigate';
import { TaskForm } from '@/components/GenericTab/task';
import Task from '@/models/Task';

const {ParentModule}TasksNew = props => {
  const { id } = useParams();
  const { navigate } = useNavigate();

  const breadCrumbs = [
    { title: '{ParentModule}' },
    { title: '{ParentModule}' },
    { title: 'View {parentModule}' },
    { title: 'New task' },
  ];

  const handleTaskCreated = (task: Task) => {
    // Navigate to the task view within parent module context
    navigate(`/{parentModule}/${id}/tasks/${task.id}`);
  };

  return (
    <TaskForm
      mode='new'
      breadCrumbs={breadCrumbs}
      onTaskCreated={handleTaskCreated}
      relatedTo={{
        module: '{parentModule}',
      }}
      {parentModule}Id={id} // Adjust prop name based on your module
      {...props}
    />
  );
};

export default {ParentModule}TasksNew;
```

### Step 5: Implement Task Edit Component

```tsx
// src/views/{parentModule}/{parentModule}/view/tabs/Tasks/edit/index.tsx
import React from 'react';
import { useParams } from '@/utils/navigation.utils';
import useNavigate from '@/hooks/useNavigate';
import { TaskForm } from '@/components/GenericTab/task';
import Task from '@/models/Task';

const {ParentModule}TasksEdit = props => {
  const { id, taskId } = useParams();
  const { navigate } = useNavigate();

  const breadCrumbs = [
    { title: '{ParentModule}' },
    { title: '{ParentModule}' },
    { title: 'View {parentModule}' },
    { title: 'Edit task' },
  ];

  const handleTaskUpdated = (task: Task) => {
    // Navigate to the task view within parent module context
    navigate(`/{parentModule}/${id}/tasks/${task.id}`);
  };

  return (
    <TaskForm
      mode='edit'
      taskId={taskId}
      breadCrumbs={breadCrumbs}
      onTaskUpdated={handleTaskUpdated}
      relatedTo={{
        module: '{parentModule}',
      }}
      {parentModule}Id={id}
      {...props}
    />
  );
};

export default {ParentModule}TasksEdit;
```

### Step 6: Implement Task View Component

```tsx
// src/views/{parentModule}/{parentModule}/view/tabs/Tasks/view/index.tsx
import React from 'react';
import TasksView from '@/views/calendar/tasks/view';
import { useParams } from '@/utils/navigation.utils';
import { getViewRoute } from '@/mfe-utilities';

const {ParentModule}TasksView = props => {
  const { id, taskId } = useParams();
  
  const breadCrumbs = [
    { title: '{ParentModule}' },
    { title: '{ParentModule}' },
    { title: 'View {parentModule}' },
    { title: 'View task' },
  ];

  const parentUrl = `${getViewRoute('{ParentModule}')}/${id}`;

  return (
    <TasksView
      breadCrumbs={breadCrumbs}
      parentUrl={parentUrl}
      taskId={taskId}
      tabMode={true}
      {...props}
    />
  );
};

export default {ParentModule}TasksView;
```

### Step 7: Add Task Creation to Parent Module Actions

#### In Parent Module List Actions:
```tsx
// src/views/{parentModule}/{parentModule}/list/index.tsx
{
  type: 'custom',
  title: 'Create a task',
  icon: <MaterialIcon name='add' />,
  onClick: (record: {ParentModule}Model) =>
    navigate(
      `/{parentModule}/${record.id}/tasks/new?module={parentModule}&relatedToId=${record.id}`
    ),
},
```

#### In Parent Module View MoreActions:
```tsx
// src/views/{parentModule}/{parentModule}/view/tabs/{ParentModule}Info/sections/MoreActions.tsx
{
  icon: <MaterialIcon name='add' $css='color: #3137FD;' />,
  label: 'Create a task',
  onClick: () =>
    navigate(
      `/{parentModule}/${data.id}/tasks/new?module={parentModule}&relatedToId=${data.id}`
    ),
},
```

## Code Examples

### Complete Implementation Example (Deals Module)

#### Router Configuration
```tsx
// src/views/deals/index.tsx
<Route
  path='/:id/tasks/new'
  element={
    <RouteWithErrorBoundary moduleName='New Deal Task' modulePath='/deals'>
      <LazyLoader><DealsTasksNew {...props} /></LazyLoader>
    </RouteWithErrorBoundary>
  }
/>
```

#### Task List Implementation
```tsx
// src/views/deals/deals/view/tabs/Tasks/list/index.tsx
const DealsTasksTab = (props) => {
  const { id } = useParams();
  const { navigate } = useNavigate('List');

  const handleNewTask = () => {
    navigate(`/deals/${id}/tasks/new?module=deal&relatedToId=${id}`);
  };

  const searchArg = [
    {
      fieldName: 'deal.id',
      searchValue: id,
      comparator: SearchComparator.EQUAL,
    },
  ];

  return (
    <TasksDataTable
      id={id}
      module='deals'
      breadCrumbs={['Deals', 'View Deal', 'Tasks']}
      onNewTask={handleNewTask}
      searchArg={searchArg}
      {...props}
    />
  );
};
```

## Best Practices

### 1. URL Parameter Consistency
Always include context parameters in task creation URLs:
```tsx
// ✅ Good
`/accounts/${id}/tasks/new?module=account&relatedToId=${id}`

// ❌ Bad
`/accounts/${id}/tasks/new`
```

### 2. Navigation Context Preservation
Ensure navigation handlers keep users within the parent module:
```tsx
// ✅ Good - Stays in accounts context
const handleTaskCreated = (task: Task) => {
  navigate(`/accounts/${accountId}/tasks/${task.id}`);
};

// ❌ Bad - Redirects to generic calendar
const handleTaskCreated = (task: Task) => {
  navigate(`/calendar/tasks/${task.id}`);
};
```

### 3. Breadcrumb Consistency
Maintain consistent breadcrumb patterns across all modules:
```tsx
const breadCrumbs = [
  { title: 'ModuleName' },        // Module list
  { title: 'ModuleName' },        // Module list (repeated for consistency)
  { title: 'View module' },       // Current record view
  { title: 'Task action' },       // Task-specific action
];
```

### 4. Search Arguments
Use proper field names for filtering tasks by parent record:
```tsx
// For accounts
fieldName: 'account.id'

// For deals  
fieldName: 'deal.id'

// For jobs
fieldName: 'job.id'
```

### 5. Component Props
Pass the parent record ID using the appropriate prop name:
```tsx
// ✅ Consistent naming
<TaskForm accountId={id} />      // For accounts
<TaskForm dealId={id} />         // For deals  
<TaskForm jobId={id} />          // For jobs
```

## Integration Points

### 1. TasksDataTable Component
The `TasksDataTable` component handles:
- Task listing with filtering
- Pagination and sorting
- Action buttons (New, Edit, View, Delete)
- Search functionality

**Required Props:**
- `id` - Parent record ID
- `module` - Parent module name
- `breadCrumbs` - Navigation breadcrumbs
- `onNewTask` - New task handler
- `onEditTask` - Edit task handler  
- `onViewTask` - View task handler
- `searchArg` - Search filters

### 2. TaskForm Component
The `TaskForm` component handles:
- Task creation and editing
- Form validation
- Relationship setup
- Success callbacks

**Required Props:**
- `mode` - 'new' or 'edit'
- `breadCrumbs` - Navigation breadcrumbs
- `relatedTo` - Parent module context
- `{parentModule}Id` - Parent record ID
- `onTaskCreated/onTaskUpdated` - Success callbacks

### 3. TasksView Component
The `TasksView` component handles:
- Task detail display
- Related data viewing
- Navigation context

**Required Props:**
- `breadCrumbs` - Navigation breadcrumbs
- `parentUrl` - Parent record URL
- `taskId` - Task ID to display

## Troubleshooting

### Common Issues and Solutions

#### 1. Tasks Not Filtered by Parent Record
**Problem:** All tasks show instead of just parent record tasks
**Solution:** Verify the `searchArg` field name matches your GraphQL schema
```tsx
// Check your GraphQL schema for the correct relationship field
const searchArg = [
  {
    fieldName: 'account.id', // Must match schema exactly
    searchValue: id,
    comparator: SearchComparator.EQUAL,
  },
];
```

#### 2. Navigation Breaks Parent Context
**Problem:** Task actions redirect to generic calendar views
**Solution:** Ensure all navigation handlers use parent module URLs
```tsx
// ✅ Correct
navigate(`/accounts/${id}/tasks/${task.id}`);

// ❌ Incorrect  
navigate(`/calendar/tasks/${task.id}`);
```

#### 3. Missing Parent Record Relationship
**Problem:** Created tasks aren't linked to parent record
**Solution:** Verify the `relatedTo` prop and parent ID prop are correctly set
```tsx
<TaskForm
  relatedTo={{ module: 'account' }}
  accountId={id} // Must match the expected prop name
/>
```

#### 4. Breadcrumb Navigation Issues
**Problem:** Breadcrumbs don't navigate correctly
**Solution:** Ensure breadcrumbs array structure matches expected format
```tsx
const breadCrumbs = [
  { title: 'Accounts' },          // Should link to /accounts
  { title: 'Accounts' },          // Repeated for consistency
  { title: 'View account' },      // Should link to /accounts/:id
  { title: 'New task' },          // Current page (no link)
];
```

#### 5. Route Not Found Errors
**Problem:** Task routes return 404 errors
**Solution:** Verify routes are properly configured in parent module router
```tsx
// Ensure these routes exist in your parent module's index.tsx
<Route path='/:id/tasks/new' element={...} />
<Route path='/:id/tasks/:taskId/edit' element={...} />
<Route path='/:id/tasks/:taskId' element={...} />
```

## Module-Specific Customizations

### Search Field Customization
Different modules may need different search configurations:

```tsx
// Accounts - search by account relationship
fieldName: 'account.id'

// Deals - search by deal relationship  
fieldName: 'deal.id'

// Jobs - search by job relationship
fieldName: 'job.id'

// Custom modules - check your GraphQL schema
fieldName: 'yourModule.id'
```

### Breadcrumb Customization
Adjust breadcrumbs to match your module's navigation structure:

```tsx
// Standard pattern
const breadCrumbs = [
  { title: 'Your Module' },
  { title: 'Your Module' },
  { title: 'View your module' },
  { title: 'Task action' },
];
```

### Parent URL Generation
Use the appropriate route helper for your module:

```tsx
const parentUrl = `${getViewRoute('YourModule')}/${id}`;
```

## Testing Checklist

- [ ] Task creation navigates to correct URL
- [ ] Task editing works within parent context
- [ ] Task viewing maintains breadcrumbs
- [ ] Task list filters by parent record only
- [ ] All navigation stays within parent module
- [ ] Breadcrumbs navigate correctly
- [ ] Created tasks are properly related to parent record
- [ ] Parent module actions create tasks with correct context
- [ ] URL parameters are preserved during navigation
- [ ] Error boundaries handle failures gracefully

## Conclusion

This generic task tab pattern provides a robust, scalable solution for integrating task management into any module while maintaining proper context and user experience. Following these patterns ensures consistency across the application and leverages existing components effectively.

For questions or issues not covered in this guide, refer to the existing account implementation as a reference or consult the development team. 