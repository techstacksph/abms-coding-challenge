# CLAUDE.md - FE-ABMS Project Guide

## Project Overview

**ABMS Frontend Application** - A comprehensive React TypeScript application built with Vite for Account and Business Management System. This is a modern web application with advanced form management, routing, GraphQL integration, and business process automation.

## Technology Stack

- **Framework**: React 18.2.0 with TypeScript
- **Build Tool**: Vite 6.0.0 (ES modules, fast HMR)
- **UI Libraries**: Ant Design 5.26.5, Material-UI 5.14.9
- **State Management**: Zustand 5.0.6, Apollo Client 3.8.4 (GraphQL)
- **Routing**: React Router DOM 6.8.0
- **Styling**: Styled Components 6.1.19, Emotion
- **Data Handling**: GraphQL with Apollo Client, Axios for REST
- **Package Manager**: Yarn 4.9.2

## Key Dependencies

### Core Libraries
- **Apollo Client**: GraphQL client for data fetching and caching
- **Ant Design + Material-UI**: Dual UI library setup for comprehensive component library
- **React Router**: Client-side routing with lazy loading support
- **Zustand**: Lightweight state management
- **Day.js**: Date manipulation and formatting
- **Styled Components**: CSS-in-JS styling solution

### Specialized Features
- **@fullcalendar/react**: Calendar components for scheduling
- **@react-google-maps/api**: Google Maps integration
- **@react-pdf/renderer**: PDF generation
- **react-signature-canvas**: Digital signature capture
- **@dnd-kit**: Drag and drop functionality
- **react-quill**: Rich text editor

## Project Structure

```
src/
├── api/                 # REST API service layer
├── components/          # Reusable UI components (100+ components)
│   ├── ui/             # Basic UI components
│   └── business/       # Business logic components
├── views/              # Page-level components
├── hooks/              # Custom React hooks (32+ hooks)
├── services/           # Business logic and external service integrations
├── graphql/            # GraphQL queries, mutations, subscriptions (150+ files)
├── models/             # TypeScript type definitions (165+ models)
├── utils/              # Utility functions and helpers
├── constants/          # Application constants
├── context/            # React context providers
├── stores/             # Zustand store definitions
├── styled-components/  # Styled component definitions
├── typings/            # Type definitions
└── router.tsx          # Application routing configuration
```

## Development Commands

### Core Development
```bash
yarn dev                 # Start development server (port 3000)
yarn build              # Production build
yarn preview            # Preview production build
```

### Testing
```bash
yarn test               # Run unit tests (Vitest)
yarn test:watch         # Run tests in watch mode
yarn test:coverage      # Generate test coverage report
yarn test:ui            # Open Vitest UI
yarn test:e2e           # Run Playwright e2e tests
yarn test:e2e:ui        # Run e2e tests with UI
yarn test:e2e:headed    # Run e2e tests in headed mode
yarn test:e2e:debug     # Debug e2e tests
```

### Code Quality
```bash
yarn lint               # Fix ESLint issues
yarn lint:check         # Check ESLint without fixing
yarn type-check         # TypeScript type checking
yarn format             # Format code with Prettier
yarn format:check       # Check code formatting
```

### Docker Operations
```bash
yarn docker:dev         # Start development environment
yarn docker:prod        # Start production environment
yarn docker:build       # Build Docker images
yarn docker:stop        # Stop Docker containers
yarn docker:clean       # Clean Docker resources
```

## Development Guidelines

### File Organization
- Use TypeScript path aliases (@/) for imports
- Components should be organized by domain/feature
- Shared utilities go in `/utils`
- Business logic belongs in `/services`
- GraphQL operations in `/graphql` with proper organization

### Code Conventions
- **TypeScript**: Strict mode enabled with relaxed rules for development velocity
- **ESLint**: Extended configuration with React, TypeScript, and Prettier integration
- **Import Organization**: Use TypeScript path resolver for clean imports
- **Styling**: Prefer styled-components for component-level styles
- **Testing**: Vitest for unit tests, Playwright for e2e testing

### Path Aliases
All major directories have path aliases configured:
- `@/` → `src/`
- `@/components/` → `src/components/`
- `@/hooks/` → `src/hooks/`
- `@/services/` → `src/services/`
- `@/utils/` → `src/utils/`
- `@/graphql/` → `src/graphql/`
- `@/models/` → `src/models/`
- And many more...

## Environment Configuration

### Required Environment Variables
```bash
VITE_APOLLO_URI=         # GraphQL endpoint
VITE_APOLLO_WS=          # GraphQL WebSocket endpoint
VITE_AUTH_URI=           # Authentication service URL
VITE_API_URL=            # REST API base URL
VITE_TENANT_PREFIX=      # Multi-tenant prefix
VITE_GOOGLE_API_KEY=     # Google Maps API key
VITE_PORT=3000           # Development server port
```

## Testing Strategy

### Unit Testing (Vitest)
- **Framework**: Vitest with jsdom environment
- **Setup**: Global test setup in `src/test/setup.ts`
- **Coverage**: Available via `yarn test:coverage`
- **File Pattern**: `**/*.{test,spec}.{js,ts,jsx,tsx}`

### E2E Testing (Playwright)
- **Framework**: Playwright with Chrome browser
- **Configuration**: Comprehensive setup in `playwright.config.ts`
- **Authentication**: Global auth setup with state persistence
- **Test Location**: `/e2e` directory
- **CI Integration**: Optimized for CI/CD pipelines

### MCP Playwright (Development Testing)
- **Preferred Tool**: Use MCP Playwright for development testing and debugging
- **Test Credentials**:
  - Username: `eugene@ayr-dev`
  - Password: `Ctodev@123`
- **Usage**: MCP Playwright provides interactive browser automation for development workflows

## Build Configuration

### Vite Configuration
- **Optimized Chunks**: Vendor, Ant Design, Material-UI, Apollo, Router
- **Asset Handling**: Proper hashing for cache busting
- **Source Maps**: Configurable via environment variable
- **HMR**: Hot module replacement on port 24678
- **Service Worker**: Automatic cache version updates during build

### TypeScript Configuration
- **Target**: ES2020 with modern browser support
- **Strict Mode**: Enabled with pragmatic relaxations for development
- **Path Mapping**: Comprehensive alias system for clean imports
- **Module Resolution**: Node.js style with TypeScript extensions

## Documentation

The project includes extensive documentation in the `/docs` directory:
- **Routing Guide**: Application routing architecture
- **Component Migration Guides**: For major component updates
- **Component Reuse Pattern**: Guide for converting duplicate components to wrappers ([docs/component-reuse-pattern.md](./docs/component-reuse-pattern.md))
- **CSV Export Guidelines**: Data export implementation
- **Event Tab Implementation**: Feature-specific guides
- **Environment Alignment**: Multi-environment setup
- **Responsive Design Guide**: Mobile-first design principles

## Key Features

- **Multi-tenant Architecture**: Configurable tenant prefixes
- **GraphQL Integration**: Comprehensive query/mutation/subscription setup
- **Real-time Updates**: WebSocket integration for live data
- **PDF Generation**: Server-side PDF rendering capabilities
- **Map Integration**: Google Maps with location services
- **Calendar System**: Full-featured calendar with recurring events
- **Drag & Drop**: Sortable lists and interactive components
- **Digital Signatures**: Canvas-based signature capture
- **Rich Text Editing**: WYSIWYG editor integration
- **Responsive Design**: Mobile-first responsive layouts

## Getting Started Checklist

1. **Environment Setup**: Copy `.env.example` to `.env` and configure variables
2. **Dependencies**: Run `yarn install`
3. **Development**: Start with `yarn dev`
4. **Type Checking**: Ensure `yarn type-check` passes
5. **Testing**: Run `yarn test` to verify setup
6. **Linting**: Check code quality with `yarn lint:check`

## Development Testing

### MCP Playwright Setup
For interactive browser testing during development, use MCP Playwright tools with these credentials:
- **Application URL**: http://localhost:3005 (frontend already running)
- **Login URL**: Application login page
- **Username**: `eugene@ayr-dev`
- **Password**: `Ctodev@123`

Use MCP Playwright for:
- Manual testing of new features
- Debugging UI interactions
- Validating form submissions
- Testing authentication flows

## Common Tasks

### Git Branching Strategy

#### Creating Feature Branches from Development
```bash
# Start from development
git checkout development
git pull origin development

# Create feature branch
git checkout -b feature/TICKET-NUMBER-description

# Make changes, commit, and push
git add .
git commit -m "commit message"
git push -u origin feature/TICKET-NUMBER-description
```

#### Applying Development Changes to Sandbox (ayr/sandbox)
When you have a feature branch that was created from `development` and need to apply the same changes to `ayr/sandbox`:

**IMPORTANT: Do NOT cherry-pick - copy files from development instead**

```bash
# 1. Fetch latest changes
git fetch origin

# 2. Create sandbox branch from ayr/sandbox
git checkout origin/ayr/sandbox
git checkout -b sandbox/TICKET-NUMBER-description

# 3. Get the list of changed files from your feature branch
git diff origin/development feature/TICKET-NUMBER-description --name-only

# 4. For EACH changed file, copy from development:
git show origin/development:path/to/file.tsx > path/to/file.tsx

# Example for email settings files:
git show origin/development:src/views/settings/emailSettings/edit/common/fields.tsx > src/views/settings/emailSettings/edit/common/fields.tsx
git show origin/development:src/views/settings/emailSettings/edit/common/components/ModuleForm.tsx > src/views/settings/emailSettings/edit/common/components/ModuleForm.tsx
# ... repeat for all files

# 5. Stage, commit, and push
git add .
git commit -m "Same commit message as feature branch"
git push -u origin sandbox/TICKET-NUMBER-description
```

**Why copy files instead of cherry-pick?**
- Avoids complex merge conflicts between diverged branches
- Ensures implementation matches the tested development version
- Prevents subtle syntax errors from manual conflict resolution
- Faster and more reliable for branches with significant differences

**Alternative (if files are identical between branches):**
If development and ayr/sandbox have minimal differences in the affected files, you can try cherry-picking:
```bash
git cherry-pick <commit-hash>
# If conflicts occur, switch to the copy method above
```

### Adding New Features
1. Create components in appropriate `/components` subdirectory
2. Add GraphQL operations in `/graphql`
3. Define TypeScript types in `/models`
4. Implement business logic in `/services`
5. Add routing configuration to `router.tsx`
6. Write tests for critical functionality

### Working with GraphQL
- Operations are organized by domain in `/graphql`
- Use Apollo Client hooks for data fetching
- Implement proper error handling and loading states
- Leverage Apollo cache for optimal performance

### Managing State
- Use Zustand stores for application state
- React Context for theme and auth state
- Apollo Client cache for server state
- Local component state for UI-only state

## Performance Considerations

- **Code Splitting**: Lazy loading implemented for routes
- **Bundle Analysis**: Use `yarn analyze` to inspect bundle size
- **Asset Optimization**: Images and fonts properly hashed
- **Caching Strategy**: Service worker with versioned cache management
- **Tree Shaking**: Vite optimizes unused code elimination

## AI-Assisted Development

### Claude Code Attribution

When AI assistance (Claude Code) is used for development work, follow these guidelines:

#### Commit Messages
- **DO NOT** include Claude Code attribution directly in commit messages
- Keep commit messages focused on the technical changes and their impact
- Follow conventional commit format (feat:, fix:, chore:, etc.)

#### Documentation
- Document AI-assisted work in this CLAUDE.md file or relevant documentation
- Include context about what was automated or assisted
- Note any significant refactoring or architectural decisions made with AI assistance

#### Pull Requests
- Mention Claude Code usage in PR descriptions when relevant
- Highlight any areas that may benefit from additional human review
- Use format: "Note: Parts of this PR were developed with Claude Code assistance"

#### Example Usage Documentation
```markdown
## Recent AI-Assisted Changes

### [Date] - Feature/Fix Description
- **Files Modified**: List of files
- **AI Tool**: Claude Code
- **Assistance Type**: Bug fix / Feature development / Refactoring
- **Human Review**: Required areas or decisions made
```

### Benefits of AI-Assisted Development
- Faster identification of runtime errors and edge cases
- Improved code consistency across large codebases
- Better documentation of complex technical decisions
- Enhanced testing coverage suggestions