#!/bin/bash

# Docker management script for FE-ABMS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_color() {
    printf "${1}${2}${NC}\n"
}

# Print usage information
usage() {
    echo "Usage: $0 {dev|prod|build|stop|clean|logs}"
    echo ""
    echo "Commands:"
    echo "  dev    - Start development environment"
    echo "  prod   - Start production environment"
    echo "  build  - Build Docker image"
    echo "  stop   - Stop all containers"
    echo "  clean  - Remove containers and images"
    echo "  logs   - Show container logs"
    echo ""
    exit 1
}

# Check if Docker is running
check_docker() {
    if ! docker info > /dev/null 2>&1; then
        print_color $RED "Error: Docker is not running. Please start Docker and try again."
        exit 1
    fi
}

# Check if .env file exists
check_env() {
    if [ ! -f .env ]; then
        print_color $YELLOW "Warning: .env file not found. Copying from env.example..."
        cp env.example .env
        print_color $YELLOW "Please edit .env file with your configuration before continuing."
        read -p "Press Enter to continue or Ctrl+C to exit..."
    fi
}

# Start development environment
start_dev() {
    print_color $BLUE "Starting development environment..."
    check_env
    docker-compose --profile dev up --build -d
    print_color $GREEN "Development environment started!"
    print_color $GREEN "Application available at: http://localhost:5173"
    print_color $BLUE "To view logs: $0 logs"
}

# Start production environment
start_prod() {
    print_color $BLUE "Starting production environment..."
    check_env
    docker-compose --profile prod up --build -d
    print_color $GREEN "Production environment started!"
    print_color $GREEN "Application available at: http://localhost:80"
    print_color $BLUE "To view logs: $0 logs"
}

# Build Docker image
build_image() {
    print_color $BLUE "Building Docker image..."
    docker build -t fe-abms:latest .
    print_color $GREEN "Docker image built successfully!"
}

# Stop all containers
stop_containers() {
    print_color $BLUE "Stopping all containers..."
    docker-compose --profile dev --profile prod down
    print_color $GREEN "All containers stopped!"
}

# Clean up containers and images
clean_all() {
    print_color $BLUE "Cleaning up containers and images..."
    docker-compose --profile dev --profile prod down --rmi all --volumes --remove-orphans
    print_color $GREEN "Cleanup completed!"
}

# Show container logs
show_logs() {
    print_color $BLUE "Showing container logs (press Ctrl+C to exit)..."
    docker-compose --profile dev --profile prod logs -f
}

# Main script logic
check_docker

case "${1:-}" in
    dev)
        start_dev
        ;;
    prod)
        start_prod
        ;;
    build)
        build_image
        ;;
    stop)
        stop_containers
        ;;
    clean)
        clean_all
        ;;
    logs)
        show_logs
        ;;
    *)
        usage
        ;;
esac
