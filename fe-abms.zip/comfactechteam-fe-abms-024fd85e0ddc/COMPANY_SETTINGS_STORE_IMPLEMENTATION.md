# Company Settings Store Implementation

## Overview

I've created a dedicated Zustand store for managing company settings, following the same patterns and behavior as the existing global options store but focused specifically on company settings data.

## Files Created

### 1. Core Store (`src/stores/companySettingsStore.ts`)
- **Purpose**: Main Zustand store for company settings state management
- **Features**:
  - Auto-loading with cache-first policy
  - Manual refresh with network-only policy
  - Loading and error state management
  - Type-safe with full TypeScript support

### 2. React Hook (`src/hooks/useCompanySettings.ts`)
- **Purpose**: React hook for easy component integration
- **Features**:
  - `useCompanySettings()` - Auto-fetch version (default)
  - `useCompanySettingsData()` - Read-only version (no auto-fetch)
  - Convenience getters for common properties
  - Automatic fetch management with refs to prevent duplicate requests

### 3. ~~Refresh Utilities~~ (Removed - Simplified Approach)
- **Purpose**: ~~Helper functions for refreshing settings after mutations~~ 
- **Simplified**: Direct use of `refreshCompanySettings()` from the hook after successful mutations

### 4. Documentation (`src/stores/README_COMPANY_SETTINGS.md`)
- **Purpose**: Comprehensive usage guide and API documentation
- **Contents**: Usage examples, best practices, migration guide, API reference

### 5. Examples (`src/examples/`)
- **CompanySettingsExample.tsx**: Comprehensive example showing all features
- **CompanySettingsIntegration.tsx**: Real-world integration examples

## Key Features

### 1. Similar to Global Options Store
- Same API patterns and conventions
- Cache-first and network-only fetch policies
- Loading state management
- Error handling
- Zustand with devtools integration

### 2. Simple Refresh After Updates
```typescript
// Direct refresh after company settings updates
const { refreshCompanySettings } = useCompanySettings();

const updateSettings = async (data) => {
  await updateMutation(data);
  await refreshCompanySettings(); // Store refreshes with latest data
};
```

### 3. Multiple Usage Patterns
```typescript
// Auto-fetch (default)
const { companySettings, isLoading } = useCompanySettings();

// Read-only (no auto-fetch)
const { companyName } = useCompanySettingsData();

// Direct store access
const companySettings = useCompanySettingsStore(state => state.companySettings);
```

### 4. Convenience Properties
```typescript
const {
  companyName,
  tradingName,
  email,
  phone,
  website,
  companyLogo,
  hasCompanySettings,
} = useCompanySettings();
```

## Integration Examples

### Basic Component Usage
```typescript
import { useCompanySettings } from '@/hooks/useCompanySettings';

const MyComponent = () => {
  const { companyName, isLoading, companySettingsError } = useCompanySettings();

  if (isLoading) return <div>Loading...</div>;
  if (companySettingsError) return <div>Error: {companySettingsError}</div>;

  return <h1>{companyName}</h1>;
};
```

### Settings Form with Refresh After Update
```typescript
import { useCompanySettings } from '@/hooks/useCompanySettings';

const SettingsForm = () => {
  const { companySettings, refreshCompanySettings } = useCompanySettings();

  const handleSubmit = async (data) => {
    try {
      await updateCompanySettingsMutation(data);
      // Refresh the store after successful update
      await refreshCompanySettings();
    } catch (error) {
      console.error('Update failed:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* Form fields */}
    </form>
  );
};
```

### Header Component (Read-Only)
```typescript
import { useCompanySettingsData } from '@/hooks/useCompanySettings';

const AppHeader = () => {
  const { companyName, companyLogo } = useCompanySettingsData();

  return (
    <header>
      {companyLogo && <img src={companyLogo} alt="Logo" />}
      <h1>{companyName}</h1>
    </header>
  );
};
```

## Comparison with Global Options Store

| Feature | Global Options Store | Company Settings Store |
|---------|---------------------|------------------------|
| **Scope** | Multiple data types (locations, accounts, etc.) | Company settings only |
| **Usage** | `useGlobalOptions({ companySettings: true })` | `useCompanySettings()` |
| **Auto-fetch** | Based on parameters | Always (unless disabled) |
| **Refresh** | `refreshCompanySettings(client)` | `refreshCompanySettings()` |
| **Loading** | `companySettingsLoading` | `isLoading` |
| **Error** | Not implemented for company settings | `companySettingsError` |
| **Convenience** | Raw data only | Convenience getters included |

## Migration Strategy

### 1. Gradual Migration
Both stores can coexist during migration:

```typescript
// OLD (still works)
const { companySettings } = useGlobalOptions({ companySettings: true });

// NEW (preferred)
const { companySettings } = useCompanySettings();
```

### 2. Component-by-Component
Update components one at a time without breaking existing functionality.

### 3. Remove from Global Options
Once fully migrated, the company settings functionality can be removed from the global options store.

## Benefits

### 1. **Focused Responsibility**
- Dedicated store for company settings only
- Cleaner separation of concerns
- Easier to maintain and debug

### 2. **Better Performance**
- Only loads company settings when needed
- No unnecessary data fetching
- Optimized caching strategy

### 3. **Enhanced Developer Experience**
- Convenience getters for common properties
- Better TypeScript support
- Comprehensive error handling

### 4. **Auto-Refresh Integration**
- Built-in utilities for refreshing after updates
- Ensures UI stays in sync with backend
- Prevents stale data issues

### 5. **Consistent API**
- Same patterns as global options store
- Familiar developer experience
- Easy to learn and use

## Usage Recommendations

### 1. **Use Auto-Fetch by Default**
```typescript
// ✅ Preferred
const { companySettings } = useCompanySettings();

// ❌ Only if you have a specific reason
const { companySettings } = useCompanySettings({ autoFetch: false });
```

### 2. **Use Read-Only for Display Components**
```typescript
// ✅ For components that only display data
const { companyName } = useCompanySettingsData();

// ❌ For pure display components
const { companyName } = useCompanySettings();
```

### 3. **Always Refresh After Updates**
```typescript
// ✅ Ensures UI stays in sync
const updateSettings = async (data) => {
  await mutation(data);
  await refreshCompanySettings();
};
```

### 4. **Handle All States Properly**
```typescript
// ✅ Complete state handling
const { companySettings, isLoading, companySettingsError } = useCompanySettings();

if (isLoading) return <LoadingSpinner />;
if (companySettingsError) return <ErrorMessage />;
if (!companySettings) return <NoDataMessage />;

return <CompanyInfo settings={companySettings} />;
```

## Testing

The store can be tested using standard React Testing Library patterns:

```typescript
import { renderHook } from '@testing-library/react';
import { useCompanySettings } from '@/hooks/useCompanySettings';

test('should load company settings', async () => {
  const { result, waitForNextUpdate } = renderHook(() => useCompanySettings());
  
  expect(result.current.isLoading).toBe(true);
  await waitForNextUpdate();
  expect(result.current.companySettings).toBeDefined();
});
```

## Conclusion

This implementation provides a robust, type-safe, and developer-friendly solution for managing company settings state in the application. It follows the same patterns as the existing global options store while providing enhanced functionality specifically for company settings management.

The auto-refresh capability ensures that the UI always stays in sync with the backend when company settings are updated, which was a key requirement. The multiple usage patterns (auto-fetch, read-only, direct store access) provide flexibility for different component needs while maintaining a consistent API.
