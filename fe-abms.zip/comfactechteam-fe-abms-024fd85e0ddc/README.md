# AYR FE-ABMS

> **Frontend Application for Account and Business Management System**

A comprehensive React TypeScript application built with Vite, featuring advanced form management, routing, and business process automation.

## 🚀 Quick Start

### Prerequisites

- **Node.js** >= 18.0.0
- **Yarn** >= 1.22.0
- **Git**

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd fe-abms
   ```

2. **Install dependencies**
   ```bash
   yarn install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   # Edit .env with your configuration
   ```

4. **Start development server**
   ```bash
   yarn dev
   ```

5. **Open in browser**
   ```
   http://localhost:5173
   ```

## � Docker Setup

For containerized deployment, see [DOCKER.md](./DOCKER.md) for detailed instructions.

### Quick Docker Start

**Development:**
```bash
./docker.sh dev
# Access at http://localhost:5173
```

**Production:**
```bash
./docker.sh prod
# Access at http://localhost:80
```

## �📋 Available Scripts

| Command | Description |
|---------|-------------|
| `yarn dev` | Start development server |
| `yarn build` | Build for production |
| `yarn preview` | Preview production build |
| `yarn lint` | Run ESLint |
| `yarn type-check` | Run TypeScript type checking |
| `yarn test` | Run tests |

## 🏗️ Project Structure

```
fe-abms/
├── src/
│   ├── components/               # Reusable UI components
│   ├── views/                   # Page components
│   │   ├── accounts/           # Account management
│   │   ├── sales/              # Sales management
│   │   ├── calendar/           # Calendar & tasks
│   │   ├── settings/           # Application settings
│   │   └── ...
│   ├── hooks/                  # Custom React hooks
│   ├── utils/                  # Utility functions
│   ├── services/               # API services
│   ├── models/                 # TypeScript models
│   ├── constants/              # Application constants
│   ├── routes/                 # Route definitions
│   ├── stores/                 # State management
│   ├── styled-components/      # This is the old MFE styled components
│   ├── mfe-utilities/          # This is the old MFE utils
│   ├── unathorized-components/ # Unauthorized/public components - Old MFE unauthorized
│   └── graphql/               # GraphQL queries & mutations
├── public/                     # Static assets
└── dist/                      # Production build output
```

## 🛠️ Tech Stack

### Core Technologies
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool & dev server
- **Apollo Client** - GraphQL client
- **Ant Design** - UI component library
- **Material-UI** - Additional UI components
- **Styled Components** - CSS-in-JS styling

### Development Tools
- **ESLint** - Code linting
- **Prettier** - Code formatting
- **Husky** - Git hooks
- **Jest** - Testing framework

## 🔧 Configuration

### Environment Variables

Create a `.env` file based on `env.example`:

```bash
# ================================
# APPLICATION CONFIGURATION
# ================================
NODE_ENV=local
PORT=3000
APP_NAME=fe-abms

# ================================
# API SERVICE ENDPOINTS
# ================================
# Apollo GraphQL Gateway
REACT_APP_APOLLO_URI=http://localhost:8080/api/gw
REACT_APP_APOLLO_WS=ws://localhost:8080/api/ws

# Authentication Service
REACT_APP_AUTH_URI=http://localhost:8092/api/auth

# Legacy API URL
REACT_APP_API_URL=http://localhost:8080
REACT_APP_API_TIMEOUT=5000

# ================================
# TENANT CONFIGURATION
# ================================
REACT_APP_TENANT_PREFIX=abms

# ================================
# EXTERNAL SERVICES
# ================================
# Google Maps API Key
REACT_APP_GOOGLE_API_KEY=your-google-maps-api-key

# ================================
# LOGGING CONFIGURATION
# ================================
REACT_APP_LOG_LEVEL=debug

# ================================
# DEVELOPMENT CONFIGURATION
# ================================
GENERATE_SOURCEMAP=true
FAST_REFRESH=true

# ================================
# VITE CONFIGURATION
# ================================
VITE_APP_TITLE=AYR Business Management System
VITE_API_URL=http://localhost:8080
VITE_AUTH_URL=http://localhost:8092
VITE_TENANT_PREFIX=abms
```

### TypeScript Configuration

The project uses strict TypeScript configuration:
- Strict mode enabled
- Path aliases configured (`@/` points to `src/`)
- Module resolution optimized for modern bundlers

### Build Configuration

Vite configuration includes:
- Hot Module Replacement (HMR)
- Path alias resolution
- Bundle optimization
- Environment variable injection

## 🧭 Routing & Navigation

The application uses a centralized routing system with type-safe helper functions.

### Quick Reference

```typescript
import { getViewRoute, getListRoute, getNewRoute, getEditRoute } from '@/mfe-utilities';

// Navigate to pages
const accountViewUrl = getViewRoute('Account');
const tasksListUrl = getListRoute('Tasks');
const newLeadUrl = getNewRoute('Leads');
```

📖 **See [Routing Guide](./docs/ROUTING_GUIDE.md) for complete documentation**

## 🎨 UI Components & Styling

### Design System

The application uses a custom design system built on:
- **Styled Components** for component styling
- **Ant Design** for base UI components
- **Material-UI** for advanced components
- **Custom theme** with consistent colors, typography, and spacing

### Component Library

```typescript
import { Button, Form, Table, Modal } from '@/styled-components';
import { Box, Stack } from '@mui/material';
```

## 📊 State Management

### Apollo Client (GraphQL)

Primary state management through Apollo Client:

```typescript
import { useQuery, useMutation } from '@apollo/client';
import { GET_ACCOUNTS, CREATE_ACCOUNT } from '@/graphql/accounts.gql';

const { data, loading, error } = useQuery(GET_ACCOUNTS);
const [createAccount] = useMutation(CREATE_ACCOUNT);
```

### Local State

React hooks and context for local component state:

```typescript
import { useState, useContext } from 'react';
import { useProfile } from '@/mfe-utilities';
```

## 🔌 API Integration

### GraphQL API

The application communicates with a GraphQL backend:

```typescript
// Query example
const GET_ACCOUNT = gql`
  query GetAccount($id: ID!) {
    account(id: $id) {
      id
      name
      email
      status
    }
  }
`;

// Mutation example
const CREATE_ACCOUNT = gql`
  mutation CreateAccount($input: AccountInput!) {
    createAccount(input: $input) {
      id
      name
    }
  }
`;
```

## 🧪 Testing

### Running Tests

```bash
# Run all tests
yarn test

# Run tests in watch mode
yarn test:watch

# Run tests with coverage
yarn test:coverage
```

### Testing Strategy

- **Unit tests** for utilities and hooks
- **Component tests** for UI components
- **Integration tests** for complete user flows
- **E2E tests** for critical business processes

## 📦 Build & Deployment

### Production Build

```bash
# Create production build
yarn build

# Preview production build locally
yarn preview
```

### Build Output

The build process creates:
- Optimized JavaScript bundles
- CSS files with vendor prefixes
- Static assets with cache headers
- Source maps for debugging

### Deployment Options

- **Static hosting** (Netlify, Vercel, AWS S3)
- **CDN deployment** for global distribution
- **Docker containers** for containerized deployment

## 🔍 Development Guidelines

### Code Style

- Use **TypeScript** for all new files
- Follow **ESLint** and **Prettier** configurations
- Use **functional components** with hooks
- Implement **proper error handling**
- Write **meaningful commit messages**

### File Naming

- Components: `PascalCase.tsx`
- Hooks: `useCamelCase.ts`
- Utils: `camelCase.ts`
- Constants: `UPPER_SNAKE_CASE.ts`

### Import Organization

```typescript
// 1. React imports
import React, { useState, useEffect } from 'react';

// 2. Third-party libraries
import { useQuery } from '@apollo/client';
import { Button } from 'antd';

// 3. Internal imports (absolute paths)
import { getViewRoute } from '@/mfe-utilities';
import { AccountForm } from '@/components';

// 4. Relative imports
import './styles.css';
```

## 📚 Documentation

Comprehensive documentation is available in the `docs/` folder:

- **[Routing Guide](./docs/ROUTING_GUIDE.md)** - Navigation and routing patterns
- **[TypeScript Fixes](./docs/TYPESCRIPT_FIXES_TODO.md)** - Type safety improvements
- **[Environment Setup](./docs/ENVIRONMENT_ALIGNMENT.md)** - Development environment

## 🐛 Troubleshooting

### Common Issues

#### TypeScript Errors
```bash
# Clear TypeScript cache
rm -rf node_modules/.cache
yarn type-check
```

#### Build Issues
```bash
# Clear build cache
rm -rf dist/ node_modules/.vite/
yarn install
yarn build
```

#### Development Server Issues
```bash
# Reset development server
rm -rf node_modules/.vite/
yarn dev
```

### Getting Help

1. Check the [documentation](./docs/) first
2. Search existing issues in the repository
3. Ask in the team chat or create a new issue
4. Contact the development team

## 🤝 Contributing

### Development Workflow

1. **Create feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make changes and test**
   ```bash
   yarn type-check
   yarn lint
   yarn test
   ```

3. **Commit changes**
   ```bash
   git add .
   git commit -m "feat: add new feature"
   ```

4. **Push and create PR**
   ```bash
   git push origin feature/your-feature-name
   ```

### Code Review Process

- All changes require peer review
- Automated tests must pass
- TypeScript compilation must succeed
- Follow established code patterns

## 📝 Recent Updates

### ✅ Completed Improvements

- **Route System Refactor** - Migrated to type-safe helper functions
- **TypeScript Optimization** - Fixed 1,000+ type errors
- **Path Alias Alignment** - Consistent import paths
- **Documentation** - Comprehensive developer guides

### 🔄 In Progress

- Form validation improvements
- Component library expansion
- Performance optimizations
- Test coverage expansion

## 📞 Support

### Development Team

- **Frontend Lead**: [Team Lead Name]
- **DevOps**: [DevOps Contact]
- **QA**: [QA Contact]

### Resources

- **Repository**: [Repository URL]
- **CI/CD**: [Pipeline URL]
- **Documentation**: [Wiki URL]
- **Issue Tracking**: [Issues URL]

---

## 🚀 Ready to Start?

1. Follow the [Quick Start](#-quick-start) guide
2. Read the [Routing Guide](./docs/ROUTING_GUIDE.md)
3. Explore the codebase structure
4. Start building amazing features!

**Happy coding! 🎉**
