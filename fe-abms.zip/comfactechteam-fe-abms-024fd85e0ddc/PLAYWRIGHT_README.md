# Playwright E2E Testing Guide

This guide provides comprehensive instructions for setting up and using Playwright for end-to-end testing in the ABMS Frontend Application.

## Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Installation & Setup](#installation--setup)
- [Configuration](#configuration)
- [Authentication System](#authentication-system)
- [Writing Tests](#writing-tests)
- [Running Tests](#running-tests)
- [Best Practices](#best-practices)
- [Debugging](#debugging)
- [CI/CD Integration](#cicd-integration)
- [Troubleshooting](#troubleshooting)

## Overview

This project uses Playwright for end-to-end testing with the following key features:

- **Global Authentication Setup**: Login once, use across all tests
- **Automatic Dev Server**: Starts the application automatically before tests
- **Cross-browser Testing**: Configured for Chromium (Chrome)
- **Visual Testing**: Screenshots and videos on failure
- **Parallel Execution**: Tests run in parallel for faster execution

## Prerequisites

- Node.js 18+ and Yarn
- Chrome browser installed
- Access to the development environment
- Valid test credentials

## Installation & Setup

### 1. Install Dependencies

```bash
# Install all project dependencies (includes Playwright)
yarn install

# Install Playwright browsers
npx playwright install chromium
```

### 2. Environment Setup

Ensure your development server can run on `http://localhost:3000` (or your configured base URL):

```bash
# Test that the dev server starts correctly
yarn dev
```

#### Environment Variables

You can customize the base URL using environment variables:

```bash
# Set custom base URL for tests
export PW_BASE_URL=http://localhost:3005
yarn test:e2e

# Or set it inline
PW_BASE_URL=http://localhost:8080 yarn test:e2e
```

Create a `.env` file in your project root to set default values:

```bash
# .env file
PW_BASE_URL=http://localhost:3000
CI=false
```

### 3. Verify Installation

```bash
# Run the example test to verify setup
yarn test:e2e example.spec.ts
```

## Configuration

The Playwright configuration is defined in `playwright.config.ts`:

### Key Configuration Options

- **Test Directory**: `./e2e`
- **Base URL**: `http://localhost:3000` (configurable via `PW_BASE_URL` environment variable)
- **Browser**: Chrome (Chromium with Chrome channel)
- **Timeouts**: 60s for tests, 30s for actions
- **Retries**: 2 retries on CI, 0 locally
- **Parallel**: Enabled locally, disabled on CI

### Web Server Integration

Playwright automatically starts the development server:

```typescript
webServer: {
  command: 'yarn dev',
  url: process.env.PW_BASE_URL || 'http://localhost:3000',
  reuseExistingServer: !process.env.CI,
}
```

### Environment Variable Configuration

The configuration supports the following environment variables:

- **`PW_BASE_URL`**: Base URL for the application (default: `http://localhost:3000`)
- **`CI`**: Enables CI-specific settings (retries, workers, etc.)
- **`PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD`**: Skip browser download if pre-installed

## Authentication System

The project uses a sophisticated authentication system to avoid repeated logins:

### How It Works

1. **Global Setup** (`e2e/global-setup.ts`):
   - Runs once before all tests
   - Logs in with test credentials
   - Saves authentication state to `e2e/auth-state.json`

2. **Test Execution**:
   - All tests automatically load the saved authentication state
   - Tests start already logged in
   - No need for manual login in individual tests

### Test Credentials

```typescript
// Configured in global-setup.ts
username: 'eugene@ayr-dev'
password: 'Ctodev@123'
```

### Authentication Files

- `e2e/global-setup.ts` - Global authentication logic
- `e2e/fixtures/auth.ts` - Custom fixture for authenticated tests
- `e2e/auth-state.json` - Saved authentication state (auto-generated)

## Writing Tests

### Option 1: Using the Custom Fixture (Recommended)

```typescript
import { test, expect } from './fixtures/auth';

test.describe('HR Compliance Tests', () => {
  test('should access performance review page', async ({ authenticatedPage }) => {
    // authenticatedPage is already logged in and verified
    await authenticatedPage.goto('/hr-compliance/performance-review');
    
    // Wait for page to load
    await authenticatedPage.waitForLoadState('networkidle');
    
    // Your test assertions
    await expect(authenticatedPage.locator('h1')).toContainText('Performance Review');
  });
});
```

### Option 2: Standard Playwright Test

```typescript
import { test, expect } from '@playwright/test';

test.describe('Feature Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Authentication state is automatically loaded
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    // Verify authentication (optional)
    const bodyText = await page.locator('body').textContent();
    if (bodyText?.includes('Please enter your username and password')) {
      throw new Error('Authentication failed');
    }
  });

  test('should perform action', async ({ page }) => {
    await page.goto('/your-feature');
    // Your test logic here
  });
});
```

### Test Structure Best Practices

```typescript
import { test, expect } from './fixtures/auth';

test.describe('Feature Name', () => {
  test.beforeEach(async ({ authenticatedPage }) => {
    // Common setup for all tests in this describe block
    await authenticatedPage.goto('/feature-page');
    await authenticatedPage.waitForLoadState('networkidle');
  });

  test('should perform specific action', async ({ authenticatedPage }) => {
    // Arrange
    const button = authenticatedPage.locator('[data-testid="action-button"]');
    
    // Act
    await button.click();
    
    // Assert
    await expect(authenticatedPage.locator('.success-message')).toBeVisible();
  });

  test('should handle error case', async ({ authenticatedPage }) => {
    // Test error scenarios
  });
});
```

## Running Tests

### Basic Commands

```bash
# Run all tests
yarn test:e2e

# Run specific test file
yarn test:e2e hr-compliance-performance-review.spec.ts

# Run tests with UI mode (interactive)
yarn test:e2e:ui

# Run tests in headed mode (see browser)
yarn test:e2e:headed

# Debug specific test
yarn test:e2e:debug --grep "test name"
```

### Advanced Options

```bash
# Run tests matching a pattern
npx playwright test --grep "performance review"

# Run tests in a specific project
npx playwright test --project=chromium

# Run tests with specific timeout
npx playwright test --timeout=120000

# Run tests and generate report
npx playwright test --reporter=html
```

### Viewing Reports

```bash
# Open HTML report
npx playwright show-report

# View trace files (for failed tests)
npx playwright show-trace test-results/path-to-trace.zip
```

## Best Practices

### 1. Locator Strategies

```typescript
// Prefer data-testid attributes
const button = page.locator('[data-testid="submit-button"]');

// Use role-based selectors
const heading = page.getByRole('heading', { name: 'Performance Review' });

// Use text content for unique text
const link = page.getByText('Add New Review');

// Combine selectors for specificity
const form = page.locator('form').locator('[data-testid="review-form"]');
```

### 2. Waiting Strategies

```typescript
// Wait for network to be idle
await page.waitForLoadState('networkidle');

// Wait for specific element
await page.locator('[data-testid="content"]').waitFor();

// Wait for API response
await page.waitForResponse(response => 
  response.url().includes('/api/reviews') && response.status() === 200
);

// Wait for condition
await page.waitForFunction(() => 
  document.querySelectorAll('.review-item').length > 0
);
```

### 3. Error Handling

```typescript
test('should handle network errors', async ({ authenticatedPage }) => {
  // Simulate network failure
  await authenticatedPage.route('**/api/reviews', route => 
    route.abort('failed')
  );
  
  await authenticatedPage.goto('/reviews');
  
  // Verify error handling
  await expect(authenticatedPage.locator('.error-message')).toBeVisible();
});
```

### 4. Data Management

```typescript
// Use test data factories
const testReview = {
  title: 'Test Review',
  employee: 'John Doe',
  period: '2024-Q1'
};

// Clean up after tests
test.afterEach(async ({ authenticatedPage }) => {
  // Clean up test data if needed
  await authenticatedPage.evaluate(() => {
    localStorage.clear();
    sessionStorage.clear();
  });
});
```

## Debugging

### 1. Debug Mode

```bash
# Run in debug mode with browser visible
yarn test:e2e:debug

# Debug specific test
npx playwright test --debug --grep "test name"
```

### 2. Screenshots and Videos

```typescript
// Take manual screenshot
await page.screenshot({ path: 'debug-screenshot.png' });

// Full page screenshot
await page.screenshot({ path: 'full-page.png', fullPage: true });
```

### 3. Console Logs

```typescript
// Listen to console messages
page.on('console', msg => console.log('PAGE LOG:', msg.text()));

// Listen to page errors
page.on('pageerror', error => console.log('PAGE ERROR:', error.message));
```

### 4. Trace Viewer

```typescript
// Enable tracing in test
test('debug test', async ({ page, context }) => {
  await context.tracing.start({ screenshots: true, snapshots: true });
  
  // Your test code
  
  await context.tracing.stop({ path: 'trace.zip' });
});
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  e2e:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'yarn'
      
      - name: Install dependencies
        run: yarn install --frozen-lockfile
      
      - name: Install Playwright browsers
        run: npx playwright install --with-deps chromium
      
      - name: Run E2E tests
        run: yarn test:e2e
        env:
          CI: true
      
      - name: Upload test results
        uses: actions/upload-artifact@v3
        if: failure()
        with:
          name: playwright-report
          path: playwright-report/
```

### Environment Variables

```bash
# Base URL configuration
PW_BASE_URL=http://localhost:3000  # Custom base URL for tests

# CI environment
CI=true                    # Enables CI-specific settings
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1  # Skip browser download if pre-installed

# Development environments
PW_BASE_URL=https://staging.example.com  # For staging tests
PW_BASE_URL=https://dev.example.com      # For dev environment tests
```

## Troubleshooting

### Common Issues

#### 1. Authentication Fails

```bash
# Delete saved auth state and retry
rm e2e/auth-state.json
yarn test:e2e
```

#### 2. Tests Timeout

```typescript
// Increase timeout for slow operations
test('slow test', async ({ authenticatedPage }) => {
  test.setTimeout(120000); // 2 minutes
  // Your test code
});
```

#### 3. Element Not Found

```typescript
// Add explicit waits
await page.locator('[data-testid="element"]').waitFor({ 
  state: 'visible',
  timeout: 10000 
});
```

#### 4. Flaky Tests

```typescript
// Add retry logic
test('flaky test', async ({ authenticatedPage }) => {
  test.retries(2);
  // Your test code
});
```

### Debug Commands

```bash
# Check Playwright installation
npx playwright --version

# List installed browsers
npx playwright install --dry-run

# Generate test code
npx playwright codegen http://localhost:3000

# Generate test code for custom URL
npx playwright codegen $PW_BASE_URL

# Run specific browser
npx playwright test --project=chromium
```

### Performance Tips

1. **Use `waitForLoadState('networkidle')`** for dynamic content
2. **Avoid `page.waitForTimeout()`** unless absolutely necessary
3. **Use specific locators** instead of generic ones
4. **Run tests in parallel** for faster execution
5. **Clean up test data** to avoid interference

## File Structure

```
e2e/
├── fixtures/
│   └── auth.ts              # Authentication fixture
├── global-setup.ts          # Global authentication setup
├── auth-state.json          # Saved auth state (auto-generated)
├── example.spec.ts          # Example test file
├── hr-compliance-performance-review.spec.ts  # Feature tests
└── README.md               # E2E specific documentation

playwright.config.ts        # Main Playwright configuration
playwright-report/          # Test reports (auto-generated)
test-results/              # Test artifacts (auto-generated)
```

## Additional Resources

- [Playwright Documentation](https://playwright.dev/docs/intro)
- [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- [Playwright API Reference](https://playwright.dev/docs/api/class-playwright)
- [Project E2E README](./e2e/README.md)

---

**Need Help?** Check the troubleshooting section above or refer to the existing test files for examples.