# Reschedule Jobs Functionality Diagram

## System Architecture Overview

```mermaid
graph TB
    subgraph "Frontend Components"
        JL[Jobs List View]
        JV[Jobs Detail View]
        RM[Reschedule Modal]
        SP[Service Provider Days Modal]
        JF[Job Specifications Table]
    end

    subgraph "GraphQL Layer"
        GQL[GraphQL Client]
        RMUT[RESCHEDULE_JOB Mutation]
        UJMUT[UPDATE_JOB Mutation]
    end

    subgraph "Backend API"
        API[Backend API]
        RS[Reschedule Service]
        JS[Job Service]
    end

    subgraph "Database"
        DB[(Database)]
        JT[Jobs Table]
        JST[Job Schedules Table]
        SPT[Service Providers Table]
    end

    JL -->|"Click Reschedule"| RM
    JV -->|"Click Reschedule"| RM
    RM -->|"Open"| SP
    RM -->|"Expand"| JF
    
    RM -->|"Submit Form"| GQL
    GQL -->|"rescheduleJob"| RMUT
    GQL -->|"updateJob"| UJMUT
    
    RMUT --> API
    UJMUT --> API
    
    API --> RS
    API --> JS
    
    RS --> DB
    JS --> DB
    
    DB --> JT
    DB --> JST
    DB --> SPT
```

## Detailed Flow Diagram

```mermaid
sequenceDiagram
    participant User
    participant JL as Jobs List View
    participant JV as Jobs Detail View
    participant RM as Reschedule Modal
    participant SP as Service Provider Days Modal
    participant GQL as GraphQL Client
    participant API as Backend API
    participant DB as Database

    Note over User,DB: Jobs List View Flow
    User->>JL: Click "Reschedule job" action
    JL->>JL: Check job eligibility (ALLOCATED + RECURRING)
    JL->>RM: Open modal with job data
    RM->>RM: Initialize form with default values
    RM->>User: Display reschedule form
    
    User->>RM: Fill reschedule details
    Note over RM: Date, Frequency, Days, Time, Notes
    User->>RM: Configure job specifications
    RM->>SP: Open service provider days modal
    User->>SP: Assign days to service providers
    SP->>RM: Save day assignments
    User->>RM: Submit form
    
    RM->>GQL: Call updateJobs mutation
    GQL->>API: Update job with new startDate
    API->>DB: Update job record
    DB->>API: Return updated job
    API->>GQL: Return success response
    GQL->>RM: Show success message
    RM->>JL: Close modal & refetch data

    Note over User,DB: Jobs Detail View Flow
    User->>JV: Click "Reschedule job" action
    JV->>RM: Open modal with job data
    RM->>User: Display reschedule form
    
    User->>RM: Fill reschedule details
    User->>RM: Submit form
    
    RM->>GQL: Call rescheduleJob mutation
    GQL->>API: Process reschedule with full data
    Note over API: jobId, frequency, days, time, rescheduleDate, notes
    API->>DB: Update job and schedules
    DB->>API: Return updated job
    API->>GQL: Return success response
    GQL->>RM: Show success message
    RM->>JV: Close modal & refetch data
```

## Component Structure Diagram

```mermaid
graph TD
    subgraph "Modal Content Handler"
        MCH[ModalContentHandler]
        MCH -->|"action = RESCHEDULE_JOB"| RJ[RescheduleJob Component]
    end

    subgraph "RescheduleJob Component"
        RJ --> RF1[Reschedule Fields 1<br/>Date Picker]
        RJ --> RF2[Reschedule Fields 2<br/>Frequency Select]
        RJ --> RF3[Reschedule Fields 3<br/>Days Multi-Select]
        RJ --> RF4[Reschedule Fields 4<br/>Time Picker]
        RJ --> RF5[Reschedule Fields 5<br/>Notes Textarea]
        RJ --> JST[Job Specifications Table]
    end

    subgraph "Job Specifications Table"
        JST --> SP[Service Provider Column]
        JST --> AR[Area Column]
        JST --> FR[Frequency Column]
        JST --> NT[Notes Column]
        JST --> ER[Expandable Row Renderer]
    end

    subgraph "Expandable Components"
        ER --> RJEC[RescheduleJobExpandableComponent]
        RJEC --> SPDM[ServiceProviderDaysModal]
    end

    subgraph "Form Fields"
        RF1 -->|"rescheduleDate"| FORM[Form State]
        RF2 -->|"frequency"| FORM
        RF3 -->|"days"| FORM
        RF4 -->|"time"| FORM
        RF5 -->|"notes"| FORM
        JST -->|"jobSpecifications"| FORM
    end
```

## Data Flow Diagram

```mermaid
graph LR
    subgraph "Input Data"
        JD[Job Data]
        SP[Service Providers]
        FR[Frequencies]
        AR[Areas]
    end

    subgraph "Form Processing"
        VAL[Validation]
        FOR[Formatting]
        MAP[Data Mapping]
    end

    subgraph "Mutation Data"
        RD[Reschedule Data]
        UD[Update Data]
    end

    subgraph "Response Handling"
        SU[Success Handler]
        ER[Error Handler]
        RF[Refetch Data]
    end

    JD --> VAL
    SP --> VAL
    FR --> VAL
    AR --> VAL

    VAL --> FOR
    FOR --> MAP

    MAP --> RD
    MAP --> UD

    RD --> SU
    UD --> SU

    SU --> RF
    ER --> RF
```

## State Management Flow

```mermaid
stateDiagram-v2
    [*] --> JobList
    [*] --> JobDetail
    
    JobList --> ModalOpen: Click Reschedule
    JobDetail --> ModalOpen: Click Reschedule
    
    ModalOpen --> FormFilling: Initialize Form
    
    FormFilling --> ServiceProviderModal: Configure Days
    ServiceProviderModal --> FormFilling: Save Days
    
    FormFilling --> Validation: Submit Form
    Validation --> Processing: Valid
    Validation --> FormFilling: Invalid
    
    Processing --> Success: API Success
    Processing --> Error: API Error
    
    Success --> DataRefetch: Close Modal
    Error --> FormFilling: Show Error
    
    DataRefetch --> JobList: Update List
    DataRefetch --> JobDetail: Update Detail
    
    JobList --> [*]
    JobDetail --> [*]
```

## File Structure Overview

```
src/
├── views/jobs/jobs/
│   ├── list/index.tsx                    # Jobs List View
│   ├── view/index.tsx                    # Jobs Detail View
│   └── common/
│       ├── constants.ts                  # Modal Actions
│       └── components/modal-contents/
│           ├── ModalContentHandler.tsx   # Modal Router
│           ├── RescheduleJob.tsx         # Main Reschedule Component
│           ├── fields/rescheduleJobFields.tsx  # Basic Fields
│           └── form/ServiceProviderDaysModal.tsx  # Days Modal
├── graphql/jobs.gql.ts                   # GraphQL Mutations
└── models/
    ├── JobsModel.ts                      # Job Data Model
    └── JobScheduleLogModel.ts            # Schedule Log Model
```

## Key Features Summary

| Feature | Description | Implementation |
|---------|-------------|----------------|
| **Access Control** | Only ALLOCATED + RECURRING jobs | Conditional rendering in list/detail views |
| **Date Validation** | No past dates allowed | `disabledDate` prop in date picker |
| **Frequency Support** | Daily, Weekly, Monthly, etc. | Dropdown with predefined options |
| **Days Assignment** | Multi-select for weekly jobs | Required validation for weekly frequency |
| **Time Configuration** | HH:mm format with defaults | Time picker with 17:30 default |
| **Service Provider Days** | Detailed day assignment per provider | Expandable modal with day selection |
| **Job Specifications** | Table with expandable rows | Dynamic form with service provider assignments |
| **Form Validation** | Required fields and business rules | Ant Design form validation |
| **Success Handling** | Modal close + data refetch | GraphQL mutation success callbacks |
| **Error Handling** | User-friendly error messages | Try-catch with snackbar notifications |

## Mutation Comparison

| View | Mutation | Purpose | Data Structure |
|------|----------|---------|----------------|
| **List View** | `updateJobs` | Update job start date | Basic job update fields |
| **Detail View** | `rescheduleJob` | Full reschedule with schedules | Complete reschedule data structure |

The reschedule functionality provides a comprehensive solution for managing recurring job schedules with detailed service provider assignments and flexible scheduling options. 