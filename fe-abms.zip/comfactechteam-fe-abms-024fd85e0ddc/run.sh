#!/bin/bash

# Script to run yarn commands with global yarn
# Usage: ./run.sh [yarn command]
# Example: ./run.sh dev
# Example: ./run.sh build
# Example: ./run.sh install

echo "Using global yarn..."
yarn "$@" 