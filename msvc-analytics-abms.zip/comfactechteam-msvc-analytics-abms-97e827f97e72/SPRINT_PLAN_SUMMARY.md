# Sprint Plan Summary - Adjusted for Team Availability

## Team Allocation & Availability

| Developer | Widgets Assigned | Days Available | Total Hours |
|-----------|------------------|----------------|-------------|
| **Eugene** | 5 KPI widgets | 6/6 days ✅ | 48-60 hours |
| **Aldous** | 3 KPI + 2 Chart widgets | 6/6 days ✅ | 48-60 hours |
| **Guill** | 4 Chart widgets | 3/6 days ⚠️ | 24-30 hours |
| **FE** | 14 UI components | 6/6 days ✅ | 48-60 hours |

**⚠️ Risk:** Guill has 50% reduced availability (3 days instead of 6). Plan adjusted accordingly.

---

## Widget Distribution

### Eugene (5 KPI Widgets - 6 days)
**Estimated:** ~10 hours per widget

| Widget | Ticket | Days | Status |
|--------|--------|------|--------|
| `invoices_credits_kpi` | ABMS-4014 | Day 1-2 | ⏳ |
| `invoices_count_kpi` | ABMS-4019 | Day 2-3 | ⏳ |
| `converted_jobs_kpi` | ABMS-4021 | Day 3-4 | ⏳ |
| `budgeted_jobs_kpi` | ABMS-4022 | Day 4-5 | ⏳ |
| `quality_audits_kpi` | ABMS-4023 | Day 5-6 | ⏳ |

---

### Aldous (3 KPI + 2 Chart Widgets - 6 days)
**Estimated:** ~10 hours per widget

| Widget | Ticket | Days | Status |
|--------|--------|------|--------|
| `franchise_invoices_kpi` | ABMS-4024 | Day 1-2 | ⏳ |
| `extra_work_invoices_kpi` | ABMS-4025 | Day 2-3 | ⏳ |
| `consumable_invoices_kpi` | ABMS-4026 | Day 3-4 | ⏳ |
| `sales_targets_chart` | ABMS-4027 | Day 4-5 | ⏳ |
| `service_type_invoices_chart` | ABMS-4028 | Day 5-6 | ⏳ |

---

### Guill (4 Chart Widgets - 3 days) ⚠️
**Estimated:** ~6-8 hours per widget (compressed schedule)

| Widget | Ticket | Days | Available | Status |
|--------|--------|------|-----------|--------|
| `leads_chart` | ABMS-4029 | Day 1 | ✅ | ⏳ |
| `consumable_purchases_chart` | ABMS-4030 | Day 2 | ✅ | ⏳ |
| `cases_chart` | ABMS-4031 | Day 3 | ✅ | ⏳ |
| `quality_audits_chart` | ABMS-4032 | Day 6 | ⚠️ **Backup** | ⏳ |

**⚠️ Contingency Plan for ABMS-4032:**
- If Guill cannot complete on Day 6, Eugene or Aldous will take over
- Quality audits chart shares data source with quality_audits_kpi (Eugene's work)
- Can be implemented in 4-6 hours by Eugene as fallback

---

## 6-Day Schedule

### Day 1 (Saturday Week 1)
**Available: Eugene, Aldous, Guill ✅, FE**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Start `invoices_credits_kpi` | Continue + testing |
| Aldous | Start `franchise_invoices_kpi` | Continue + testing |
| Guill | Start `leads_chart` | Complete `leads_chart` ✅ |
| FE | Dashboard layout | KPI card component |

**End of Day Targets:**
- Eugene: 50% invoices_credits_kpi
- Aldous: 50% franchise_invoices_kpi
- Guill: 100% leads_chart ✅
- FE: Layout + KPI component

---

### Day 2 (Sunday Week 1)
**Available: Eugene, Aldous, Guill ✅, FE**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Finish `invoices_credits_kpi` ✅ | Start `invoices_count_kpi` |
| Aldous | Finish `franchise_invoices_kpi` ✅ | Start `extra_work_invoices_kpi` |
| Guill | Start `consumable_purchases_chart` | Complete `consumable_purchases_chart` ✅ |
| FE | Integrate 2 KPIs | Chart component |

**End of Day Targets:**
- Eugene: invoices_credits_kpi ✅ + 50% invoices_count_kpi
- Aldous: franchise_invoices_kpi ✅ + 50% extra_work_invoices_kpi
- Guill: leads_chart ✅ + consumable_purchases_chart ✅
- FE: 2 KPIs working + chart component

---

### Day 3 (Saturday Week 2)
**Available: Eugene, Aldous, Guill ✅, FE**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Finish `invoices_count_kpi` ✅ | Start `converted_jobs_kpi` |
| Aldous | Finish `extra_work_invoices_kpi` ✅ | Start `consumable_invoices_kpi` |
| Guill | Start `cases_chart` | Complete `cases_chart` ✅ |
| FE | Integrate 3 more KPIs | Integrate 2 charts |

**End of Day Targets:**
- Eugene: 2 KPIs ✅ + 50% converted_jobs_kpi
- Aldous: 2 KPIs ✅ + 50% consumable_invoices_kpi
- Guill: 3 charts ✅ (leads, consumables, cases)
- FE: 5 KPIs + 2 charts working

---

### Day 4 (Sunday Week 2)
**Available: Eugene, Aldous, FE** ⚠️ **Guill NOT available**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Finish `converted_jobs_kpi` ✅ | Start `budgeted_jobs_kpi` |
| Aldous | Finish `consumable_invoices_kpi` ✅ | Start `sales_targets_chart` |
| Guill | ❌ Not available | ❌ Not available |
| FE | Integrate remaining KPIs | Polish + testing |

**End of Day Targets:**
- Eugene: 3 KPIs ✅ + 50% budgeted_jobs_kpi
- Aldous: 3 KPIs ✅ + 50% sales_targets_chart
- Guill: Still at 3 charts ✅
- FE: All KPIs integrated

---

### Day 5 (Saturday Week 3)
**Available: Eugene, Aldous, FE** ⚠️ **Guill NOT available**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Finish `budgeted_jobs_kpi` ✅ | Start `quality_audits_kpi` |
| Aldous | Finish `sales_targets_chart` ✅ | Start `service_type_invoices_chart` |
| Guill | ❌ Not available | ❌ Not available |
| FE | Integrate all charts | E2E testing |

**End of Day Targets:**
- Eugene: 4 KPIs ✅ + 50% quality_audits_kpi
- Aldous: 3 KPIs ✅ + 1 chart ✅ + 50% service_type_invoices_chart
- Guill: Still at 3 charts ✅
- FE: All widgets integrated

---

### Day 6 (Sunday Week 3) - Final Push
**Available: Eugene, Aldous, FE** ⚠️ **Guill NOT available**

| Developer | Morning (4h) | Afternoon (4h) |
|-----------|--------------|----------------|
| Eugene | Finish `quality_audits_kpi` ✅ | **BACKUP:** Start `quality_audits_chart` if needed |
| Aldous | Finish `service_type_invoices_chart` ✅ | **BACKUP:** Help with quality_audits_chart if needed |
| Guill | ❌ Not available | ❌ Not available |
| FE | Final polish | Performance optimization |

**End of Day Targets:**
- Eugene: 5 KPIs ✅ + quality_audits_chart ✅ (if backup needed)
- Aldous: 3 KPIs ✅ + 2 charts ✅
- Guill: 3 charts ✅ (or 4 if available)
- FE: All 14 widgets live ✅

**Final Sprint Completion:**
- ✅ 8 KPI widgets
- ✅ 6 Chart widgets (3 by Guill, 3 by Aldous + Eugene backup)
- ✅ Complete dashboard UI
- ✅ All tests passing

---

## Risk Mitigation

### Risk 1: Guill's Reduced Availability
**Impact:** 4th chart widget (quality_audits_chart) may not be completed by Guill

**Mitigation:**
- ✅ Eugene implements quality_audits_kpi first (shares data source)
- ✅ Eugene has buffer time on Day 6 to implement quality_audits_chart
- ✅ Aldous can also assist if needed (finished by Day 6 morning)
- ✅ Quality audits chart is one of the simpler widgets (stacked bar)

**Likelihood of Success:** **95%** - Eugene will have 4-6 hours on Day 6 for backup

---

### Risk 2: Complex Chart Implementations
**Impact:** Chart widgets may take longer than KPIs

**Mitigation:**
- ✅ Aldous gets 2 charts (has most time available)
- ✅ Guill's charts are on his available days (Days 1-3)
- ✅ Chart component library already exists in fe-abms
- ✅ BaseWidgetService handles caching automatically

---

### Risk 3: Database Performance
**Impact:** Slow queries may block development

**Mitigation:**
- ✅ Using shared database (msvc_abms) - already optimized
- ✅ Indexes managed by msvc-abms team
- ✅ Cache-first strategy reduces database load
- ✅ TTL configured per widget type (5-15 minutes)

---

## Success Metrics

| Metric | Target | Tracking |
|--------|--------|----------|
| Widgets Completed | 14/14 | ⏳ 0/14 |
| Eugene's KPIs | 5/5 | ⏳ 0/5 |
| Aldous's Widgets | 5/5 | ⏳ 0/5 |
| Guill's Charts | 3-4/4 | ⏳ 0/4 |
| FE Components | 14/14 | ⏳ 0/14 |
| Tests Passing | 100% | ⏳ 0% |
| Cache Hit Rate | >80% | ⏳ TBD |

---

## Daily Standup Questions

1. **What did you complete yesterday?**
2. **What will you work on today?**
3. **Any blockers or risks?**
4. **On track for your sprint goals?**

---

## Emergency Contacts

- **Architecture Questions:** Review CLAUDE.md
- **Database Issues:** Check msvc-abms team
- **Deployment Issues:** Docker troubleshooting in README.md
- **Code Examples:** See TASK_ALLOCATION.md

---

## Post-Sprint Review

After Day 6, complete:
- [ ] All 14 widgets deployed
- [ ] Performance testing completed
- [ ] Cache invalidation verified
- [ ] Documentation updated
- [ ] Handover to QA team
- [ ] Sprint retrospective meeting

**Target Completion: End of Day 6 (Sunday Week 3)**

---

**Let's ship it! 🚀**
