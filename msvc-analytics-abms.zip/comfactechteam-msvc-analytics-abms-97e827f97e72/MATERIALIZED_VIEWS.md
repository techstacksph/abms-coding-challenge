# Materialized Views Strategy for Analytics Dashboard

## Overview

This service uses **PostgreSQL Materialized Views** for optimal performance of dashboard KPIs and charts. Materialized views pre-aggregate data and are refreshed on a schedule, providing sub-second query times.

## Why Materialized Views?

### Benefits
- ✅ **Fast Query Performance**: Pre-aggregated data returns in <100ms
- ✅ **Reduced Database Load**: Complex aggregations run once, not on every request
- ✅ **Consistent Results**: Same data across KPI widgets and record lists
- ✅ **Efficient Caching**: Redis caches materialized view results
- ✅ **Scalability**: Can handle 100+ concurrent users

### Trade-offs
- ⚠️ **Near Real-time**: Data refreshed every 5-15 minutes (not instant)
- ⚠️ **Storage**: Requires additional disk space for pre-aggregated data
- ⚠️ **Maintenance**: Refresh schedule must be managed

## Architecture

```
┌─────────────────┐
│   Frontend UI   │
│  - KPI Widgets  │
│  - Record Lists │
└────────┬────────┘
         │ GraphQL Query
         ▼
┌────────────────────────────────────────┐
│  Analytics Service (Node.js)           │
│  ┌──────────────────────────────────┐  │
│  │ GraphQL Resolver                 │  │
│  │  - Cache Check (Redis)           │  │
│  │  - Query Materialized View       │  │
│  └──────────────────────────────────┘  │
│                                         │
│  ┌──────────────────────────────────┐  │
│  │ BullMQ Worker                    │  │
│  │  - Process refresh jobs          │  │
│  │  - REFRESH MATERIALIZED VIEW     │  │
│  └──────────────────────────────────┘  │
└────────┬───────────────────────┬────────┘
         │ SELECT                 │ REFRESH
         │ FROM mv_*              │ MATERIALIZED VIEW
         ▼                        ▼
┌─────────────────────────────────────────┐
│  PostgreSQL Database (msvc_abms)        │
│  ┌─────────────────────┐                │
│  │ Base Tables         │                │
│  │ - invoices          │                │
│  │ - jobs              │                │
│  │ - quality_audits    │                │
│  └──────────┬──────────┘                │
│             │ Source Data                │
│             ▼                            │
│  ┌─────────────────────┐                │
│  │ Materialized Views  │                │
│  │ - mv_invoice_kpis   │                │
│  │ - mv_job_kpis       │                │
│  │ - mv_audit_kpis     │                │
│  │ - mv_sales_targets  │                │
│  │ - mv_*_records      │                │
│  └─────────────────────┘                │
└─────────────────────────────────────────┘
         ▲
         │
┌────────┴────────┐
│  Redis          │
│  - BullMQ Jobs  │  ← Scheduled refresh jobs
│  - Cache        │     (every 5-15 min)
└─────────────────┘
```

## Materialized Views Design

### 1. Invoice KPIs Materialized View

**Name:** `mv_invoice_kpis`

**Purpose:** Aggregates all invoice-based KPIs by location and date

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_invoice_kpis AS
SELECT
    location_id,
    DATE(invoice_date) as date,

    -- ABMS-4014: Total Turnover (Invoices + Credits)
    SUM(CASE WHEN invoice_type = 'invoice' THEN grand_total ELSE 0 END) as invoice_total,
    SUM(CASE WHEN invoice_type = 'credit' THEN grand_total ELSE 0 END) as credit_total,
    SUM(grand_total) as net_turnover,

    -- ABMS-4019: Turnover Count
    COUNT(CASE WHEN invoice_type = 'invoice' AND exported = true THEN 1 END) as invoice_count,

    -- ABMS-4024: Franchise Sales (Account 2001)
    SUM(CASE WHEN account_code = '2001' THEN grand_total ELSE 0 END) as franchise_sales,

    -- ABMS-4025: Extra Work Sold (Account 2003)
    SUM(CASE WHEN account_code = '2003' THEN grand_total ELSE 0 END) as extra_work_sales,

    -- ABMS-4026: Consumables Turnover (Accounts 207/208)
    SUM(CASE WHEN account_code IN ('207', '208') THEN grand_total ELSE 0 END) as consumable_sales,

    updated_at
FROM invoices
WHERE deleted_at IS NULL
GROUP BY location_id, DATE(invoice_date)
WITH DATA;

-- Indexes for fast lookups
CREATE UNIQUE INDEX idx_mv_invoice_kpis_location_date
    ON mv_invoice_kpis(location_id, date);
CREATE INDEX idx_mv_invoice_kpis_date
    ON mv_invoice_kpis(date);
```

**Refresh Strategy:** Every 10 minutes
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_kpis;
```

---

### 2. Job KPIs Materialized View

**Name:** `mv_job_kpis`

**Purpose:** Aggregates job-based KPIs by location and date

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_job_kpis AS
SELECT
    location_id,
    DATE(start_date) as date,

    -- ABMS-4021: Converted Jobs
    COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_jobs_count,
    SUM(CASE WHEN status = 'converted' THEN job_value ELSE 0 END) as converted_jobs_value,

    -- ABMS-4022: Budgeted Extra Jobs
    COUNT(CASE WHEN has_budgeted_extra_work = true THEN 1 END) as budgeted_jobs_count,
    SUM(CASE WHEN has_budgeted_extra_work = true THEN budgeted_extra_amount ELSE 0 END) as budgeted_jobs_value,

    updated_at
FROM jobs
WHERE deleted_at IS NULL
GROUP BY location_id, DATE(start_date)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_job_kpis_location_date
    ON mv_job_kpis(location_id, date);
CREATE INDEX idx_mv_job_kpis_date
    ON mv_job_kpis(date);
```

**Refresh Strategy:** Every 5 minutes
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_job_kpis;
```

---

### 3. Quality Audits KPIs Materialized View

**Name:** `mv_quality_audit_kpis`

**Purpose:** Aggregates quality audit metrics

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_quality_audit_kpis AS
SELECT
    location_id,
    DATE(completed_date) as date,

    -- ABMS-4023: Total Audits
    COUNT(*) as total_audits,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_audits,
    COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_audits,
    AVG(score) as average_score,

    -- For ABMS-4032: QA Chart (by type)
    COUNT(CASE WHEN audit_type = 'safety' THEN 1 END) as safety_audits,
    COUNT(CASE WHEN audit_type = 'quality' THEN 1 END) as quality_audits,
    COUNT(CASE WHEN audit_type = 'compliance' THEN 1 END) as compliance_audits,

    updated_at
FROM quality_audits
WHERE deleted_at IS NULL
GROUP BY location_id, DATE(completed_date)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_quality_audit_kpis_location_date
    ON mv_quality_audit_kpis(location_id, date);
CREATE INDEX idx_mv_quality_audit_kpis_date
    ON mv_quality_audit_kpis(date);
```

**Refresh Strategy:** Every 15 minutes
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_quality_audit_kpis;
```

---

### 4. Sales Targets Chart Materialized View

**Name:** `mv_sales_targets_chart`

**Purpose:** Pre-aggregates sales targets vs actual for column-line chart

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_sales_targets_chart AS
SELECT
    location_id,
    DATE_TRUNC('month', period_date) as month,

    -- Target values
    SUM(target_amount) as target_total,

    -- Actual values (from invoices)
    COALESCE(
        (SELECT SUM(grand_total)
         FROM invoices
         WHERE invoices.location_id = sales_targets.location_id
           AND DATE_TRUNC('month', invoice_date) = DATE_TRUNC('month', period_date)
           AND deleted_at IS NULL
        ), 0
    ) as actual_total,

    updated_at
FROM sales_targets
WHERE deleted_at IS NULL
GROUP BY location_id, DATE_TRUNC('month', period_date)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_sales_targets_chart_location_month
    ON mv_sales_targets_chart(location_id, month);
CREATE INDEX idx_mv_sales_targets_chart_month
    ON mv_sales_targets_chart(month);
```

**Refresh Strategy:** Every 15 minutes
```sql
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_sales_targets_chart;
```

---

### 5. Service Type Invoices Chart Materialized View

**Name:** `mv_service_type_invoices_chart`

**Purpose:** Turnover grouped by service type for column chart

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_service_type_invoices_chart AS
SELECT
    location_id,
    service_type,
    DATE_TRUNC('month', invoice_date) as month,

    -- ABMS-4028: Turnover per Service Type
    SUM(grand_total) as total_turnover,
    COUNT(*) as invoice_count,
    AVG(grand_total) as average_invoice_value,

    updated_at
FROM invoices
WHERE deleted_at IS NULL
  AND invoice_type = 'invoice'
  AND service_type IS NOT NULL
GROUP BY location_id, service_type, DATE_TRUNC('month', invoice_date)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_service_type_invoices_location_type_month
    ON mv_service_type_invoices_chart(location_id, service_type, month);
CREATE INDEX idx_mv_service_type_invoices_month
    ON mv_service_type_invoices_chart(month);
```

**Refresh Strategy:** Every 15 minutes

---

### 6. Leads Chart Materialized View

**Name:** `mv_leads_chart`

**Purpose:** New leads over time for bar chart

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_leads_chart AS
SELECT
    location_id,
    DATE(created_at) as date,

    -- ABMS-4029: New Leads
    COUNT(*) as new_leads_count,
    COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads_count,
    COUNT(CASE WHEN status = 'lost' THEN 1 END) as lost_leads_count,

    updated_at
FROM leads
WHERE deleted_at IS NULL
GROUP BY location_id, DATE(created_at)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_leads_chart_location_date
    ON mv_leads_chart(location_id, date);
CREATE INDEX idx_mv_leads_chart_date
    ON mv_leads_chart(date);
```

**Refresh Strategy:** Every 5 minutes

---

### 7. Consumable Purchases Chart Materialized View

**Name:** `mv_consumable_purchases_chart`

**Purpose:** Consumable spending vs budget for column-line chart

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_consumable_purchases_chart AS
SELECT
    location_id,
    DATE_TRUNC('month', purchase_date) as month,

    -- ABMS-4030: Actual spending
    SUM(purchase_amount) as actual_spending,

    -- Budget (from consumable_budgets table)
    COALESCE(
        (SELECT budget_amount
         FROM consumable_budgets
         WHERE consumable_budgets.location_id = consumable_purchases.location_id
           AND DATE_TRUNC('month', budget_period) = DATE_TRUNC('month', purchase_date)
         LIMIT 1
        ), 0
    ) as budget_amount,

    updated_at
FROM consumable_purchases
WHERE deleted_at IS NULL
GROUP BY location_id, DATE_TRUNC('month', purchase_date)
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_consumable_purchases_location_month
    ON mv_consumable_purchases_chart(location_id, month);
CREATE INDEX idx_mv_consumable_purchases_month
    ON mv_consumable_purchases_chart(month);
```

**Refresh Strategy:** Every 10 minutes

---

### 8. Cases Chart Materialized View

**Name:** `mv_cases_chart`

**Purpose:** Cases grouped by status for stacked bar chart

**SQL Definition:**
```sql
CREATE MATERIALIZED VIEW mv_cases_chart AS
SELECT
    location_id,
    DATE(created_at) as date,
    status,

    -- ABMS-4031: Cases by status
    COUNT(*) as case_count,

    updated_at
FROM cases
WHERE deleted_at IS NULL
GROUP BY location_id, DATE(created_at), status
WITH DATA;

-- Indexes
CREATE UNIQUE INDEX idx_mv_cases_chart_location_date_status
    ON mv_cases_chart(location_id, date, status);
CREATE INDEX idx_mv_cases_chart_date
    ON mv_cases_chart(date);
```

**Refresh Strategy:** Every 5 minutes

---

## Refresh Strategy

### Automated Refresh with BullMQ

**Why BullMQ instead of pg_cron?**
- ✅ BullMQ already installed in msvc-analytics-abms
- ✅ Uses existing Redis infrastructure (no new dependencies)
- ✅ Application-level control and monitoring
- ✅ No PostgreSQL superuser permissions required
- ✅ Better for microservices architecture
- ✅ Built-in retry logic and failure handling
- ✅ Web UI available for monitoring (Bull Board)

### Implementation

#### 1. Create Refresh Job Service

```typescript
// src/services/jobs/MaterializedViewRefresh.ts
import { Queue, Worker } from 'bullmq';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';
import { Container } from 'typedi';
import { RedisClient } from '../cache/RedisClient';

const logger = createLogger('MaterializedViewRefresh');

// Get Redis connection from existing RedisClient
const redisClient = Container.get(RedisClient);
const redisConnection = {
  host: redisClient.client.options.host,
  port: redisClient.client.options.port,
  password: redisClient.client.options.password,
  db: redisClient.client.options.db
};

// Create Queue for materialized view refresh jobs
export const mvRefreshQueue = new Queue('materialized-view-refresh', {
  connection: redisConnection
});

// Schedule all materialized view refresh jobs
export async function setupMaterializedViewRefresh() {
  logger.info('Setting up materialized view refresh schedules...');

  // Every 5 minutes (Jobs, Leads, Cases)
  await mvRefreshQueue.add('refresh-job-kpis', {}, {
    repeat: { pattern: '*/5 * * * *' },
    jobId: 'refresh-job-kpis-schedule'
  });

  await mvRefreshQueue.add('refresh-job-records', {}, {
    repeat: { pattern: '*/5 * * * *' },
    jobId: 'refresh-job-records-schedule'
  });

  await mvRefreshQueue.add('refresh-leads-chart', {}, {
    repeat: { pattern: '*/5 * * * *' },
    jobId: 'refresh-leads-chart-schedule'
  });

  await mvRefreshQueue.add('refresh-lead-records', {}, {
    repeat: { pattern: '*/5 * * * *' },
    jobId: 'refresh-lead-records-schedule'
  });

  await mvRefreshQueue.add('refresh-cases-chart', {}, {
    repeat: { pattern: '*/5 * * * *' },
    jobId: 'refresh-cases-chart-schedule'
  });

  // Every 10 minutes (Invoices, Consumables)
  await mvRefreshQueue.add('refresh-invoice-kpis', {}, {
    repeat: { pattern: '*/10 * * * *' },
    jobId: 'refresh-invoice-kpis-schedule'
  });

  await mvRefreshQueue.add('refresh-invoice-records', {}, {
    repeat: { pattern: '*/10 * * * *' },
    jobId: 'refresh-invoice-records-schedule'
  });

  await mvRefreshQueue.add('refresh-consumable-purchases-chart', {}, {
    repeat: { pattern: '*/10 * * * *' },
    jobId: 'refresh-consumable-purchases-chart-schedule'
  });

  // Every 15 minutes (Audits, Sales Targets, Service Types)
  await mvRefreshQueue.add('refresh-quality-audit-kpis', {}, {
    repeat: { pattern: '*/15 * * * *' },
    jobId: 'refresh-quality-audit-kpis-schedule'
  });

  await mvRefreshQueue.add('refresh-quality-audit-records', {}, {
    repeat: { pattern: '*/15 * * * *' },
    jobId: 'refresh-quality-audit-records-schedule'
  });

  await mvRefreshQueue.add('refresh-sales-targets-chart', {}, {
    repeat: { pattern: '*/15 * * * *' },
    jobId: 'refresh-sales-targets-chart-schedule'
  });

  await mvRefreshQueue.add('refresh-service-type-invoices-chart', {}, {
    repeat: { pattern: '*/15 * * * *' },
    jobId: 'refresh-service-type-invoices-chart-schedule'
  });

  logger.info('All materialized view refresh schedules created');
}

// Worker to process refresh jobs
export function startMaterializedViewWorker() {
  const worker = new Worker('materialized-view-refresh', async (job) => {
    const startTime = Date.now();

    try {
      logger.info(`Starting ${job.name}...`);

      // Map job names to materialized view names
      const viewMap: Record<string, string> = {
        'refresh-invoice-kpis': 'mv_invoice_kpis',
        'refresh-invoice-records': 'mv_invoice_records',
        'refresh-job-kpis': 'mv_job_kpis',
        'refresh-job-records': 'mv_job_records',
        'refresh-quality-audit-kpis': 'mv_quality_audit_kpis',
        'refresh-quality-audit-records': 'mv_quality_audit_records',
        'refresh-sales-targets-chart': 'mv_sales_targets_chart',
        'refresh-service-type-invoices-chart': 'mv_service_type_invoices_chart',
        'refresh-leads-chart': 'mv_leads_chart',
        'refresh-lead-records': 'mv_lead_records',
        'refresh-consumable-purchases-chart': 'mv_consumable_purchases_chart',
        'refresh-cases-chart': 'mv_cases_chart'
      };

      const viewName = viewMap[job.name];
      if (!viewName) {
        throw new Error(`Unknown job: ${job.name}`);
      }

      // Refresh materialized view
      await AppDataSource.query(
        `REFRESH MATERIALIZED VIEW CONCURRENTLY ${viewName}`
      );

      const duration = Date.now() - startTime;
      logger.info(`${job.name} completed in ${duration}ms`);

    } catch (error) {
      logger.error(`${job.name} failed:`, error);
      throw error; // BullMQ will retry based on job options
    }
  }, {
    connection: redisConnection,
    concurrency: 2, // Process up to 2 refreshes in parallel
    limiter: {
      max: 5,        // Max 5 refreshes
      duration: 1000 // per second (to avoid DB overload)
    }
  });

  // Event listeners for monitoring
  worker.on('completed', (job) => {
    logger.info(`Job ${job.id} (${job.name}) completed successfully`);
  });

  worker.on('failed', (job, err) => {
    logger.error(`Job ${job?.id} (${job?.name}) failed:`, err.message);
  });

  worker.on('error', (err) => {
    logger.error('Worker error:', err);
  });

  logger.info('Materialized view refresh worker started');

  return worker;
}

// Manual refresh function (for development/testing)
export async function manualRefreshAllViews() {
  logger.info('Manually refreshing all materialized views...');

  const views = [
    'mv_invoice_kpis',
    'mv_invoice_records',
    'mv_job_kpis',
    'mv_job_records',
    'mv_quality_audit_kpis',
    'mv_quality_audit_records',
    'mv_sales_targets_chart',
    'mv_service_type_invoices_chart',
    'mv_leads_chart',
    'mv_lead_records',
    'mv_consumable_purchases_chart',
    'mv_cases_chart'
  ];

  for (const view of views) {
    try {
      await AppDataSource.query(`REFRESH MATERIALIZED VIEW CONCURRENTLY ${view}`);
      logger.info(`✓ Refreshed ${view}`);
    } catch (error) {
      logger.error(`✗ Failed to refresh ${view}:`, error);
    }
  }

  logger.info('Manual refresh complete');
}
```

#### 2. Start Worker in Server

```typescript
// src/server.ts
import { setupMaterializedViewRefresh, startMaterializedViewWorker } from './services/jobs/MaterializedViewRefresh';

async function startServer() {
  // ... existing startup code

  // Setup and start materialized view refresh
  if (process.env.ENABLE_MV_REFRESH !== 'false') {
    await setupMaterializedViewRefresh();
    startMaterializedViewWorker();
    logger.info('Materialized view auto-refresh enabled');
  }

  // ... rest of server startup
}
```

#### 3. Environment Configuration

```bash
# .env
ENABLE_MV_REFRESH=true  # Set to false to disable auto-refresh (for dev/testing)
```

### Monitoring Refresh Jobs

#### Option 1: Bull Board (Web UI)

```bash
# Install Bull Board
yarn add @bull-board/api @bull-board/express @bull-board/ui
```

```typescript
// src/server.ts
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';
import { mvRefreshQueue } from './services/jobs/MaterializedViewRefresh';

// Setup Bull Board
const serverAdapter = new ExpressAdapter();
serverAdapter.setBasePath('/admin/queues');

createBullBoard({
  queues: [new BullMQAdapter(mvRefreshQueue)],
  serverAdapter
});

app.use('/admin/queues', serverAdapter.getRouter());

// Access at: http://localhost:4040/admin/queues
```

#### Option 2: Code-based Monitoring

```typescript
// Get queue statistics
const stats = await mvRefreshQueue.getJobCounts();
console.log(stats);
// { waiting: 0, active: 1, completed: 245, failed: 2 }

// Get failed jobs
const failedJobs = await mvRefreshQueue.getFailed();
failedJobs.forEach(job => {
  console.log(`Failed: ${job.name} - ${job.failedReason}`);
});

// Get active jobs
const activeJobs = await mvRefreshQueue.getActive();
console.log(`Currently refreshing: ${activeJobs.map(j => j.name).join(', ')}`);
```

### Manual Refresh (Development/Testing)

```typescript
// Via code
import { manualRefreshAllViews } from './services/jobs/MaterializedViewRefresh';
await manualRefreshAllViews();

// Via GraphQL mutation (optional)
mutation {
  refreshMaterializedViews
}

// Via API endpoint (optional)
POST /api/admin/refresh-materialized-views
```

### Direct SQL Refresh (Fallback)

```sql
-- Refresh individual view
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_kpis;

-- Refresh all views
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_kpis;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_records;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_job_kpis;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_job_records;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_quality_audit_kpis;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_quality_audit_records;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_sales_targets_chart;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_service_type_invoices_chart;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_leads_chart;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_lead_records;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_consumable_purchases_chart;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_cases_chart;
```

---

## Service Implementation with Materialized Views

### Example: Invoice Credits KPI Service

```typescript
// src/services/kpi/InvoicesCreditsKPI.ts
import { Service } from 'typedi';
import { BaseWidgetService } from '../BaseWidgetService';
import { KPIData, DashboardFilterInput } from '../../schema/DashboardSchema';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';

const logger = createLogger('InvoicesCreditsKPI');

@Service()
export class InvoicesCreditsKPI extends BaseWidgetService<KPIData> {
  readonly widgetName = 'invoices_credits_kpi';

  protected async fetchFromDatabase(filters: DashboardFilterInput): Promise<KPIData> {
    logger.info('Fetching invoices credits KPI from materialized view', { filters });

    // Query materialized view (much faster than base tables)
    const result = await AppDataSource.query(`
      SELECT
        SUM(net_turnover) as current_value,
        (
          SELECT SUM(net_turnover)
          FROM mv_invoice_kpis
          WHERE date BETWEEN $3 AND $4
            AND ($5::varchar IS NULL OR location_id = $5)
        ) as previous_value
      FROM mv_invoice_kpis
      WHERE date BETWEEN $1 AND $2
        AND ($5::varchar IS NULL OR location_id = $5)
    `, [
      filters.dateRange.startDate,
      filters.dateRange.endDate,
      // Previous period (same duration, shifted back)
      filters.previousPeriodStart,
      filters.previousPeriodEnd,
      filters.location || null,
    ]);

    const current = parseFloat(result[0].current_value || '0');
    const previous = parseFloat(result[0].previous_value || '0');
    const change = previous > 0 ? ((current - previous) / previous) * 100 : 0;

    return {
      widgetName: this.widgetName,
      ticket: 'ABMS-4014',
      value: current,
      previousValue: previous,
      changePercentage: change,
      trend: change > 0 ? 'up' : change < 0 ? 'down' : 'stable',
      lastUpdated: new Date(),
    };
  }
}
```

---

## Record Lists (Drilldown Functionality)

### Architecture

When users click on a KPI widget, they can drill down to see the **record list** that contributed to that KPI value.

**IMPORTANT:** Record lists should also use materialized views for better performance and consistency with KPI values.

```
┌─────────────────────────┐
│   KPI Widget Display    │
│   Total Turnover: $50K  │
│   [Click to view list]  │
└───────────┬─────────────┘
            │ onClick()
            ▼
┌─────────────────────────────────────┐
│   Record List Modal/Page            │
│   Query: mv_invoice_records         │
│   ┌───────────────────────────────┐ │
│   │ Invoice #  Date      Amount   │ │
│   │ INV-001    2025-01  $5,000    │ │
│   │ INV-002    2025-01  $3,500    │ │
│   │ INV-003    2025-01  $7,200    │ │
│   │ ...                            │ │
│   └───────────────────────────────┘ │
└─────────────────────────────────────┘
```

### Record List Materialized Views

Each KPI should have a corresponding materialized view for record lists that stores individual records (not aggregated). This ensures:
- ✅ Same data shown in KPI and record list
- ✅ Fast pagination and sorting
- ✅ Consistent performance
- ✅ No data discrepancies

### GraphQL Schema for Record Lists

```typescript
// src/schema/DashboardSchema.ts

@ObjectType()
export class InvoiceRecord {
  @Field()
  id: string;

  @Field()
  invoiceNumber: string;

  @Field()
  invoiceDate: Date;

  @Field()
  customerName: string;

  @Field()
  grandTotal: number;

  @Field()
  status: string;
}

@ObjectType()
export class RecordListResponse {
  @Field(() => [InvoiceRecord])
  records: InvoiceRecord[];

  @Field()
  total: number;

  @Field()
  page: number;

  @Field()
  pageSize: number;
}

@InputType()
export class RecordListFilterInput {
  @Field()
  dateRange: DateRangeInput;

  @Field({ nullable: true })
  location?: string;

  @Field({ defaultValue: 1 })
  page: number;

  @Field({ defaultValue: 20 })
  pageSize: number;

  @Field({ nullable: true })
  sortBy?: string;

  @Field({ nullable: true })
  sortOrder?: string;
}
```

### Example Record List Materialized Views

#### 1. Invoice Records (for Invoice KPIs)

```sql
CREATE MATERIALIZED VIEW mv_invoice_records AS
SELECT
    id,
    invoice_number,
    invoice_date,
    customer_name,
    location_id,
    grand_total,
    invoice_type,
    account_code,
    service_type,
    status,
    exported,
    created_at,
    updated_at
FROM invoices
WHERE deleted_at IS NULL
WITH DATA;

-- Indexes for fast filtering and sorting
CREATE INDEX idx_mv_invoice_records_date
    ON mv_invoice_records(invoice_date);
CREATE INDEX idx_mv_invoice_records_location_date
    ON mv_invoice_records(location_id, invoice_date);
CREATE INDEX idx_mv_invoice_records_customer
    ON mv_invoice_records(customer_name);
```

**Refresh:** Every 10 minutes (same as mv_invoice_kpis)

#### 2. Job Records (for Job KPIs)

```sql
CREATE MATERIALIZED VIEW mv_job_records AS
SELECT
    id,
    job_number,
    customer_name,
    location_id,
    start_date,
    status,
    job_value,
    has_budgeted_extra_work,
    budgeted_extra_amount,
    created_at,
    updated_at
FROM jobs
WHERE deleted_at IS NULL
WITH DATA;

-- Indexes
CREATE INDEX idx_mv_job_records_date
    ON mv_job_records(start_date);
CREATE INDEX idx_mv_job_records_location_date
    ON mv_job_records(location_id, start_date);
CREATE INDEX idx_mv_job_records_status
    ON mv_job_records(status);
```

**Refresh:** Every 5 minutes (same as mv_job_kpis)

#### 3. Quality Audit Records (for Audit KPIs)

```sql
CREATE MATERIALIZED VIEW mv_quality_audit_records AS
SELECT
    id,
    audit_number,
    location_id,
    completed_date,
    status,
    score,
    audit_type,
    auditor_name,
    created_at,
    updated_at
FROM quality_audits
WHERE deleted_at IS NULL
WITH DATA;

-- Indexes
CREATE INDEX idx_mv_quality_audit_records_date
    ON mv_quality_audit_records(completed_date);
CREATE INDEX idx_mv_quality_audit_records_location_date
    ON mv_quality_audit_records(location_id, completed_date);
CREATE INDEX idx_mv_quality_audit_records_type
    ON mv_quality_audit_records(audit_type);
```

**Refresh:** Every 15 minutes (same as mv_quality_audit_kpis)

#### 4. Lead Records (for Leads Chart)

```sql
CREATE MATERIALIZED VIEW mv_lead_records AS
SELECT
    id,
    lead_number,
    customer_name,
    location_id,
    created_at,
    status,
    source,
    value,
    updated_at
FROM leads
WHERE deleted_at IS NULL
WITH DATA;

-- Indexes
CREATE INDEX idx_mv_lead_records_date
    ON mv_lead_records(created_at);
CREATE INDEX idx_mv_lead_records_location_date
    ON mv_lead_records(location_id, created_at);
```

**Refresh:** Every 5 minutes (same as mv_leads_chart)

---

### Resolver with Record List Support

```typescript
// src/resolver/DashboardResolver.ts

@Resolver()
export class DashboardResolver {

  // KPI query (returns aggregated value from mv_invoice_kpis)
  @Query(() => KPIData, { name: `${SchemaPrefix}GetInvoicesCreditsKPI` })
  async getInvoicesCreditsKPI(
    @Arg('filters') filters: DashboardFilterInput,
    @Ctx() ctx: Context
  ): Promise<KPIData> {
    const service = Container.get(InvoicesCreditsKPI);
    return await service.getData(filters);
  }

  // Record list query (returns individual records from mv_invoice_records)
  @Query(() => RecordListResponse, { name: `${SchemaPrefix}GetInvoicesRecordList` })
  async getInvoicesRecordList(
    @Arg('filters') filters: RecordListFilterInput,
    @Ctx() ctx: Context
  ): Promise<RecordListResponse> {
    logger.info('Fetching invoices record list from materialized view', { filters });

    // Query materialized view (not base table) for consistent data with KPIs
    const query = `
      SELECT
        id,
        invoice_number,
        invoice_date,
        customer_name,
        grand_total,
        status,
        COUNT(*) OVER() as total_count
      FROM mv_invoice_records
      WHERE invoice_date >= $1::date
        AND invoice_date <= $2::date
        AND ($3::varchar IS NULL OR location_id = $3)
      ORDER BY ${filters.sortBy || 'invoice_date'} ${filters.sortOrder || 'DESC'}
      LIMIT $4 OFFSET $5
    `;

    const results = await AppDataSource.query(query, [
      filters.dateRange.startDate,
      filters.dateRange.endDate,
      filters.location || null,
      filters.pageSize,
      (filters.page - 1) * filters.pageSize,
    ]);

    const total = results.length > 0 ? parseInt(results[0].total_count) : 0;

    return {
      records: results.map(row => ({
        id: row.id,
        invoiceNumber: row.invoice_number,
        invoiceDate: row.invoice_date,
        customerName: row.customer_name,
        grandTotal: parseFloat(row.grand_total),
        status: row.status,
      })),
      total,
      page: filters.page,
      pageSize: filters.pageSize,
    };
  }
}
```

### Frontend Integration Example

```typescript
// fe-abms/src/pages/Dashboard.tsx

const InvoicesCreditsKPIWidget = () => {
  const [showRecordList, setShowRecordList] = useState(false);

  const { data: kpiData } = useQuery(GET_INVOICES_CREDITS_KPI, {
    variables: { filters: { dateRange, location } }
  });

  const { data: recordList } = useQuery(GET_INVOICES_RECORD_LIST, {
    variables: { filters: { dateRange, location, page: 1, pageSize: 20 } },
    skip: !showRecordList,
  });

  return (
    <>
      <KPICard
        title="Total Turnover"
        value={kpiData?.abmsGetInvoicesCreditsKPI?.value}
        trend={kpiData?.abmsGetInvoicesCreditsKPI?.trend}
        onClick={() => setShowRecordList(true)}
      />

      {showRecordList && (
        <RecordListModal
          title="Invoice Records"
          records={recordList?.abmsGetInvoicesRecordList?.records}
          total={recordList?.abmsGetInvoicesRecordList?.total}
          onClose={() => setShowRecordList(false)}
        />
      )}
    </>
  );
};
```

---

## Monitoring & Maintenance

### Check Materialized View Freshness

```sql
-- Check when views were last refreshed
SELECT
    schemaname,
    matviewname,
    matviewowner,
    tablespace,
    hasindexes,
    ispopulated,
    definition
FROM pg_matviews
WHERE schemaname = 'public'
ORDER BY matviewname;
```

### View Refresh Status

See BullMQ monitoring section above for checking refresh job status via:
- Bull Board UI at `/admin/queues`
- Code-based monitoring via `getRefreshQueueStats()`

### Performance Metrics

```sql
-- Check materialized view sizes
SELECT
    schemaname,
    matviewname,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||matviewname)) as size
FROM pg_matviews
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||matviewname) DESC;
```

---

## Materialized View Creation (via msvc-abms)

**IMPORTANT:** Materialized views are created via **msvc-abms migrations** (same team maintains both services).

**Why in msvc-abms?**
- Materialized views are database objects in the shared `msvc_abms` database
- msvc-abms owns the schema and all database migrations
- msvc-analytics-abms has **read-only access** (no writes to PostgreSQL)
- Both services maintained by the same team

**Migration Process:**
1. Add SQL definitions from this document to msvc-abms migrations
2. Create migration file in msvc-abms repository
3. Run migration via msvc-abms deployment
4. msvc-analytics-abms automatically has read access to new views

**Example migration in msvc-abms:**
```typescript
// msvc-abms/src/datasource/migrations/1234567890-CreateAnalyticsMaterializedViews.ts

export class CreateAnalyticsMaterializedViews1234567890 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create all 12 materialized views for analytics
    await queryRunner.query(`
      CREATE MATERIALIZED VIEW mv_invoice_kpis AS
      SELECT ...
      WITH DATA;
    `);

    // Create indexes
    await queryRunner.query(`
      CREATE UNIQUE INDEX idx_mv_invoice_kpis_location_date
      ON mv_invoice_kpis(location_id, date);
    `);

    // Note: View refresh is handled by BullMQ in msvc-analytics-abms
    // No pg_cron setup needed in migration
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop views
    await queryRunner.query(`DROP MATERIALIZED VIEW IF EXISTS mv_invoice_kpis;`);
  }
}
```

**Note:**
- msvc-analytics-abms does **NOT** run any database migrations - all schema changes via msvc-abms
- View **refresh is handled by BullMQ** in msvc-analytics-abms service (not pg_cron)

---

## Summary

### KPI & Chart Materialized Views (Aggregated Data)

| Materialized View | Refresh Frequency | Used By | Purpose |
|-------------------|-------------------|---------|---------|
| `mv_invoice_kpis` | 10 min | 5 KPIs | Aggregated invoice metrics |
| `mv_job_kpis` | 5 min | 2 KPIs | Aggregated job metrics |
| `mv_quality_audit_kpis` | 15 min | 2 widgets | Aggregated audit metrics |
| `mv_sales_targets_chart` | 15 min | 1 chart | Sales targets vs actual |
| `mv_service_type_invoices_chart` | 15 min | 1 chart | Turnover by service type |
| `mv_leads_chart` | 5 min | 1 chart | Lead metrics over time |
| `mv_consumable_purchases_chart` | 10 min | 1 chart | Consumable spending |
| `mv_cases_chart` | 5 min | 1 chart | Case metrics by status |

### Record List Materialized Views (Individual Records)

| Materialized View | Refresh Frequency | Used By | Purpose |
|-------------------|-------------------|---------|---------|
| `mv_invoice_records` | 10 min | Invoice KPIs | Individual invoice records |
| `mv_job_records` | 5 min | Job KPIs | Individual job records |
| `mv_quality_audit_records` | 15 min | Audit widgets | Individual audit records |
| `mv_lead_records` | 5 min | Lead chart | Individual lead records |

**Total:** 12 materialized views
- 8 for KPIs/charts (aggregated data)
- 4 for record lists (individual records)
- All supporting 14 dashboard widgets with drilldown functionality

---

**Next Steps:**
1. Create materialized views via msvc-abms migrations
2. Grant REFRESH MATERIALIZED VIEW permission to analytics user (if using separate user)
3. Start msvc-analytics-abms with BullMQ refresh enabled
4. Monitor refresh jobs via Bull Board UI at `/admin/queues`
5. Implement record list queries in resolvers
6. Add frontend drilldown functionality
