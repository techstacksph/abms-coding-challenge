import path from 'path';
import { DataSource, DataSourceOptions, LoggerOptions } from 'typeorm';
import environment from './src/environment';

const entity_path = path.join('src/model-dictionary/**/*.{js,ts}');
const migration_path = path.join('src/datasource/migrations/**/*.{js,ts}');

let sql_logger_options: LoggerOptions = environment.SHOW_SQL ? true : false;

// Check if connecting to local database (localhost or container name)
const isLocalDatabase =
  environment.DB_HOST === 'localhost' ||
  environment.DB_HOST === '127.0.0.1' ||
  environment.DB_HOST?.includes('postgres'); // Docker container name

const baseConfig: DataSourceOptions = {
  type: 'postgres',
  host: environment.DB_HOST ?? 'localhost',
  port: environment.DB_PORT ?? 5432,
  username: environment.DB_USER ?? 'postgres',
  password: environment.DB_PASSWORD ?? '',
  database: environment.DB_NAME ?? '',
  synchronize: false, // Never sync - read-only service
  logging: sql_logger_options,
  entities: [entity_path],
  migrations: [migration_path],
  migrationsTableName: 'analytics_migrations',
  migrationsRun: false, // Run migrations manually with yarn migration:run
  subscribers: [],
  name: 'default',
  maxQueryExecutionTime: 5000, // Log queries taking >5s
  extra: {
    max: 50, // Max connections
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 30000,
  },
};

// Add SSL only for remote databases
const dataSourceOptions: DataSourceOptions = isLocalDatabase
  ? baseConfig
  : {
      ...baseConfig,
      extra: {
        ...baseConfig.extra,
        ssl: {
          rejectUnauthorized: false,
        },
      },
    };

export const AppDataSource = new DataSource(dataSourceOptions);