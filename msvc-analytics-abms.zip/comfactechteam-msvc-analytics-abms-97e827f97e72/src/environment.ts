import path from 'path';

import dotenv from 'dotenv';

// Load environment variables
dotenv.config({ path: path.resolve(__dirname, '../.env') });

export const environment = {
  // Server
  NODE_ENV: process.env.NODE_ENV,
  PORT: parseInt(process.env.PORT || '4040', 10),
  TENANT_PREFIX: process.env.TENANT_PREFIX,
  SYSTEM_ID: process.env.SYSTEM_ID,

  // Database (Shared with msvc-abms)
  DB_HOST: process.env.DB_HOST,
  DB_PORT: parseInt(process.env.DB_PORT || '5432', 10),
  DB_NAME: process.env.DB_NAME,
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD,

  // Redis (Shared infrastructure with msvc-abms)
  REDIS_HOST: process.env.REDIS_HOST,
  REDIS_PORT: parseInt(process.env.REDIS_PORT || '6379', 10),
  REDIS_PASSWORD: process.env.REDIS_PASSWORD,
  REDIS_DB: parseInt(process.env.REDIS_DB || '1', 10), // Use DB 1 for analytics (0 is msvc-abms)
  REDIS_TLS: process.env.REDIS_TLS === 'true',
  REDIS_MAX_RETRIES: parseInt(process.env.REDIS_MAX_RETRIES || '3', 10),
  REDIS_CONNECT_TIMEOUT: parseInt(process.env.REDIS_CONNECT_TIMEOUT || '10000', 10),

  // Pulsar
  PULSAR_SERVICE_URL: process.env.PULSAR_SERVICE_URL,
  PULSAR_SUBSCRIPTION_NAME: process.env.PULSAR_SUBSCRIPTION_NAME || 'analytics-cache-invalidation',

  // GraphQL
  GRAPHQL_PATH: process.env.GRAPHQL_PATH || '/',
  GRAPHQL_INTROSPECTION: process.env.GRAPHQL_INTROSPECTION !== 'false',
  GRAPHQL_PLAYGROUND: process.env.GRAPHQL_PLAYGROUND !== 'false',

  // Logging
  LOG_LEVEL: process.env.LOG_LEVEL,
  LOG_FORMAT: process.env.LOG_FORMAT,
  SHOW_SQL: process.env.SHOW_SQL === 'true',

  // Cache
  CACHE_DEFAULT_TTL: parseInt(process.env.CACHE_DEFAULT_TTL || '600', 10),
  CACHE_MAX_KEYS: parseInt(process.env.CACHE_MAX_KEYS || '10000', 10),

  // Performance
  MAX_QUERY_COMPLEXITY: parseInt(process.env.MAX_QUERY_COMPLEXITY || '1000', 10),
  RATE_LIMIT_WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10),
  RATE_LIMIT_MAX_REQUESTS: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100', 10),

  // Helper methods
  isDevelopment(): boolean {
    return this.NODE_ENV === 'development';
  },
  isProduction(): boolean {
    return this.NODE_ENV === 'production';
  },
  isTest(): boolean {
    return this.NODE_ENV === 'test';
  },
};

export default environment;
