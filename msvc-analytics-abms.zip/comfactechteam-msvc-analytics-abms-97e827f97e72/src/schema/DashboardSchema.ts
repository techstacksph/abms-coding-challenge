import { ObjectType, Field, InputType, registerEnumType } from 'type-graphql';
import { GraphQLJSON } from 'graphql-scalars';

// Enums
export enum TrendDirection {
  UP = 'UP',
  DOWN = 'DOWN',
  STABLE = 'STABLE',
}

registerEnumType(TrendDirection, {
  name: 'TrendDirection',
  description: 'Direction of trend (up, down, or stable)',
});

// Input Types
@InputType()
export class DateRangeInput {
  @Field()
  startDate: string;

  @Field()
  endDate: string;
}

@InputType()
export class DashboardFilterInput {
  @Field({ nullable: true })
  location?: string;

  @Field(() => DateRangeInput)
  dateRange: DateRangeInput;

  @Field({ defaultValue: 'invoice_date' })
  dateField: string;
}

// Output Types
@ObjectType()
export class KPIData {
  @Field()
  widgetName: string; // Data source-based name (e.g., 'invoices_credits_kpi')

  @Field()
  value: number;

  @Field({ nullable: true })
  previousValue?: number;

  @Field({ nullable: true })
  changePercentage?: number;

  @Field(() => TrendDirection, { nullable: true })
  trend?: TrendDirection;

  @Field(() => GraphQLJSON, { nullable: true })
  metadata?: Record<string, unknown>;

  @Field()
  lastUpdated: Date;
}

@ObjectType()
export class ChartDataset {
  @Field()
  label: string;

  @Field(() => [Number])
  data: number[];

  @Field({ nullable: true })
  type?: string;

  @Field({ nullable: true })
  backgroundColor?: string;

  @Field({ nullable: true })
  borderColor?: string;
}

@ObjectType()
export class ChartData {
  @Field()
  widgetName: string; // Data source-based name (e.g., 'sales_targets_chart')

  @Field(() => [String])
  labels: string[];

  @Field(() => [ChartDataset])
  datasets: ChartDataset[];

  @Field(() => GraphQLJSON, { nullable: true })
  metadata?: Record<string, unknown>;

  @Field()
  lastUpdated: Date;
}

@ObjectType()
export class DashboardData {
  @Field(() => [KPIData])
  kpis: KPIData[];

  @Field(() => [ChartData])
  charts: ChartData[];

  @Field()
  lastUpdated: Date;
}
