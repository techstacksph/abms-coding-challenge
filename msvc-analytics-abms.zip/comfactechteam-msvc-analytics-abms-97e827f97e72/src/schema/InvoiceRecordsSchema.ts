import { ObjectType, Field, InputType } from 'type-graphql';

// Invoice Record for detailed list
@ObjectType()
export class InvoiceRecord {
  @Field()
  id: string;

  @Field()
  invoiceNumber: string;

  @Field()
  invoiceDate: Date;

  @Field({ nullable: true })
  billDate?: Date;

  @Field()
  netTurnover: number;

  @Field({ nullable: true })
  locationId?: string;

  @Field({ nullable: true })
  customerName?: string;

  @Field({ nullable: true })
  status?: string;
}

// Paginated list response
@ObjectType()
export class InvoiceRecordList {
  @Field(() => [InvoiceRecord])
  records: InvoiceRecord[];

  @Field()
  total: number;

  @Field()
  page: number;

  @Field()
  pageSize: number;

  @Field()
  lastUpdated: Date;
}

// Pagination input
@InputType()
export class PaginationInput {
  @Field({ defaultValue: 1 })
  page: number;

  @Field({ defaultValue: 10 })
  pageSize: number;
}
