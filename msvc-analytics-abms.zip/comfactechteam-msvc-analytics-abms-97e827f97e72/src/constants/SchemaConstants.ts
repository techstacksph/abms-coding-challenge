import environment from '../environment';

/**
 * Schema prefix for GraphQL queries and mutations.
 * Used to namespace analytics queries in the federated gateway.
 *
 * Example:
 * - Query name: getInvoicesCreditsKPI
 * - With prefix: abmsGetInvoicesCreditsKPI
 *
 * This prevents naming conflicts when multiple services are federated
 * and allows for multi-tenant deployments.
 */
export const SchemaPrefix = environment.TENANT_PREFIX;
