/**
 * Cache TTL (Time-To-Live) configuration for dashboard widgets
 * Uses data source-based widget names instead of ticket numbers
 * Values are in seconds
 */

export const WIDGET_TTL: Record<string, number> = {
  // Invoice-based KPIs (10 minutes)
  invoices_credits_kpi: 600, // ABMS-4014: Total Turnover
  invoices_count_kpi: 600, // ABMS-4019: Turnover Count
  franchise_invoices_kpi: 600, // ABMS-4024: Franchise Sales
  extra_work_invoices_kpi: 600, // ABMS-4025: Extra Work Sold
  consumable_invoices_kpi: 600, // ABMS-4026: Consumables Turnover

  // Job-based KPIs (5 minutes - more frequent updates)
  converted_jobs_kpi: 300, // ABMS-4021: Converted Jobs
  budgeted_jobs_kpi: 300, // ABMS-4022: Budgeted Extra Jobs

  // Audit KPIs (15 minutes - less frequent)
  quality_audits_kpi: 900, // ABMS-4023: Total Audits

  // Sales Charts (15 minutes)
  sales_targets_chart: 900, // ABMS-4027: Sales Target per Location
  service_type_invoices_chart: 900, // ABMS-4028: Turnover per Service Type

  // CRM Charts (5 minutes)
  leads_chart: 300, // ABMS-4029: New Leads
  cases_chart: 300, // ABMS-4031: Cases
  quality_audits_chart: 300, // ABMS-4032: QA

  // Procurement Charts (10 minutes)
  consumable_purchases_chart: 600, // ABMS-4030: Consumable Spending vs Budget
};

/**
 * Get TTL for a specific widget name
 * Returns default TTL if widget not found
 */
export function getTTL(widgetName: string, defaultTTL = 600): number {
  return WIDGET_TTL[widgetName] ?? defaultTTL;
}

/**
 * Widget categories for easier management
 * Organized by data source
 */
export const WIDGET_CATEGORIES = {
  INVOICE_KPI: [
    'invoices_credits_kpi',
    'invoices_count_kpi',
    'franchise_invoices_kpi',
    'extra_work_invoices_kpi',
    'consumable_invoices_kpi',
  ],
  JOB_KPI: ['converted_jobs_kpi', 'budgeted_jobs_kpi'],
  AUDIT_KPI: ['quality_audits_kpi'],
  SALES_CHART: ['sales_targets_chart', 'service_type_invoices_chart'],
  CRM_CHART: ['leads_chart', 'cases_chart', 'quality_audits_chart'],
  PROCUREMENT_CHART: ['consumable_purchases_chart'],
};
