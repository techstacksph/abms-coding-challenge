import winston from 'winston';
import util from 'util';
import environment from '../environment';

// Custom format for pretty console logs
const prettyFormat = winston.format.printf(({ timestamp, level, message, context, ...meta }) => {
  const ctx = context ? `[${context}]` : '';

  // Build the base log line
  let logLine = `${timestamp} ${level} ${ctx} ${message}`;

  // Pretty print metadata if it exists
  if (Object.keys(meta).length > 0) {
    // Filter out Winston internal properties
    const cleanMeta = Object.keys(meta)
      .filter((key) => !['timestamp', 'level', 'message', 'context'].includes(key))
      .reduce(
        (obj, key) => {
          obj[key] = meta[key];
          return obj;
        },
        {} as Record<string, unknown>
      );

    if (Object.keys(cleanMeta).length > 0) {
      // Use util.inspect for colored, formatted output
      const prettyMeta = util.inspect(cleanMeta, {
        depth: null,
        colors: true,
        compact: false,
        breakLength: 80,
      });
      logLine += `\n${prettyMeta}`;
    }
  }

  return logLine;
});

// Log format for console (development)
const consoleFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.colorize({ all: true }),
  prettyFormat
);

// Log format for files (production)
const fileFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

const transports: winston.transport[] = [
  new winston.transports.Console({
    format: consoleFormat,
  }),
];

// Add file transport for production
if (environment.isProduction()) {
  transports.push(
    new winston.transports.File({
      filename: 'logs/analytics-error.log',
      level: 'error',
      format: fileFormat,
    }),
    new winston.transports.File({
      filename: 'logs/analytics.log',
      format: fileFormat,
    })
  );
}

const baseLogger = winston.createLogger({
  level: environment.LOG_LEVEL,
  transports,
});

/**
 * Create a logger instance with optional context
 * @param context - Context name (e.g., service name, module name)
 * @returns Winston logger instance
 *
 * @example
 * const logger = createLogger('DashboardService');
 * logger.info('Processing dashboard request', {
 *   userId: '123',
 *   filters: { dateRange: '...' }
 * });
 *
 * // Output (prettified in console):
 * // 2025-01-15 10:30:00 info [DashboardService] Processing dashboard request
 * // {
 * //   userId: '123',
 * //   filters: { dateRange: '...' }
 * // }
 */
export function createLogger(context?: string): winston.Logger {
  return baseLogger.child({ context });
}

export default baseLogger;
