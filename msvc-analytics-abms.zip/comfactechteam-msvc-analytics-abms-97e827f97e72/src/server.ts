import 'reflect-metadata';
import express, { Application } from 'express';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginLandingPageLocalDefault } from '@apollo/server/plugin/landingPage/default';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import { buildSchema } from 'type-graphql';
import { Container } from 'typedi';

import environment from './environment';
import { createLogger } from './utils/logger';
import { initializeDatabase } from './datasource/datasource';
import { RedisClient } from './services/cache/RedisClient';
import { PulsarClient } from './client/PulsarClient';
import {
  setupMaterializedViewRefresh,
  startMaterializedViewWorker,
  getRefreshQueueStats,
  manualRefreshAllViews,
  mvRefreshQueue,
} from './services/jobs/MaterializedViewRefresh';
import type { Worker } from 'bullmq';
import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';

// Import resolvers
import { DashboardResolver } from './resolver/DashboardResolver';
import { InvoiceRecordsResolver } from './resolver/InvoiceRecordsResolver';

const logger = createLogger('Server');

class AnalyticsServer {
  private app: Application;
  private apolloServer: ApolloServer | null = null;
  private mvRefreshWorker: Worker | null = null;

  constructor() {
    this.app = express();
  }

  async initialize(): Promise<void> {
    logger.info('Initializing Analytics Microservice...');

    // Initialize database connection
    await this.initializeDatabase();

    // Initialize Redis
    await this.initializeRedis();

    // Initialize Pulsar (event bus)
    await this.initializePulsar();

    // Initialize BullMQ for materialized view refresh
    await this.initializeMaterializedViewJobs();

    // Setup Express middleware
    this.setupMiddleware();

    // Setup routes (BEFORE GraphQL to prevent route conflicts)
    this.setupRoutes();

    // Setup GraphQL server (after routes to allow specific paths to take precedence)
    await this.setupGraphQL();

    // Error handling
    this.setupErrorHandling();
  }

  private async initializeDatabase(): Promise<void> {
    logger.info('Connecting to database (read-only)...');
    try {
      await initializeDatabase();
      logger.info('Database connected successfully');
    } catch (error) {
      logger.error('Failed to connect to database:', error);
      throw error;
    }
  }

  private async initializeRedis(): Promise<void> {
    logger.info('Connecting to Redis...');
    try {
      const redisClient = Container.get(RedisClient);
      await redisClient.connect();
      logger.info('Redis connected successfully');
    } catch (error) {
      logger.error('Failed to connect to Redis:', error);
      throw error;
    }
  }

  private async initializePulsar(): Promise<void> {
    logger.info('Connecting to Pulsar...');
    try {
      const pulsarClient = Container.get(PulsarClient);
      await pulsarClient.connect();
      logger.info('Pulsar connected successfully');
    } catch (error) {
      logger.error('Failed to connect to Pulsar:', error);
      // Don't throw - Pulsar is optional for basic functionality
      logger.warn('Continuing without Pulsar (cache invalidation will be TTL-based only)');
    }
  }

  private async initializeMaterializedViewJobs(): Promise<void> {
    logger.info('Setting up materialized view refresh jobs...');
    try {
      // Setup scheduled jobs
      await setupMaterializedViewRefresh();
      logger.info('✅ Materialized view refresh schedules created');

      // Start worker to process jobs
      this.mvRefreshWorker = startMaterializedViewWorker();
      logger.info('✅ Materialized view refresh worker started');
    } catch (error) {
      logger.error('Failed to setup materialized view refresh:', error);
      // Don't throw - the service can still run without automated refreshes
      logger.warn('Continuing without automated materialized view refresh');
    }
  }

  private setupMiddleware(): void {
    // CORS
    this.app.use(
      cors({
        origin: true,
        credentials: true,
      })
    );

    // Body parsing
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(cookieParser());

    // Logging
    if (environment.isDevelopment()) {
      this.app.use(morgan('dev'));
    } else {
      this.app.use(morgan('combined'));
    }
  }

  private async setupGraphQL(): Promise<void> {
    logger.info('Setting up GraphQL server...');

    try {
      // Build TypeGraphQL schema with Apollo Federation support
      const schema = await buildSchema({
        resolvers: [DashboardResolver, InvoiceRecordsResolver],
        container: Container,
        emitSchemaFile: environment.isDevelopment(),
        validate: false,
      });

      // Create Apollo Server
      this.apolloServer = new ApolloServer({
        schema,
        introspection: environment.GRAPHQL_INTROSPECTION,
        plugins: [
          environment.isDevelopment()
            ? ApolloServerPluginLandingPageLocalDefault({ footer: false })
            : {},
        ],
      });

      await this.apolloServer.start();
      logger.info('GraphQL server started');

      // Apply GraphQL middleware
      this.app.use(
        environment.GRAPHQL_PATH,
        expressMiddleware(this.apolloServer, {
          context: async ({ req }) => ({
            req,
            // Add user context from JWT here
          }),
        })
      );

      logger.info(`GraphQL endpoint available at ${environment.GRAPHQL_PATH}`);
    } catch (error) {
      logger.error('Failed to setup GraphQL:', error);
      throw error;
    }
  }

  private setupRoutes(): void {
    // Bull Board UI for queue monitoring
    const serverAdapter = new ExpressAdapter();
    serverAdapter.setBasePath('/admin/queues');

    createBullBoard({
      queues: [new BullMQAdapter(mvRefreshQueue)],
      serverAdapter: serverAdapter,
    });

    this.app.use('/admin/queues', serverAdapter.getRouter());
    logger.info('📊 Bull Board UI available at /admin/queues');

    // Health check
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        service: 'msvc-analytics-abms',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
      });
    });

    // Readiness check
    this.app.get('/ready', async (req, res) => {
      try {
        // Check Redis connection
        const redisClient = Container.get(RedisClient);
        await redisClient.ping();

        res.json({
          status: 'ready',
          redis: 'connected',
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        res.status(503).json({
          status: 'not ready',
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    });

    // Cache stats endpoint
    this.app.get('/cache/stats', async (req, res) => {
      try {
        const redisClient = Container.get(RedisClient);
        const stats = await redisClient.getStats();
        res.json(stats);
      } catch (error) {
        res.status(500).json({
          error: error instanceof Error ? error.message : 'Failed to get cache stats',
        });
      }
    });

    // Materialized view refresh queue stats
    this.app.get('/mv-refresh/stats', async (req, res) => {
      try {
        const stats = await getRefreshQueueStats();
        res.json(stats);
      } catch (error) {
        res.status(500).json({
          error: error instanceof Error ? error.message : 'Failed to get refresh queue stats',
        });
      }
    });

    // Manual refresh all materialized views
    this.app.post('/mv-refresh/manual', async (req, res) => {
      try {
        logger.info('Manual refresh of all materialized views triggered');
        const results = await manualRefreshAllViews();
        res.json({
          message: 'Manual refresh completed',
          results,
        });
      } catch (error) {
        res.status(500).json({
          error: error instanceof Error ? error.message : 'Failed to manually refresh views',
        });
      }
    });
  }

  private setupErrorHandling(): void {
    // 404 handler
    this.app.use((req, res) => {
      res.status(404).json({
        error: 'Not Found',
        path: req.path,
      });
    });

    // Global error handler
    this.app.use(
      (err: Error, req: express.Request, res: express.Response, _next: express.NextFunction) => {
        logger.error('Unhandled error:', err);

        res.status(500).json({
          error: environment.isDevelopment() ? err.message : 'Internal Server Error',
          stack: environment.isDevelopment() ? err.stack : undefined,
        });
      }
    );
  }

  async start(): Promise<void> {
    await this.initialize();

    const server = this.app.listen(environment.PORT, () => {
      logger.info(`🚀 Analytics Microservice running on port ${environment.PORT}`);
      logger.info(
        `📊 GraphQL endpoint: http://localhost:${environment.PORT}${environment.GRAPHQL_PATH}`
      );
      logger.info(`🏥 Health check: http://localhost:${environment.PORT}/health`);
      logger.info(`📈 Bull Board UI: http://localhost:${environment.PORT}/admin/queues`);
    });

    // Graceful shutdown
    const shutdown = async () => {
      logger.info('Shutting down gracefully...');

      server.close(() => {
        logger.info('HTTP server closed');
      });

      if (this.apolloServer) {
        await this.apolloServer.stop();
        logger.info('GraphQL server stopped');
      }

      try {
        const redisClient = Container.get(RedisClient);
        await redisClient.disconnect();
        logger.info('Redis disconnected');
      } catch (error) {
        logger.error('Error disconnecting Redis:', error);
      }

      try {
        const pulsarClient = Container.get(PulsarClient);
        await pulsarClient.disconnect();
        logger.info('Pulsar disconnected');
      } catch (error) {
        logger.error('Error disconnecting Pulsar:', error);
      }

      if (this.mvRefreshWorker) {
        try {
          await this.mvRefreshWorker.close();
          logger.info('Materialized view refresh worker stopped');
        } catch (error) {
          logger.error('Error stopping materialized view worker:', error);
        }
      }

      process.exit(0);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  }
}

// Start the server
const server = new AnalyticsServer();
server.start().catch((error) => {
  logger.error('Failed to start server:', error);
  process.exit(1);
});

export default server;
