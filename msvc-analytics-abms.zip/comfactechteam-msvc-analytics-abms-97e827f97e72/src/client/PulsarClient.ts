import Pulsar from 'pulsar-client';
import { Service } from 'typedi';
import { CacheInvalidator, InvalidationEvent } from '../services/cache/CacheInvalidator';
import environment from '../environment';
import { createLogger } from '../utils/logger';

const logger = createLogger('PulsarClient');

@Service()
export class PulsarClient {
  private client: Pulsar.Client | null = null;
  private consumer: Pulsar.Consumer | null = null;
  private isConnected = false;

  constructor(private cacheInvalidator: CacheInvalidator) {}

  async connect(): Promise<void> {
    if (this.isConnected) {
      logger.warn('Pulsar client already connected');
      return;
    }

    try {
      logger.info(`Connecting to Pulsar at ${environment.PULSAR_SERVICE_URL}...`);

      this.client = new Pulsar.Client({
        serviceUrl: environment.PULSAR_SERVICE_URL || '',
      });

      // Subscribe to cache invalidation topics
      await this.subscribeToTopics();

      this.isConnected = true;
      logger.info('Pulsar client connected successfully');
    } catch (error) {
      logger.error('Failed to connect to Pulsar:', error);
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    if (this.consumer) {
      await this.consumer.close();
      this.consumer = null;
      logger.info('Pulsar consumer closed');
    }

    if (this.client) {
      await this.client.close();
      this.client = null;
      logger.info('Pulsar client closed');
    }

    this.isConnected = false;
  }

  private async subscribeToTopics(): Promise<void> {
    if (!this.client) {
      throw new Error('Pulsar client not initialized');
    }

    const topics = this.cacheInvalidator
      .getSupportedEventTypes()
      .map((eventType) => `persistent://public/default/${eventType}`);

    logger.info(`Subscribing to ${topics.length} Pulsar topics for cache invalidation`);

    this.consumer = await this.client.subscribe({
      topics,
      subscription: environment.PULSAR_SUBSCRIPTION_NAME,
      subscriptionType: 'Shared',
    });

    // Start receiving messages
    this.receiveMessages();
  }

  private async receiveMessages(): Promise<void> {
    if (!this.consumer) {
      logger.error('Cannot receive messages: consumer not initialized');
      return;
    }

    logger.info('Started receiving messages from Pulsar');

    while (this.isConnected) {
      try {
        const msg = await this.consumer.receive();

        try {
          // Parse message
          const data = JSON.parse(msg.getData().toString());

          // Extract event type from topic
          const topicName = msg.getTopicName();
          const eventType = topicName.split('/').pop() || '';

          // Create invalidation event
          const event: InvalidationEvent = {
            type: eventType,
            payload: data,
            timestamp: new Date(),
          };

          // Handle cache invalidation
          await this.cacheInvalidator.handleEvent(event);

          // Acknowledge message
          await this.consumer.acknowledge(msg);
        } catch (error) {
          logger.error('Error processing message:', error);
          // Negative acknowledgment - message will be redelivered
          await this.consumer.negativeAcknowledge(msg);
        }
      } catch (error) {
        if (this.isConnected) {
          logger.error('Error receiving message:', error);
          // Wait before retrying
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }
      }
    }
  }
}
