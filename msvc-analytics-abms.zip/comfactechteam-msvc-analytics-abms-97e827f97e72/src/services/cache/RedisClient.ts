import Redis, { RedisOptions } from 'ioredis';
import { Service } from 'typedi';
import environment from '../../environment';
import { createLogger } from '../../utils/logger';

const logger = createLogger('RedisClient');

@Service()
export class RedisClient {
  private client: Redis | null = null;
  private isConnected = false;

  async connect(): Promise<void> {
    if (this.isConnected) {
      logger.warn('Redis client already connected');
      return;
    }

    const options: RedisOptions = {
      host: environment.REDIS_HOST,
      port: environment.REDIS_PORT,
      password: environment.REDIS_PASSWORD || undefined,
      db: environment.REDIS_DB, // Use separate DB index for analytics
      maxRetriesPerRequest: environment.REDIS_MAX_RETRIES,
      connectTimeout: environment.REDIS_CONNECT_TIMEOUT,
      retryStrategy: (times: number) => {
        const delay = Math.min(times * 50, 2000);
        logger.warn(`Redis connection retry #${times}, waiting ${delay}ms`);
        return delay;
      },
      tls: environment.REDIS_TLS ? {} : undefined,
    };

    this.client = new Redis(options);

    this.client.on('connect', () => {
      logger.info(`Redis client connected (DB ${environment.REDIS_DB})`);
      this.isConnected = true;
    });

    this.client.on('error', (error) => {
      logger.error('Redis client error:', error);
    });

    this.client.on('close', () => {
      logger.warn('Redis connection closed');
      this.isConnected = false;
    });

    // Wait for connection
    await new Promise((resolve, reject) => {
      if (!this.client) return reject(new Error('Redis client not initialized'));

      this.client.once('ready', resolve);
      this.client.once('error', reject);
    });
  }

  async disconnect(): Promise<void> {
    if (this.client) {
      await this.client.quit();
      this.client = null;
      this.isConnected = false;
      logger.info('Redis client disconnected');
    }
  }

  async get<T = string>(key: string): Promise<T | null> {
    if (!this.client) throw new Error('Redis client not connected');

    const value = await this.client.get(key);
    if (!value) return null;

    try {
      return JSON.parse(value) as T;
    } catch {
      return value as unknown as T;
    }
  }

  async set(key: string, value: unknown, ttl?: number): Promise<void> {
    if (!this.client) throw new Error('Redis client not connected');

    const serialized = typeof value === 'string' ? value : JSON.stringify(value);

    if (ttl) {
      await this.client.setex(key, ttl, serialized);
    } else {
      await this.client.set(key, serialized);
    }
  }

  async del(key: string | string[]): Promise<number> {
    if (!this.client) throw new Error('Redis client not connected');

    return await this.client.del(...(Array.isArray(key) ? key : [key]));
  }

  async exists(key: string): Promise<boolean> {
    if (!this.client) throw new Error('Redis client not connected');

    const result = await this.client.exists(key);
    return result === 1;
  }

  async keys(pattern: string): Promise<string[]> {
    if (!this.client) throw new Error('Redis client not connected');

    return await this.client.keys(pattern);
  }

  async deletePattern(pattern: string): Promise<number> {
    if (!this.client) throw new Error('Redis client not connected');

    const keys = await this.keys(pattern);
    if (keys.length === 0) return 0;

    return await this.del(keys);
  }

  async ping(): Promise<string> {
    if (!this.client) throw new Error('Redis client not connected');

    return await this.client.ping();
  }

  async getStats(): Promise<{
    connected: boolean;
    dbSize: number;
    info: Record<string, string>;
  }> {
    if (!this.client) throw new Error('Redis client not connected');

    const info = await this.client.info();
    const dbSize = await this.client.dbsize();

    return {
      connected: this.isConnected,
      dbSize,
      info: this.parseRedisInfo(info),
    };
  }

  private parseRedisInfo(info: string): Record<string, string> {
    const result: Record<string, string> = {};
    const lines = info.split('\r\n');

    for (const line of lines) {
      if (line.startsWith('#') || !line.includes(':')) continue;

      const [key, value] = line.split(':');
      result[key.trim()] = value.trim();
    }

    return result;
  }

  getClient(): Redis {
    if (!this.client) throw new Error('Redis client not connected');
    return this.client;
  }
}
