import { Service } from 'typedi';
import { RedisClient } from './RedisClient';
import { CacheKeyBuilder } from './CacheKeyBuilder';
import { createLogger } from '../../utils/logger';
import environment from '../../environment';

const logger = createLogger('CacheManager');

export interface CacheOptions {
  ttl?: number;
  prefix?: string;
}

@Service()
export class CacheManager {
  constructor(
    private redisClient: RedisClient,
    private keyBuilder: CacheKeyBuilder
  ) {}

  /**
   * Get value from cache
   */
  async get<T = unknown>(key: string, options: CacheOptions = {}): Promise<T | null> {
    const fullKey = options.prefix ? `${options.prefix}:${key}` : key;

    try {
      const value = await this.redisClient.get<T>(fullKey);

      if (value !== null) {
        logger.debug(`Cache hit: ${fullKey}`);
      } else {
        logger.debug(`Cache miss: ${fullKey}`);
      }

      return value;
    } catch (error) {
      logger.error(`Cache get error for key ${fullKey}:`, error);
      return null;
    }
  }

  /**
   * Set value in cache
   */
  async set(key: string, value: unknown, options: CacheOptions = {}): Promise<void> {
    const fullKey = options.prefix ? `${options.prefix}:${key}` : key;
    const ttl = options.ttl ?? environment.CACHE_DEFAULT_TTL;

    try {
      await this.redisClient.set(fullKey, value, ttl);
      logger.debug(`Cache set: ${fullKey} (TTL: ${ttl}s)`);
    } catch (error) {
      logger.error(`Cache set error for key ${fullKey}:`, error);
      throw error;
    }
  }

  /**
   * Delete specific key(s) from cache
   */
  async delete(key: string | string[], options: CacheOptions = {}): Promise<number> {
    const keys = Array.isArray(key) ? key : [key];
    const fullKeys = options.prefix ? keys.map((k) => `${options.prefix}:${k}`) : keys;

    try {
      const count = await this.redisClient.del(fullKeys);
      logger.debug(`Cache delete: ${count} key(s) removed`);
      return count;
    } catch (error) {
      logger.error(`Cache delete error:`, error);
      throw error;
    }
  }

  /**
   * Invalidate cache keys matching a pattern
   */
  async invalidatePattern(pattern: string): Promise<number> {
    try {
      const count = await this.redisClient.deletePattern(pattern);
      logger.info(`Cache invalidation: ${count} key(s) deleted for pattern "${pattern}"`);
      return count;
    } catch (error) {
      logger.error(`Cache invalidation error for pattern ${pattern}:`, error);
      throw error;
    }
  }

  /**
   * Get or set pattern - if cache miss, execute fn and cache result
   */
  async getOrSet<T>(key: string, fn: () => Promise<T>, options: CacheOptions = {}): Promise<T> {
    const cached = await this.get<T>(key, options);

    if (cached !== null) {
      return cached;
    }

    logger.debug(`Cache miss for ${key}, executing function`);
    const result = await fn();

    await this.set(key, result, options);

    return result;
  }

  /**
   * Check if key exists in cache
   */
  async exists(key: string, options: CacheOptions = {}): Promise<boolean> {
    const fullKey = options.prefix ? `${options.prefix}:${key}` : key;

    try {
      return await this.redisClient.exists(fullKey);
    } catch (error) {
      logger.error(`Cache exists check error for key ${fullKey}:`, error);
      return false;
    }
  }

  /**
   * Get cache statistics
   */
  async getStats(): Promise<{
    totalKeys: number;
    hitRate?: number;
    memoryUsage?: string;
  }> {
    try {
      const stats = await this.redisClient.getStats();

      return {
        totalKeys: stats.dbSize,
        hitRate: this.calculateHitRate(stats.info),
        memoryUsage: stats.info.used_memory_human,
      };
    } catch (error) {
      logger.error('Failed to get cache stats:', error);
      throw error;
    }
  }

  private calculateHitRate(info: Record<string, string>): number | undefined {
    const hits = parseInt(info.keyspace_hits || '0', 10);
    const misses = parseInt(info.keyspace_misses || '0', 10);

    const total = hits + misses;
    if (total === 0) return undefined;

    return (hits / total) * 100;
  }
}
