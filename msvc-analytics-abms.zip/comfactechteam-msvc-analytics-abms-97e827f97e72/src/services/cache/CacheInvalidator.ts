import { Service } from 'typedi';
import { CacheManager } from './CacheManager';
import { CacheKeyBuilder } from './CacheKeyBuilder';
import { createLogger } from '../../utils/logger';

const logger = createLogger('CacheInvalidator');

// Event to widget mapping (using data source-based widget names)
export const EVENT_INVALIDATION_MAP: Record<string, string[]> = {
  'invoice.exported': [
    'invoices_credits_kpi', // ABMS-4014
    'invoices_count_kpi', // ABMS-4019
    'franchise_invoices_kpi', // ABMS-4024
    'extra_work_invoices_kpi', // ABMS-4025
    'consumable_invoices_kpi', // ABMS-4026
    'service_type_invoices_chart', // ABMS-4028
  ],
  'credit_note.created': [
    'invoices_credits_kpi', // ABMS-4014
  ],
  'job.status_changed': [
    'converted_jobs_kpi', // ABMS-4021
    'budgeted_jobs_kpi', // ABMS-4022
  ],
  'quality_audit.completed': [
    'quality_audits_kpi', // ABMS-4023
    'quality_audits_chart', // ABMS-4032
  ],
  'lead.created': [
    'leads_chart', // ABMS-4029
  ],
  'lead.updated': [
    'leads_chart', // ABMS-4029
  ],
  'case.status_changed': [
    'cases_chart', // ABMS-4031
  ],
  'po.delivered': [
    'consumable_purchases_chart', // ABMS-4030
  ],
  'sales_target.updated': [
    'sales_targets_chart', // ABMS-4027
  ],
  'consumable.purchased': [
    'consumable_purchases_chart', // ABMS-4030
  ],
};

export interface InvalidationEvent {
  type: string;
  payload: Record<string, unknown>;
  timestamp: Date;
}

@Service()
export class CacheInvalidator {
  constructor(
    private cacheManager: CacheManager,
    private keyBuilder: CacheKeyBuilder
  ) {}

  /**
   * Handle event and invalidate affected cache entries
   */
  async handleEvent(event: InvalidationEvent): Promise<void> {
    const { type } = event;

    logger.info(`Processing cache invalidation event: ${type}`);

    const affectedWidgets = EVENT_INVALIDATION_MAP[type];

    if (!affectedWidgets || affectedWidgets.length === 0) {
      logger.debug(`No cache invalidation rules for event type: ${type}`);
      return;
    }

    const results = await Promise.allSettled(
      affectedWidgets.map((widgetName) => this.invalidateWidget(widgetName, type))
    );

    const successCount = results.filter((r) => r.status === 'fulfilled').length;
    const failureCount = results.filter((r) => r.status === 'rejected').length;

    logger.info(
      `Cache invalidation completed for event ${type}: ` +
        `${successCount} succeeded, ${failureCount} failed`
    );
  }

  /**
   * Invalidate all cache entries for a specific widget
   */
  async invalidateWidget(widgetName: string, reason?: string): Promise<number> {
    const pattern = this.keyBuilder.buildInvalidationPattern(widgetName);

    try {
      const count = await this.cacheManager.invalidatePattern(pattern);

      logger.info(
        `Invalidated ${count} cache entries for widget ${widgetName}` +
          (reason ? ` (reason: ${reason})` : '')
      );

      return count;
    } catch (error) {
      logger.error(`Failed to invalidate cache for widget ${widgetName}:`, error);
      throw error;
    }
  }

  /**
   * Invalidate all cache entries for a specific location
   */
  async invalidateLocation(location: string): Promise<number> {
    const pattern = this.keyBuilder.buildLocationPattern(location);

    try {
      const count = await this.cacheManager.invalidatePattern(pattern);

      logger.info(`Invalidated ${count} cache entries for location ${location}`);

      return count;
    } catch (error) {
      logger.error(`Failed to invalidate cache for location ${location}:`, error);
      throw error;
    }
  }

  /**
   * Invalidate all dashboard cache (use with caution!)
   */
  async invalidateAll(): Promise<number> {
    const pattern = this.keyBuilder.buildAllDashboardPattern();

    try {
      const count = await this.cacheManager.invalidatePattern(pattern);

      logger.warn(`Invalidated ALL dashboard cache: ${count} entries deleted`);

      return count;
    } catch (error) {
      logger.error('Failed to invalidate all dashboard cache:', error);
      throw error;
    }
  }

  /**
   * Get list of event types that trigger cache invalidation
   */
  getSupportedEventTypes(): string[] {
    return Object.keys(EVENT_INVALIDATION_MAP);
  }

  /**
   * Get widgets affected by an event type
   */
  getAffectedWidgets(eventType: string): string[] {
    return EVENT_INVALIDATION_MAP[eventType] || [];
  }
}
