import { Service } from 'typedi';
import crypto from 'crypto';

export interface DashboardCacheKeyParams {
  widgetName: string; // Data source-based name (e.g., 'invoices_credits_kpi')
  location?: string;
  dateRange: {
    startDate: string;
    endDate: string;
    dateField: string;
  };
}

@Service()
export class CacheKeyBuilder {
  private readonly PREFIX = 'dashboard';

  /**
   * Build cache key for dashboard widgets
   * Pattern: dashboard:{widget_name}:{location}:{date_range_hash}
   * Example: dashboard:invoices_credits_kpi:LOC001:abc12345
   */
  buildDashboardKey(params: DashboardCacheKeyParams): string {
    const { widgetName, location = 'ALL', dateRange } = params;

    const dateHash = this.hashDateRange(
      dateRange.startDate,
      dateRange.endDate,
      dateRange.dateField
    );

    return `${this.PREFIX}:${widgetName}:${location}:${dateHash}`;
  }

  /**
   * Build pattern for invalidating all cache entries for a specific widget
   * Example: dashboard:invoices_credits_kpi:*
   */
  buildInvalidationPattern(widgetName: string): string {
    return `${this.PREFIX}:${widgetName}:*`;
  }

  /**
   * Build pattern for invalidating all cache entries for a specific location
   */
  buildLocationPattern(location: string): string {
    return `${this.PREFIX}:*:${location}:*`;
  }

  /**
   * Build pattern for invalidating all dashboard cache
   */
  buildAllDashboardPattern(): string {
    return `${this.PREFIX}:*`;
  }

  /**
   * Hash date range parameters to create a compact, consistent key
   */
  private hashDateRange(startDate: string, endDate: string, dateField: string): string {
    const input = `${startDate}:${endDate}:${dateField}`;
    return crypto.createHash('md5').update(input).digest('hex').substring(0, 8);
  }

  /**
   * Build custom key with prefix
   */
  buildCustomKey(parts: string[]): string {
    return parts.join(':');
  }

  /**
   * Parse dashboard key back to components
   */
  parseDashboardKey(key: string): {
    prefix: string;
    widgetName: string;
    location: string;
    dateHash: string;
  } | null {
    const parts = key.split(':');

    if (parts.length !== 4 || parts[0] !== this.PREFIX) {
      return null;
    }

    return {
      prefix: parts[0],
      widgetName: parts[1],
      location: parts[2],
      dateHash: parts[3],
    };
  }
}
