import { Service } from 'typedi';
import { CacheManager } from './cache/CacheManager';
import { CacheKeyBuilder } from './cache/CacheKeyBuilder';
import { getTTL } from '../constants/CacheTTL';
import { createLogger } from '../utils/logger';

const logger = createLogger('BaseWidgetService');

export interface WidgetFilters {
  location?: string;
  dateRange: {
    startDate: string;
    endDate: string;
    dateField: string;
  };
  page?: number;
  pageSize?: number;
  [key: string]: any; // Allow additional filters for specific widgets
}

@Service()
export abstract class BaseWidgetService<T> {
  protected abstract readonly widgetName: string; // e.g., 'invoices_credits_kpi'

  constructor(
    protected cacheManager: CacheManager,
    protected keyBuilder: CacheKeyBuilder
  ) {}

  /**
   * Get widget data with caching
   */
  async getWidgetData(filters: WidgetFilters): Promise<T> {
    // Build cache key using widget name
    const cacheKey = this.keyBuilder.buildDashboardKey({
      widgetName: this.widgetName,
      location: filters.location,
      dateRange: filters.dateRange,
    });

    // Try to get from cache
    const cached = await this.cacheManager.get<T>(cacheKey);

    if (cached) {
      logger.debug(`Cache hit for widget ${this.widgetName}`);
      return cached;
    }

    logger.debug(`Cache miss for widget ${this.widgetName}, fetching from database`);

    // Fetch from database
    const data = await this.fetchFromDatabase(filters);

    // Cache the result
    const ttl = getTTL(this.widgetName);
    await this.cacheManager.set(cacheKey, data, { ttl });

    return data;
  }

  /**
   * Abstract method to fetch data from database
   * Must be implemented by each widget service
   */
  protected abstract fetchFromDatabase(filters: WidgetFilters): Promise<T>;

  /**
   * Invalidate cache for this widget
   */
  async invalidateCache(): Promise<number> {
    const pattern = this.keyBuilder.buildInvalidationPattern(this.widgetName);
    return await this.cacheManager.invalidatePattern(pattern);
  }
}
