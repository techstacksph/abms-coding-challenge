import { Service } from 'typedi';
import { BaseWidgetService, WidgetFilters } from '../BaseWidgetService';
import { KPIData, TrendDirection } from '../../schema/DashboardSchema';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';

const logger = createLogger('InvoicesCreditsKPI');

@Service()
export class InvoicesCreditsKPI extends BaseWidgetService<KPIData> {
  readonly widgetName = 'invoices_credits_kpi';

  protected async fetchFromDatabase(filters: WidgetFilters): Promise<KPIData> {
    logger.info('Fetching total turnover KPI', { filters });

    try {
      // Calculate current period net turnover
      const currentResult = await AppDataSource.query(
        `
        SELECT
          COALESCE(SUM(net_turnover), 0) as total
        FROM mv_invoice_kpis
        WHERE date >= $1::date
          AND date <= $2::date
          AND ($3::varchar IS NULL OR location_id::text = $3)
      `,
        [filters.dateRange.startDate, filters.dateRange.endDate, filters.location || null]
      );

      // Calculate previous period for comparison
      const daysDiff = this.calculateDaysDifference(
        filters.dateRange.startDate,
        filters.dateRange.endDate
      );

      const previousStart = this.subtractDays(filters.dateRange.startDate, daysDiff);
      const previousEnd = this.subtractDays(filters.dateRange.endDate, daysDiff);

      const previousResult = await AppDataSource.query(
        `
        SELECT
          COALESCE(SUM(net_turnover), 0) as total
        FROM mv_invoice_kpis
        WHERE date >= $1::date
          AND date <= $2::date
          AND ($3::varchar IS NULL OR location_id::text = $3)
      `,
        [previousStart, previousEnd, filters.location || null]
      );

      const currentValue = parseFloat(currentResult[0].total);
      const previousValue = parseFloat(previousResult[0].total);

      // Calculate percentage change
      const changePercentage =
        previousValue > 0 ? ((currentValue - previousValue) / previousValue) * 100 : 0;

      // Determine trend
      const trend =
        changePercentage > 0
          ? TrendDirection.UP
          : changePercentage < 0
            ? TrendDirection.DOWN
            : TrendDirection.STABLE;

      logger.info('Total turnover KPI calculated', {
        currentValue,
        previousValue,
        changePercentage,
        trend,
      });

      return {
        widgetName: this.widgetName,
        value: currentValue,
        previousValue,
        changePercentage: Math.round(changePercentage * 100) / 100, // Round to 2 decimals
        trend,
        lastUpdated: new Date(),
      };
    } catch (error) {
      logger.error('Failed to fetch total turnover KPI', { error, filters });
      throw error;
    }
  }

  /**
   * Calculate the number of days between two dates
   */
  private calculateDaysDifference(startDate: string, endDate: string): number {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  }

  /**
   * Subtract days from a date string
   */
  private subtractDays(dateString: string, days: number): string {
    const date = new Date(dateString);
    date.setDate(date.getDate() - days);
    return date.toISOString().split('T')[0];
  }
}
