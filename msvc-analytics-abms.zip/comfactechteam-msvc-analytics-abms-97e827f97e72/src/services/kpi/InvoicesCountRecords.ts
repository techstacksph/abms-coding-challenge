import { Service } from 'typedi';
import { BaseWidgetService, WidgetFilters } from '../BaseWidgetService';
import { InvoiceRecordList, InvoiceRecord } from '../../schema/InvoiceRecordsSchema';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';

const logger = createLogger('InvoicesCountRecords');

interface RecordFilters extends WidgetFilters {
  page?: number;
  pageSize?: number;
}

@Service()
export class InvoicesCountRecords extends BaseWidgetService<InvoiceRecordList> {
  readonly widgetName = 'invoices_count_records';

  protected async fetchFromDatabase(filters: RecordFilters): Promise<InvoiceRecordList> {
    logger.info('Fetching invoice records for count KPI', { filters });

    const page = filters.page || 1;
    const pageSize = filters.pageSize || 10;
    const offset = (page - 1) * pageSize;

    try {
      // Support filtering by either invoice_date or bill_date based on dateField filter
      const dateField = filters.dateRange.dateField === 'bill_date' ? 'bill_date' : 'invoice_date';

      // Get total count from materialized view
      const countResult = await AppDataSource.query(
        `
        SELECT COUNT(*) as total
        FROM mv_invoice_records
        WHERE (${dateField === 'bill_date' ? 'bill_date IS NOT NULL AND bill_date' : 'invoice_date'}) >= $1::date
          AND ${dateField} <= $2::date
          AND ($3::varchar IS NULL OR location_id::text = $3)
          AND record_type = 'invoice'
      `,
        [filters.dateRange.startDate, filters.dateRange.endDate, filters.location || null]
      );

      const total = parseInt(countResult[0].total, 10);

      // Get paginated records from materialized view

      const records = await AppDataSource.query(
        `
        SELECT
          id,
          invoice_number as "invoiceNumber",
          invoice_date as "invoiceDate",
          bill_date as "billDate",
          net_turnover as "netTurnover",
          location_id as "locationId",
          customer_name as "customerName",
          status
        FROM mv_invoice_records
        WHERE (${dateField === 'bill_date' ? 'bill_date IS NOT NULL AND bill_date' : 'invoice_date'}) >= $1::date
          AND ${dateField} <= $2::date
          AND ($3::varchar IS NULL OR location_id::text = $3)
          AND record_type = 'invoice'
        ORDER BY ${dateField} DESC, invoice_number DESC
        LIMIT $4
        OFFSET $5
      `,
        [
          filters.dateRange.startDate,
          filters.dateRange.endDate,
          filters.location || null,
          pageSize,
          offset,
        ]
      );

      logger.info('Invoice records fetched', {
        total,
        page,
        pageSize,
        recordsReturned: records.length,
      });

      return {
        records: records.map(
          (r: Record<string, any>): InvoiceRecord => ({
            id: r.id,
            invoiceNumber: r.invoiceNumber,
            invoiceDate: r.invoiceDate,
            billDate: r.billDate,
            netTurnover: parseFloat(r.netTurnover),
            locationId: r.locationId,
            customerName: r.customerName,
            status: r.status,
          })
        ),
        total,
        page,
        pageSize,
        lastUpdated: new Date(),
      };
    } catch (error) {
      logger.error('Failed to fetch invoice records', { error, filters });
      throw error;
    }
  }
}
