import { Service } from 'typedi';
import { BaseWidgetService, WidgetFilters } from '../BaseWidgetService';
import { KPIData, TrendDirection } from '../../schema/DashboardSchema';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';

const logger = createLogger('InvoicesExtraWorkSoldKPI');

@Service()
export class InvoicesExtraWorkSoldKPI extends BaseWidgetService<KPIData> {
  readonly widgetName = 'invoices_extra_work_sold_kpi';

  protected async fetchFromDatabase(filters: WidgetFilters): Promise<KPIData> {
    logger.info('Fetching extra work sold KPI', { filters });

    try {
      // Support filtering by either invoice_date or bill_date based on dateField filter
      const dateField = filters.dateRange.dateField === 'bill_date' ? 'bill_date' : 'invoice_date';

      // Calculate current period extra work sold from mv_invoice_kpis materialized view
      const currentResult = await AppDataSource.query(
        `
        SELECT
          COALESCE(SUM(additional_work_amount), 0) as total
        FROM mv_invoice_kpis
        WHERE (${dateField === 'bill_date' ? 'bill_date IS NOT NULL AND bill_date' : 'invoice_date'}) >= $1::date
          AND ${dateField} <= $2::date
          AND ($3::uuid IS NULL OR location_id = $3::uuid)
          AND record_type = 'invoice'
      `,
        [filters.dateRange.startDate, filters.dateRange.endDate, filters.location || null]
      );

      // Calculate previous period for comparison
      const daysDiff = this.calculateDaysDifference(
        filters.dateRange.startDate,
        filters.dateRange.endDate
      );

      const previousStart = this.subtractDays(filters.dateRange.startDate, daysDiff);
      const previousEnd = this.subtractDays(filters.dateRange.endDate, daysDiff);

      const previousResult = await AppDataSource.query(
        `
        SELECT
          COALESCE(SUM(additional_work_amount), 0) as total
        FROM mv_invoice_kpis
        WHERE (${dateField === 'bill_date' ? 'bill_date IS NOT NULL AND bill_date' : 'invoice_date'}) >= $1::date
          AND ${dateField} <= $2::date
          AND ($3::uuid IS NULL OR location_id = $3::uuid)
          AND record_type = 'invoice'
      `,
        [previousStart, previousEnd, filters.location || null]
      );

      const currentValue = parseFloat(currentResult[0].total);
      const previousValue = parseFloat(previousResult[0].total);

      // Calculate percentage change
      const changePercentage =
        previousValue > 0 ? ((currentValue - previousValue) / previousValue) * 100 : 0;

      // Determine trend
      const trend =
        changePercentage > 0
          ? TrendDirection.UP
          : changePercentage < 0
            ? TrendDirection.DOWN
            : TrendDirection.STABLE;

      logger.info('Extra work sold KPI calculated', {
        currentValue,
        previousValue,
        changePercentage,
        trend,
      });

      return {
        widgetName: this.widgetName,
        value: currentValue,
        previousValue,
        changePercentage: Math.round(changePercentage * 100) / 100, // Round to 2 decimals
        trend,
        lastUpdated: new Date(),
      };
    } catch (error) {
      logger.error('Failed to fetch extra work sold KPI', { error, filters });
      throw error;
    }
  }

  /**
   * Calculate the number of days between two dates
   */
  private calculateDaysDifference(startDate: string, endDate: string): number {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  }

  /**
   * Subtract days from a date string
   */
  private subtractDays(dateString: string, days: number): string {
    const date = new Date(dateString);
    date.setDate(date.getDate() - days);
    return date.toISOString().split('T')[0];
  }
}
