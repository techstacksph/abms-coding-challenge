import { Queue, Worker } from 'bullmq';
import { AppDataSource } from '../../datasource/datasource';
import { createLogger } from '../../utils/logger';
import { environment } from '../../environment';

const logger = createLogger('MaterializedViewRefresh');

// Redis connection configuration for BullMQ
const redisConnection = {
  host: environment.REDIS_HOST,
  port: environment.REDIS_PORT,
  password: environment.REDIS_PASSWORD,
  db: environment.REDIS_DB,
};

// Create Queue for materialized view refresh jobs
export const mvRefreshQueue = new Queue('materialized-view-refresh', {
  connection: redisConnection,
});

// Configuration for materialized view refresh schedules
export interface MaterializedViewRefreshConfig {
  jobName: string;
  viewName: string;
  cronPattern: string;
  description?: string;
}

export const REFRESH_SCHEDULES: MaterializedViewRefreshConfig[] = [
  // High volatility data - Every 5 minutes
  {
    jobName: 'refresh-job-kpis',
    viewName: 'mv_job_kpis',
    cronPattern: '*/5 * * * *',
    description: 'Job KPIs',
  },
  {
    jobName: 'refresh-job-records',
    viewName: 'mv_job_records',
    cronPattern: '*/5 * * * *',
    description: 'Job Records',
  },
  {
    jobName: 'refresh-leads-chart',
    viewName: 'mv_leads_chart',
    cronPattern: '*/5 * * * *',
    description: 'Leads Chart',
  },
  {
    jobName: 'refresh-lead-records',
    viewName: 'mv_lead_records',
    cronPattern: '*/5 * * * *',
    description: 'Lead Records',
  },
  {
    jobName: 'refresh-cases-chart',
    viewName: 'mv_cases_chart',
    cronPattern: '*/5 * * * *',
    description: 'Cases Chart',
  },

  // Medium volatility data - Every 10 minutes
  {
    jobName: 'refresh-invoice-kpis',
    viewName: 'mv_invoice_kpis',
    cronPattern: '*/10 * * * *',
    description: 'Invoice KPIs',
  },
  {
    jobName: 'refresh-invoice-records',
    viewName: 'mv_invoice_records',
    cronPattern: '*/10 * * * *',
    description: 'Invoice Records',
  },
  {
    jobName: 'refresh-consumable-purchases-chart',
    viewName: 'mv_consumable_purchases_chart',
    cronPattern: '*/10 * * * *',
    description: 'Consumable Purchases',
  },

  // Low volatility data - Every 15 minutes
  {
    jobName: 'refresh-quality-audit-kpis',
    viewName: 'mv_quality_audit_kpis',
    cronPattern: '*/15 * * * *',
    description: 'Quality Audit KPIs',
  },
  {
    jobName: 'refresh-quality-audit-records',
    viewName: 'mv_quality_audit_records',
    cronPattern: '*/15 * * * *',
    description: 'Quality Audit Records',
  },
  {
    jobName: 'refresh-sales-targets-chart',
    viewName: 'mv_sales_targets_chart',
    cronPattern: '*/15 * * * *',
    description: 'Sales Targets Chart',
  },
  {
    jobName: 'refresh-service-type-invoices-chart',
    viewName: 'mv_service_type_invoices_chart',
    cronPattern: '*/15 * * * *',
    description: 'Service Type Invoices',
  },
];

/**
 * Refresh a single materialized view with graceful error handling
 */
async function refreshMaterializedView(viewName: string): Promise<void> {
  try {
    await AppDataSource.query(`REFRESH MATERIALIZED VIEW CONCURRENTLY ${viewName}`);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);

    // Check if error is due to missing view
    if (
      errorMessage.includes('does not exist') ||
      (errorMessage.includes('relation') && errorMessage.includes('does not exist'))
    ) {
      logger.warn(`⚠️  Materialized view ${viewName} does not exist yet - skipping refresh`);
      return; // Don't throw, just skip this refresh
    }

    // Re-throw other errors (like concurrent refresh issues, permissions, etc)
    throw error;
  }
}

/**
 * Setup scheduled jobs for materialized view refreshes
 * @param schedules - Optional custom schedule configuration (defaults to REFRESH_SCHEDULES)
 * @param options - Optional job configuration (removeOnComplete, removeOnFail)
 */
export async function setupMaterializedViewRefresh(
  schedules: MaterializedViewRefreshConfig[] = REFRESH_SCHEDULES,
  options: { removeOnComplete?: number; removeOnFail?: number } = {}
) {
  const { removeOnComplete = 100, removeOnFail = 50 } = options;

  logger.info(`Setting up ${schedules.length} materialized view refresh schedules...`);

  try {
    for (const schedule of schedules) {
      await mvRefreshQueue.add(
        schedule.jobName,
        {},
        {
          repeat: { pattern: schedule.cronPattern },
          jobId: `${schedule.jobName}-schedule`,
          removeOnComplete,
          removeOnFail,
        }
      );

      logger.debug(
        `Scheduled: ${schedule.description || schedule.jobName} (${schedule.cronPattern})`
      );
    }

    logger.info('✅ All materialized view refresh schedules created');
  } catch (error) {
    logger.error('Failed to setup materialized view refresh schedules:', error);
    throw error;
  }
}

/**
 * Start worker to process materialized view refresh jobs
 * @param schedules - Optional custom schedule configuration (defaults to REFRESH_SCHEDULES)
 */
export function startMaterializedViewWorker(
  schedules: MaterializedViewRefreshConfig[] = REFRESH_SCHEDULES
) {
  // Build job name to view name mapping from schedules
  const viewMap: Record<string, string> = schedules.reduce(
    (map, schedule) => {
      map[schedule.jobName] = schedule.viewName;
      return map;
    },
    {} as Record<string, string>
  );

  const worker = new Worker(
    'materialized-view-refresh',
    async (job) => {
      const startTime = Date.now();

      try {
        logger.info(`🔄 Starting ${job.name}...`);

        const viewName = viewMap[job.name];
        if (!viewName) {
          throw new Error(`Unknown job: ${job.name}`);
        }

        // Refresh materialized view (fails gracefully if view doesn't exist)
        await refreshMaterializedView(viewName);

        const duration = Date.now() - startTime;
        logger.info(`✅ ${job.name} completed in ${duration}ms`);
      } catch (error) {
        logger.error(`❌ ${job.name} failed:`, error);
        throw error; // BullMQ will retry based on job options
      }
    },
    {
      connection: redisConnection,
      concurrency: 2, // Process up to 2 refreshes in parallel
      limiter: {
        max: 5, // Max 5 refreshes
        duration: 1000, // per second (to avoid DB overload)
      },
    }
  );

  // Event listeners for monitoring
  worker.on('completed', (job) => {
    logger.info(`✅ Job ${job.id} (${job.name}) completed successfully`);
  });

  worker.on('failed', (job, err) => {
    logger.error(`❌ Job ${job?.id} (${job?.name}) failed: ${err.message}`);
  });

  worker.on('error', (err) => {
    logger.error('Worker error:', err);
  });

  logger.info('🚀 Materialized view refresh worker started');

  return worker;
}

/**
 * Manual refresh function for all materialized views
 * Useful for development, testing, or on-demand refreshes
 * @param schedules - Optional custom schedule configuration (defaults to REFRESH_SCHEDULES)
 */
export async function manualRefreshAllViews(
  schedules: MaterializedViewRefreshConfig[] = REFRESH_SCHEDULES
) {
  logger.info(`🔄 Manually refreshing ${schedules.length} materialized views...`);

  const results = {
    successful: [] as string[],
    failed: [] as { view: string; error: string }[],
  };

  for (const schedule of schedules) {
    try {
      const startTime = Date.now();
      await refreshMaterializedView(schedule.viewName);
      const duration = Date.now() - startTime;
      logger.info(`✅ Refreshed ${schedule.viewName} in ${duration}ms`);
      results.successful.push(schedule.viewName);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error(`❌ Failed to refresh ${schedule.viewName}:`, errorMessage);
      results.failed.push({ view: schedule.viewName, error: errorMessage });
    }
  }

  logger.info(
    `✅ Manual refresh complete: ${results.successful.length} successful, ${results.failed.length} failed`
  );
  return results;
}

/**
 * Get refresh queue statistics
 */
export async function getRefreshQueueStats() {
  const counts = await mvRefreshQueue.getJobCounts();
  const repeatableJobs = await mvRefreshQueue.getRepeatableJobs();

  return {
    jobCounts: counts,
    scheduledJobs: repeatableJobs.length,
    schedules: repeatableJobs.map((job) => ({
      name: job.name,
      pattern: job.pattern,
      next: job.next,
    })),
  };
}
