import { Resolver, Query, Arg, Ctx } from 'type-graphql';
import { Service, Container } from 'typedi';
import { InvoiceRecordList, PaginationInput } from '../schema/InvoiceRecordsSchema';
import { DashboardFilterInput } from '../schema/DashboardSchema';
import { createLogger } from '../utils/logger';
import { SchemaPrefix } from '../constants/SchemaConstants';
import { InvoicesCountRecords } from '../services/kpi/InvoicesCountRecords';
import { InvoicesCreditsRecords } from '../services/kpi/InvoicesCreditsRecords';

const logger = createLogger('InvoiceRecordsResolver');

interface Context {
  req: Express.Request;
}

@Service()
@Resolver()
export class InvoiceRecordsResolver {
  /**
   * ABMS-4019: Invoice Records List (for Turnover Count KPI)
   * Returns paginated list of invoices
   */
  @Query(() => InvoiceRecordList, { name: `${SchemaPrefix}GetInvoicesCountRecords` })
  async getInvoicesCountRecords(
    @Arg('filters') filters: DashboardFilterInput,
    @Arg('pagination', { nullable: true }) pagination: PaginationInput,
    @Ctx() _ctx: Context
  ): Promise<InvoiceRecordList> {
    logger.info('Fetching invoice records for count KPI', { filters, pagination });
    const service = Container.get(InvoicesCountRecords);
    return await service.getWidgetData({
      location: filters.location,
      dateRange: {
        startDate: filters.dateRange.startDate,
        endDate: filters.dateRange.endDate,
        dateField: filters.dateField,
      },
      page: pagination?.page,
      pageSize: pagination?.pageSize,
    });
  }

  /**
   * ABMS-4014: Invoice/Credit Records List (for Total Turnover KPI)
   * Returns paginated list of invoices and credits
   */
  @Query(() => InvoiceRecordList, { name: `${SchemaPrefix}GetInvoicesCreditsRecords` })
  async getInvoicesCreditsRecords(
    @Arg('filters') filters: DashboardFilterInput,
    @Arg('pagination', { nullable: true }) pagination: PaginationInput,
    @Ctx() _ctx: Context
  ): Promise<InvoiceRecordList> {
    logger.info('Fetching invoice/credit records for total turnover KPI', { filters, pagination });
    const service = Container.get(InvoicesCreditsRecords);
    return await service.getWidgetData({
      location: filters.location,
      dateRange: {
        startDate: filters.dateRange.startDate,
        endDate: filters.dateRange.endDate,
        dateField: filters.dateField,
      },
      page: pagination?.page,
      pageSize: pagination?.pageSize,
    });
  }
}
