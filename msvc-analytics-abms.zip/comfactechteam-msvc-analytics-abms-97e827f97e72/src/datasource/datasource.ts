import { DataSource } from 'typeorm';
import { createLogger } from '../utils/logger';
import { AppDataSource as OrmConfigDataSource } from '../../ormconfig';

const logger = createLogger('DataSource');

// Import DataSource from ormconfig.ts for consistency with msvc-abms
export const AppDataSource = OrmConfigDataSource;

export async function initializeDatabase(): Promise<DataSource> {
  try {
    logger.info('Initializing dedicated analytics database connection...');

    if (!AppDataSource.isInitialized) {
      await AppDataSource.initialize();
      logger.info('Analytics database connection initialized successfully');

      // Log database info
      const result = await AppDataSource.query('SELECT current_database(), current_user');
      logger.info(
        `Connected to database: ${result[0].current_database} as ${result[0].current_user}`
      );
    }

    return AppDataSource;
  } catch (error) {
    logger.error('Failed to initialize analytics database:', error);
    throw error;
  }
}

export async function closeDatabase(): Promise<void> {
  if (AppDataSource.isInitialized) {
    await AppDataSource.destroy();
    logger.info('Database connection closed');
  }
}

// Export as default for TypeORM CLI
export default AppDataSource;
