# Database Migrations

**⚠️ IMPORTANT: This service does NOT run database migrations!**

**msvc-analytics-abms has READ-ONLY access to PostgreSQL.**

## Migration Strategy

Since msvc-analytics-abms and msvc-abms are maintained by the same team and share the same `msvc_abms` database:

- **All database migrations** (base tables, materialized views, indexes) are managed via **msvc-abms**
- **msvc-analytics-abms** has **read-only access** (SELECT queries only)
- **No migrations run from this service** - no INSERT, UPDATE, DELETE, schema changes
- Entity models in `src/model-dictionary/` are copied from msvc-abms for TypeORM mapping only
- **Only database writes**: Redis (for caching)

## Creating Materialized Views for Analytics

All materialized views for analytics dashboards should be created via **msvc-abms migrations**.

**Example migration in msvc-abms:**

```typescript
// msvc-abms/src/datasource/migrations/1234567890-CreateAnalyticsMaterializedViews.ts

export class CreateAnalyticsMaterializedViews1234567890 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create materialized view for invoice KPIs
    await queryRunner.query(`
      CREATE MATERIALIZED VIEW mv_invoice_kpis AS
      SELECT
        location_id,
        DATE(invoice_date) as date,
        SUM(CASE WHEN invoice_type = 'invoice' THEN grand_total ELSE 0 END) as invoice_total,
        SUM(CASE WHEN invoice_type = 'credit' THEN grand_total ELSE 0 END) as credit_total,
        SUM(grand_total) as net_turnover,
        COUNT(CASE WHEN invoice_type = 'invoice' THEN 1 END) as invoice_count
      FROM invoices
      WHERE deleted_at IS NULL
      GROUP BY location_id, DATE(invoice_date)
      WITH DATA;
    `);

    // Create indexes
    await queryRunner.query(`
      CREATE UNIQUE INDEX idx_mv_invoice_kpis_location_date
      ON mv_invoice_kpis(location_id, date);
    `);

    // Set up pg_cron refresh schedule (every 10 minutes)
    await queryRunner.query(`
      SELECT cron.schedule('refresh-invoice-kpis', '*/10 * * * *',
        'REFRESH MATERIALIZED VIEW CONCURRENTLY mv_invoice_kpis;');
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`SELECT cron.unschedule('refresh-invoice-kpis');`);
    await queryRunner.query(`DROP MATERIALIZED VIEW IF EXISTS mv_invoice_kpis;`);
  }
}
```

## Old Migration Documentation (For Reference Only)

The content below is kept for reference but **should NOT be used** for this service.

---

## ~~Migration Workflow~~ (NOT APPLICABLE)

### 1. Create Entity Models

Define your entity models in `src/model-dictionary/`:

```typescript
// src/model-dictionary/Invoice.ts
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('invoices')
export class Invoice {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'timestamp' })
  invoice_date: Date;

  @Column({ type: 'decimal', precision: 12, scale: 2 })
  grand_total: number;

  // ... more columns
}
```

### 2. Generate Migration from Entity Changes

TypeORM will automatically compare your entity definitions with the current database schema and generate a migration file:

```bash
# Generate migration based on entity changes
yarn migration:generate src/datasource/migrations/InitialSchema

# This creates: src/datasource/migrations/{timestamp}-InitialSchema.ts
```

**Example generated migration:**

```typescript
import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitialSchema1234567890123 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE "invoices" ...`);
    await queryRunner.query(`CREATE INDEX "idx_invoice_date" ...`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "invoices"`);
  }
}
```

### 3. Create Empty Migration (for custom operations)

For custom SQL that doesn't relate to entity changes (e.g., indexes, views, functions):

```bash
yarn migration:create src/datasource/migrations/AddAnalyticsIndexes
```

Then manually write the up/down logic:

```typescript
export class AddAnalyticsIndexes1234567890123 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE INDEX idx_invoice_date_location
            ON invoices(invoice_date, location_id);
        `);

    await queryRunner.query(`
            CREATE MATERIALIZED VIEW mv_daily_turnover AS
            SELECT DATE(invoice_date) as date,
                   location_id,
                   SUM(grand_total) as total
            FROM invoices
            GROUP BY DATE(invoice_date), location_id;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP MATERIALIZED VIEW mv_daily_turnover;`);
    await queryRunner.query(`DROP INDEX idx_invoice_date_location;`);
  }
}
```

### 4. Run Migrations

Apply pending migrations to the database:

```bash
# Run all pending migrations
yarn migration:run

# Check migration status
yarn migration:show

# Revert last migration
yarn migration:revert
```

### 5. Production Deployment

**Before deploying:**

1. Build the project: `yarn build`
2. Run migrations: `yarn migration:run`
3. Start the service: `yarn start`

**CI/CD Pipeline:**

```bash
# In deployment script
yarn build
NODE_ENV=production yarn migration:run
NODE_ENV=production yarn start
```

## Available Commands

```bash
# Generate migration from entity changes
yarn migration:generate src/datasource/migrations/MigrationName

# Create empty migration file
yarn migration:create src/datasource/migrations/MigrationName

# Run pending migrations
yarn migration:run

# Revert last migration
yarn migration:revert

# Show migration status
yarn migration:show

# Sync schema (DANGEROUS - only for dev)
yarn schema:sync

# Drop entire schema (DANGEROUS)
yarn schema:drop
```

## Two Database Strategies

### Option A: Dedicated Analytics Database (Recommended)

When using a dedicated `msvc_analytics_abms` database:

1. **Copy entity models** from `msvc-abms` to `src/model-dictionary/`
2. **Generate initial migration**: `yarn migration:generate src/datasource/migrations/InitialSchema`
3. **Run migration**: `yarn migration:run`
4. **Setup logical replication** from `msvc_abms` to sync data
5. **Add analytics-specific indexes/views** via custom migrations

**Benefits:**

- Query isolation (analytics don't impact production)
- Can add analytics-specific indexes and materialized views
- Independent schema evolution

### Option B: Direct Access to msvc_abms

When connecting directly to the `msvc_abms` database:

1. **Copy entity models** from `msvc-abms` (for TypeORM mapping only)
2. **DO NOT run migrations** (schema is managed by msvc-abms)
3. **Read-only access** via `analytics_reader` user
4. **No schema changes allowed**

**Important:** Set `migrationsRun: false` and don't run `yarn migration:run`

## Migration Best Practices

### 1. Always Test Migrations

```bash
# Test migration in development
yarn migration:run

# Verify it works
yarn migration:show

# Test rollback
yarn migration:revert

# Re-apply
yarn migration:run
```

### 2. Write Reversible Migrations

Always implement both `up()` and `down()` methods:

```typescript
export class AddColumnExample implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE invoices ADD COLUMN notes TEXT`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE invoices DROP COLUMN notes`);
  }
}
```

### 3. Use Transactions

Migrations run in transactions by default. For operations that can't run in transactions:

```typescript
export class CreateIndexConcurrently implements MigrationInterface {
  // Disable transaction wrapper
  transaction = false;

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE INDEX CONCURRENTLY idx_invoice_date
            ON invoices(invoice_date)
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX CONCURRENTLY idx_invoice_date`);
  }
}
```

### 4. Add Indexes for Analytics Queries

```typescript
export class AddAnalyticsIndexes implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Invoice analytics
    await queryRunner.query(`
            CREATE INDEX idx_invoice_date_location
            ON invoices(invoice_date, location_id);
        `);

    await queryRunner.query(`
            CREATE INDEX idx_invoice_account_code
            ON invoices(account_code)
            WHERE account_code IN ('2001', '2003', '207', '208');
        `);

    // Job analytics
    await queryRunner.query(`
            CREATE INDEX idx_job_start_date_status
            ON jobs(start_date, status);
        `);

    // Quality audit analytics
    await queryRunner.query(`
            CREATE INDEX idx_audit_completed_date
            ON quality_audits(completed_date);
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX idx_invoice_date_location`);
    await queryRunner.query(`DROP INDEX idx_invoice_account_code`);
    await queryRunner.query(`DROP INDEX idx_job_start_date_status`);
    await queryRunner.query(`DROP INDEX idx_audit_completed_date`);
  }
}
```

### 5. Create Materialized Views

```typescript
export class CreateMaterializedViews implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Daily turnover aggregation
    await queryRunner.query(`
            CREATE MATERIALIZED VIEW mv_daily_turnover AS
            SELECT
                DATE(invoice_date) as date,
                location_id,
                SUM(grand_total) as total_turnover,
                COUNT(*) as invoice_count
            FROM invoices
            GROUP BY DATE(invoice_date), location_id;
        `);

    await queryRunner.query(`
            CREATE INDEX ON mv_daily_turnover(date, location_id);
        `);

    // Monthly job conversions
    await queryRunner.query(`
            CREATE MATERIALIZED VIEW mv_monthly_job_conversions AS
            SELECT
                DATE_TRUNC('month', start_date) as month,
                location_id,
                COUNT(*) FILTER (WHERE status = 'converted') as converted_count,
                COUNT(*) as total_count
            FROM jobs
            GROUP BY DATE_TRUNC('month', start_date), location_id;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP MATERIALIZED VIEW mv_monthly_job_conversions`);
    await queryRunner.query(`DROP MATERIALIZED VIEW mv_daily_turnover`);
  }
}
```

### 6. Keep Migrations Small and Focused

❌ **Bad: One giant migration**

```typescript
export class Everything implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Creates 20 tables, 50 indexes, 10 views...
  }
}
```

✅ **Good: Multiple focused migrations**

```typescript
// 1_InitialSchema.ts - Core tables
// 2_AddIndexes.ts - Performance indexes
// 3_CreateMaterializedViews.ts - Aggregated views
// 4_AddAnalyticsOptimizations.ts - Analytics-specific improvements
```

## Troubleshooting

### Migration Already Exists

```bash
# Error: Migration "InitialSchema1234567890123" already exists
# Solution: Check existing migrations
ls src/datasource/migrations/

# Show applied migrations
yarn migration:show
```

### No Changes Detected

```bash
# Error: No changes in database schema were found
# Reasons:
# 1. Entities already match database schema
# 2. Entity decorators not properly configured
# 3. TypeORM can't find entity files

# Solution: Verify entity configuration in datasource.ts
```

### Migration Fails

```bash
# Error: Migration failed with error...
# Solution: Revert and fix
yarn migration:revert
# Fix the migration file
yarn migration:run
```

### Can't Connect to Database

```bash
# Error: Connection refused
# Solution: Check .env configuration
cat .env | grep DB_

# Verify database is running
docker ps | grep postgres
```

## Example: Complete Migration Setup

```bash
# 1. Copy entities from msvc-abms
cp -r ../msvc-abms/src/model-dictionary/Invoice.ts src/model-dictionary/
cp -r ../msvc-abms/src/model-dictionary/Job.ts src/model-dictionary/
# ... copy other entities

# 2. Generate initial migration
yarn migration:generate src/datasource/migrations/InitialSchema

# 3. Review generated migration
cat src/datasource/migrations/*-InitialSchema.ts

# 4. Run migration
yarn migration:run

# 5. Verify tables created
docker exec postgres-analytics psql -U analytics_user msvc_analytics_abms -c "\dt"

# 6. Create analytics-specific optimizations
yarn migration:create src/datasource/migrations/AddAnalyticsIndexes

# 7. Add custom indexes and views to the migration file

# 8. Run new migration
yarn migration:run

# 9. Check migration history
yarn migration:show
```

## Migration Naming Convention

Use descriptive names with action verbs:

- `InitialSchema` - Initial database setup
- `AddIndexes` - Add performance indexes
- `CreateMaterializedViews` - Create aggregated views
- `AddInvoiceStatusColumn` - Add new column
- `RemoveDeprecatedFields` - Remove old columns
- `UpdateAccountCodes` - Data migration
- `OptimizeAnalyticsQueries` - Performance improvements

## Notes

- Migrations are stored in the `analytics_migrations` table
- Each migration has a timestamp prefix (e.g., `1234567890123-InitialSchema.ts`)
- Migrations run in chronological order
- Never edit a migration that has been run in production
- Create a new migration for changes instead
