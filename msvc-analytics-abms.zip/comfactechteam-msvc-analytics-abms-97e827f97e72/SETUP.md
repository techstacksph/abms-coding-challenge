# msvc-analytics-abms Setup Guide

Complete setup instructions for the Analytics & Dashboard Microservice.

## Architecture Overview

This microservice has its **own dedicated PostgreSQL database** (`msvc_analytics_abms`) that receives data from the core database (`msvc_abms`) via **PostgreSQL Logical Replication**.

```
msvc_abms (Core DB)  ──[Logical Replication]──▶  msvc_analytics_abms (Analytics DB)
     Port 5432                                           Port 5433
```

## Prerequisites

- Docker & Docker Compose
- Node.js 20.13.1+
- Yarn package manager
- Access to `msvc-abms` database (for replication setup)

## Quick Start (Development)

### 1. Clone and Install

```bash
cd /Users/ctouser/CTO/msvc-analytics-abms
yarn install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Start Infrastructure

```bash
# Create Docker network (if not exists)
docker network create local_bridge

# IMPORTANT: Start shared Redis from msvc-abms (if not already running)
cd /Users/ctouser/CTO/msvc-abms
docker-compose -f docker-compose-redis.yml up -d
cd -

# Start analytics-specific database
docker-compose -f docker-compose-postgres.yml up -d

# Wait for database to be ready
docker logs postgres-analytics -f
```

**Infrastructure Overview:**
- **PostgreSQL**: Dedicated `msvc_analytics_abms` database (port 5433)
- **Redis**: SHARED with msvc-abms (port 6379, DB index 1)
- **Pulsar**: SHARED event bus (port 6650)

### 4. Setup Database Schema

**Choose based on your database strategy:**

**For Option A (Dedicated Analytics Database):**

**4a. Using TypeORM Migrations (Recommended)**
```bash
# 1. Copy entity models from msvc-abms
cp -r ../msvc-abms/src/model-dictionary/*.ts ./src/model-dictionary/

# 2. Generate initial migration from entities
yarn migration:generate src/datasource/migrations/InitialSchema

# 3. Review the generated migration
cat src/datasource/migrations/*-InitialSchema.ts

# 4. Run migration to create tables
yarn migration:run

# 5. Verify tables created
docker exec postgres-analytics psql -U analytics_user msvc_analytics_abms -c "\dt"

# 6. Create analytics-specific indexes and views
yarn migration:create src/datasource/migrations/AddAnalyticsOptimizations

# Edit the migration file to add indexes, materialized views, etc.

# 7. Run analytics optimizations
yarn migration:run
```

**4b. Or Copy Schema from msvc_abms**
```bash
# Export schema from core database
pg_dump -h localhost -p 5432 -U abms_user -s msvc_abms > schema.sql

# Import schema to analytics database
psql -h localhost -p 5433 -U analytics_user msvc_analytics_abms < schema.sql
```

**For Option B (Direct Access):**
- No schema setup needed - you're using the existing `msvc_abms` database
- Just copy entity models for TypeORM mapping: `cp -r ../msvc-abms/src/model-dictionary/*.ts ./src/model-dictionary/`
- **Do NOT run migrations** (schema is managed by msvc-abms)

### 5. Setup Logical Replication

**Step A: On Source Database (msvc_abms)**
```bash
# Connect to core database
docker exec -it postgres-abms psql -U abms_user msvc_abms

# Run replication setup
\i /path/to/msvc-analytics-abms/scripts/setup-logical-replication.sql
```

**Step B: On Target Database (msvc_analytics_abms)**
```bash
# Connect to analytics database
docker exec -it postgres-analytics psql -U analytics_user msvc_analytics_abms

# Create subscription (after tables exist!)
\i /path/to/msvc-analytics-abms/scripts/setup-subscription.sql
```

**Step C: Verify Replication**
```sql
-- On analytics database
SELECT * FROM pg_subscription;
SELECT * FROM pg_stat_subscription;

-- Check if data is syncing
SELECT COUNT(*) FROM invoices;  -- Should match core DB
```

### 6. Start Development Server

```bash
yarn dev
```

Service will be available at:
- **GraphQL (Direct):** http://localhost:4040/graphql
- **Health:** http://localhost:4040/health
- **Cache Stats:** http://localhost:4040/cache/stats

### 7. Integrate with Apollo Gateway (Recommended)

The analytics service is an Apollo Federation subgraph and should be accessed through the gateway in production.

**Setup Gateway Integration:**

```bash
# 1. Navigate to gateway repository
cd /Users/ctouser/CTO/msvc-gw-apollo-abms

# 2. Verify analytics service is in APOLLO_SERVICE_LIST
cat .env | grep APOLLO_SERVICE_LIST
# Should include: {"name":"msvc-analytics-abms","url":"http://localhost:4040/graphql"}

# 3. Start the gateway
yarn dev

# 4. Access analytics queries through the gateway
# Gateway URL: http://localhost:3001/
```

**Gateway Configuration (`.env`):**
```bash
APOLLO_SERVICE_LIST=[
  {"name":"msvc-abms","url":"http://localhost:8083"},
  {"name":"msvc-analytics-abms","url":"http://localhost:4040/graphql"}
]
```

**Docker Configuration (`docker-compose.dev.yml`):**
```yaml
APOLLO_SERVICE_LIST: '[
  {"name":"msvc-abms","url":"http://msvc-cto-bo:8083"},
  {"name":"msvc-analytics-abms","url":"http://msvc-analytics-abms-dev:4040/graphql"}
]'
```

**Benefits of using the gateway:**
- ✅ Unified authentication/authorization
- ✅ Cross-service query composition
- ✅ Centralized monitoring and logging
- ✅ Rate limiting and security policies
- ✅ Schema stitching across services

## Database Setup Details

### Dedicated Analytics Database

**Why separate database?**
- ✅ Query isolation (analytics don't impact production)
- ✅ Independent scaling
- ✅ Optimized indexes for analytics
- ✅ Materialized views for pre-aggregation
- ✅ Clear security boundary

**Connection Details:**
- Host: localhost (or `postgres-analytics` in Docker)
- Port: 5433 (different from core DB's 5432)
- Database: `msvc_analytics_abms`
- User: `analytics_user`

### Data Synchronization Options

#### Option 1: PostgreSQL Logical Replication (Recommended)

**Pros:**
- Real-time sync (milliseconds lag)
- No custom code required
- Built-in PostgreSQL feature
- Automatic conflict resolution

**Cons:**
- Requires PostgreSQL 10+
- Network connectivity required
- Initial setup complexity

**Setup Steps:**
1. Configure source DB: `wal_level=logical`
2. Create publication on source
3. Create subscription on target
4. Monitor replication lag

#### Option 2: Change Data Capture (CDC)

**Pros:**
- Language/platform agnostic
- Can transform data during sync
- Works with any source database

**Cons:**
- Requires Debezium/CDC tool
- More infrastructure
- Higher latency

**Tools:**
- Debezium + Kafka/Pulsar
- AWS DMS
- Google Cloud Datastream

#### Option 3: Scheduled ETL

**Pros:**
- Simple to implement
- Works with any database
- Easy to debug

**Cons:**
- Higher latency (hourly/daily)
- Potential data staleness
- Manual orchestration

**Implementation:**
```typescript
// src/jobs/DataSyncJob.ts
import { CronJob } from 'cron';

export class DataSyncJob {
  start() {
    new CronJob('0 * * * *', async () => {  // Every hour
      await this.syncInvoices();
      await this.syncJobs();
      // ... sync other tables
    }).start();
  }
}
```

## Docker Compose Setup

### Full Stack (Everything)

```bash
yarn docker:dev:full
```

This starts:
- Analytics service (port 4040)
- PostgreSQL analytics DB (port 5433)
- Redis cache (port 6380)
- Pulsar event bus (port 6650) - shared

### Infrastructure Only

```bash
docker-compose -f docker-compose-postgres.yml -f docker-compose-redis.yml -f docker-compose-pulsar.yml up -d
```

Then run service locally:
```bash
yarn dev
```

### Individual Services

```bash
# Just database
docker-compose -f docker-compose-postgres.yml up -d

# Just Redis
docker-compose -f docker-compose-redis.yml up -d

# Just Pulsar
docker-compose -f docker-compose-pulsar.yml up -d
```

## Verifying Setup

### 1. Check Database Connection

```bash
docker exec -it postgres-analytics psql -U analytics_user msvc_analytics_abms

# Run test query
SELECT current_database(), current_user, version();
```

### 2. Check Redis Connection

```bash
# Connect to shared Redis instance
docker exec -it redis redis-cli

# Switch to analytics database (DB 1)
SELECT 1

# Run test commands
PING
INFO stats
KEYS dashboard:*
```

### 3. Check Service Health

```bash
curl http://localhost:4040/health
curl http://localhost:4040/ready
curl http://localhost:4040/cache/stats
```

### 4. Check GraphQL

Open http://localhost:4040/graphql in browser

Test query:
```graphql
query {
  __schema {
    queryType {
      name
    }
  }
}
```

### 5. Check Replication Status

```bash
# On analytics database
docker exec -it postgres-analytics psql -U analytics_user msvc_analytics_abms

# Check subscription status
SELECT
  subname,
  pid,
  received_lsn,
  latest_end_lsn,
  last_msg_send_time,
  last_msg_receipt_time
FROM pg_stat_subscription;

# Check replication lag
SELECT
  slot_name,
  active,
  pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)) AS lag
FROM pg_replication_slots
WHERE slot_name = 'analytics_slot';
```

## Performance Optimization

### 1. Create Analytics Indexes

```sql
-- Run on analytics database
\i /path/to/scripts/create-indexes.sql
```

See Architecture Diagram section 6.5 for index DDL.

### 2. Create Materialized Views

```sql
-- Daily turnover aggregation
CREATE MATERIALIZED VIEW mv_daily_turnover AS
SELECT
  DATE(invoice_date) as date,
  location_id,
  SUM(grand_total) as total_turnover,
  COUNT(*) as invoice_count
FROM invoices
GROUP BY DATE(invoice_date), location_id;

CREATE INDEX ON mv_daily_turnover(date, location_id);

-- Refresh schedule (via cron job)
-- REFRESH MATERIALIZED VIEW CONCURRENTLY mv_daily_turnover;
```

### 3. Configure Connection Pool

Edit `src/datasource/datasource.ts`:
```typescript
extra: {
  max: 50,                      // Max connections
  min: 10,                      // Min connections
  connectionTimeoutMillis: 10000,
  idleTimeoutMillis: 30000,
  statement_timeout: 30000,     // 30s query timeout
}
```

## Monitoring

### Database Metrics

```sql
-- Connection count
SELECT count(*) FROM pg_stat_activity
WHERE datname = 'msvc_analytics_abms';

-- Top slow queries
SELECT
  query,
  mean_exec_time,
  calls,
  total_exec_time
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 10;

-- Table sizes
SELECT
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

### Redis Metrics

```bash
# View stats for all databases
docker exec redis redis-cli INFO stats

# View keyspace info (shows which DBs are in use)
docker exec redis redis-cli INFO keyspace

# Check analytics DB specifically (DB 1)
docker exec redis redis-cli --eval "redis.call('SELECT', 1); return redis.call('DBSIZE')"
```

Key metrics:
- `keyspace_hits` / `keyspace_misses` - Cache hit rate
- `used_memory_human` - Memory usage
- `connected_clients` - Active connections
- `db1:keys` - Number of keys in analytics database

### Service Logs

```bash
# Docker logs
docker logs msvc-analytics-abms-dev -f

# Local logs (if running with yarn dev)
# Check console output
```

## Troubleshooting

### Database Won't Start

```bash
# Check logs
docker logs postgres-analytics

# Check if port is in use
lsof -i :5433

# Reset database (⚠️ deletes all data)
docker-compose -f docker-compose-postgres.yml down -v
docker-compose -f docker-compose-postgres.yml up -d
```

### Replication Not Working

**Check 1: Source database configuration**
```sql
-- On msvc_abms database
SHOW wal_level;  -- Must be 'logical'
SHOW max_replication_slots;  -- Must be > 0
```

**Check 2: Publication exists**
```sql
-- On msvc_abms database
SELECT * FROM pg_publication WHERE pubname = 'analytics_pub';
```

**Check 3: Network connectivity**
```bash
# From analytics container, try to connect to core DB
docker exec -it postgres-analytics psql -h postgres-abms -U replication_user msvc_abms
```

**Check 4: Subscription status**
```sql
-- On analytics database
SELECT * FROM pg_stat_subscription;
-- Check for errors in last_error field
```

### Redis Connection Issues

```bash
# Test connection to shared Redis
docker exec redis redis-cli PING

# Check if Redis is running
docker ps | grep redis

# Check analytics DB (DB 1)
docker exec redis redis-cli SELECT 1
docker exec redis redis-cli DBSIZE

# Restart Redis (CAUTION: affects all microservices)
docker restart redis
```

**Note**: Redis is shared with msvc-abms. Restarting it affects all services.

### Service Won't Start

```bash
# Check dependencies
yarn install

# Check TypeScript compilation
yarn build

# Check environment variables
cat .env

# Run with verbose logging
DEBUG=* yarn dev
```

## Production Deployment

### 1. Environment Variables

```bash
# Production .env
NODE_ENV=production
PORT=4040

# Dedicated Analytics Database
DB_HOST=prod-postgres-analytics.example.com
DB_PORT=5432
DB_NAME=msvc_analytics_abms
DB_USER=analytics_user
DB_PASSWORD=<strong-password>

# Shared Redis (same as msvc-abms)
REDIS_HOST=prod-redis.example.com
REDIS_PORT=6379
REDIS_PASSWORD=<strong-password>
REDIS_DB=1  # Analytics uses DB 1
REDIS_TLS=true

# Shared Pulsar
PULSAR_SERVICE_URL=pulsar://prod-pulsar.example.com:6650
```

### 2. Build Production Image

```bash
docker build -t msvc-analytics-abms:1.0.0 .
docker tag msvc-analytics-abms:1.0.0 registry.example.com/msvc-analytics-abms:1.0.0
docker push registry.example.com/msvc-analytics-abms:1.0.0
```

### 3. Deploy

```bash
docker-compose -f docker-compose.yml up -d
```

### 4. Health Checks

Configure health checks in orchestration platform:
- **Liveness:** `GET /health` (should return 200)
- **Readiness:** `GET /ready` (checks Redis connectivity)

## Next Steps

1. ✅ Implement KPI services (ABMS-4014 to ABMS-4026)
2. ✅ Implement Chart services (ABMS-4027 to ABMS-4032)
3. ✅ Create database migrations
4. ✅ Setup monitoring and alerting
5. ✅ Performance testing
6. ✅ Security hardening

## Support

For issues or questions, contact the ABMS development team.
