# CLAUDE.md - msvc-analytics-abms Project Guide

## Project Overview

**msvc-analytics-abms** - Analytics and Dashboard Microservice for the ABMS (At Your Request) ecosystem. This service provides high-performance dashboard widgets with Redis caching and event-driven cache invalidation.

**Purpose:** Implement 14 dashboard widgets (8 KPIs + 6 Charts) covering tickets ABMS-4014 to ABMS-4032.

## Technology Stack

- **Runtime:** Node.js 20.13.1+
- **Language:** TypeScript 5.2.2
- **API:** GraphQL (Apollo Server 4.9.3, Type-GraphQL 2.0)
- **Federation:** Apollo Federation (@apollo/subgraph)
- **Cache:** Redis 7 (ioredis 5.3.2)
- **Database:** PostgreSQL 15 (TypeORM 0.3.17, **read-only access**)
- **Event Bus:** Apache Pulsar 3.0 (pulsar-client 1.9.0)
- **Queue:** BullMQ 4.12
- **DI:** TypeDI 0.10.0
- **Logging:** Winston 3.10.0

## Key Concepts

### 1. Shared Database Access

**IMPORTANT:** This service shares the same PostgreSQL database with msvc-abms:
- Database: `msvc_abms` (shared with msvc-abms, same team maintains both services)
- Uses same database user: `abms_user`
- **STRICTLY READ-ONLY**: Only SELECT queries allowed - no INSERT, UPDATE, DELETE
- **No schema migrations** - schema managed exclusively by msvc-abms
- **No schema sync** - TypeORM configured for read-only access
- Direct access to all ABMS tables and materialized views
- **Only database writes**: Redis (for caching)

### 2. Redis Caching Strategy

**Cache-Aside Pattern:**
1. Check cache first
2. On miss, query database
3. Store result in cache with TTL
4. Return data

**Cache Key Pattern:**
```
dashboard:{ticket}:{location}:{date_range_hash}
```

**TTL Configuration:**
- Invoice KPIs: 10 minutes
- Job KPIs: 5 minutes
- Audit KPIs: 15 minutes
- Charts: 5-15 minutes (see `src/constants/CacheTTL.ts`)

### 3. Event-Driven Cache Invalidation

**How it works:**
1. Core services (msvc-abms) publish events to Pulsar when data changes
2. This service subscribes to relevant events
3. On event receipt, invalidate affected cache entries
4. Next request will fetch fresh data from database

**Event Mapping:** See `src/services/cache/CacheInvalidator.ts` for `EVENT_INVALIDATION_MAP`

### 4. GraphQL Federation

This service is an **Apollo Federation subgraph**:
- Integrates with `msvc-gw-apollo-abms` (API Gateway)
- Provides `analytics` subgraph
- Uses `@apollo/subgraph` for federation support

## Project Structure

```
src/
├── server.ts                    # Application entry point
├── environment.ts               # Environment configuration
│
├── resolver/                    # GraphQL resolvers
│   └── DashboardResolver.ts     # Main dashboard queries
│
├── schema/                      # GraphQL type definitions
│   └── DashboardSchema.ts       # Dashboard types & inputs
│
├── services/                    # Business logic layer
│   ├── cache/                   # Redis cache layer
│   │   ├── RedisClient.ts       # Redis connection wrapper
│   │   ├── CacheManager.ts      # Cache operations (get, set, invalidate)
│   │   ├── CacheKeyBuilder.ts   # Cache key generation
│   │   └── CacheInvalidator.ts  # Event-based invalidation
│   │
│   ├── kpi/                     # KPI widget services (8 widgets - data source names)
│   │   ├── InvoicesCreditsKPI.ts       # ABMS-4014: Total Turnover
│   │   ├── InvoicesCountKPI.ts         # ABMS-4019: Turnover Count
│   │   ├── ConvertedJobsKPI.ts         # ABMS-4021: Converted Jobs
│   │   ├── BudgetedJobsKPI.ts          # ABMS-4022: Budgeted Extra Jobs
│   │   ├── QualityAuditsKPI.ts         # ABMS-4023: Total Audits
│   │   ├── FranchiseInvoicesKPI.ts     # ABMS-4024: Franchise Sales
│   │   ├── ExtraWorkInvoicesKPI.ts     # ABMS-4025: Extra Work Sold
│   │   └── ConsumableInvoicesKPI.ts    # ABMS-4026: Consumables Turnover
│   │
│   ├── chart/                   # Chart widget services (6 widgets - data source names)
│   │   ├── SalesTargetsChart.ts           # ABMS-4027: Sales Target per Location
│   │   ├── ServiceTypeInvoicesChart.ts    # ABMS-4028: Turnover per Service Type
│   │   ├── LeadsChart.ts                  # ABMS-4029: New Leads
│   │   ├── ConsumablePurchasesChart.ts    # ABMS-4030: Consumable Spending vs Budget
│   │   ├── CasesChart.ts                  # ABMS-4031: Cases
│   │   └── QualityAuditsChart.ts          # ABMS-4032: QA
│   │
│   └── BaseWidgetService.ts     # Abstract base class for widgets
│
├── datasource/                  # Database connection
│   └── datasource.ts            # TypeORM DataSource (read-only)
│
├── model-dictionary/            # TypeORM entities (shared from msvc-abms)
│   ├── Invoice.ts
│   ├── Job.ts
│   ├── QualityAudit.ts
│   ├── Location.ts
│   └── ... (other entities)
│
├── dto/                         # Data transfer objects
│
├── utils/                       # Utilities
│   └── logger.ts                # Winston logger
│
├── client/                      # External service clients
│   └── PulsarClient.ts          # Pulsar event bus client
│
└── constants/                   # Application constants
    └── CacheTTL.ts              # Widget TTL configuration
```

## Development Commands

### Core Development
```bash
yarn dev                 # Start development server (nodemon)
yarn build              # Build TypeScript to dist/
yarn start              # Run production build
```

### Docker Development
```bash
# NOTE: This service uses shared infrastructure from msvc-abms
# Start msvc-abms infrastructure first:
cd /path/to/msvc-abms && docker-compose up -d

# Then start analytics service:
cd /path/to/msvc-analytics-abms
yarn docker:dev                # Start service in Docker
yarn docker:dev:down           # Stop service
```

### Code Quality
```bash
yarn lint               # Run ESLint + Prettier
yarn format             # Format code with Prettier
```

### Testing
```bash
yarn test               # Run Jest tests
yarn test:watch         # Watch mode
yarn test:coverage      # Generate coverage
```

## Development Guidelines

### 1. Database Access

**IMPORTANT:** This service uses a **shared database** with msvc-abms (same team maintains both):
- **STRICTLY READ-ONLY**: Only SELECT queries - no INSERT, UPDATE, DELETE operations
- **DO NOT** run migrations from this service
- **DO NOT** use `schema:sync` or any schema modification commands
- Schema is managed exclusively by msvc-abms
- This service has full read access to all tables (same user as msvc-abms)
- Materialized views are created via msvc-abms migrations
- **Only database writes**: Redis (for caching)

**Entity Models:**

Entity models in `src/model-dictionary/` should mirror the tables in msvc-abms database. Copy entity definitions from msvc-abms when needed for TypeORM queries.

```typescript
// src/model-dictionary/Invoice.ts
// This should match the entity definition in msvc-abms
import { Entity, PrimaryGeneratedColumn, Column, Index } from 'typeorm';

@Entity('invoices')
export class Invoice {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'timestamp' })
  invoice_date: Date;

  @Column({ type: 'decimal', precision: 12, scale: 2 })
  grand_total: number;

  // ... other fields matching msvc-abms schema
}
```

### 2. Adding New Widgets

**For KPI Widgets:**
1. Create service in `src/services/kpi/` extending `BaseWidgetService`
2. Implement `fetchFromDatabase()` method
3. Add to `DashboardResolver` queries
4. Update cache TTL in `src/constants/CacheTTL.ts`
5. Update event mapping in `CacheInvalidator` if needed

**For Chart Widgets:**
1. Create service in `src/services/chart/` extending `BaseWidgetService`
2. Implement data aggregation logic
3. Return data in chart format (labels + datasets)
4. Follow same steps as KPI widgets

### 3. Database Queries

**IMPORTANT:**
- **READ-ONLY**: Use TypeORM query builder for complex SELECT queries only
- **Never use**: `save()`, `insert()`, `update()`, `delete()`, `remove()` - this service does NOT write to PostgreSQL
- Query materialized views when available for better performance
- Indexes are managed by msvc-abms team
- Log slow queries (>5 seconds)
- Test with realistic data volumes

**Example (Read from materialized view):**
```typescript
// Query materialized view for fast aggregated data
const result = await AppDataSource.query(`
  SELECT SUM(net_turnover) as total
  FROM mv_invoice_kpis
  WHERE date >= $1::date AND date <= $2::date
    AND ($3::varchar IS NULL OR location_id = $3)
`, [filters.dateRange.startDate, filters.dateRange.endDate, filters.location || null]);
```

**Example (Read from base table for record lists):**
```typescript
// Query base table for individual records
const result = await AppDataSource
  .getRepository(Invoice)
  .createQueryBuilder('invoice')
  .select('SUM(invoice.grand_total)', 'total')
  .where('invoice.invoice_date BETWEEN :start AND :end', {
    start: filters.dateRange.startDate,
    end: filters.dateRange.endDate,
  })
  .getRawOne();
```

### 4. Cache Management

**Best Practices:**
- Use `BaseWidgetService` for automatic caching
- Set appropriate TTL per widget type
- Invalidate on relevant data mutations
- Monitor cache hit rates (target: >80%)
- Use patterns for bulk invalidation

**Widget Naming:**
- Widget names are based on **data sources**, not ticket numbers
- Examples: `invoices_credits_kpi`, `sales_targets_chart`, `leads_chart`
- Ticket numbers (e.g., ABMS-4014) are kept in metadata for reference

**Manual Cache Operations:**
```typescript
// Get from cache
const data = await cacheManager.get<T>(key);

// Set in cache
await cacheManager.set(key, data, { ttl: 600 });

// Invalidate pattern (using widget name)
await cacheManager.invalidatePattern('dashboard:invoices_credits_kpi:*');
```

### 4. Event Handling

**Adding New Events:**
1. Update `EVENT_INVALIDATION_MAP` in `CacheInvalidator.ts`
2. Map event type to affected widget names (data source-based)
3. Ensure core services publish these events
4. Test invalidation flow

**Example:**
```typescript
// Map event to widgets by data source names
export const EVENT_INVALIDATION_MAP: Record<string, string[]> = {
  'invoice.exported': [
    'invoices_credits_kpi',
    'invoices_count_kpi',
    'service_type_invoices_chart',
  ],
  'job.status_changed': [
    'converted_jobs_kpi',
    'budgeted_jobs_kpi',
  ],
};
```

### 5. TypeScript Patterns

- Use strict mode
- Leverage type inference
- Define interfaces for data structures
- Use enums for constants
- Prefer `readonly` for immutable data

### 6. Error Handling

```typescript
try {
  const data = await this.fetchData();
  return data;
} catch (error) {
  logger.error('Failed to fetch data:', error);
  throw new Error('Data fetch failed');
}
```

## Environment Variables

**Required:**
- `DB_HOST`, `DB_PORT`, `DB_NAME` - Database connection
- `DB_USER_READONLY`, `DB_PASSWORD_READONLY` - Read-only credentials
- `REDIS_HOST`, `REDIS_PORT` - Redis connection

**Optional:**
- `REDIS_PASSWORD` - Redis auth
- `PULSAR_SERVICE_URL` - Event bus (optional, TTL-based caching works without it)
- `LOG_LEVEL` - Logging verbosity (default: info)

## API Usage

### Health Checks
```bash
GET /health       # Liveness probe
GET /ready        # Readiness probe (checks Redis)
GET /cache/stats  # Cache statistics
```

### GraphQL Queries

**Endpoint:** `http://localhost:4040/graphql`

**Sample Query 1: Get Invoice/Credit KPI**
```graphql
query AbmsGetInvoicesCreditsKPI($filters: DashboardFilterInput!) {
  abmsGetInvoicesCreditsKPI(filters: $filters) {
    widgetName
    value
    previousValue
    changePercentage
    trend
    metadata
    lastUpdated
  }
}
```

**Variables:**
```json
{
  "filters": {
    "dateRange": {
      "startDate": "2025-10-01",
      "endDate": "2025-10-05",
      "dateField": "invoice_date"
    }
  }
}
```

**Sample Response:**
```json
{
  "data": {
    "abmsGetInvoicesCreditsKPI": {
      "widgetName": "invoices_credits_kpi",
      "value": 10812.5,
      "previousValue": 0,
      "changePercentage": 0,
      "trend": "STABLE",
      "metadata": null,
      "lastUpdated": "2025-10-05T14:51:49.456Z"
    }
  }
}
```

**Sample Query 2: Get Invoice Count Records (Drill-down)**
```graphql
query AbmsGetInvoicesCountRecords($filters: DashboardFilterInput!) {
  abmsGetInvoicesCountRecords(filters: $filters) {
    records {
      id
      invoiceNumber
      invoiceDate
      billDate
      netTurnover
      locationId
      customerName
      status
    }
    total
    page
    pageSize
  }
}
```

**Variables:**
```json
{
  "filters": {
    "dateRange": {
      "startDate": "2025-10-01",
      "endDate": "2025-10-05",
      "dateField": "invoice_date"
    }
  }
}
```

**Sample Response:**
```json
{
  "data": {
    "abmsGetInvoicesCountRecords": {
      "records": [
        {
          "id": "17e04ab9-5979-4db2-8004-548577c99f66",
          "invoiceNumber": "I000004",
          "invoiceDate": "2024-03-10T09:00:00.000Z",
          "billDate": "2025-05-31T00:00:00.000Z",
          "netTurnover": 4600,
          "locationId": "b430513e-4f70-40b9-af74-c5cdf622e482",
          "customerName": "Client Kim Catunao",
          "status": "Exported"
        },
        {
          "id": "b18a6b8e-b2d7-4e4b-9888-1f774590ff4b",
          "invoiceNumber": "I000046",
          "invoiceDate": "2024-03-05T09:00:00.000Z",
          "billDate": null,
          "netTurnover": 2012.5,
          "locationId": "eb34d112-c6c2-4884-9d04-742495d2010d",
          "customerName": "Prince Rastogi324adsfa",
          "status": "Exported"
        },
        {
          "id": "f2698964-37cd-4d06-8348-db17da07fb46",
          "invoiceNumber": "I000045",
          "invoiceDate": "2024-03-01T09:00:00.000Z",
          "billDate": null,
          "netTurnover": 4200,
          "locationId": "f5172149-2572-44bb-b399-5c7b1dcd9a85",
          "customerName": "March Apartments and Extended Stay",
          "status": "Exported"
        }
      ],
      "total": 3,
      "page": 1,
      "pageSize": 10
    }
  }
}
```

**Filter Options:**
- `dateRange.startDate`: Start date in `YYYY-MM-DD` format (required)
- `dateRange.endDate`: End date in `YYYY-MM-DD` format (required)
- `dateRange.dateField`: `"invoice_date"` or `"bill_date"` (optional, defaults to `"invoice_date"`)
- `location`: Location UUID as string (optional, filters by specific location)
- `page`: Page number for pagination (optional, defaults to 1)
- `pageSize`: Records per page (optional, defaults to 10)

## Performance Monitoring

### Key Metrics

1. **Cache Performance:**
   - Hit rate (target: >80%)
   - Latency (get/set operations)
   - Memory usage

2. **API Performance:**
   - Response time (p50, p95, p99)
   - Query count
   - Error rate

3. **Database:**
   - Query execution time
   - Connection pool usage
   - Slow query log

### Monitoring Tools

- Redis: `GET /cache/stats` endpoint
- Logs: Winston JSON format
- APM: (To be integrated)

## Common Tasks

### 1. Test Redis Connection

```bash
docker exec -it redis redis-cli
> SELECT 1  # Switch to analytics DB
> PING
PONG
> KEYS dashboard:*
```

### 2. View Service Logs

```bash
# Docker logs
docker logs msvc-analytics-abms -f

# Local development
# Logs output to console via Winston with pretty formatting
```

**Enhanced Logging Features:**

The logger uses Winston with prettified console output:

```typescript
import { createLogger } from './utils/logger';

const logger = createLogger('DashboardService');

// Simple log
logger.info('Processing dashboard request');

// Log with metadata (automatically prettified)
logger.info('Cache miss', {
  widgetName: 'invoices_credits_kpi',
  filters: {
    dateRange: { startDate: '2025-01-01', endDate: '2025-01-31' },
    location: 'LOC001'
  },
  queryTime: '45ms'
});

// Error log with stack trace
logger.error('Database query failed', {
  query: 'SELECT * FROM invoices',
  error: err.message,
  stack: err.stack
});
```

**Console Output (prettified & colored):**
```
2025-01-15 10:30:00 info [DashboardService] Processing dashboard request

2025-01-15 10:30:05 warn [DashboardService] Cache miss
{
  widgetName: 'invoices_credits_kpi',
  filters: {
    dateRange: { startDate: '2025-01-01', endDate: '2025-01-31' },
    location: 'LOC001'
  },
  queryTime: '45ms'
}

2025-01-15 10:30:10 error [DashboardService] Database query failed
{
  query: 'SELECT * FROM invoices',
  error: 'Connection timeout',
  stack: '...'
}
```

**Features:**
- ✅ Colored log levels (error=red, warn=yellow, info=green, debug=blue)
- ✅ Multi-line pretty-printed JSON with syntax highlighting
- ✅ Automatic indentation and formatting
- ✅ Context tags for easy filtering
- ✅ Production logs are JSON format (for log aggregation)
- ✅ Development logs are human-readable

### 3. Clear Cache

```bash
# Via GraphQL (when implemented)
mutation {
  invalidateCache(widgetName: "invoices_credits_kpi")
}

# Via Redis CLI
docker exec -it redis redis-cli
> SELECT 1  # Switch to analytics DB
> KEYS dashboard:*
> DEL dashboard:invoices_credits_kpi:LOC001:abc123
```

### 4. Database Connection Test

```bash
# Connect to shared database
docker exec -it postgres psql -U abms_user -d msvc_abms

# Test query
SELECT COUNT(*) FROM invoices;
```

## Integration with Other Services

### API Gateway (msvc-gw-apollo-abms)

**The analytics service is already integrated** into the Apollo Federation Gateway as a subgraph.

**Gateway Configuration:**

Local development (`.env`):
```bash
APOLLO_SERVICE_LIST=[
  {"name":"msvc-abms","url":"http://localhost:8083"},
  {"name":"msvc-analytics-abms","url":"http://localhost:4040/graphql"}
]
```

Docker development (`docker-compose.dev.yml`):
```yaml
APOLLO_SERVICE_LIST: '[
  {"name":"msvc-abms","url":"http://msvc-cto-bo:8083"},
  {"name":"msvc-analytics-abms","url":"http://msvc-analytics-abms-dev:4040/graphql"}
]'
```

**Accessing Analytics Queries:**

Direct (development/testing):
```
http://localhost:4040/graphql
```

Via Gateway (production/recommended):
```
http://localhost:3001/
```

**Schema Federation:**

The analytics service uses `@apollo/subgraph` and Type-GraphQL to expose its schema. The gateway automatically discovers and merges it with other subgraphs (like msvc-abms) using Apollo Federation v2.

**Testing Gateway Integration:**
```bash
# Start analytics service
cd /Users/ctouser/CTO/msvc-analytics-abms
yarn dev

# Start gateway (in another terminal)
cd /Users/ctouser/CTO/msvc-gw-apollo-abms
yarn dev

# Query through gateway
curl -X POST http://localhost:3001/ \
  -H "Content-Type: application/json" \
  -d '{"query":"{ getInvoicesCreditsKPI(filters: {dateRange: {startDate: \"2025-01-01\", endDate: \"2025-01-31\"}}) { widgetName value } }"}'
```

### Core Service (msvc-abms)

Ensure core service publishes events to Pulsar:
- `invoice.exported`
- `job.status_changed`
- `quality_audit.completed`
- etc.

### Frontend (fe-abms)

GraphQL queries via Apollo Client:
```typescript
import { useQuery } from '@apollo/client';
import { GET_INVOICES_CREDITS_KPI } from '@/graphql/dashboard/queries';

const { data, loading } = useQuery(GET_INVOICES_CREDITS_KPI, {
  variables: {
    filters: {
      location: 'LOC001',
      dateRange: {
        startDate: '2025-01-01',
        endDate: '2025-01-31'
      }
    }
  }
});
// Returns: { widgetName: 'invoices_credits_kpi', ticket: 'ABMS-4014', value: ... }
```

## Troubleshooting

### Redis Not Connecting

1. Check Docker container: `docker ps | grep redis`
2. Check connectivity: `docker exec redis-analytics redis-cli ping`
3. Verify password: Check `REDIS_PASSWORD` in `.env`

### Database Permission Denied

1. Verify read-only user exists: `\du analytics_reader`
2. Check permissions: `\dp` (should show SELECT on tables)
3. Reconnect to database

### Cache Invalidation Not Working

1. Check Pulsar connectivity
2. Verify event subscriptions in `PulsarClient`
3. Check event type mapping in `CacheInvalidator`
4. Review service logs for errors

### Slow Query Performance

1. Check database indexes (see README)
2. Use `EXPLAIN` on slow queries
3. Monitor query execution time
4. Consider adding more specific indexes

## Best Practices

1. **Always use `BaseWidgetService`** for consistent caching
2. **Log important operations** at appropriate levels
3. **Handle errors gracefully** with user-friendly messages
4. **Test with realistic data** before deploying
5. **Monitor cache hit rates** and adjust TTLs as needed
6. **Document complex business logic** in code comments
7. **Use TypeScript types** for all data structures

## Next Steps After Scaffold

1. Implement KPI services (ABMS-4014 to ABMS-4026)
2. Implement Chart services (ABMS-4027 to ABMS-4032)
3. Copy entity models from `msvc-abms`
4. Add database indexes
5. Test with real data
6. Deploy to staging
7. Performance tuning
8. Production deployment

---

**For detailed implementation plans, see:**
- `/Users/ctouser/CTO/Dashboard Reports - Implementation Plan.md`
- `/Users/ctouser/CTO/Dashboard Reports - Architecture Diagram.md`
- `/Users/ctouser/CTO/Dashboard Reports - Gap Analysis.md`
