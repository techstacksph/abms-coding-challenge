# msvc-analytics-abms

Analytics and Dashboard Microservice for ABMS (At Your Request Business Management System)

## Overview

This microservice provides high-performance analytics and dashboard capabilities for the ABMS ecosystem. It implements 14 dashboard widgets (8 KPIs + 6 Charts) with Redis caching and event-driven cache invalidation.

**Tickets Covered:** ABMS-4014 to ABMS-4032

## Features

- ✅ **8 KPI Widgets** - Real-time business metrics
- ✅ **6 Chart Widgets** - Visual data analytics
- ✅ **Redis Caching** - Sub-second response times (target: >80% cache hit rate)
- ✅ **Event-Driven Cache Invalidation** - Automatic cache updates via Pulsar
- ✅ **GraphQL API** - Apollo Federation subgraph with tenant prefix
- ✅ **Shared Database** - Direct access to msvc_abms database
- ✅ **TypeScript** - Full type safety
- ✅ **Docker Support** - Containerized deployment
- ✅ **Prettified Logging** - Winston with colored, formatted output

## Technology Stack

- **Runtime:** Node.js 20+
- **Language:** TypeScript 5.2
- **API:** GraphQL (Apollo Server 4.9, Type-GraphQL, Apollo Federation)
- **Cache:** Redis 7 (ioredis 5.x, shared with msvc-abms, DB index 1)
- **Database:** PostgreSQL 15 (TypeORM 0.3, shared msvc_abms database)
- **Event Bus:** Apache Pulsar (cache invalidation, shared with msvc-abms)
- **Logging:** Winston (prettified console output with util.inspect)
- **Container:** Docker + Docker Compose

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌────────────────────┐     ┌──────────────────┐
│   Frontend  │────▶│  API Gateway │────▶│   Redis Cache      │────▶│    msvc_abms     │
│  Dashboard  │     │ (Federation) │     │   (Shared, DB 1)   │     │ (Shared Database)│
└─────────────┘     └──────────────┘     └────────────────────┘     └──────────────────┘
                            │                    │                           │
                            │              Cache Hit                   Cache Miss
                            │                Return                    Query DB
                            │                                      Store in Redis
                            ▼
                    ┌──────────────┐
                    │ Apache Pulsar│              ┌──────────────────┐
                    │ (Event Bus)  │◀─────────────│   msvc-abms      │
                    │  (Shared)    │  Events      │  (Core Service)  │
                    └──────────────┘              └──────────────────┘
                            │
                      Cache Invalidation
```

**Infrastructure (All Shared with msvc-abms):**
- **PostgreSQL**: Shared `msvc_abms` database (same database as core service)
- **Redis**: Shared instance (uses DB index 1 for analytics, DB 0 for msvc-abms)
- **Pulsar**: Shared event bus for cache invalidation
- **API Gateway**: Apollo Federation for unified GraphQL endpoint

## Widgets Implemented

### KPI Widgets (8)

| Widget Name | Ticket | Description | Data Source | TTL |
|-------------|--------|-------------|-------------|-----|
| `invoices_credits_kpi` | ABMS-4014 | Total Turnover | Invoices, Credits | 10 min |
| `invoices_count_kpi` | ABMS-4019 | Turnover Count | Invoices | 10 min |
| `converted_jobs_kpi` | ABMS-4021 | Converted Jobs | Jobs | 5 min |
| `budgeted_jobs_kpi` | ABMS-4022 | Budgeted Extra Jobs | Jobs | 5 min |
| `quality_audits_kpi` | ABMS-4023 | Total Audits | Quality Audits | 15 min |
| `franchise_invoices_kpi` | ABMS-4024 | Franchise Sales | Invoices (Acc 2001) | 10 min |
| `extra_work_invoices_kpi` | ABMS-4025 | Extra Work Sold | Invoices (Acc 2003) | 10 min |
| `consumable_invoices_kpi` | ABMS-4026 | Consumables Turnover | Invoices (Acc 207/208) | 10 min |

### Chart Widgets (6)

| Widget Name | Ticket | Description | Chart Type | TTL |
|-------------|--------|-------------|------------|-----|
| `sales_targets_chart` | ABMS-4027 | Sales Target per Location | Column-Line | 15 min |
| `service_type_invoices_chart` | ABMS-4028 | Turnover per Service Type | Column | 15 min |
| `leads_chart` | ABMS-4029 | New Leads | Bar | 5 min |
| `consumable_purchases_chart` | ABMS-4030 | Consumable Spending vs Budget | Column-Line | 10 min |
| `cases_chart` | ABMS-4031 | Cases | Stacked Bar | 5 min |
| `quality_audits_chart` | ABMS-4032 | QA | Stacked Bar | 5 min |

## Installation

### Prerequisites

- Node.js 20.13.1 or higher
- Yarn package manager
- Docker and Docker Compose (for local development)
- Access to ABMS PostgreSQL database
- Redis instance
- Apache Pulsar instance (optional, for event-driven cache invalidation)

### Setup

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd msvc-analytics-abms
   ```

2. **Install dependencies:**
   ```bash
   yarn install
   ```

3. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start msvc-abms infrastructure:**
   ```bash
   # This service uses shared infrastructure from msvc-abms
   cd /path/to/msvc-abms
   docker-compose up -d
   ```

5. **Run development server:**
   ```bash
   cd /path/to/msvc-analytics-abms
   yarn dev
   ```

## Development

### Scripts

```bash
# Development
yarn dev                 # Start development server with hot reload
yarn build              # Build TypeScript to JavaScript
yarn start              # Start production server

# Docker (requires msvc-abms infrastructure running)
yarn docker:dev         # Start analytics service in Docker
yarn docker:dev:down    # Stop analytics service

# Code Quality
yarn lint               # Run ESLint and Prettier
yarn format             # Format code with Prettier

# Testing
yarn test               # Run tests
yarn test:watch         # Run tests in watch mode
yarn test:coverage      # Generate coverage report
```

### Environment Variables

See `.env.example` for all available configuration options.

**Key Variables:**
- `PORT` - Server port (default: 4040)
- `TENANT_PREFIX` - GraphQL query prefix (default: abms)
- `SYSTEM_ID` - System identifier for logging (default: analytics)
- `DB_HOST`, `DB_PORT`, `DB_NAME` - PostgreSQL connection (shared msvc_abms database)
- `DB_USER`, `DB_PASSWORD` - Database credentials (same as msvc-abms)
- `REDIS_HOST`, `REDIS_PORT`, `REDIS_DB` - Redis connection (DB 1 for analytics)
- `PULSAR_SERVICE_URL` - Apache Pulsar connection (shared with msvc-abms)
- `GRAPHQL_PATH` - GraphQL endpoint path (default: /)

### Project Structure

```
msvc-analytics-abms/
├── src/
│   ├── server.ts                # Application entry point
│   ├── environment.ts           # Environment configuration
│   │
│   ├── resolver/                # GraphQL resolvers
│   │   └── DashboardResolver.ts
│   │
│   ├── schema/                  # GraphQL schemas
│   │   └── DashboardSchema.ts
│   │
│   ├── services/                # Business logic
│   │   ├── cache/
│   │   │   ├── RedisClient.ts
│   │   │   ├── CacheManager.ts
│   │   │   ├── CacheKeyBuilder.ts
│   │   │   └── CacheInvalidator.ts
│   │   ├── kpi/                 # KPI widget services
│   │   ├── chart/               # Chart widget services
│   │   └── BaseWidgetService.ts
│   │
│   ├── datasource/              # Database connection
│   │   └── datasource.ts
│   │
│   ├── model-dictionary/        # TypeORM entities
│   │
│   ├── dto/                     # Data transfer objects
│   │
│   ├── utils/                   # Utilities
│   │   └── logger.ts
│   │
│   ├── client/                  # External service clients
│   │   └── PulsarClient.ts
│   │
│   └── constants/               # Constants
│       └── CacheTTL.ts
│
├── docker-compose.yml           # Production Docker config
├── docker-compose.dev.yml       # Development Docker config
├── docker-compose-redis.yml     # Redis standalone
├── docker-compose-postgres.yml  # PostgreSQL reference
├── docker-compose-pulsar.yml    # Pulsar standalone
├── Dockerfile                   # Production Dockerfile
├── Dockerfile.dev               # Development Dockerfile
├── package.json
├── tsconfig.json
└── README.md
```

## API Documentation

### GraphQL Endpoints

**Direct Access (Development):**
```
http://localhost:4040/
```

**Via Apollo Gateway (Recommended):**
```
http://localhost:3001/
```

The analytics service is integrated into the Apollo Federation Gateway (`msvc-gw-apollo-abms`) as a subgraph. All queries are prefixed with `TENANT_PREFIX` (e.g., `abmsGetInvoicesCreditsKPI`). In production, all queries should go through the gateway for unified access control, monitoring, and schema stitching.

### Query Examples

**Get KPI Data (Total Turnover):**
```graphql
query GetInvoicesCreditsKPI {
  abmsGetInvoicesCreditsKPI(
    filters: {
      location: "LOC001"
      dateRange: {
        startDate: "2025-01-01"
        endDate: "2025-01-31"
      }
      dateField: "invoice_date"
    }
  ) {
    widgetName
    ticket
    value
    previousValue
    changePercentage
    trend
    lastUpdated
  }
}
```

**Get Chart Data (Sales Targets):**
```graphql
query GetSalesTargetsChart {
  abmsGetSalesTargetsChart(
    filters: {
      dateRange: {
        startDate: "2025-01-01"
        endDate: "2025-12-31"
      }
      dateField: "created_at"
    }
  ) {
    widgetName
    ticket
    labels
    datasets {
      label
      data
      type
    }
    lastUpdated
  }
}
```

**Get Complete Dashboard:**
```graphql
query GetDashboard {
  abmsGetDashboard(
    filters: {
      dateRange: {
        startDate: "2025-01-01"
        endDate: "2025-01-31"
      }
      dateField: "invoice_date"
    }
  ) {
    kpis {
      widgetName
      ticket
      value
    }
    charts {
      widgetName
      ticket
      labels
    }
    lastUpdated
  }
}
```

## Cache Strategy

### Cache Keys

Pattern: `dashboard:{widget_name}:{location}:{date_range_hash}`

Examples:
- `dashboard:invoices_credits_kpi:LOC001:abc12345`
- `dashboard:sales_targets_chart:ALL:def67890`
- `dashboard:leads_chart:LOC002:ghi56789`

### TTL Configuration

See `src/constants/CacheTTL.ts` for widget-specific TTL values (5-15 minutes).

### REST API Endpoints

**Health Checks:**
```bash
GET /health              # Liveness probe
GET /ready               # Readiness probe
```

**Cache Management:**
```bash
GET /cache/stats         # View cache statistics
```

**Materialized View Refresh (BullMQ):**
```bash
GET /mv-refresh/stats    # View refresh queue statistics and schedules
POST /mv-refresh/manual  # Manually trigger refresh of all materialized views
GET /admin/queues        # Bull Board UI - Visual dashboard for queue monitoring
```

**Bull Board UI:**

Visual dashboard for monitoring BullMQ queues, jobs, and workers:
```
http://localhost:4040/admin/queues
```

Features:
- Real-time queue statistics
- Job status monitoring (waiting, active, completed, failed)
- Job retry management
- Manual job triggering
- Job logs and error details
- Queue metrics and charts

Example response from `/mv-refresh/stats`:
```json
{
  "jobCounts": {
    "active": 2,
    "completed": 150,
    "failed": 0,
    "delayed": 0,
    "waiting": 0
  },
  "scheduledJobs": 12,
  "schedules": [
    {
      "name": "refresh-job-kpis",
      "pattern": "*/5 * * * *",
      "next": 1705334400000
    }
  ]
}
```

### Event-Driven Invalidation

Automatic cache invalidation on data mutations:

| Event | Affected Widgets |
|-------|-----------------|
| `invoice.exported` | `invoices_credits_kpi`, `invoices_count_kpi`, `franchise_invoices_kpi`, `extra_work_invoices_kpi`, `consumable_invoices_kpi`, `service_type_invoices_chart` |
| `job.status_changed` | `converted_jobs_kpi`, `budgeted_jobs_kpi` |
| `quality_audit.completed` | `quality_audits_kpi`, `quality_audits_chart` |
| `lead.created` / `lead.updated` | `leads_chart` |
| `case.status_changed` | `cases_chart` |
| `sales_target.updated` | `sales_targets_chart` |
| `consumable.purchased` | `consumable_purchases_chart` |

See `src/services/cache/CacheInvalidator.ts` for complete mapping.

## Performance Targets

| Metric | Target |
|--------|--------|
| Widget Load Time | ≤3 seconds |
| Cache Hit Rate | >80% |
| API Response (cached) | <100ms |
| API Response (uncached) | <2 seconds |
| Concurrent Users | 100+ |

## Database Access

This service uses the **shared `msvc_abms` database** with the same credentials as msvc-abms. No separate database setup is required.

**Important:**
- **READ-ONLY ACCESS**: This service performs **ONLY SELECT queries** - no writes to PostgreSQL
- Database schema is managed by msvc-abms (same team maintains both services)
- **No INSERT, UPDATE, DELETE** operations on PostgreSQL
- **No migrations** should be run from this service
- **No schema sync** - schema is managed exclusively by msvc-abms
- Entity models should mirror the tables from msvc-abms
- **Only database writes**: Redis (for caching)

### Required Indexes

Indexes are managed by msvc-abms. The following indexes are recommended for analytics queries:

```sql
-- Invoice queries (managed by msvc-abms)
CREATE INDEX idx_invoice_date_location ON invoices(invoice_date, location_id);
CREATE INDEX idx_invoice_account_code ON invoices(account_code);

-- Job queries (managed by msvc-abms)
CREATE INDEX idx_job_start_date_location ON jobs(start_date, location_id, status);

-- Audit queries (managed by msvc-abms)
CREATE INDEX idx_audit_completed_date ON quality_audits(completed_date, status);

-- Lead queries (managed by msvc-abms)
CREATE INDEX idx_lead_created_date ON leads(created_at, status);
```

Request index creation through msvc-abms team if needed.

## Deployment

### Docker Production

```bash
# Build image
docker build -t msvc-analytics-abms:latest .

# Run container
docker-compose up -d
```

### Health Checks

- **Liveness:** `GET /health`
- **Readiness:** `GET /ready`
- **Cache Stats:** `GET /cache/stats`

### Monitoring

Monitor these metrics:
- Redis cache hit/miss rate
- API response times (p50, p95, p99)
- Database query performance
- Widget-specific load times

## Troubleshooting

### Redis Connection Issues

```bash
# Check Redis connectivity (use shared Redis container)
docker exec -it redis redis-cli
> SELECT 1  # Switch to analytics DB
> PING
> KEYS dashboard:*

# View Redis logs
docker logs redis
```

### Database Connection Issues

```bash
# Test database connection (shared database)
docker exec -it postgres psql -U abms_user -d msvc_abms

# Test query
SELECT COUNT(*) FROM invoices;
```

### Cache Invalidation Not Working

```bash
# Check Pulsar connection (shared Pulsar)
docker logs pulsar

# View analytics service logs
docker logs msvc-analytics-abms-dev
```

## Contributing

### Development Workflow

1. Create feature branch from `development`
2. Implement changes with tests
3. Run linting and type checking
4. Submit pull request to `development` branch

### Code Standards

- Follow TypeScript strict mode
- Write JSDoc comments for public APIs
- Use meaningful variable names
- Keep functions small and focused

## License

ISC

## Support

For issues or questions, contact the ABMS development team.

---

**Built with ❤️ by the ABMS Team**
