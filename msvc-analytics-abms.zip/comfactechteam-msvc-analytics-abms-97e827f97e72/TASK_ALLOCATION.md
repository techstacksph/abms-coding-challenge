# Backend Task Allocation - Dashboard Widgets

## Sprint Overview

**Team:** 3 Backend Developers (Eugene, Aldous, Guill)
**Timeline:** 3 Saturdays + 3 Sundays (6 days total)
**Scope:** 14 Dashboard Widgets (8 KPIs + 6 Charts)

## Task Distribution

### Eugene - KPI Widgets (5 widgets)

| Widget Name | Ticket | Description | Data Source | TTL | Priority |
|-------------|--------|-------------|-------------|-----|----------|
| `invoices_credits_kpi` | ABMS-4014 | Total Turnover | Invoices, Credits | 10 min | High |
| `invoices_count_kpi` | ABMS-4019 | Turnover Count | Invoices | 10 min | High |
| `converted_jobs_kpi` | ABMS-4021 | Converted Jobs | Jobs | 5 min | Medium |
| `budgeted_jobs_kpi` | ABMS-4022 | Budgeted Extra Jobs | Jobs | 5 min | Medium |
| `quality_audits_kpi` | ABMS-4023 | Total Audits | Quality Audits | 15 min | Medium |

**Implementation Path:**
```
src/services/kpi/
├── InvoicesCreditsKPI.ts       # ABMS-4014
├── InvoicesCountKPI.ts         # ABMS-4019
├── ConvertedJobsKPI.ts         # ABMS-4021
├── BudgetedJobsKPI.ts          # ABMS-4022
└── QualityAuditsKPI.ts         # ABMS-4023
```

---

### Aldous - KPI & Chart Widgets (5 widgets)

#### KPI Widgets (3)

| Widget Name | Ticket | Description | Data Source | TTL | Priority |
|-------------|--------|-------------|-------------|-----|----------|
| `franchise_invoices_kpi` | ABMS-4024 | Franchise Sales | Invoices (Acc 2001) | 10 min | Medium |
| `extra_work_invoices_kpi` | ABMS-4025 | Extra Work Sold | Invoices (Acc 2003) | 10 min | Medium |
| `consumable_invoices_kpi` | ABMS-4026 | Consumables Turnover | Invoices (Acc 207/208) | 10 min | Medium |

#### Chart Widgets (2)

| Widget Name | Ticket | Description | Chart Type | TTL | Priority |
|-------------|--------|-------------|------------|-----|----------|
| `sales_targets_chart` | ABMS-4027 | Sales Target per Location | Column-Line | 15 min | High |
| `service_type_invoices_chart` | ABMS-4028 | Turnover per Service Type | Column | 15 min | High |

**Implementation Path:**
```
src/services/kpi/
├── FranchiseInvoicesKPI.ts     # ABMS-4024
├── ExtraWorkInvoicesKPI.ts     # ABMS-4025
└── ConsumableInvoicesKPI.ts    # ABMS-4026

src/services/chart/
├── SalesTargetsChart.ts        # ABMS-4027
└── ServiceTypeInvoicesChart.ts # ABMS-4028
```

---

### Guill - Chart Widgets (4 widgets)

| Widget Name | Ticket | Description | Chart Type | TTL | Priority |
|-------------|--------|-------------|------------|-----|----------|
| `leads_chart` | ABMS-4029 | New Leads | Bar | 5 min | Medium |
| `consumable_purchases_chart` | ABMS-4030 | Consumable Spending vs Budget | Column-Line | 10 min | Medium |
| `cases_chart` | ABMS-4031 | Cases | Stacked Bar | 5 min | Medium |
| `quality_audits_chart` | ABMS-4032 | QA | Stacked Bar | 5 min | Medium |

**Implementation Path:**
```
src/services/chart/
├── LeadsChart.ts                  # ABMS-4029
├── ConsumablePurchasesChart.ts    # ABMS-4030
├── CasesChart.ts                  # ABMS-4031
└── QualityAuditsChart.ts          # ABMS-4032
```

---

## Implementation Checklist (Per Widget)

### Phase 1: Service Implementation
- [ ] Create service class extending `BaseWidgetService`
- [ ] Define `widgetName` property (data source-based)
- [ ] Implement `fetchFromDatabase()` method (READ-ONLY - SELECT queries only)
- [ ] Query materialized views (e.g., `mv_invoice_kpis`) for aggregated data
- [ ] Use TypeORM query builder or raw SQL for SELECT queries
- [ ] Add error handling and logging
- [ ] Set up cache TTL in `src/constants/CacheTTL.ts`
- [ ] **Important**: No INSERT, UPDATE, DELETE operations - read-only access to PostgreSQL

### Phase 2: Entity Models
- [ ] Copy entity definitions from msvc-abms (if not already present)
- [ ] Verify TypeORM entity decorators
- [ ] Add to `src/model-dictionary/`

### Phase 3: Resolver Integration
- [ ] Update `DashboardResolver.ts` with query method
- [ ] Use tenant prefix: `${SchemaPrefix}Get{WidgetName}`
- [ ] Add proper type annotations
- [ ] Add context handling

### Phase 4: Cache Configuration
- [ ] Add TTL to `CacheTTL.ts`
- [ ] Update event invalidation mapping in `CacheInvalidator.ts`
- [ ] Map Pulsar events to widget names

### Phase 5: Testing
- [ ] Test GraphQL query directly (http://localhost:4040/)
- [ ] Test with tenant prefix (`abmsGet...`)
- [ ] Verify cache hit/miss behavior
- [ ] Test cache invalidation events
- [ ] Load test with realistic data volumes

### Phase 6: Documentation
- [ ] Add JSDoc comments to service class
- [ ] Document query parameters
- [ ] Add example GraphQL queries
- [ ] Update SPRINT_PLAN.md with progress

---

## GraphQL Query Naming Convention

All queries use tenant prefix (`abms` by default):

```graphql
# Eugene's widgets
query { abmsGetInvoicesCreditsKPI(filters: {...}) { ... } }
query { abmsGetInvoicesCountKPI(filters: {...}) { ... } }
query { abmsGetConvertedJobsKPI(filters: {...}) { ... } }
query { abmsGetBudgetedJobsKPI(filters: {...}) { ... } }
query { abmsGetQualityAuditsKPI(filters: {...}) { ... } }

# Aldous's widgets
query { abmsGetFranchiseInvoicesKPI(filters: {...}) { ... } }
query { abmsGetExtraWorkInvoicesKPI(filters: {...}) { ... } }
query { abmsGetConsumableInvoicesKPI(filters: {...}) { ... } }
query { abmsGetSalesTargetsChart(filters: {...}) { ... } }
query { abmsGetServiceTypeInvoicesChart(filters: {...}) { ... } }

# Guill's widgets
query { abmsGetLeadsChart(filters: {...}) { ... } }
query { abmsGetConsumablePurchasesChart(filters: {...}) { ... } }
query { abmsGetCasesChart(filters: {...}) { ... } }
query { abmsGetQualityAuditsChart(filters: {...}) { ... } }
```

---

## Common Filters

All widgets accept these filters:

```typescript
interface DashboardFilterInput {
  location?: string;              // Location ID filter
  dateRange: {                    // Required date range
    startDate: string;            // ISO date string
    endDate: string;              // ISO date string
  };
  dateField?: string;             // Field to filter by (default: varies by widget)
  groupBy?: string;               // Grouping field for charts
}
```

---

## Code Examples

### KPI Widget Example

```typescript
// src/services/kpi/InvoicesCreditsKPI.ts
import { Service } from 'typedi';
import { BaseWidgetService } from '../BaseWidgetService';
import { KPIData, DashboardFilterInput } from '../../schema/DashboardSchema';
import { AppDataSource } from '../../datasource/datasource';
import { Invoice } from '../../model-dictionary/Invoice';
import { createLogger } from '../../utils/logger';

const logger = createLogger('InvoicesCreditsKPI');

@Service()
export class InvoicesCreditsKPI extends BaseWidgetService<KPIData> {
  readonly widgetName = 'invoices_credits_kpi';

  protected async fetchFromDatabase(filters: DashboardFilterInput): Promise<KPIData> {
    logger.info('Fetching invoices credits KPI', { filters });

    // Query database
    const result = await AppDataSource
      .getRepository(Invoice)
      .createQueryBuilder('invoice')
      .select('SUM(invoice.grand_total)', 'total')
      .where('invoice.invoice_date BETWEEN :start AND :end', {
        start: filters.dateRange.startDate,
        end: filters.dateRange.endDate,
      })
      .andWhere(filters.location ? 'invoice.location_id = :location' : '1=1', {
        location: filters.location,
      })
      .getRawOne();

    return {
      widgetName: this.widgetName,
      ticket: 'ABMS-4014',
      value: parseFloat(result.total || '0'),
      lastUpdated: new Date(),
    };
  }
}
```

### Chart Widget Example

```typescript
// src/services/chart/SalesTargetsChart.ts
import { Service } from 'typedi';
import { BaseWidgetService } from '../BaseWidgetService';
import { ChartData, DashboardFilterInput } from '../../schema/DashboardSchema';
import { AppDataSource } from '../../datasource/datasource';
import { SalesTarget } from '../../model-dictionary/SalesTarget';
import { createLogger } from '../../utils/logger';

const logger = createLogger('SalesTargetsChart');

@Service()
export class SalesTargetsChart extends BaseWidgetService<ChartData> {
  readonly widgetName = 'sales_targets_chart';

  protected async fetchFromDatabase(filters: DashboardFilterInput): Promise<ChartData> {
    logger.info('Fetching sales targets chart', { filters });

    // Query grouped data
    const results = await AppDataSource
      .getRepository(SalesTarget)
      .createQueryBuilder('target')
      .select('target.location_id', 'location')
      .addSelect('SUM(target.target_amount)', 'target')
      .addSelect('SUM(target.actual_amount)', 'actual')
      .where('target.period_date BETWEEN :start AND :end', {
        start: filters.dateRange.startDate,
        end: filters.dateRange.endDate,
      })
      .groupBy('target.location_id')
      .getRawMany();

    return {
      widgetName: this.widgetName,
      ticket: 'ABMS-4027',
      labels: results.map(r => r.location),
      datasets: [
        {
          label: 'Target',
          data: results.map(r => parseFloat(r.target)),
          type: 'column',
        },
        {
          label: 'Actual',
          data: results.map(r => parseFloat(r.actual)),
          type: 'line',
        },
      ],
      lastUpdated: new Date(),
    };
  }
}
```

---

## Cache TTL Configuration

Update `src/constants/CacheTTL.ts`:

```typescript
export const WIDGET_TTL: Record<string, number> = {
  // Eugene's widgets
  invoices_credits_kpi: 600,        // 10 min
  invoices_count_kpi: 600,          // 10 min
  converted_jobs_kpi: 300,          // 5 min
  budgeted_jobs_kpi: 300,           // 5 min
  quality_audits_kpi: 900,          // 15 min

  // Aldous's widgets
  franchise_invoices_kpi: 600,      // 10 min
  extra_work_invoices_kpi: 600,     // 10 min
  consumable_invoices_kpi: 600,     // 10 min
  sales_targets_chart: 900,         // 15 min
  service_type_invoices_chart: 900, // 15 min

  // Guill's widgets
  leads_chart: 300,                 // 5 min
  consumable_purchases_chart: 600,  // 10 min
  cases_chart: 300,                 // 5 min
  quality_audits_chart: 300,        // 5 min
};
```

---

## Event Invalidation Mapping

Update `src/services/cache/CacheInvalidator.ts`:

```typescript
export const EVENT_INVALIDATION_MAP: Record<string, string[]> = {
  // Invoice events
  'invoice.exported': [
    'invoices_credits_kpi',
    'invoices_count_kpi',
    'franchise_invoices_kpi',
    'extra_work_invoices_kpi',
    'consumable_invoices_kpi',
    'service_type_invoices_chart',
  ],

  // Job events
  'job.status_changed': [
    'converted_jobs_kpi',
    'budgeted_jobs_kpi',
  ],

  // Quality audit events
  'quality_audit.completed': [
    'quality_audits_kpi',
    'quality_audits_chart',
  ],

  // Lead events
  'lead.created': ['leads_chart'],
  'lead.updated': ['leads_chart'],

  // Case events
  'case.status_changed': ['cases_chart'],

  // Sales target events
  'sales_target.updated': ['sales_targets_chart'],

  // Consumable events
  'consumable.purchased': ['consumable_purchases_chart'],
};
```

---

## Testing Commands

```bash
# Start development server
yarn dev

# Test GraphQL query
curl -X POST http://localhost:4040/ \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query { abmsGetInvoicesCreditsKPI(filters: { dateRange: { startDate: \"2025-01-01\", endDate: \"2025-01-31\" } }) { widgetName value } }"
  }'

# Check cache
docker exec -it redis redis-cli
> SELECT 1
> KEYS dashboard:*
> GET dashboard:invoices_credits_kpi:*

# Check logs
docker logs msvc-analytics-abms-dev -f
```

---

## Progress Tracking

Each developer should update their progress in SPRINT_PLAN.md:

- ✅ Done
- 🚧 In Progress
- ⏳ Pending
- ❌ Blocked

---

## Support & Questions

- **CLAUDE.md**: Complete project documentation
- **README.md**: Setup and API documentation
- **Slack**: #abms-analytics channel
- **Team Leads**: For blockers and architectural questions

---

**Let's build something great! 🚀**
