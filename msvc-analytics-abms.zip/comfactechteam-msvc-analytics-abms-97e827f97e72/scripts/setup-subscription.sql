-- Setup Subscription on TARGET database (msvc_analytics_abms)
-- Run this on the ANALYTICS database after tables are created

-- Step 1: Ensure tables exist (created by migrations or manually)
-- Tables must exist before creating subscription with copy_data=true

-- Step 2: Create subscription
CREATE SUBSCRIPTION analytics_sub
  CONNECTION 'host=postgres-abms port=5432 dbname=msvc_abms user=replication_user password=replication_password'
  PUBLICATION analytics_pub
  WITH (
    copy_data = true,           -- Copy existing data
    create_slot = true,          -- Create replication slot
    enabled = true,              -- Start replication immediately
    slot_name = 'analytics_slot' -- Named slot for better management
  );

-- Step 3: Verify subscription
SELECT * FROM pg_subscription;
SELECT * FROM pg_subscription_rel;

-- Step 4: Monitor replication lag
SELECT
  slot_name,
  active,
  restart_lsn,
  confirmed_flush_lsn,
  pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)) AS replication_lag
FROM pg_replication_slots
WHERE slot_name = 'analytics_slot';

-- Note: For this to work:
-- 1. Source database must have wal_level=logical
-- 2. max_replication_slots >= 1
-- 3. max_wal_senders >= 1
-- 4. Network connectivity between containers
