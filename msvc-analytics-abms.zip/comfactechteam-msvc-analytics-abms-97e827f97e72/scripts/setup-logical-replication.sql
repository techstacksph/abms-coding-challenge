-- Setup Logical Replication from msvc_abms to msvc_analytics_abms
-- Run this on the SOURCE database (msvc_abms)

-- Step 1: Create publication on source database
CREATE PUBLICATION analytics_pub FOR TABLE
  invoices,
  credits,
  jobs,
  quality_audits,
  leads,
  cases,
  locations,
  accounts,
  sales_targets,
  consumable_purchases;

-- Step 2: Create replication user (if not exists)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_user WHERE usename = 'replication_user') THEN
    CREATE USER replication_user WITH REPLICATION PASSWORD 'replication_password';
    GRANT SELECT ON ALL TABLES IN SCHEMA public TO replication_user;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO replication_user;
  END IF;
END $$;

-- Verify publication
SELECT * FROM pg_publication;
SELECT * FROM pg_publication_tables WHERE pubname = 'analytics_pub';

-- On TARGET database (msvc_analytics_abms), run:
-- CREATE SUBSCRIPTION analytics_sub
--   CONNECTION 'host=postgres-abms dbname=msvc_abms user=replication_user password=replication_password'
--   PUBLICATION analytics_pub
--   WITH (copy_data = true, create_slot = true);
