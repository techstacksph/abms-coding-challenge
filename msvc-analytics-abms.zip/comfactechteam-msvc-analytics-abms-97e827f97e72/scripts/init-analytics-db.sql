-- Initialize Analytics Database
-- This script runs on first container startup

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Log initialization
DO $$
BEGIN
  RAISE NOTICE 'Analytics database initialized successfully';
  RAISE NOTICE 'Database: %', current_database();
  RAISE NOTICE 'User: %', current_user;
END $$;

-- Note: Actual table schema will be created by TypeORM migrations
-- or by logical replication from msvc_abms
