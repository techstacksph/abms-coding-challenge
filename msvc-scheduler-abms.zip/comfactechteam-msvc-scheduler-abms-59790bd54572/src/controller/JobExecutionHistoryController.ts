import {
  Body,
  Get,
  JsonController,
  Param,
  Post,
  QueryParam,
} from 'routing-controllers';
import Container from 'typedi';

import { JobExecutionStatus } from '../datasource/models/JobExecutionHistoryModel';
import {
  ExecutionHistoryQuery,
  JobExecutionHistoryService,
} from '../services/JobExecutionHistoryService';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1')
export class JobExecutionHistoryController {
  private jobExecutionHistoryService: JobExecutionHistoryService;

  constructor() {
    this.jobExecutionHistoryService = Container.get(JobExecutionHistoryService);
  }

  /**
   * GET /v1/job-execution-history
   * Get job execution history with optional filtering
   */
  @Get('/job-execution-history')
  public async getExecutionHistory(
    @QueryParam('jobId') jobId?: string,
    @QueryParam('jobName') jobName?: string,
    @QueryParam('status') status?: JobExecutionStatus,
    @QueryParam('startDate') startDate?: string,
    @QueryParam('endDate') endDate?: string,
    @QueryParam('limit') limit: number = 50,
    @QueryParam('offset') offset: number = 0
  ) {
    try {
      // Validate status if provided
      if (status && !Object.values(JobExecutionStatus).includes(status)) {
        return {
          error: true,
          message: `Invalid status. Valid values: ${Object.values(JobExecutionStatus).join(', ')}`,
        };
      }

      const query: ExecutionHistoryQuery = {
        jobId,
        jobName,
        status,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        limit,
        offset,
      };

      const executions =
        await this.jobExecutionHistoryService.getExecutionHistory(query);

      return {
        success: true,
        data: executions,
        meta: {
          count: executions.length,
          limit,
          offset,
        },
      };
    } catch (error) {
      logger.error('Failed to get execution history', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      return {
        error: true,
        message: 'Failed to get execution history',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * GET /v1/job-execution-history/:jobId
   * Get execution history for a specific job
   */
  @Get('/job-execution-history/:jobId')
  public async getJobExecutionHistory(
    @Param('jobId') jobId: string,
    @QueryParam('limit') limit: number = 50,
    @QueryParam('offset') offset: number = 0
  ) {
    try {
      const executions =
        await this.jobExecutionHistoryService.getJobExecutionHistory(
          jobId,
          limit,
          offset
        );

      return {
        success: true,
        data: executions,
        meta: {
          jobId,
          count: executions.length,
          limit,
          offset,
        },
      };
    } catch (error) {
      logger.error('Failed to get job execution history', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId,
      });

      return {
        error: true,
        message: 'Failed to get job execution history',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * GET /v1/job-execution-summary
   * Get execution summary for jobs
   */
  @Get('/job-execution-summary')
  public async getJobExecutionSummary(@QueryParam('jobIds') jobIds?: string) {
    try {
      let jobIdArray: string[] | undefined;
      if (jobIds) {
        jobIdArray = jobIds.split(',');
      }

      const summaries =
        await this.jobExecutionHistoryService.getJobExecutionSummary(
          jobIdArray
        );

      return {
        success: true,
        data: summaries,
        meta: {
          count: summaries.length,
        },
      };
    } catch (error) {
      logger.error('Failed to get job execution summary', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      return {
        error: true,
        message: 'Failed to get job execution summary',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * POST /v1/job-execution-history/cleanup
   * Clean up old execution records
   */
  @Post('/job-execution-history/cleanup')
  public async cleanupOldExecutions(
    @Body() body: { retentionDays?: number; batchSize?: number }
  ) {
    try {
      const { retentionDays = 30 } = body;

      const deletedCount =
        await this.jobExecutionHistoryService.cleanupOldExecutions(
          retentionDays
        );

      return {
        success: true,
        message: 'Old execution records cleaned up',
        data: {
          deletedCount,
          retentionDays,
        },
      };
    } catch (error) {
      logger.error('Failed to cleanup old execution records', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      return {
        error: true,
        message: 'Failed to cleanup old execution records',
        details: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
}
