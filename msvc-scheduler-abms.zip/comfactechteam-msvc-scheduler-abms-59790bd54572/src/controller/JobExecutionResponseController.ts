import { Response } from 'express';
import { Body, JsonController, Post, Res } from 'routing-controllers';
import Container from 'typedi';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { JobExecutionResponseDto } from '../dto/JobExecutionResponseDto';
import { JobExecutionHistoryService } from '../services/JobExecutionHistoryService';
import { JobExecutionResponseService } from '../services/JobExecutionResponseService';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1/job-execution')
export class JobExecutionResponseController {
  private jobExecutionResponseService: JobExecutionResponseService;
  private jobExecutionHistoryService: JobExecutionHistoryService;

  constructor() {
    this.jobExecutionResponseService = Container.get(
      JobExecutionResponseService
    );
    this.jobExecutionHistoryService = Container.get(JobExecutionHistoryService);
  }

  /**
   * Endpoint for target services to report job execution completion
   */
  @Post('/response')
  async handleJobExecutionResponse(
    @Body() response: JobExecutionResponseDto,
    @Res() res: Response
  ) {
    const startTime = Date.now();
    try {
      logger.info('Received job execution response', {
        correlationId: response.correlationId,
        jobId: response.jobId,
        status: response.status,
      });

      // Validate required fields
      if (!response.correlationId || !response.jobId || !response.status) {
        const duration = Date.now() - startTime;
        logger.warn('Job execution response validation failed', {
          correlationId: response.correlationId,
          duration,
        });
        return res
          .status(400)
          .json(
            new ApiErrorResponseDto(
              400,
              'handle_job_execution_response',
              'ValidationError',
              'Missing required fields: correlationId, jobId, or status'
            )
          );
      }

      // Handle the response
      const handleStartTime = Date.now();
      const handled =
        this.jobExecutionResponseService.handleExecutionResponse(response);
      const handleDuration = Date.now() - handleStartTime;

      if (!handled) {
        const totalDuration = Date.now() - startTime;
        logger.warn('Job execution response correlation not found', {
          correlationId: response.correlationId,
          handleDuration,
          totalDuration,
        });
        return res
          .status(404)
          .json(
            new ApiErrorResponseDto(
              404,
              'handle_job_execution_response',
              'CorrelationNotFound',
              `No pending execution found for correlation ID: ${response.correlationId}`
            )
          );
      }

      // Record execution completion in history
      try {
        const historyStartTime = Date.now();
        await this.jobExecutionHistoryService.recordExecutionComplete(
          response.correlationId,
          response
        );
        const historyDuration = Date.now() - historyStartTime;
        const totalDuration = Date.now() - startTime;

        logger.info('Job execution response processed successfully', {
          correlationId: response.correlationId,
          jobId: response.jobId,
          status: response.status,
          handleDuration,
          historyDuration,
          totalDuration,
        });
      } catch (historyError) {
        const historyDuration =
          Date.now() - (Date.now() - startTime + handleDuration);
        const totalDuration = Date.now() - startTime;
        logger.error('Failed to record job execution history', {
          error:
            historyError instanceof Error
              ? historyError.message
              : 'Unknown error',
          correlationId: response.correlationId,
          jobId: response.jobId,
          handleDuration,
          historyDuration,
          totalDuration,
        });
        // Don't fail the response if history recording fails
      }

      return res.status(200).json({
        success: true,
        message: 'Job execution response processed successfully',
        correlationId: response.correlationId,
      });
    } catch (error) {
      logger.error('Failed to handle job execution response', {
        error: error instanceof Error ? error.message : 'Unknown error',
        response,
      });

      return res
        .status(500)
        .json(
          new ApiErrorResponseDto(
            500,
            'handle_job_execution_response',
            'InternalServerError',
            'Failed to process job execution response'
          )
        );
    }
  }

  /**
   * Health check endpoint to monitor pending executions
   */
  @Post('/status')
  async getExecutionStatus(@Res() res: Response) {
    try {
      const pendingExecutions =
        this.jobExecutionResponseService.getPendingExecutions();

      return res.status(200).json({
        pendingExecutions: pendingExecutions.length,
        executions: pendingExecutions,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('Failed to get execution status', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });

      return res
        .status(500)
        .json(
          new ApiErrorResponseDto(
            500,
            'get_execution_status',
            'InternalServerError',
            'Failed to retrieve execution status'
          )
        );
    }
  }
}
