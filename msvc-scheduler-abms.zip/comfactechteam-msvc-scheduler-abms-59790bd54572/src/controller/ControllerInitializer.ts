import { Service } from 'typedi';

import { HomeController } from './HomeController';
import { JobExecutionHistoryController } from './JobExecutionHistoryController';
import { JobExecutionResponseController } from './JobExecutionResponseController';
import { ScheduledJobController } from './ScheduledJobController';

@Service()
export class ControllerInitializer {
  // eslint-disable-next-line @typescript-eslint/ban-types
  controllers(): Function[] | string[] {
    return [
      HomeController,
      ScheduledJobController,
      JobExecutionResponseController,
      JobExecutionHistoryController,
    ];
  }
}
