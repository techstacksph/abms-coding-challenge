import { Get, JsonController } from 'routing-controllers';
import { OpenAPI } from 'routing-controllers-openapi';
import Container from 'typedi';

import { appDataSource } from '../datasource/config/database';
import environment from '../environment';
import { BullMQManager } from '../queue/BullMQManager';
import { ScheduledJobService } from '../services/ScheduledJobService';

@JsonController('/v1/home')
export class HomeController {
  @Get('/status')
  async status() {
    return { message: 'GOOD TO GO', server_name: environment.APP_HOST_NAME };
  }

  @Get('/server-time')
  async getServerTime() {
    const now = new Date();
    return {
      serverTime: {
        iso: now.toISOString(),
        utc: now.toUTCString(),
        timestamp: now.getTime(),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        local: now.toLocaleString(),
      },
      message: 'Server time information',
    };
  }

  @Get('/health')
  @OpenAPI({ summary: 'Comprehensive health check endpoint' })
  async health(): Promise<any> {
    try {
      const bullmqManager = Container.get(BullMQManager);
      const scheduledJobService = Container.get(ScheduledJobService);

      // Check database connection
      await appDataSource.query('SELECT 1');

      // Check Redis/BullMQ connection
      const queues = bullmqManager.getAllQueues();
      const queueHealth = await Promise.all(
        queues.map(async (q) => ({
          name: q.name,
          status: (q as any).client?.status === 'ready' ? 'healthy' : 'unhealthy',
        }))
      );

      // Check job statistics
      const stats = await scheduledJobService.getJobStatistics();

      return {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        timezone: process.env.TZ || 'UTC',
        database: 'connected',
        queues: queueHealth,
        jobs: {
          total: stats.total,
          scheduled: stats.byStatus.SCHEDULED,
          running: stats.byStatus.RUNNING,
          failed: stats.byStatus.FAILED,
          overdue: stats.overdue,
        },
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  @Get('/health/ready')
  @OpenAPI({ summary: 'Readiness check for Kubernetes/ECS' })
  async ready(): Promise<{ ready: boolean; timestamp: string }> {
    try {
      // Check if database is accessible
      await appDataSource.query('SELECT 1');
      return {
        ready: true,
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      return {
        ready: false,
        timestamp: new Date().toISOString(),
      };
    }
  }

  @Get('/health/live')
  @OpenAPI({ summary: 'Liveness check for Kubernetes/ECS' })
  async live(): Promise<{ alive: boolean; timestamp: string }> {
    return {
      alive: true,
      timestamp: new Date().toISOString(),
    };
  }
}
