import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  Delete,
  Get,
  JsonController,
  Param,
  Post,
  Put,
  QueryParam,
  Res,
} from 'routing-controllers';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { FunctionJobDataDto } from '../dto/FunctionJobDataDto';
import { RecurringJobConfigDto } from '../dto/JobDto';
import { RecurringType } from '../enums/RecurringJobEnum';
import { ScheduledJobService } from '../services/ScheduledJobService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@JsonController('/v1/jobs')
export class ScheduledJobController {
  constructor(private scheduledJobService: ScheduledJobService) {}

  @Authorized()
  @Get('/search')
  async searchJobs(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @QueryParam('name') name: string
  ) {
    logger.debug('scheduled_job_controller_search_running', { name });
    try {
      const result = await this.scheduledJobService.searchJobsByName(name);
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'search_scheduled_jobs',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post()
  async createJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() jobConfig: RecurringJobConfigDto
  ) {
    const startTime = Date.now();
    logger.debug('scheduled_job_controller_create_running', {
      jobName: jobConfig.name,
    });

    const errors: ValidationError[] = await validate(jobConfig);
    if (errors.length) {
      const duration = Date.now() - startTime;
      logger.warn('Job creation failed validation', {
        jobName: jobConfig.name,
        duration,
        errorCount: errors.length,
      });
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const searchStartTime = Date.now();
      // Check if a job with the same name already exists
      const existingJobs = await this.scheduledJobService.searchJobsByName(
        jobConfig.name
      );
      const searchDuration = Date.now() - searchStartTime;

      if (existingJobs.length > 0) {
        const totalDuration = Date.now() - startTime;
        logger.warn('Job creation failed - name exists', {
          jobName: jobConfig.name,
          searchDuration,
          totalDuration,
        });
        return res
          .status(409)
          .send(
            new ApiErrorResponseDto(
              409,
              'create_scheduled_job',
              'JobNameAlreadyExists',
              `A job with the name '${jobConfig.name}' already exists`
            )
          );
      }

      const createStartTime = Date.now();
      const result =
        await this.scheduledJobService.createRecurringJob(jobConfig);
      const createDuration = Date.now() - createStartTime;
      const totalDuration = Date.now() - startTime;

      logger.info('Job creation successful', {
        jobName: jobConfig.name,
        jobId: result.id,
        searchDuration,
        createDuration,
        totalDuration,
      });

      return result;
    } catch (error) {
      const totalDuration = Date.now() - startTime;
      const errorNumber = toHttpErrorCode(error, 500);
      logger.error('Job creation failed with error', {
        jobName: jobConfig.name,
        totalDuration,
        error: error instanceof Error ? error.message : String(error),
      });
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'create_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Get('/statistics')
  async getStatistics(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    logger.debug('scheduled_job_controller_get_statistics_running');
    try {
      const result = await this.scheduledJobService.getJobStatistics();
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_job_statistics',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Get('/:id')
  async getJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string
  ) {
    logger.debug('scheduled_job_controller_get_running', { id });
    try {
      const result = await this.scheduledJobService.getJobById(id);
      if (!result) {
        return res
          .status(404)
          .send(
            new ApiErrorResponseDto(
              404,
              'get_scheduled_job',
              'JobNotFound',
              `Job with id ${id} not found`
            )
          );
      }
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Get()
  async getAllJobs(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    logger.debug('scheduled_job_controller_get_all_running');
    try {
      const result = await this.scheduledJobService.getAllJobs();
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_all_scheduled_jobs',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Put('/:id')
  async updateJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string,
    @Body() jobConfig: Partial<RecurringJobConfigDto>
  ) {
    logger.debug('scheduled_job_controller_update_running', { id });
    const errors: ValidationError[] = await validate(jobConfig);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const result = await this.scheduledJobService.updateJob(id, jobConfig);
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Delete('/:id')
  async deleteJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string
  ) {
    logger.debug('scheduled_job_controller_delete_running', { id });
    try {
      const result = await this.scheduledJobService.deleteJob(id);
      if (!result) {
        return res
          .status(404)
          .send(
            new ApiErrorResponseDto(
              404,
              'delete_scheduled_job',
              'JobNotFound',
              `Job with id ${id} not found`
            )
          );
      }
      return { success: true };
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'delete_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post('/one-time')
  async createOneTimeJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() jobConfig: RecurringJobConfigDto
  ) {
    logger.debug('scheduled_job_controller_create_one_time_running');
    const errors: ValidationError[] = await validate(jobConfig);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      // Check if a job with the same name already exists
      const existingJobs = await this.scheduledJobService.searchJobsByName(
        jobConfig.name
      );
      if (existingJobs.length > 0) {
        return res
          .status(409)
          .send(
            new ApiErrorResponseDto(
              409,
              'create_one_time_job',
              'JobNameAlreadyExists',
              `A job with the name '${jobConfig.name}' already exists`
            )
          );
      }

      // Create one-time job (executes in 2 minutes)
      logger.info('[Job Schedule] Creating one-time job', {
        jobName: jobConfig.name,
      });

      const result = await this.scheduledJobService.createOneTimeJob(
        jobConfig.name,
        jobConfig.description,
        jobConfig.jobData
      );
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'create_one_time_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post('/one-time/scheduled')
  async createOneTimeScheduledJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() jobConfig: {
      name: string;
      description?: string;
      jobData: FunctionJobDataDto;
      executionTime: string;
    }
  ) {
    logger.debug('scheduled_job_controller_create_one_time_scheduled_running');

    try {
      // Validate execution time
      const executionTime = new Date(jobConfig.executionTime);
      if (isNaN(executionTime.getTime())) {
        return res
          .status(400)
          .send(
            new ApiErrorResponseDto(
              400,
              'create_one_time_scheduled_job',
              'InvalidExecutionTime',
              'Invalid executionTime format. Must be a valid ISO date string.'
            )
          );
      }

      if (executionTime <= new Date()) {
        return res
          .status(400)
          .send(
            new ApiErrorResponseDto(
              400,
              'create_one_time_scheduled_job',
              'InvalidExecutionTime',
              'Execution time must be in the future'
            )
          );
      }

      // Check if a job with the same name already exists
      const existingJobs = await this.scheduledJobService.searchJobsByName(
        jobConfig.name
      );
      if (existingJobs.length > 0) {
        return res
          .status(409)
          .send(
            new ApiErrorResponseDto(
              409,
              'create_one_time_scheduled_job',
              'JobNameAlreadyExists',
              `A job with the name '${jobConfig.name}' already exists`
            )
          );
      }

      // Create one-time scheduled job (executes at specific time)
      logger.info('[Job Schedule] Creating one-time scheduled job', {
        jobName: jobConfig.name,
        executionTime: executionTime.toISOString(),
      });

      const result = await this.scheduledJobService.createOneTimeScheduledJob(
        jobConfig.name,
        jobConfig.description,
        jobConfig.jobData,
        executionTime
      );
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'create_one_time_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post('/:id/retry')
  async retryJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string
  ) {
    logger.debug('scheduled_job_controller_retry_running', { id });
    try {
      const result = await this.scheduledJobService.retryJob(id);
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'retry_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post('/:id/pause')
  async pauseJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string
  ) {
    logger.debug('scheduled_job_controller_pause_running', { id });
    try {
      const result = await this.scheduledJobService.pauseJob(id);
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'pause_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Post('/:id/resume')
  async resumeJob(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('id') id: string
  ) {
    logger.debug('scheduled_job_controller_resume_running', { id });
    try {
      const result = await this.scheduledJobService.resumeJob(id);
      return result;
    } catch (error) {
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'resume_scheduled_job',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
