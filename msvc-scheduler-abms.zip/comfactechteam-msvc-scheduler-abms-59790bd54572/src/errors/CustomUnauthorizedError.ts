import { UnauthorizedError } from 'routing-controllers';

export class CustomUnauthorizedError extends UnauthorizedError {
  constructor(msg: string) {
    super(msg);
    Object.setPrototypeOf(this, CustomUnauthorizedError.prototype);
    super.stack = undefined;
  }
}
