import swaggerJSDoc from 'swagger-jsdoc';

import environment from '../environment';

const options: swaggerJSDoc.Options = {
  apis: ['./swagger-doc/**/*.yaml'],
  definition: {
    openapi: '3.0.0',
    servers: [
      {
        url: `${environment.SWAGGER_SCHEMES.split(',')[0]}://${environment.APP_HOST_NAME}`,
        description: 'API Server',
      },
    ],
    info: {
      description:
        'A background job scheduling service designed to manage, queue, and execute asynchronous jobs using Apache Pulsar, with execution times determined by CRON expressions or fixed intervals.',
      title: 'ABMS Scheduler',
      version: '1.0.0',
    },
    components: {
      securitySchemes: {
        SystemAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'Authorization',
          description:
            'Enter your system admin secret token (e.g., 79da9c36-ab2b-11ec-b909-0242ac120003)',
        },
      },
    },
    security: [
      {
        SystemAuth: [],
      },
    ],
  },
};

export default swaggerJSDoc(options);
