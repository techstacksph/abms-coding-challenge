/* eslint-disable no-unused-vars */
import { QueryFailedError } from 'typeorm';

import { ErrorKeyTypes } from './StaticMessageCodeUtils';

interface DatabaseDriverError extends Error {
  code?: string;
  detail?: string;
}

//  FIND A BETTER FUNCTION NAME HERE
export function friendlyError(error: unknown, source: string) {
  if (error instanceof QueryFailedError) {
    const err = error as QueryFailedError;
    const driverError = err.driverError as DatabaseDriverError;
    //console.log(err);
    throw new CustomError(
      driverError.code || '',
      driverError.detail || '',
      source,
      toErrorKeyType(driverError.code || ''),
      err.stack
    );
  } else {
    //console.log(error);
    throw error;
  }
}

export function toErrorKeyType(code: string): ErrorKeyTypes {
  switch (code) {
    case '23505':
      return ErrorKeyTypes.ENTITY_CONFLICT_ERROR;
    case '23502':
      return ErrorKeyTypes.NOT_NULL_VALIDATION_ERROR;
    default:
      return ErrorKeyTypes.INTERNAL_SERVER_ERROR;
  }
}

export function toHttpErrorCode(error: unknown, elseCode?: number): number {
  let errorCode: string | number = '';
  if (error instanceof CustomError) {
    errorCode = (error as CustomError).code;
  }
  if (error instanceof Error) {
    errorCode = error.message;
  }
  switch (errorCode) {
    case '23505':
      return 409;
    case '23502':
      return 400;
    case ErrorKeyTypes.INVALID_USER_EMAIL:
    case ErrorKeyTypes.INVALID_ORG_CODE:
    case ErrorKeyTypes.INVALID_CLIENT_KEY:
      return 404;
    case ErrorKeyTypes.INVALID_USER_CREDENTIAL:
    case ErrorKeyTypes.INVALID_REFRESH_TOKEN:
    case ErrorKeyTypes.REFRESH_TOKEN_EXPIRED:
      return 401;
    default:
      return elseCode ?? 500;
  }
}

export function getCustomErrorAdditionalMessage(
  error: Error | unknown
): string | undefined {
  if (error instanceof Error) {
    return error.message;
  } else {
    return undefined;
  }
}

export function getCustomErrorName(error: Error | unknown) {
  if (error instanceof CustomError) {
    return error.name;
  } else {
    return (error as Error).message;
  }
}

export class CustomError extends Error {
  constructor(
    code: number | string,
    message: string,
    source: string,
    errorName: ErrorKeyTypes,
    detail?: unknown
  ) {
    super(message);
    this.name = errorName;
    this.source = source;
    this.detail = detail;
    this.code = code;
  }
  source!: string;
  detail?: unknown;
  code!: number | string;
}
