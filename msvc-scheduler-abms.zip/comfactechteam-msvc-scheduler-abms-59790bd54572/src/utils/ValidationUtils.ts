import { NextFunction, Request, Response } from 'express';
import { validationResult } from 'express-validator';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';

const validate = (req: Request, res: Response, next: NextFunction) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }

  const extractedErrors: unknown[] = [];
  errors.array().map((err) =>
    extractedErrors.push({
      [err.msg]: err.msg,
      value: err.msg.value ? err.msg.value : '',
    })
  );

  const apiErrorResponse = new ApiErrorResponseDto(
    400,
    'validation',
    extractedErrors
  );

  return res.status(400).send(apiErrorResponse);
};

export default validate;
