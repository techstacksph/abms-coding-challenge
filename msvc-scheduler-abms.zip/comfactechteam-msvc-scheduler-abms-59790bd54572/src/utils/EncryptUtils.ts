import bcrypt from 'bcrypt';
import * as crypto from 'crypto';

import environment from '../environment';

const ALGO = 'aes-256-cbc';
const ENCRYPTION_KEY = environment.ENCRYPTION_KEY;
const SALT_ROUND = 10;

export function encrypt(val: string): string {
  if (!val) {
    throw Error('Value to encrypt is required!');
  }

  const iv = crypto.randomBytes(16);

  const cipher = crypto.createCipheriv(ALGO, Buffer.from(ENCRYPTION_KEY), iv);
  let encrypted = cipher.update(val);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return `${iv.toString('hex')}:${encrypted.toString('hex')}`;
}

export function decrypt(val: string): string {
  if (!val) {
    throw Error('Value to decrypt is required!');
  }
  const encryptedArray = val.split(':');
  const iv = Buffer.from(encryptedArray[0], 'hex');
  const encryptedVal = Buffer.from(encryptedArray[1], 'hex');
  const decipher = crypto.createDecipheriv(
    ALGO,
    Buffer.from(ENCRYPTION_KEY),
    iv
  );
  let decrypted = decipher.update(encryptedVal);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

export async function hash(val: string): Promise<string> {
  if (!val) {
    throw Error('Value to hash is required!');
  }
  const hashed = await bcrypt.hash(val, SALT_ROUND);
  return hashed;
}

export async function validHash(
  val: string,
  hashedVal: string
): Promise<boolean> {
  const result = await bcrypt.compare(val, hashedVal);
  return result;
}
