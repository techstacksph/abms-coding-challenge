/* eslint-disable @typescript-eslint/no-unused-vars */
import 'reflect-metadata';

import cookieParser from 'cookie-parser';
import express, { Application } from 'express';
import { Action, useContainer, useExpressServer } from 'routing-controllers';
import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { ControllerInitializer } from '../controller/ControllerInitializer';
import { appDataSource } from '../datasource/config/database';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { httpLogger, logger } from './LoggerUtils';

@Service()
export class AppServerUtils {
  private app: Application;

  constructor() {
    this.app = express();
  }

  async startServer(): Promise<Application> {
    await appDataSource.initialize();
    if (appDataSource.isInitialized) {
      logger.debug(`database_initialized`, {
        status: appDataSource.isInitialized ? 'connected' : 'not_connected',
      });
      this.initExpress();
    }
    return this.app;
  }

  initExpress() {
    useContainer(Container);
    this.app.use(httpLogger);
    this.app.use(cookieParser());
    this.app.use(express.json());

    const controllerInitializer: ControllerInitializer = Container.get(
      ControllerInitializer
    );

    useExpressServer(this.app, {
      authorizationChecker: async (action: Action): Promise<boolean> => {
        // THIS IS FOR UNIT TEST APPLY AUTHENTICATION HERE IF ANY
        return Promise.resolve(true);
      },
      controllers: controllerInitializer.controllers(),
      cors: true,
      currentUserChecker: async (
        action: Action
      ): Promise<ClientAuthenticationDto> => {
        // THIS IS FOR UNIT TEST APPLY AUTHENTICATION HERE IF ANY
        return {
          PERMISSION: {},
          ROLE: 'authenticated-userole',
          USER_ID: uuidv4().toString(),
          USER_NAME: 'authenticated-username',
        };
      },
      validation: false,
    });
  }
}
