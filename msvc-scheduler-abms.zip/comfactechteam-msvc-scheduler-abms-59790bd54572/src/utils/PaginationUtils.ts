export function computePageCount(totalRow: number, pageSize: number): number {
  let pageCount = 0;
  pageCount = totalRow > 0 ? totalRow / pageSize : 0;
  pageCount = totalRow > 0 && pageCount < 1 ? 1 : pageCount;
  pageCount =
    pageCount % 1 > 0 && pageCount % 1 < 0.5
      ? Math.round(pageCount) + 1
      : Math.round(pageCount);
  return pageCount;
}

export const DEFAULT_LIMIT = 5;
export const DEFAULT_OFFSET = 0;
