import 'reflect-metadata';

import { Service } from 'typedi';

import { PulsarMessageDto } from '../dto/PulsarMessageDto';
import { logger } from '../utils/LoggerUtils';

@Service()
export class PulsarConsumerService {
  async processMessage(message: PulsarMessageDto): Promise<boolean> {
    logger.debug('pulsar_processor', { message });

    switch (message.action) {
      default:
        break;
    }

    return Promise.resolve(false);
  }
}
