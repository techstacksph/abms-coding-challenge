import 'reflect-metadata';

import { Service } from 'typedi';
import { Repository } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';

import { appDataSource } from '../datasource/config/database';
import { RecurringJobModel } from '../datasource/models/RecurringJobModel';
import { FunctionJobDataDto } from '../dto/FunctionJobDataDto';
import { RecurringJobConfigDto } from '../dto/JobDto';
import { JobStatus, RecurringType } from '../enums/RecurringJobEnum';
import { JobQueue } from '../queue/JobQueue';
import { logger } from '../utils/LoggerUtils';

/**
 * ScheduledJobService - Refactored to use BullMQ instead of Pulsar
 * ABMS-3525: Migrated from Pulsar to BullMQ for job scheduling
 */
@Service()
export class ScheduledJobService {
  private jobRepository: Repository<RecurringJobModel>;

  constructor(private readonly jobQueue: JobQueue) {
    this.jobRepository = appDataSource.getRepository(RecurringJobModel);
  }

  /**
   * Create a new recurring job
   * BullMQ handles scheduling automatically based on CRON/INTERVAL pattern
   */
  async createRecurringJob(
    config: RecurringJobConfigDto
  ): Promise<RecurringJobModel> {
    const job = this.jobRepository.create({
      ...config,
      id: uuidv4(),
      status: JobStatus.SCHEDULED,
      topic: config.topic || config.jobData?.source || undefined,
    });

    logger.info('[Job Schedule] [createRecurringJob] job', { job });

    // Save job to database
    await this.jobRepository.save(job);

    // Add job to BullMQ queue (replaces Pulsar scheduling)
    try {
      await this.jobQueue.addRecurringJob(job);
      logger.info('[Job Schedule] Job added to BullMQ successfully', {
        jobId: job.id,
        jobName: job.name,
      });
    } catch (error) {
      logger.error('[Job Schedule] Failed to add job to BullMQ', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId: job.id,
      });
      // Rollback database save
      await this.jobRepository.delete(job.id);
      throw error;
    }

    return job;
  }

  /**
   * Create a one-time scheduled job (executes at specific time)
   */
  async createOneTimeScheduledJob(
    name: string,
    description: string | undefined,
    jobData: FunctionJobDataDto,
    executionTime: Date
  ): Promise<RecurringJobModel> {
    const jobId = uuidv4();

    // Calculate delay until execution time
    const now = new Date();
    const delayMs = executionTime.getTime() - now.getTime();
    
    if (delayMs <= 0) {
      throw new Error('Execution time must be in the future');
    }

    // For one-time jobs, we use INTERVAL with a very large value and endDate
    // The actual scheduling is handled by JobQueue.addOneTimeScheduledJob using BullMQ delay
    const job = this.jobRepository.create({
      id: jobId,
      name,
      description,
      jobData,
      recurringType: RecurringType.INTERVAL, // Required by DB schema
      recurringPattern: '999999999999', // Very large interval (won't repeat due to endDate)
      endDate: new Date(executionTime.getTime() + 60000), // End 1 minute after execution
      status: JobStatus.SCHEDULED,
      maxRetries: 3,
      topic: jobData.source,
    });

    await this.jobRepository.save(job);

    try {
      // The JobQueue handles the actual one-time scheduling with BullMQ delay
      await this.jobQueue.addOneTimeScheduledJob(jobId, jobData, executionTime);
      logger.info('[Job Schedule] One-time scheduled job created', {
        jobId,
        executionTime: executionTime.toISOString(),
        delayMs,
      });
    } catch (error) {
      logger.error('[Job Schedule] Failed to schedule one-time job', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId,
      });
      await this.jobRepository.delete(jobId);
      throw error;
    }

    return job;
  }

  /**
   * Create a quick one-time job (executes in 2 minutes)
   */
  async createOneTimeJob(
    name: string,
    description: string | undefined,
    jobData: FunctionJobDataDto
  ): Promise<RecurringJobModel> {
    const executionTime = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes
    return this.createOneTimeScheduledJob(
      name,
      description,
      jobData,
      executionTime
    );
  }

  /**
   * Get all recurring jobs
   */
  async getAllJobs(): Promise<RecurringJobModel[]> {
    return this.jobRepository.find();
  }

  /**
   * Get a specific job by ID
   */
  async getJobById(id: string): Promise<RecurringJobModel | null> {
    return this.jobRepository.findOneBy({ id });
  }

  /**
   * Update a recurring job
   * BullMQ will automatically reschedule based on new pattern
   */
  async updateJob(
    id: string,
    config: Partial<RecurringJobConfigDto>
  ): Promise<RecurringJobModel> {
    const job = await this.jobRepository.findOneBy({ id });
    if (!job) {
      throw new Error(`[Job Schedule] [updateJob] Job not found: ${id}`);
    }

    Object.assign(job, config);

    // Update topic if jobData.source changed or if topic is explicitly provided
    if (config.topic !== undefined || config.jobData?.source) {
      job.topic = config.topic || config.jobData?.source || job.topic;
    }

    await this.jobRepository.save(job);

    // Update job in BullMQ (remove old, add new)
    try {
      await this.jobQueue.updateRecurringJob(job);
      logger.info('[Job Schedule] Job updated in BullMQ', {
        jobId: job.id,
        jobName: job.name,
      });
    } catch (error) {
      logger.error('[Job Schedule] Failed to update job in BullMQ', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId: job.id,
      });
      throw error;
    }

    return job;
  }

  /**
   * Delete a recurring job
   */
  async deleteJob(id: string): Promise<boolean> {
    // Remove from BullMQ first
    try {
      await this.jobQueue.removeJob(id);
      logger.info('[Job Schedule] Job removed from BullMQ', { jobId: id });
    } catch (error) {
      logger.warn('[Job Schedule] Failed to remove job from BullMQ', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId: id,
      });
      // Continue with database deletion even if BullMQ removal fails
    }

    // Remove from database
    const result = await this.jobRepository.delete(id);
    return (result.affected ?? 0) > 0;
  }

  /**
   * Pause a recurring job
   */
  async pauseJob(id: string): Promise<RecurringJobModel> {
    const job = await this.jobRepository.findOneBy({ id });
    if (!job) {
      throw new Error(`[Job Schedule] [pauseJob] Job not found: ${id}`);
    }

    job.status = JobStatus.PAUSED;
    await this.jobRepository.save(job);

    // Remove from BullMQ (paused jobs shouldn't execute)
    await this.jobQueue.removeJob(id);

    logger.info('[Job Schedule] Job paused', { jobId: id });
    return job;
  }

  /**
   * Resume a paused job
   */
  async resumeJob(id: string): Promise<RecurringJobModel> {
    const job = await this.jobRepository.findOneBy({ id });
    if (!job) {
      throw new Error(`Job not found: ${id}`);
    }

    job.status = JobStatus.SCHEDULED;
    await this.jobRepository.save(job);

    // Re-add to BullMQ
    await this.jobQueue.addRecurringJob(job);

    logger.info('[Job Schedule] Job resumed', { jobId: id });
    return job;
  }

  /**
   * Retry a failed job (reset retry counter and reschedule)
   */
  async retryJob(id: string): Promise<RecurringJobModel> {
    const job = await this.jobRepository.findOneBy({ id });
    if (!job) {
      throw new Error(`[Job Schedule] [retryJob] Job not found: ${id}`);
    }

    if (job.status !== JobStatus.FAILED) {
      throw new Error(
        `Job ${id} is not in FAILED status. Current status: ${job.status}`
      );
    }

    // Reset retry counter and schedule immediate execution
    job.currentRetries = 0;
    job.status = JobStatus.SCHEDULED;

    await this.jobRepository.save(job);

    // Re-add to BullMQ with immediate execution (5 seconds)
    await this.jobQueue.removeJob(id);
    await this.jobQueue.addRecurringJob(job);

    logger.info('Job scheduled for retry', { jobId: job.id });

    return job;
  }

  /**
   * Search jobs by name
   */
  async searchJobsByName(name: string): Promise<RecurringJobModel[]> {
    const startTime = Date.now();
    logger.info('[Job Schedule] [searchJobsByName] starting', { name });

    try {
      const result = await this.jobRepository.findBy({ name });
      const duration = Date.now() - startTime;
      logger.info('[Job Schedule] [searchJobsByName] completed', {
        duration,
        name,
        resultCount: result.length,
      });
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error('[Job Schedule] [searchJobsByName] failed', {
        duration,
        error: error instanceof Error ? error.message : String(error),
        name,
      });
      throw error;
    }
  }

  /**
   * Find jobs that have been running for too long (stuck jobs)
   * Note: BullMQ has built-in stalled job detection, this is for database records
   */
  async findStuckJobs(
    stuckThresholdMs: number = 600000
  ): Promise<RecurringJobModel[]> {
    const thresholdTime = new Date(Date.now() - stuckThresholdMs);

    const stuckJobs = await this.jobRepository
      .createQueryBuilder('job')
      .where('job.status = :status', { status: JobStatus.RUNNING })
      .andWhere('job.lastRunTime < :threshold', { threshold: thresholdTime })
      .getMany();

    logger.warn('Found stuck jobs', {
      count: stuckJobs.length,
      stuckThresholdMs,
      thresholdTime,
    });

    return stuckJobs;
  }

  /**
   * Recover stuck jobs by marking them as failed
   * Note: BullMQ handles this automatically, but we keep for database cleanup
   */
  async recoverStuckJobs(stuckThresholdMs: number = 600000): Promise<number> {
    const stuckJobs = await this.findStuckJobs(stuckThresholdMs);

    for (const job of stuckJobs) {
      logger.warn('Recovering stuck job', {
        jobId: job.id,
        lastRunTime: job.lastRunTime,
        stuckDuration: Date.now() - (job.lastRunTime?.getTime() || 0),
      });

      // Mark as failed so it can be retried
      job.status = JobStatus.FAILED;
      job.currentRetries = job.maxRetries; // Prevent automatic retry
      await this.jobRepository.save(job);
    }

    logger.info('Recovered stuck jobs', { count: stuckJobs.length });
    return stuckJobs.length;
  }

  /**
   * Get job statistics
   */
  async getJobStatistics(): Promise<{
    total: number;
    byStatus: Record<JobStatus, number>;
    overdue: number;
  }> {
    const jobs = await this.jobRepository.find();
    const now = new Date();

    const stats = {
      byStatus: {
        [JobStatus.SCHEDULED]: 0,
        [JobStatus.RUNNING]: 0,
        [JobStatus.COMPLETED]: 0,
        [JobStatus.FAILED]: 0,
        [JobStatus.PAUSED]: 0,
      } as Record<JobStatus, number>,
      overdue: 0,
      total: jobs.length,
    };

    for (const job of jobs) {
      const status = job.status as JobStatus;
      stats.byStatus[status]++;

      // Count overdue jobs (scheduled but past nextRunTime)
      if (
        job.status === JobStatus.SCHEDULED &&
        job.nextRunTime &&
        job.nextRunTime < now
      ) {
        stats.overdue++;
      }
    }

    return stats;
  }

  /**
   * Reschedule all existing SCHEDULED jobs on startup
   * BullMQ persists jobs in Redis, so this is mainly for syncing database state
   */
  async rescheduleExistingJobs(): Promise<number> {
    logger.info(
      '[Job Schedule] [rescheduleExistingJobs] Starting job recovery process'
    );

    try {
      // Find all scheduled jobs that should be running
      const scheduledJobs = await this.jobRepository
        .createQueryBuilder('job')
        .where('job.status = :status', { status: JobStatus.SCHEDULED })
        .getMany();

      logger.info(
        '[Job Schedule] [rescheduleExistingJobs] Found scheduled jobs',
        {
          count: scheduledJobs.length,
        }
      );

      let rescheduledCount = 0;

      for (const job of scheduledJobs) {
        try {
          // Re-add to BullMQ (will recreate if doesn't exist)
          await this.jobQueue.addRecurringJob(job);
          rescheduledCount++;

          logger.info(
            '[Job Schedule] [rescheduleExistingJobs] Rescheduled job',
            {
              jobId: job.id,
              jobName: job.name,
            }
          );
        } catch (error) {
          logger.error(
            '[Job Schedule] [rescheduleExistingJobs] Failed to reschedule job',
            {
              error: error instanceof Error ? error.message : 'Unknown error',
              jobId: job.id,
              jobName: job.name,
            }
          );
        }
      }

      logger.info(
        '[Job Schedule] [rescheduleExistingJobs] Job recovery completed',
        {
          rescheduledJobs: rescheduledCount,
          totalJobs: scheduledJobs.length,
        }
      );

      return rescheduledCount;
    } catch (error) {
      logger.error(
        '[Job Schedule] [rescheduleExistingJobs] Job recovery failed',
        {
          error: error instanceof Error ? error.message : 'Unknown error',
        }
      );
      throw error;
    }
  }
}
