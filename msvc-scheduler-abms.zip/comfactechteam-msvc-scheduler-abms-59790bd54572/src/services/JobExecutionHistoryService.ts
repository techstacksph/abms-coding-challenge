import { Service } from 'typedi';
import { Repository } from 'typeorm';

import { appDataSource } from '../datasource/config/database';
import {
  JobExecutionHistoryModel,
  JobExecutionStatus,
} from '../datasource/models/JobExecutionHistoryModel';
import { JobExecutionResponseDto } from '../dto/JobExecutionResponseDto';
import { logger } from '../utils/LoggerUtils';

export interface JobExecutionSummary {
  jobId: string;
  jobName?: string;
  totalExecutions: number;
  successfulExecutions: number;
  failedExecutions: number;
  lastExecution?: Date;
  lastStatus?: JobExecutionStatus;
  averageDuration?: number;
}

export interface ExecutionHistoryQuery {
  jobId?: string;
  jobName?: string;
  status?: JobExecutionStatus;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}

@Service()
export class JobExecutionHistoryService {
  private repository: Repository<JobExecutionHistoryModel>;

  constructor() {
    this.repository = appDataSource.getRepository(JobExecutionHistoryModel);
  }

  getRepository(): Repository<JobExecutionHistoryModel> {
    return this.repository;
  }

  /**
   * Record the start of a job execution
   */
  async recordExecutionStart(
    jobId: string,
    correlationId: string,
    jobName?: string,
    attempt: number = 1,
    maxRetries: number = 3,
    metadata?: object
  ): Promise<JobExecutionHistoryModel> {
    const execution = this.repository.create({
      jobId,
      correlationId,
      jobName,
      status: JobExecutionStatus.STARTED,
      executionStartTime: new Date(),
      attempt,
      maxRetries,
      metadata,
    });

    const saved = await this.repository.save(execution);

    logger.info('Recorded job execution start', {
      executionId: saved.id,
      jobId,
      correlationId,
      attempt,
    });

    return saved;
  }

  /**
   * Record the completion of a job execution
   */
  async recordExecutionComplete(
    correlationId: string,
    response: JobExecutionResponseDto
  ): Promise<JobExecutionHistoryModel | null> {
    const startTime = Date.now();

    const findStartTime = Date.now();
    const execution = await this.repository.findOne({
      where: { correlationId },
    });
    const findDuration = Date.now() - findStartTime;

    if (!execution) {
      const totalDuration = Date.now() - startTime;
      logger.warn('Execution record not found for completion', {
        correlationId,
        jobId: response.jobId,
        findDuration,
        totalDuration,
      });
      return null;
    }

    const endTime = new Date();
    const durationMs =
      endTime.getTime() - execution.executionStartTime.getTime();

    // Map response status to our enum
    let status: JobExecutionStatus;
    switch (response.status) {
      case 'SUCCESS':
        status = JobExecutionStatus.SUCCESS;
        break;
      case 'PARTIAL_SUCCESS':
        status = JobExecutionStatus.PARTIAL_SUCCESS;
        break;
      case 'FAILED':
        status = JobExecutionStatus.FAILED;
        break;
      default:
        status = JobExecutionStatus.FAILED;
    }

    // Update the execution record
    execution.status = status;
    execution.executionEndTime = endTime;
    execution.durationMs = durationMs;
    execution.itemsProcessed = response.result?.itemsProcessed;
    execution.itemsFailed = response.result?.itemsFailed;
    execution.errorMessage = response.error;
    execution.result = response.result;
    execution.metadata = {
      ...execution.metadata,
      ...response.metadata,
    };
    execution.executedBy = response.metadata?.executedBy;
    execution.logs = response.metadata?.logs;

    const saveStartTime = Date.now();
    const saved = await this.repository.save(execution);
    const saveDuration = Date.now() - saveStartTime;
    const totalDuration = Date.now() - startTime;

    logger.info('Recorded job execution completion', {
      executionId: saved.id,
      correlationId,
      status,
      durationMs,
      findDuration,
      saveDuration,
      totalDuration,
    });

    return saved;
  }

  /**
   * Record a timeout for a job execution
   */
  async recordExecutionTimeout(
    correlationId: string
  ): Promise<JobExecutionHistoryModel | null> {
    const execution = await this.repository.findOne({
      where: { correlationId },
    });

    if (!execution) {
      logger.warn('Execution record not found for timeout', { correlationId });
      return null;
    }

    const endTime = new Date();
    const durationMs =
      endTime.getTime() - execution.executionStartTime.getTime();

    execution.status = JobExecutionStatus.TIMEOUT;
    execution.executionEndTime = endTime;
    execution.durationMs = durationMs;
    execution.errorMessage = 'Job execution timed out';

    const saved = await this.repository.save(execution);

    logger.info('Recorded job execution timeout', {
      executionId: saved.id,
      correlationId,
      durationMs,
    });

    return saved;
  }

  /**
   * Get execution history for a specific job
   */
  async getJobExecutionHistory(
    jobId: string,
    limit: number = 50,
    offset: number = 0
  ): Promise<JobExecutionHistoryModel[]> {
    return this.repository.find({
      where: { jobId },
      order: { executionStartTime: 'DESC' },
      take: limit,
      skip: offset,
    });
  }

  /**
   * Get execution history with flexible filtering
   */
  async getExecutionHistory(
    query: ExecutionHistoryQuery
  ): Promise<JobExecutionHistoryModel[]> {
    const qb = this.repository.createQueryBuilder('execution');

    if (query.jobId) {
      qb.andWhere('execution.jobId = :jobId', { jobId: query.jobId });
    }

    if (query.jobName) {
      qb.andWhere('execution.jobName ILIKE :jobName', {
        jobName: `%${query.jobName}%`,
      });
    }

    if (query.status) {
      qb.andWhere('execution.status = :status', { status: query.status });
    }

    if (query.startDate) {
      qb.andWhere('execution.executionStartTime >= :startDate', {
        startDate: query.startDate,
      });
    }

    if (query.endDate) {
      qb.andWhere('execution.executionStartTime <= :endDate', {
        endDate: query.endDate,
      });
    }

    qb.orderBy('execution.executionStartTime', 'DESC');

    if (query.limit) {
      qb.take(query.limit);
    }

    if (query.offset) {
      qb.skip(query.offset);
    }

    return qb.getMany();
  }

  /**
   * Get execution summary for jobs
   */
  async getJobExecutionSummary(
    jobIds?: string[]
  ): Promise<JobExecutionSummary[]> {
    const qb = this.repository
      .createQueryBuilder('execution')
      .select([
        'execution.jobId as "jobId"',
        'execution.jobName as "jobName"',
        'COUNT(*) as "totalExecutions"',
        'COUNT(CASE WHEN execution.status = :successStatus THEN 1 END) as "successfulExecutions"',
        'COUNT(CASE WHEN execution.status IN (:...failureStatuses) THEN 1 END) as "failedExecutions"',
        'MAX(execution.executionStartTime) as "lastExecution"',
        'AVG(execution.durationMs) as "averageDuration"',
      ])
      .setParameters({
        successStatus: JobExecutionStatus.SUCCESS,
        failureStatuses: [
          JobExecutionStatus.FAILED,
          JobExecutionStatus.TIMEOUT,
        ],
      })
      .groupBy('execution.jobId, execution.jobName');

    if (jobIds && jobIds.length > 0) {
      qb.where('execution.jobId IN (:...jobIds)', { jobIds });
    }

    const results = await qb.getRawMany();

    // Get last status for each job
    const summaries: JobExecutionSummary[] = [];
    for (const result of results) {
      const lastExecution = await this.repository.findOne({
        where: { jobId: result.jobId },
        order: { executionStartTime: 'DESC' },
        select: ['status'],
      });

      summaries.push({
        jobId: result.jobId,
        jobName: result.jobName,
        totalExecutions: parseInt(result.totalExecutions),
        successfulExecutions: parseInt(result.successfulExecutions),
        failedExecutions: parseInt(result.failedExecutions),
        lastExecution: result.lastExecution,
        lastStatus: lastExecution?.status,
        averageDuration: result.averageDuration
          ? Math.round(result.averageDuration)
          : undefined,
      });
    }

    return summaries;
  }

  /**
   * Clean up old execution records
   */
  async cleanupOldExecutions(retentionDays: number = 30): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    const result = await this.repository
      .createQueryBuilder()
      .delete()
      .where('executionStartTime < :cutoffDate', { cutoffDate })
      .execute();

    logger.info('Cleaned up old job execution records', {
      deletedCount: result.affected,
      cutoffDate: cutoffDate.toISOString(),
    });

    return result.affected || 0;
  }
}
