import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';

import { JobExecutionResponseDto } from '../dto/JobExecutionResponseDto';
import { logger } from '../utils/LoggerUtils';

interface PendingExecution {
  correlationId: string;
  jobId: string;
  startTime: Date;
  timeoutHandle: NodeJS.Timeout;
  resolve: (response: JobExecutionResponseDto | null) => void;
  reject: (error: Error) => void;
}

@Service()
export class JobExecutionResponseService {
  private pendingExecutions = new Map<string, PendingExecution>();
  private readonly DEFAULT_TIMEOUT_MS = 300000; // 5 minutes

  /**
   * Create a correlation ID and register for response tracking
   */
  public createCorrelatedExecution(
    jobId: string,
    timeoutMs: number = this.DEFAULT_TIMEOUT_MS
  ): Promise<JobExecutionResponseDto | null> {
    const correlationId = uuidv4();

    return new Promise((resolve, reject) => {
      // Set timeout for response
      const timeoutHandle = setTimeout(() => {
        logger.warn('Job execution response timeout', {
          correlationId,
          jobId,
          timeoutMs,
        });

        this.pendingExecutions.delete(correlationId);
        resolve(null); // Return null on timeout instead of rejecting
      }, timeoutMs);

      // Store pending execution
      this.pendingExecutions.set(correlationId, {
        correlationId,
        jobId,
        startTime: new Date(),
        timeoutHandle,
        resolve,
        reject,
      });

      logger.info('Created correlated job execution', {
        correlationId,
        jobId,
        timeoutMs,
      });
    });
  }

  /**
   * Get correlation ID for job execution message
   */
  public getCorrelationId(jobId: string): string | null {
    for (const [correlationId, execution] of this.pendingExecutions) {
      if (execution.jobId === jobId) {
        return correlationId;
      }
    }
    return null;
  }

  /**
   * Handle response from target service
   */
  public handleExecutionResponse(response: JobExecutionResponseDto): boolean {
    const pending = this.pendingExecutions.get(response.correlationId);

    if (!pending) {
      logger.warn('Received response for unknown correlation ID', {
        correlationId: response.correlationId,
        jobId: response.jobId,
      });
      return false;
    }

    // Clear timeout
    clearTimeout(pending.timeoutHandle);

    // Remove from pending
    this.pendingExecutions.delete(response.correlationId);

    logger.info('Received job execution response', {
      correlationId: response.correlationId,
      jobId: response.jobId,
      status: response.status,
      duration: Date.now() - pending.startTime.getTime(),
    });

    // Resolve the promise
    pending.resolve(response);

    return true;
  }

  /**
   * Get all pending executions (for monitoring/debugging)
   */
  public getPendingExecutions(): Array<{
    correlationId: string;
    jobId: string;
    startTime: Date;
  }> {
    return Array.from(this.pendingExecutions.values()).map((p) => ({
      correlationId: p.correlationId,
      jobId: p.jobId,
      startTime: p.startTime,
    }));
  }

  /**
   * Clean up orphaned pending executions (older than max timeout)
   */
  public cleanupOrphanedExecutions(maxAgeMs: number = 600000): number {
    const cutoff = new Date(Date.now() - maxAgeMs);
    let cleaned = 0;

    for (const [correlationId, execution] of this.pendingExecutions) {
      if (execution.startTime < cutoff) {
        clearTimeout(execution.timeoutHandle);
        this.pendingExecutions.delete(correlationId);
        execution.resolve(null); // Resolve with null for cleanup
        cleaned++;

        logger.warn('Cleaned up orphaned job execution', {
          correlationId,
          jobId: execution.jobId,
          age: Date.now() - execution.startTime.getTime(),
        });
      }
    }

    if (cleaned > 0) {
      logger.info('Cleaned up orphaned job executions', { count: cleaned });
    }

    return cleaned;
  }
}
