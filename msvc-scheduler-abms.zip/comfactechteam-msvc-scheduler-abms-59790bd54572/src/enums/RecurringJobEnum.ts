export enum RecurringType {
  CRON = 'CRON',
  INTERVAL = 'INTERVAL',
}

export enum JobStatus {
  SCHEDULED = 'SCHEDULED',
  RUNNING = 'RUNNING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  PAUSED = 'PAUSED',
}
