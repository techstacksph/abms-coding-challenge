import environment from '../environment';

/* eslint-disable no-unused-vars */
export enum PulsarTopicsEnum {
  MICROSERVICE_APP_ID = 'AYR_SCHEDULER',
  BACK_OFFICE = 'AYR_BACK_OFFICE',
}

const MICROSERVICE_APP_ID = `${environment.ENVIRONMENT_NAME}.${PulsarTopicsEnum.MICROSERVICE_APP_ID}`;
const BACK_OFFICE_TOPIC = `${environment.ENVIRONMENT_NAME}.${PulsarTopicsEnum.BACK_OFFICE}`;

export const PulsarTopics = {
  MICROSERVICE_APP_ID: MICROSERVICE_APP_ID,
  BACK_OFFICE: BACK_OFFICE_TOPIC,
};
