/* eslint-disable no-unused-vars */
export enum ModelName {
  RECURRING_JOB = 'recurring_job',
}
