export enum JobDataType {
  EXECUTE_FUNCTION = 'EXECUTE_FUNCTION',
}
