import { PulsarDataAction } from '../enums/DataActionEnum';

export class PulsarMessageDto {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data!: any;
  action!: PulsarDataAction;
  subAction?: string;
  objectName?: string;

  /** Correlation ID for request/response tracking */
  correlationId?: string;

  /** Indicates if this message expects a response */
  expectsResponse?: boolean;

  /** Timeout for response in milliseconds */
  responseTimeoutMs?: number;
}
