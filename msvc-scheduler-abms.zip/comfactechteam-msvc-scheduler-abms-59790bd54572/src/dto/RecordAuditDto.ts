//  WILL BE USED FOR RECORD CREATED, UPDATED and DELETED (CUD)
export class RecordCUDDto {
  userId?: string;
  userName?: string;
}
