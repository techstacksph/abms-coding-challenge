import {
  IsEnum,
  IsNotEmpty,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';

import { JobDataType } from '../enums/JobDataTypeEnum';

export class FunctionJobDataDto {
  @IsEnum(JobDataType)
  @IsNotEmpty()
  type!: JobDataType;

  @IsString()
  @IsNotEmpty()
  source!: string;

  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsString()
  objectName?: string;

  @IsString()
  objectId?: string;

  @IsOptional()
  @IsObject()
  data?: Record<string, unknown>;
}
