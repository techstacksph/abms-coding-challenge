/* eslint-disable no-unused-vars */
export enum smtpType {
  GOOGLE = 'GOOGLE',
  M365 = 'M365',
}

export class MailerOptionDto {
  mailerCredentialOption?: {
    smtpType: smtpType;
    username: string;
    password: string;
    host: string;
    port: number;
    m365?: {
      clientId: string;
      clientSecret: string;
      tenantId: string;
    };
  };
  sender!: string;
  replyTo!: string;
  recipients!: string[];
  subject!: string;
  content!: string;
  attachments?: [{ cid: string; path: string }];
}

export class MailerClientResult {
  accepted!: string[];
  rejected!: string[];
  ehlo!: string[];
  envelopeTime!: number;
  messageTime!: number;
  messageSize!: number;
  response?: string;
  envelope!: { from: string[]; to: string[] };
  messageId!: string;
}
