import { JobStatus } from '../enums/RecurringJobEnum';

/**
 * Response from target service after job execution
 */
export interface JobExecutionResponseDto {
  /** Unique correlation ID to match request/response */
  correlationId: string;

  /** The job ID that was executed */
  jobId: string;

  /** Execution status */
  status: 'SUCCESS' | 'FAILED' | 'PARTIAL_SUCCESS';

  /** Start time of actual business logic execution */
  executionStartTime: Date;

  /** End time of actual business logic execution */
  executionEndTime: Date;

  /** Any result data from the execution */
  result?: {
    /** Number of items processed (e.g., emails sent) */
    itemsProcessed?: number;
    /** Number of items that failed */
    itemsFailed?: number;
    /** Specific results or metadata */
    details?: Record<string, unknown>;
  };

  /** Error message if execution failed */
  error?: string;

  /** Additional execution metadata */
  metadata?: {
    /** Service that executed the job */
    executedBy: string;
    /** Method that was called */
    method: string;
    /** Any logs or traces */
    logs?: string[];
  };
}

/**
 * Enhanced job execution DTO with correlation tracking
 */
export interface CorrelatedJobExecutionDto {
  /** Original job execution info */
  jobId: string;
  startTime: Date;
  endTime?: Date;
  status: JobStatus;
  error?: string;
  result?: unknown;

  /** Correlation tracking */
  correlationId: string;

  /** Response from target service */
  serviceResponse?: JobExecutionResponseDto;

  /** Timeout for waiting for response */
  responseTimeoutMs: number;
}
