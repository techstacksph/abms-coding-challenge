import { Type } from 'class-transformer';
import {
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

import { JobStatus, RecurringType } from '../enums/RecurringJobEnum';
import { FunctionJobDataDto } from './FunctionJobDataDto';

export class JobConfigDto {
  @IsOptional()
  @IsString()
  id?: string;

  @IsNotEmpty()
  @IsString()
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @ValidateNested()
  @Type(() => FunctionJobDataDto)
  @IsNotEmpty()
  jobData!: FunctionJobDataDto;

  @IsOptional()
  @IsString()
  topic?: string;

  @IsOptional()
  maxRetries?: number = 3;

  @IsOptional()
  timeoutMs?: number = 300000; // 5 minutes default
}

export class RecurringJobConfigDto extends JobConfigDto {
  @IsEnum(RecurringType)
  @IsNotEmpty()
  recurringType!: RecurringType;

  @IsNotEmpty()
  @IsString()
  // For CRON type: cron expression (e.g., "0 0 * * *" for daily at midnight)
  // For INTERVAL type: interval in milliseconds
  recurringPattern!: string;

  @IsOptional()
  startDate?: Date;

  @IsOptional()
  endDate?: Date;

  @IsOptional()
  lastRunTime?: Date;

  @IsOptional()
  nextRunTime?: Date;

  @IsEnum(JobStatus)
  @IsNotEmpty()
  status!: JobStatus;

  @IsOptional()
  currentRetries?: number;
}

export class JobExecutionDto {
  jobId!: string;
  startTime!: Date;
  endTime?: Date;
  status!: JobStatus;
  error?: string;
  result?: unknown;
}
