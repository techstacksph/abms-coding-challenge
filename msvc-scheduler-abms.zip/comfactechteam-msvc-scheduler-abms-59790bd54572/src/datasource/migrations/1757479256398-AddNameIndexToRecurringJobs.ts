import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddNameIndexToRecurringJobs1757479256398
  implements MigrationInterface
{
  name = 'AddNameIndexToRecurringJobs1757479256398';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create index on name column for better search performance
    await queryRunner.query(
      `CREATE INDEX "IDX_recurring_jobs_name" ON "recurring_jobs" ("name")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop the index
    await queryRunner.query(`DROP INDEX "public"."IDX_recurring_jobs_name"`);
  }
}
