import { MigrationInterface, QueryRunner } from 'typeorm';

export class AMBSScheduledJobs1744374052154 implements MigrationInterface {
  name = 'AMBSScheduledJobs1744374052154';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."recurring_jobs_recurringtype_enum" AS ENUM('CRON', 'INTERVAL')`
    );
    await queryRunner.query(
      `CREATE TYPE "public"."recurring_jobs_status_enum" AS ENUM('SCHEDULED', 'RUNNING', 'COMPLETED', 'FAILED')`
    );
    await queryRunner.query(
      `CREATE TABLE "recurring_jobs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying NOT NULL, "description" character varying, "jobData" jsonb NOT NULL, "topic" character varying, "recurringType" "public"."recurring_jobs_recurringtype_enum" NOT NULL, "recurringPattern" character varying NOT NULL, "startDate" TIMESTAMP, "endDate" TIMESTAMP, "lastRunTime" TIMESTAMP, "nextRunTime" TIMESTAMP, "status" "public"."recurring_jobs_status_enum" NOT NULL DEFAULT 'SCHEDULED', "maxRetries" integer NOT NULL DEFAULT '3', "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "createdBy" character varying, "updatedBy" character varying, CONSTRAINT "PK_2d51d1441da2cfd7b2c9345aaa2" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "recurring_jobs"`);
    await queryRunner.query(`DROP TYPE "public"."recurring_jobs_status_enum"`);
    await queryRunner.query(
      `DROP TYPE "public"."recurring_jobs_recurringtype_enum"`
    );
  }
}
