import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS3804AddJobExecutionHistory1757479256396
  implements MigrationInterface
{
  name = 'ABMS3804AddJobExecutionHistory1757479256396';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create job execution status enum
    await queryRunner.query(
      `CREATE TYPE "public"."job_execution_history_status_enum" AS ENUM('STARTED', 'SUCCESS', 'PARTIAL_SUCCESS', 'FAILED', 'TIMEOUT', 'CANCELLED')`
    );

    // Create job_execution_history table
    await queryRunner.query(`
            CREATE TABLE "job_execution_history" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "jobId" character varying NOT NULL,
                "correlationId" character varying,
                "jobName" character varying,
                "status" "public"."job_execution_history_status_enum" NOT NULL,
                "executionStartTime" TIMESTAMP NOT NULL,
                "executionEndTime" TIMESTAMP,
                "durationMs" integer,
                "attempt" integer NOT NULL DEFAULT '1',
                "maxRetries" integer NOT NULL DEFAULT '3',
                "itemsProcessed" integer,
                "itemsFailed" integer,
                "errorMessage" text,
                "result" jsonb,
                "metadata" jsonb,
                "executedBy" character varying,
                "logs" text array,
                "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
                "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
                CONSTRAINT "PK_job_execution_history" PRIMARY KEY ("id")
            )
        `);

    // Create indexes for better query performance
    await queryRunner.query(
      `CREATE INDEX "IDX_job_execution_history_jobId_executionStartTime" ON "job_execution_history" ("jobId", "executionStartTime")`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_job_execution_history_correlationId" ON "job_execution_history" ("correlationId")`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_job_execution_history_status_executionStartTime" ON "job_execution_history" ("status", "executionStartTime")`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_job_execution_history_jobId" ON "job_execution_history" ("jobId")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop indexes
    await queryRunner.query(
      `DROP INDEX "public"."IDX_job_execution_history_jobId"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_job_execution_history_status_executionStartTime"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_job_execution_history_correlationId"`
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_job_execution_history_jobId_executionStartTime"`
    );

    // Drop table
    await queryRunner.query(`DROP TABLE "job_execution_history"`);

    // Drop enum
    await queryRunner.query(
      `DROP TYPE "public"."job_execution_history_status_enum"`
    );
  }
}
