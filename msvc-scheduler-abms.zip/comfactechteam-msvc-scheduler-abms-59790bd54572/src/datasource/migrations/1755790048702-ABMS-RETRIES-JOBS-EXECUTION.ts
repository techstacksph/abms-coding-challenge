import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMSRETRIESJOBSEXECUTION1755790048702
  implements MigrationInterface
{
  name = 'ABMSRETRIESJOBSEXECUTION1755790048702';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Add currentRetries column
    await queryRunner.query(
      `ALTER TABLE "recurring_jobs" ADD "currentRetries" integer NOT NULL DEFAULT '0'`
    );

    // Add timeoutMs column
    await queryRunner.query(
      `ALTER TABLE "recurring_jobs" ADD "timeoutMs" integer NOT NULL DEFAULT '300000'`
    );

    // Update the status enum to include PAUSED
    await queryRunner.query(
      `ALTER TYPE "public"."recurring_jobs_status_enum" ADD VALUE 'PAUSED'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Remove the added columns
    await queryRunner.query(
      `ALTER TABLE "recurring_jobs" DROP COLUMN "timeoutMs"`
    );
    await queryRunner.query(
      `ALTER TABLE "recurring_jobs" DROP COLUMN "currentRetries"`
    );

    // Note: PostgreSQL doesn't support removing enum values directly
    // To properly rollback the enum change, we would need to:
    // 1. Create a new enum without PAUSED
    // 2. Update all PAUSED records to another status
    // 3. Alter the column to use the new enum
    // 4. Drop the old enum
    // For simplicity, we're leaving the enum as-is in the down migration
    // since removing enum values can cause data loss
  }
}
