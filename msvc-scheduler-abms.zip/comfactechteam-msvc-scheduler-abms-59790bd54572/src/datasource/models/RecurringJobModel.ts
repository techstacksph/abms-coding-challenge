import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { JobStatus, RecurringType } from '../../enums/RecurringJobEnum';

@Entity('recurring_jobs')
export class RecurringJobModel {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ nullable: true })
  description?: string;

  @Column({ type: 'jsonb' })
  jobData!: object;

  @Column({ nullable: true })
  topic?: string;

  @Column({
    type: 'enum',
    enum: RecurringType,
  })
  recurringType!: RecurringType;

  @Column()
  recurringPattern!: string;

  @Column({ type: 'timestamp', nullable: true })
  startDate?: Date;

  @Column({ type: 'timestamp', nullable: true })
  endDate?: Date;

  @Column({ type: 'timestamp', nullable: true })
  lastRunTime?: Date;

  @Column({ type: 'timestamp', nullable: true })
  nextRunTime?: Date;

  @Column({
    type: 'enum',
    enum: JobStatus,
    default: JobStatus.SCHEDULED,
  })
  status!: JobStatus;

  @Column({ default: 3 })
  maxRetries!: number;

  @Column({ default: 0 })
  currentRetries!: number;

  @Column({ default: 300000 }) // 5 minutes default timeout
  timeoutMs!: number;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;

  @Column({ nullable: true })
  createdBy?: string;

  @Column({ nullable: true })
  updatedBy?: string;
}
