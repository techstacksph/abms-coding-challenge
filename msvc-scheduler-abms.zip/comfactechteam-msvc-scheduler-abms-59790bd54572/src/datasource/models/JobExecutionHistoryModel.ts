import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

export enum JobExecutionStatus {
  STARTED = 'STARTED',
  SUCCESS = 'SUCCESS',
  PARTIAL_SUCCESS = 'PARTIAL_SUCCESS',
  FAILED = 'FAILED',
  TIMEOUT = 'TIMEOUT',
  CANCELLED = 'CANCELLED',
}

@Entity('job_execution_history')
@Index(['jobId', 'executionStartTime'])
@Index(['correlationId'])
@Index(['status', 'executionStartTime'])
export class JobExecutionHistoryModel {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  @Index()
  jobId!: string;

  @Column({ nullable: true })
  correlationId?: string;

  @Column({ nullable: true })
  jobName?: string;

  @Column({
    type: 'enum',
    enum: JobExecutionStatus,
  })
  status!: JobExecutionStatus;

  @Column({ type: 'timestamp' })
  executionStartTime!: Date;

  @Column({ type: 'timestamp', nullable: true })
  executionEndTime?: Date;

  @Column({ type: 'integer', nullable: true })
  durationMs?: number;

  @Column({ type: 'integer', default: 1 })
  attempt!: number;

  @Column({ type: 'integer', default: 3 })
  maxRetries!: number;

  @Column({ type: 'integer', nullable: true })
  itemsProcessed?: number;

  @Column({ type: 'integer', nullable: true })
  itemsFailed?: number;

  @Column({ type: 'text', nullable: true })
  errorMessage?: string;

  @Column({ type: 'jsonb', nullable: true })
  result?: object;

  @Column({ type: 'jsonb', nullable: true })
  metadata?: object;

  @Column({ nullable: true })
  executedBy?: string;

  @Column({ type: 'text', array: true, nullable: true })
  logs?: string[];

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
