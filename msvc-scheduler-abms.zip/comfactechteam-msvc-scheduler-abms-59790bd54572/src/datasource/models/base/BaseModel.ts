import { Column } from 'typeorm';

import { CommonModel } from './CommonModel';

export abstract class BaseModel extends CommonModel {
  @Column({ nullable: true, type: 'uuid' })
  orgId!: string;
}
