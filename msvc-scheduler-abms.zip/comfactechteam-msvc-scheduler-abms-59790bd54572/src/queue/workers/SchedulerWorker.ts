import 'reflect-metadata';

import { Job, Worker } from 'bullmq';
import { Service } from 'typedi';

import { logger } from '../../utils/LoggerUtils';
import { redisConnection } from '../QueueConfig';
import { ScheduledJobData } from '../JobQueue';

/**
 * SchedulerWorker - Processes jobs sent to external services (msvc-abms)
 * ABMS-3525: BullMQ worker that replaces Pulsar subscriber
 *
 * Note: This worker runs in msvc-scheduler-abms but actually sends jobs
 * to msvc-abms via the BullMQ queue. The actual execution happens in msvc-abms.
 */
@Service()
export class SchedulerWorker {
  private worker: Worker | null = null;

  /**
   * Start the worker
   */
  async start(): Promise<void> {
    this.worker = new Worker(
      'scheduled-jobs',
      async (job: Job<ScheduledJobData>) => {
        return await this.processJob(job);
      },
      {
        connection: redisConnection,
        concurrency: 10, // Process up to 10 jobs concurrently
        limiter: {
          max: 100, // Max 100 jobs
          duration: 60000, // per minute
        },
      }
    );

    // Event listeners
    this.worker.on('completed', (job) => {
      logger.info('Job completed', {
        jobId: job.id,
        returnValue: job.returnvalue,
      });
    });

    this.worker.on('failed', (job, error) => {
      logger.error('Job failed', {
        jobId: job?.id,
        error: error.message,
        attemptsMade: job?.attemptsMade,
      });
    });

    this.worker.on('stalled', (jobId) => {
      logger.warn('Job stalled (will be retried)', { jobId });
    });

    logger.info('SchedulerWorker started successfully', {
      queue: 'scheduled-jobs',
      concurrency: 10,
    });
  }

  /**
   * Process a job
   * Note: In this architecture, the actual job processing happens in msvc-abms
   * This is just a pass-through/logging point
   */
  private async processJob(job: Job<ScheduledJobData>): Promise<any> {
    const { jobId, jobData, isRecurring, executionTime } = job.data;

    logger.info('Processing scheduled job', {
      bullJobId: job.id,
      jobId,
      isRecurring,
      executionTime,
      jobDataSource: jobData.source,
      jobDataObjectName: jobData.objectName,
    });

    // The job data is now in BullMQ queue and will be picked up by msvc-abms worker
    // We return success here as the queueing is complete
    return {
      status: 'QUEUED',
      jobId,
      queuedAt: new Date().toISOString(),
    };
  }

  /**
   * Stop the worker gracefully
   */
  async stop(): Promise<void> {
    if (this.worker) {
      logger.info('Stopping SchedulerWorker...');
      await this.worker.close();
      this.worker = null;
      logger.info('SchedulerWorker stopped');
    }
  }
}
