import 'reflect-metadata';

import { Queue } from 'bullmq';
import { Service } from 'typedi';

import { logger } from '../utils/LoggerUtils';
import {
  defaultQueueOptions,
  QueueNames,
  redisConnection,
} from './QueueConfig';

/**
 * BullMQ Manager - Manages queue connections and lifecycle
 */
@Service()
export class BullMQManager {
  private queues: Map<string, Queue> = new Map();
  private isInitialized = false;

  /**
   * Initialize all queues
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      logger.warn('BullMQ Manager already initialized');
      return;
    }

    try {
      // Create scheduled jobs queue (for jobs sent to msvc-abms)
      const scheduledJobsQueue = new Queue(
        QueueNames.SCHEDULED_JOBS,
        defaultQueueOptions
      );
      this.queues.set(QueueNames.SCHEDULED_JOBS, scheduledJobsQueue);

      // Create internal scheduler queue (for jobs scheduler processes itself)
      const schedulerInternalQueue = new Queue(
        QueueNames.SCHEDULER_INTERNAL,
        defaultQueueOptions
      );
      this.queues.set(QueueNames.SCHEDULER_INTERNAL, schedulerInternalQueue);

      this.isInitialized = true;

      logger.info('BullMQ Manager initialized successfully', {
        queues: Array.from(this.queues.keys()),
        redisHost: (redisConnection as any).host,
        redisPort: (redisConnection as any).port,
      });
    } catch (error) {
      logger.error('Failed to initialize BullMQ Manager', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Get a queue by name
   */
  getQueue(queueName: string): Queue {
    const queue = this.queues.get(queueName);
    if (!queue) {
      throw new Error(`Queue '${queueName}' not found. Did you initialize BullMQ Manager?`);
    }
    return queue;
  }

  /**
   * Get the scheduled jobs queue
   */
  getScheduledJobsQueue(): Queue {
    return this.getQueue(QueueNames.SCHEDULED_JOBS);
  }

  /**
   * Get the internal scheduler queue
   */
  getSchedulerInternalQueue(): Queue {
    return this.getQueue(QueueNames.SCHEDULER_INTERNAL);
  }

  /**
   * Get all queues
   */
  getAllQueues(): Queue[] {
    return Array.from(this.queues.values());
  }

  /**
   * Close all queue connections
   */
  async close(): Promise<void> {
    logger.info('Closing all BullMQ queues');

    for (const [name, queue] of this.queues.entries()) {
      try {
        await queue.close();
        logger.debug(`Queue '${name}' closed successfully`);
      } catch (error) {
        logger.error(`Failed to close queue '${name}'`, {
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    this.queues.clear();
    this.isInitialized = false;

    logger.info('All BullMQ queues closed');
  }

  /**
   * Graceful shutdown
   */
  async shutdown(): Promise<void> {
    logger.info('BullMQ Manager shutdown initiated');
    await this.close();
    logger.info('BullMQ Manager shutdown completed');
  }
}
