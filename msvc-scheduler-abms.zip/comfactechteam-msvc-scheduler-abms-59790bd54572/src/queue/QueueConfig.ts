import 'reflect-metadata';

import { ConnectionOptions, QueueOptions } from 'bullmq';

import environment from '../environment';

/**
 * Redis connection configuration for BullMQ
 */
export const redisConnection: ConnectionOptions = {
  host: environment.REDIS_URL?.replace('redis://', '').split(':')[0] || 'localhost',
  port: parseInt(environment.REDIS_URL?.split(':')[2] || '6379'),
  password: environment.REDIS_PASSWORD,
  maxRetriesPerRequest: null, // Required for BullMQ
};

/**
 * Default queue options for all queues
 */
export const defaultQueueOptions: QueueOptions = {
  connection: redisConnection,
  prefix: environment.REDIS_PREFIX || 'abms',
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000, // Start with 2 seconds
    },
    removeOnComplete: {
      age: 86400, // Keep completed jobs for 24 hours
      count: 1000, // Keep last 1000 completed jobs
    },
    removeOnFail: {
      age: 604800, // Keep failed jobs for 7 days
      count: 5000, // Keep last 5000 failed jobs
    },
  },
};

/**
 * Timezone configuration for scheduled jobs
 * All cron patterns should use this timezone for consistent behavior
 * BullMQ automatically handles DST transitions
 */
export const SCHEDULER_TIMEZONE = 'Pacific/Auckland';

/**
 * Queue names used in the application
 */
export const QueueNames = {
  SCHEDULED_JOBS: 'scheduled-jobs',
  SCHEDULER_INTERNAL: 'scheduler-internal',
} as const;

/**
 * Job name constants for type safety
 */
export const JobNames = {
  RECURRING_JOB: 'recurring-job',
  ONE_TIME_JOB: 'one-time-job',
  ONE_TIME_SCHEDULED_JOB: 'one-time-scheduled-job',
  INTERNAL_CLEANUP: 'internal-cleanup',
  INTERNAL_STUCK_JOBS: 'internal-stuck-jobs',
} as const;
