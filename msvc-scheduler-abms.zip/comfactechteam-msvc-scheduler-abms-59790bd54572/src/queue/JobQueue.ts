import 'reflect-metadata';

import { JobsOptions, Queue } from 'bullmq';
import { Service } from 'typedi';

import { RecurringJobModel } from '../datasource/models/RecurringJobModel';
import { FunctionJobDataDto } from '../dto/FunctionJobDataDto';
import { RecurringType } from '../enums/RecurringJobEnum';
import { logger } from '../utils/LoggerUtils';
import { BullMQManager } from './BullMQManager';
import { JobNames, SCHEDULER_TIMEZONE } from './QueueConfig';

/**
 * Job data interface for BullMQ jobs
 */
export interface ScheduledJobData {
  jobId: string;
  jobData: FunctionJobDataDto;
  isRecurring: boolean;
  executionTime?: Date;
}

/**
 * JobQueue - High-level interface for adding jobs to BullMQ
 */
@Service()
export class JobQueue {
  private scheduledJobsQueue!: Queue;

  constructor(private bullmqManager: BullMQManager) {
    // Queue will be initialized in server.ts after BullMQManager.initialize()
  }

  /**
   * Initialize the job queue (called after BullMQManager.initialize())
   */
  initialize(): void {
    this.scheduledJobsQueue = this.bullmqManager.getScheduledJobsQueue();
    logger.info('JobQueue initialized');
  }

  /**
   * Add a recurring job to the queue
   */
  async addRecurringJob(job: RecurringJobModel): Promise<string> {
    const jobData: ScheduledJobData = {
      jobId: job.id,
      jobData: job.jobData as FunctionJobDataDto,
      isRecurring: true,
    };

    const options: JobsOptions = {
      jobId: job.id, // Use job ID for deduplication
      attempts: job.maxRetries || 3,
      backoff: {
        type: 'exponential',
        delay: 2000,
      },
    };

    // Add CRON or Interval repeat pattern
    if (job.recurringType === RecurringType.CRON) {
      options.repeat = {
        pattern: job.recurringPattern,
        // Add timezone support for CRON jobs to handle DST automatically
        // This ensures jobs run at the specified LOCAL time (e.g., 8 AM NZ time)
        // regardless of DST changes (NZDT UTC+13 vs NZST UTC+12)
        tz: SCHEDULER_TIMEZONE,
      };
    } else if (job.recurringType === RecurringType.INTERVAL) {
      const intervalMs = parseInt(job.recurringPattern);
      options.repeat = {
        every: intervalMs,
      };
    }

    // Add end date if specified
    if (job.endDate) {
      options.repeat!.endDate = job.endDate;
    }

    const bullJob = await this.scheduledJobsQueue.add(
      JobNames.RECURRING_JOB,
      jobData,
      options
    );

    logger.info('Recurring job added to BullMQ', {
      jobId: job.id,
      jobName: job.name,
      bullJobId: bullJob.id,
      recurringType: job.recurringType,
      pattern: job.recurringPattern,
      timezone: job.recurringType === RecurringType.CRON ? SCHEDULER_TIMEZONE : undefined,
    });

    return bullJob.id as string;
  }

  /**
   * Add a one-time scheduled job (executes at specific time)
   */
  async addOneTimeScheduledJob(
    jobId: string,
    jobData: FunctionJobDataDto,
    executionTime: Date
  ): Promise<string> {
    const data: ScheduledJobData = {
      jobId,
      jobData,
      isRecurring: false,
      executionTime,
    };

    const delay = executionTime.getTime() - Date.now();

    const options: JobsOptions = {
      jobId,
      delay: Math.max(0, delay), // Ensure non-negative delay
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 2000,
      },
    };

    const bullJob = await this.scheduledJobsQueue.add(
      JobNames.ONE_TIME_SCHEDULED_JOB,
      data,
      options
    );

    logger.info('One-time scheduled job added to BullMQ', {
      jobId,
      bullJobId: bullJob.id,
      executionTime: executionTime.toISOString(),
      delay,
    });

    return bullJob.id as string;
  }

  /**
   * Add a quick one-time job (executes in 2 minutes)
   */
  async addOneTimeJob(
    jobId: string,
    jobData: FunctionJobDataDto
  ): Promise<string> {
    const executionTime = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes
    return this.addOneTimeScheduledJob(jobId, jobData, executionTime);
  }

  /**
   * Remove a job from the queue (for job deletion)
   */
  async removeJob(jobId: string): Promise<boolean> {
    try {
      const job = await this.scheduledJobsQueue.getJob(jobId);
      if (job) {
        await job.remove();
        logger.info('Job removed from BullMQ', { jobId });
        return true;
      }
      return false;
    } catch (error) {
      logger.error('Failed to remove job from BullMQ', {
        error: error instanceof Error ? error.message : 'Unknown error',
        jobId,
      });
      return false;
    }
  }

  /**
   * Update a recurring job (remove old, add new)
   */
  async updateRecurringJob(job: RecurringJobModel): Promise<string> {
    // Remove existing job
    await this.removeJob(job.id);

    // Add updated job
    return this.addRecurringJob(job);
  }
}
