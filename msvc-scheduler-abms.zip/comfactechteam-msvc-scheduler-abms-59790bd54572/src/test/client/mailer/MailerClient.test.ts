/* eslint-disable jest/no-focused-tests */

/* eslint-disable jest/no-disabled-tests */
import { DeepPartial } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';

import { MailerClient } from '../../../client/mailer/MailerClient';
import { appDataSource } from '../../../datasource/config/database';
import { MailerAuditModel } from '../../../datasource/models/MailerAuditModel';
import { MailerOptionDto, smtpType } from '../../../dto/MailerOptionDto';
import { RecordCUDDto } from '../../../dto/RecordAuditDto';
import environment from '../../../environment';
import { MailerAuditService } from '../../../services/MailerAuditService';
import {
  sampleEmailBodyWithBase64LogoM365,
  sampleEmailBodyWithLinkLogo,
  sampleEmailBodyWithLinkLogoM365,
  sampleLogo,
  sampleLogoBase64,
} from '../../SampleData';

describe('MAILER CLIENT', () => {
  let mailerClient: MailerClient;

  const EMAIL_SEMDER = environment.MAILER_USERNAME;
  const EMAIL_SENDER_PASSWORD = environment.MAILER_PASSWORD;
  const EMAIL_REPLY_TO = 'cesar@comfactechoptions.com';
  const RECIPIENTS: string[] = ['cesar.pastor.jr@gmail.com'];

  const M365_EMAIL_SEMDER = 'no-reply@comfactechoptions.com';
  const M365_EMAIL_REPLY_TO = 'cesar@comfactechoptions.com';
  const M365_CLIENT_ID = environment.M365_CLIENT_ID;
  const M365_CLIENT_SECRET = environment.M365_CLIENT_SECRET;
  const M365_TENANT_ID = environment.M365_TENANT_ID;

  beforeAll(async () => {
    if (!appDataSource.isInitialized) {
      await appDataSource.initialize();
    }

    jest.mock('../../../services/MailerAuditService');
    MailerAuditService.prototype.save = jest.fn(
      async (
        entity: DeepPartial<MailerAuditModel>,
        userDto: RecordCUDDto
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ): Promise<any> => {
        return { entity, userDto };
      }
    );

    if (environment.NODE_ENV === 'test') {
      jest.mock('../../../client/mailer/MailerClient');
      MailerClient.prototype.sendEmail = jest.fn(
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        async (option: MailerOptionDto): Promise<boolean> => {
          return Promise.resolve(true);
        }
      );
    }

    mailerClient = Container.get(MailerClient);
  });

  afterAll(async () => {
    await appDataSource.destroy();
  });

  test('SEND EMAIL PLAIN', async () => {
    const option: MailerOptionDto = {
      content: 'THIS IS A SAMPLE EMAIL',
      mailerCredentialOption: {
        host: 'smtp.gmail.com',
        password: EMAIL_SENDER_PASSWORD,
        port: 587,
        smtpType: smtpType.GOOGLE,
        username: EMAIL_SEMDER,
      },
      recipients: RECIPIENTS,
      replyTo: EMAIL_REPLY_TO,
      sender: EMAIL_SEMDER,
      subject: 'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE PLAIN TEXT',
    };

    mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });

  test('SEND EMAIL LINK ICON', async () => {
    const option: MailerOptionDto = {
      attachments: [
        {
          cid: 'sample_logo',
          path: 'https://www.comfactechoptions.com/wp-content/uploads/2018/08/cto-design3-512x512.png',
        },
      ],
      content: sampleEmailBodyWithLinkLogo,
      mailerCredentialOption: {
        host: 'smtp.gmail.com',
        password: EMAIL_SENDER_PASSWORD,
        port: 587,
        smtpType: smtpType.GOOGLE,
        username: EMAIL_SEMDER,
      },
      recipients: RECIPIENTS,
      replyTo: EMAIL_REPLY_TO,
      sender: EMAIL_SEMDER,
      subject: 'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE LINK LOGO',
    };

    mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });

  test('SEND EMAIL BASE64 ICON', async () => {
    const option: MailerOptionDto = {
      attachments: [
        {
          cid: 'sample_logo',
          path: sampleLogo,
        },
      ],
      content: sampleEmailBodyWithLinkLogo,
      mailerCredentialOption: {
        host: 'smtp.gmail.com',
        password: EMAIL_SENDER_PASSWORD,
        port: 587,
        smtpType: smtpType.GOOGLE,
        username: EMAIL_SEMDER,
      },
      recipients: RECIPIENTS,
      replyTo: EMAIL_REPLY_TO,
      sender: EMAIL_SEMDER,
      subject: 'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE BASE64 LOGO',
    };

    mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });

  test('SEND EMAIL M365 LINK LOGO', async () => {
    const option: MailerOptionDto = {
      content: sampleEmailBodyWithLinkLogoM365,

      mailerCredentialOption: {
        host: 'smtp.office365.com',
        m365: {
          clientId: M365_CLIENT_ID,
          clientSecret: M365_CLIENT_SECRET,
          tenantId: M365_TENANT_ID,
        },
        password: '',
        port: 587,
        smtpType: smtpType.M365,
        username: M365_EMAIL_SEMDER,
      },

      recipients: RECIPIENTS,
      replyTo: M365_EMAIL_REPLY_TO,
      sender: M365_EMAIL_SEMDER,
      subject: 'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE URL LOGO M365',
    };

    await mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });

  test('SEND EMAIL M365 BASE LOGO', async () => {
    const option: MailerOptionDto = {
      attachments: [
        {
          cid: 'sample_logo',
          path: sampleLogoBase64,
        },
      ],

      content: sampleEmailBodyWithBase64LogoM365,
      mailerCredentialOption: {
        host: 'smtp.office365.com',
        m365: {
          clientId: M365_CLIENT_ID,
          clientSecret: M365_CLIENT_SECRET,
          tenantId: M365_TENANT_ID,
        },
        password: '',
        port: 587,
        smtpType: smtpType.M365,
        username: M365_EMAIL_SEMDER,
      },
      recipients: RECIPIENTS,
      replyTo: M365_EMAIL_REPLY_TO,
      sender: M365_EMAIL_SEMDER,
      subject:
        'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE BASE 64 LOGO M365',
    };

    await mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });

  test('SEND EMAIL M365 DEFAULT LINK LOGO', async () => {
    const option: MailerOptionDto = {
      content: sampleEmailBodyWithLinkLogoM365,
      recipients: RECIPIENTS,
      replyTo: M365_EMAIL_REPLY_TO,
      sender: M365_EMAIL_SEMDER,
      subject:
        'TEST MAIL FROM COMMUNICATION MEDIA MICRO SERVICE URL LOGO M365 SYSTEM DEFAULT SMPT',
    };

    await mailerClient.sendEmail(option);

    expect(true).toBe(true);
  });
});
