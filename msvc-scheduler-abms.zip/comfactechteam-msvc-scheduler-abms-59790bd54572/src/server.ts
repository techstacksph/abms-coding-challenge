/* eslint-disable @typescript-eslint/no-unused-vars */
import 'reflect-metadata';

import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';
import cookieParser from 'cookie-parser';
import express from 'express';
import basicAuth from 'express-basic-auth';
import { Action, createExpressServer, useContainer } from 'routing-controllers';
import swaggerUi from 'swagger-ui-express';
import { Container } from 'typeorm-typedi-extensions';

import { ControllerInitializer } from './controller/ControllerInitializer';
import { appDataSource } from './datasource/config/database';
import { ClientAuthenticationDto } from './dto/ClientAuthenticationDto';
import environment from './environment';
import { CustomUnauthorizedError } from './errors/CustomUnauthorizedError';
import { BullMQManager } from './queue/BullMQManager';
import { JobQueue } from './queue/JobQueue';
import { SchedulerWorker } from './queue/workers/SchedulerWorker';
import { AuthenticateRequestService } from './services/AuthenticateRequestService';
import { ScheduledJobService } from './services/ScheduledJobService';
import { httpLogger, logger } from './utils/LoggerUtils';
import swaggerSpec from './utils/SwaggerUtils';

const startServer = async () => {
  const PORT = environment.PORT;
  //const app = express();

  useContainer(Container);

  const controllerInitializer: ControllerInitializer = Container.get(
    ControllerInitializer
  );

  const authenticateRequestService: AuthenticateRequestService = Container.get(
    AuthenticateRequestService
  );

  const app = createExpressServer({
    authorizationChecker: async (action: Action): Promise<boolean> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );

      if (!authenticate.valid) {
        throw new CustomUnauthorizedError('invalid_authorization');
      }
      return Promise.resolve(authenticate.valid);
    },
    controllers: controllerInitializer.controllers(),
    cors: true,
    classTransformer: true,
    validation: true,
    currentUserChecker: async (
      action: Action
    ): Promise<ClientAuthenticationDto> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );

      if (authenticate.valid) {
        return {
          PERMISSION: {},
          ROLE: 'system_admin',
          USER_ID: authenticate.userId as string,
          USER_NAME: 'system_admin',
        };
      } else {
        return {
          PERMISSION: null,
          ROLE: null,
          USER_ID: null,
          USER_NAME: null,
        };
      }
    },
  });

  app.use(httpLogger);
  app.use(cookieParser());
  app.use(express.json());

  app.use(
    '/v1/api-doc',
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec, {
      swaggerOptions: {
        defaultModelsExpandDepth: -1,
        persistAuthorization: true,
      },
    })
  );

  // ABMS-3525: Setup BullMQ Board UI for queue monitoring
  const serverAdapter = new ExpressAdapter();
  serverAdapter.setBasePath('/admin/queues');

  const bullmqManager = Container.get(BullMQManager);
  const queues = bullmqManager.getAllQueues();

  createBullBoard({
    queues: queues.map((q) => new BullMQAdapter(q)) as any,
    serverAdapter,
  });

  // Add basic authentication to protect BullMQ Board
  app.use(
    '/admin/queues',
    basicAuth({
      users: {
        [environment.BULL_BOARD_USERNAME]: environment.BULL_BOARD_PASSWORD,
      },
      challenge: true,
      realm: 'BullMQ Board',
    }),
    serverAdapter.getRouter()
  );

  await new Promise<void>((resolve) => app.listen({ port: PORT }, resolve));
  logger.info('Environment config: ', {
    ...environment,
  });
  logger.info(`Visit API Docs http://localhost:${PORT}/v1/api-doc `);
  logger.info(`Visit BullMQ Board http://localhost:${PORT}/admin/queues `);
  logger.info(`Server running at http://localhost:${PORT} `);
  return app;
};

appDataSource.initialize().then(async (connetion) => {
  logger.info(`Database connection is connected:`, {
    isInitialized: connetion.isInitialized,
  });

  // ABMS-3525: Initialize BullMQ (replaces Pulsar)
  try {
    const bullmqManager = Container.get(BullMQManager);
    await bullmqManager.initialize();
    logger.info('BullMQ initialized successfully');

    // Initialize JobQueue
    const jobQueue = Container.get(JobQueue);
    jobQueue.initialize();
    logger.info('JobQueue initialized successfully');

    // Start SchedulerWorker
    const schedulerWorker = Container.get(SchedulerWorker);
    await schedulerWorker.start();
    logger.info('SchedulerWorker started successfully');
  } catch (error) {
    logger.error('Failed to initialize BullMQ', {
      error: error instanceof Error ? error.message : 'Unknown error',
    });
    process.exit(1); // Exit if BullMQ fails to initialize
  }

  if (!['test', 'local'].includes(environment.NODE_ENV.toLocaleLowerCase())) {
    //RUN PROCESS THAT NEEDED IN SERVER HERE
  }
  await startServer();

  // Reschedule existing jobs on startup (BullMQ persists jobs, this syncs database)
  try {
    const scheduledJobService = Container.get(ScheduledJobService);
    const rescheduledCount = await scheduledJobService.rescheduleExistingJobs();
    logger.info('Startup job recovery completed', {
      rescheduledJobs: rescheduledCount,
    });
  } catch (error) {
    logger.error('Startup job recovery failed', {
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});
