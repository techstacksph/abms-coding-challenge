#!/bin/sh
cd /code
yarn migration:run:prod
yarn start
