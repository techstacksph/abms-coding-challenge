/** @type {import('@ts-jest/dist/types').InitialOptionsTsJest} */
module.exports = {
  globalSetup: './jest.global.setup.ts',
  extensionsToTreatAsEsm: ['.ts'],
  moduleNameMapper: {
    '^(\\.{1,2}/.*)\\.js$': '$1',
  },

  moduleFileExtensions: ['ts', 'tsx', 'js'],
  //preset: 'ts-jest/presets/default-esm',
  preset: 'ts-jest',
  roots: ['<rootDir>/src/'],
  setupFilesAfterEnv: ['./jest.setup.js'],
  testEnvironment: 'node',
  testTimeout: 30000,
  transform: {
    '^.+\\.m?[tj]sx?$': [
      'ts-jest',
      {
        useESM: true,
      },
    ],
    '^.+\\.tsx?$': [
      'ts-jest',
      {
        useESM: true,
      },
    ],
  },
  transformIgnorePatterns: ['/node_modules/', './jest.setup.js'],
};
