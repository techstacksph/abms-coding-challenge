import path from 'path';
import { DataSource, DataSourceOptions, LoggerOptions } from 'typeorm';

// Use different paths based on environment (dev vs production)
// In deployment, files are compiled to dist/ even if NODE_ENV is 'dev'
const isProduction = process.env.NODE_ENV === 'production' ||
                    process.env.NODE_ENV === 'prod' ||
                    process.env.MIGRATION_MODE === 'production';

// Import environment based on context
const environment = isProduction
  ? require('./dist/environment').default
  : require('./src/environment').default;
const baseDir = isProduction ? 'dist' : 'src';
const extensions = isProduction ? '{js}' : '{js,ts}';

const subscriber_path = path.join(`${baseDir}/datasource/subscribers/**/*.${extensions}`);
const entity_path = path.join(`${baseDir}/datasource/models/**/*.${extensions}`);
const migration_path = path.join(`${baseDir}/datasource/migrations/**/*.${extensions}`);

let sql_logger_options: LoggerOptions;
if (environment.SHOW_SQL) {
  sql_logger_options = true;
} else {
  sql_logger_options = false;
}
const dataSourceOptions: DataSourceOptions = {
  database: environment.DATABASE_NAME,
  entities: [entity_path],
  host: environment.DATABASE_HOSTNAME,
  logging: sql_logger_options,
  migrations: [migration_path],
  migrationsTableName: 'migrations',
  name: 'default',
  password: environment.DATABASE_PASSWORD,
  port: environment.DATABASE_PORT,
  subscribers: [subscriber_path],
  synchronize: false,
  type: 'postgres',

  username: environment.DATABASE_USERNAME,
};

if (environment.NODE_ENV.toLowerCase() != 'local') {
  Object.assign(dataSourceOptions, {
    extra: {
      ssl: {
        rejectUnauthorized: false,
      },
    },
  });
}

export const appDataSource = new DataSource(dataSourceOptions);
