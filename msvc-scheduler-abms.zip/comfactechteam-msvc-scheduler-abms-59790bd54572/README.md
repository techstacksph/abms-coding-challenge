# MSVC Scheduler ABMS

A robust microservice for scheduling and managing jobs with support for one-time, recurring, and CRON-based job execution patterns.

## Overview

This service provides a comprehensive job scheduling system with the following key features:
- **One-time job scheduling** at specific dates and times
- **Recurring job patterns** with CRON expressions and intervals
- **Job monitoring and management** with status tracking
- **Secure API endpoints** with authentication
- **Apache Pulsar integration** for distributed messaging
- **Database persistence** with TypeORM and PostgreSQL

## Quick Start

### Prerequisites
- Node.js 16+ 
- Docker and Docker Compose
- PostgreSQL database
- Apache Pulsar (optional, for distributed messaging)

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   yarn install
   ```

3. Set up environment variables (copy from `environment.ts`)

4. Start the database and dependencies:
   ```bash
   docker-compose up -d
   ```

5. Run database migrations:
   ```bash
   yarn migration:run
   ```

6. Start the development server:
   ```bash
   yarn dev
   ```

The service will be available at `http://localhost:8085`

## Docker Development Environment (Recommended)

For the best development experience with hot reload and isolated environments, use the Docker development setup:

### Prerequisites for Docker Development
- Docker and Docker Compose
- Node.js 20+ (for local development)

### Quick Start with Docker

**Option 1: Full Development Environment (Recommended)**
Start all services including PostgreSQL, Redis, and Pulsar with hot reload:
```bash
yarn docker:dev:full
```
This will:
- Create the `local_bridge` Docker network
- Start PostgreSQL, Redis, and Pulsar services
- Build and start the scheduler microservice with hot reload
- Automatically create the development database (`DOCKER_MSVC_SCHEDULER`)
- Run database migrations
- Mount source code for instant reload on changes

**Option 2: Microservice Only**
If you have infrastructure running elsewhere:
```bash
yarn docker:dev
```

**Option 3: Infrastructure Only**
Start shared services (PostgreSQL, Redis, Pulsar) without the microservice:
```bash
yarn docker:infrastructure
```

### Docker Development Features

✅ **Hot Reload**: Code changes in `src/` automatically restart the server  
✅ **Isolated Database**: Separate `DOCKER_MSVC_SCHEDULER` database for development  
✅ **Auto Database Creation**: Database created automatically if it doesn't exist  
✅ **Volume Mounts**: Source code, config files mounted for instant updates  
✅ **One Command Setup**: Everything starts with `yarn docker:dev:full`  
✅ **Web UIs Available**:
  - **Scheduler API**: http://localhost:8085
  - **Swagger Docs**: http://localhost:8085/api-docs
  - **Redis Commander**: http://localhost:8081 (if using full infrastructure)
  - **Pulsar Admin**: http://localhost:8080 (if using full infrastructure)

### Docker Management Commands

```bash
# Start full environment
yarn docker:dev:full

# Start microservice only
yarn docker:dev

# Start infrastructure only
yarn docker:infrastructure

# Stop and restart with rebuild
yarn docker:dev:restart

# Stop microservice
yarn docker:dev:down

# Stop infrastructure
yarn docker:infrastructure:down

# View logs
docker-compose -f docker-compose.dev.yml logs -f

# Access container shell
docker exec -it msvc-scheduler-abms sh
```

### Docker Development Configuration

The development environment uses:
- **Port**: 8085 (mapped to host)
- **Database**: `DOCKER_MSVC_SCHEDULER` (auto-created)
- **Network**: `local_bridge` (shared with other microservices)
- **Node Version**: 20 (matches production)
- **Environment**: All required variables pre-configured

### Troubleshooting Docker Development

**Issue: Port already in use**
```bash
# Check what's using the port
lsof -i :8085
# Stop any existing containers
docker-compose -f docker-compose.dev.yml down
```

**Issue: Database connection fails**
```bash
# Restart infrastructure
yarn docker:infrastructure:down
yarn docker:infrastructure
```

**Issue: Hot reload not working**
- Ensure source code is mounted: check `docker-compose.dev.yml` volumes
- Restart the development container: `yarn docker:dev:restart`

**Issue: Node modules issues**
```bash
# Rebuild containers
docker-compose -f docker-compose.dev.yml build --no-cache
```

### Switching Between Docker and Local Development

**Docker Development (Recommended)**:
- Consistent environment across team
- Hot reload with volume mounts  
- Isolated database and dependencies
- One command setup

**Local Development**:
- Direct Node.js execution
- Requires local PostgreSQL, Redis, Pulsar
- Manual database setup
- Environment variables from `.env`

## API Endpoints

### Job Scheduling

The service provides multiple ways to schedule jobs depending on your needs:

### Method 1: Using the Scheduled One-Time Job Endpoint (Recommended)

Use the `/v1/jobs/one-time/scheduled` endpoint to create a job that runs once at a specific date and time:

```bash
POST /v1/jobs/one-time/scheduled
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN

{
  "name": "Scheduled Backup Task",
  "description": "Performs a backup task at a specific time",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "local.AYR_BACK_OFFICE",
    "objectName": "backup",
    "data": {
      "target": "database",
      "action": "backup"
    }
  },
  "executionTime": "2025-12-25T15:00:00Z"
}
```

**Parameters:**
- `name`: Name of the job
- `description`: Optional description
- `jobData`: Job-specific configuration and data
- `executionTime`: ISO 8601 date string for when the job should execute (must be in the future)

### Method 2: Using the Main Jobs Endpoint with CRON

Use the `/v1/jobs` endpoint with a CRON expression for a specific date and time:

```bash
POST /v1/jobs
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN

{
  "name": "One-time Task",
  "description": "Task to run once at specific time",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "your-app",
    "objectName": "task",
    "data": {
      "action": "your-action"
    }
  },
  "recurringType": "CRON",
  "recurringPattern": "0 15 25 12 *",
  "endDate": "2025-12-25T15:01:00Z"
}
```

**CRON Pattern Explanation:**
- `0 15 25 12 *` = Run at 3:00 PM on December 25th
- Format: `minute hour day month day-of-week`

### Method 3: Using the Main Jobs Endpoint with INTERVAL

Calculate the milliseconds until your target time and use the INTERVAL type:

```bash
POST /v1/jobs
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN

{
  "name": "One-time Task",
  "description": "Task to run once at specific time",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "your-app",
    "objectName": "task",
    "data": {
      "action": "your-action"
    }
  },
  "recurringType": "INTERVAL",
  "recurringPattern": "86400000",
  "endDate": "2025-12-25T15:01:00Z"
}
```

### Method 4: Quick One-Time Job (2 minutes from now)

Use the `/v1/jobs/one-time` endpoint for a job that runs 2 minutes after creation:

```bash
POST /v1/jobs/one-time
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN

{
  "name": "Quick Task",
  "description": "Task to run in 2 minutes",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "your-app",
    "objectName": "task",
    "data": {
      "action": "your-action"
    }
  }
}
```

### Examples

#### Schedule a job for tomorrow at 9:00 AM
```json
{
  "name": "Daily Report",
  "description": "Generate daily report",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "reporting-service",
    "objectName": "report",
    "data": {
      "type": "daily",
      "recipients": ["admin@company.com"]
    }
  },
  "executionTime": "2025-08-22T09:00:00Z"
}
```

#### Schedule a job for next week Monday at 8:00 AM
```json
{
  "name": "Weekly Cleanup",
  "description": "Weekly system cleanup",
  "jobData": {
    "type": "EXECUTE_FUNCTION",
    "source": "maintenance-service",
    "objectName": "cleanup",
    "data": {
      "scope": "system",
      "retention": "7days"
    }
  },
  "executionTime": "2025-08-25T08:00:00Z"
}
```

### Important Notes

1. **Execution Time Validation**: The system validates that the execution time is in the future
2. **Automatic Cleanup**: One-time jobs are automatically marked as completed after execution
3. **Timezone**: Use UTC timezone for execution times
4. **Job Status**: Jobs start with status `SCHEDULED` and progress through `RUNNING` to `COMPLETED` or `FAILED`
5. **Retry Logic**: Failed jobs can be retried based on the `maxRetries` configuration

### Error Handling

- **400 Bad Request**: Invalid input or execution time in the past
- **401 Unauthorized**: Missing or invalid authentication
- **500 Internal Server Error**: Server-side errors

### Monitoring Jobs

You can monitor your scheduled jobs using these endpoints:
- `GET /v1/jobs` - List all jobs
- `GET /v1/jobs/{id}` - Get specific job details  
- `GET /v1/jobs/search?name={name}` - Search jobs by name
- `PUT /v1/jobs/{id}` - Update a job configuration
- `DELETE /v1/jobs/{id}` - Delete a job

## Job Data Types

The service supports different job data types via the `jobData.type` field:

- **EXECUTE_FUNCTION**: Execute a function call on a remote service
- **SEND_EMAIL**: Send email notifications (requires mailer configuration)
- **WEBHOOK**: Make HTTP requests to external endpoints
- **CUSTOM**: Execute custom job logic

## Architecture

### Components

- **ScheduledJobController**: REST API endpoints for job management
- **ScheduledJobService**: Core business logic for job scheduling
- **PulsarConsumerService**: Handles distributed message processing
- **AuthenticateRequestService**: Handles API authentication
- **RecurringJobModel**: Database model for persistent job storage

### Database

The service uses PostgreSQL with TypeORM for data persistence:
- Jobs are stored with their configuration, status, and execution history
- Supports migrations for schema changes
- Configurable connection settings via environment variables

### Message Queue Integration

Apache Pulsar integration enables:
- Distributed job execution across multiple service instances
- Reliable message delivery and processing
- Scalable job processing with consumer groups

## Development

### Available Scripts

**Development Scripts:**
- `yarn dev` - Start development server with hot reload (local)
- `yarn docker:dev:full` - Start full Docker development environment (recommended)
- `yarn docker:dev` - Start microservice in Docker only
- `yarn docker:infrastructure` - Start PostgreSQL, Redis, and Pulsar services

**Build Scripts:**
- `yarn build` - Build the TypeScript project
- `yarn clean` - Clean build artifacts

**Docker Management:**
- `yarn docker:dev:restart` - Restart development container with rebuild
- `yarn docker:dev:down` - Stop microservice container
- `yarn docker:infrastructure:down` - Stop infrastructure services

**Database Scripts:**
- `yarn migration:run` - Execute database migrations
- `yarn migration:generate` - Generate new migrations
- `yarn migration:create` - Create a new migration file
- `yarn migration:revert` - Revert the last migration

**Testing & Code Quality:**
- `yarn test` - Run the test suite
- `yarn test:local` - Run tests with local database
- `yarn lint` - Run linting and formatting
- `yarn format` - Format code with Prettier

### Testing

Run the test suite:
```bash
yarn test
```

For local testing with a test database:
```bash
yarn test:local
```

### Docker Support

The service includes comprehensive Docker configuration:

**Development Files:**
- `Dockerfile.dev` - Development build with hot reload support
- `docker-compose.dev.yml` - Development environment with volume mounts
- `docker-entrypoint.dev.sh` - Development startup script with database auto-creation

**Production Files:**
- `Dockerfile` - Production build
- `docker-compose.yml` - Production environment
- `docker-entrypoint.sh` - Production startup script

**Infrastructure Files:**
- `docker-compose-postgres.yml` - PostgreSQL service
- `docker-compose-redis.yml` - Redis service  
- `docker-compose-pulsar.yml` - Apache Pulsar service

## Configuration

Key environment variables:
- `DATABASE_URL` - PostgreSQL connection string
- `PULSAR_SERVICE_URL` - Apache Pulsar broker URL
- `JWT_SECRET` - Secret key for JWT authentication
- `LOG_LEVEL` - Logging level (debug, info, warn, error)

## API Documentation

Swagger documentation is available at `/api-docs` when the service is running.

## Deployment

### Kubernetes

Kubernetes manifests are available in the `manifest/` directory for container orchestration deployment.

### CI/CD

The project includes:
- GitHub Actions workflows in `.github/workflows/`
- Bitbucket Pipelines configuration in `bitbucket-pipelines.yml`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite and linting
6. Submit a pull request

## License

ISC License
