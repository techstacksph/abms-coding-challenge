/* eslint-disable @typescript-eslint/no-var-requires */
require('reflect-metadata');
const { default: Container } = require('typedi');
require('typeorm');
require('typeorm-typedi-extensions');
require('dotenv').config();

class mockRedisClient {
  static store;
  constructor() {
    this.store = [];
  }
  async setValue(key, val, exSec) {
    this.store.push({ EX: exSec, key, val });
    return 'OK';
  }

  async getValue(key) {
    const find = this.store.find((x) => x.key == key);
    if (find) {
      return find.val;
    } else {
      return null;
    }
  }
  async delValue(key) {
    const find = this.store.find((x) => x.key == key);
    if (find) {
      this.store.pop(find);
    }
    return true;
  }
}

class mockPulsarProducerClient {
  async produce() {
    return 'test-message-id';
  }
  produceAsync() {
    // Fire and forget
  }
  async getCompanySettings() {
    return null;
  }
  async close() {
    return undefined;
  }
}

if (process.env.NODE_ENV == 'test') {
  jest.mock('./src/client/redis/RedisClient.ts', () => ({
    RedisClient: mockRedisClient,
  }));

  jest.mock('./src/client/pulsar/producer/PulsarProducerClient.ts', () => ({
    PulsarProducerClient: mockPulsarProducerClient,
  }));

  Container.set(mockRedisClient, new mockRedisClient());
  Container.set(mockPulsarProducerClient, new mockPulsarProducerClient());
}
