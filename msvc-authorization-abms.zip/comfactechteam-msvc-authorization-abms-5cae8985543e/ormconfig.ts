import path from 'path';
import { DataSource, DataSourceOptions, LoggerOptions } from 'typeorm';

import environment from './src/environment';

const subscriber_path = path.join('src/datasource/subscribers/**/*.{js,ts}');
const entity_path = path.join('src/datasource/models/**/*.{js,ts}');
const migration_path = path.join('src/datasource/migrations/**/*.{js,ts}');

let sql_logger_options: LoggerOptions;
if (environment.SHOW_SQL) {
  sql_logger_options = true;
} else {
  sql_logger_options = false;
}

// Helper function to get SSL configuration
const getSSLConfig = () => {
  if (
    !environment.DATABASE_SSL ||
    environment.DATABASE_SSL.toLowerCase() === 'false'
  ) {
    return false;
  }
  return {
    rejectUnauthorized: false,
  };
};

const dataSourceOptions: DataSourceOptions =
  environment.NODE_ENV != 'local'
    ? {
        cache: false,
        database: environment.DATABASE_NAME,
        entities: [entity_path],
        extra: {
          acquire: 30000, // Maximum time to wait for a connection
          connectionTimeoutMillis: 10000,
          idle: 10000, // Maximum time a connection can be idle
          max: 20, // Maximum number of connections in the pool
          min: 5, // Minimum number of connections in the pool
          query_timeout: 30000,
          ssl: {
            rejectUnauthorized: false,
          },
          statement_timeout: 30000,
        },
        host: environment.DATABASE_HOSTNAME,
        logging: sql_logger_options,
        migrations: [migration_path],
        migrationsRun: false,
        migrationsTableName: 'migrations',
        name: 'default',
        password: environment.DATABASE_PASSWORD,
        port: environment.DATABASE_PORT,
        subscribers: [subscriber_path],
        synchronize: false,
        type: 'postgres',
        username: environment.DATABASE_USERNAME,
      }
    : {
        cache: false,
        database: environment.DATABASE_NAME,
        entities: [entity_path],
        extra: {
          acquire: 30000, // Maximum time to wait for a connection
          connectionTimeoutMillis: 10000,
          idle: 10000, // Maximum time a connection can be idle
          max: 20, // Maximum number of connections in the pool
          min: 5, // Minimum number of connections in the pool
          query_timeout: 30000,
          ssl: getSSLConfig(),
          statement_timeout: 30000,
        },
        host: environment.DATABASE_HOSTNAME,
        logging: sql_logger_options,
        migrations: [migration_path],
        migrationsRun: false,
        migrationsTableName: 'migrations',
        name: 'default',
        password: environment.DATABASE_PASSWORD,
        port: environment.DATABASE_PORT,
        subscribers: [subscriber_path],
        synchronize: false,
        type: 'postgres',
        username: environment.DATABASE_USERNAME,
      };

export const appDataSource = new DataSource(dataSourceOptions);
