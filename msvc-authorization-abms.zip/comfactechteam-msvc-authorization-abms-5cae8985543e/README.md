# msvc-cto-authorization

Version: 1.0.0.0

 This project contains the source code for an Apollo federated GraphQL microservice. Its purpose is to support CTO's ecosystem of microservices.

## Installation

Node.js v18.17.1 is required to run this project.

**Node** : v18.17.1

 **NPM** : 9.6.7

 **Yarn** : 1.22.19

* Yarn will be used for executing command in package.json such as `yarn test`, `yarn dev`, `yarn build`, it will also be used or the installation of packages `yarn install`.

 **TypeScript** : 5.2.2

 **Jest** : 29.6.4

 **eslint** : 8.48.0

 **Apollo Server** : 4.9.3

 **Apollo Gateway** : 2.5.4

**Pulsar Client**: 1.9.0

**TypeORM:** ^0.3.17

## Fundamental tooling

1. **Language:** TypeScript
2. **Linter:** eslint
3. **Formatter:** Prettier
4. **Testing:** Jest
5. TypeORM: version 0.3.17 [see docs](https://www.npmjs.com/package/typeorm/v/0.2.45)

## .env Config

Create a .env file to the root folder with the following variables and sample.

* **APP_HOST_NAME**: This will be used in the swagger host
* **DATABASE_HOSTNAME**: Database hostname
* **DATABASE_NAME**: Database name
* **DATABASE_PASSWORD**: Databse password
* **DATABASE_PORT**: Datasbe port
* **DATABASE_SSL**: Datasbe SSL, if not using, do not include
* **DATABASE_USERNAME**: Datasbe user name
* **ENCRYPTION_KEY**: Authorization encryption key
* **JWT_ISSUER**: JWT issuer name
* **JWT_SECRET_KEY**: JWT secret key
* **LOG_LEVEL**: Log level
* **NODE_ENV**: Node environment
* **PORT**: Application port
* **PULSAR_SERVICE_URL**: Pulsar service URL (default: pulsar://localhost:6650)
* **PULSAR_AUTH_TOKEN**: Pulsar authentication token (optional, for secured clusters)
* **PULSAR_TLS_ENABLED**: Enable TLS for Pulsar connection (true/false, default: false)
* **PULSAR_TLS_TRUST_CERT_PATH**: Path to TLS trust certificate file (optional)
* **REDIS_URL**: Redist url/hostname
* **SHOW_SQL**: Show SQL for debugging purpose
* **SWAGGER_SCHEMES**: swagger schemes
* **SYSTEM_ADMIN_SECRET**: Admin secret, super admin credential key
* **SYSTEM_ID**: Application name

```bash
APP_HOST_NAME=locahost:8080/
DATABASE_HOSTNAME=localhost
DATABASE_NAME=CTO_Authorization
DATABASE_PASSWORD=root
DATABASE_PORT=5432
DATABASE_SSL=
DATABASE_USERNAME=root
ENCRYPTION_KEY=1d7b31a4aa5811ecb9090242ac120002
JWT_ISSUER=CTO
JWT_SECRET_KEY=79da9c36-ab2b-11ec-b909-0242ac120002
LOG_LEVEL=info/error/debug
NODE_ENV=local/staging/production/test
PORT=8080
REDIS_URL=redis://localhost:6379
SHOW_SQL=false
SWAGGER_SCHEMES=http,https
SYSTEM_ADMIN_SECRET=this_is_the_system_admin_secret_internal_use_only
SYSTEM_ID=msvc-cto-authorization
```

## Usage

To run the microservice locally with nodemon, such as in development:

```bash
yarn install
yarn dev
```

To build the service, and start the service in production mode:

* `yarn build`
* `yarn start`

Please ensure that you have linted and run all tests against your code prior to submitting a merge request.

* `yarn lint`
* `yarn test`

## Docker build

The Dockerfile also requires Nexus credentials. To build the image locally, please ensure that you export environment variables with your Nexus credentials, and then pass them to the build command via a build arg, like so:

### For all platform

* `docker build -t msvc-cto-authorization:latest . --progress=plain`

### For amd64 platform

* `docker build -t msvc-cto-authorization:latest . --progress=plain --platform linux/amd64`

### Database Migration [see docs](https://typeorm.io/migrations)

* Generate migration script from existing database `name={migration-filename} yarn migration:generate`
* Create migration script template `name={migration-filename} yarn migration:create`
* Run migration script `yarn migration:run`
* Revert last migrated script `yarn migration:revert`
* Show migrated script `yarn migration:show`

## Docker compose files included in the code base

Make sure to create docker network local bridge by executing `docker network create local_bridge --driver bridge`

* **POSTGRES**: To run execute `docker compose -f docker-compose-postgres.yml up -d`, to stop `docker compose -f docker-compose-postgres.yml down`
* **REDIS**: To run execute `docker compose -f docker-compose-redis.yml up -d`, to stop `docker compose -f docker-compose-redis.yml down`
* **PULSAR**: To run execute `docker compose -f docker-compose-pulsar.yml up -d`, to stop `docker compose -f docker-compose-pulsar.yml down`
* **MSVC-MICROSERVICE**: To run execute `docker compose up -d`, to stop `docker compose down` since the default `docker-compose.yml` contains the microservice config file

## Docker Development Environment (Hot Reload)

For development purposes, this project includes a Docker development environment that supports hot reloading of code changes without rebuilding containers. This setup dramatically improves developer productivity by eliminating build times during development.

### Features

- ⚡ **Hot Reload**: Code changes in `src/` folder automatically restart the server
- 🏠 **Isolated Environment**: Separate development database (`DOCKER_MSVC_AUTHORIZATION`)
- 🚀 **One-Command Setup**: Complete environment starts with single command
- 📱 **Web UIs**: Access to Redis Commander, Pulsar Express, and API endpoints
- 🔧 **Consistent Environment**: All developers use identical setup

### Quick Start

```bash
# Start complete development environment (recommended for first time)
yarn docker:dev:full

# Start only the microservice (if infrastructure is already running)
yarn docker:dev

# Start only infrastructure services (PostgreSQL, Redis, Pulsar)
yarn docker:infrastructure
```

### Available Docker Scripts

| Script | Description |
|--------|-------------|
| `yarn docker:dev:full` | Start complete development environment (infrastructure + microservice) |
| `yarn docker:dev` | Start microservice only (requires infrastructure to be running) |
| `yarn docker:infrastructure` | Start shared services (PostgreSQL, Redis, Pulsar) |
| `yarn docker:dev:down` | Stop development microservice |
| `yarn docker:infrastructure:down` | Stop infrastructure services |

### Development vs Production

#### Development Environment (docker-compose.dev.yml)
- Uses `Dockerfile.dev` optimized for development
- Source code mounted as volumes for hot reloading
- Separate development database: `DOCKER_MSVC_AUTHORIZATION`
- Includes all environment variables for local development
- Automatic database creation on startup
- Runs migrations automatically

#### Production Environment (docker-compose.yml)
- Uses `Dockerfile` with built application
- No volume mounts (source code copied into image)
- Production database configuration
- Optimized for deployment

### Environment Variables (Development)

The development environment includes these key variables:

```bash
# Database Configuration
DATABASE_NAME=DOCKER_MSVC_AUTHORIZATION
DATABASE_HOSTNAME=postgres-service
DATABASE_USERNAME=root
DATABASE_PASSWORD=root

# Microservice Integration
TENANT_PREFIX=abms
AUTH_API_URL=http://msvc-authorization:8082
MFE_ROOT_URL=http://localhost:3005
ENVIRONMENT_NAME=dev
DEFAULT_TIMEZONE=Pacific/Auckland

# Service URLs
REDIS_URL=redis://redis-service:6379
PULSAR_SERVICE_URL=pulsar://pulsar-service:6650
```

#### Custom Environment Variables (.env.local)

For local development with custom Pulsar authentication settings, create a `.env.local` file in the project root:

```bash
# Example .env.local for Pulsar authentication
PULSAR_SERVICE_URL=pulsar://your-pulsar-server:6650
PULSAR_AUTH_TOKEN=your-jwt-token-here
PULSAR_TLS_ENABLED=true
PULSAR_TLS_TRUST_CERT_PATH=/path/to/cert.pem
```

The development scripts (`yarn docker:dev` and `yarn docker:dev:full`) will automatically load variables from `.env.local` if the file exists.

### File Structure

```
├── Dockerfile.dev              # Development Docker image
├── docker-compose.dev.yml      # Development compose configuration
├── docker-entrypoint.dev.sh    # Development startup script
├── Dockerfile                  # Production Docker image
└── docker-compose.yml          # Production compose configuration
```

### How Hot Reload Works

1. **Volume Mounting**: Source code (`./src`) is mounted into the container at `/code/src`
2. **Nodemon**: Development container runs `nodemon` which watches for file changes
3. **Auto Restart**: When files change, nodemon automatically restarts the Node.js process
4. **No Rebuild**: Container doesn't need to be rebuilt for code changes

### Accessing Services

When running the development environment:

- **Authorization API**: http://localhost:8082
- **API Documentation**: http://localhost:8082/swagger
- **PostgreSQL**: localhost:5432 (user: root, password: root)
- **Redis**: localhost:6379
- **Pulsar**: localhost:8080 (Pulsar Express UI)

### Troubleshooting

#### Common Issues

**Port Conflicts**
```bash
# Check what's using the port
lsof -i :8082
# Kill the process if needed
kill -9 <PID>
```

**Network Issues**
```bash
# Recreate the Docker network
docker network rm local_bridge
docker network create local_bridge
```

**Database Connection Issues**
```bash
# Check if PostgreSQL is ready
docker logs postgres-service
```

**Permission Issues on macOS/Linux**
```bash
# Make sure the entrypoint script is executable
chmod +x docker-entrypoint.dev.sh
```

#### Clean Restart

```bash
# Stop everything and clean up
yarn docker:dev:down
yarn docker:infrastructure:down
docker system prune -f

# Start fresh
yarn docker:dev:full
```

### Development Workflow

1. **Initial Setup**
   ```bash
   yarn docker:dev:full
   ```

2. **Daily Development**
   ```bash
   # Infrastructure should already be running
   yarn docker:dev
   ```

3. **Making Changes**
   - Edit files in `src/` folder
   - Changes automatically trigger server restart
   - Check logs: `docker logs msvc-authorization`

4. **Database Changes**
   ```bash
   # Generate migration (from host machine)
   name=AddNewTable yarn migration:generate
   
   # Restart development container to apply migration
   yarn docker:dev:down && yarn docker:dev
   ```

### Integration with Other Microservices

This development environment is designed to work with other microservices in the CTO ecosystem:

- **msvc-abms**: Main ABMS microservice
- **msvc-scheduler-abms**: Scheduling service
- **msvc-abms-communication-media**: Communication service
- **msvc-gw-apollo-abms**: API Gateway

All services should use the same `local_bridge` network and follow the same development patterns for seamless integration.
