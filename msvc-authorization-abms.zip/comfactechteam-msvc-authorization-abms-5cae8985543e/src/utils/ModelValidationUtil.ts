import { ValidationError } from 'class-validator';

class errorValidationMessage {
  property!: string;
  value!: unknown;
  message!: unknown;
}

export function errorValidationResponse(
  errors: ValidationError[]
): errorValidationMessage[] {
  const message: errorValidationMessage[] = [];

  for (const error of errors) {
    for (const key in error.constraints) {
      message.push({
        message: error.constraints[key],
        property: error.property,
        value: error.value,
      });
    }

    if (error.children && error.children.length > 0) {
      for (const childError of error.children) {
        for (const key in childError.constraints) {
          message.push({
            message: childError.constraints[key],
            property: childError.property,
            value: childError.value,
          });
        }
      }
    }
  }
  return message;
}
