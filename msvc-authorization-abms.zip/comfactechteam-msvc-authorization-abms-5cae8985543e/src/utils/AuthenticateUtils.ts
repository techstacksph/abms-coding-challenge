import { NextFunction, Request, Response } from 'express';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import environment from '../environment';
import { logger } from './LoggerUtils';
import { ErrorKeyTypes } from './StaticMessageCodeUtils';

export async function authenticate(
  req: Request,
  res: Response,
  next: NextFunction
) {
  if (isSecure(req.url) && !req.headers.authorization) {
    logger.warn(`authorization_not_found`, { url: req.url });
    return res
      .status(401)
      .send(
        new ApiErrorResponseDto(
          401,
          'authenticate_request',
          ErrorKeyTypes.AUTHORIZATION_HEADER_NOT_FOUND
        )
      );
  }

  if (
    req.url.includes('/auth/organization') &&
    req.headers.authorization &&
    req.headers.authorization == environment.SYSTEM_ADMIN_SECRET
  ) {
    Object.assign(req, {
      IS_SYSTEM_ADMIN: true,
      SYSTEM_ADMIN_SECRET: environment.SYSTEM_ADMIN_SECRET,
    });
  } else if (
    req.url.includes('/auth/organization') &&
    req.headers.authorization &&
    req.headers.authorization != environment.SYSTEM_ADMIN_SECRET
  ) {
    logger.warn(`authorization_not_found`, { url: req.url });
    return res
      .status(401)
      .send(
        new ApiErrorResponseDto(
          401,
          'authenticate_request',
          ErrorKeyTypes.AUTHORIZATION_HEADER_NOT_SYSTEM_ADMIN
        )
      );
  }

  next();
}

function isSecure(url: string): boolean {
  if (
    url.includes('/auth/') ||
    (url.includes('/authenticate/') && !url.includes('/authenticate/refresh'))
  ) {
    return true;
  } else {
    return false;
  }
}
