/**
 * Permission utility functions for checking user access
 */

/**
 * Interface for user permissions object
 */
export interface UserPermissions {
  access: string[];
}

type UserPermissionType = UserPermissions | null | undefined;
/**
 * Check if user has access to a specific permission
 * @param userPermissions - Permission object from user (contains access array)
 * @param module - Module code (e.g., 'franchiseehub', 'account', 'user')
 * @param action - Permission action ('read', 'create', 'update', 'delete', or '*' for all)
 * @param attribute - Permission attribute (usually '*' for full access)
 * @returns boolean - true if user has permission
 *
 * @example
 * // Check for franchisee hub access
 * hasPermission(user.permissions, 'franchiseehub');
 *
 * // Check for specific action
 * hasPermission(user.permissions, 'franchiseehub', 'read');
 *
 * // Check for admin wildcard access
 * hasPermission(user.permissions, 'account'); // Returns true if user has account.*.* or *.*.*
 */
export function hasPermission(
  userPermissions: UserPermissionType,
  module: string,
  action: string = '*',
  attribute: string = '*'
): boolean {
  // Validate input
  if (!userPermissions || !userPermissions.access) {
    return false;
  }

  if (!Array.isArray(userPermissions.access)) {
    return false;
  }

  // Check for wildcard admin access (full system access)
  if (userPermissions.access.includes('*.*.*')) {
    return true;
  }

  // Check for module-level wildcard (full module access)
  if (userPermissions.access.includes(`${module}.*.*`)) {
    return true;
  }

  // Check for specific permission string
  const permissionString = `${module}.${action}.${attribute}`;
  if (userPermissions.access.includes(permissionString)) {
    return true;
  }

  // Check for action-level wildcard
  if (action !== '*') {
    const actionWildcard = `${module}.${action}.*`;
    if (userPermissions.access.includes(actionWildcard)) {
      return true;
    }
  }

  return false;
}

/**
 * Check if user has any of the specified permissions
 * @param userPermissions - Permission object from user
 * @param modules - Array of module codes to check
 * @returns boolean - true if user has at least one of the permissions
 *
 * @example
 * hasAnyPermission(user.permissions, ['franchiseehub', 'clienthub']);
 */
export function hasAnyPermission(
  userPermissions: UserPermissionType,
  modules: string[]
): boolean {
  for (const module of modules) {
    if (hasPermission(userPermissions, module)) {
      return true;
    }
  }
  return false;
}

/**
 * Check if user has all of the specified permissions
 * @param userPermissions - Permission object from user
 * @param modules - Array of module codes to check
 * @returns boolean - true if user has all of the permissions
 *
 * @example
 * hasAllPermissions(user.permissions, ['account', 'user']);
 */
export function hasAllPermissions(
  userPermissions: UserPermissionType,
  modules: string[]
): boolean {
  for (const module of modules) {
    if (!hasPermission(userPermissions, module)) {
      return false;
    }
  }
  return true;
}
