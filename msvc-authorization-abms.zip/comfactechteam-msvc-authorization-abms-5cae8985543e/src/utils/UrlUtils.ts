/**
 * Ensures a URL has a protocol (defaults to https://)
 * @param url - The URL string that may or may not have a protocol
 * @param defaultProtocol - The default protocol to use (default: 'https')
 * @returns URL string with protocol
 *
 * @example
 * ensureProtocol('example.com') // returns 'https://example.com'
 * ensureProtocol('http://example.com') // returns 'http://example.com'
 * ensureProtocol('https://example.com') // returns 'https://example.com'
 */
export function ensureProtocol(
  url: string,
  defaultProtocol: 'https' | 'http' = 'https'
): string {
  if (!url) {
    return url;
  }

  // Check if URL already has a protocol
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return url;
  }

  // Add the default protocol
  return `${defaultProtocol}://${url}`;
}

/**
 * Creates a URL with ensured protocol
 * @param path - The path to append to the base URL
 * @param baseUrl - The base URL (will have protocol added if missing)
 * @param defaultProtocol - The default protocol to use (default: 'https')
 * @returns Complete URL string
 *
 * @example
 * createUrlWithProtocol('/login', 'example.com') // returns 'https://example.com/login'
 * createUrlWithProtocol('/api', 'http://example.com') // returns 'http://example.com/api'
 */
export function createUrlWithProtocol(
  path: string,
  baseUrl: string,
  defaultProtocol: 'https' | 'http' = 'https'
): string {
  if (!baseUrl || baseUrl.trim() === '') {
    throw new Error(`Invalid base URL provided for path '${path}'. Base URL is empty or undefined. Please check MAIN_APP_HOST_NAME environment variable.`);
  }

  try {
    const urlWithProtocol = ensureProtocol(baseUrl, defaultProtocol);
    return new URL(path, urlWithProtocol).toString();
  } catch (error) {
    throw new Error(`Failed to create URL with path '${path}' and base URL '${baseUrl}': ${(error as Error).message}. Please check MAIN_APP_HOST_NAME environment variable.`);
  }
}
