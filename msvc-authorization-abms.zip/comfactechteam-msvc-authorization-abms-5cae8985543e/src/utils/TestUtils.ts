import 'reflect-metadata';

import cookieParser from 'cookie-parser';
import express, { Application } from 'express';
import { Action, useContainer, useExpressServer } from 'routing-controllers';
import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';

import { ControllerInitializer } from '../controller/ControllerInitializer';
import { appDataSource } from '../datasource/config/database';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { CustomUnauthorizedError } from '../errors/CustomUnauthorizedError';
import { AuthenticateRequestService } from '../services/AuthenticateRequestService';
import { httpLogger, logger } from './LoggerUtils';

@Service()
export class AppServerUtils {
  private app: Application;

  constructor() {
    this.app = express();
  }

  async startServer(): Promise<Application> {
    await appDataSource.initialize();
    if (appDataSource.isInitialized) {
      logger.debug(`database_initialized`, {
        status: appDataSource.isInitialized ? 'connected' : 'not_connected',
      });
      this.initExpress();
    }
    return this.app;
  }

  async closeServer(): Promise<void> {
    if (appDataSource.isInitialized) {
      appDataSource.destroy();
    }
  }

  initExpress() {
    useContainer(Container);
    this.app.use(httpLogger);
    this.app.use(cookieParser());
    this.app.use(express.json());

    const authenticateRequestService: AuthenticateRequestService =
      Container.get(AuthenticateRequestService);

    const controllerInitializer: ControllerInitializer = Container.get(
      ControllerInitializer
    );

    useExpressServer(this.app, {
      authorizationChecker: async (action: Action): Promise<boolean> => {
        const auth = await authenticateRequestService.authenticate(
          action.request
        );
        if (!auth.VALID) {
          throw new CustomUnauthorizedError(auth.STATUS_DESCRIPTION);
        }
        return Promise.resolve(auth.VALID);
      },
      controllers: controllerInitializer.controllers(),
      cors: true,
      currentUserChecker: async (
        action: Action
      ): Promise<ClientAuthenticationDto> => {
        const authenticate = authenticateRequestService.authenticate(
          action.request
        );
        return Promise.resolve(authenticate);
      },
      validation: false,
    });
  }
}
