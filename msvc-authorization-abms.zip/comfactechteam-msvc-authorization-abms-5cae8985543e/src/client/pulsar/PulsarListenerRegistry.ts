import { Client, ClientConfig } from 'pulsar-client';
import { Service } from 'typedi';

import environment from '../../environment';
import { logger } from '../../utils/LoggerUtils';
import { SampleSubscriberClient } from './subscriber/SampleSubscriberClient';

export interface IListenerMethod {
  (): void;
}

export interface IListener {
  TOPIC: string;
  SUBSCRIPTION: string;
  listen: IListenerMethod;
}

@Service()
export class PulsarListenerRegistry {
  private listeners: IListener[];

  constructor() {
    const client = new Client(this.buildPulsarConfig());

    this.listeners = [new SampleSubscriberClient(client)];
  }

  private buildPulsarConfig(): ClientConfig {
    const config: ClientConfig = {
      serviceUrl: environment.PULSAR_SERVICE_URL,
      operationTimeoutSeconds: 60,
    };

    if (environment.PULSAR_AUTH_TOKEN) {
      config.authentication = {
        method: 'token',
        token: environment.PULSAR_AUTH_TOKEN,
      };
    }

    if (environment.PULSAR_TLS_ENABLED) {
      if (environment.PULSAR_TLS_TRUST_CERT_PATH) {
        config.tlsTrustCertsFilePath = environment.PULSAR_TLS_TRUST_CERT_PATH;
        config.tlsValidateHostname = true;
        config.tlsAllowInsecureConnection = false;
      } else {
        // For StreamNative cloud, trust system certificates
        config.tlsValidateHostname = true;
        config.tlsAllowInsecureConnection = true;
      }
    }

    return config;
  }

  async startListen(): Promise<void> {
    for (const listener of this.listeners) {
      try {
        await listener.listen();
      } catch (err) {
        logger.error(err);
      }
    }
  }
}
