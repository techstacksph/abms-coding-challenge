import 'reflect-metadata';

import * as redis from 'redis';
import { Service } from 'typedi';

import environment from '../../environment';
import { friendlyError } from '../../utils/ExceptionUtils';
import { ErrorKeyTypes } from '../../utils/StaticMessageCodeUtils';

@Service()
export class RedisClient {
  private readonly EXPIRATION_DEFAULT = 86400;

  private readonly REDIS_PREFIX_KEY = environment.SYSTEM_ID;

  async setValue(
    key: string,
    val: string,
    exSec?: number
  ): Promise<string | null> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });
    try {
      await redisClient.connect();
    } catch (error) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REDIS_IS_DOWN),
        'redis_set_value'
      );
    }
    const expireSec = exSec ?? this.EXPIRATION_DEFAULT;
    const result = await redisClient.set(
      `${environment.REDIS_PREFIX}:${key}`,
      val,
      {
        EX: expireSec,
      }
    );
    await redisClient.quit();
    return result;
  }

  async getValue(key: string): Promise<string | null> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });
    try {
      await redisClient.connect();
    } catch (error) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REDIS_IS_DOWN),
        'redis_set_value'
      );
    }
    const result = await redisClient.get(`${environment.REDIS_PREFIX}:${key}`);
    await redisClient.quit();
    return result;
  }

  async delValue(key: string): Promise<boolean> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });
    try {
      await redisClient.connect();
    } catch (error) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REDIS_IS_DOWN),
        'redis_delete_value'
      );
    }
    const result = await redisClient.del(`${environment.REDIS_PREFIX}:${key}`);
    await redisClient.quit();
    return result > 0;
  }

  async getTTL(key: string): Promise<number> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });
    try {
      await redisClient.connect();
    } catch (error) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REDIS_IS_DOWN),
        'redis_get_ttl'
      );
    }
    const result = await redisClient.ttl(`${environment.REDIS_PREFIX}:${key}`);
    await redisClient.quit();
    return result;
  }

  async scanKeys(pattern: string): Promise<string[]> {
    const redisClient = redis.createClient({
      password: environment.REDIS_PASSWORD,
      url: environment.REDIS_URL,
    });

    try {
      await redisClient.connect();
    } catch (error) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REDIS_IS_DOWN),
        'redis_scan_keys'
      );
    }

    const keys: string[] = [];
    const fullPattern = `${environment.REDIS_PREFIX}:${pattern}`;

    // Use SCAN to iterate through keys matching the pattern
    let cursor = 0;
    do {
      const result = await redisClient.scan(cursor, {
        MATCH: fullPattern,
        COUNT: 100,
      });
      cursor = result.cursor;
      keys.push(
        ...result.keys.map((k) => k.replace(`${environment.REDIS_PREFIX}:`, ''))
      );
    } while (cursor !== 0);

    await redisClient.quit();
    return keys;
  }
}
