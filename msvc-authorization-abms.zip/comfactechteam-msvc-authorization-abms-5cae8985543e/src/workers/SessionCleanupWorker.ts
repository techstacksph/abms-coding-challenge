import 'reflect-metadata';

import { Service } from 'typedi';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { RedisClient } from '../client/redis/RedisClient';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { AuthorizationService } from '../services/AuthorizationService';
import { logger } from '../utils/LoggerUtils';

/**
 * SessionCleanupWorker
 * Periodically checks for inactive user sessions and auto-logs them out
 * Runs every 5 minutes to check for inactivity timeouts
 */
@Service()
export class SessionCleanupWorker {
  private intervalId?: NodeJS.Timeout;
  private readonly CLEANUP_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

  constructor(
    private redisClient: RedisClient,
    private authService: AuthorizationService,
    private pulsarClient: PulsarProducerClient
  ) {}

  /**
   * Start the cleanup worker
   */
  async start() {
    logger.info('SessionCleanupWorker starting...');

    // Run immediately on start
    await this.cleanupInactiveSessions();

    // Then run every 5 minutes
    this.intervalId = setInterval(() => {
      this.cleanupInactiveSessions().catch((err) => {
        logger.error('session_cleanup_error', {
          error: (err as Error).message,
        });
      });
    }, this.CLEANUP_INTERVAL_MS);

    logger.info('SessionCleanupWorker started successfully');
  }

  /**
   * Stop the cleanup worker
   */
  async stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = undefined;
      logger.info('SessionCleanupWorker stopped');
    }
  }

  /**
   * Main cleanup logic - scans for inactive sessions and logs them out
   */
  private async cleanupInactiveSessions() {
    const startTime = Date.now();
    logger.debug('session_cleanup_started');

    try {
      // Scan for all activity keys
      const activityKeys = await this.scanKeys(
        `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_*`
      );

      let cleanedCount = 0;
      let activeCount = 0;
      let errorCount = 0;

      for (const activityKey of activityKeys) {
        try {
          // Parse userType and userName from activity key
          // Format: USER_LAST_ACTIVITY_{userType}_{userName}
          const keyWithoutPrefix = activityKey.replace(
            `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_`,
            ''
          );

          // Split on first underscore only (handles usernames with underscores)
          const firstUnderscoreIndex = keyWithoutPrefix.indexOf('_');

          if (firstUnderscoreIndex === -1) {
            logger.error('invalid_activity_key_format', {
              activityKey,
              expectedFormat: `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_{userType}_{userName}`,
            });
            continue;
          }

          const userType = keyWithoutPrefix.substring(0, firstUnderscoreIndex);
          const userName = keyWithoutPrefix.substring(firstUnderscoreIndex + 1);

          // Validate userType
          if (!['ADMIN', 'FRANCHISEE', 'CLIENT'].includes(userType)) {
            logger.error('invalid_user_type_in_activity_key', {
              activityKey,
              userType,
            });
            continue;
          }

          // Get user's permission to retrieve org ID
          const permissionKey = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userType}_${userName}`;
          const permissionData = await this.redisClient.getValue(permissionKey);

          logger.info('session_cleanup_permission_data', { permissionData, userName, userType });

          if (!permissionData) {
            // Session doesn't exist anymore, clean up activity key
            await this.redisClient.delValue(activityKey);
            continue;
          }

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const userPermission = JSON.parse(permissionData) as any;
          const orgId = userPermission.organization_id;

          // Check if inactive
          const isInactive = await this.authService.checkInactivityTimeout(
            userName,
            orgId,
            userType
          );

          if (isInactive) {
            // Auto-logout user
            await this.authService.destroyUserLoginCacheByUserName(userName, userType);

            // Clean up activity key
            await this.redisClient.delValue(activityKey);

            // Emit audit event
            await this.emitAuditEvent(userName, orgId);

            cleanedCount++;
            logger.info('user_auto_logged_out_inactivity', {
              userName,
              userType,
              orgId,
            });
          } else {
            activeCount++;
          }
        } catch (error) {
          errorCount++;
          logger.error('session_cleanup_item_error', {
            error: (error as Error).message,
            activityKey,
          });
        }
      }

      const duration = Date.now() - startTime;

      logger.info('session_cleanup_completed', {
        duration: `${duration}ms`,
        totalScanned: activityKeys.length,
        cleanedCount,
        activeCount,
        errorCount,
      });
    } catch (error) {
      logger.error('session_cleanup_failed', {
        error: (error as Error).message,
        duration: `${Date.now() - startTime}ms`,
      });
    }
  }

  /**
   * Scan Redis keys matching a pattern
   * Uses SCAN for safe iteration without blocking
   */
  private async scanKeys(pattern: string): Promise<string[]> {
    try {
      return await this.redisClient.scanKeys(pattern);
    } catch (error) {
      logger.error('redis_scan_error', {
        error: (error as Error).message,
        pattern,
      });
      return [];
    }
  }

  /**
   * Emit audit event for session expiration
   */
  private async emitAuditEvent(userName: string, orgId: string) {
    try {
      await this.pulsarClient.produce(PulsarTopics.BACK_OFFICE, {
        action: PulsarDataAction.UPDATE,
        objectName: 'user_session',
        data: {
          userName,
          orgId,
          action: 'SESSION_EXPIRED_INACTIVITY',
          timestamp: new Date().toISOString(),
          reason: 'Inactivity timeout exceeded',
        },
      });
    } catch (error) {
      logger.error('audit_event_emission_failed', {
        error: (error as Error).message,
        userName,
        orgId,
      });
    }
  }
}
