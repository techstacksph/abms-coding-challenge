import 'reflect-metadata';

import path from 'path';
import { DataSource, DataSourceOptions, LoggerOptions } from 'typeorm';

import environment from '../../environment';

// Database connection pool constants
const DB_CONNECTION_CONFIG = {
  ACQUIRE_TIMEOUT: 30000, // Maximum time to wait for a connection
  CONNECTION_TIMEOUT: 10000, // Connection timeout
  IDLE_TIMEOUT: 10000, // Maximum time a connection can be idle
  MAX_CONNECTIONS: 20, // Maximum number of connections in the pool
  MIN_CONNECTIONS: 5, // Minimum number of connections in the pool
  QUERY_TIMEOUT: 30000, // Query timeout
  STATEMENT_TIMEOUT: 30000, // Statement timeout
} as const;

const subscriber_path = path.join(__dirname + './../subscribers/**/*.{js,ts}');
const entity_path = path.join(__dirname + './../models/**/*.{js,ts}');
const migration_path = path.join(__dirname + './../migrations/**/*.{js,ts}');

let sql_logger_options: LoggerOptions;
if (environment.SHOW_SQL) {
  sql_logger_options = true;
} else {
  sql_logger_options = false;
}

let dataSourceOptions: DataSourceOptions;

if (environment.NODE_ENV.toLowerCase() != 'test') {
  const baseConfig = {
    database: environment.DATABASE_NAME,
    entities: [entity_path],
    host: environment.DATABASE_HOSTNAME,
    logging: sql_logger_options,
    migrations: [migration_path],
    name: 'default',
    password: environment.DATABASE_PASSWORD,
    port: environment.DATABASE_PORT,
    subscribers: [subscriber_path],
    synchronize: false,
    type: 'postgres' as const,
    username: environment.DATABASE_USERNAME,
  };

  // Common connection pool configuration
  const commonExtraConfig = {
    acquire: DB_CONNECTION_CONFIG.ACQUIRE_TIMEOUT,
    connectionTimeoutMillis: DB_CONNECTION_CONFIG.CONNECTION_TIMEOUT,
    idle: DB_CONNECTION_CONFIG.IDLE_TIMEOUT,
    max: DB_CONNECTION_CONFIG.MAX_CONNECTIONS,
    min: DB_CONNECTION_CONFIG.MIN_CONNECTIONS,
    query_timeout: DB_CONNECTION_CONFIG.QUERY_TIMEOUT,
    statement_timeout: DB_CONNECTION_CONFIG.STATEMENT_TIMEOUT,
  };

  if (environment.NODE_ENV === 'local') {
    // Local development without SSL
    dataSourceOptions = {
      ...baseConfig,
      extra: commonExtraConfig,
    };
  } else {
    // Remote environments with SSL
    dataSourceOptions = {
      ...baseConfig,
      extra: {
        ...commonExtraConfig,
        ssl: {
          rejectUnauthorized: false,
        },
      },
    };
  }
} else {
  dataSourceOptions = {
    database: `./sqlite/${Date.now()}_test.sqlite`,
    entities: ['./src/datasource/models/*{.ts,.js}'],
    logging: sql_logger_options,
    name: 'default',
    synchronize: true,
    type: 'sqlite',
  };
}

export const appDataSource = new DataSource(dataSourceOptions);
