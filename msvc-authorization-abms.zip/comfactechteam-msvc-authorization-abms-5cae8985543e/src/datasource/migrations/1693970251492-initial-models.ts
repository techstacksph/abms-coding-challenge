import { MigrationInterface, QueryRunner } from 'typeorm';

export class initialModels1693970251492 implements MigrationInterface {
  name = 'initialModels1693970251492';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "organizations" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "code" character varying NOT NULL, "name" character varying NOT NULL, "description" character varying, "externalId" character varying NOT NULL, "status" text NOT NULL DEFAULT 'CREATED', CONSTRAINT "PK_6b031fcd0863e3f6b44230163f9" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexOrganization_ExternalId" ON "organizations" ("externalId") WHERE "deletedAt" IS NULL`
    );
    await queryRunner.query(
      `CREATE TABLE "users" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "externalId" character varying NOT NULL, "userName" character varying NOT NULL, "passwordHash" character varying NOT NULL, "status" text NOT NULL DEFAULT 'ACTIVE', "email" character varying NOT NULL, "orgId" character varying NOT NULL, "permissions" text NOT NULL DEFAULT '{}', CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexUser_UserName" ON "users" ("userName") WHERE "deletedAt" IS NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."UniqueIndexUser_UserName"`);
    await queryRunner.query(`DROP TABLE "users"`);
    await queryRunner.query(
      `DROP INDEX "public"."UniqueIndexOrganization_ExternalId"`
    );
    await queryRunner.query(`DROP TABLE "organizations"`);
  }
}
