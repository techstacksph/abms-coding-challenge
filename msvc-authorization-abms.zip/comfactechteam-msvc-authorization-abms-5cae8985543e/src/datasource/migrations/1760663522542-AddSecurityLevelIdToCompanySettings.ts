import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddSecurityLevelIdToCompanySettings1760663522542
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Add securityLevelId column to companysettings table
    await queryRunner.query(
      `ALTER TABLE "companysettings" ADD "securityLevelId" uuid`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Remove securityLevelId column from companysettings table
    await queryRunner.query(
      `ALTER TABLE "companysettings" DROP COLUMN "securityLevelId"`
    );
  }
}
