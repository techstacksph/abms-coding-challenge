import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS3659ADDLEAVETYPEDETAILSPERMISSION1757668459818
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                            SELECT id, permissions
                            FROM users
                            WHERE "deletedAt" IS NULL
                        `);

    for (const user of users) {
      let permissions = {
        access: [] as string[],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      // Check if permission already exists to avoid duplicates
      if (!permissions.access.includes('leavetypedetails.*.*')) {
        Object.assign(permissions, {
          access: [...permissions.access, 'leavetypedetails.*.*'],
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                                SELECT id, permissions
                                FROM users
                                WHERE "deletedAt" IS NULL
                        `);

    for (const user of users) {
      let permissions = {
        access: [] as string[],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      const newPermissions = ['leavetypedetails.*.*'];

      Object.assign(permissions, {
        access: permissions.access.filter(
          (item) => newPermissions.indexOf(item) == -1
        ),
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }
}
