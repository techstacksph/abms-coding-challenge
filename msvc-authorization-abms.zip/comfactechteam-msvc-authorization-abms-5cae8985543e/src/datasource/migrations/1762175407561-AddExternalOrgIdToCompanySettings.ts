import { MigrationInterface, QueryRunner } from "typeorm";
import { TestIds } from "../../test/SampleData";

export class AddExternalOrgIdToCompanySettings1762175407561 implements MigrationInterface {
    name = 'AddExternalOrgIdToCompanySettings1762175407561'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "companysettings" ADD "externalOrgId" character varying`);
        // Set all existing company settings to have an externalOrgId to 714f6f30-a65b-11ec-b909-0242ac120004
        await queryRunner.query(`UPDATE "companysettings" SET "externalOrgId" = '714f6f30-a65b-11ec-b909-0242ac120004'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "companysettings" DROP COLUMN "externalOrgId"`);
    }

}
