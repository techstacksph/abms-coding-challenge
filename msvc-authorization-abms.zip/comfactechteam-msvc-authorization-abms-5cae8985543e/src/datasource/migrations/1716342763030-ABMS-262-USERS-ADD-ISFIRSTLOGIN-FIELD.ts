import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS262USERSADDISFIRSTLOGINFIELD1716342763030
  implements MigrationInterface
{
  name = 'ABMS262USERSADDISFIRSTLOGINFIELD1716342763030';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" ADD "isFirstlogin" boolean`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "isFirstlogin"`);
  }
}
