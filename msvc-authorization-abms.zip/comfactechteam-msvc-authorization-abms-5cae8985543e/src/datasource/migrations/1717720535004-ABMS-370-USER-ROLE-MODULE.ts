import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS370USERROLEMODULE1717720535004 implements MigrationInterface {
  name = 'ABMS370USERROLEMODULE1717720535004';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "roles" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "externalId" character varying NOT NULL, "name" character varying NOT NULL, "externalOrgId" character varying NOT NULL, "permissions" text NOT NULL DEFAULT '{}', CONSTRAINT "PK_c1433d71a4838793a49dcad46ab" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "UniqueIndexRole_Id" ON "roles" ("id") WHERE "deletedAt" IS NULL`
    );

    await queryRunner.query(
      `ALTER TABLE "users" ADD "externalRoleId" character varying`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "externalRoleId"`);

    await queryRunner.query(`DROP INDEX "public"."UniqueIndexRole_Id"`);
    await queryRunner.query(`DROP TABLE "roles"`);
  }
}
