import { MigrationInterface, QueryRunner } from 'typeorm';

export class CREATESYSTEMSETTINGSSECURITYLEVEL1715609950877
  implements MigrationInterface
{
  name = 'CREATESYSTEMSETTINGSSECURITYLEVEL1715609950877';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "securityLevels" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "externalId" character varying NOT NULL, "name" character varying NOT NULL, "configuration" text NOT NULL DEFAULT '{}', "externalOrgId" character varying NOT NULL, CONSTRAINT "PK_fc49f3cecd4de52bd4e09f37634" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "systemsettings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "externalId" character varying NOT NULL, "securityLevelId" uuid NOT NULL DEFAULT '714f6f30-a65b-11ec-b909-0242ac120021', "externalOrgId" character varying NOT NULL, CONSTRAINT "PK_364886df7d2d3f7f3a89a87689d" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "systemsettings"`);
    await queryRunner.query(`DROP TABLE "securityLevels"`);
  }
}
