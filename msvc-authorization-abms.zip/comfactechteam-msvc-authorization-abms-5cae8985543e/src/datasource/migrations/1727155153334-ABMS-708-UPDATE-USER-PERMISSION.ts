import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS708UPDATEUSERPERMISSION1727155153334
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    console.log('🔧 Adding missing permissions to all users...');

    const users = await queryRunner.query(`
      SELECT id, permissions, "userName"
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    console.log(`📊 Found ${users.length} users to update`);
    let updatedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      // Add missing permissions if they don't already exist
      const missingPermissions = [
        'organization.*.*',
        'function.*.*',
        'location.*.*',
        'department.*.*',
        'group.*.*',
        'securityLevel.*.*',
        'systemsettings.*.*',
        'country.*.*',
        'user.*.*',
        'usergroup.*.*',
        'module.*.*',
        'workflow.*.*',
        'workflowstatus.*.*',
        'workflowaction.*.*',
        'workflowprocess.*.*',
        'globalsearch.*.*',
        'timezone.*.*',
        'event.*.*',
        'eventwatcher.*.*',
        'eventassignee.*.*',
        'task.*.*',
        'taskassignee.*.*',
        'taskwatcher.*.*',
        'tasktype.*.*',
        'eventtype.*.*',
        'documenttype.*.*',
        'document.*.*',
        'userrole.*.*',
        'companies.*.*',
        'contact.*.*',
        'contacttype.*.*',
        'contactcompanies.*.*',
        'contactcontacttype.*.*',
        'site.*.*',
        'taskreccuring.*.*',
        'eventrecurring.*.*',
        'account.*.*',
        'industry.*.*',
        'dealtype.*.*',
        'source.*.*',
      ];

      const newPermissions = missingPermissions.filter(
        (permission) => !permissions.access.includes(permission)
      );

      if (newPermissions.length > 0) {
        console.log(
          `✅ Adding missing permissions to user: ${
            user.userName
          } - ${newPermissions.join(', ')}`
        );

        Object.assign(permissions, {
          access: [...permissions.access, ...newPermissions],
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        updatedCount++;
      } else {
        console.log(
          `ℹ️  User ${user.userName}: All permissions already present`
        );
      }
    }

    console.log(
      `🎉 Migration complete! Updated ${updatedCount} users with missing permissions.`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    console.log('🔄 Removing permissions from all users...');

    const users = await queryRunner.query(`
      SELECT id, permissions, "userName"
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    let revertedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      const permissionsToRemove = [
        'organization.*.*',
        'function.*.*',
        'location.*.*',
        'department.*.*',
        'group.*.*',
        'securityLevel.*.*',
        'systemsettings.*.*',
        'country.*.*',
        'user.*.*',
        'usergroup.*.*',
        'module.*.*',
        'workflow.*.*',
        'workflowstatus.*.*',
        'workflowaction.*.*',
        'workflowprocess.*.*',
        'globalsearch.*.*',
        'timezone.*.*',
        'event.*.*',
        'eventwatcher.*.*',
        'eventassignee.*.*',
        'task.*.*',
        'taskassignee.*.*',
        'taskwatcher.*.*',
        'tasktype.*.*',
        'eventtype.*.*',
        'documenttype.*.*',
        'document.*.*',
        'userrole.*.*',
        'companies.*.*',
        'contact.*.*',
        'contacttype.*.*',
        'contactcompanies.*.*',
        'contactcontacttype.*.*',
        'site.*.*',
        'taskreccuring.*.*',
        'eventrecurring.*.*',
        'account.*.*',
        'industry.*.*',
        'dealtype.*.*',
        'source.*.*',
      ];

      const permissionsToKeep = permissions.access.filter(
        (item) => !permissionsToRemove.includes(item)
      );

      if (permissionsToKeep.length !== permissions.access.length) {
        console.log(`🔄 Removing permissions from user: ${user.userName}`);

        Object.assign(permissions, {
          access: permissionsToKeep,
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        revertedCount++;
      }
    }

    console.log(`🔄 Revert complete! Updated ${revertedCount} users.`);
  }
}
