import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS2781ADDINVOICETEMPLATEDETAILSPERMISSION1744640574572
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                    SELECT id, permissions
                    FROM users
                    WHERE "deletedAt" IS NULL
                `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: [...permissions.access, 'invoicetemplatedetails.*.*'],
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                    SELECT id, permissions
                    FROM users
                    WHERE "deletedAt" IS NULL
                `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: permissions.access.filter(
          (item) => item !== 'invoicetemplatedetails.*.*'
        ),
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }
}
