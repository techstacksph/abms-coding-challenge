import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const PERMISSION = {
  access: [
    'organization.*.*',
    'function.*.*',
    'location.*.*',
    'department.*.*',
    'group.*.*',
    'securityLevel.*.*',
    'systemsettings.*.*',
    'country.*.*',
    'user.*.*',
    'usergroup.*.*',
    'module.*.*',
    'workflow.*.*',
    'workflowstatus.*.*',
    'workflowaction.*.*',
    'workflowprocess.*.*',
    'globalsearch.*.*',
    'timezone.*.*',
    'event.*.*',
    'eventwatcher.*.*',
    'eventassignee.*.*',
    'task.*.*',
    'taskassignee.*.*',
    'taskwatcher.*.*',
    'tasktype.*.*',
    'eventtype.*.*',
    'documenttype.*.*',
    'document.*.*',
  ],
  departments: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  functions: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  locations: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  systemId: TestIds.SYSTEM_ID,
};

export class INITIALSEEDUSERROLE1720594339714 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // CREATE INITIAL SEED FOR USER ROLES -- ADMIN (only if not exists)
    await queryRunner.query(
      `
          INSERT INTO "roles"
            ("createdAt", "updatedAt", "deletedAt", "createdById", "createdByName", "externalId", "name", "externalOrgId", "permissions")
          SELECT NOW(), NOW(), NULL, '${
            TestIds.PERSON_ID
          }', 'Comfac Technology Options', '${
            TestIds.ADMIN_USER_ROLE_ID
          }', 'Administrator', '${TestIds.ORGANIZATION_ID}', '${JSON.stringify(
            PERMISSION
          )}'
          WHERE NOT EXISTS (
            SELECT 1 FROM "roles" WHERE "externalId" = '${
              TestIds.ADMIN_USER_ROLE_ID
            }'
          )
        `
    );

    /// ATTACH ADMIN USER ROLE TO EXISTING USERS
    await queryRunner.query(
      `UPDATE "users" SET "externalRoleId" = '${TestIds.ADMIN_USER_ROLE_ID}'`
    );

    // ADD NOT NULL CONSTRAINT TO externalRoleId COLUMN
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "externalRoleId" SET NOT NULL`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "externalRoleId"`);
    await queryRunner.query(
      `DELETE FROM "roles" WHERE "externalId"='${TestIds.ADMIN_USER_ROLE_ID}'`
    );
  }
}
