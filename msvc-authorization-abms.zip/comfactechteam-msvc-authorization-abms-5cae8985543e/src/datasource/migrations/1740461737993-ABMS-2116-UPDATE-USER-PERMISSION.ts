import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const newPermissionName = ['marketplacejobpurchase.*.*'];

export class ABMS2116UPDATEUSERPERMISSION1740461737993
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
      SELECT id, permissions
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: [...permissions.access, ...newPermissionName],
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
      SELECT id, permissions
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: permissions.access.filter(
          (item) =>
            item !== newPermissionName[0] || item !== newPermissionName[1]
        ),
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }
}
