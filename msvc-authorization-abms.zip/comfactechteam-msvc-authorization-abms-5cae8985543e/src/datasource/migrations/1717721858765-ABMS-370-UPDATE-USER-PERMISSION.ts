import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

const previousPermissions = {
  access: [
    'organization.*.*',
    'function.*.*',
    'location.*.*',
    'department.*.*',
    'group.*.*',
    'securityLevel.*.*',
    'systemsettings.*.*',
    'country.*.*',
    'user.*.*',
    'usergroup.*.*',
    'module.*.*',
    'workflow.*.*',
    'workflowstatus.*.*',
    'workflowaction.*.*',
    'workflowprocess.*.*',
    'globalsearch.*.*',
    'timezone.*.*',
    'event.*.*',
    'eventwatcher.*.*',
  ],
  departments: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  functions: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  locations: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  systemId: TestIds.SYSTEM_ID,
};

export class ABMS370UPDATEUSERPERMISSION1717721858765
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const permissions = {
      ...previousPermissions,
      access: [...previousPermissions.access, 'userrole.*.*'],
    };
    await queryRunner.query(
      `UPDATE "roles" SET "permissions" = '${JSON.stringify(permissions)}'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const permissions = previousPermissions;
    await queryRunner.query(
      `UPDATE "roles" SET "permissions" = '${JSON.stringify(permissions)}'`
    );
  }
}
