import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddAccountIdToUsers1760959104958 implements MigrationInterface {
  name = 'AddAccountIdToUsers1760959104958';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Add accountId column as nullable string
    await queryRunner.query(`
      ALTER TABLE "users"
      ADD "accountId" character varying
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop the accountId column
    await queryRunner.query(`
      ALTER TABLE "users" DROP COLUMN "accountId"
    `);
  }
}
