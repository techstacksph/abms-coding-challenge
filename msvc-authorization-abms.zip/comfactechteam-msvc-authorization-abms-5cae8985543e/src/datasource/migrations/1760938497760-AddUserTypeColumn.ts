import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddUserTypeColumn1760938497760 implements MigrationInterface {
  name = 'AddUserTypeColumn1760938497760';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Create ENUM type
    await queryRunner.query(`
      CREATE TYPE "user_type_enum" AS ENUM('ADMIN', 'FRANCHISEE', 'CLIENT')
    `);

    // Add userType column with default ADMIN
    await queryRunner.query(`
      ALTER TABLE "users"
      ADD "userType" "user_type_enum" NOT NULL DEFAULT 'ADMIN'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Drop the column
    await queryRunner.query(`
      ALTER TABLE "users" DROP COLUMN "userType"
    `);

    // Drop the ENUM type
    await queryRunner.query(`
      DROP TYPE "user_type_enum"
    `);
  }
}
