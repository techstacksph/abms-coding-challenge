import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class HOTFIXADDMISSINGXEROPERMISSIONS1763969697000
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    console.log(
      '🔧 Adding missing permissions to users (141 permissions including Xero, Jobs, Invoices, etc.)...'
    );

    const users = await queryRunner.query(`
      SELECT id, permissions, "userName"
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    console.log(`📊 Found ${users.length} users to check`);
    let updatedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      // Check for missing permissions
      // This includes Xero and all other permissions that were added to msvc-abms but never synced to auth service
      const requiredPermissions = [
        'accountcode.*.*',
        'accountproductfavorite.*.*',
        'actionplan.*.*',
        'agreement.*.*',
        'agreementandcontract.*.*',
        'allocatedjob.*.*',
        'amendmentdetail.*.*',
        'amendmenttype.*.*',
        'answer.*.*',
        'area.*.*',
        'audittrails.*.*',
        'bankingdetails.*.*',
        'batchjobtransfer.*.*',
        'bill.*.*',
        'billdetail.*.*',
        'billtemplate.*.*',
        'billtemplatedetail.*.*',
        'businessforsale.*.*',
        'cancellationType.*.*',
        'case.*.*',
        'casetype.*.*',
        'channel.*.*',
        'chcommunicationresponse.*.*',
        'clienthubcommunication.*.*',
        'companysetting.*.*',
        'course.*.*',
        'creditbureau.*.*',
        'creditdebitnote.*.*',
        'creditdebitnotedetails.*.*',
        'creditdebitnotetobill.*.*',
        'creditdebitnotetofranchisee.*.*',
        'creditdebitnotetoinvoice.*.*',
        'cursorref.*.*',
        'dealtemplate.*.*',
        'dealtemplatedetail.*.*',
        'dealtemplatespecification.*.*',
        'deliveryandreturn.*.*',
        'documenttemplate.*.*',
        'emergencycontact.*.*',
        'employee.*.*',
        'employementhistory.*.*',
        'evaluation.*.*',
        'evaluationdetails.*.*',
        'faq.*.*',
        'franchiseeagreement.*.*',
        'franchiseehub.*.*',
        'franchiseekit.*.*',
        'franchiseeonboarding.*.*',
        'franchiseesecuritycheck.*.*',
        'industrystandardjobtitle.*.*',
        'insurancedetail.*.*',
        'invoice.*.*',
        'invoicedetails.*.*',
        'invoicejob.*.*',
        'invoicetemplate.*.*',
        'invoicetemplatedetail.*.*',
        'itemtag.*.*',
        'itemvarianttype.*.*',
        'job.*.*',
        'jobarea.*.*',
        'jobbilling.*.*',
        'jobdetails.*.*',
        'jobforsale.*.*',
        'jobpdf.*.*',
        'jobprocessing.*.*',
        'jobpurchase.*.*',
        'jobschedule.*.*',
        'jobschedulelog.*.*',
        'jobspecification.*.*',
        'jobtransaction.*.*',
        'jobtransfermovement.*.*',
        'kiwisaverdetails.*.*',
        'lead.*.*',
        'leadquestion.*.*',
        'leave.*.*',
        'leavebalance.*.*',
        'leavetypedetails.*.*',
        'manageprofile.*.*',
        'manual.*.*',
        'marketplace.*.*',
        'marketplacejobpurchase.*.*',
        'microsoftaccount.*.*',
        'moduleinfo.*.*',
        'nationality.*.*',
        'note.*.*',
        'notifandalert.*.*',
        'onboardingchecklist.*.*',
        'option.*.*',
        'paydetails.*.*',
        'paymenthistory.*.*',
        'paymentterm.*.*',
        'performancereview.*.*',
        'performancereviewquestion.*.*',
        'permission.*.*',
        'person.*.*',
        'preferredproducts.*.*',
        'pricelistitem.*.*',
        'purchaseorder.*.*',
        'purchaseorderitem.*.*',
        'qaarea.*.*',
        'qarecurring.*.*',
        'qaspecification.*.*',
        'qualityaudit.*.*',
        'question.*.*',
        'questionnaire.*.*',
        'quotepdf.*.*',
        'recruitment.*.*',
        'recruitmentquestionnaire.*.*',
        'reviewperiod.*.*',
        'reviewperioddetails.*.*',
        'reviewperioddetailstodepartment.*.*',
        'reviewperioddetailstouser.*.*',
        'royaltysheet.*.*',
        'salesorder.*.*',
        'salesorderitem.*.*',
        'securitycheck.*.*',
        'securityLevel.*.*',
        'serviceproviderassignments.*.*',
        'servicetype.*.*',
        'smsrepeating.*.*',
        'stockcontrol.*.*',
        'stocktransaction.*.*',
        'supplierpricelist.*.*',
        'supplierpricelistitem.*.*',
        'taskrecurring.*.*',
        'taxcodedeclarationdetails.*.*',
        'test.*.*',
        'testquestion.*.*',
        'testresult.*.*',
        'training.*.*',
        'trainingprogramsection.*.*',
        'trainingsectiondetails.*.*',
        'userpermission.*.*',
        'vehicle.*.*',
        'video.*.*',
        'warehouseitem.*.*',
        'xero.*.*',
        'xeroaccount.*.*',
      ];

      const missingPermissions = requiredPermissions.filter(
        (permission) => !permissions.access.includes(permission)
      );

      if (missingPermissions.length > 0) {
        console.log(
          `✅ User ${user.userName}: Adding ${missingPermissions.length} missing permissions`
        );

        Object.assign(permissions, {
          access: [...permissions.access, ...missingPermissions],
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        updatedCount++;
      } else {
        console.log(
          `ℹ️  User ${user.userName}: All permissions already present`
        );
      }
    }

    console.log(
      `🎉 Migration complete! Updated ${updatedCount} users with missing permissions.`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    console.log('🔄 Removing all 141 permissions from users...');

    const users = await queryRunner.query(`
      SELECT id, permissions, "userName"
      FROM users
      WHERE "deletedAt" IS NULL
    `);

    let revertedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      const permissionsToRemove = [
        'accountcode.*.*',
        'accountproductfavorite.*.*',
        'actionplan.*.*',
        'agreement.*.*',
        'agreementandcontract.*.*',
        'allocatedjob.*.*',
        'amendmentdetail.*.*',
        'amendmenttype.*.*',
        'answer.*.*',
        'area.*.*',
        'audittrails.*.*',
        'bankingdetails.*.*',
        'batchjobtransfer.*.*',
        'bill.*.*',
        'billdetail.*.*',
        'billtemplate.*.*',
        'billtemplatedetail.*.*',
        'businessforsale.*.*',
        'cancellationType.*.*',
        'case.*.*',
        'casetype.*.*',
        'channel.*.*',
        'chcommunicationresponse.*.*',
        'clienthubcommunication.*.*',
        'companysetting.*.*',
        'course.*.*',
        'creditbureau.*.*',
        'creditdebitnote.*.*',
        'creditdebitnotedetails.*.*',
        'creditdebitnotetobill.*.*',
        'creditdebitnotetofranchisee.*.*',
        'creditdebitnotetoinvoice.*.*',
        'cursorref.*.*',
        'dealtemplate.*.*',
        'dealtemplatedetail.*.*',
        'dealtemplatespecification.*.*',
        'deliveryandreturn.*.*',
        'documenttemplate.*.*',
        'emergencycontact.*.*',
        'employee.*.*',
        'employementhistory.*.*',
        'evaluation.*.*',
        'evaluationdetails.*.*',
        'faq.*.*',
        'franchiseeagreement.*.*',
        'franchiseehub.*.*',
        'franchiseekit.*.*',
        'franchiseeonboarding.*.*',
        'franchiseesecuritycheck.*.*',
        'industrystandardjobtitle.*.*',
        'insurancedetail.*.*',
        'invoice.*.*',
        'invoicedetails.*.*',
        'invoicejob.*.*',
        'invoicetemplate.*.*',
        'invoicetemplatedetail.*.*',
        'itemtag.*.*',
        'itemvarianttype.*.*',
        'job.*.*',
        'jobarea.*.*',
        'jobbilling.*.*',
        'jobdetails.*.*',
        'jobforsale.*.*',
        'jobpdf.*.*',
        'jobprocessing.*.*',
        'jobpurchase.*.*',
        'jobschedule.*.*',
        'jobschedulelog.*.*',
        'jobspecification.*.*',
        'jobtransaction.*.*',
        'jobtransfermovement.*.*',
        'kiwisaverdetails.*.*',
        'lead.*.*',
        'leadquestion.*.*',
        'leave.*.*',
        'leavebalance.*.*',
        'leavetypedetails.*.*',
        'manageprofile.*.*',
        'manual.*.*',
        'marketplace.*.*',
        'marketplacejobpurchase.*.*',
        'microsoftaccount.*.*',
        'moduleinfo.*.*',
        'nationality.*.*',
        'note.*.*',
        'notifandalert.*.*',
        'onboardingchecklist.*.*',
        'option.*.*',
        'paydetails.*.*',
        'paymenthistory.*.*',
        'paymentterm.*.*',
        'performancereview.*.*',
        'performancereviewquestion.*.*',
        'permission.*.*',
        'person.*.*',
        'preferredproducts.*.*',
        'pricelistitem.*.*',
        'purchaseorder.*.*',
        'purchaseorderitem.*.*',
        'qaarea.*.*',
        'qarecurring.*.*',
        'qaspecification.*.*',
        'qualityaudit.*.*',
        'question.*.*',
        'questionnaire.*.*',
        'quotepdf.*.*',
        'recruitment.*.*',
        'recruitmentquestionnaire.*.*',
        'reviewperiod.*.*',
        'reviewperioddetails.*.*',
        'reviewperioddetailstodepartment.*.*',
        'reviewperioddetailstouser.*.*',
        'royaltysheet.*.*',
        'salesorder.*.*',
        'salesorderitem.*.*',
        'securitycheck.*.*',
        'securityLevel.*.*',
        'serviceproviderassignments.*.*',
        'servicetype.*.*',
        'smsrepeating.*.*',
        'stockcontrol.*.*',
        'stocktransaction.*.*',
        'supplierpricelist.*.*',
        'supplierpricelistitem.*.*',
        'taskrecurring.*.*',
        'taxcodedeclarationdetails.*.*',
        'test.*.*',
        'testquestion.*.*',
        'testresult.*.*',
        'training.*.*',
        'trainingprogramsection.*.*',
        'trainingsectiondetails.*.*',
        'userpermission.*.*',
        'vehicle.*.*',
        'video.*.*',
        'warehouseitem.*.*',
        'xero.*.*',
        'xeroaccount.*.*',
      ];

      const permissionsToKeep = permissions.access.filter(
        (item) => !permissionsToRemove.includes(item)
      );

      if (permissionsToKeep.length !== permissions.access.length) {
        console.log(
          `🔄 Removing ${
            permissions.access.length - permissionsToKeep.length
          } permissions from user: ${user.userName}`
        );

        Object.assign(permissions, {
          access: permissionsToKeep,
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        revertedCount++;
      }
    }

    console.log(`🔄 Revert complete! Updated ${revertedCount} users.`);
  }
}
