import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS4772ADDMICROSOFTACCOUNTSPERMISSION1755607337682
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    // Get all existing roles
    const roles = await queryRunner.query(`
            SELECT id, permissions
            FROM roles
            WHERE "deletedAt" IS NULL
        `);

    for (const role of roles) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = role.permissions
          ? JSON.parse(role.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      // Ensure permissions.access is an array before using .includes()
      if (!Array.isArray(permissions.access)) {
        permissions.access = [];
      }

      // Check if Microsoft Account permission already exists
      if (!permissions.access.includes('microsoftaccount.*.*')) {
        Object.assign(permissions, {
          access: [...permissions.access, 'microsoftaccount.*.*'],
        });

        await queryRunner.query(
          `UPDATE "roles" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), role.id]
        );
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Get all existing roles
    const roles = await queryRunner.query(`
            SELECT id, permissions
            FROM roles
            WHERE "deletedAt" IS NULL
        `);

    for (const role of roles) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = role.permissions
          ? JSON.parse(role.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      // Remove Microsoft Account permission
      Object.assign(permissions, {
        access: permissions.access.filter(
          (item) => item !== 'microsoftaccount.*.*'
        ),
      });

      await queryRunner.query(
        `UPDATE "roles" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), role.id]
      );
    }
  }
}
