import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class SECURITYLEVELSEED1715612164751 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const seedData = [
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 0,
              userLockTimeInMins: 0,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: true,
              minPasswordLength: 6,
              requireLowercaseCharacter: true,
              requireNumber: false,
              requireSpecialCharacter: false,
              requireUppercaseCharacter: true,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 7200,
            },
          },
          record: {
            recordLockTimeInMins: 120,
          },
        },
        id: TestIds.SECURITY_LEVEL_LOW_ID,
        name: 'Low',
      },
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 5,
              userLockTimeInMins: 30,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: false,
              minPasswordLength: 8,
              requireLowercaseCharacter: false,
              requireNumber: true,
              requireSpecialCharacter: true,
              requireUppercaseCharacter: false,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 4320,
            },
          },
          record: {
            recordLockTimeInMins: 60,
          },
        },
        id: TestIds.SECURITY_LEVEL_MEDIUM_ID,
        name: 'Medium',
      },
      {
        configuration: {
          authentication: {
            login: {
              maxFailedLogin: 3,
              userLockTimeInMins: 60,
            },
            password: {
              allowSamePassword: false,
              allowSequentialCharacters: false,
              minPasswordLength: 8,
              requireLowercaseCharacter: false,
              requireNumber: true,
              requireSpecialCharacter: true,
              requireUppercaseCharacter: false,
            },
            session: {
              inactivityInMin: 240,
              loginSession: 1440,
            },
          },
          record: {
            recordLockTimeInMins: 30,
          },
        },
        id: TestIds.SECURITY_LEVEL_HIGH_ID,
        name: 'High',
      },
    ];
    const seedValues = seedData.map((data) => {
      return `('${data.id}','${data.name}','${
        TestIds.PERSON_ID
      }','Comfac Technology Options','${data.id}','${
        TestIds.ORGANIZATION_ID
      }','${JSON.stringify(data.configuration)}')`;
    });

    await queryRunner.query(
      `
        INSERT INTO "securityLevels"
            ("id","name", "createdById", "createdByName", "externalId", "externalOrgId", "configuration") 
        VALUES 
            ${seedValues.join(',')}
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "securityLevels"`);
  }
}
