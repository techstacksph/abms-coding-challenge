import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS266COMPANYSETTINGSMODULE1742529046202
  implements MigrationInterface
{
  name = 'ABMS266COMPANYSETTINGSMODULE1742529046202';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "companysettings" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "deletedAt" TIMESTAMP, "createdById" uuid, "updatedById" uuid, "deletedById" uuid, "createdByName" text, "updatedByName" text, "deletedByName" text, "companyName" character varying, "emailSettings" character varying DEFAULT 'MICROSOFT_OUTLOOK', "mailerAccount" character varying, "tenantId" character varying, "clientId" character varying, "clientSecret" character varying, "mailHost" character varying, "mailPort" character varying, "appPassword" character varying, "autoReply" character varying, "mailSender" character varying, "externalId" character varying, "customDisplayName" character varying, "smsKey" character varying, "smsSecret" character varying, "xeroApp" character varying, "xeroID" character varying, "xeroSecret" character varying, "mapAPI" character varying, "tinyKey" character varying, "outlookTenantID" character varying, "outlookID" character varying, "outlookSecret" character varying, "sharePointSiteName" character varying, "sharePointUploadFolderName" character varying, CONSTRAINT "PK_c1433f39c75912dbe00a7445910" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "companysettings"`);
  }
}
