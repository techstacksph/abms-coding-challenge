import { MigrationInterface, QueryRunner } from 'typeorm';

export class ABMS49UPDATEUSER1710213814509 implements MigrationInterface {
  name = 'ABMS49UPDATEUSER1710213814509';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" RENAME COLUMN "orgId" TO "externalOrgId"`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "firstName" character varying`
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "lastName" character varying`
    );

    // Remove rows with userNames that fail to convert to citext
    await queryRunner.query(`
      DELETE FROM "users"
      WHERE id NOT IN (
          SELECT id FROM (
              SELECT id, ROW_NUMBER() OVER (PARTITION BY LOWER("userName") ORDER BY "createdAt") AS rowNumber
              FROM "users"
          ) t
          WHERE rowNumber = 1
      );
    `);

    // CONVERT FIELD TYPE OF userName TO citext
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "userName" TYPE citext USING "userName"::citext`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "userName" TYPE character varying USING "userName"::character varying`
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "lastName"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "firstName"`);
    await queryRunner.query(
      `ALTER TABLE "users" RENAME COLUMN "externalOrgId" TO "orgId"`
    );
  }
}
