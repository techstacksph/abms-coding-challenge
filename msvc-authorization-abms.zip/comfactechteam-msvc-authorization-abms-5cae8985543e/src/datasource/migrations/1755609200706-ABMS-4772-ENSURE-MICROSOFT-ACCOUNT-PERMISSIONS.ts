import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS4772ENSUREMICROSOFTACCOUNTPERMISSIONS1755609200706
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    console.log('🔧 Ensuring all users have Microsoft Account permissions...');

    // Get all existing users
    const users = await queryRunner.query(`
            SELECT id, permissions, "userName"
            FROM users
            WHERE "deletedAt" IS NULL
        `);

    console.log(`📊 Found ${users.length} users to check`);
    let updatedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      // Check if Microsoft Account permission already exists
      if (!permissions.access.includes('microsoftaccount.*.*')) {
        console.log(
          `✅ Adding Microsoft Account permission to user: ${user.userName}`
        );

        Object.assign(permissions, {
          access: [...permissions.access, 'microsoftaccount.*.*'],
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        updatedCount++;
      }
    }

    console.log(
      `🎉 Migration complete! Updated ${updatedCount} users with Microsoft Account permissions.`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    console.log('🔄 Removing Microsoft Account permissions from all users...');

    // Get all existing users
    const users = await queryRunner.query(`
            SELECT id, permissions, "userName"
            FROM users
            WHERE "deletedAt" IS NULL
        `);

    console.log(`📊 Found ${users.length} users to process`);
    let updatedCount = 0;

    for (const user of users) {
      let permissions: {
        access: string[];
        departments: string[];
        functions: string[];
        locations: string[];
        systemId: string;
      } = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        console.warn(
          `⚠️  User ${user.userName}: Invalid permissions JSON, skipping`
        );
        continue;
      }

      // Remove Microsoft Account permission if it exists
      if (permissions.access.includes('microsoftaccount.*.*')) {
        console.log(
          `❌ Removing Microsoft Account permission from user: ${user.userName}`
        );

        Object.assign(permissions, {
          access: permissions.access.filter(
            (item) => item !== 'microsoftaccount.*.*'
          ),
        });

        await queryRunner.query(
          `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
          [JSON.stringify(permissions), user.id]
        );
        updatedCount++;
      }
    }

    console.log(
      `🎉 Rollback complete! Removed Microsoft Account permissions from ${updatedCount} users.`
    );
  }
}
