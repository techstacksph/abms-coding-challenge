import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class PERMISSIONABMS22631741717515176 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                SELECT id, permissions
                FROM users
                WHERE "deletedAt" IS NULL
            `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: [...permissions.access, 'paymentterm.*.*'],
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const users = await queryRunner.query(`
                SELECT id, permissions
                FROM users
                WHERE "deletedAt" IS NULL
            `);

    for (const user of users) {
      let permissions = {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: TestIds.SYSTEM_ID,
      };

      try {
        permissions = user.permissions
          ? JSON.parse(user.permissions)
          : permissions;
      } catch (error) {
        continue;
      }

      Object.assign(permissions, {
        access: permissions.access.filter((item) => item !== 'paymentterm.*.*'),
      });

      await queryRunner.query(
        `UPDATE "users" SET "permissions" = $1 WHERE id = $2`,
        [JSON.stringify(permissions), user.id]
      );
    }
  }
}
