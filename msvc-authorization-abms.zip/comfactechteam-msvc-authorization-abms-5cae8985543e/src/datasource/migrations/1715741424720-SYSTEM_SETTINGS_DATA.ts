import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class SYSTEMSETTINGSDATA1715741424720 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `
        INSERT INTO "systemsettings" 
            ("id","createdByName", "externalId", "externalOrgId", "securityLevelId") 
        VALUES 
            ('${TestIds.SYSTEM_SETTINGS_ID}', 'Comfac Technology Options', '${TestIds.SYSTEM_SETTINGS_ID}', '${TestIds.ORGANIZATION_ID}', '${TestIds.SECURITY_LEVEL_HIGH_ID}')
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `
        DELETE FROM "systemsettings"
        WHERE "id"='${TestIds.SYSTEM_SETTINGS_ID}'
      `
    );
  }
}
