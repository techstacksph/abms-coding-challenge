import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class ABMS229UPDATEINITIALUSERSYSTEMID1715650411821
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "users" SET "permissions" = '{"systemId":"${TestIds.SYSTEM_ID}","access":["organization.*.*"],"locations":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"departments":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"functions":["3fa85f64-5717-4562-b3fc-2c963f66afa6"]}' WHERE id = '${TestIds.PERSON_ID}'`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `UPDATE "users" SET "permissions" = '{"systemId":"msvc-cto-bo","access":["organization.*.*"],"locations":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"departments":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"functions":["3fa85f64-5717-4562-b3fc-2c963f66afa6"]}' WHERE id = '${TestIds.PERSON_ID}'`
    );
  }
}
