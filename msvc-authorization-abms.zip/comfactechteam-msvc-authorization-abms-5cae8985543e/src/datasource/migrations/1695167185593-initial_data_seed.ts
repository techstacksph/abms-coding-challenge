import { MigrationInterface, QueryRunner } from 'typeorm';

import { TestIds } from '../../test/SampleData';

export class InitialDataSeed1695167185593 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `
        INSERT INTO "organizations" 
            ("id", "createdAt", "updatedAt", "deletedAt", "createdById", "updatedById", "deletedById", "createdByName", "updatedByName", "deletedByName", "code", "name", "description", "externalId", "status") 
        VALUES 
            ('${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, '${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, 'CTO', 'Comfac Technology Options', DEFAULT, '${TestIds.ORGANIZATION_ID}', 'active') RETURNING "id", "createdAt", "updatedAt", "deletedAt", "status"
      `
    );

    await queryRunner.query(
      `
        INSERT INTO "users"
            ("id", "createdAt", "updatedAt", "deletedAt", "createdById", "updatedById", "deletedById", "createdByName", "updatedByName", "deletedByName", "externalId", "userName", "passwordHash", "status", "email", "orgId", "permissions") 
        VALUES 
            ('${TestIds.PERSON_ID}', DEFAULT, DEFAULT, DEFAULT, '${TestIds.ORGANIZATION_ID}', DEFAULT, DEFAULT, 'Comfac Technology Options', DEFAULT, DEFAULT, '${TestIds.PERSON_ID}', 'dev@comfactechoptions.com', '$2b$10$oOAkZagfxwamqaFqNM1VquCgpqHSlTzKqakHivgzT3Ra8Fh1eJgZi', 'active', 'dev@comfactechoptions.com', '${TestIds.ORGANIZATION_ID}', '{"systemId":"msvc-cto-bo","access":["organization.*.*"],"locations":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"departments":["3fa85f64-5717-4562-b3fc-2c963f66afa6"],"functions":["3fa85f64-5717-4562-b3fc-2c963f66afa6"]}') 
      `
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM  "organizations" WHERE "id"='${TestIds.ORGANIZATION_ID}'`
    );

    await queryRunner.query(
      `DELETE FROM  "users" WHERE "id"='${TestIds.PERSON_ID}'`
    );
  }
}
