/* eslint-disable no-unused-vars */
import { Column, Entity, Index, JoinColumn, OneToOne } from 'typeorm';

import { PermissionDto } from '../../dto/UserDto';
import { OrganizationModel } from './OrganizationModel';
import { BaseModel } from './base/BaseModel';

@Entity('roles')
@Index('UniqueIndexRole_Id', ['id'], {
  unique: true,
  where: '"deletedAt" IS NULL',
})
export class RoleModel extends BaseModel {
  @Column({ nullable: false })
  externalId!: string;

  @Column({ nullable: false })
  name!: string;

  @Column({ nullable: false, type: 'uuid' })
  externalOrgId!: string;

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  @OneToOne((type) => OrganizationModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'externalOrgId', referencedColumnName: 'externalId' })
  organization!: OrganizationModel;

  @Column({ default: '{}', nullable: false, type: 'simple-json' })
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  permissions!: PermissionDto;
}
