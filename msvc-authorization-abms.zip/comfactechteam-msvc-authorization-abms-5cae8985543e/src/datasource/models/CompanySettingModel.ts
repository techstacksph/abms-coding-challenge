import { Column, Entity, JoinColumn, OneToOne } from 'typeorm';

import {
  CompanySettingsEmailSettings,
  CompanySettingsMailSender,
} from '../../enums/CompanySettingEnum';
import { BaseModel } from './base/BaseModel';
import { SecurityLevelModel } from './SecurityLevelModel';

@Entity('companysettings')
export class CompanySettingModel extends BaseModel {
  @Column({ nullable: true })
  companyName?: string;

  /****  MAILER INTEG FIELDS *****/
  @Column({
    default: CompanySettingsEmailSettings.MICROSOFT_OUTLOOK,
    nullable: true,
  })
  emailSettings?: CompanySettingsEmailSettings;

  @Column({ nullable: true })
  mailerAccount?: string;

  @Column({ nullable: true })
  tenantId?: string;

  @Column({ nullable: true })
  clientId?: string;

  @Column({ nullable: true })
  clientSecret?: string;

  @Column({ nullable: true })
  mailHost?: string;

  @Column({ nullable: true })
  mailPort?: string;

  @Column({ nullable: true })
  appPassword?: string;

  @Column({ nullable: true })
  autoReply?: string;

  @Column({ nullable: true })
  mailSender?: CompanySettingsMailSender;

  @Column({ nullable: true })
  externalId?: string;

  @Column({ nullable: true })
  externalOrgId?: string;

  @Column({ nullable: true })
  customDisplayName?: string;

  @Column({ nullable: true, type: 'uuid' })
  securityLevelId?: string;

  @OneToOne(() => SecurityLevelModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'securityLevelId', referencedColumnName: 'id' })
  securityLevel!: SecurityLevelModel;

  /****  MESSAGE MEDIA INTEG FIELDS *****/
  @Column({ nullable: true })
  smsKey?: string;

  @Column({ nullable: true })
  smsSecret?: string;

  /****  XERO INTEG FIELDS *****/
  @Column({ nullable: true })
  xeroApp?: string;

  @Column({ nullable: true })
  xeroID?: string;

  @Column({ nullable: true })
  xeroSecret?: string;

  /****  GOOGLE MAPS INTEG FIELDS *****/
  @Column({ nullable: true })
  mapAPI?: string;

  /****  TINYURL INTEG FIELDS *****/
  @Column({ nullable: true })
  tinyKey?: string;

  /****  MS365 INTEG FIELDS *****/
  @Column({ nullable: true })
  outlookTenantID?: string; // TENANT ID

  @Column({ nullable: true }) // CLIENT ID (OAUTH APP ID)
  outlookID?: string;

  @Column({ nullable: true }) // CLIENT SECRET (OAUTH APP PASSWORD)
  outlookSecret?: string;

  @Column({ nullable: true })
  sharePointSiteName?: string;

  @Column({ nullable: true })
  sharePointUploadFolderName?: string;
}
