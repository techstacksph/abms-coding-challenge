/* eslint-disable no-unused-vars */
import { isString } from 'lodash';
import { Column, Entity, Index, JoinColumn, OneToOne } from 'typeorm';

import { UserStatus, UserType } from '../../enums/UserEnums';
import environment from '../../environment';
import { OrganizationModel } from './OrganizationModel';
import { BaseModel } from './base/BaseModel';

@Entity('users')
@Index('UniqueIndexUser_UserName', ['userName'], {
  unique: true,
  where: '"deletedAt" IS NULL',
})
export class UserModel extends BaseModel {
  @Column({ nullable: false })
  externalId!: string;

  @Column({
    nullable: false,
    transformer: {
      from: (value) => value,
      to: (value) => {
        return isString(value) && value ? value?.trim() : value;
      },
    },
    type: environment.NODE_ENV == 'test' ? 'text' : 'citext',
  })
  userName!: string;

  @Column({ nullable: false })
  passwordHash!: string;

  @Column({
    default: UserStatus.ACTIVE,
    nullable: false,
    type: 'text',
  })
  status!: UserStatus;

  @Column({ nullable: false })
  email!: string;

  @Column({ nullable: false, type: 'uuid' })
  externalOrgId!: string;

  @Column({ nullable: false })
  externalRoleId!: string;

  @Column({ nullable: true })
  firstName?: string;

  @Column({ nullable: true })
  lastName?: string;

  @Column({ nullable: true })
  isFirstlogin?: boolean;

  @Column({
    type: 'enum',
    enum: UserType,
    enumName: 'user_type_enum',
    default: UserType.ADMIN,
    nullable: false,
  })
  userType!: UserType;

  @Column({ nullable: true })
  accountId?: string;

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  @OneToOne((type) => OrganizationModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'externalOrgId', referencedColumnName: 'externalId' })
  organization!: OrganizationModel;

  @Column({ default: '{}', nullable: false, type: 'simple-json' })
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  permissions!: any;
}
