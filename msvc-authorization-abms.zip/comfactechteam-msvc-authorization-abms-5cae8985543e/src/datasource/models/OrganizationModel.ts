/* eslint-disable no-unused-vars */
import { Column, Entity, Index } from 'typeorm';

import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { BaseModel } from './base/BaseModel';

@Entity('organizations')
@Index('UniqueIndexOrganization_ExternalId', ['externalId'], {
  unique: true,
  where: '"deletedAt" IS NULL',
})
export class OrganizationModel extends BaseModel {
  @Column({ nullable: false })
  code!: string;

  @Column({ nullable: false })
  name!: string;

  @Column({ nullable: true })
  description!: string;

  @Column({ nullable: false })
  externalId!: string;

  @Column({
    default: OrganizationStatus.CREATED,
    nullable: false,
    type: 'text',
  })
  status!: OrganizationStatus;
}
