import { Column, Entity, JoinColumn, OneToOne } from 'typeorm';

import { TestIds } from '../../test/SampleData';
import { OrganizationModel } from './OrganizationModel';
import { SecurityLevelModel } from './SecurityLevelModel';
import { BaseModel } from './base/BaseModel';

@Entity('systemsettings')
export class SystemSettingsModel extends BaseModel {
  @Column({ nullable: false })
  externalId!: string;

  @Column({
    default: TestIds.SECURITY_LEVEL_LOW_ID,
    nullable: false,
    type: 'uuid',
  })
  securityLevelId!: string;

  @OneToOne(() => SecurityLevelModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'securityLevelId', referencedColumnName: 'id' })
  securityLevel!: SecurityLevelModel;

  @Column({ nullable: false, type: 'uuid' })
  externalOrgId!: string;

  @OneToOne(() => OrganizationModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'externalOrgId', referencedColumnName: 'externalId' })
  organization!: OrganizationModel;
}
