import { Column, Entity, JoinColumn, OneToOne } from 'typeorm';

import { SecurityLevelConfigurationDto } from '../../dto/SecurityLevelDto';
import { OrganizationModel } from './OrganizationModel';
import { BaseModel } from './base/BaseModel';

@Entity('securityLevels')
export class SecurityLevelModel extends BaseModel {
  @Column({ nullable: false })
  externalId!: string;

  @Column({ nullable: false })
  name!: string;

  @Column({ default: '{}', nullable: false, type: 'simple-json' })
  configuration!: SecurityLevelConfigurationDto;

  @Column({ nullable: false, type: 'uuid' })
  externalOrgId!: string;

  @OneToOne(() => OrganizationModel, { createForeignKeyConstraints: false })
  @JoinColumn({ name: 'externalOrgId', referencedColumnName: 'externalId' })
  organization!: OrganizationModel;
}
