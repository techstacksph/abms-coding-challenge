import 'reflect-metadata';

import cookieParser from 'cookie-parser';
import express from 'express';
import { Action, createExpressServer, useContainer } from 'routing-controllers';
import swaggerUi from 'swagger-ui-express';
import { Container } from 'typeorm-typedi-extensions';

import { PulsarListenerRegistry } from './client/pulsar/PulsarListenerRegistry';
import { ControllerInitializer } from './controller/ControllerInitializer';
import { appDataSource } from './datasource/config/database';
import { ClientAuthenticationDto } from './dto/ClientAuthenticationDto';
import environment from './environment';
import { CustomUnauthorizedError } from './errors/CustomUnauthorizedError';
import { trackActivity } from './middleware/ActivityTracker';
import { AuthenticateRequestService } from './services/AuthenticateRequestService';
import { httpLogger, logger } from './utils/LoggerUtils';
import swaggerSpec from './utils/SwaggerUtils';
import { SessionCleanupWorker } from './workers/SessionCleanupWorker';

const startServer = async () => {
  const PORT = environment.PORT;
  //const app = express();

  useContainer(Container);

  const controllerInitializer: ControllerInitializer = Container.get(
    ControllerInitializer
  );

  const authenticateRequestService: AuthenticateRequestService = Container.get(
    AuthenticateRequestService
  );

  const app = createExpressServer({
    authorizationChecker: async (action: Action): Promise<boolean> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );

      if (!authenticate.VALID) {
        throw new CustomUnauthorizedError(authenticate.STATUS_DESCRIPTION);
      }
      return Promise.resolve(authenticate.VALID);
    },
    controllers: controllerInitializer.controllers(),
    cors: {
      origin:
        ((environment as Record<string, unknown>).CORS_ORIGIN as string) || '*',
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Content-Type',
        'Authorization',
        'Cookie',
        'refresh_token',
      ],
    },
    currentUserChecker: async (
      action: Action
    ): Promise<ClientAuthenticationDto> => {
      const authenticate = await authenticateRequestService.authenticate(
        action.request
      );
      return {
        IS_SYSTEM_ADMIN: authenticate.IS_SYSTEM_ADMIN,
        SYSTEM_ADMIN_SECRET: authenticate.SYSTEM_ADMIN_SECRET,
        USER_ID: authenticate.USER_ID,
      };
    },
    validation: false,
  });

  app.use(httpLogger);
  app.use(cookieParser());
  app.use(express.json({ limit: '100mb' }));
  app.use(
    express.urlencoded({
      extended: true,
      limit: '100mb',
    })
  );

  // Activity tracking for inactivity timeout detection
  app.use(trackActivity);

  app.use(
    '/v1/api-doc',
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec, {
      swaggerOptions: { defaultModelsExpandDepth: -1 },
    })
  );

  await new Promise<void>((resolve) => app.listen({ port: PORT }, resolve));
  logger.info('Environment config: ', {
    ...environment,
  });
  logger.info(`Visit API Docs http://localhost:${PORT}/v1/api-doc `);
  logger.info(`Server running at http://localhost:${PORT} `);
  return app;
};

appDataSource.initialize().then(async (connetion) => {
  logger.info(`Database connection is connected:`, {
    isInitialized: connetion.isInitialized,
  });

  if (!['test', 'local'].includes(environment.NODE_ENV.toLocaleLowerCase())) {
    //RUN PROCESS THAT NEEDED IN SERVER HERE
  }

  await startServer();

  const pulsarListenerRegistry = Container.get(PulsarListenerRegistry);
  pulsarListenerRegistry.startListen();

  // Start session cleanup worker for inactivity timeout detection
  const sessionCleanupWorker = Container.get(SessionCleanupWorker);
  await sessionCleanupWorker.start();

  // Handle graceful shutdown
  process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully...');
    await sessionCleanupWorker.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    logger.info('SIGINT received, shutting down gracefully...');
    await sessionCleanupWorker.stop();
    process.exit(0);
  });
});

 