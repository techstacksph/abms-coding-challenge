import { UserModel } from '../../datasource/models/UserModel';

export const DefaultResetPassword = (user: UserModel, url: string) =>
  `<!DOCTYPE html>
  <html>
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;600;700&display=swap" rel="stylesheet">
      <style>

        body, table, td, a, p, div {
          margin: 0;
          padding: 0;
          font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
          color: #324251;
          font-size: 18px;
          line-height: 20px;
        }
        
        .container {
          background-color: #F4F4F6;
          padding: 40px;
          display: block;
        }

        .logo-container {
          margin: 0 auto 20px auto;
          width: fit-content;
        }

        .email-container {
          background-color: #fff;
          border-radius: 16px;
          margin: 0 auto;
          max-width: 800px;
          width: 100%;
        }

        .email-content {
          padding: 40px;
        }

        .email-title p {
          font-weight: 700 !important;
          font-size: 22px !important;
          line-height: 30px !important;
          color: #090A0B !important;
          margin: 0;
        }

        .email-body p {
          margin-top: 20px;
          font-size: 16px;
        }

        .text-highlight {
          font-family: 'Hanken Grotesk', 'Open Sans', Helvetica, Arial, sans-serif !important;
          font-weight: 700;
          font-size: 16px;
          line-height: 26px;
          text-decoration: none;
          color: #324251;
        }

        .email-fake {
          text-align: center;
          margin-top: 20px;
          font-size: 16px !important;
        }

        .fake-table {
          margin: 0 auto;
        }

        .fake-cell {
          background-color: #3137FD;
          border-radius: 10px;
          text-align: center;
        }

        .fake-link {
          display: inline-block;
          width: 165px;
          padding: 16px 0;
          border-radius: 10px;
          background-color: #3137FD;
          color: #ffffff !important;
          text-decoration: none;
          font-weight: 600;
          font-size: 16px;
          line-height: 21px;
          font-family: 'Hanken Grotesk', 'Open Sans', Helvetica, Arial, sans-serif !important;
        }

        .text-link {
          color: #3137FD !important;
          text-decoration: none;
          font-size: 16px !important;
        }

        .footer {
          text-align: center;
          margin-top: 26px;
          font-size: 16px !important;
        }
        .footer p {
          margin-top: 26px;
          font-size: 16px !important;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="logo-container">
          <img src="cid:app_logo" alt="App Logo" />
        </div>
        <div class="email-container">
          <div>
            <img width="100%" src="cid:reset_password_logo" alt="Reset Password" />
          </div>
          <div class="email-content">
            <div class="email-title" style="text-align: center;">
              <p>Reset password request</p>
            </div>
            <div class="email-body">
              <p>Hi <span class="text-highlight">${
                user?.firstName ?? user.userName
              },</span></p>
              <p>
                It appears that you've forgotten your password. 
                No worries &ndash; these situations can occur.
              </p>
              <p>
                Your login name is: <span class="text-highlight">${
                  user.userName
                }</span><br />
                To initiate a password reset, simply click the button below.
              </p>
            </div>
            <div class="email-fake">
              <table border="0" cellpadding="0" cellspacing="0" class="fake-table">
                <tr>
                  <td class="fake-cell" style="background-color: #3137FD; border-radius: 10px; text-align: center;">
                    <a href="${url}" class="fake-link" style="display: inline-block; width: 165px; padding: 16px 0; border-radius: 10px; background-color: #3137FD; color: #ffffff !important; text-decoration: none; font-weight: 600; font-size: 16px; line-height: 21px; font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;">Reset Password</a>
                  </td>
                </tr>
              </table>
            </div>
            <div class="email-body">
              <p>
                Please do not reply to this message. This is a system-generated email 
                sent to <a href="mailto:${user.email}" class="text-link">${
                  user.email
                }</a>
              </p>
            </div>
          </div>
        </div>
        <div class="footer">
          <p>www.getctoplatform.com</p>
          <p>&copy; ${new Date().getFullYear()} At Your Request</p>
          <p>If you need assistance or have any questions, please contact the admin.</p>
        </div>
      </div>
    </body>
  </html>`;
