import { UserModel } from '../../datasource/models/UserModel';

export const RequiredResetPassword = (
  user: UserModel,
  url: string,
  isPasswordResetRequired: boolean = false,
  rawPassword: string = '',
  roleName: string = 'Administrator'
) => `
<!DOCTYPE html>
  <html>
    <head>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;600;700&display=swap" rel="stylesheet">
      <style>
        body, table, td, a, p, div {
          margin: 0;
          padding: 0;
          font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
          color: #324251;
          font-size: 18px;
          line-height: 28px;
        }

        .container {
          background-color: #F4F4F6;
          padding: 40px;
          display: block;
        }

        .logo-container {
          margin: 0 auto 20px auto;
          width: fit-content;
        }

        .email-container {
          background-color: #fff;
          border-radius: 16px;
          margin: 0 auto;
          max-width: 800px;
          width: 100%;
        }

        .email-content {
          padding: 40px;
        }

        .email-title p {
          font-weight: 700 !important;
          font-size: 22px !important;
          line-height: 30px !important;
          color: #090A0B !important;
          margin: 0;
          text-align: center;
        }

        .email-body p {
          margin-top: 20px;
          line-height: 28px;
          font-size: 16px;
        }

        .text-highlight {
          font-family: 'Hanken Grotesk', 'Open Sans', Helvetica, Arial, sans-serif !important;
          font-weight: 700;
          font-size: 16px;
          line-height: 28px;
          text-decoration: none;
          color: #324251;
        }

        .email-button {
          text-align: center;
          margin-top: 20px;
        }

        .button-table {
          margin: 0 auto;
        }

        .button-cell {
          background-color: #3137FD;
          border-radius: 10px;
          text-align: center;
        }

        .button-link {
          display: inline-block;
          width: 165px;
          padding: 16px 0;
          border-radius: 10px;
          background-color: #3137FD;
          color: #ffffff !important;
          text-decoration: none;
          font-weight: 600;
          font-size: 18px;
          line-height: 21px;
          font-family: 'Hanken Grotesk', 'Open Sans', Helvetica, Arial, sans-serif !important;
        }

        .text-link {
          color: #3137FD !important;
          text-decoration: none;
          font-size: 16px !important;
        }

        .footer {
          text-align: center;
          margin-top: 26px;
          font-size: 16px !important;
        }
        .footer p {
          margin-top: 26px;
          line-height: 28px;
          font-size: 16px !important;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="logo-container">
          <img src="cid:app_logo" alt="App Logo" />
        </div>
        <div class="email-container">
          <div>
            <img width="100%" src="cid:new_user_logo" alt="New User" />
          </div>
          <div class="email-content">
            <div class="email-title">
              <p>Welcome to At Your Request</p>
            </div>
            <div class="email-body">
              <p>Hi <span class="text-highlight">${
                user?.firstName ?? user.userName
              }</span>,</p>
              <p>
                We're excited to have you as ${
                  /^[aeiouAEIOU]/.test(roleName) ? 'an' : 'a'
                } <span class="text-highlight">${roleName}</span> on <span class="text-highlight">AYR Platform</span>.
                Our platform simplifies admin tasks, and ensures smooth oversight
                for peak organizational performance.
              </p>
              <div style="margin-top: 20px;">
                <p style="margin-top: 0; font-size: 16px;">
                  Your login name is: <span class="text-highlight">${
                    user.userName
                  }</span>
                </p>
                ${
                  isPasswordResetRequired
                    ? `
                <p style="margin-top: 0; font-size: 18px;">
                  Your password is: <span class="text-highlight">${rawPassword}</span>
                </p>
                `
                    : ``
                }
              </div>

            </div>
            <div class="email-button">
              <table border="0" cellpadding="0" cellspacing="0" class="button-table">
                <tr>
                  <td class="button-cell" style="background-color: #3137FD; border-radius: 10px; text-align: center;">
                    <a href="${url}" class="button-link" style="display: inline-block; padding: 16px 32px; background-color: #3137FD; border-radius: 10px; color: #ffffff !important; text-decoration: none; font-weight: 600; font-size: 16px; line-height: 21px; font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;">Reset Password</a>
                  </td>
                </tr>
              </table>
            </div>
            <div class="email-body">
              <p>
                Please do not reply to this message. This is a system-generated email
                sent to <a href="mailto:${user.email}" class="text-link">${
                  user.email
                }</a>
              </p>
            </div>
          </div>
        </div>
        <div class="footer">
          <p>www.atyourrequest.co.nz</p>
          <p>&copy; ${new Date().getFullYear()} At Your Request</p>
          <p>If you need assistance or have any questions, please contact the admin.</p>
        </div>
      </div>
    </body>
  </html>   
`;
