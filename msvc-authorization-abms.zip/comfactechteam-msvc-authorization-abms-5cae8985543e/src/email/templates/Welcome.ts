import { UserModel } from '../../datasource/models/UserModel';

export const Welcome = (user: UserModel, url: string) => `
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
      body, table, td, a, p, div {
        font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
        font-size: 18px;
        line-height: 20px;
      }
      .container {
        padding: 40px 60px;
        background-color: #F9FAFB;
        display: block;
      }

      .logo-container {
        margin: 0 auto;
        width: fit-content;
      }
      
      .email-container {
        background-color: #fff;
        border-radius: 16px;
        margin: 0 auto;
        margin-top: 20px;
        width: 619px;
      }
      
      .email-content {
        padding: 0px 40px 40px 40px;
      }
      
      .email-content > div {
        margin-top: 20px;
      }

      .email-content p {
        color: #324251;
      }

      .email-title p {
        color: #1F2226;
      }
      
      .email-title {
        text-align: center;
        font-size: 26px;
        font-weight: 700;
      }
      
      .text-highlight {
        color: #324251 !important;
        font-weight: 700;
      }
      
      .email-button {
        text-align: center;
        margin-top: 20px;
      }
      
      .email-button a {
        display: inline-block;
        width: 165px;
        padding: 16px 0;
        border-radius: 10px;
        background-color: #3137FD;
        box-shadow: 0px 1px 2px 0px #0000000D;
        color: #fff !important;
        text-decoration: none;
        font-weight: 600;
        font-size: 18px;
        line-height: 21px;
        text-align: center;
      }
      
      .text-link {
        color: #3137FD !important;
        text-decoration: none;
      }

      .footer {
        display: block;
        text-align: center;
      }

      .footer p {
        margin: 0px;
        margin-top: 26px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="logo-container">
        <img width="200px" src="cid:app_logo" />
      </div>
      <div class="email-container">
        <div>
          <img width="100%" src="cid:new_user_logo" />
        </div>
        <div class="email-content">
          <div class="email-title">
            <p>Welcome to JobsReports.io!</p>
          </div>
          <div class="email-body">
            <p>Hi <span class="text-highlight">${
              user?.firstName ?? user.userName
            }</span>,</p>
            <p>
              We're excited to have you as an <span class="text-highlight">Administrator</span> on JobsReport.io. 
            </p>
            <p>
              Your username is: <span class="text-highlight">${
                user.userName
              }</span>
            </p>
          </div>
          <div class="email-button">
            <a href="${url}" style="display: inline-block; width: 165px; padding: 16px 0; border-radius: 10px; background-color: #3137FD; color: #fff !important; text-decoration: none; font-weight: 600; font-size: 18px; line-height: 21px; text-align: center; font-family: 'Hanken Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;">Reset Password</a>
          </div>
          <div>
            <div>
              <span>Please do not reply to this message. This is a system-generated email sent to</span>
              <a href="mailto:${user.email}" class="text-link">${user.email}</a>
            </div>
            <p>Team JobReports</p>
          </div>
        </div>
      </div>
      <div class="footer">
        <p>© ${new Date().getFullYear()} JobReports.io</p>
        <p>www.jobreports.io</p>
        <p>If you need assistance or have any questions, please contact our <span class="text-link">Customer Support</span></p>.
      </div>
    </div>
  </body>
</html>
`;
