import { format } from 'date-fns';

import { UserModel } from '../../datasource/models/UserModel';

export const ResetPasswordSuccess = (user: UserModel) => `
<!DOCTYPE html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
      body, table, td, a, p, div {
        margin: 0;
        padding: 0;
        font-family: "Hanken Grotesk", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        color: #324251;
        font-size: 18px;
        line-height: 26px;
      }
      
      .container {
        background-color: #F4F4F6;
        padding: 40px;
        display: block;
      }
      
      .logo-container {
        margin: 0 auto 20px auto;
        width: fit-content;
      }
      
      .email-container {
        background-color: #fff;
        border-radius: 16px;
        margin: 0 auto;
        max-width: 800px;
        width: 100%;
      }
      
      .email-content {
        padding: 40px;
      }
      
      .email-title p {
        color: #090A0B !important;
        font-weight: 700 !important;
        font-size: 22px !important;
        line-height: 30px !important;
        text-align: center;
        margin: 0;
      }
      
      .email-body p {
        margin-top: 20px;
        margin-bottom: 20px;
        font-size: 16px;
      }
      
      .text-highlight {
        font-family: 'Hanken Grotesk', 'Open Sans', Helvetica, Arial, sans-serif !important;
        font-weight: 700;
        font-size: 16px;
        line-height: 26px;
        text-decoration: none;
        color: #324251;
      }
      
      .text-link {
        color: #3137FD !important;
        text-decoration: none;
        font-size: 16px !important;
      }
      
      .footer {
        text-align: center;
        margin-top: 26px;
        font-size: 16px !important;
      }
      
      .footer p {
        margin-top: 26px;
        line-height: 26px;
        font-weight: 400;
        font-size: 16px !important;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="logo-container">
        <img src="cid:app_logo" />
      </div>
      <div class="email-container">
        <div>
          <img width="100%" src="cid:reset_password_logo" />
        </div>
        <div class="email-content">
          <div class="email-title">
            <p>Password successfully changed</p>
          </div>
          <div class="email-body">
            <p>Hi <span class="text-highlight">${
              user?.firstName ?? user.userName
            }</span>,</p>
            <p>
              Your profile's password was successfully reset last ${format(
                new Date(),
                'MMMM dd, yyyy'
              )}
            </p>
          </div>
          <div style = 'font-size: 16px !important;'>
            <div>
              <span>Please do not reply to this message. This is a system-generated email sent to</span>
              <a href="mailto:${user.email}" class="text-link">${user.email}</a>
            </div>
          </div>
        </div>
      </div>
      <div class="footer">
        <p>www.getctoplatform.com</p>
        <p>&copy; ${new Date().getFullYear()} At Your Request</p>
        <p>If you need assistance or have any questions, please contact the admin.</p>
      </div>
    </div>
  </body>
</html>
`;
