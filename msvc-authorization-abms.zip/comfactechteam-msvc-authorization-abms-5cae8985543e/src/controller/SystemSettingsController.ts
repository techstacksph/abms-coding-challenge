import { Response } from 'express';
import { Get, JsonController, Res } from 'routing-controllers';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { SystemSettingsService } from '../services/SystemSettingsService';
import { TestIds } from '../test/SampleData';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1/system-settings')
export class SystemSettingsController {
  constructor(private systemSettingsService: SystemSettingsService) {}

  @Get('/')
  async getSystemSettings(@Res() res: Response) {
    try {
      const systemSettings = await this.systemSettingsService.findOne({
        relations: ['securityLevel'],
        where: { externalOrgId: TestIds.ORGANIZATION_ID },
      });

      return systemSettings?.securityLevel?.configuration;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'system-settings',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
