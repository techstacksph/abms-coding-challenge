import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  JsonController,
  Param,
  Patch,
  Post,
  Res,
} from 'routing-controllers';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import {
  ChangePasswordByTokenDto,
  ChangePasswordDto,
  GenerateTokenDtoByEmailAndLoginName,
  RegisterUserDto,
  UpdateUserRegistrationDto,
} from '../dto/UserDto';
import { UserStatus } from '../enums/UserEnums';
import { UserService } from '../services/UserService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@JsonController('/v1/auth/user')
export class UserController {
  constructor(private userService: UserService) {}

  @Authorized()
  @Post()
  async registerUser(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: RegisterUserDto
  ) {
    const errors: ValidationError[] = await validate(body);
    if (errors.length) {
      logger.debug('validate_user_register', { errors });
      return res.status(400).send(errorValidationResponse(errors));
    }

    const registerUser = body;
    try {
      const result = await this.userService.register(
        user.USER_ID as string,
        registerUser as RegisterUserDto
      );
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'register_user',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Patch('/:status/:userName')
  async changeUserStatus(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Param('status') status: string,
    @Param('userName') userName: string
  ) {
    try {
      if (status == UserStatus.ACTIVE) {
        const result = await this.userService.activate(userName);
        return result;
      } else {
        const result = await this.userService.deactivate(userName);
        return result;
      }
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_user_status',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Post('/generate-token')
  async generateResetPasswordToken(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: GenerateTokenDtoByEmailAndLoginName
  ) {
    logger.info('generate_reset_password_token_controller', { body });

    try {
      const result = await this.userService.generateResetPasswordTokenAndEmail({
        email: body.email,
        host: body.host,
        loginName: body.loginName,
      });
      return result;
    } catch (error) {
      logger.error('generate_registration_token_error', {
        error: (error as Error).message,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'generate_registration_token',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Patch()
  async updateUserRegistration(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: UpdateUserRegistrationDto
  ) {
    const errors: ValidationError[] = await validate(body);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    const userInfo = body;
    try {
      const result = await this.userService.updateUserRegistration(
        user.USER_ID as string,
        userInfo as UpdateUserRegistrationDto
      );
      return result;
    } catch (error) {
      logger.error('update_user_error', { error: (error as Error).message });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_user',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Authorized()
  @Patch('/change-password')
  async changeUserPassword(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: ChangePasswordDto
  ) {
    const errors: ValidationError[] = await validate(body);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    logger.debug('debug_change_password_controller', { user });

    const userInfo = body;
    try {
      const result = await this.userService.changePassword(
        user.USER_ID as string,
        userInfo as ChangePasswordDto
      );
      return result;
    } catch (error) {
      logger.error('change_password_error', {
        error: (error as Error).message,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'change_password',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Patch('/change-password-token')
  async changeUserPasswordByToken(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: ChangePasswordByTokenDto
  ) {
    const errors: ValidationError[] = await validate(body);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    const userInfo = body;

    try {
      const result = await this.userService.changePasswordByToken(
        userInfo as ChangePasswordByTokenDto
      );
      return result;
    } catch (error) {
      logger.error('change_password_error', {
        error: (error as Error).message,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'change_password',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
