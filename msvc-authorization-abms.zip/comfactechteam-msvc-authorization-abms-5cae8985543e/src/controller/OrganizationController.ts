import 'reflect-metadata';

import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  JsonController,
  Patch,
  Post,
  Res,
} from 'routing-controllers';

import { OrganizationModel } from '../datasource/models/OrganizationModel';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import {
  RegisterOrganizationDto,
  UpdateOrganizationDto,
} from '../dto/OrganizationDto';
import { OrganizationService } from '../services/OrganizationService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@Authorized()
@JsonController('/v1/auth/organization')
export class OrganizationController {
  constructor(private organizationService: OrganizationService) {}

  @Post()
  async registerOrganization(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() registerOrg: RegisterOrganizationDto
  ) {
    const errors: ValidationError[] = await validate(registerOrg);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const org = new OrganizationModel();
      Object.assign(org, {
        ...registerOrg,
      });
      const result = await this.organizationService.register(org, {
        userName: user.SYSTEM_ADMIN_SECRET,
      });
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'register_organization',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Patch()
  async updateOrgRegistration(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() updateOrganization: UpdateOrganizationDto
  ) {
    const errors: ValidationError[] = await validate(updateOrganization);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    try {
      const org = new OrganizationModel();
      Object.assign(org, {
        ...updateOrganization,
      });
      const result = await this.organizationService.updateRegistration(
        updateOrganization,
        {
          userName: user.SYSTEM_ADMIN_SECRET,
        }
      );
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_organization',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
