import { ValidationError, validate } from 'class-validator';
import { Response } from 'express';
import {
  Authorized,
  Body,
  CurrentUser,
  Get,
  JsonController,
  Param,
  Patch,
  Res,
} from 'routing-controllers';

import { CompanySettingModel } from '../datasource/models/CompanySettingModel';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { CompanySettingService } from '../services/CompanySettingService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { errorValidationResponse } from '../utils/ModelValidationUtil';

@Authorized()
@JsonController('/v1/auth/company-settings')
export class CompanySettingController {
  constructor(private companySettingService: CompanySettingService) {}

  @Get('/:companySettingsId')
  async getCompanySettings(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('companySettingsId') companySettingsId: string,
    @Res() res: Response
  ) {
    try {
      const companySettings = await this.companySettingService.findOne({
        where: { externalId: companySettingsId },
      });

      logger.debug('get_company_settings_result', companySettings);

      return companySettings;
    } catch (error) {
      logger.error('get_company_settings_error', {
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_company_settings',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Patch()
  async updateCompanySettings(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response,
    @Body() body: CompanySettingModel
  ) {
    const errors: ValidationError[] = await validate(body);
    if (errors.length) {
      return res.status(400).send(errorValidationResponse(errors));
    }

    const companySettingsInfo = body;
    try {
      const result =
        await this.companySettingService.createOrUpdateCompanySettings(
          companySettingsInfo as CompanySettingModel
        );

      return result;
    } catch (error) {
      logger.error('update_company_settings_error', {
        error: (error as Error).message,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_company_setting',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
