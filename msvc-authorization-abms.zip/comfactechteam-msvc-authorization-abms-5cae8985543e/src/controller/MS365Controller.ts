import 'reflect-metadata';

import axios from 'axios';
import { Request, Response } from 'express';
import {
  Get,
  JsonController,
  QueryParam,
  Redirect,
  Req,
  Res,
} from 'routing-controllers';
import { IsNull, Not } from 'typeorm';

import environment from '../environment';
import { CompanySettingService } from '../services/CompanySettingService';
import { MS365Service } from '../services/MS365Service';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1/ms365')
export class MS365Controller {
  constructor(
    private ms365Service: MS365Service,
    private companySettingService: CompanySettingService
  ) {}

  @Get('/signin')
  @Redirect(
    'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=:clientId&response_type=code&redirect_uri=:redirectUri&response_mode=query&scope=:scopes&state=:userId'
  )
  async signIn(@QueryParam('userId') userId: string) {
    const companySettings = await this.companySettingService.findOne({
      order: { updatedAt: 'DESC' },
      where: { externalId: Not(IsNull()) },
    });

    const redirectUri = environment.OAUTH_REDIRECT_URI;
    const scopes = environment.OAUTH_SCOPES;

    const tenantId = companySettings?.tenantId,
      clientId = companySettings?.outlookID,
      clientSecret = companySettings?.outlookSecret,
      hasMS365Keys =
        tenantId && clientId && clientSecret && redirectUri && scopes;

    if (hasMS365Keys) {
      return {
        clientId,
        redirectUri,
        scopes,
        userId,
      };
    }

    return './failed?reason=INCOMPLETE_CREDENTIALS'; // INCOMPLETE INTEGRATION KEYS
  }

  @Get('/callback')
  @Redirect('./success?displayName=:displayName')
  async ms365AuthCallBack(@Req() req: Request) {
    const companySettings = await this.companySettingService.findOne({
      order: { updatedAt: 'DESC' },
      where: { externalId: Not(IsNull()) },
    });

    const redirectUri = environment.OAUTH_REDIRECT_URI;
    const scopes = environment.OAUTH_SCOPES;

    const tenantId = companySettings?.tenantId,
      clientId = companySettings?.outlookID,
      clientSecret = companySettings?.outlookSecret,
      hasMS365Keys =
        tenantId && clientId && clientSecret && redirectUri && scopes;

    if (hasMS365Keys) {
      const params = new URLSearchParams();
      params.append('code', req.query.code as string);
      params.append('scope', scopes);
      params.append('redirect_uri', redirectUri);
      params.append('grant_type', 'authorization_code');
      params.append('client_id', clientId);
      params.append('client_secret', clientSecret);

      const response = await axios.post(
        'https://login.microsoftonline.com/common/oauth2/v2.0/token',
        params
      );

      logger.info('ms_365_get_account_token_response', { response });

      if (response.data) {
        const { access_token, refresh_token } = response.data;

        const user = await this.ms365Service.getAccountDetails(access_token);

        logger.info('ms_365_get_account_details_response', { user });

        if (user.data) {
          const { mail, userPrincipalName, displayName } = user.data;
          const email = mail ?? userPrincipalName;

          const tokenExpirationDate = new Date();
          tokenExpirationDate.setMinutes(tokenExpirationDate.getMinutes() + 55);

          const data = {
            accessToken: access_token,
            email,
            purpose: 'PERSONAL',
            refreshToken: refresh_token,
            tokenExpirationDate,
            userId: req.query.state,
          };

          await this.ms365Service.createMicrosoftAccount(data);

          return { displayName };
        }
      }
    }

    return './failed';
  }

  @Get('/success')
  async onSuccess(
    @Res() res: Response,
    @QueryParam('displayName') displayName: string
  ) {
    return res.send(`
      <html>
        <body style="text-align: center;">
          <br/>
          <span>Account successfully connected to application as: ${String(
            displayName
          ).toUpperCase()}</span>
          <script>
            setTimeout(() => {
              parent.opener.postMessage("close", "*");
              window.close();
            }, 2000);
          </script>
        </body>
      </html>
    `);
  }

  @Get('/failed')
  async onFailed(@Res() res: Response, @QueryParam('reason') reason: string) {
    return res.send(`
      <html>
        <body style="text-align: center;">
          <br/>
          <span>There was an error connecting to your application.</span>
          ${
            reason == 'INCOMPLETE_CREDENTIALS'
              ? `<br/><span>Some credentials are missing or invalid. Please check your settings.</span>`
              : ``
          }
          <script>
            setTimeout(() => {
              parent.opener.postMessage("close", "*");
            }, 2000);
          </script>
        </body>
      </html>
    `);
  }
}
