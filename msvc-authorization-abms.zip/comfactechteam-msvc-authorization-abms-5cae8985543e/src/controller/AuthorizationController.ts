import 'reflect-metadata';

import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import {
  Body,
  CurrentUser,
  Get,
  JsonController,
  Param,
  Post,
  QueryParam,
  Req,
  Res,
} from 'routing-controllers';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { AuthorizationService } from '../services/AuthorizationService';
import { SessionConfigurationService } from '../services/SessionConfigurationService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1/authenticate')
export class AuthorizationController {
  constructor(
    private authorizationService: AuthorizationService,
    private sessionConfigService: SessionConfigurationService
  ) {}

  @Get('/:credential')
  @Post('/:credential')
  async authenticateUser(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('credential') credential: string,
    @Res() res: Response,
    @QueryParam('loginType') loginType: string = 'ADMIN',
    @QueryParam('tokenExpirationMin') tokenExpirationMin?: number
  ) {
    try {
      const type = loginType || 'ADMIN'; // Default to ADMIN
      const result = await this.authorizationService.authenticate(
        credential,
        type,
        tokenExpirationMin
      );
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'authenticate_user',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Get('/email/:credential')
  @Post('/email/:credential')
  async authenticateUserByEmail(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('credential') credential: string,
    @Res() res: Response,
    @QueryParam('loginType') loginType: string = 'ADMIN',
    @QueryParam('tokenExpirationMin') tokenExpirationMin?: number
  ) {
    try {
      const type = loginType || 'ADMIN'; // Default to ADMIN
      const result = await this.authorizationService.authenticateByEmail(
        credential,
        type,
        tokenExpirationMin
      );
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'authenticate_user_by_email',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Get('/refresh/:refresh_token/:username')
  @Post('/refresh/:refresh_token/:username')
  async refreshToken(
    @Param('refresh_token') refresh_token: string,
    @Param('username') username: string,
    @Res() res: Response
  ) {
    try {
      const refresh = await this.authorizationService.refreshSecurityToken(
        username,
        refresh_token
      );
      return refresh;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'refresh_token',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Get('/valid/refresh-token/:refresh_token/:username')
  @Post('/valid/refresh-token/:refresh_token/:username')
  async isValidRefreshToken(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('refresh_token') refresh_token: string,
    @Param('username') username: string,
    @Res() res: Response
  ) {
    try {
      const result = await this.authorizationService.isValidRefreshToken(
        username,
        refresh_token
      );
      return { valid: result };
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'is_valid_token',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Post('/valid/token')
  async isValidToken(
    @CurrentUser() user: ClientAuthenticationDto,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Body() body: any,
    @Res() res: Response
  ) {
    try {
      const result = await this.authorizationService.isValidToken(body.token);
      return { valid: result };
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'is_valid_token',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Get('/token/permission/:token')
  async tokenPermission(
    @CurrentUser() user: ClientAuthenticationDto,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Param('token') token: string,
    @Res() res: Response
  ) {
    try {
      const result =
        await this.authorizationService.getUserPermissionByToken(token);
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'is_valid_token',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  @Get('/system-settings/:token/:userName')
  async getSystemSettingsByToken(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('token') token: string,
    @Param('userName') userName: string,
    @Res() res: Response
  ) {
    try {
      const result = await this.authorizationService.getSystemSettingsByToken(
        token,
        userName
      );
      return result;
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'authenticate_user',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * @deprecated Login lockout feature has been disabled
   * This endpoint is kept for backward compatibility but always returns false
   * POST /v1/authenticate/locked/:user
   */
  @Post('/locked/:user')
  async lockUser(
    @Param('user') user: string,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Body() body: any,
    @Res() res: Response
  ) {
    try {
      const isLocked = await this.authorizationService.lockUser(
        user,
        body.time
      );
      return isLocked; // Always returns false now
    } catch (error) {
      logger.error((error as Error).message);
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'authenticate_user',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Clear all user lockout entries from Redis
   * Used during deployment to unlock all users when lockout feature is disabled
   * POST /v1/authenticate/unlock-all
   */
  @Post('/unlock-all')
  async unlockAllUsers(@Res() res: Response) {
    try {
      const clearedCount = await this.authorizationService.clearAllUserLocks();
      return {
        success: true,
        message: `Cleared ${clearedCount} user lock entries`,
        count: clearedCount,
      };
    } catch (error) {
      logger.error('unlock_all_users_error', {
        error: (error as Error).message,
      });
      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'unlock_all_users',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Update user activity timestamp (called by frontend periodically)
   * POST /v1/authenticate/activity
   */
  @Post('/activity')
  async updateActivity(@Req() req: Request, @Res() res: Response) {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');

      if (!token) {
        return res.status(401).send({ error: 'No token provided' });
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const decoded = jwt.decode(token) as any;

      if (!decoded?.user_name) {
        return res.status(401).send({ error: 'Invalid token' });
      }

      await this.authorizationService.updateUserActivity(decoded.user_name);

      return res.status(200).send({ success: true });
    } catch (error) {
      logger.error('update_activity_failed', {
        error: (error as Error).message,
      });
      return res.status(500).send({ error: 'Internal server error' });
    }
  }

  /**
   * Get session configuration for current user's organization
   * GET /v1/authenticate/session-config
   */
  @Get('/session-config')
  async getSessionConfig(@Req() req: Request, @Res() res: Response) {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');

      if (!token) {
        return res.status(401).send({ error: 'No token provided' });
      }

      const { valid, userPermission } =
        await this.authorizationService.getUserPermissionByToken(token);

      if (!valid || !userPermission) {
        return res.status(401).send({ error: 'Session not found' });
      }

      const config = await this.sessionConfigService.getSessionConfig(
        userPermission.organization_id
      );

      return res.status(200).send(config);
    } catch (error) {
      logger.error('get_session_config_failed', {
        error: (error as Error).message,
      });
      return res.status(500).send({ error: 'Internal server error' });
    }
  }
}
