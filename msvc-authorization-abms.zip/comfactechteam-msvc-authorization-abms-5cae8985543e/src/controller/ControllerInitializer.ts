import { Service } from 'typedi';

import { AuthorizationController } from './AuthorizationController';
import { CompanySettingController } from './CompanySettingController';
import { HomeController } from './HomeController';
import { MS365Controller } from './MS365Controller';
import { OrganizationController } from './OrganizationController';
import { RecordLockController } from './RecordLockController';
import { SecurityLevelController } from './SecurityLevelController';
import { SystemSettingsController } from './SystemSettingsController';
import { UserController } from './UserController';

@Service()
export class ControllerInitializer {
  // eslint-disable-next-line @typescript-eslint/ban-types
  controllers(): Function[] | string[] {
    return [
      HomeController,
      AuthorizationController,
      UserController,
      OrganizationController,
      SystemSettingsController,
      CompanySettingController,
      MS365Controller,
      RecordLockController,
      SecurityLevelController,
    ];
  }
}
