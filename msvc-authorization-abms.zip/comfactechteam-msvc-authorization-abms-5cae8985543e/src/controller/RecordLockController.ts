import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import {
  Authorized,
  Body,
  CurrentUser,
  Delete,
  Get,
  JsonController,
  Post,
  QueryParam,
  Req,
  Res,
} from 'routing-controllers';

import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { RedisEntryNames } from '../enums/RedisEntryName';
import {
  AcquireLockParams,
  CheckLockParams,
  RecordLockService,
  ReleaseLockParams,
} from '../services/RecordLockService';
import { UserService } from '../services/UserService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';

@JsonController('/v1/record-locks')
export class RecordLockController {
  constructor(
    private recordLockService: RecordLockService,
    private userService: UserService
  ) {}

  /**
   * Extract user information from JWT token
   * Supports both Authorization header, cookie-based authentication, and body token
   * (cookies and body tokens are used by sendBeacon which cannot send custom headers)
   */
  private getUserFromToken(req: Request): string | null {
    try {
      // Try Authorization header first (normal requests)
      let token = req.headers.authorization?.replace('Bearer ', '');

      // Fall back to access_token in request body (sendBeacon requests)
      if (!token && req.body?.accessToken) {
        token = req.body.accessToken;
        logger.info('extract_user_from_body', {
          hasToken: !!token,
        });
      }

      // Fall back to access_token cookie (sendBeacon requests)
      if (!token && req.cookies?.access_token) {
        token = req.cookies.access_token;
        logger.info('extract_user_from_cookie', {
          hasCookie: !!token,
        });
      }

      if (!token) {
        logger.warn('extract_user_no_token', {
          hasAuthHeader: !!req.headers.authorization,
          hasBodyToken: !!req.body?.accessToken,
          hasCookie: !!req.cookies?.access_token,
        });
        return null;
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const decoded = jwt.decode(token) as any;
      const userName = decoded?.user_name || decoded?.username;

      logger.info('extract_user_from_token', {
        hasToken: !!token,
        hasDecoded: !!decoded,
        userName,
        source: req.headers.authorization
          ? 'header'
          : req.body?.accessToken
          ? 'body'
          : 'cookie',
      });

      return userName || null;
    } catch (error) {
      logger.error('extract_user_from_token_error', {
        error: (error as Error).message,
      });
      return null;
    }
  }

  /**
   * Acquire a lock for a record
   * POST /v1/record-locks/acquire
   *
   * Body: {
   *   recordType: string;
   *   recordId: string;
   * }
   */
  @Authorized()
  @Post('/acquire')
  async acquireLock(
    @Body()
    body: {
      recordType: string;
      recordId: string;
    },
    @Req() req: Request,
    @CurrentUser() currentUser: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      // Extract username from JWT token
      const userName = this.getUserFromToken(req);
      if (!userName) {
        return res
          .status(401)
          .send(
            new ApiErrorResponseDto(
              401,
              'record-lock-acquire',
              'UNAUTHORIZED',
              'Unable to extract user information from token'
            )
          );
      }

      logger.info('acquire_lock_user_lookup', { userName });

      const user = await this.userService.findByUserName(userName);
      logger.info('acquire_lock_user_found', {
        userName,
        hasUser: !!user,
        hasOrganization: !!user?.organization,
        orgId: user?.organization?.id,
      });

      if (!user || !user.organization) {
        return res
          .status(403)
          .send(
            new ApiErrorResponseDto(
              403,
              'record-lock-acquire',
              'USER_NOT_FOUND',
              'User or organization not found'
            )
          );
      }

      const displayName =
        user.firstName && user.lastName
          ? `${user.firstName} ${user.lastName}`
          : user.userName || 'Unknown User';
      const orgId = user.organization.id;

      const params: AcquireLockParams = {
        recordType: body.recordType,
        recordId: body.recordId,
        userId: userName,
        userName: displayName,
        orgId,
      };

      const lockInfo = await this.recordLockService.acquireLock(params);

      return lockInfo;
    } catch (error) {
      logger.error('acquire_lock_controller_error', {
        error: (error as Error).message,
        recordType: body.recordType,
        recordId: body.recordId,
      });

      const errorNumber = toHttpErrorCode(error, 409); // 409 Conflict
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-acquire',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Release a lock for a record
   * POST /v1/record-locks/release
   *
   * Body: {
   *   recordType: string;
   *   recordId: string;
   * }
   *
   * Note: No @Authorized() decorator to support sendBeacon API
   * which cannot send custom headers. Authentication is handled
   * manually via cookies.
   */
  @Post('/release')
  async releaseLock(
    @Body()
    body: {
      recordType: string;
      recordId: string;
    },
    @Req() req: Request,
    @CurrentUser() currentUser: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      const userName = this.getUserFromToken(req);
      if (!userName) {
        return res
          .status(401)
          .send(
            new ApiErrorResponseDto(
              401,
              'record-lock-release',
              'UNAUTHORIZED',
              'Unable to extract user information from token'
            )
          );
      }

      const user = await this.userService.findByUserName(userName);
      if (!user || !user.organization) {
        return res
          .status(403)
          .send(
            new ApiErrorResponseDto(
              403,
              'record-lock-release',
              'USER_NOT_FOUND',
              'User or organization not found'
            )
          );
      }

      const orgId = user.organization.id;

      const params: ReleaseLockParams = {
        recordType: body.recordType,
        recordId: body.recordId,
        userId: userName,
        orgId,
      };

      const result = await this.recordLockService.releaseLock(params);

      return { success: result };
    } catch (error) {
      logger.error('release_lock_controller_error', {
        error: (error as Error).message,
        recordType: body.recordType,
        recordId: body.recordId,
      });

      const errorNumber = toHttpErrorCode(error, 403); // 403 Forbidden
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-release',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Check lock status for a record
   * GET /v1/record-locks/status?recordType=job&recordId=123
   */
  @Authorized()
  @Get('/status')
  async checkLockStatus(
    @QueryParam('recordType') recordType: string,
    @QueryParam('recordId') recordId: string,
    @Req() req: Request,
    @CurrentUser() currentUser: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      if (!recordType || !recordId) {
        return res
          .status(400)
          .send(
            new ApiErrorResponseDto(
              400,
              'record-lock-status',
              'BAD_REQUEST',
              'recordType and recordId are required'
            )
          );
      }

      const userName = this.getUserFromToken(req);
      if (!userName) {
        return res
          .status(401)
          .send(
            new ApiErrorResponseDto(
              401,
              'record-lock-status',
              'UNAUTHORIZED',
              'Unable to extract user information from token'
            )
          );
      }

      const user = await this.userService.findByUserName(userName);
      if (!user || !user.organization) {
        return res
          .status(403)
          .send(
            new ApiErrorResponseDto(
              403,
              'record-lock-status',
              'USER_NOT_FOUND',
              'User or organization not found'
            )
          );
      }

      const orgId = user.organization.id;

      const params: CheckLockParams = {
        recordType,
        recordId,
        userId: userName,
        orgId,
      };

      const lockInfo = await this.recordLockService.checkLockStatus(params);

      return lockInfo;
    } catch (error) {
      logger.error('check_lock_status_controller_error', {
        error: (error as Error).message,
        recordType,
        recordId,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-status',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Force release a lock (admin operation)
   * DELETE /v1/record-locks/force-release?recordType=job&recordId=123
   */
  @Authorized()
  @Delete('/force-release')
  async forceReleaseLock(
    @QueryParam('recordType') recordType: string,
    @QueryParam('recordId') recordId: string,
    @CurrentUser() currentUser: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      if (!recordType || !recordId) {
        return res
          .status(400)
          .send(
            new ApiErrorResponseDto(
              400,
              'record-lock-force-release',
              'BAD_REQUEST',
              'recordType and recordId are required'
            )
          );
      }

      const adminUserId = currentUser.USER_ID || 'unknown';

      const result = await this.recordLockService.forceReleaseLock(
        recordType,
        recordId,
        adminUserId
      );

      return { success: result };
    } catch (error) {
      logger.error('force_release_lock_controller_error', {
        error: (error as Error).message,
        recordType,
        recordId,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-force-release',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Clear lock timeout cache for debugging
   * DELETE /v1/record-locks/clear-cache
   */
  @Authorized()
  @Delete('/clear-cache')
  async clearLockTimeoutCache(@Res() res: Response) {
    try {
      // Clear all lock timeout caches
      const pattern = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_*`;
      const keys =
        await this.recordLockService['redisClient'].scanKeys(pattern);

      for (const key of keys) {
        await this.recordLockService['redisClient'].delValue(key);
      }

      logger.info('lock_timeout_cache_cleared_manual', {
        keysCleared: keys.length,
      });

      return { success: true, keysCleared: keys.length };
    } catch (error) {
      logger.error('clear_lock_timeout_cache_error', {
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-clear-cache',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Get all active locks for the organization
   * GET /v1/record-locks/active
   */
  @Authorized()
  @Get('/active')
  async getActiveLocks(
    @Req() req: Request,
    @CurrentUser() currentUser: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      const userName = this.getUserFromToken(req);
      if (!userName) {
        return res
          .status(401)
          .send(
            new ApiErrorResponseDto(
              401,
              'record-lock-active',
              'UNAUTHORIZED',
              'Unable to extract user information from token'
            )
          );
      }

      const user = await this.userService.findByUserName(userName);
      if (!user || !user.organization) {
        return res
          .status(403)
          .send(
            new ApiErrorResponseDto(
              403,
              'record-lock-active',
              'USER_NOT_FOUND',
              'User or organization not found'
            )
          );
      }

      const orgId = user.organization.id;
      const locks = await this.recordLockService.getActiveLocks(orgId);

      return { locks, count: locks.length };
    } catch (error) {
      logger.error('get_active_locks_controller_error', {
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'record-lock-active',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
