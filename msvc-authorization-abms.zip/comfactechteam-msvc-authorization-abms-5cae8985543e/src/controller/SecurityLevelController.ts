import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import {
  Authorized,
  Body,
  CurrentUser,
  Get,
  JsonController,
  Param,
  Patch,
  Req,
  Res,
} from 'routing-controllers';

import { RedisClient } from '../client/redis/RedisClient';
import { SecurityLevelModel } from '../datasource/models/SecurityLevelModel';
import { ApiErrorResponseDto } from '../dto/ApiErrorResponseDto';
import { ClientAuthenticationDto } from '../dto/ClientAuthenticationDto';
import { SecurityLevelConfigurationDto } from '../dto/SecurityLevelDto';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { CompanySettingService } from '../services/CompanySettingService';
import { SecurityLevelService } from '../services/SecurityLevelService';
import { SessionConfigurationService } from '../services/SessionConfigurationService';
import { UserService } from '../services/UserService';
import {
  getCustomErrorAdditionalMessage,
  getCustomErrorName,
  toHttpErrorCode,
} from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';

@Authorized()
@JsonController('/v1/security-levels')
export class SecurityLevelController {
  constructor(
    private securityLevelService: SecurityLevelService,
    private redisClient: RedisClient,
    private userService: UserService,
    private companySettingService: CompanySettingService,
    private sessionConfigService: SessionConfigurationService
  ) {}

  /**
   * Extract user information from JWT token
   * Similar pattern to RecordLockController
   */
  private getUserFromToken(req: Request): string | null {
    try {
      // Extract token from Authorization header
      const token = req.headers.authorization?.replace('Bearer ', '');

      if (!token) {
        logger.warn('extract_user_no_token', {
          hasAuthHeader: !!req.headers.authorization,
        });
        return null;
      }

      // Decode JWT token
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const decoded = jwt.decode(token) as any;
      const userName = decoded?.user_name || decoded?.username;

      logger.info('extract_user_from_token', {
        hasToken: !!token,
        hasDecoded: !!decoded,
        userName,
      });

      return userName || null;
    } catch (error) {
      logger.error('extract_user_from_token_error', {
        error: (error as Error).message,
      });
      return null;
    }
  }

  /**
   * Get all security levels
   * GET /v1/security-levels
   */
  @Get()
  async getAllSecurityLevels(
    @CurrentUser() user: ClientAuthenticationDto,
    @Res() res: Response
  ) {
    try {
      const securityLevels = await this.securityLevelService.all();

      logger.debug('get_all_security_levels_result', {
        count: securityLevels.length,
      });

      return securityLevels;
    } catch (error) {
      logger.error('get_all_security_levels_error', {
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_all_security_levels',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Get security level by name
   * GET /v1/security-levels/by-name/:levelName
   */
  @Get('/by-name/:levelName')
  async getSecurityLevelByName(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('levelName') levelName: string,
    @Res() res: Response
  ) {
    try {
      const securityLevel = await this.securityLevelService.findOne({
        where: { name: levelName },
      });

      if (!securityLevel) {
        logger.warn('security_level_not_found', { levelName });
        return res
          .status(404)
          .send(
            new ApiErrorResponseDto(
              404,
              'get_security_level_by_name',
              'NOT_FOUND',
              `Security level '${levelName}' not found`
            )
          );
      }

      logger.debug('get_security_level_by_name_result', {
        id: securityLevel.id,
        name: securityLevel.name,
      });

      return securityLevel;
    } catch (error) {
      logger.error('get_security_level_by_name_error', {
        levelName,
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'get_security_level_by_name',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }

  /**
   * Update security level configuration
   * PATCH /v1/security-levels/:id/configuration
   */
  @Patch('/:id/configuration')
  async updateSecurityLevelConfiguration(
    @CurrentUser() user: ClientAuthenticationDto,
    @Param('id') id: string,
    @Body() body: { configuration: SecurityLevelConfigurationDto },
    @Req() req: Request,
    @Res() res: Response
  ) {
    try {
      // Extract username from JWT token
      const userName = this.getUserFromToken(req);
      if (!userName) {
        return res
          .status(401)
          .send(
            new ApiErrorResponseDto(
              401,
              'update_security_level_configuration',
              'UNAUTHORIZED',
              'Unable to extract user information from token'
            )
          );
      }

      logger.info('update_security_level_user_lookup', { userName });

      // Get user details
      const userDetails = await this.userService.findByUserName(userName);
      if (!userDetails || !userDetails.organization) {
        return res
          .status(403)
          .send(
            new ApiErrorResponseDto(
              403,
              'update_security_level_configuration',
              'USER_NOT_FOUND',
              'User or organization not found'
            )
          );
      }

      const displayName =
        userDetails.firstName && userDetails.lastName
          ? `${userDetails.firstName} ${userDetails.lastName}`
          : userDetails.userName || 'Unknown User';

      // Validate that the security level exists
      const existingLevel = await this.securityLevelService.findById(id);

      if (!existingLevel) {
        logger.warn('security_level_not_found_for_update', { id });
        return res
          .status(404)
          .send(
            new ApiErrorResponseDto(
              404,
              'update_security_level_configuration',
              'NOT_FOUND',
              `Security level with id '${id}' not found`
            )
          );
      }

      // Validate that configuration is provided
      if (!body.configuration) {
        return res
          .status(400)
          .send(
            new ApiErrorResponseDto(
              400,
              'update_security_level_configuration',
              'INVALID_REQUEST',
              'Configuration object is required'
            )
          );
      }

      logger.info('update_security_level_before_update', {
        id,
        existingConfiguration: existingLevel.configuration,
        newConfiguration: body.configuration,
        existingLevelKeys: Object.keys(existingLevel),
      });

      // Update the configuration
      existingLevel.configuration = body.configuration;

      logger.info('update_security_level_after_assignment', {
        id,
        updatedConfiguration: existingLevel.configuration,
        configurationMatches: existingLevel.configuration === body.configuration,
      });

      const updatedLevel = await this.securityLevelService.update(
        id,
        existingLevel as SecurityLevelModel,
        {
          userId: userDetails.id,
          userName: displayName,
        }
      );

      logger.info('update_security_level_after_service_call', {
        id,
        updatedLevelReturned: !!updatedLevel,
        updatedLevelConfiguration: updatedLevel?.configuration,
      });

      // Clear lock timeout cache when security level configuration is updated
      const lockTimeoutCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${id}`;
      await this.redisClient.delValue(lockTimeoutCacheKey);

      // Find all organizations using this security level and invalidate their session config cache
      const companySettings = await this.companySettingService.find({
        where: { securityLevelId: id },
      });

      logger.info('invalidating_session_config_caches', {
        securityLevelId: id,
        organizationsAffected: companySettings.length,
      });

      // Invalidate session config cache for each affected organization
      for (const setting of companySettings) {
        if (setting?.externalOrgId) {
          await this.sessionConfigService.invalidateCache(setting.externalOrgId);
          logger.info('session_config_cache_invalidated', {
            orgId: setting.externalOrgId,
            reason: 'security_level_configuration_updated',
          });
        }
      }

      logger.info('security_level_configuration_updated', {
        id,
        name: existingLevel.name,
        updatedByUserId: userDetails.id,
        updatedByUserName: userName,
        updatedByDisplayName: displayName,
        cacheKeyCleared: lockTimeoutCacheKey,
        sessionConfigCachesInvalidated: companySettings.length,
        newRecordLockTimeInMins:
          body.configuration?.record?.recordLockTimeInMins,
      });

      return updatedLevel;
    } catch (error) {
      logger.error('update_security_level_configuration_error', {
        id,
        error: (error as Error).message,
      });

      const errorNumber = toHttpErrorCode(error, 500);
      return res
        .status(errorNumber)
        .send(
          new ApiErrorResponseDto(
            errorNumber,
            'update_security_level_configuration',
            getCustomErrorName(error),
            getCustomErrorAdditionalMessage(error)
          )
        );
    }
  }
}
