import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { Container } from 'typedi';

import { AuthorizationService } from '../services/AuthorizationService';
import { logger } from '../utils/LoggerUtils';

/**
 * Activity Tracker Middleware
 * Updates user activity timestamp for inactivity tracking
 * Runs in fire-and-forget mode to avoid blocking requests
 */
export async function trackActivity(
  req: Request,
  res: Response,
  next: NextFunction
) {
  // Only track for authenticated requests
  if (!req.headers.authorization) {
    return next();
  }

  try {
    const authService = Container.get(AuthorizationService);

    // Extract username from token (non-blocking)
    const token = req.headers.authorization.replace('Bearer ', '');

    // Decode without verification (fast)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const decoded = jwt.decode(token) as any;

    if (decoded?.user_name) {
      // Update activity timestamp (fire and forget - don't await)
      authService.updateUserActivity(decoded.user_name).catch((err) => {
        logger.error('activity_tracking_failed', {
          error: (err as Error).message,
          userName: decoded.user_name,
        });
      });
    }
  } catch (error) {
    // Don't block request if activity tracking fails
    logger.error('activity_tracker_error', {
      error: (error as Error).message,
    });
  }

  // Always continue to next middleware
  next();
}
