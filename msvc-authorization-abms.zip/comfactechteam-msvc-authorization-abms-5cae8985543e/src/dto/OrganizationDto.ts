import { IsNotEmpty } from 'class-validator';

import { OrganizationStatus } from '../enums/OrganizationEnums';

export class RegisterOrganizationDto {
  @IsNotEmpty({ message: 'Organization code is required' })
  code!: string;

  @IsNotEmpty({ message: 'Organization name is required' })
  name!: string;

  @IsNotEmpty({ message: 'External is required' })
  externalId?: string;

  @IsNotEmpty({ message: 'Organization status is required' })
  status: OrganizationStatus = OrganizationStatus.CREATED;

  description?: string;
}

export class UpdateOrganizationDto {
  @IsNotEmpty({ message: 'Organization code is required' })
  code!: string;

  @IsNotEmpty({ message: 'Organization name is required' })
  name!: string;

  @IsNotEmpty({ message: 'External is required' })
  externalId?: string;

  @IsNotEmpty({ message: 'Organization status is required' })
  status: OrganizationStatus = OrganizationStatus.CREATED;

  description?: string;
}
