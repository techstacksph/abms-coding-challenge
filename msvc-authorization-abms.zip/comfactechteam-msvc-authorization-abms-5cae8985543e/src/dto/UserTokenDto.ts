export class UserIdentityPermission {
  external_id!: string;
  email!: string;
  user_name!: string;
  external_orgid!: string;
  organization_id!: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  permission!: any;
  user_id!: string;
  token_secret!: string;
  user_type!: string;
  firstName?: string;
  lastName?: string;
  account_id?: string;
}

export class UserToken {
  user_name!: string;
  token_secret!: string;
  user_type!: string;
  account_id?: string;
}

export class RefreshTokenDto {
  user_id!: string;
  external_user_id!: string;
  token!: string;
  token_key!: string;
  user_name!: string;
}

export class UserRegistrationTokenDto {
  token_secret!: string;
}
