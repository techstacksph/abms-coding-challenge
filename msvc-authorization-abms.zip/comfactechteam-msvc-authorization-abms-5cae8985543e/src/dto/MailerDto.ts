import { CompanySettingsMailSender } from '../enums/CompanySettingEnum';

/* eslint-disable no-unused-vars */
export enum smtpType {
  GOOGLE = 'GOOGLE',
  M365 = 'M365',
  OTHERS = 'OTHERS',
}

export class MailerOptionDto {
  mailerCredentialOption?: MailerTransportOptionDto;
  sender!: string;
  replyTo!: string;
  recipients!: string[];
  subject!: string;
  content!: string;
  attachments?: Array<{ cid: string; content: string; encoding: string; contentType?: string }>;
}

export class MailerTransportOptionDto {
  smtpType?: smtpType;
  username?: string;
  password?: string;
  host?: string;
  port?: number;
  m365?: {
    clientId: string;
    clientSecret: string;
    tenantId: string;
    accessToken?: string;
    refreshToken?: string;
  };
  customDisplayName?: string;
  mailSender?: CompanySettingsMailSender;
}
