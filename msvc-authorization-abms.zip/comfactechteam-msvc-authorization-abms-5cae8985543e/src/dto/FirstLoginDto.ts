export class FirstLoginDto {
  isPasswordResetRequired!: boolean;
  resetPasswordLink?: string;
}
