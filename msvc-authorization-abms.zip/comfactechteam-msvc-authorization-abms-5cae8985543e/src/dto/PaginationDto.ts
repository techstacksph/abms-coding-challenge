import { Max, Min } from 'class-validator';

/* eslint-disable no-unused-vars */
export abstract class PaginatedData<T> {
  data?: T[] = [];
  pageInfo?: PageInfo;
  sort?: SortingInfo[];
}

export class PageInfo {
  count?: number = 0;

  pageSize?: number = 0;

  pageCount?: number = 0;

  skip?: number = 0;

  take?: number = 0;
}

export class SortingInfo {
  field!: string;

  direction: SortDirection = SortDirection.asc;
}

export enum SortDirection {
  asc = 'ASC',
  desc = 'DESC',
}

export class PageArg {
  @Min(0)
  skip!: number;

  @Min(1)
  @Max(50)
  take!: number;

  sort?: SortingInfo[];
}
