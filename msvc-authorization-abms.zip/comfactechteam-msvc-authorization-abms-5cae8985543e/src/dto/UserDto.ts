import { Type } from 'class-transformer';
import { IsEmail, IsNotEmpty } from 'class-validator';

import { UserModel } from '../datasource/models/UserModel';
import { UserStatus } from '../enums/UserEnums';
import { PaginatedData } from './PaginationDto';

export class PaginatedUser extends PaginatedData<UserModel> {}

export class PermissionDto {
  @IsNotEmpty({ message: 'System ID is required' })
  systemId!: string;

  access: string[] = [];
  locations: string[] = [];
  departments: string[] = [];
  functions: string[] = [];
}

export class RegisterUserDto {
  @IsNotEmpty({ message: 'External id is required' })
  externalId!: string;

  @IsNotEmpty({ message: 'User name is required' })
  userName!: string;

  @IsNotEmpty({ message: 'Password is required' })
  password!: string;

  @IsNotEmpty({ message: 'Status is required' })
  status!: UserStatus;

  @IsNotEmpty({ message: 'Email is required' })
  @IsEmail({}, { message: 'Should be email format' })
  email!: string;

  @IsNotEmpty({ message: 'Role is required' })
  externalRoleId!: string;

  firstName?: string;
  lastName?: string;

  setPassword?: boolean;
  requireThis?: boolean;

  @Type(() => PermissionDto)
  permissions?: PermissionDto;
}
export class UpdateUserRegistrationDto {
  externalId?: string;

  @IsNotEmpty({ message: 'User name is required' })
  userName!: string;

  @IsNotEmpty({ message: 'Email is required' })
  @IsEmail({}, { message: 'Should be email format' })
  email!: string;

  password?: string;
  status?: UserStatus;
  externalRoleId?: string;
  firstName?: string;
  lastName?: string;

  @Type(() => PermissionDto)
  permissions?: PermissionDto;
}

export class ChangePasswordDto {
  @IsNotEmpty({ message: 'Old password is required' })
  oldPassword!: string;

  @IsNotEmpty({ message: 'Password is required' })
  password!: string;

  @IsNotEmpty({ message: 'User name is required' })
  userName!: string;
}

export class ChangePasswordByTokenDto {
  @IsNotEmpty({ message: 'Password is required' })
  password!: string;

  @IsNotEmpty({ message: 'Token is required' })
  token!: string;

  @IsNotEmpty({ message: 'User name is required' })
  userName!: string;
}

export class GenerateTokenDto {
  @IsNotEmpty({ message: 'Host is required' })
  host!: string;

  @IsNotEmpty({ message: 'User name is required' })
  userName!: string;
}

export class GenerateTokenDtoByEmail {
  @IsNotEmpty({ message: 'Host is required' })
  host!: string;

  @IsNotEmpty({ message: 'Email is required' })
  email!: string;
}

export class GenerateTokenDtoByEmailAndLoginName {
  @IsNotEmpty({ message: 'Host is required' })
  host!: string;

  @IsNotEmpty({ message: 'Email is required' })
  email!: string;

  @IsNotEmpty({ message: 'Login name is required' })
  loginName!: string;
}
