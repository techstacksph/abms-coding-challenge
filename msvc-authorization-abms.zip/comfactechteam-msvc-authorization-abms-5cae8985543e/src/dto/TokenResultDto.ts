export class TokenResultDto {
  refresh!: string;
  jwt!: string;
  isPasswordResetRequired?: boolean;
  resetPasswordLink?: string;
}
