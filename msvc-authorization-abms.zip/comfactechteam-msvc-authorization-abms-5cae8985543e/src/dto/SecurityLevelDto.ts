export class SecurityLevelConfigurationDto {
  authentication?: {
    session: {
      inactivityInMin: number;
      loginSession: number;
    };
    login: {
      maxFailedLogin: number;
      userLockTimeInMins: number;
    };
    password: {
      minPasswordLength: number;
      requireNumber: boolean;
      requireSpecialCharacter: boolean;
      requireLowercaseCharacter: boolean;
      requireUppercaseCharacter: boolean;
      allowSequentialCharacters: boolean;
      allowSamePassword: boolean;
    };
  };
  record?: {
    recordLockTimeInMins: number;
  };
}
