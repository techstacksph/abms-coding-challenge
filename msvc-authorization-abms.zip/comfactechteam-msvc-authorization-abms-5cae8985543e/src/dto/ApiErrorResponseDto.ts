export class ApiErrorResponseDto {
  constructor(
    error_code: number,
    source: string,
    errors: unknown,
    message?: unknown
  ) {
    this.error = true;
    this.source = source;
    this.error_code = error_code;
    this.errors = errors;
    this.message = message;
  }
  error!: boolean;
  error_code!: number;
  errors!: unknown;
  source!: string;
  message?: unknown;
}
