export class ClientAuthenticationDto {
  USER_ID?: string | null;
  IS_SYSTEM_ADMIN!: boolean;
  SYSTEM_ADMIN_SECRET?: string;
}
