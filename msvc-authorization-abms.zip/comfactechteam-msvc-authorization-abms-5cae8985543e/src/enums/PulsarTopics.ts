/* eslint-disable no-unused-vars */
export enum PulsarTopics {
  AUTHORIZATION = 'AYR_AUTHORIZATION',
  JOB_REPORTS = 'JOB_REPORTS',
  BACK_OFFICE = 'AYR_BACK_OFFICE',
  WORKBUE = 'WORKBUE', // Add tenant that will receive the message
  COMMUNICATION_MEDIA = 'COMMUNICATION_MEDIA',
  AYRBMS = 'AYRBMS',
}
