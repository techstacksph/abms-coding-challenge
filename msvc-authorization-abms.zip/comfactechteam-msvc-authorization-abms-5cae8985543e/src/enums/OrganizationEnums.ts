/* eslint-disable no-unused-vars */
export enum OrganizationStatus {
  CREATED = 'CREATED',
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}
