/* eslint-disable no-unused-vars */
export enum CompanySettingTaxRates {
  NO_TAX = 'NO_TAX',
  TAX_EXCLUSIVE = 'TAX_EXCLUSIVE',
  TAX_INCLUSIVE = 'TAX_INCLUSIVE',
  ZERO_RATE = 'ZERO_RATE',
}

export enum CompanySettingsEmailSettings {
  MICROSOFT_OUTLOOK = 'MICROSOFT_OUTLOOK',
  OTHERS = 'OTHERS',
}

export enum CompanySettingsMailSender {
  COMPANY_NAME = 'COMPANY_NAME',
  CURRENT_USER_NAME = 'CURRENT_USER_NAME',
  CUSTOM_DISPLAY_NAME = 'CUSTOM_DISPLAY_NAME',
}
