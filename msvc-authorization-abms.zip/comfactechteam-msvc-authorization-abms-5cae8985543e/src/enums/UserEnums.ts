/* eslint-disable no-unused-vars */
export enum UserStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
}

export enum SystemUser {
  userName = 'SYSTEM_PROCESS',
}

export enum UserType {
  ADMIN = 'ADMIN',
  FRANCHISEE = 'FRANCHISEE',
  CLIENT = 'CLIENT',
}
