import { Application } from 'express';
import request from 'supertest';
import { Container } from 'typeorm-typedi-extensions';

import { faker } from '@faker-js/faker';

import {
  RegisterOrganizationDto,
  UpdateOrganizationDto,
} from '../../dto/OrganizationDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import environment from '../../environment';
import { logger } from '../../utils/LoggerUtils';
import { AppServerUtils } from '../../utils/TestUtils';

describe('ORGANIZATION CONTROLLER TEST', () => {
  let server: Application;
  let appServer: AppServerUtils;

  beforeAll(async () => {
    appServer = Container.get(AppServerUtils);
    server = await appServer.startServer();
  });

  afterAll(async () => {
    //
  });

  function mockRegisterOrganizationData(): RegisterOrganizationDto {
    return {
      code: faker.company.name(),
      description: faker.lorem.sentence(),
      externalId: faker.string.uuid(),
      name: faker.company.name(),
      status: faker.helpers.arrayElement(Object.values(OrganizationStatus)),
    };
  }

  test('POST', async () => {
    const resp = await request(server)
      .post('/v1/auth/organization')
      .set({ Authorization: environment.SYSTEM_ADMIN_SECRET })
      .send(mockRegisterOrganizationData());

    logger.debug('register_organization_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);
  });

  test('PATCH', async () => {
    const resp = await request(server)
      .post('/v1/auth/organization')
      .set({ Authorization: environment.SYSTEM_ADMIN_SECRET })
      .send(mockRegisterOrganizationData());

    logger.debug('register_organization_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);

    const org = resp.body as UpdateOrganizationDto;
    org.description = `${org.description} - UPDATED`;

    const respUpdate = await request(server)
      .patch('/v1/auth/organization')
      .set({ Authorization: environment.SYSTEM_ADMIN_SECRET })
      .send(org);

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.description).toBe(org.description);

    logger.debug('update_registered_organization_test_result', {
      data: respUpdate.body,
    });
  });

  test('NOT AUTHORIZED', async () => {
    const resp = await request(server)
      .post('/v1/auth/organization')
      .send(mockRegisterOrganizationData());

    logger.debug('register_organization_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(401);
  });
});
