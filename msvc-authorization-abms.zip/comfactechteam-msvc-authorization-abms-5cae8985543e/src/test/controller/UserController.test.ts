import { Application } from 'express';
import request from 'supertest';
import { Container } from 'typeorm-typedi-extensions';

import { faker } from '@faker-js/faker';

import { PulsarProducerClient } from '../../client/pulsar/producer/PulsarProducerClient';
import { OrganizationModel } from '../../datasource/models/OrganizationModel';
import { RegisterOrganizationDto } from '../../dto/OrganizationDto';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import {
  GenerateTokenDtoByEmail,
  RegisterUserDto,
  UpdateUserRegistrationDto,
} from '../../dto/UserDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { UserStatus } from '../../enums/UserEnums';
import environment from '../../environment';
import { OrganizationService } from '../../services/OrganizationService';
import { logger } from '../../utils/LoggerUtils';
import { AppServerUtils } from '../../utils/TestUtils';
import { TestIds } from '../SampleData';

describe('ORGANIZATION CONTROLLER TEST', () => {
  let server: Application;
  let appServer: AppServerUtils;
  let organizationsService: OrganizationService;
  let organization: OrganizationModel;

  beforeAll(async () => {
    appServer = Container.get(AppServerUtils);
    server = await appServer.startServer();
    organizationsService = Container.get(OrganizationService);
    organization = await createMockOrganization();

    if (environment.NODE_ENV == 'test') {
      jest.mock('../../client/pulsar/producer/PulsarProducerClient');
      PulsarProducerClient.prototype.produce = jest.fn(
        (): Promise<string | null> => {
          return Promise.resolve('mocked_pulsar_message_id');
        }
      );
    }
  });

  afterAll(async () => {
    //
  });

  function mockRegisterOrganizationData(): RegisterOrganizationDto {
    return {
      code: faker.company.name(),
      description: faker.lorem.sentence(),
      externalId: faker.string.uuid(),
      name: faker.company.name(),
      status: OrganizationStatus.CREATED,
    };
  }

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  async function createMockOrganization(): Promise<OrganizationModel> {
    const org = await organizationsService.save(
      mockRegisterOrganizationData(),
      userDto
    );
    return Promise.resolve(org);
  }

  function mockRegisterUserData(): RegisterUserDto {
    return {
      email: faker.internet.email(),
      externalId: faker.string.uuid(),
      externalRoleId: TestIds.ADMIN_USER_ROLE_ID,
      password: faker.internet.password(),
      permissions: {
        access: [],
        departments: [],
        functions: [],
        locations: [],
        systemId: 'msvc-cto-bo',
      },
      status: faker.helpers.arrayElement(Object.values(UserStatus)),
      userName: faker.internet.userName(),
    };
  }

  test('POST', async () => {
    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockRegisterUserData());

    logger.debug('register_user_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);
  });

  test('PATCH', async () => {
    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockRegisterUserData());

    logger.debug('register_user_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);

    const user = resp.body as UpdateUserRegistrationDto;
    Object.assign(user, {
      email: `updated.${user.email}`,
      password: faker.internet.password(),
    });

    user.email = `updated.${user.email}`;

    const respUpdate = await request(server)
      .patch('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(user);

    logger.debug('update_registered_user_test_result', {
      data: respUpdate.body,
    });

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.email).toBe(user.email);
  });

  test('PATCH STATUS INACTIVE', async () => {
    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockRegisterUserData());

    logger.debug('register_user_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);

    const url = `/v1/auth/user/${UserStatus.INACTIVE}/${resp.body.userName}`;

    const respUpdate = await request(server)
      .patch(url)
      .set({ Authorization: organization.externalId });

    logger.debug('update_registered_user_test_result', {
      data: respUpdate.body,
      url,
    });

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.status).toBe(UserStatus.INACTIVE);
  });

  test('PATCH STATUS ACTIVE', async () => {
    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockRegisterUserData());

    logger.debug('register_user_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(200);

    const url = `/v1/auth/user/${UserStatus.ACTIVE}/${resp.body.userName}`;

    const respUpdate = await request(server)
      .patch(url)
      .set({ Authorization: organization.externalId });

    logger.debug('update_registered_user_test_result', {
      data: respUpdate.body,
      url,
    });

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.status).toBe(UserStatus.ACTIVE);
  });

  test('POST GENERATE TOKEN', async () => {
    const mockUser = mockRegisterUserData();

    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockUser);

    expect(resp.statusCode).toBe(200);

    const body = {
      email: mockUser.email,
      host: faker.internet.domainName(),
    } as GenerateTokenDtoByEmail;

    const respUpdate = await request(server)
      .post('/v1/auth/user/generate-token')
      .set({ Authorization: organization.externalId })
      .send(body);

    logger.debug('generate_token_test_response', {
      data: respUpdate.body,
    });

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.valid).toBe(true);
    expect(respUpdate.body.token).not.toBeNull();
  });

  test('PATCH CHANGE PASSWORD BY TOKEN', async () => {
    const mockUser = mockRegisterUserData();

    const resp = await request(server)
      .post('/v1/auth/user')
      .set({ Authorization: organization.externalId })
      .send(mockUser);

    expect(resp.statusCode).toBe(200);

    const body = {
      email: mockUser.email,
      host: faker.internet.domainName(),
    } as GenerateTokenDtoByEmail;

    const respUpdate = await request(server)
      .post('/v1/auth/user/generate-token')
      .set({ Authorization: organization.externalId })
      .send(body);

    logger.debug('generate_token_test_response', {
      data: respUpdate.body,
    });

    expect(respUpdate.statusCode).toBe(200);
    expect(respUpdate.body.valid).toBe(true);
  });

  test('NOT AUTHORIZED', async () => {
    const resp = await request(server)
      .post('/v1/auth/organization')
      .send(mockRegisterUserData());

    logger.debug('register_user_test_result', { data: resp.body });

    expect(resp.statusCode).toBe(401);
  });
});
