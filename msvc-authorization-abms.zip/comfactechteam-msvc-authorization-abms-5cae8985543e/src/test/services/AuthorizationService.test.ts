import { DeepPartial } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { faker } from '@faker-js/faker';

import { appDataSource } from '../../datasource/config/database';
import { OrganizationModel } from '../../datasource/models/OrganizationModel';
import { SecurityLevelModel } from '../../datasource/models/SecurityLevelModel';
import { SystemSettingsModel } from '../../datasource/models/SystemSettingsModel';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import { TokenResultDto } from '../../dto/TokenResultDto';
import { RegisterUserDto } from '../../dto/UserDto';
import { GenerateTokenDto } from '../../dto/UserDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { UserStatus } from '../../enums/UserEnums';
import { AuthorizationService } from '../../services/AuthorizationService';
import { OrganizationService } from '../../services/OrganizationService';
import { SecurityLevelService } from '../../services/SecurityLevelService';
import { SystemSettingsService } from '../../services/SystemSettingsService';
import { UserService } from '../../services/UserService';
import { logger } from '../../utils/LoggerUtils';
import { ErrorKeyTypes } from '../../utils/StaticMessageCodeUtils';
import { TestIds } from '../SampleData';

describe('Test authorization service', () => {
  let organizationService!: OrganizationService;
  let userService!: UserService;
  let organization: OrganizationModel;
  let authorizationService!: AuthorizationService;
  let securityLevelService!: SecurityLevelService;
  let systemSettingsService!: SystemSettingsService;

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  const EMAIL = TestIds.TEST_EMAIL;
  const PASSWORD = 'MyStr0ngP@ssword123!!$$';

  beforeAll(async () => {
    await appDataSource.initialize();
    organizationService = Container.get(OrganizationService);
    userService = Container.get(UserService);
    authorizationService = Container.get(AuthorizationService);
    securityLevelService = Container.get(SecurityLevelService);
    systemSettingsService = Container.get(SystemSettingsService);

    if (!organization) {
      organization = await organizationService.save(
        mockOrganizationData(),
        userDto
      );
    }
  });

  afterAll(async () => {
    //
  });

  function mockOrganizationData(): DeepPartial<OrganizationModel> {
    const result = {
      code: faker.company.name(),
      email: faker.internet.email(),
      externalId: uuidv4(),
      name: faker.company.name(),
      status: OrganizationStatus.ACTIVE,
    };
    return result;
  }

  function mockPermissionData() {
    const permission = {
      access: ['person.*.*'],
      departments: [faker.string.uuid(), faker.string.uuid()],
      functions: [faker.string.uuid(), faker.string.uuid()],
      locations: [faker.string.uuid(), faker.string.uuid()],
      systemId: 'msvc-cto-bo',
    };
    return permission;
  }

  function mockRegisterUserData(): RegisterUserDto {
    const unique_email = `${uuidv4()}+${EMAIL}`;
    const result = {
      email: unique_email,
      externalId: uuidv4(),
      externalRoleId: TestIds.ADMIN_USER_ROLE_ID,
      password: PASSWORD,
      permissions: mockPermissionData(),
      status: UserStatus.ACTIVE,
      userName: unique_email,
    };
    return result;
  }

  function mockSecurityLevelData(): Partial<SecurityLevelModel> {
    const id = faker.string.uuid();
    return {
      configuration: {
        authentication: {
          login: {
            maxFailedLogin: 3,
            userLockTimeInMins: 60,
          },
          password: {
            allowSamePassword: false,
            allowSequentialCharacters: false,
            minPasswordLength: 8,
            requireLowercaseCharacter: false,
            requireNumber: true,
            requireSpecialCharacter: true,
            requireUppercaseCharacter: false,
          },
          session: {
            inactivityInMin: 240,
            loginSession: 1440,
          },
        },
        record: {
          recordLockTimeInMins: 30,
        },
      },
      createdById: TestIds.PERSON_ID,
      createdByName: 'Comfac Technology Options',
      externalId: id,
      externalOrgId: organization.externalId,
      id: id,
      name: 'High',
    };
  }
  function mockSystemSettingsData(): Partial<SystemSettingsModel> {
    return {
      createdByName: 'Comfac Technology Options',
      externalId: TestIds.SYSTEM_SETTINGS_ID,
      externalOrgId: organization.externalId,
      id: TestIds.SYSTEM_SETTINGS_ID,
      securityLevelId: TestIds.SECURITY_LEVEL_HIGH_ID,
    };
  }

  describe('Test authorization', () => {
    test('AUTHENTICATE RESET NOT REQUIRED', async () => {
      const registerUser = mockRegisterUserData();

      Object.assign(registerUser, {
        isFirstLogin: false,
      });

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const buff = Buffer.from(`${register.userName}:${PASSWORD}`);
      const base64_basic_credential = buff.toString('base64');

      const data = (await authorizationService.authenticate(
        base64_basic_credential
      )) as TokenResultDto;

      logger.debug('authenticate_service_test', { data });

      expect(data.refresh).not.toBeNull();
      expect(data.jwt).not.toBeNull();
      expect(data.isPasswordResetRequired).toBe(false);
      expect(data.resetPasswordLink).toBe('');
    });

    test('AUTHENTICATE RESET REQUIRED', async () => {
      const registerUser = mockRegisterUserData();

      Object.assign(registerUser, {
        isFirstLogin: true,
        requireThis: true,
        setPassword: true,
      });

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const buff = Buffer.from(`${register.userName}:${PASSWORD}`);
      const base64_basic_credential = buff.toString('base64');

      const data = (await authorizationService.authenticate(
        base64_basic_credential
      )) as TokenResultDto;

      logger.debug('authenticate_service_test', { data });

      expect(data.isPasswordResetRequired).toBe(true);
      expect(data.resetPasswordLink).not.toBeNull();
      expect(data.refresh).toBe('');
      expect(data.jwt).toBe('');
    });

    test('REFRESH TOKEN', async () => {
      const registerUser = mockRegisterUserData();

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const buff = Buffer.from(`${register.userName}:${PASSWORD}`);
      const base64_basic_credential = buff.toString('base64');

      const token = (await authorizationService.authenticate(
        base64_basic_credential
      )) as TokenResultDto;

      expect(token.refresh).not.toBeNull();
      expect(token.jwt).not.toBeNull();

      const refresh = await authorizationService.refreshSecurityToken(
        register.userName,
        token.refresh
      );

      expect(refresh.refresh).not.toBeNull();
      expect(refresh.jwt).not.toBeNull();
    });

    test('INVALID CREDENTIAL', async () => {
      const registerUser = mockRegisterUserData();

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const buff = Buffer.from(`${register.userName}:${PASSWORD}123`);
      const base64_basic_credential = buff.toString('base64');

      await expect(
        authorizationService.authenticate(base64_basic_credential)
      ).rejects.toThrow(ErrorKeyTypes.INVALID_USER_CREDENTIAL);
    });

    test('INVALID USER EMAIL', async () => {
      const registerUser = mockRegisterUserData();
      Object.assign(registerUser, {
        email: `${uuidv4()}+${registerUser.email}`,
      });

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const buff = Buffer.from(`123${register.userName}:${PASSWORD}`);
      const base64_basic_credential = buff.toString('base64');

      await expect(
        authorizationService.authenticate(base64_basic_credential)
      ).rejects.toThrow(ErrorKeyTypes.INVALID_USERNAME);
    });

    test('INVALID REFRESH TOKEN', async () => {
      await expect(
        authorizationService.refreshSecurityToken('some-user-name', 'asdasdasd')
      ).rejects.toThrow(ErrorKeyTypes.REFRESH_TOKEN_EXPIRED);
    });

    test('GET SYSTEM SETTINGS BY TOKEN', async () => {
      const createSecurityLevel = mockSecurityLevelData();
      const createSystemSettings = mockSystemSettingsData();
      createSystemSettings.securityLevelId = createSecurityLevel.id;

      await securityLevelService.save(createSecurityLevel, userDto);

      await systemSettingsService.save(createSystemSettings, userDto);

      const registerUser = mockRegisterUserData();

      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const response = await userService.generateResetPasswordToken({
        host: faker.internet.domainName(),
        userName: register.userName,
      } as GenerateTokenDto);

      expect(response.token).not.toBeNull();

      const configuration = await authorizationService.getSystemSettingsByToken(
        response?.token as string,
        register.userName
      );

      expect(configuration).not.toBeNull();
    });

    test('LOCKED USER', async () => {
      const registerUser = mockRegisterUserData();
      const register = await userService.register(
        organization.externalId,
        registerUser
      );

      const timeLock = new Date().getTime() + 60 * 60 * 1000;
      const response = await authorizationService.lockUser(
        register.userName,
        timeLock.toString()
      );

      expect(response).not.toBeNull();
    });
  });
});
