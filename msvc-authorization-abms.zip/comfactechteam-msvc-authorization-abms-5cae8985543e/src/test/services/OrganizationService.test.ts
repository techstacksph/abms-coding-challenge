import 'reflect-metadata';

import { Raw } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { faker } from '@faker-js/faker';

import { appDataSource } from '../../datasource/config/database';
import { OrganizationModel } from '../../datasource/models/OrganizationModel';
import { PageArg, SortDirection, SortingInfo } from '../../dto/PaginationDto';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { OrganizationService } from '../../services/OrganizationService';
import { logger } from '../../utils/LoggerUtils';
import { TestIds } from '../SampleData';

describe('Test organization service CRUD', () => {
  //

  let organizationService!: OrganizationService;

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  beforeAll(async () => {
    await appDataSource.initialize();
    organizationService = Container.get(OrganizationService);
  });

  afterAll(async () => {
    //
  });

  function mockOrganizationData(): OrganizationModel {
    const result = {
      code: `${uuidv4()}-${faker.company.name()}`,
      description: faker.lorem.sentence(),
      externalId: uuidv4(),
      name: faker.company.name(),
      status: OrganizationStatus.ACTIVE,
    };
    return result as OrganizationModel;
  }

  test('REGISTER', async () => {
    const org = mockOrganizationData();
    const save = await organizationService.register(
      org as OrganizationModel,
      userDto
    );
    expect(save).toMatchObject(org);
  });

  test('ACTIVATE', async () => {
    const org = mockOrganizationData();
    const register = await organizationService.register(org, userDto);
    const activated = await organizationService.activate(
      register.externalId,
      userDto
    );
    expect(activated.status).toBe(OrganizationStatus.ACTIVE);
  });

  test('DEACTIVATE', async () => {
    const org = mockOrganizationData();
    const register = await organizationService.register(org, userDto);
    const activated = await organizationService.deactivate(
      register.externalId,
      userDto
    );
    expect(activated.status).toBe(OrganizationStatus.INACTIVE);
  });

  test('CREATE', async () => {
    const save = (await organizationService.save(
      mockOrganizationData(),
      userDto
    )) as OrganizationModel;
    //console.dir(save, { depth: null });
    const find = await organizationService.findById(save.id);
    expect(save).toMatchObject(find as OrganizationModel);
  });

  test('UPDATE', async () => {
    const save = await organizationService.save(
      mockOrganizationData(),
      userDto
    );
    //console.dir(save, { depth: null });
    const update_data = Object.assign({}, save);
    Object.assign(update_data, {
      name: `${save.name} - UPDATED`,
    });
    await organizationService.update(save.id, update_data, userDto);
    const find = await organizationService.findById(save.id);
    expect(update_data).toMatchObject(find as OrganizationModel);
  });

  test('DELETE', async () => {
    const save = await organizationService.save(
      mockOrganizationData(),
      userDto
    );
    //console.dir(save, { depth: null });
    await organizationService.softRemove(save.id, userDto);
    const find = await organizationService.findById(save.id);
    expect(find).toBeNull();
  });

  test('FIND', async () => {
    await organizationService.save(mockOrganizationData(), userDto);

    for (let x = 0; x < 5; x++) {
      const mock_data = mockOrganizationData();
      Object.assign(mock_data, {
        name: `test+${mock_data.description}`,
      });
      await organizationService.save(mock_data, userDto);
    }

    const find = await organizationService.find({
      where: {
        description: Raw(
          (name) => `'LOWER(${name})' Like '%${'TEST+'.toLowerCase()}%'`
        ),
      },
    });

    //console.dir(find, { depth: null });
    expect(find.length).toBeLessThanOrEqual(5);
  });

  test('FIND AND COUNT', async () => {
    await organizationService.save(mockOrganizationData(), userDto);

    for (let x = 0; x < 5; x++) {
      const mock_data = mockOrganizationData();
      Object.assign(mock_data, {
        name: `TEST_PAGINATION+${mock_data.name}`,
      });
      await organizationService.save(mock_data, userDto);
    }

    const sort: SortingInfo[] = [];
    sort.push({ direction: SortDirection.asc, field: 'name' });
    sort.push({ direction: SortDirection.asc, field: 'code' });

    const pageArg: PageArg = {
      skip: 1,
      sort: sort,
      take: 3,
    };

    const result = await organizationService.findAndCount(pageArg, {
      where: {
        description: Raw(
          (name) =>
            `'LOWER(${name})' Like '%${'TEST_PAGINATION+'.toLowerCase()}%'`
        ),
      },
    });

    logger.debug('organization_test_pagination', { result });
    expect(result.pageInfo?.count).toBeLessThanOrEqual(5);
  });
});
