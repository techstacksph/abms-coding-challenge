import { DeepPartial } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';

import { faker } from '@faker-js/faker';

import { CompanySettingModel } from '../../datasource/models/CompanySettingModel';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import {
  CompanySettingsEmailSettings,
  CompanySettingsMailSender,
} from '../../enums/CompanySettingEnum';
import { CompanySettingService } from '../../services/CompanySettingService';
import { AppServerUtils } from '../../utils/TestUtils';
import { TestIds } from '../SampleData';

describe('COMPANY SETTINGS SERVICE TEST', () => {
  let appServer: AppServerUtils;
  let service: CompanySettingService;

  beforeAll(async () => {
    appServer = Container.get(AppServerUtils);
    await appServer.startServer();
    service = Container.get(CompanySettingService);
  });

  afterAll(async () => {
    await appServer.closeServer();
  });

  function mockCreateData(): DeepPartial<CompanySettingModel> {
    const externalId = faker.string.uuid();
    return {
      appPassword: faker.string.uuid(),
      autoReply: faker.internet.email(),
      emailSettings: CompanySettingsEmailSettings.OTHERS,
      externalId: externalId,
      mailHost: faker.internet.domainName(),
      mailPort: String(faker.internet.port()),
      mailSender: CompanySettingsMailSender.COMPANY_NAME,
      mailerAccount: faker.internet.email(),
    };
  }

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  test('CREATE COMPANY SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    const find = await service.findById(save.id);
    expect(save.id).toBe(find?.id);
  });

  test('UPDATE COMPANY SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    const update_data = Object.assign({}, save);
    const new_mailer_account = faker.internet.email();
    Object.assign(update_data, {
      mailerAccount: new_mailer_account,
    });
    await service.update(save.id, update_data, userDto);
    const find = await service.findById(save.id);
    expect(update_data.mailerAccount).toEqual(find?.mailerAccount);
  });

  test('DELETE COMPANY SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    await service.softRemove(save.id, userDto);
    const find = await service.findById(save.id);
    expect(find).toBeNull();
  });
});
