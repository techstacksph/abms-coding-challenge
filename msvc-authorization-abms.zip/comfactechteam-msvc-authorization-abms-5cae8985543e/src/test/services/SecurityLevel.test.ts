import 'reflect-metadata';

import { DeepPartial, Raw } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { faker } from '@faker-js/faker';

import { appDataSource } from '../../datasource/config/database';
import { OrganizationModel } from '../../datasource/models/OrganizationModel';
import { SecurityLevelModel } from '../../datasource/models/SecurityLevelModel';
import { PageArg, SortDirection, SortingInfo } from '../../dto/PaginationDto';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { OrganizationService } from '../../services/OrganizationService';
import { SecurityLevelService } from '../../services/SecurityLevelService';
import { TestIds } from '../SampleData';

describe('Test security level service CRUD', () => {
  let organizationService!: OrganizationService;
  let organization: OrganizationModel;
  let securityLevelService: SecurityLevelService;

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  beforeAll(async () => {
    await appDataSource.initialize();

    organizationService = Container.get(OrganizationService);
    securityLevelService = Container.get(SecurityLevelService);

    if (!organization) {
      organization = await organizationService.save(
        mockOrganizationData(),
        userDto
      );
    }
  });

  afterAll(async () => {
    await appDataSource.destroy();
  });

  function mockOrganizationData(): DeepPartial<OrganizationModel> {
    const result = {
      code: `${uuidv4()}-${faker.company.name()}`,
      email: faker.internet.email(),
      externalId: uuidv4(),
      name: faker.company.name(),
      status: OrganizationStatus.ACTIVE,
    };
    return result;
  }

  function mockCreateSecurityLevelData(): DeepPartial<SecurityLevelModel> {
    const result = {
      configuration: {
        authentication: {
          login: {
            maxFailedLogin: 5,
            userLockTimeInMins: 30,
          },
          password: {
            allowSamePassword: false,
            allowSequentialCharacters: false,
            minPasswordLength: 8,
            requireLowercaseCharacter: false,
            requireNumber: true,
            requireSpecialCharacter: true,
            requireUppercaseCharacter: false,
          },
          session: {
            inactivityInMin: 240,
            loginSession: 4320,
          },
        },
        record: {
          recordLockTimeInMins: 60,
        },
      },
      externalId: uuidv4(),
      externalOrgId: organization.externalId,
      name: faker.word.noun() + '-' + uuidv4(),
    };
    return result;
  }

  test('CREATE', async () => {
    const save = await securityLevelService.save(
      mockCreateSecurityLevelData(),
      userDto
    );
    const find = await securityLevelService.findById(save.id);
    expect(save.id).toEqual(find?.id);
  });

  test('UPDATE', async () => {
    const save = await securityLevelService.save(
      mockCreateSecurityLevelData(),
      userDto
    );
    const update_data = Object.assign({}, save);
    Object.assign(update_data, {
      name: `${save.name}-UPDATED`,
    });
    await securityLevelService.update(save.id, update_data, userDto);
    const find = await securityLevelService.findById(save.id);
    expect(update_data.name).toEqual(find?.name);
  });

  test('DELETE', async () => {
    const save = await securityLevelService.save(
      mockCreateSecurityLevelData(),
      userDto
    );
    await securityLevelService.softRemove(save.id, userDto);
    const find = await securityLevelService.findById(save.id);
    expect(find).toBeNull();
  });

  test('FIND', async () => {
    await securityLevelService.save(mockCreateSecurityLevelData(), userDto);
    for (let x = 0; x < 5; x++) {
      const mock_data = mockCreateSecurityLevelData();
      Object.assign(mock_data, {
        name: `test+${mock_data.name}`,
      });
      await securityLevelService.save(mock_data, userDto);
    }
    const find = await securityLevelService.find({
      relations: ['organization'],
      where: {
        name: Raw(
          (name) => `'LOWER(${name})' Like '%${'TEST+'.toLowerCase()}%'`
        ),
      },
    });

    //console.dir(find, { depth: null });
    expect(find).not.toBeNull();
  });

  test('FIND AND COUNT', async () => {
    await securityLevelService.save(mockCreateSecurityLevelData(), userDto);
    for (let x = 0; x < 5; x++) {
      const mock_data = mockCreateSecurityLevelData();
      Object.assign(mock_data, {
        email: `TEST_PAGINATION+${mock_data.name}`,
      });
      await securityLevelService.save(mock_data, userDto);
    }

    const sort: SortingInfo[] = [];
    sort.push({ direction: SortDirection.asc, field: 'name' });

    const pageArg: PageArg = {
      skip: 1,
      sort: sort,
      take: 3,
    };

    const find = await securityLevelService.findAndCount(pageArg, {
      relations: ['organization'],
      where: {
        name: Raw(
          (name) =>
            `'LOWER(${name})' Like '%${'TEST_PAGINATION+'.toLowerCase()}%'`
        ),
      },
    });

    //console.dir(find, { depth: null });
    expect(find.pageInfo?.count).toBeLessThanOrEqual(5);
  });
});
