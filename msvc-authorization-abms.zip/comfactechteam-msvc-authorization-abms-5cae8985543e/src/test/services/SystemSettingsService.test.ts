import { DeepPartial } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';

import { faker } from '@faker-js/faker';

import { SystemSettingsModel } from '../../datasource/models/SystemSettingsModel';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import { SystemSettingsService } from '../../services/SystemSettingsService';
import { AppServerUtils } from '../../utils/TestUtils';
import { TestIds } from '../SampleData';

describe('SYSTEM SETTINGS CONTROLLER TEST', () => {
  let appServer: AppServerUtils;
  let service: SystemSettingsService;

  beforeAll(async () => {
    appServer = Container.get(AppServerUtils);
    await appServer.startServer();
    service = Container.get(SystemSettingsService);
  });

  afterAll(async () => {
    await appServer.closeServer();
  });

  function mockCreateData(): DeepPartial<SystemSettingsModel> {
    const externalId = faker.string.uuid();
    return {
      externalId: externalId,
      externalOrgId: TestIds.ORGANIZATION_ID,
      securityLevelId: faker.string.uuid(),
    };
  }

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  test('CREATE SYSTEM SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    const find = await service.findById(save.id);
    expect(save.id).toBe(find?.id);
  });

  test('UPDATE SYSTEM SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    const update_data = Object.assign({}, save);
    const new_security_level_id = faker.string.uuid();
    Object.assign(update_data, {
      securityLevelId: new_security_level_id,
    });

    await service.update(save.id, update_data, userDto);
    const find = await service.findById(save.id);

    expect(update_data.securityLevelId).toEqual(find?.securityLevelId);
  });

  test('DELETE SYSTEM SETTINGS', async () => {
    const save = await service.save(mockCreateData(), userDto);
    await service.softRemove(save.id, userDto);
    const find = await service.findById(save.id);
    expect(find).toBeNull();
  });
});
