import 'reflect-metadata';

import { DeepPartial, Raw } from 'typeorm';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { faker } from '@faker-js/faker';

import { PulsarProducerClient } from '../../client/pulsar/producer/PulsarProducerClient';
import { appDataSource } from '../../datasource/config/database';
import { OrganizationModel } from '../../datasource/models/OrganizationModel';
import { UserModel } from '../../datasource/models/UserModel';
import { PageArg, SortDirection, SortingInfo } from '../../dto/PaginationDto';
import { RecordCUDDto } from '../../dto/RecordAuditDto';
import {
  ChangePasswordByTokenDto,
  GenerateTokenDto,
  RegisterUserDto,
} from '../../dto/UserDto';
import { OrganizationStatus } from '../../enums/OrganizationEnums';
import { UserStatus } from '../../enums/UserEnums';
import environment from '../../environment';
import { OrganizationService } from '../../services/OrganizationService';
import { UserService } from '../../services/UserService';
import { logger } from '../../utils/LoggerUtils';
import { TestIds } from '../SampleData';

describe('Test user service CRUD', () => {
  let organizationService!: OrganizationService;
  let userService!: UserService;
  let organization: OrganizationModel;

  const userDto: RecordCUDDto = {
    userId: TestIds.PERSON_ID,
    userName: TestIds.TEST_EMAIL,
  };

  beforeAll(async () => {
    await appDataSource.initialize();

    organizationService = Container.get(OrganizationService);
    userService = Container.get(UserService);

    if (!organization) {
      organization = await organizationService.save(
        mockOrganizationData(),
        userDto
      );
    }

    if (environment.NODE_ENV == 'test') {
      jest.mock('../../client/pulsar/producer/PulsarProducerClient');
      PulsarProducerClient.prototype.produce = jest.fn(
        (): Promise<string | null> => {
          return Promise.resolve('mocked_pulsar_message_id');
        }
      );
    }
  });

  afterAll(async () => {
    //
  });

  function mockOrganizationData(): DeepPartial<OrganizationModel> {
    const result = {
      code: `${uuidv4()}-${faker.company.name()}`,
      email: faker.internet.email(),
      externalId: uuidv4(),
      name: faker.company.name(),
      status: OrganizationStatus.ACTIVE,
    };
    return result;
  }

  function mockPermissionData() {
    const permission = {
      access: ['person.*.*'],
      departments: [faker.string.uuid(), faker.string.uuid()],
      functions: [faker.string.uuid(), faker.string.uuid()],
      locations: [faker.string.uuid(), faker.string.uuid()],
      systemId: 'msvc-cto-bo',
    };
    return permission;
  }

  function mockUserData(): DeepPartial<UserModel> {
    const result = {
      email: `${uuidv4()}+${faker.internet.email()}`,
      externalId: faker.string.uuid(),
      externalRoleId: TestIds.ADMIN_USER_ROLE_ID,
      organization: organization,
      passwordHash: faker.internet.password(),
      permissions: mockPermissionData(),
      status: UserStatus.ACTIVE,
      userName: faker.internet.userName(),
    };
    return result;
  }

  function mockRegisterUserData(): RegisterUserDto {
    const result = {
      email: `${uuidv4()}+${faker.internet.email()}`,
      externalId: uuidv4(),
      externalRoleId: TestIds.ADMIN_USER_ROLE_ID,
      password: faker.internet.password(),
      permissions: mockPermissionData(),
      status: UserStatus.ACTIVE,
      userName: faker.internet.userName(),
    };
    return result;
  }

  test('REGISTER', async () => {
    const registerUser = mockRegisterUserData();

    const register = await userService.register(
      organization.externalId,
      registerUser
    );
    const find = await userService.findById(register.id);

    expect(register.passwordHash).not.toEqual(registerUser.password);
    expect(register.passwordHash).toEqual(find?.passwordHash);
    expect(register.status).toEqual(UserStatus.ACTIVE);

    await expect(
      userService.register(`${uuidv4()}`, registerUser)
    ).rejects.toThrow();
  });

  test('ACTIVATE', async () => {
    const registerUser = mockRegisterUserData();

    const register = await userService.register(
      organization.externalId,
      registerUser
    );

    const activate = await userService.activate(register.userName);

    const find = await userService.findById(register.id);

    expect(register.status).toEqual(UserStatus.ACTIVE);
    expect(activate.status).toEqual(UserStatus.ACTIVE);
    expect(register.passwordHash).toEqual(find?.passwordHash);
  });

  test('DEACTIVATE', async () => {
    const registerUser = mockRegisterUserData();

    const register = await userService.register(
      organization.externalId,
      registerUser
    );

    const deactivatedUser = await userService.deactivate(register.userName);

    const find = await userService.findById(register.id);

    expect(deactivatedUser).toBeDefined();

    expect(register.status).toEqual(UserStatus.ACTIVE);
    expect(deactivatedUser?.status).toEqual(UserStatus.INACTIVE);
    expect(register.passwordHash).toEqual(find?.passwordHash);
  });

  test('GENERATE RESET PASSWORD TOKEN', async () => {
    const registerUser = mockRegisterUserData();

    const register = await userService.register(
      organization.externalId,
      registerUser
    );

    const response = await userService.generateResetPasswordToken({
      host: faker.internet.domainName(),
      userName: register.userName,
    } as GenerateTokenDto);

    expect(response.valid).toBe(true);
  });

  test('CHANGE PASSWORD BY TOKEN', async () => {
    const registerUser = mockRegisterUserData();

    const register = await userService.register(
      organization.externalId,
      registerUser
    );
    logger.debug('registerOld', { register });

    const oldUserData = await userService.findById(register.id);

    const newPassword = faker.internet.password();

    const resetPasswordResponse = await userService.generateResetPasswordToken({
      host: faker.internet.domainName(),
      userName: register.userName,
    } as GenerateTokenDto);

    logger.debug('CHANGE PASSWORD BY TOKEN', { resetPasswordResponse });

    const changePasswordResponse = await userService.changePasswordByToken({
      password: newPassword,
      token: resetPasswordResponse.token,
      userName: registerUser.userName,
    } as ChangePasswordByTokenDto);

    const newUserData = await userService.findById(register.id);

    logger.debug('newUserData', { newUserData });

    expect(register.passwordHash).toEqual(oldUserData?.passwordHash);
    expect(oldUserData?.passwordHash).not.toEqual(newUserData?.passwordHash);
    expect(changePasswordResponse.valid).toBe(true);
  });

  test('CREATE', async () => {
    const save = await userService.save(mockUserData(), userDto);
    const find = await userService.findById(save.id);
    expect(save.id).toEqual(find?.id);
  });

  test('UPDATE', async () => {
    const save = await userService.save(mockUserData(), userDto);
    const update_data = Object.assign({}, save);
    Object.assign(update_data, {
      userName: `${save.userName}-UPDATED`,
    });
    await userService.update(save.id, update_data, userDto);
    const find = await userService.findById(save.id);
    expect(update_data.userName).toEqual(find?.userName);
  });

  test('DELETE', async () => {
    const save = await userService.save(mockUserData(), userDto);
    await userService.softRemove(save.id, userDto);
    const find = await userService.findById(save.id);
    expect(find).toBeNull();
  });

  test('FIND', async () => {
    await userService.save(mockUserData(), userDto);
    for (let x = 0; x < 5; x++) {
      const mock_data = mockUserData();
      Object.assign(mock_data, {
        email: `test+${mock_data.email}`,
      });
      await userService.save(mock_data, userDto);
    }
    const find = await userService.find({
      relations: ['organization'],
      where: {
        email: Raw(
          (email) => `'LOWER(${email})' Like '%${'TEST+'.toLowerCase()}%'`
        ),
      },
    });

    //console.dir(find, { depth: null });
    expect(find).not.toBeNull();
  });

  test('FIND AND COUNT', async () => {
    await userService.save(mockUserData(), userDto);
    for (let x = 0; x < 5; x++) {
      const mock_data = mockUserData();
      Object.assign(mock_data, {
        email: `TEST_PAGINATION+${mock_data.email}`,
      });
      await userService.save(mock_data, userDto);
    }

    const sort: SortingInfo[] = [];
    sort.push({ direction: SortDirection.asc, field: 'userName' });
    sort.push({ direction: SortDirection.asc, field: 'email' });

    const pageArg: PageArg = {
      skip: 1,
      sort: sort,
      take: 3,
    };

    const find = await userService.findAndCount(pageArg, {
      relations: ['organization'],
      where: {
        email: Raw(
          (email) =>
            `'LOWER(${email})' Like '%${'TEST_PAGINATION+'.toLowerCase()}%'`
        ),
      },
    });

    //console.dir(find, { depth: null });
    expect(find.pageInfo?.count).toBeLessThanOrEqual(5);
  });

  test('CHECK IS FIRST LOGIN', async () => {
    // PASSWORD RESET REQUIRED
    const userWithResetRequired = Object.assign(mockUserData(), {
      isFirstlogin: true,
    });
    const createUserWithResetRequired = await userService.save(
      userWithResetRequired,
      userDto
    );

    const checkLoginWithResetRequired = await userService.checkIsFirstLogin(
        createUserWithResetRequired
      ),
      { isPasswordResetRequired, resetPasswordLink } =
        checkLoginWithResetRequired;

    const userWithResetNotRequired = Object.assign(mockUserData(), {
      isFirstlogin: false,
    });
    const createUserWithResetNotRequired = await userService.save(
      userWithResetNotRequired,
      userDto
    );

    const checkLoginWithResetNotRequired = await userService.checkIsFirstLogin(
        createUserWithResetNotRequired
      ),
      isPasswordResetRequired1 =
        checkLoginWithResetNotRequired.isPasswordResetRequired,
      resetPasswordLink1 = checkLoginWithResetNotRequired.resetPasswordLink;

    expect(isPasswordResetRequired).toBe(true);
    expect(resetPasswordLink).not.toBeNull();

    expect(isPasswordResetRequired1).toBe(false);
    expect(resetPasswordLink1).toBeUndefined();
  });
});
