import { decrypt, encrypt, hash, validHash } from '../../utils/EncryptUtils';

describe('Test encrypt-utils', () => {
  const VALUE_TO_ENCRYPT = 'd2d7f2d0-aa53-11ec-b909-0242ac120002';

  test('ENCRYPT', () => {
    const encrypted = encrypt(VALUE_TO_ENCRYPT);
    expect(VALUE_TO_ENCRYPT).not.toBe(encrypted);
  });
  test('DENCRYPT', () => {
    const encrypted = encrypt(VALUE_TO_ENCRYPT);
    const decrypted = decrypt(encrypted);

    expect(VALUE_TO_ENCRYPT).not.toBe(encrypted);
    expect(decrypted).toBe(VALUE_TO_ENCRYPT);
  });

  test('HASH', async () => {
    const PASSWORD = 'My-Strong-P@ssw0rd';

    const hashed = await hash(PASSWORD);
    const isValid = await validHash(PASSWORD, hashed);
    const isNotValid = await validHash(PASSWORD + 'OTHER', hashed);

    expect(hashed).toBeDefined();
    expect(hashed).not.toBeNull();
    expect(isValid).toBe(true);
    expect(isNotValid).toBe(false);
  });
});
