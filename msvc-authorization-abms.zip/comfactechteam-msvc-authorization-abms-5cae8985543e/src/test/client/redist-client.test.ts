import { Container } from 'typeorm-typedi-extensions';

import { RedisClient } from '../../client/redis/RedisClient';

describe('Test Redis Client', () => {
  let redisClient: RedisClient;

  const KEY = 'MY_KEY_HERE';
  const VAL = 'MY_VAL_HERE_asdasdasd';

  beforeAll(async () => {
    redisClient = Container.get(RedisClient);
  });

  test('SET VALUE', async () => {
    for (let i = 0; i < 100; i++) {
      await redisClient.setValue(KEY, VAL);
    }

    const result = await redisClient.setValue(KEY, VAL);
    expect(result).toBe('OK');
  });

  test('GET VALUE', async () => {
    const val = await redisClient.getValue(KEY);
    expect(val).toBe(VAL);
  });
});
