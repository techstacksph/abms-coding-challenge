import 'reflect-metadata';

import { Service } from 'typedi';

import { RedisClient } from '../client/redis/RedisClient';
import { CompanySettingModel } from '../datasource/models/CompanySettingModel';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { logger } from '../utils/LoggerUtils';
import { CompanySettingService } from './CompanySettingService';
import { SystemSettingsService } from './SystemSettingsService';
import { UserService } from './UserService';

@Service()
export class CompanySettingConsumerService {
  constructor(
    private readonly companySettingService: CompanySettingService,
    private readonly userService: UserService,
    private readonly redisClient: RedisClient,
    private readonly systemSettingsService: SystemSettingsService
  ) {}
  async createOrUpdateCompanySettings(
    entity: CompanySettingModel
  ): Promise<boolean> {
    logger.info('pulsar_processor_create_update_company_settings', { entity });
    let result = false;

    const record = await this.companySettingService.findOne({
      order: { updatedAt: 'DESC' },
      where: { externalId: entity.externalId },
    });

    if (record) {
      const user = await this.userService.findOne({
        where: { externalId: entity.updatedById },
      });

      // Check if security level changed
      const oldSecurityLevelId = record.securityLevelId;
      const newSecurityLevelId = entity.securityLevelId;

      logger.info('company_settings_security_level_check', {
        oldSecurityLevelId,
        newSecurityLevelId,
        changed: oldSecurityLevelId !== newSecurityLevelId,
      });

      // Clear lock timeout cache and update systemsettings when security level changes
      if (oldSecurityLevelId !== newSecurityLevelId) {
        // Clear old security level cache
        if (oldSecurityLevelId) {
          const oldCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${oldSecurityLevelId}`;
          await this.redisClient.delValue(oldCacheKey);
          logger.info('lock_timeout_cache_cleared_old_security_level', {
            companySettingId: record.id,
            oldSecurityLevelId,
            cacheKey: oldCacheKey,
            reason: 'company_settings_security_level_changed',
          });
        }

        // Clear new security level cache (force fresh database read)
        if (newSecurityLevelId) {
          const newCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${newSecurityLevelId}`;
          await this.redisClient.delValue(newCacheKey);
          logger.info('lock_timeout_cache_cleared_new_security_level', {
            companySettingId: record.id,
            newSecurityLevelId,
            cacheKey: newCacheKey,
            reason: 'company_settings_security_level_changed',
          });
        }

        // Update systemsettings table to keep security level in sync
        // RecordLockService reads from systemsettings table
        if (newSecurityLevelId) {
          try {
            // Find the single systemsettings record (one per organization)
            const allSystemSettings = await this.systemSettingsService.all();

            if (allSystemSettings.length > 0) {
              const systemSettings = allSystemSettings[0];
              const systemSettingsId = systemSettings.id;
              const externalOrgId = systemSettings.externalOrgId;

              // Fetch full entity, modify it, then save
              systemSettings.securityLevelId = newSecurityLevelId;
              await this.systemSettingsService.save(systemSettings, {
                userId: entity.updatedById,
                userName: user?.userName,
              });

              logger.info('system_settings_security_level_synced', {
                systemSettingsId,
                oldSecurityLevelId,
                newSecurityLevelId,
                reason: 'company_settings_security_level_changed',
              });

              // Clear the system settings cache in Redis
              if (externalOrgId) {
                const systemSettingsCacheKey = `${RedisEntryNames.REDIS_SYSTEM_SETTINGS}_${externalOrgId}`;
                await this.redisClient.delValue(systemSettingsCacheKey);
                logger.info('system_settings_cache_cleared', {
                  externalOrgId,
                  cacheKey: systemSettingsCacheKey,
                  reason: 'security_level_synced',
                });
              }
            }
          } catch (error) {
            logger.error('system_settings_sync_error', {
              error: (error as Error).message,
              newSecurityLevelId,
            });
            // Don't fail the company setting update if system settings sync fails
          }
        }
      }

      const updateCompanySetting = await this.companySettingService.update(
        record.id,
        entity,
        {
          userId: entity.updatedById,
          userName: user?.userName,
        }
      );

      logger.info('pulsar_processor_update_company_setting_result', {
        updateCompanySetting,
      });

      // Clear Redis cache after successful update to ensure fresh credentials
      // Since CompanySettingModel doesn't have orgId, we need to scan for all SESSION_CONFIG:* keys
      if (updateCompanySetting) {
        try {
          const cacheKeys =
            await this.redisClient.scanKeys('SESSION_CONFIG:*');

          if (cacheKeys.length > 0) {
            for (const cacheKey of cacheKeys) {
              await this.redisClient.delValue(cacheKey);
              logger.info('company_settings_cache_cleared', {
                cacheKey,
                reason: 'company_settings_updated_via_pulsar',
              });
            }
          } else {
            logger.info('no_company_settings_cache_found', {
              message: 'No cache keys found to clear',
            });
          }
        } catch (error) {
          logger.error('company_settings_cache_clear_failed', {
            error: error instanceof Error ? error.message : 'Unknown error',
          });
          // Don't throw - cache clearing failure shouldn't break the update
        }
      }

      result = true;
    } else {
      const user = await this.userService.findOne({
        where: { externalId: entity.createdById },
      });

      const createCompanySetting = await this.companySettingService.save(
        entity,
        {
          userId: entity.createdById,
          userName: user?.userName,
        }
      );

      logger.info('pulsar_processor_create_company_setting_result', {
        createCompanySetting,
      });

      // Clear Redis cache after successful creation to ensure fresh credentials
      // Since CompanySettingModel doesn't have orgId, we need to scan for all SESSION_CONFIG:* keys
      if (createCompanySetting) {
        try {
          const cacheKeys =
            await this.redisClient.scanKeys('SESSION_CONFIG:*');

          if (cacheKeys.length > 0) {
            for (const cacheKey of cacheKeys) {
              await this.redisClient.delValue(cacheKey);
              logger.info('company_settings_cache_cleared', {
                cacheKey,
                reason: 'company_settings_created_via_pulsar',
              });
            }
          } else {
            logger.info('no_company_settings_cache_found', {
              message: 'No cache keys found to clear',
            });
          }
        } catch (error) {
          logger.error('company_settings_cache_clear_failed', {
            error: error instanceof Error ? error.message : 'Unknown error',
          });
          // Don't throw - cache clearing failure shouldn't break the creation
        }
      }
    }

    return Promise.resolve(result);
  }
}
