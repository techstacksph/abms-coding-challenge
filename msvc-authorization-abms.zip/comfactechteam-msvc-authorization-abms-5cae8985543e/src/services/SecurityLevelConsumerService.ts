import 'reflect-metadata';

import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';

import { RedisClient } from '../client/redis/RedisClient';
import { SecurityLevelModel } from '../datasource/models/SecurityLevelModel';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { logger } from '../utils/LoggerUtils';
import { SecurityLevelService } from './SecurityLevelService';
import { UserService } from './UserService';

@Service()
export class SecurityLevelConsumerService {
  constructor(private redisClient: RedisClient) {}
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async createOrUpdateSecurityLevel(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_create_update_securityLevel');
    let result = false;
    const service: SecurityLevelService = Container.get(SecurityLevelService);
    const userService: UserService = Container.get(UserService);

    const entity = data as SecurityLevelModel;

    const record = await service.findOne({
      where: { externalId: entity.id },
    });

    if (record) {
      logger.info('pulsar_processor_update_securityLevel', {
        internalId: record.id,
        externalId: data.id,
        name: data.name,
        oldConfiguration: JSON.stringify(record.configuration),
        newConfiguration: JSON.stringify(data.configuration),
        oldRecordLockTime: record.configuration?.record?.recordLockTimeInMins,
        newRecordLockTime: data.configuration?.record?.recordLockTimeInMins,
      });

      const user = await userService.findOne({
        where: { externalId: data.updatedBy },
      });

      await service.update(
        record.id,
        {
          configuration: data.configuration,
          externalId: data.id,
          externalOrgId: data.orgId,
          name: data.name,
        } as SecurityLevelModel,
        { userId: data.updatedBy, userName: user?.userName }
      );

      // Clear lock timeout cache when security level is updated
      const lockTimeoutCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${record.id}`;
      await this.redisClient.delValue(lockTimeoutCacheKey);
      logger.info('lock_timeout_cache_cleared', {
        securityLevelId: record.id,
        securityLevelName: data.name,
        cacheKey: lockTimeoutCacheKey,
        reason: 'security_level_updated',
        newRecordLockTimeInMins:
          data.configuration?.record?.recordLockTimeInMins,
      });

      result = true;
    } else {
      logger.debug('pulsar_processor_create_securityLevel', { entity });

      const user = await userService.findOne({
        where: { externalId: data.createdBy },
      });

      await service.save(
        {
          configuration: data.configuration,
          externalId: data.id,
          externalOrgId: data.orgId,
          name: data.name,
        } as SecurityLevelModel,
        { userId: data.createdBy, userName: user?.userName }
      );
      result = true;
    }

    return Promise.resolve(result);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async deleteSecurityLevel(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_delete_securityLevel');
    let result = false;
    const service: SecurityLevelService = Container.get(SecurityLevelService);
    const userService: UserService = Container.get(UserService);

    const securityLevel = await service.findOne({
      where: { externalId: data.id },
    });

    if (securityLevel) {
      logger.debug('pulsar_processor_delete_securityLevel', { securityLevel });

      const user = await userService.findOne({
        where: { externalId: data.deletedBy },
      });

      await service.softRemove(securityLevel.id, {
        userId: data.deletedBy,
        userName: user?.userName,
      });
      result = true;
    }

    return Promise.resolve(result);
  }
}
