import 'reflect-metadata';

import { Request } from 'express';
import { Service } from 'typedi';

import environment from '../environment';
import { logger } from '../utils/LoggerUtils';
import { OrganizationService } from './OrganizationService';

@Service()
export class AuthenticateRequestService {
  constructor(private readonly organizationService: OrganizationService) {}

  async authenticate(req: Request): Promise<{
    USER_ID?: string;
    STATUS_CODE: number;
    STATUS_DESCRIPTION: string;
    VALID: boolean;
    IS_SYSTEM_ADMIN: boolean;
    SYSTEM_ADMIN_SECRET?: string;
  }> {
    if (this.isSecureUrl(req.url) && !req.headers.authorization) {
      logger.debug(`authorization_not_found`, { url: req.url });

      return {
        IS_SYSTEM_ADMIN: false,
        STATUS_CODE: 401,
        STATUS_DESCRIPTION: 'AUTHORIZATION_NOT_FOUND',
        SYSTEM_ADMIN_SECRET: undefined,
        USER_ID: undefined,
        VALID: false,
      };
    }

    if (
      req.url.includes('/auth/organization') &&
      req.headers.authorization &&
      req.headers.authorization == environment.SYSTEM_ADMIN_SECRET
    ) {
      return {
        IS_SYSTEM_ADMIN: true,
        STATUS_CODE: 200,
        STATUS_DESCRIPTION: 'USER_IS_SYSTEM_ADMIN',
        SYSTEM_ADMIN_SECRET: req.headers.authorization,
        USER_ID: req.headers.authorization,
        VALID: true,
      };
    } else if (
      req.url.includes('/auth/organization') &&
      req.headers.authorization &&
      req.headers.authorization != environment.SYSTEM_ADMIN_SECRET
    ) {
      logger.warn(`authorization_not_found`, { url: req.url });
      return {
        IS_SYSTEM_ADMIN: false,
        STATUS_CODE: 401,
        STATUS_DESCRIPTION: 'USER_IS_NOT_SYSTEM_ADMIN',
        SYSTEM_ADMIN_SECRET: undefined,
        USER_ID: req.headers.authorization,
        VALID: false,
      };
    }

    //  TODO: CHECK IF THE CLIENT KEY IS VALID, VALIDATE IN DATABASE OR REDIS

    if (req.headers.authorization) {
      const organization = await this.organizationService.findByExternalId(
        req.headers.authorization
      );
      if (organization) {
        return {
          IS_SYSTEM_ADMIN: false,
          STATUS_CODE: 200,
          STATUS_DESCRIPTION: 'USER_IS_ORGANIZATION',
          SYSTEM_ADMIN_SECRET: undefined,
          USER_ID: organization.externalId,
          VALID: true,
        };
      }
    }

    return {
      IS_SYSTEM_ADMIN: false,
      STATUS_CODE: 200,
      STATUS_DESCRIPTION: 'AUTHORIZATION_FOUND',
      SYSTEM_ADMIN_SECRET: undefined,
      USER_ID: req.headers.authorization ?? undefined,
      VALID: true,
    };
  }

  isSecureUrl(url: string): boolean {
    if (
      url.includes('/auth/') ||
      (url.includes('/authenticate/') && !url.includes('/authenticate/refresh'))
    ) {
      return true;
    } else {
      return false;
    }
  }
}
