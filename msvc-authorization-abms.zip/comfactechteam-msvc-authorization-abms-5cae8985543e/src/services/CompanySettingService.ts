import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { CompanySettingModel } from '../datasource/models/CompanySettingModel';
import { RecordCUDDto } from '../dto/RecordAuditDto';
import { ModelName } from '../enums/ModelObjectEnums';
import { friendlyError } from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { BaseService } from './BaseService';
import { UserService } from './UserService';

@Service()
export class CompanySettingService extends BaseService<
  CompanySettingModel,
  string
> {
  constructor(private userService: UserService) {
    const companySettingsRepository =
      appDataSource.getRepository(CompanySettingModel);
    super(companySettingsRepository, ModelName.COMPANY_SETTINGS);
  }

  async createOrUpdateCompanySettings(
    companySettings: CompanySettingModel
  ): Promise<CompanySettingModel> {
    try {
      const recordCUDDto: RecordCUDDto = {
        userId: companySettings.updatedById,
        userName: undefined,
      };

      let companySetting: CompanySettingModel | null = null;

      if (companySettings.externalId) {
        companySetting = await this.findOne({
          where: { externalId: companySettings.externalId },
        });
      }

      if (companySetting) {
        const updateCompanySetting = await this.update(
          companySetting.id,
          companySettings,
          recordCUDDto
        );

        logger.info('pulsar_processor_update_company_setting_result', {
          updateCompanySetting,
        });

        return updateCompanySetting as CompanySettingModel;
      } else {
        const user = await this.userService.findOne({
          where: { externalId: companySettings.createdById },
        });

        const createCompanySetting = await this.save(companySettings, {
          userId: companySettings.createdById,
          userName: user?.userName,
        });

        logger.info('pulsar_processor_create_company_setting_result', {
          createCompanySetting,
        });

        return createCompanySetting as CompanySettingModel;
      }
    } catch (error) {
      logger.info('error_updating_company_setting', { error });
      throw friendlyError(error, 'update_company_setting');
    }
  }
}
