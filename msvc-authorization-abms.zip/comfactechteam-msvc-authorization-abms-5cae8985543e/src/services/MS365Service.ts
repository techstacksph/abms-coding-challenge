import 'reflect-metadata';

import axios from 'axios';
import { Service } from 'typedi';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';

@Service()
export class MS365Service {
  constructor(private pulsarProducerClient: PulsarProducerClient) {}

  async getAccountDetails(token: string) {
    return await axios({
      headers: {
        Authorization: 'Bearer ' + token,
      },
      method: 'GET',
      url: 'https://graph.microsoft.com/v1.0/me',
    });
  }

  async createMicrosoftAccount(data: {
    accessToken?: string;
    email?: string;
    purpose?: string;
    refreshToken?: string;
    tokenExpirationDate?: Date;
  }) {
    await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
      action: PulsarDataAction.CREATE,
      data,
      objectName: 'microsoft_account',
      subAction: 'create_microsoft_account',
    });
  }

  async testSendMessage() {
    await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
      action: PulsarDataAction.UPDATE,
      data: {},
      objectName: 'microsoft_account',
      subAction: 'create_microsoft_account',
    });
  }
}
