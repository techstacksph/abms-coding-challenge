import 'reflect-metadata';

import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';

import { OrganizationModel } from '../datasource/models/OrganizationModel';
import { PulsarMessageDto } from '../dto/PulsarMessageDto';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { OrganizationStatus } from '../enums/OrganizationEnums';
import { logger } from '../utils/LoggerUtils';
import { CompanySettingConsumerService } from './CompanySettingConsumerService';
import { OrganizationService } from './OrganizationService';
import { RoleConsumerService } from './RoleConsumerService';
import { SecurityLevelConsumerService } from './SecurityLevelConsumerService';
import { SystemSettingsConsumerService } from './SystemSettingsConsumerService';
import { UserConsumerService } from './UserConsumerService';

@Service()
export class PulsarConsumerService {
  constructor(
    private readonly companySettingConsumerService: CompanySettingConsumerService,
    private readonly securityLevelConsumerService: SecurityLevelConsumerService,
    private readonly systemSettingConsumerService: SystemSettingsConsumerService,
    private readonly userConsumerService: UserConsumerService,
    private readonly roleConsumerService: RoleConsumerService
  ) {}

  async processMessage(message: PulsarMessageDto): Promise<boolean> {
    logger.info('pulsar_processor', { message });

    switch (message.objectName) {
      case 'user':
        if (message.action == PulsarDataAction.DELETE) {
          logger.error('soft remove user');
          return Promise.resolve(
            await this.userConsumerService.deleteUser(message.data)
          );
        } else if (
          message.action == PulsarDataAction.PROCESS &&
          message.subAction == 'send_reset_password'
        ) {
          await this.userConsumerService.sendResetPasswordToken(message.data);
        }
        break;
      case 'role':
        if (message.action == PulsarDataAction.DELETE) {
          await this.roleConsumerService.deleteRole(message.data);
        } else {
          await this.roleConsumerService.createOrUpdateRole(message.data);
        }
        break;
      case 'organization':
        return Promise.resolve(
          await this.createOrUpdateOrganization(message.data)
        );
      case 'securityLevel':
        switch (message.action) {
          case PulsarDataAction.CREATE:
          case PulsarDataAction.UPDATE:
            return Promise.resolve(
              await this.securityLevelConsumerService.createOrUpdateSecurityLevel(
                message.data
              )
            );
          case PulsarDataAction.DELETE:
            return Promise.resolve(
              await this.securityLevelConsumerService.deleteSecurityLevel(
                message.data
              )
            );
          default:
            break;
        }
        break;
      case 'systemsettings':
        switch (message.action) {
          case PulsarDataAction.UPDATE:
            return Promise.resolve(
              await this.systemSettingConsumerService.createOrUpdateSecurityLevel(
                message.data
              )
            );
          default:
            break;
        }
        break;
      case 'companysettings':
        await this.companySettingConsumerService.createOrUpdateCompanySettings(
          message.data
        );
        break;
      default:
        break;
    }

    return Promise.resolve(false);
  }

  // THIS CAN BE REFACTORED IN ITS OWN SERVICE FILE, THIS IS JUST A SAMPLE
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async createOrUpdateOrganization(data: any): Promise<boolean> {
    let result = false;
    const organizationService: OrganizationService =
      Container.get(OrganizationService);

    const entity = data as OrganizationModel;

    const org = await organizationService.findOne({
      where: { externalId: entity.id },
    });

    if (org) {
      await organizationService.update(
        org.id,
        {
          code: data.code,
          description: data.description,
          externalId: entity.id,
          name: data.name,
          status: OrganizationStatus.ACTIVE,
        } as OrganizationModel,
        { userId: entity.createdById, userName: entity.createdByName }
      );
      result = true;
    } else {
      await organizationService.save(
        {
          code: data.code,
          description: data.description,
          externalId: entity.id,
          name: data.name,
          status: OrganizationStatus.ACTIVE,
        } as OrganizationModel,
        {
          userId: entity.createdById,
          userName: entity.createdByName,
        }
      );
      result = true;
    }
    return Promise.resolve(result);
  }
}
