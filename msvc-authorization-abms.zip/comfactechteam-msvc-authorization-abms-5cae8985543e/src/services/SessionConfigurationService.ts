import 'reflect-metadata';

import { Service } from 'typedi';

import { RedisClient } from '../client/redis/RedisClient';
import { appDataSource } from '../datasource/config/database';
import { CompanySettingModel } from '../datasource/models/CompanySettingModel';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { logger } from '../utils/LoggerUtils';

export interface SessionConfig {
  inactivityTimeoutMin: number;
  sessionTimeoutMin: number;
  recordLockTimeMin: number;
}

@Service()
export class SessionConfigurationService {
  private readonly CACHE_TTL_SECONDS = 300; // 5 minutes

  constructor(private redisClient: RedisClient) {}

  /**
   * Get session configuration for an organization
   * Uses Redis cache with 5-minute TTL
   */
  async getSessionConfig(orgId: string): Promise<SessionConfig> {
    const cacheKey = `SESSION_CONFIG:${orgId}`;

    try {
      // Check cache first
      const cached = await this.redisClient.getValue(cacheKey);

      if (cached) {
        logger.info('session_config_cache_hit', { orgId });
        return JSON.parse(cached);
      }

      // Fetch from database
      logger.info('session_config_cache_miss', { orgId });
      const systemSettings = await appDataSource
        .getRepository(CompanySettingModel)
        .findOne({
          where: { externalOrgId: orgId },
          relations: ['securityLevel'],
        });

      logger.info('session_config_system_settings_find', { systemSettings });

      if (!systemSettings?.securityLevel?.configuration) {
        throw new Error(
          `Security level configuration not found for organization: ${orgId}`
        );
      }

      const { configuration } = systemSettings.securityLevel;

      const config: SessionConfig = {
        inactivityTimeoutMin:
          Number(configuration.authentication?.session?.inactivityInMin) || 240,
        sessionTimeoutMin:
          Number(configuration.authentication?.session?.loginSession) || 480,
        recordLockTimeMin:
          Number(configuration.record?.recordLockTimeInMins) || 120,
      };

      // Cache for 5 minutes
      await this.redisClient.setValue(
        cacheKey,
        JSON.stringify(config),
        this.CACHE_TTL_SECONDS
      );

      logger.info('session_config_loaded', { orgId, config });

      return config;
    } catch (error) {
      logger.error('session_config_error', {
        error: (error as Error).message,
        orgId,
      });
      throw error;
    }
  }

  /**
   * Invalidate cached session config for an organization
   * Call this when security level settings are updated
   */
  async invalidateCache(orgId: string): Promise<void> {
    const cacheKey = `SESSION_CONFIG:${orgId}`;

    try {
      await this.redisClient.delValue(cacheKey);
      logger.info('session_config_cache_invalidated', { orgId });
    } catch (error) {
      logger.error('session_config_invalidation_error', {
        error: (error as Error).message,
        orgId,
      });
    }
  }

  /**
   * Invalidate all cached session configs
   * Useful for maintenance or bulk security level updates
   */
  async invalidateAllCaches(): Promise<void> {
    try {
      // Note: This requires Redis SCAN which is not exposed in RedisClient
      // For now, we'll just log. In production, consider adding SCAN support
      logger.warn('invalidate_all_caches_not_implemented');
    } catch (error) {
      logger.error('session_config_invalidation_all_error', {
        error: (error as Error).message,
      });
    }
  }
}
