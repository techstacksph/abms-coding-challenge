import 'reflect-metadata';

import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { RedisClient } from '../client/redis/RedisClient';
import { appDataSource } from '../datasource/config/database';
import { UserModel } from '../datasource/models/UserModel';
import { FirstLoginDto } from '../dto/FirstLoginDto';
import { MailerOptionDto } from '../dto/MailerDto';
import { RecordCUDDto } from '../dto/RecordAuditDto';
import {
  ChangePasswordByTokenDto,
  ChangePasswordDto,
  GenerateTokenDto,
  GenerateTokenDtoByEmailAndLoginName,
  RegisterUserDto,
  UpdateUserRegistrationDto,
} from '../dto/UserDto';
import { UserRegistrationTokenDto } from '../dto/UserTokenDto';
import AppLogo from '../email/logos/AppLogo';
import NewUserLogo from '../email/logos/NewUserLogo';
import ResetPasswordLogo from '../email/logos/ResetPasswordLogo';
import ResetPasswordSuccessLogoNew from '../email/logos/ResetPasswordSuccessLogoNew';
import { DefaultResetPassword } from '../email/templates/DefaultResetPassword';
import { RequiredResetPassword } from '../email/templates/RequiredResetPassword';
import { ResetPasswordSuccess } from '../email/templates/ResetPasswordSuccess';
import { WelcomeWithPassword } from '../email/templates/WelcomeWithPassword';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { ModelName } from '../enums/ModelObjectEnums';
import { PulsarTopics } from '../enums/PulsarTopics';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { SystemUser, UserStatus } from '../enums/UserEnums';
import environment from '../environment';
import { hash, validHash } from '../utils/EncryptUtils';
import { friendlyError } from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { ErrorKeyTypes } from '../utils/StaticMessageCodeUtils';
import { createUrlWithProtocol } from '../utils/UrlUtils';
import { BaseService } from './BaseService';
import { OrganizationService } from './OrganizationService';
import { RoleService } from './RoleService';

export const PERMISSIONS = {
  access: [
    'organization.*.*',
    'function.*.*',
    'location.*.*',
    'department.*.*',
    'group.*.*',
    'securityLevel.*.*',
    'systemsettings.*.*',
    'country.*.*',
    'user.*.*',
    'usergroup.*.*',
    'module.*.*',
    'workflow.*.*',
    'workflowstatus.*.*',
    'workflowaction.*.*',
    'workflowprocess.*.*',
    'globalsearch.*.*',
    'timezone.*.*',
    'event.*.*',
    'eventwatcher.*.*',
    'eventassignee.*.*',
    'task.*.*',
    'taskassignee.*.*',
    'taskwatcher.*.*',
    'tasktype.*.*',
    'eventtype.*.*',
    'documenttype.*.*',
    'document.*.*',
    'userrole.*.*',
    'companies.*.*',
    'contact.*.*',
    'contacttype.*.*',
    'contactcompanies.*.*',
    'contactcontacttype.*.*',
    'site.*.*',
    'taskreccuring.*.*',
    'eventrecurring.*.*',
    'account.*.*',
    'industry.*.*',
    'dealtype.*.*',
    'source.*.*',
    'premisetype.*.*',
    'suppliertype.*.*',
    'breachtype.*.*',
    'leavetype.*.*',
    'trainingprogram.*.*',
    'warehouses.*.*',
    'variant.*.*',
    'pricelist.*.*',
    'positions.*.*',
    'unitofmeasure.*.*',
    'insurancetype.*.*',
    'item.*.*',
    'itemcategory.*.*',
    'itemsubcategory.*.*',
    'franchiseenotification.*.*',
    'ratingscale.*.*',
    'checklist.*.*',
    'franchiseenotificationrecipient.*.*',
    'securitychecktype.*.*',
    'sms.*.*',
    'deal.*.*',
    'contactaccount.*.*',
    'insurancedetail.*.*',
    'franchiseekit.*.*',
    'vehicle.*.*',
    'channel.*.*',
    'casetype.*.*',
    'case.*.*',
    'communicationlog.*.*',
    'quote.*.*',
    'note.*.*',
    'area.*.*',
    'securitycheck.*.*',
    'lead.*.*',
    'accountcode.*.*',
    'servicetype.*.*',
    'amendmenttype.*.*',
    'job.*.*',
    'jobschedule.*.*',
    'cancellationType.*.*',
    'jobpdf.*.*',
    'jobtransaction.*.*',
    'franchiseeagreement.*.*',
    'itemvarianttype.*.*',
    'training.*.*',
    'trainingprogramsection.*.*',
    'amendmentdetail.*.*',
    'trainingsectiondetails.*.*',
    'jobbilling.*.*',
    'franchiseeonboarding.*.*',
    'jobdetails.*.*',
    'jobspecification.*.*',
    'serviceproviderassignments.*.*',
    'onboardingchecklist.*.*',
    'jobtransfermovement.*.*',
    'itemtag.*.*',
    'qualityaudit.*.*',
    'qaarea.*.*',
    'leave.*.*',
    'qaspecification.*.*',
    'performancereview.*.*',
    'performancereviewquestion.*.*',
    'answer.*.*',
    'recruitment.*.*',
    'employee.*.*',
    'emergencycontact.*.*',
    'bankingdetails.*.*',
    'employementhistory.*.*',
    'industrystandardjobtitle.*.*',
    'nationality.*.*',
    'taxcodedeclarationdetails.*.*',
    'paydetails.*.*',
    'kiwisaverdetails.*.*',
    'warehouseitem.*.*',
    'agreementandcontract.*.*',
    'marketplace.*.*',
    'jobpurchase.*.*',
    'reviewperiod.*.*',
    'evaluation.*.*',
    'evaluationdetails.*.*',
    'documenttemplate.*.*',
    'questionnaire.*.*',
    'marketplacejobpurchase.*.*',
    'salesorder.*.*',
    'salesorderitem.*.*',
    'purchaseorder.*.*',
    'purchaseorderitem.*.*',
    'companysetting.*.*',
    'paymentterm.*.*',
    'invoice.*.*',
    'invoicetemplate.*.*',
    'bill.*.*',
    'billtemplate.*.*',
    'creditdebitnote.*.*',
    'royaltysheet.*.*',
    'pricelistitem.*.*',
    'deliveryandreturn.*.*',
    'actionplan.*.*',
    'question.*.*',
    'option.*.*',
    'faq.*.*',
    'course.*.*',
    'manual.*.*',
    'video.*.*',
    'moduleinfo.*.*',
    'testquestion.*.*',
    'test.*.*',
    'billtemplatedetail.*.*',
    'quotepdf.*.*',
    'billdetail.*.*',
    'xeroaccount.*.*',
    'notifandalert.*.*',
    'leadquestion.*.*',
    'testoption.*.*',
    'reviewperioddetails.*.*',
    'reviewperioddetailstodepartment.*.*',
    'reviewperioddetailstouser.*.*',
    'recruitmentquestionnaire.*.*',
    'invoicetemplatedetail.*.*',
    'supplierpricelist.*.*',
    'supplierpricelistitem.*.*',
    'testresult.*.*',
    'jobarea.*.*',
    'jobschedulelog.*.*',
    'dealtemplate.*.*',
    'dealtemplatedetail.*.*',
    'dealtemplatespecification.*.*',
    'preferredproducts.*.*',
    'leavebalance.*.*',
    'batchjobtransfer.*.*',
    'jobprocessing.*.*',
    'clienthubcommunication.*.*',
    'chcommunicationresponse.*.*',
    'accountproductfavorite.*.*',
    'invoice-job.*.*',
    'creditbureau.*.*',
    'jobforsale.*.*',
    'businessforsale.*.*',
    'microsoftaccount.*.*',
    'leavetypedetails.*.*',
    'creditdebitnotetoinvoice.*.*',
    'creditdebitnotetobill.*.*',
    'franchiseehub.*.*',
    'qarecurring.*.*'
  ],
  departments: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  functions: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  locations: ['3fa85f64-5717-4562-b3fc-2c963f66afa6'],
  systemId: 'abms',
};

@Service()
export class UserService extends BaseService<UserModel, string> {
  private readonly SYSTEM_PROCESS_USERNAME = 'SYSTEM_PROCESS';
  // THIS IS IN SEC 60 * 60 IS 1 HOUR
  private readonly TOKEN_EXPIRATION = 60 * 60;

  systemUserCUDDto: RecordCUDDto = {
    userName: SystemUser.userName,
  };

  constructor(
    private organizationService: OrganizationService,
    private redisClient: RedisClient,
    private pulsarProducerClient: PulsarProducerClient,
    private roleService: RoleService
  ) {
    const userRepository = appDataSource.getRepository(UserModel);
    super(userRepository, ModelName.USER);
  }

  async register(
    externalOrgId: string,
    registerUser: RegisterUserDto
  ): Promise<UserModel> {
    const org = await this.organizationService.findByExternalId(externalOrgId);
    const { setPassword, requireThis, password } = registerUser;

    if (!org) {
      throw new Error(ErrorKeyTypes.INVALID_CLIENT_KEY);
    }

    const recordCUDDto: RecordCUDDto = {
      userId: org.externalId,
      userName: org.name,
    };

    const user: UserModel = new UserModel();
    Object.assign(user, {
      ...registerUser,
      externalOrgId: org.externalId,
      isFirstlogin: requireThis ? true : false,
      permissions: PERMISSIONS,
    });

    Object.assign(user, {
      passwordHash: await hash(registerUser.password),
    });
    try {
      const newUser = await this.save(user, recordCUDDto);

      if (newUser) {
        // Get company settings from Redis cache
        let companySettings = await this.getCachedCompanySettings(
          newUser.externalOrgId
        );

        // If cache miss, request ABMS to refresh cache
        if (!companySettings) {
          logger.info('company_settings_cache_miss_requesting_refresh', {
            orgId: newUser.externalOrgId,
            message:
              'Company settings not in cache, requesting ABMS to refresh cache',
          });

          try {
            // Send cache refresh request to ABMS
            await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
              objectName: 'companysettings',
              action: PulsarDataAction.REFRESH_CACHE,
              subAction: 'refresh_cache',
              data: {
                orgId: newUser.externalOrgId,
                requestedBy: 'authorization-service',
                reason: 'user_registration_email',
              },
            });

            // Wait for cache to be refreshed (with timeout)
            await this.waitForCacheRefresh(newUser.externalOrgId, 5000);

            // Retry getting cache after refresh
            companySettings = await this.getCachedCompanySettings(
              newUser.externalOrgId
            );

            if (companySettings) {
              logger.info('company_settings_cache_refreshed_successfully', {
                orgId: newUser.externalOrgId,
                message: 'Cache refreshed successfully by ABMS',
              });
            } else {
              logger.warn(
                'company_settings_cache_still_missing_after_refresh',
                {
                  orgId: newUser.externalOrgId,
                  message:
                    'Cache still missing after refresh request, will use fallback credentials',
                }
              );
            }
          } catch (error) {
            logger.error('company_settings_cache_refresh_failed', {
              orgId: newUser.externalOrgId,
              error: error instanceof Error ? error.message : 'Unknown error',
              message:
                'Failed to refresh cache, will use fallback credentials for email',
            });
          }
        }

        // Build complete mailer credentials from cached company settings
        // If no company settings in cache, fetch from database
        const mailerCredentialOption = companySettings
          ? this.buildMailerCredentials(companySettings, newUser)
          : await this.buildFallbackMailerCredentialsFromDB(
              newUser.externalOrgId,
              newUser
            );

        logger.debug('set_password', { requireThis, setPassword });
        //WITH PASSWORD (RESET NOT REQUIRED)
        if (!requireThis && setPassword) {
          logger.debug('send_email_with_password_reset_not_required', {
            requireThis,
            setPassword,
          });
          const loginUrl = createUrlWithProtocol(
            '/login',
            environment.MAIN_APP_HOST_NAME
          );

          // Fetch role name from externalRoleId
          const role = await this.roleService.findOne({
            where: { externalId: user.externalRoleId },
          });
          const roleName = role?.name || 'Administrator';

          await this.pulsarProducerClient.produce(
            PulsarTopics.COMMUNICATION_MEDIA,
            {
              action: PulsarDataAction.PROCESS,
              data: {
                attachments: [
                  {
                    cid: 'app_logo',
                    content: AppLogo,
                    encoding: 'base64',
                  },
                  {
                    cid: 'new_user_logo',
                    content: NewUserLogo,
                    encoding: 'base64',
                  },
                ],
                content: WelcomeWithPassword(user, loginUrl, password, roleName),
                recipients: [user.email],
                replyTo:
                  (companySettings?.mailerAccount as string) ||
                  'no-reply@comfactechoptions.com',
                sender: this.resolveSenderName(companySettings, newUser),
                subject: 'Welcome to At Your Request!',
                mailerCredentialOption,
              } as MailerOptionDto,
              subAction: 'email',
            }
          );
        }
        //NO CUSTOM PASSWORD or
        //WITH PASSWORD BUT REQUIRED TO RESET
        else {
          const { url } = await this.generateResetPasswordToken({
            host: environment.MAIN_APP_HOST_NAME,
            userName: newUser.userName,
          });

          if (!url) {
            throw new Error(ErrorKeyTypes.SERVICE_ERROR);
          }

          logger.debug('send_email_with_password_reset', {
            requireThis,
            setPassword,
          });

          // Fetch role name from externalRoleId
          const role = await this.roleService.findOne({
            where: { externalId: user.externalRoleId },
          });
          const roleName = role?.name || 'Administrator';

          await this.pulsarProducerClient.produce(
            PulsarTopics.COMMUNICATION_MEDIA,
            {
              action: PulsarDataAction.PROCESS,
              data: {
                attachments: [
                  {
                    cid: 'app_logo',
                    content: AppLogo,
                    encoding: 'base64',
                  },
                  {
                    cid: 'new_user_logo',
                    content: NewUserLogo,
                    encoding: 'base64',
                  },
                ],
                content: RequiredResetPassword(
                  user,
                  url,
                  requireThis,
                  password,
                  roleName
                ),
                recipients: [user.email],
                replyTo:
                  (companySettings?.mailerAccount as string) ||
                  'no-reply@comfactechoptions.com',
                sender: this.resolveSenderName(companySettings, newUser),
                subject: 'Welcome to At Your Request!',
                mailerCredentialOption,
              } as MailerOptionDto,
              subAction: 'email',
            }
          );
        }
      }
      logger.debug('register_newUser', { newUser });

      return newUser;
    } catch (error) {
      throw friendlyError(error, 'register_user');
    }
  }

  async updateUserRegistration(
    externalOrgId: string,
    userInfo: UpdateUserRegistrationDto
  ): Promise<UserModel> {
    const org = await this.organizationService.findByExternalId(externalOrgId);

    if (!org) {
      throw new Error(ErrorKeyTypes.INVALID_CLIENT_KEY);
    }

    const recordCUDDto: RecordCUDDto = {
      userId: org.externalId,
      userName: org.name,
    };

    let user: UserModel | null = null;

    if (!userInfo.externalId) {
      user = await this.findClientUserByUserName(userInfo.userName);
    } else {
      user = await this.findOne({ where: { externalId: userInfo.externalId } });
    }

    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USER_EMAIL);
    }

    const raw_password = userInfo.password;
    delete userInfo.password;

    Object.assign(user, {
      ...userInfo,
      externalOrgId: org.externalId,
    });

    if (raw_password) {
      const passwordHash = await hash(raw_password);
      Object.assign(user, {
        passwordHash,
      });
    }

    try {
      const updateUser = await this.update(user.id, user, recordCUDDto);

      if (updateUser) {
        // Only destroy cache if password was changed
        if (raw_password) {
          await this.destroyUserLoginCache(user.userName.toString());
        } else {
          // Update the Redis cache with new user data without destroying token
          await this.updateUserLoginCache(user);
        }
        await this.destroyResetPasswordTokenCache(user.userName.toString());
        return user;
      } else {
        throw new Error(ErrorKeyTypes.FAILURE_UPDATING_USER);
      }
    } catch (error) {
      throw friendlyError(error, 'update_user');
    }
  }

  async changePassword(
    externalOrgId: string,
    userInfo: ChangePasswordDto
  ): Promise<{ valid: boolean }> {
    const org = await this.organizationService.findByExternalId(externalOrgId);

    if (!org) {
      throw new Error(ErrorKeyTypes.INVALID_CLIENT_KEY);
    }

    const recordCUDDto: RecordCUDDto = {
      userId: org.externalId,
      userName: org.name,
    };

    const user: UserModel | null = await this.findClientUserByUserName(
      userInfo.userName
    );

    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USERNAME);
    }

    const raw_password = userInfo.password;

    const isValidHash = await validHash(
      userInfo.oldPassword,
      user.passwordHash
    );

    if (!isValidHash) {
      throw new Error(ErrorKeyTypes.OLD_PASSWORD_MISMATCH);
    }

    if (raw_password) {
      const passwordHash = await hash(raw_password);
      Object.assign(user, {
        passwordHash,
      });
    }

    try {
      const updateUser = await this.update(user.id, user, recordCUDDto);
      if (updateUser) {
        // Get company settings from Redis cache
        let companySettings = await this.getCachedCompanySettings(
          user.externalOrgId
        );

        // If cache miss, request ABMS to refresh cache
        if (!companySettings) {
          logger.info('company_settings_cache_miss_requesting_refresh', {
            orgId: user.externalOrgId,
            message:
              'Company settings not in cache, requesting ABMS to refresh cache',
          });

          try {
            // Send cache refresh request to ABMS
            await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
              objectName: 'companysettings',
              action: PulsarDataAction.REFRESH_CACHE,
              subAction: 'refresh_cache',
              data: {
                orgId: user.externalOrgId,
                requestedBy: 'authorization-service',
                reason: 'password_change_email',
              },
            });

            // Wait for cache to be refreshed (with timeout)
            await this.waitForCacheRefresh(user.externalOrgId, 5000);

            // Retry getting cache after refresh
            companySettings = await this.getCachedCompanySettings(
              user.externalOrgId
            );

            if (companySettings) {
              logger.info('company_settings_cache_refreshed_successfully', {
                orgId: user.externalOrgId,
                message: 'Cache refreshed successfully by ABMS',
              });
            } else {
              logger.warn(
                'company_settings_cache_still_missing_after_refresh',
                {
                  orgId: user.externalOrgId,
                  message:
                    'Cache still missing after refresh request, will use fallback credentials',
                }
              );
            }
          } catch (error) {
            logger.error('company_settings_cache_refresh_failed', {
              orgId: user.externalOrgId,
              error: error instanceof Error ? error.message : 'Unknown error',
              message:
                'Failed to refresh cache, will use fallback credentials for email',
            });
          }
        }

        // Build complete mailer credentials from cached company settings
        // If no company settings in cache, fetch from database
        const mailerCredentialOption = companySettings
          ? this.buildMailerCredentials(companySettings, updateUser)
          : await this.buildFallbackMailerCredentialsFromDB(
              updateUser.externalOrgId,
              updateUser
            );

        await this.pulsarProducerClient.produce(
          PulsarTopics.COMMUNICATION_MEDIA,
          {
            action: PulsarDataAction.PROCESS,
            data: {
              attachments: [
                {
                  cid: 'app_logo',
                  content: AppLogo,
                  encoding: 'base64',
                },
                {
                  cid: 'reset_password_logo',
                  content: ResetPasswordSuccessLogoNew,
                  encoding: 'base64',
                },
              ],
              content: ResetPasswordSuccess(updateUser),
              recipients: [updateUser.email],
              replyTo:
                (companySettings?.mailerAccount as string) ||
                'no-reply@comfactechoptions.com',
              sender: this.resolveSenderName(companySettings, updateUser),
              subject: 'At Your Request Password Successfully Changed',
              mailerCredentialOption,
            } as MailerOptionDto,
            subAction: 'email',
          }
        );

        await this.destroyUserLoginCache(user.userName.toString());
        await this.destroyResetPasswordTokenCache(user.userName.toString());

        return { valid: true };
      } else {
        throw new Error(ErrorKeyTypes.FAILURE_UPDATING_USER);
      }
    } catch (error) {
      throw friendlyError(error, 'change_password');
    }
  }

  async changePasswordByToken(
    userInfo: ChangePasswordByTokenDto
  ): Promise<{ valid: boolean }> {
    const raw_password = userInfo.password;

    const userRegistrationTokenName = `${RedisEntryNames.REDIS_USER_RESET_PASSWORD_TOKEN}_${userInfo.userName}`;
    const cacheRegistrationToken = (await this.redisClient.getValue(
      userRegistrationTokenName
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    )) as any;

    if (!cacheRegistrationToken) {
      throw new Error(ErrorKeyTypes.INVALID_REGISTRATION_TOKEN);
    }

    const cacheRegistrationTokenDto: UserRegistrationTokenDto = JSON.parse(
      cacheRegistrationToken
    );

    if (!(cacheRegistrationTokenDto.token_secret == userInfo.token)) {
      throw new Error(ErrorKeyTypes.INVALID_REGISTRATION_TOKEN);
    }

    const user: UserModel | null = await this.findClientUserByUserName(
      userInfo.userName
    );

    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USERNAME);
    }

    if (raw_password) {
      const passwordHash = await hash(raw_password);
      Object.assign(user, {
        passwordHash,
      });
    }

    if (user.isFirstlogin) {
      Object.assign(user, {
        isFirstlogin: false,
      });
    }

    try {
      const updateUser = await this.update(
        user.id,
        user,
        this.systemUserCUDDto
      );

      if (updateUser) {
        // Get company settings from Redis cache
        let companySettings = await this.getCachedCompanySettings(
          user.externalOrgId
        );

        // If cache miss, request ABMS to refresh cache
        if (!companySettings) {
          logger.info('company_settings_cache_miss_requesting_refresh', {
            orgId: user.externalOrgId,
            message:
              'Company settings not in cache, requesting ABMS to refresh cache',
          });

          try {
            // Send cache refresh request to ABMS
            await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
              objectName: 'companysettings',
              action: PulsarDataAction.REFRESH_CACHE,
              subAction: 'refresh_cache',
              data: {
                orgId: user.externalOrgId,
                requestedBy: 'authorization-service',
                reason: 'password_reset_confirmation_email',
              },
            });

            // Wait for cache to be refreshed (with timeout)
            await this.waitForCacheRefresh(user.externalOrgId, 5000);

            // Retry getting cache after refresh
            companySettings = await this.getCachedCompanySettings(
              user.externalOrgId
            );

            if (companySettings) {
              logger.info('company_settings_cache_refreshed_successfully', {
                orgId: user.externalOrgId,
                message: 'Cache refreshed successfully by ABMS',
              });
            } else {
              logger.warn(
                'company_settings_cache_still_missing_after_refresh',
                {
                  orgId: user.externalOrgId,
                  message:
                    'Cache still missing after refresh request, will use fallback credentials',
                }
              );
            }
          } catch (error) {
            logger.error('company_settings_cache_refresh_failed', {
              orgId: user.externalOrgId,
              error: error instanceof Error ? error.message : 'Unknown error',
              message:
                'Failed to refresh cache, will use fallback credentials for email',
            });
          }
        }

        // Build complete mailer credentials from cached company settings
        // If no company settings in cache, fetch from database
        const mailerCredentialOption = companySettings
          ? this.buildMailerCredentials(companySettings, updateUser)
          : await this.buildFallbackMailerCredentialsFromDB(
              updateUser.externalOrgId,
              updateUser
            );

        await this.pulsarProducerClient.produce(
          PulsarTopics.COMMUNICATION_MEDIA,
          {
            action: PulsarDataAction.PROCESS,
            data: {
              attachments: [
                {
                  cid: 'app_logo',
                  content: AppLogo,
                  encoding: 'base64',
                },
                {
                  cid: 'reset_password_logo',
                  content: ResetPasswordSuccessLogoNew,
                  encoding: 'base64',
                },
              ],
              content: ResetPasswordSuccess(updateUser),
              recipients: [updateUser.email],
              replyTo:
                (companySettings?.mailerAccount as string) ||
                'no-reply@comfactechoptions.com',
              sender: this.resolveSenderName(companySettings, updateUser),
              subject: 'At Your Request Password Successfully Changed',
              mailerCredentialOption,
            } as MailerOptionDto,
            subAction: 'email',
          }
        );

        await this.destroyUserLoginCache(userInfo.userName);
        await this.destroyResetPasswordTokenCache(userInfo.userName);

        return { valid: true };
      } else {
        throw new Error(ErrorKeyTypes.FAILURE_UPDATING_USER);
      }
    } catch (error) {
      throw friendlyError(error, 'change_password');
    }
  }

  async findClientUserByUserName(userName: string): Promise<UserModel | null> {
    const user = await this.findOne({
      relations: ['organization'],
      where: { userName },
    });
    return Promise.resolve(user ?? null);
  }

  async findClientUserByEmail(email: string): Promise<UserModel | null> {
    const user = await this.findOne({
      relations: ['organization'],
      where: { email },
    });
    return Promise.resolve(user ?? null);
  }

  async findClientUserByEmailAndLoginName(
    email: string,
    loginName: string
  ): Promise<UserModel | null> {
    const user = await this.findOne({
      relations: ['organization'],
      where: {
        email: email,
        userName: loginName,
      },
    });

    logger.info('find_client_user_by_email_and_login_name', { user });

    return Promise.resolve(user ?? null);
  }

  async findByUserName(userName: string): Promise<UserModel | null> {
    const user = await super.findOne({
      relations: ['organization'],
      where: { userName: userName },
    });
    logger.debug('find_user_by_username', { user });
    return Promise.resolve(user);
  }

  async generateResetPasswordToken(
    generateToken: GenerateTokenDto
  ): Promise<{ valid: boolean; token?: string; url?: string }> {
    const { host, userName } = generateToken;

    const user = await this.findClientUserByUserName(userName);

    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USERNAME);
    }

    const tokenSecret = uuidv4();

    const userRegistrationTokenDto = {
      token_secret: tokenSecret,
    } as UserRegistrationTokenDto;

    const userRegistrationToken = `${RedisEntryNames.REDIS_USER_RESET_PASSWORD_TOKEN}_${userName}`;

    await this.redisClient.delValue(userRegistrationToken);

    await this.redisClient.setValue(
      userRegistrationToken,
      JSON.stringify(userRegistrationTokenDto),
      this.TOKEN_EXPIRATION
    );

    const resetUrl = new URL(
      '/reset-password',
      host.startsWith('http') ? host : `https://${host}`
    );
    resetUrl.searchParams.set('token', tokenSecret);
    resetUrl.searchParams.set('userName', userName);
    resetUrl.searchParams.set(
      'expireAt',
      String(
        Date.parse(new Date().toISOString()) + this.TOKEN_EXPIRATION * 1000
      )
    );
    const url = resetUrl.toString();

    const result = {
      token: tokenSecret,
      url: url,
      valid: true,
    };

    return Promise.resolve(result);
  }

  async generateResetPasswordTokenAndEmail(
    generateToken: GenerateTokenDtoByEmailAndLoginName
  ): Promise<{ valid: boolean; token?: string }> {
    const { email, host, loginName } = generateToken;

    const user = await this.findClientUserByEmailAndLoginName(email, loginName);

    logger.info('password_reset_user_lookup', {
      requestedEmail: email,
      requestedLoginName: loginName,
      foundUser: !!user,
      userId: user?.id,
      userName: user?.userName,
      userEmail: user?.email,
      externalOrgId: user?.externalOrgId,
    });

    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USER_EMAIL);
    }

    // Get company settings from Redis cache
    let companySettings = await this.getCachedCompanySettings(
      user.externalOrgId
    );

    logger.info('password_reset_company_settings_lookup', {
      orgId: user.externalOrgId,
      companySettings: companySettings,
      foundInCache: !!companySettings,
      hasEmailSettings: !!companySettings?.emailSettings,
      emailSettings: companySettings?.emailSettings,
      hasTenantId: !!companySettings?.tenantId,
      hasClientId: !!companySettings?.clientId,
      hasClientSecret: !!companySettings?.clientSecret,
      hasLegacyOutlookTenantID: !!companySettings?.outlookTenantID,
      hasLegacyOutlookID: !!companySettings?.outlookID,
    });

    // If cache miss, request ABMS to refresh cache
    if (!companySettings) {
      logger.info('company_settings_cache_miss_requesting_refresh', {
        orgId: user.externalOrgId,
        message:
          'Company settings not in cache, requesting ABMS to refresh cache',
      });

      try {
        // Send cache refresh request to ABMS
        await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
          objectName: 'companysettings',
          action: PulsarDataAction.REFRESH_CACHE,
          subAction: 'refresh_cache',
          data: {
            orgId: user.externalOrgId,
            requestedBy: 'authorization-service',
            reason: 'forgot_password_email',
          },
        });

        // Wait for cache to be refreshed (with timeout)
        await this.waitForCacheRefresh(user.externalOrgId, 5000);

        // Retry getting cache after refresh
        companySettings = await this.getCachedCompanySettings(
          user.externalOrgId
        );

        if (companySettings) {
          logger.info('company_settings_cache_refreshed_successfully', {
            orgId: user.externalOrgId,
            message: 'Cache refreshed successfully by ABMS',
          });
        } else {
          logger.warn('company_settings_cache_still_missing_after_refresh', {
            orgId: user.externalOrgId,
            message:
              'Cache still missing after refresh request, will use fallback credentials',
          });
        }
      } catch (error) {
        logger.error('company_settings_cache_refresh_failed', {
          orgId: user.externalOrgId,
          error: error instanceof Error ? error.message : 'Unknown error',
          message:
            'Failed to refresh cache, will use fallback credentials for email',
        });
      }
    }

    const userPayload = {
      host: host,
      userName: user.userName,
    };
    const { url, token } = await this.generateResetPasswordToken(userPayload);

    if (!url) {
      throw new Error(ErrorKeyTypes.SERVICE_ERROR);
    }

    // Build complete mailer credentials from cached company settings
    // If no company settings in cache, fetch from database
    const mailerCredentialOption = companySettings
      ? this.buildMailerCredentials(companySettings, user)
      : await this.buildFallbackMailerCredentialsFromDB(user.externalOrgId, user);

    const result = {
      token: token,
      valid: true,
    };

    // LOG: Debug what's actually in mailerCredentialOption
    logger.info('password_reset_mailer_credentials_built', {
      orgId: user.externalOrgId,
      userEmail: user.email,
      usingFallback: !companySettings,
      hasMailerCredentialOption: !!mailerCredentialOption,
      smtpType: mailerCredentialOption?.smtpType,
      username: mailerCredentialOption?.username,
      hasM365: !!mailerCredentialOption?.m365,
      m365TenantId: (mailerCredentialOption?.m365 as Record<string, unknown>)?.tenantId,
      m365ClientId: (mailerCredentialOption?.m365 as Record<string, unknown>)?.clientId,
      m365ClientSecretLength: ((mailerCredentialOption?.m365 as Record<string, unknown>)?.clientSecret as string)?.length || 0,
      hasAccessToken: !!(
        mailerCredentialOption?.m365 as Record<string, unknown>
      )?.accessToken,
      hasRefreshToken: !!(
        mailerCredentialOption?.m365 as Record<string, unknown>
      )?.refreshToken,
    });

    await this.pulsarProducerClient.produce(PulsarTopics.COMMUNICATION_MEDIA, {
      action: PulsarDataAction.PROCESS,
      data: {
        attachments: [
          {
            cid: 'app_logo',
            content: AppLogo,
            encoding: 'base64',
          },
          {
            cid: 'reset_password_logo',
            content: ResetPasswordLogo,
            encoding: 'base64',
          },
        ],
        content: DefaultResetPassword(user, url),
        recipients: [user.email],
        replyTo:
          (companySettings?.mailerAccount as string) ||
          'no-reply@comfactechoptions.com',
        sender: this.resolveSenderName(companySettings, user),
        subject: 'Reset Password Request',
        mailerCredentialOption, // ✅ Complete company settings included
      } as MailerOptionDto,
      subAction: 'email',
    });

    return Promise.resolve(result);
  }

  async activate(userName: string): Promise<UserModel> {
    const user = await this.findClientUserByUserName(userName);
    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USERNAME);
    }

    const userDto: RecordCUDDto = { userName: this.SYSTEM_PROCESS_USERNAME };
    Object.assign(user, {
      status: UserStatus.ACTIVE,
    });

    try {
      const activate = await this.update(user.id, user as UserModel, userDto);
      if (activate) {
        return user;
      } else {
        throw new Error(ErrorKeyTypes.FAILURE_ACTIVATING_USER);
      }
    } catch (error) {
      throw friendlyError(error, 'activate_user');
    }
  }

  async deactivate(userName: string): Promise<UserModel | null> {
    const user = await this.findClientUserByUserName(userName);
    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USER_EMAIL);
    }

    Object.assign(user, {
      status: UserStatus.INACTIVE,
    });

    try {
      const userDto: RecordCUDDto = { userName: SystemUser.userName };
      const result = await this.update(user.id, user as UserModel, userDto);
      await this.destroyUserLoginCache(user.id.toString());
      return Promise.resolve(result);
    } catch (error) {
      throw friendlyError(error, 'activate_user');
    }
  }

  async destroyUserLoginCache(userName: string): Promise<boolean> {
    const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${userName}`;
    const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userName}`;
    this.redisClient.delValue(userRefreshPermissionName);
    this.redisClient.delValue(userLoginPermissionName);
    return true;
  }

  async updateUserLoginCache(user: UserModel): Promise<boolean> {
    const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${user.userName}`;

    // Get existing cache to preserve token_secret
    const existingCache = await this.redisClient.getValue(
      userLoginPermissionName
    );

    if (existingCache) {
      const cachedData = JSON.parse(existingCache);

      // Update only the profile fields, keep token_secret intact
      cachedData.firstName = user.firstName;
      cachedData.lastName = user.lastName;
      cachedData.email = user.email;

      // Get remaining TTL
      const ttl = await this.redisClient.getTTL(userLoginPermissionName);

      // Update cache with same expiration
      await this.redisClient.setValue(
        userLoginPermissionName,
        JSON.stringify(cachedData),
        ttl > 0 ? ttl : 60 * 60 * 24 * 5 // Use existing TTL or default
      );

      logger.debug('updated_user_login_cache', { userName: user.userName });
    }

    return true;
  }

  async destroyResetPasswordTokenCache(key: string): Promise<boolean> {
    const userRegistrationTokenName = `${RedisEntryNames.REDIS_USER_RESET_PASSWORD_TOKEN}_${key}`;
    await this.redisClient.delValue(userRegistrationTokenName);
    logger.debug('destroyed', { userRegistrationTokenName });
    return true;
  }

  // SEND RESET PASSWORD LINK IF isFirstlogin TRUE
  async checkIsFirstLogin(user: UserModel): Promise<FirstLoginDto> {
    const { isFirstlogin, userName } = user;

    const firstLoginUserData: FirstLoginDto = {
      isPasswordResetRequired: false,
    };

    if (isFirstlogin) {
      const tokenSecret = uuidv4();

      const userRegistrationTokenDto = {
        token_secret: tokenSecret,
      } as UserRegistrationTokenDto;

      const userRegistrationToken = `${RedisEntryNames.REDIS_USER_RESET_PASSWORD_TOKEN}_${userName}`;

      await this.redisClient.delValue(userRegistrationToken);

      await this.redisClient.setValue(
        userRegistrationToken,
        JSON.stringify(userRegistrationTokenDto),
        this.TOKEN_EXPIRATION
      );

      const resetPasswordUrl = new URL(
        '/reset-password',
        environment.MAIN_APP_HOST_NAME.startsWith('http')
          ? environment.MAIN_APP_HOST_NAME
          : `https://${environment.MAIN_APP_HOST_NAME}`
      );
      resetPasswordUrl.searchParams.set('token', tokenSecret);
      resetPasswordUrl.searchParams.set('userName', userName);
      resetPasswordUrl.searchParams.set(
        'expireAt',
        String(
          Date.parse(new Date().toISOString()) + this.TOKEN_EXPIRATION * 1000
        )
      );
      const url = resetPasswordUrl.toString();

      Object.assign(firstLoginUserData, {
        isPasswordResetRequired: true,
        resetPasswordLink: url,
      });
    }

    return Promise.resolve(firstLoginUserData);
  }

  private async getCompanySettingsFromCache(
    orgId: string
  ): Promise<Record<string, unknown> | null> {
    try {
      const cacheKey = `SESSION_CONFIG:${orgId}`;
      const cachedSettings = await this.redisClient.getValue(cacheKey);

      if (cachedSettings) {
        logger.info('company_settings_cache_hit', { orgId });
        return JSON.parse(cachedSettings);
      }

      logger.warn('company_settings_cache_miss', {
        orgId,
        message:
          'Company settings not found in cache, email will use fallback credentials',
      });
      return null;
    } catch (error) {
      logger.error('company_settings_cache_error', {
        orgId,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      return null;
    }
  }
  
  private async getCachedCompanySettings(
    orgId: string
  ): Promise<Record<string, unknown> | null> {
    try {
      const cacheKey = `COMPANY_SETTINGS:${orgId}`;
      const cachedSettings = await this.redisClient.getValue(cacheKey);

      if (cachedSettings) {
        logger.info('company_settings_cache_hit', { orgId });
        return JSON.parse(cachedSettings);
      }

      logger.warn('company_settings_cache_miss', {
        orgId,
        message:
          'Company settings not found in cache, email will use fallback credentials',
      });
      return null;
    } catch (error) {
      logger.error('company_settings_cache_error', {
        orgId,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      return null;
    }
  }

  /**
   * Wait for cache refresh to complete by polling Redis
   * Uses simple polling strategy with timeout
   */
  private async waitForCacheRefresh(
    orgId: string,
    timeoutMs: number
  ): Promise<boolean> {
    const startTime = Date.now();
    const pollInterval = 200; // Check every 200ms
    const cacheKey = `SESSION_CONFIG:${orgId}`;

    logger.info('waiting_for_cache_refresh', {
      orgId,
      timeoutMs,
      message: 'Polling Redis for cache refresh completion',
    });

    while (Date.now() - startTime < timeoutMs) {
      try {
        const cachedSettings = await this.redisClient.getValue(cacheKey);
        if (cachedSettings) {
          logger.info('cache_refresh_detected', {
            orgId,
            elapsedMs: Date.now() - startTime,
            message: 'Cache refresh completed successfully',
          });
          return true;
        }

        // Wait before next poll
        await new Promise((resolve) => setTimeout(resolve, pollInterval));
      } catch (error) {
        logger.warn('cache_refresh_poll_error', {
          orgId,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    logger.warn('cache_refresh_timeout', {
      orgId,
      timeoutMs,
      message: 'Cache refresh did not complete within timeout',
    });
    return false;
  }

  private buildMailerCredentials(
    companySettings: Record<string, unknown>,
    user: UserModel
  ): Record<string, unknown> {
    // Determine username based on email settings type
    // For Microsoft Outlook: use microsoftAccountEmail (OAuth account)
    // For SMTP (OTHERS): use mailerAccount (configured SMTP username)
    const username =
      companySettings.emailSettings === 'MICROSOFT_OUTLOOK'
        ? (companySettings.microsoftAccountEmail as string) ||
          (companySettings.mailerAccount as string)
        : (companySettings.mailerAccount as string) ||
          (companySettings.microsoftAccountEmail as string);

    let mailerCredentialOption: Record<string, unknown> = {
      username: username,
    };

    // Check if using Microsoft Outlook
    if (companySettings.emailSettings === 'MICROSOFT_OUTLOOK') {
      // First priority: Use cached Microsoft Account OAuth tokens if available
      if (
        companySettings.microsoftAccountAccessToken &&
        companySettings.microsoftAccountRefreshToken
      ) {
        mailerCredentialOption = {
          ...mailerCredentialOption,
          m365: {
            clientId: companySettings.clientId || companySettings.outlookID,
            clientSecret:
              companySettings.clientSecret || companySettings.outlookSecret,
            tenantId:
              companySettings.tenantId || companySettings.outlookTenantID,
            accessToken: companySettings.microsoftAccountAccessToken,
            refreshToken: companySettings.microsoftAccountRefreshToken,
          },
          smtpType: 'M365',
          username: companySettings.microsoftAccountEmail, // Use OAuth account email
        };

        logger.info('Using cached Microsoft OAuth tokens for email', {
          orgId: user.externalOrgId,
          accountEmail: companySettings.microsoftAccountEmail,
          hasAccessToken: !!companySettings.microsoftAccountAccessToken,
          tokenExpiry: companySettings.microsoftAccountTokenExpiry,
        });
      }
      // Second priority: Use manual M365 credentials from company settings
      else {
        // Check if we have M365 credentials (prefer new fields over legacy)
        const hasNewM365Fields =
          companySettings.tenantId &&
          companySettings.clientId &&
          companySettings.clientSecret;
        const hasLegacyM365Fields =
          companySettings.outlookTenantID &&
          companySettings.outlookID &&
          companySettings.outlookSecret;

        if (hasNewM365Fields) {
          mailerCredentialOption = {
            ...mailerCredentialOption,
            m365: {
              clientId: companySettings.clientId,
              clientSecret: companySettings.clientSecret,
              tenantId: companySettings.tenantId,
            },
            smtpType: 'M365',
          };

          logger.info(
            'Using new M365 credentials from company settings cache',
            {
              orgId: user.externalOrgId,
              tenantId: companySettings.tenantId,
            }
          );
        } else if (hasLegacyM365Fields) {
          mailerCredentialOption = {
            ...mailerCredentialOption,
            m365: {
              clientId: companySettings.outlookID,
              clientSecret: companySettings.outlookSecret,
              tenantId: companySettings.outlookTenantID,
            },
            smtpType: 'M365',
          };

          logger.info(
            'Using legacy M365 credentials from company settings cache',
            {
              orgId: user.externalOrgId,
              tenantId: companySettings.outlookTenantID,
            }
          );
        } else {
          logger.warn('no_microsoft_credentials_found_in_cache', {
            orgId: user.externalOrgId,
            message: 'No M365 credentials found, email may fail',
          });
          // Still set smtpType to M365 to match ABMS behavior
          mailerCredentialOption.smtpType = 'M365';
        }
      }
    } else {
      // SMTP configuration (same as ABMS)
      mailerCredentialOption = {
        ...mailerCredentialOption,
        host: companySettings.mailHost,
        port: Number(companySettings.mailPort),
        password: companySettings.appPassword,
        smtpType: companySettings.emailSettings,
      };

      logger.info('Using SMTP credentials from company settings cache', {
        orgId: user.externalOrgId,
        host: companySettings.mailHost,
        port: companySettings.mailPort,
      });
    }

    logger.info('mailer_credentials_built', {
      orgId: user.externalOrgId,
      emailSettings: companySettings.emailSettings,
      username: mailerCredentialOption.username,
      smtpType: mailerCredentialOption.smtpType,
      hasMicrosoftOAuthTokens: !!(
        companySettings.microsoftAccountAccessToken &&
        companySettings.microsoftAccountRefreshToken
      ),
    });

    return mailerCredentialOption;
  }

  /**
   * Build fallback mailer credentials by fetching from database
   * Used when company settings are not available in cache
   */
  private async buildFallbackMailerCredentialsFromDB(
    orgId: string,
    user: UserModel
  ): Promise<Record<string, unknown>> {
    logger.info('building_fallback_mailer_credentials_from_db', {
      message: 'Company settings not in cache, fetching from database',
      orgId,
    });

    try {
      // Fetch company settings from database using Container to avoid circular dependency
      const Container = require('typedi').Container;
      const CompanySettingService = require('./CompanySettingService').CompanySettingService;
      const companySettingService = Container.get(CompanySettingService);

      const companySettingFromDB = await companySettingService.findOne({
        where: { externalOrgId: orgId },
      });

      if (companySettingFromDB) {
        logger.info('company_settings_fetched_from_database', {
          orgId,
          hasEmailSettings: !!companySettingFromDB.emailSettings,
        });

        // Convert to plain object and build credentials
        const companySettings = {
          emailSettings: companySettingFromDB.emailSettings,
          mailerAccount: companySettingFromDB.mailerAccount,
          tenantId: companySettingFromDB.tenantId,
          clientId: companySettingFromDB.clientId,
          clientSecret: companySettingFromDB.clientSecret,
          mailHost: companySettingFromDB.mailHost,
          mailPort: companySettingFromDB.mailPort,
          appPassword: companySettingFromDB.appPassword,
          mailSender: companySettingFromDB.mailSender,
          customDisplayName: companySettingFromDB.customDisplayName,
          companyName: companySettingFromDB.companyName,
          outlookTenantID: companySettingFromDB.outlookTenantID,
          outlookID: companySettingFromDB.outlookID,
          outlookSecret: companySettingFromDB.outlookSecret,
        } as Record<string, unknown>;

        return this.buildMailerCredentials(companySettings, user);
      }

      logger.warn('company_settings_not_found_in_database', {
        orgId,
        message: 'Company settings not found in database, using system default',
      });
    } catch (error) {
      logger.error('failed_to_fetch_company_settings_from_database', {
        orgId,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }

    // Return system default that triggers fallback in communication service
    return {
      username: 'no-reply@comfactechoptions.com',
      smtpType: 'M365',
    };
  }

  private resolveSenderName(
    companySettings: Record<string, unknown> | null,
    user: UserModel
  ): string {
    if (!companySettings) {
      return 'no-reply@comfactechoptions.com';
    }

    // Resolve sender display name based on mailSender preference (same logic as ABMS)
    // Use correct email account based on email settings type
    const emailAccount =
      companySettings.emailSettings === 'MICROSOFT_OUTLOOK'
        ? (companySettings.microsoftAccountEmail as string) ||
          (companySettings.mailerAccount as string)
        : (companySettings.mailerAccount as string) ||
          (companySettings.microsoftAccountEmail as string);

    let resolvedSenderName: string =
      emailAccount || 'no-reply@comfactechoptions.com';

    if (companySettings.mailSender === 'COMPANY_NAME') {
      resolvedSenderName =
        (companySettings.companyName as string) ||
        emailAccount ||
        'no-reply@comfactechoptions.com';
    } else if (companySettings.mailSender === 'CURRENT_USER_NAME') {
      // For forgot password, we don't have current user context, use email account
      // This matches ABMS behavior in CommunicationLogSubscriber line 290
      resolvedSenderName = emailAccount || 'no-reply@comfactechoptions.com';
    } else if (companySettings.mailSender === 'CUSTOM_DISPLAY_NAME') {
      resolvedSenderName =
        (companySettings.customDisplayName as string) ||
        emailAccount ||
        'no-reply@comfactechoptions.com';
    }

    logger.info('sender_name_resolved', {
      orgId: user.externalOrgId,
      mailSender: companySettings.mailSender,
      customDisplayName: companySettings.customDisplayName,
      resolvedSenderName,
    });

    return resolvedSenderName;
  }
}
