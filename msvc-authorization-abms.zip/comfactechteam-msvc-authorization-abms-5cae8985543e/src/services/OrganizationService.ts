import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { OrganizationModel } from '../datasource/models/OrganizationModel';
import { RegisterOrganizationDto } from '../dto/OrganizationDto';
import { RecordCUDDto } from '../dto/RecordAuditDto';
import { ModelName } from '../enums/ModelObjectEnums';
import { OrganizationStatus } from '../enums/OrganizationEnums';
import { friendlyError } from '../utils/ExceptionUtils';
import { ErrorKeyTypes } from '../utils/StaticMessageCodeUtils';
import { BaseService } from './BaseService';

@Service()
export class OrganizationService extends BaseService<
  OrganizationModel,
  string
> {
  constructor() {
    const organizationRepository =
      appDataSource.getRepository(OrganizationModel);

    super(organizationRepository, ModelName.ORGANIZATION);
  }

  async register(
    org: OrganizationModel,
    userCUDDto: RecordCUDDto
  ): Promise<OrganizationModel> {
    try {
      const result = await this.save(org, userCUDDto);
      return result;
    } catch (error) {
      throw friendlyError(error, 'organization_register');
    }
  }

  async updateRegistration(
    org: RegisterOrganizationDto,
    userCUDDto: RecordCUDDto
  ): Promise<OrganizationModel> {
    const organization = await this.findOne({
      where: { externalId: org.externalId },
    });
    if (!organization) {
      throw new Error(ErrorKeyTypes.INVALID_EXTERNAL_ORGID);
    }

    Object.assign(organization, {
      ...org,
    });

    try {
      const result = await this.update(
        organization.id,
        organization,
        userCUDDto
      );
      if (result) {
        return organization;
      } else {
        throw new Error(ErrorKeyTypes.FAILURE_UPDATING_ORG);
      }
    } catch (error) {
      throw friendlyError(error, 'update_organization_registration');
    }
  }

  async activate(
    externalId: string,
    userCUDDto: RecordCUDDto
  ): Promise<OrganizationModel> {
    const organization = await this.findOne({
      where: { externalId: externalId },
    });

    if (!organization) {
      throw new Error(ErrorKeyTypes.INVALID_EXTERNAL_ORGID);
    }
    organization.status = OrganizationStatus.ACTIVE;

    try {
      await this.update(organization.id, organization, userCUDDto);
      return Promise.resolve(organization);
    } catch (error) {
      throw friendlyError(error, 'activate_organization');
    }
  }

  async deactivate(
    externalId: string,
    userCUDDto: RecordCUDDto
  ): Promise<OrganizationModel> {
    const organization = await this.findOne({
      where: { externalId: externalId },
    });

    if (!organization) {
      throw new Error(ErrorKeyTypes.INVALID_EXTERNAL_ORGID);
    }

    organization.status = OrganizationStatus.INACTIVE;

    try {
      await this.update(organization.id, organization, userCUDDto);
      return Promise.resolve(organization);
    } catch (error) {
      throw friendlyError(error, 'deactivate_organization');
    }
  }

  async findByExternalId(
    externalId: string
  ): Promise<OrganizationModel | null> {
    const result = await this.find({ where: { externalId } });
    if (result.length == 0) {
      return null;
    } else {
      return result[0];
    }
  }
}
