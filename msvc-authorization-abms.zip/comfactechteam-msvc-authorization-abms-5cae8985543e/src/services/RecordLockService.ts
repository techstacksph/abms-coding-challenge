import 'reflect-metadata';

import { Service } from 'typedi';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { RedisClient } from '../client/redis/RedisClient';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { logger } from '../utils/LoggerUtils';
import { SystemSettingsService } from './SystemSettingsService';

export interface RecordLockInfo {
  /**
   * Whether the record is locked
   */
  isLocked: boolean;

  /**
   * User ID who has the lock (if locked)
   */
  lockedBy?: string;

  /**
   * User's display name who has the lock (if locked)
   */
  lockedByName?: string;

  /**
   * When the lock expires (ISO timestamp)
   */
  expiresAt?: string;

  /**
   * Whether current user owns the lock
   */
  isOwnedByCurrentUser: boolean;

  /**
   * Lock acquisition timestamp
   */
  acquiredAt?: string;
}

export interface AcquireLockParams {
  recordType: string;
  recordId: string;
  userId: string;
  userName: string;
  orgId: string;
}

export interface ReleaseLockParams {
  recordType: string;
  recordId: string;
  userId: string;
  orgId: string;
}

export interface CheckLockParams {
  recordType: string;
  recordId: string;
  userId: string;
  orgId: string;
}

interface StoredLockData {
  userId: string;
  userName: string;
  orgId: string;
  recordType: string;
  recordId: string;
  acquiredAt: string;
  expiresAt: string;
}

@Service()
export class RecordLockService {
  // Default lock time: 30 minutes (fallback if security level not configured)
  private readonly DEFAULT_LOCK_TIME_SECONDS = 30 * 60;

  constructor(
    private redisClient: RedisClient,
    private pulsarClient: PulsarProducerClient,
    private systemSettingsService: SystemSettingsService
  ) {}

  /**
   * Generate Redis key for a record lock
   */
  private getLockKey(recordType: string, recordId: string): string {
    return `${RedisEntryNames.REDIS_RECORD_LOCK}_${recordType}_${recordId}`;
  }

  /**
   * Get lock timeout in seconds based on organization's security level
   * Uses Redis-cached system settings for fast retrieval, falls back to database if needed
   *
   * @param orgId - Organization ID
   * @returns Lock timeout in seconds
   */
  private async getLockTimeoutSeconds(orgId: string): Promise<number> {
    try {
      // Step 1: Check if system settings are cached in Redis (from Pulsar sync)
      const systemSettingsCacheKey = `${RedisEntryNames.REDIS_SYSTEM_SETTINGS}_${orgId}`;
      const cachedSystemSettings = await this.redisClient.getValue(
        systemSettingsCacheKey
      );

      let securityLevelId: string | null = null;

      if (cachedSystemSettings) {
        const parsedSettings = JSON.parse(cachedSystemSettings);
        securityLevelId = parsedSettings.securityLevelId;

        logger.info('system_settings_from_cache', {
          orgId,
          securityLevelId,
          cachedAt: parsedSettings.cachedAt,
        });
      } else {
        // Step 2: Cache miss - fetch from database
        const systemSettings = await this.systemSettingsService.findOne({
          where: { organization: { id: orgId } },
        });

        if (systemSettings?.securityLevelId) {
          securityLevelId = systemSettings.securityLevelId;

          logger.info('system_settings_from_database', {
            orgId,
            securityLevelId,
          });
        } else {
          logger.warn('system_settings_not_found', { orgId });
          return this.DEFAULT_LOCK_TIME_SECONDS;
        }
      }

      // Step 3: Get security level configuration (with separate cache)
      const lockTimeoutCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${securityLevelId}`;
      const cachedTimeout =
        await this.redisClient.getValue(lockTimeoutCacheKey);

      if (cachedTimeout) {
        const ttlSeconds = parseInt(cachedTimeout, 10);
        logger.info('lock_timeout_from_cache', {
          orgId,
          securityLevelId,
          ttlSeconds,
          ttlMinutes: ttlSeconds / 60,
          cacheKey: lockTimeoutCacheKey,
        });
        return ttlSeconds;
      }

      logger.info('lock_timeout_cache_miss', {
        orgId,
        securityLevelId,
        cacheKey: lockTimeoutCacheKey,
        message: 'Cache miss - fetching from database',
      });

      // Step 4: Fetch security level from database
      if (!securityLevelId) {
        logger.warn('security_level_id_missing', { orgId });
        return this.DEFAULT_LOCK_TIME_SECONDS;
      }

      const systemSettings = await this.systemSettingsService.findOne({
        where: { securityLevelId: securityLevelId },
        relations: ['securityLevel'],
      });

      logger.info('security_level_fetched', {
        orgId,
        securityLevelId,
        hasSecurityLevel: !!systemSettings?.securityLevel,
        securityLevelName: systemSettings?.securityLevel?.name,
        fullConfiguration: JSON.stringify(
          systemSettings?.securityLevel?.configuration
        ),
        recordLockConfig: systemSettings?.securityLevel?.configuration?.record,
        recordLockTimeInMins:
          systemSettings?.securityLevel?.configuration?.record
            ?.recordLockTimeInMins,
      });

      if (
        systemSettings?.securityLevel?.configuration?.record
          ?.recordLockTimeInMins
      ) {
        const lockTimeMinutes =
          systemSettings.securityLevel.configuration.record
            .recordLockTimeInMins;
        const ttlSeconds = lockTimeMinutes * 60;

        // Cache for 24 hours (security levels rarely change)
        await this.redisClient.setValue(
          lockTimeoutCacheKey,
          ttlSeconds.toString(),
          24 * 60 * 60
        );

        logger.info('lock_timeout_from_security_level', {
          orgId,
          securityLevelId,
          lockTimeMinutes,
          ttlSeconds,
          securityLevel: systemSettings.securityLevel.name,
          cacheKey: lockTimeoutCacheKey,
          cacheTTL: 24 * 60 * 60,
          message: 'Caching lock timeout for 24 hours',
        });

        return ttlSeconds;
      }

      logger.warn('lock_timeout_using_default', {
        orgId,
        securityLevelId,
        reason: 'Security level configuration not found',
      });
      return this.DEFAULT_LOCK_TIME_SECONDS;
    } catch (error) {
      logger.error('lock_timeout_fetch_error', {
        error: (error as Error).message,
        stack: (error as Error).stack,
        orgId,
      });
      return this.DEFAULT_LOCK_TIME_SECONDS;
    }
  }

  /**
   * Acquire a lock for a record
   *
   * @throws Error if lock is already held by another user
   */
  async acquireLock(params: AcquireLockParams): Promise<RecordLockInfo> {
    const { recordType, recordId, userId, userName, orgId } = params;
    const lockKey = this.getLockKey(recordType, recordId);

    try {
      // Check if lock already exists
      const existingLock = await this.checkLockStatus({
        recordType,
        recordId,
        userId,
        orgId,
      });

      if (existingLock.isLocked && !existingLock.isOwnedByCurrentUser) {
        logger.warn('lock_acquisition_failed_already_locked', {
          recordType,
          recordId,
          requestedBy: userId,
          lockedBy: existingLock.lockedBy,
        });

        throw new Error(
          `Record is already locked by ${
            existingLock.lockedByName || 'another user'
          }`
        );
      }

      // If user already owns the lock, just refresh the TTL
      if (existingLock.isLocked && existingLock.isOwnedByCurrentUser) {
        logger.info('lock_refreshed', {
          recordType,
          recordId,
          userId,
        });

        // Get lock timeout from security level
        const ttlSeconds = await this.getLockTimeoutSeconds(orgId);

        // Refresh TTL
        const lockData = await this.redisClient.getValue(lockKey);
        if (lockData) {
          const parsedData: StoredLockData = JSON.parse(lockData);
          parsedData.expiresAt = new Date(
            Date.now() + ttlSeconds * 1000
          ).toISOString();

          await this.redisClient.setValue(
            lockKey,
            JSON.stringify(parsedData),
            ttlSeconds
          );

          return {
            isLocked: true,
            lockedBy: userId,
            lockedByName: userName,
            expiresAt: parsedData.expiresAt,
            isOwnedByCurrentUser: true,
            acquiredAt: parsedData.acquiredAt,
          };
        }
      }

      // Get lock timeout from security level
      const ttlSeconds = await this.getLockTimeoutSeconds(orgId);

      const now = new Date();
      const expiresAt = new Date(now.getTime() + ttlSeconds * 1000);

      const lockData: StoredLockData = {
        userId,
        userName,
        orgId,
        recordType,
        recordId,
        acquiredAt: now.toISOString(),
        expiresAt: expiresAt.toISOString(),
      };

      // Store lock in Redis
      await this.redisClient.setValue(
        lockKey,
        JSON.stringify(lockData),
        ttlSeconds
      );

      logger.info('lock_acquired', {
        recordType,
        recordId,
        userId,
        userName,
        expiresAt: expiresAt.toISOString(),
      });

      // Emit audit event
      await this.emitAuditEvent('LOCK_ACQUIRED', lockData);

      return {
        isLocked: true,
        lockedBy: userId,
        lockedByName: userName,
        expiresAt: expiresAt.toISOString(),
        isOwnedByCurrentUser: true,
        acquiredAt: now.toISOString(),
      };
    } catch (error) {
      logger.error('lock_acquisition_error', {
        error: (error as Error).message,
        recordType,
        recordId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Release a lock for a record
   */
  async releaseLock(params: ReleaseLockParams): Promise<boolean> {
    const { recordType, recordId, userId } = params;
    const lockKey = this.getLockKey(recordType, recordId);

    try {
      // Check if lock exists
      const lockData = await this.redisClient.getValue(lockKey);

      if (!lockData) {
        logger.debug('lock_release_no_lock_exists', {
          recordType,
          recordId,
          userId,
        });
        return true; // Already released
      }

      const parsedData: StoredLockData = JSON.parse(lockData);

      // Verify user owns the lock
      if (parsedData.userId !== userId) {
        logger.warn('lock_release_unauthorized', {
          recordType,
          recordId,
          requestedBy: userId,
          lockedBy: parsedData.userId,
        });
        throw new Error('You do not own this lock');
      }

      // Delete the lock
      await this.redisClient.delValue(lockKey);

      logger.info('lock_released', {
        recordType,
        recordId,
        userId,
      });

      // Emit audit event
      await this.emitAuditEvent('LOCK_RELEASED', parsedData);

      return true;
    } catch (error) {
      logger.error('lock_release_error', {
        error: (error as Error).message,
        recordType,
        recordId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Check the current lock status for a record
   */
  async checkLockStatus(params: CheckLockParams): Promise<RecordLockInfo> {
    const { recordType, recordId, userId } = params;
    const lockKey = this.getLockKey(recordType, recordId);

    try {
      const lockData = await this.redisClient.getValue(lockKey);

      if (!lockData) {
        return {
          isLocked: false,
          isOwnedByCurrentUser: false,
        };
      }

      const parsedData: StoredLockData = JSON.parse(lockData);

      return {
        isLocked: true,
        lockedBy: parsedData.userId,
        lockedByName: parsedData.userName,
        expiresAt: parsedData.expiresAt,
        isOwnedByCurrentUser: parsedData.userId === userId,
        acquiredAt: parsedData.acquiredAt,
      };
    } catch (error) {
      logger.error('lock_status_check_error', {
        error: (error as Error).message,
        recordType,
        recordId,
        userId,
      });

      // On error, return unlocked state to allow operations to continue
      return {
        isLocked: false,
        isOwnedByCurrentUser: false,
      };
    }
  }

  /**
   * Force release a lock (admin operation)
   * Can be used to unlock records when users close browsers without releasing
   */
  async forceReleaseLock(
    recordType: string,
    recordId: string,
    adminUserId: string
  ): Promise<boolean> {
    const lockKey = this.getLockKey(recordType, recordId);

    try {
      const lockData = await this.redisClient.getValue(lockKey);

      if (!lockData) {
        return true;
      }

      const parsedData: StoredLockData = JSON.parse(lockData);

      await this.redisClient.delValue(lockKey);

      logger.warn('lock_force_released', {
        recordType,
        recordId,
        originalOwner: parsedData.userId,
        releasedBy: adminUserId,
      });

      // Emit audit event
      await this.emitAuditEvent('LOCK_FORCE_RELEASED', {
        ...parsedData,
        releasedBy: adminUserId,
      });

      return true;
    } catch (error) {
      logger.error('lock_force_release_error', {
        error: (error as Error).message,
        recordType,
        recordId,
        adminUserId,
      });
      throw error;
    }
  }

  /**
   * Get all active locks (for monitoring/debugging)
   */
  async getActiveLocks(filterOrgId: string): Promise<StoredLockData[]> {
    try {
      const pattern = `${RedisEntryNames.REDIS_RECORD_LOCK}_*`;
      const keys = await this.redisClient.scanKeys(pattern);

      const locks: StoredLockData[] = [];

      for (const key of keys) {
        const lockData = await this.redisClient.getValue(key);
        if (lockData) {
          const parsedData: StoredLockData = JSON.parse(lockData);
          if (parsedData.orgId === filterOrgId) {
            locks.push(parsedData);
          }
        }
      }

      logger.debug('active_locks_retrieved', {
        orgId: filterOrgId,
        count: locks.length,
      });

      return locks;
    } catch (error) {
      logger.error('get_active_locks_error', {
        error: (error as Error).message,
        orgId: filterOrgId,
      });
      return [];
    }
  }

  /**
   * Emit audit event for lock operations
   */
  private async emitAuditEvent(
    action: string,
    lockData: StoredLockData & { releasedBy?: string }
  ): Promise<void> {
    try {
      await this.pulsarClient.produce(PulsarTopics.BACK_OFFICE, {
        action: PulsarDataAction.UPDATE,
        objectName: 'record_lock',
        data: {
          action,
          recordType: lockData.recordType,
          recordId: lockData.recordId,
          userId: lockData.userId,
          userName: lockData.userName,
          orgId: lockData.orgId,
          timestamp: new Date().toISOString(),
          ...(lockData.releasedBy && { releasedBy: lockData.releasedBy }),
        },
      });
    } catch (error) {
      // Don't fail the lock operation if audit fails
      logger.error('lock_audit_event_error', {
        error: (error as Error).message,
        action,
        recordType: lockData.recordType,
        recordId: lockData.recordId,
      });
    }
  }
}
