import 'reflect-metadata';

import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';

import { RedisClient } from '../client/redis/RedisClient';
import { SystemSettingsModel } from '../datasource/models/SystemSettingsModel';
import { RedisEntryNames } from '../enums/RedisEntryName';
import { logger } from '../utils/LoggerUtils';
import { SystemSettingsService } from './SystemSettingsService';
import { UserService } from './UserService';

@Service()
export class SystemSettingsConsumerService {
  constructor(private redisClient: RedisClient) {}

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async createOrUpdateSecurityLevel(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_update_system_settings');
    let result = false;
    const service: SystemSettingsService = Container.get(SystemSettingsService);
    const userService: UserService = Container.get(UserService);

    const entity = data as SystemSettingsModel;

    const record = await service.findOne({
      where: { externalId: entity.id },
    });

    const recordData = {
      externalId: data.id,
      externalOrgId: data.orgId,
      securityLevelId: data.securityLevelId,
    } as SystemSettingsModel;

    if (record) {
      logger.info('pulsar_processor_update_systemSettings', {
        entity,
        oldSecurityLevelId: record.securityLevelId,
        newSecurityLevelId: data.securityLevelId,
      });

      const user = await userService.findOne({
        where: { externalId: data.updatedBy },
      });

      // Clear lock timeout cache for BOTH old and new security levels
      // when organization changes security level selection
      if (record.securityLevelId !== data.securityLevelId) {
        // Clear old security level cache
        if (record.securityLevelId) {
          const oldCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${record.securityLevelId}`;
          await this.redisClient.delValue(oldCacheKey);
          logger.info('lock_timeout_cache_cleared_old_security_level', {
            orgId: data.orgId,
            oldSecurityLevelId: record.securityLevelId,
            cacheKey: oldCacheKey,
            reason: 'organization_changed_security_level',
          });
        }

        // Clear new security level cache (to force fresh database read)
        if (data.securityLevelId) {
          const newCacheKey = `${RedisEntryNames.REDIS_LOCK_TIMEOUT_CONFIG}_${data.securityLevelId}`;
          await this.redisClient.delValue(newCacheKey);
          logger.info('lock_timeout_cache_cleared_new_security_level', {
            orgId: data.orgId,
            newSecurityLevelId: data.securityLevelId,
            cacheKey: newCacheKey,
            reason: 'organization_changed_security_level',
          });
        }
      }

      await service.update(record.id, recordData, {
        userId: data.updatedBy,
        userName: user?.userName,
      });
      result = true;
    } else {
      logger.debug('pulsar_processor_create_systemSettings', { entity });

      const user = await userService.findOne({
        where: { externalId: data.createdBy },
      });

      await service.save(recordData, {
        userId: data.createdBy,
        userName: user?.userName,
      });
      result = true;
    }

    // Cache system settings in Redis for fast retrieval by auth service
    if (result) {
      await this.cacheSystemSettings(data.orgId, data.securityLevelId);
    }

    return Promise.resolve(result);
  }

  /**
   * Cache system settings in Redis for fast retrieval
   * This eliminates the need for database queries when checking lock timeouts
   */
  private async cacheSystemSettings(
    orgId: string,
    securityLevelId: string
  ): Promise<void> {
    try {
      const cacheKey = `${RedisEntryNames.REDIS_SYSTEM_SETTINGS}_${orgId}`;
      const cacheData = {
        orgId,
        securityLevelId,
        cachedAt: new Date().toISOString(),
      };

      // Cache for 24 hours (system settings don't change frequently)
      const ttl = 24 * 60 * 60; // 24 hours in seconds
      await this.redisClient.setValue(cacheKey, JSON.stringify(cacheData), ttl);

      logger.info('system_settings_cached', {
        orgId,
        securityLevelId,
        cacheKey,
        ttl,
      });
    } catch (error) {
      logger.error('system_settings_cache_error', {
        error: (error as Error).message,
        orgId,
        securityLevelId,
      });
      // Don't fail the sync if caching fails
    }
  }
}
