import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { SystemSettingsModel } from '../datasource/models/SystemSettingsModel';
import { ModelName } from '../enums/ModelObjectEnums';
import { BaseService } from './BaseService';

@Service()
export class SystemSettingsService extends BaseService<
  SystemSettingsModel,
  string
> {
  constructor() {
    const repository = appDataSource.getRepository(SystemSettingsModel);
    super(repository, ModelName.SYSTEMSETTINGS);
  }
}
