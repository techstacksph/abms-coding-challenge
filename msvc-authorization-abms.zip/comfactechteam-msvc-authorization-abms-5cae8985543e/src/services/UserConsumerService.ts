import 'reflect-metadata';

import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';
import { v4 as uuidv4 } from 'uuid';

import { UserModel } from '../datasource/models/UserModel';
import { GenerateTokenDto, RegisterUserDto } from '../dto/UserDto';
import { UserStatus } from '../enums/UserEnums';
import { logger } from '../utils/LoggerUtils';
import { UserService } from './UserService';

@Service()
export class UserConsumerService {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async createOrUpdateUser(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_create_update_user');
    let result = false;
    const service: UserService = Container.get(UserService);

    const entity = data as UserModel;

    const record = await service.findOne({
      where: { userName: entity.userName },
    });

    if (record) {
      logger.debug('pulsar_processor_update_user', { entity });

      await service.update(
        record.id,
        {
          email: data.email,
          externalId: data.id,
          externalOrgId: data.orgId,
          externalRoleId: data.roleId,
          firstName: data.firstName,
          lastName: data.lastName,
          status: data.status,
          userName: data.userName,
        } as UserModel,
        { userId: entity.updatedById, userName: entity.updatedByName }
      );

      // Update login cache if user is logged in
      const updatedUser = await service.findOne({
        where: { userName: entity.userName },
      });
      if (updatedUser) {
        await service.updateUserLoginCache(updatedUser);
      }

      result = true;
    } else {
      logger.debug('pulsar_processor_create_user', { entity });

      await service.register(entity.externalOrgId, {
        email: data.email,
        externalId: data.id,
        externalOrgId: data.orgId,
        externalRoleId: data.roleId,
        firstName: data.firstName,
        lastName: data.lastName,
        password: data.password ?? uuidv4(),
        status: UserStatus.ACTIVE,
        userName: data.userName,
      } as RegisterUserDto);
      result = true;
    }

    return Promise.resolve(result);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async deleteUser(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_delete_user');
    let result = false;
    const service: UserService = Container.get(UserService);

    const userName = data.userName;

    const record = await service.findByUserName(userName);

    const user = await service.findOne({
      where: { id: data.deletedBy },
    });

    if (record) {
      logger.debug('pulsar_processor_delete_user', { record });

      await service.softRemove(record.id, {
        userId: data.deletedBy,
        userName: user?.userName,
      });
      result = true;
    }

    return Promise.resolve(result);
  }

  async sendResetPasswordToken(
    generateToken: GenerateTokenDto
  ): Promise<boolean> {
    const service: UserService = Container.get(UserService);
    await service.generateResetPasswordToken(generateToken);
    logger.debug('send_rest_password', { generateToken });
    return Promise.resolve(true);
  }
}
