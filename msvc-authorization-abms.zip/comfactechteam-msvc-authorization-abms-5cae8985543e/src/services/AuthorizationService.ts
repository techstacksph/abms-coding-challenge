import 'reflect-metadata';

import jwt from 'jsonwebtoken';
import { Service } from 'typedi';
import { v4 as uuidv4 } from 'uuid';

import { createId as cuid } from '@paralleldrive/cuid2';

import { PulsarProducerClient } from '../client/pulsar/producer/PulsarProducerClient';
import { RedisClient } from '../client/redis/RedisClient';
import { SystemSettingsModel } from '../datasource/models/SystemSettingsModel';
import { UserModel } from '../datasource/models/UserModel';
import { TokenResultDto } from '../dto/TokenResultDto';
import {
  RefreshTokenDto,
  UserIdentityPermission,
  UserRegistrationTokenDto,
  UserToken,
} from '../dto/UserTokenDto';
import { PulsarDataAction } from '../enums/DataActionEnum';
import { PulsarTopics } from '../enums/PulsarTopics';
import { RedisEntryNames } from '../enums/RedisEntryName';
import environment from '../environment';
import { validHash } from '../utils/EncryptUtils';
import { friendlyError } from '../utils/ExceptionUtils';
import { logger } from '../utils/LoggerUtils';
import { hasPermission } from '../utils/PermissionUtils';
import { ErrorKeyTypes } from '../utils/StaticMessageCodeUtils';
import { SessionConfigurationService } from './SessionConfigurationService';
import { SystemSettingsService } from './SystemSettingsService';
import { UserService } from './UserService';

@Service()
export class AuthorizationService {
  constructor(
    private userService: UserService,
    private redisClient: RedisClient,
    private systemSettingsService: SystemSettingsService,
    private pulsarProducerClient: PulsarProducerClient,
    private sessionConfigService: SessionConfigurationService
  ) {}

  async authenticate(
    tokenCredential: string,
    loginType: string = 'ADMIN',
    customTokenExpirationMin?: number
  ): Promise<TokenResultDto> {
    const buff = Buffer.from(tokenCredential, 'base64');
    const credential = buff.toString('ascii').split(':');

    if (credential.length < 2) {
      throw new Error(ErrorKeyTypes.INVALID_BASIC_CREDENTIAL_TOKEN);
    }

    const userName = credential[0],
      password = credential[1];

    const user = await this.userService.findByUserName(userName);
    if (!user) {
      throw friendlyError(
        new Error(ErrorKeyTypes.INVALID_USERNAME),
        'authenticate_user'
      );
    }

    // Validation based on login type
    if (loginType === 'FRANCHISEE') {
      // Check franchiseehub permission only
      const hasFranchiseeHubPermission = hasPermission(
        user.permissions,
        'franchiseehub'
      );

      if (!hasFranchiseeHubPermission) {
        throw friendlyError(
          new Error(ErrorKeyTypes.INSUFFICIENT_PERMISSIONS),
          'You do not have permission to access the franchisee hub'
        );
      }
    } else if (loginType === 'CLIENT') {
      // Check userType is CLIENT only
      if (user.userType !== 'CLIENT') {
        throw friendlyError(
          new Error(ErrorKeyTypes.USER_TYPE_MISMATCH),
          'This account cannot access the client hub'
        );
      }
    } else if (loginType === 'ADMIN') {
      // Block CLIENT users from logging into the main ABMS app
      if (user.userType === 'CLIENT') {
        throw friendlyError(
          new Error(ErrorKeyTypes.USER_TYPE_MISMATCH),
          'Client users cannot access the admin portal'
        );
      }
    }

    const result: TokenResultDto = {
      isPasswordResetRequired: false,
      jwt: '',
      refresh: '',
      resetPasswordLink: '',
    };

    const checkLogin = await this.userService.checkIsFirstLogin(user),
      { isPasswordResetRequired } = checkLogin;

    if (isPasswordResetRequired) {
      Object.assign(result, checkLogin);
    } else {
      const isValidPassword = await validHash(password, user.passwordHash);
      if (!isValidPassword) {
        throw friendlyError(
          new Error(ErrorKeyTypes.INVALID_USER_CREDENTIAL),
          'authenticate_user'
        );
      }

      // Determine token expiration: use custom value if provided, otherwise use session config
      let sessionTimeoutMin: number;

      if (
        customTokenExpirationMin !== undefined &&
        customTokenExpirationMin !== null
      ) {
        // Validate custom token expiration range (5 minutes to 35 days)
        if (customTokenExpirationMin < 5) {
          throw friendlyError(
            new Error(ErrorKeyTypes.INVALID_TOKEN_EXPIRATION),
            'Token expiration must be at least 5 minutes'
          );
        }
        if (customTokenExpirationMin > 50400) {
          // 35 days = 50400 minutes
          throw friendlyError(
            new Error(ErrorKeyTypes.INVALID_TOKEN_EXPIRATION),
            'Token expiration cannot exceed 35 days (50400 minutes)'
          );
        }

        // Use custom token expiration from parameter
        sessionTimeoutMin = customTokenExpirationMin;
        logger.info('using_custom_token_expiration', {
          customTokenExpirationMin,
          userId: user.id,
          userName: user.userName,
        });
      } else {
        // Fetch dynamic session configuration based on security level
        const sessionConfig = await this.sessionConfigService.getSessionConfig(
          user.organization.id
        );
        sessionTimeoutMin = sessionConfig.sessionTimeoutMin;
      }

      // Ensure sessionTimeoutMin is a valid number
      if (
        !sessionTimeoutMin ||
        isNaN(sessionTimeoutMin) ||
        sessionTimeoutMin <= 0
      ) {
        logger.error('invalid_session_timeout', {
          sessionTimeoutMin,
          userId: user.id,
          userName: user.userName,
        });
        throw friendlyError(
          new Error(ErrorKeyTypes.INVALID_TOKEN_EXPIRATION),
          'Session timeout configuration is invalid. Please contact your administrator.'
        );
      }

      const TOKEN_EXPIRATION = sessionTimeoutMin * 60; // Convert to seconds
      const JWT_EXPIRATION = `${sessionTimeoutMin}m`; // e.g., "480m"

      const token_secret = cuid();
      const userSecurityTokenDto: UserIdentityPermission = {
        email: user.email,
        external_id: user.externalId,
        external_orgid: user.organization.externalId,
        firstName: user.firstName,
        lastName: user.lastName,
        organization_id: user.organization.id,
        permission: user.permissions,
        token_secret: token_secret,
        user_id: user.id,
        user_name: user.userName,
        user_type: user.userType,
        account_id: user.accountId,
      };

      const userToken: UserToken = {
        token_secret: token_secret,
        user_name: user.userName,
        user_type: user.userType,
        account_id: user.accountId,
      };

      const token = jwt.sign(userToken, environment.JWT_SECRET_KEY, {
        expiresIn: JWT_EXPIRATION,
        issuer: environment.JWT_ISSUER,
      });

      const REFRESH_TOKEN_KEY = uuidv4();
      const refreshTokenDto: RefreshTokenDto = {
        external_user_id: user.externalId,
        token: token,
        token_key: REFRESH_TOKEN_KEY,
        user_id: user.id,
        user_name: user.userName,
      };

      const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${user.userType}_${user.userName}`;
      const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${user.userType}_${user.userName}`;

      await this.redisClient.delValue(userLoginPermissionName);
      await this.redisClient.delValue(userRefreshPermissionName);

      this.redisClient.setValue(
        userLoginPermissionName,
        JSON.stringify(userSecurityTokenDto),
        TOKEN_EXPIRATION
      );

      this.redisClient.setValue(
        userRefreshPermissionName,
        JSON.stringify(refreshTokenDto),
        TOKEN_EXPIRATION
      );

      // Initialize activity timestamp for inactivity tracking
      const activityKey = `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_${user.userType}_${user.userName}`;
      await this.redisClient.setValue(
        activityKey,
        Date.now().toString(),
        TOKEN_EXPIRATION
      );

      // SEND MESSAGE TO BO TO UPDATE LAST LOGIN DATE/TIME
      await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
        action: PulsarDataAction.UPDATE,
        data: {
          id: user.externalId,
          lastLoginDateTime: new Date(),
        },
        objectName: 'user',
      });

      Object.assign(result, {
        jwt: token,
        refresh: REFRESH_TOKEN_KEY,
      });
    }

    logger.debug('authenticate_result', result);

    return Promise.resolve(result);
  }

  async authenticateByEmail(
    tokenCredential: string,
    loginType: string = 'ADMIN',
    customTokenExpirationMin?: number
  ): Promise<TokenResultDto> {
    const buff = Buffer.from(tokenCredential, 'base64');
    const credential = buff.toString('ascii').split(':');

    if (credential.length < 2) {
      throw new Error(ErrorKeyTypes.INVALID_BASIC_CREDENTIAL_TOKEN);
    }

    const email = credential[0],
      password = credential[1];

    const user = await this.userService.findClientUserByEmail(email);
    if (!user) {
      throw friendlyError(
        new Error(ErrorKeyTypes.INVALID_USERNAME),
        'authenticate_user'
      );
    }

    // Validation based on login type
    if (loginType === 'FRANCHISEE') {
      // Check franchiseehub permission only
      const hasFranchiseeHubPermission = hasPermission(
        user.permissions,
        'franchiseehub'
      );

      if (!hasFranchiseeHubPermission) {
        throw friendlyError(
          new Error(ErrorKeyTypes.INSUFFICIENT_PERMISSIONS),
          'You do not have permission to access the franchisee hub'
        );
      }
    } else if (loginType === 'CLIENT') {
      // Check userType is CLIENT only
      if (user.userType !== 'CLIENT') {
        throw friendlyError(
          new Error(ErrorKeyTypes.USER_TYPE_MISMATCH),
          'This account cannot access the client hub'
        );
      }
    } else if (loginType === 'ADMIN') {
      // Block CLIENT users from logging into the main ABMS app
      if (user.userType === 'CLIENT') {
        throw friendlyError(
          new Error(ErrorKeyTypes.USER_TYPE_MISMATCH),
          'Client users cannot access the admin portal'
        );
      }
    }

    const result: TokenResultDto = {
      isPasswordResetRequired: false,
      jwt: '',
      refresh: '',
      resetPasswordLink: '',
    };

    const checkLogin = await this.userService.checkIsFirstLogin(user),
      { isPasswordResetRequired } = checkLogin;

    if (isPasswordResetRequired) {
      Object.assign(result, checkLogin);
    } else {
      const isValidPassword = await validHash(password, user.passwordHash);
      if (!isValidPassword) {
        throw friendlyError(
          new Error(ErrorKeyTypes.INVALID_USER_CREDENTIAL),
          'authenticate_user'
        );
      }

      // Determine token expiration: use custom value if provided, otherwise use session config
      let sessionTimeoutMin: number;

      if (
        customTokenExpirationMin !== undefined &&
        customTokenExpirationMin !== null
      ) {
        // Validate custom token expiration range (5 minutes to 35 days)
        if (customTokenExpirationMin < 5) {
          throw friendlyError(
            new Error(ErrorKeyTypes.INVALID_TOKEN_EXPIRATION),
            'Token expiration must be at least 5 minutes'
          );
        }
        if (customTokenExpirationMin > 50400) {
          // 35 days = 50400 minutes
          throw friendlyError(
            new Error(ErrorKeyTypes.INVALID_TOKEN_EXPIRATION),
            'Token expiration cannot exceed 35 days (50400 minutes)'
          );
        }

        // Use custom token expiration from parameter
        sessionTimeoutMin = customTokenExpirationMin;
        logger.info('using_custom_token_expiration', {
          customTokenExpirationMin,
          userId: user.id,
          userName: user.userName,
        });
      } else {
        // Fetch dynamic session configuration based on security level
        const sessionConfig = await this.sessionConfigService.getSessionConfig(
          user.organization.id
        );
        sessionTimeoutMin = sessionConfig.sessionTimeoutMin;
      }

      const TOKEN_EXPIRATION = sessionTimeoutMin * 60; // Convert to seconds
      const JWT_EXPIRATION = `${sessionTimeoutMin}m`; // e.g., "480m"

      const token_secret = cuid();
      const userSecurityTokenDto: UserIdentityPermission = {
        email: user.email,
        external_id: user.externalId,
        external_orgid: user.organization.externalId,
        firstName: user.firstName,
        lastName: user.lastName,
        organization_id: user.organization.id,
        permission: user.permissions,
        token_secret: token_secret,
        user_id: user.id,
        user_name: user.userName,
        user_type: user.userType,
        account_id: user.accountId,
      };

      const userToken: UserToken = {
        token_secret: token_secret,
        user_name: user.userName,
        user_type: user.userType,
        account_id: user.accountId,
      };

      const token = jwt.sign(userToken, environment.JWT_SECRET_KEY, {
        expiresIn: JWT_EXPIRATION,
        issuer: environment.JWT_ISSUER,
      });

      const REFRESH_TOKEN_KEY = uuidv4();
      const refreshTokenDto: RefreshTokenDto = {
        external_user_id: user.externalId,
        token: token,
        token_key: REFRESH_TOKEN_KEY,
        user_id: user.id,
        user_name: user.userName,
      };

      const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${user.userType}_${user.userName}`;
      const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${user.userType}_${user.userName}`;

      await this.redisClient.delValue(userLoginPermissionName);
      await this.redisClient.delValue(userRefreshPermissionName);

      this.redisClient.setValue(
        userLoginPermissionName,
        JSON.stringify(userSecurityTokenDto),
        TOKEN_EXPIRATION
      );

      this.redisClient.setValue(
        userRefreshPermissionName,
        JSON.stringify(refreshTokenDto),
        TOKEN_EXPIRATION
      );

      // Initialize activity timestamp for inactivity tracking
      const activityKey = `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_${user.userType}_${user.userName}`;
      await this.redisClient.setValue(
        activityKey,
        Date.now().toString(),
        TOKEN_EXPIRATION
      );

      // SEND MESSAGE TO BO TO UPDATE LAST LOGIN DATE/TIME
      await this.pulsarProducerClient.produce(PulsarTopics.BACK_OFFICE, {
        action: PulsarDataAction.UPDATE,
        data: {
          id: user.externalId,
          lastLoginDateTime: new Date(),
        },
        objectName: 'user',
      });

      Object.assign(result, {
        jwt: token,
        refresh: REFRESH_TOKEN_KEY,
      });
    }

    logger.debug('authenticate_by_email_result', result);

    return Promise.resolve(result);
  }

  async refreshSecurityToken(
    userName: string,
    refreshToken: string
  ): Promise<TokenResultDto> {
    // Try to get cached permission to determine user type
    let userType = 'ADMIN'; // default
    for (const type of ['ADMIN', 'FRANCHISEE', 'CLIENT']) {
      const testKey = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${type}_${userName}`;
      const testVal = await this.redisClient.getValue(testKey);
      if (testVal) {
        userType = type;
        break;
      }
    }

    const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${userType}_${userName}`;
    const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userType}_${userName}`;

    const refresh_token_val = await this.redisClient.getValue(
      userRefreshPermissionName
    );

    if (!refresh_token_val) {
      throw friendlyError(
        new Error(ErrorKeyTypes.REFRESH_TOKEN_EXPIRED),
        'refresh_token'
      );
    }

    //const token_info = JSON.parse(refresh_token_credential);
    const cacheRefreshTokenDto: RefreshTokenDto = JSON.parse(refresh_token_val);

    if (refreshToken != cacheRefreshTokenDto.token_key) {
      throw friendlyError(
        new Error(ErrorKeyTypes.INVALID_REFRESH_TOKEN),
        'refresh_token'
      );
    }

    let token_expired = false;
    try {
      jwt.verify(cacheRefreshTokenDto.token, environment.JWT_SECRET_KEY);
    } catch (error) {
      if ((error as Error).message.includes('jwt expired')) {
        token_expired = true;
      } else {
        throw error;
      }
    }

    if (token_expired) {
      const user = await this.userService.findByUserName(
        cacheRefreshTokenDto.user_name
      );

      if (!user) {
        throw friendlyError(
          new Error(ErrorKeyTypes.USER_DOES_NOT_EXISTS),
          'refresh_token'
        );
      }

      // Fetch fresh session configuration
      const sessionConfig = await this.sessionConfigService.getSessionConfig(
        user.organization.id
      );

      const TOKEN_EXPIRATION = sessionConfig.sessionTimeoutMin * 60;
      const JWT_EXPIRATION = `${sessionConfig.sessionTimeoutMin}m`;

      const token_secret = cuid();

      const userSecurityTokenDto: UserIdentityPermission = {
        email: user.email,
        external_id: user.externalId,
        external_orgid: user.organization.externalId,
        firstName: user.firstName,
        lastName: user.lastName,
        organization_id: user.organization.id,
        permission: user.permissions,
        token_secret: token_secret,
        user_id: user.id,
        user_name: user.userName,
        user_type: user.userType,
      };

      const userToken: UserToken = {
        token_secret: token_secret,
        user_name: user.userName,
        user_type: user.userType,
      };

      const token = jwt.sign(userToken, environment.JWT_SECRET_KEY, {
        expiresIn: JWT_EXPIRATION,
        issuer: environment.JWT_ISSUER,
      });

      const refreshTokenDto: RefreshTokenDto = {
        external_user_id: user.externalId,
        token: token,
        token_key: refreshToken,
        user_id: user.id,
        user_name: user.userName,
      };

      this.redisClient.setValue(
        userLoginPermissionName,
        JSON.stringify(userSecurityTokenDto),
        TOKEN_EXPIRATION
      );

      this.redisClient.setValue(
        userRefreshPermissionName,
        JSON.stringify(refreshTokenDto),
        TOKEN_EXPIRATION
      );

      return { jwt: token, refresh: refreshToken };
    } else {
      return { jwt: cacheRefreshTokenDto.token, refresh: refreshToken };
    }
  }

  async isValidRefreshToken(
    userName: string,
    refreshToken: string
  ): Promise<boolean> {
    // Try all user types
    for (const type of ['ADMIN', 'FRANCHISEE', 'CLIENT']) {
      const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${type}_${userName}`;
      const val = await this.redisClient.getValue(userRefreshPermissionName);

      if (val) {
        const refresh: RefreshTokenDto = JSON.parse(val);
        if (refresh.token_key === refreshToken) {
          return true;
        }
      }
    }
    return false;
  }

  async isValidToken(token: string): Promise<boolean> {
    try {
      jwt.verify(token, environment.JWT_SECRET_KEY);
      jwt.verify(
        token,
        environment.JWT_SECRET_KEY,
        { issuer: environment.JWT_ISSUER },
        (err) => {
          if (err) {
            if (err && (err as Error).message == 'invalid issuer') {
              logger.error('is_valid_token_verify_issuer', {
                error_message: (err as Error).message,
              });
              return false;
            }
          }
        }
      );

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const tokenVal = jwt.decode(token) as any;
      const userName = tokenVal.user_name;
      const userType = tokenVal.user_type || 'ADMIN';

      const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userType}_${userName}`;

      const cachePermission = (await this.redisClient.getValue(
        userLoginPermissionName
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      )) as any;

      if (!cachePermission) {
        return Promise.resolve(false);
      }

      const userSecurityTokenDto: UserIdentityPermission = JSON.parse(
        cachePermission
      ) as UserIdentityPermission;

      if (userSecurityTokenDto.token_secret != tokenVal.token_secret) {
        return Promise.resolve(false);
      }

      return true;
    } catch (error) {
      logger.debug('is_valid_token_verify_token', {
        error_message: (error as Error).message,
      });
      return false;
    }
  }

  async destroyUserLoginCacheByUserName(
    userName: string,
    userType?: string
  ): Promise<boolean> {
    // If userType provided, delete specific cache
    if (userType) {
      const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${userType}_${userName}`;
      const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userType}_${userName}`;
      this.redisClient.delValue(userRefreshPermissionName);
      this.redisClient.delValue(userLoginPermissionName);
    } else {
      // Delete all types for backward compatibility
      for (const type of ['ADMIN', 'FRANCHISEE', 'CLIENT']) {
        const userRefreshPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_REFRESH_NAME}_${type}_${userName}`;
        const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${type}_${userName}`;
        this.redisClient.delValue(userRefreshPermissionName);
        this.redisClient.delValue(userLoginPermissionName);
      }
    }
    return false;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async getUserPermissionByToken(
    token: string
  ): Promise<{ valid: boolean; userPermission?: UserIdentityPermission }> {
    const valid = await this.isValidToken(token);

    if (!valid) {
      return Promise.resolve({ valid: false });
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const tokenVal = jwt.decode(token) as any;
    const userName = tokenVal.user_name;
    const userType = tokenVal.user_type || 'ADMIN';
    const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${userType}_${userName}`;

    const cachePermission = (await this.redisClient.getValue(
      userLoginPermissionName
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    )) as any;

    const userSecurityTokenDto: UserIdentityPermission = JSON.parse(
      cachePermission
    ) as UserIdentityPermission;

    logger.debug('token_user_permission', { tokenVal, userSecurityTokenDto });

    if (userSecurityTokenDto && userSecurityTokenDto.user_name == userName) {
      return Promise.resolve({
        userPermission: userSecurityTokenDto,
        valid: true,
      });
    }

    return Promise.resolve({ valid: false });
  }

  async getSystemSettingsByToken(
    token: string,
    userName: string
  ): Promise<SystemSettingsModel> {
    const userRegistrationTokenName = `${RedisEntryNames.REDIS_USER_RESET_PASSWORD_TOKEN}_${userName}`;
    const cacheRegistrationToken = (await this.redisClient.getValue(
      userRegistrationTokenName
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    )) as any;
    if (!cacheRegistrationToken) {
      throw new Error(ErrorKeyTypes.INVALID_REGISTRATION_TOKEN);
    }
    const cacheRegistrationTokenDto: UserRegistrationTokenDto = JSON.parse(
      cacheRegistrationToken
    );
    if (!(cacheRegistrationTokenDto.token_secret == token)) {
      throw new Error(ErrorKeyTypes.INVALID_REGISTRATION_TOKEN);
    }
    const user: UserModel | null = await this.userService.findOne({
      relations: ['organization'],
      where: { userName },
    });
    if (!user) {
      throw new Error(ErrorKeyTypes.INVALID_USERNAME);
    }
    const systemSettings = await this.systemSettingsService.findOne({
      relations: ['securityLevel'],
      where: { externalOrgId: user.organization.externalId },
    });
    if (!systemSettings) {
      throw new Error(ErrorKeyTypes.INVALID_SYSTEM_SETTINGS);
    }
    const securityLevelConfiguration =
      systemSettings.securityLevel.configuration;
    if (!securityLevelConfiguration) {
      throw new Error(ErrorKeyTypes.INVALID_SECURITY_LEVEL_CONFIGURATION);
    }
    return Promise.resolve(systemSettings);
  }

  /**
   * @deprecated Login lockout feature has been disabled
   * This method is kept for backward compatibility but does nothing
   * @returns false - user is never locked
   */
  async lockUser(user: string, time: string) {
    // Feature disabled - no longer lock users
    logger.debug('lockUser_disabled', { user, time });
    return false;
  }

  /**
   * Clear all user lockout entries from Redis
   * Used during deployment to unlock all users when lockout feature is disabled
   * @returns number of cleared lock entries
   */
  async clearAllUserLocks(): Promise<number> {
    try {
      const pattern = `${RedisEntryNames.REDIS_USER_ATTEMPT}_*`;
      const keys = await this.redisClient.scanKeys(pattern);

      if (keys && keys.length > 0) {
        await Promise.all(keys.map((key) => this.redisClient.delValue(key)));
        logger.info('cleared_user_locks', { count: keys.length, keys });
        return keys.length;
      }

      logger.info('no_user_locks_to_clear');
      return 0;
    } catch (error) {
      logger.error('clear_user_locks_error', {
        error: (error as Error).message,
      });
      return 0;
    }
  }

  /**
   * Update user activity timestamp for inactivity tracking
   */
  async updateUserActivity(userName: string, userType?: string): Promise<void> {
    try {
      // If userType not provided, try to find it from existing sessions
      let type = userType;
      if (!type) {
        for (const t of ['ADMIN', 'FRANCHISEE', 'CLIENT']) {
          const testKey = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${t}_${userName}`;
          const exists = await this.redisClient.getValue(testKey);
          if (exists) {
            type = t;
            break;
          }
        }
      }

      if (!type) {
        type = 'ADMIN'; // fallback
      }

      const activityKey = `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_${type}_${userName}`;
      const userLoginPermissionName = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${type}_${userName}`;

      // Get current session TTL to preserve it
      const ttl = await this.redisClient.getTTL(userLoginPermissionName);

      if (ttl > 0) {
        // Update activity timestamp with same TTL as session
        await this.redisClient.setValue(
          activityKey,
          Date.now().toString(),
          ttl
        );
        logger.debug('user_activity_updated', { userName, userType: type });
      }
    } catch (error) {
      logger.error('update_user_activity_error', {
        error: (error as Error).message,
        userName,
      });
    }
  }

  /**
   * Check if user session has exceeded inactivity timeout
   */
  async checkInactivityTimeout(
    userName: string,
    orgId: string,
    userType?: string
  ): Promise<boolean> {
    try {
      // If userType not provided, try to find it from existing sessions
      let type = userType;
      if (!type) {
        for (const t of ['ADMIN', 'FRANCHISEE', 'CLIENT']) {
          const testKey = `${RedisEntryNames.REDIS_USER_LOGIN_PERMISSION_NAME}_${t}_${userName}`;
          const exists = await this.redisClient.getValue(testKey);
          if (exists) {
            type = t;
            break;
          }
        }
      }

      if (!type) {
        type = 'ADMIN'; // fallback
      }

      const activityKey = `${RedisEntryNames.REDIS_USER_LAST_ACTIVITY}_${type}_${userName}`;
      const lastActivity = await this.redisClient.getValue(activityKey);

      if (!lastActivity) {
        // No activity record = expired
        return true;
      }

      const sessionConfig =
        await this.sessionConfigService.getSessionConfig(orgId);
      const inactivityTimeoutMs =
        sessionConfig.inactivityTimeoutMin * 60 * 1000;
      const lastActivityTime = parseInt(lastActivity);

      const isInactive = Date.now() - lastActivityTime > inactivityTimeoutMs;

      if (isInactive) {
        logger.info('user_inactivity_timeout_detected', {
          userName,
          userType: type,
          lastActivityTime: new Date(lastActivityTime),
          inactivityTimeoutMin: sessionConfig.inactivityTimeoutMin,
        });
      }

      return isInactive;
    } catch (error) {
      logger.error('check_inactivity_timeout_error', {
        error: (error as Error).message,
        userName,
      });
      return false; // Fail open - don't log out on error
    }
  }
}
