import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { RoleModel } from '../datasource/models/RoleModel';
import { ModelName } from '../enums/ModelObjectEnums';
import { BaseService } from './BaseService';
import { OrganizationService } from './OrganizationService';

@Service()
export class RoleService extends BaseService<RoleModel, string> {
  constructor(private organizationService: OrganizationService) {
    const repository = appDataSource.getRepository(RoleModel);
    super(repository, ModelName.ROLE);
  }
}
