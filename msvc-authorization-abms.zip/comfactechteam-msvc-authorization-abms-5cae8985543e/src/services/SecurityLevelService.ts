import 'reflect-metadata';

import { Service } from 'typedi';

import { appDataSource } from '../datasource/config/database';
import { SecurityLevelModel } from '../datasource/models/SecurityLevelModel';
import { ModelName } from '../enums/ModelObjectEnums';
import { BaseService } from './BaseService';

@Service()
export class SecurityLevelService extends BaseService<
  SecurityLevelModel,
  string
> {
  constructor() {
    const repository = appDataSource.getRepository(SecurityLevelModel);
    super(repository, ModelName.SECURITYLEVEL);
  }
}
