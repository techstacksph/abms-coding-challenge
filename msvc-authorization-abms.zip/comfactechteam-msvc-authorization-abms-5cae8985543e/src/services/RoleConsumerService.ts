import 'reflect-metadata';

import { Service } from 'typedi';
import { Container } from 'typeorm-typedi-extensions';

import { RoleModel } from '../datasource/models/RoleModel';
import { logger } from '../utils/LoggerUtils';
import { RoleService } from './RoleService';
import { UserService } from './UserService';

@Service()
export class RoleConsumerService {
  private readonly roleService: RoleService;
  private readonly userService: UserService;
  constructor() {
    this.roleService = Container.get(RoleService);
    this.userService = Container.get(UserService);
  }

  async createOrUpdateRole(entity: RoleModel): Promise<boolean> {
    logger.debug('pulsar_processor_create_update_role', { entity });
    let result = false;

    const record = await this.roleService.findOne({
      where: { externalId: entity.externalId },
    });

    if (record) {
      logger.debug('pulsar_processor_update_role', { entity });

      await this.roleService.update(record.id, entity, {
        userId: entity.updatedById,
        userName: entity.updatedByName,
      });

      const users = await this.userService.find({
        where: { externalRoleId: record.externalId },
      });

      if (users && users.length > 0) {
        for (const user of users) {
          await this.userService.destroyUserLoginCache(
            user.userName.toString()
          );
          await this.userService.destroyResetPasswordTokenCache(
            user.userName.toString()
          );
        }
      }

      result = true;
    } else {
      logger.debug('pulsar_processor_create_role', { entity });

      try {
        await this.roleService.save(entity, {
          userId: entity.createdById,
          userName: entity.createdByName,
        });
      } catch (error) {
        logger.debug('error_creating_role', { error });
      }

      result = true;
    }

    return Promise.resolve(result);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async deleteRole(data: any): Promise<boolean> {
    logger.debug('pulsar_processor_delete_role');
    let result = false;

    const record = await this.roleService.findOne({
      where: { externalId: data.externalId },
    });

    if (record) {
      logger.debug('pulsar_processor_delete_role', { data, record });

      await this.roleService.softRemove(record.id, {
        userId: data.deletedBy,
        userName: data?.deletedByName,
      });
      result = true;
    }
    return Promise.resolve(result);
  }
}
