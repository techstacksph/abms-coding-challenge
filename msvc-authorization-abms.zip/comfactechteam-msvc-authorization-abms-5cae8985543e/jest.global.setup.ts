export default async () => {
  //Jest global async setup here if any
};
